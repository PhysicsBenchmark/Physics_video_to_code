#!/usr/bin/env bash
# setup_env.sh
# ============
# One-shot environment setup for Physics-Simulation-Code-Generation.
#
# Creates a new conda environment (default: phys-sim-cg) with all packages
# needed to run:
#   - The current repo's matplotlib/scipy simulations
#   - The MuJoCo-based standalone scripts
#   - Sim2Reason's simulation + recording pipeline
#
# Detected on this machine:
#   CUDA Driver  12.2   (libEGL_nvidia.so.0 already installed → EGL headless OK)
#   nvcc         12.1
#   Platform     Ubuntu 20.04, A100-SXM4-80GB
#
# Usage:
#   bash setup_env.sh               # create env "phys-sim-cg"
#   bash setup_env.sh myenvname     # create env with custom name
#   bash setup_env.sh --skip-conda  # skip env creation (install into active env)

set -euo pipefail

# ── Colours ──────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
info()    { echo -e "${CYAN}[INFO]${NC}  $*"; }
ok()      { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
err_msg() { echo -e "${RED}[ERROR]${NC} $*"; }

# ── Args ─────────────────────────────────────────────────────────────────────
ENV_NAME="${1:-phys-sim-cg}"
PYTHON_VERSION="3.10"
SKIP_CONDA=false
[[ "${1:-}" == "--skip-conda" ]] && { SKIP_CONDA=true; ENV_NAME="(current env)"; }

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── Header ───────────────────────────────────────────────────────────────────
echo ""
echo "════════════════════════════════════════════════════════════════════"
echo "   Physics-Simulation-Code-Generation  —  Environment Setup"
echo "════════════════════════════════════════════════════════════════════"

# ── 1. CUDA / GPU check ───────────────────────────────────────────────────────
# Note: capture outputs into variables *before* piping to head/grep to avoid
# SIGPIPE broken-pipe failures under `set -o pipefail`.
info "Checking CUDA / GPU …"

CUDA_DRIVER="unknown"
CUDA_TOOLKIT="unknown"

if command -v nvidia-smi &>/dev/null; then
    # Capture full output first; then slice in bash (no subshell pipeline risk)
    _smi_drivers=$(nvidia-smi --query-gpu=driver_version --format=csv,noheader 2>/dev/null || true)
    _smi_names=$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null || true)
    CUDA_DRIVER=$(echo "$_smi_drivers" | awk 'NR==1' | tr -d ' \r')
    N_GPUS=$(echo "$_smi_names" | grep -c . || true)
    GPU_NAME=$(echo "$_smi_names" | awk 'NR==1' | sed 's/^[[:space:]]*//')
    ok "Driver ${CUDA_DRIVER}  |  ${N_GPUS}× ${GPU_NAME}"
else
    warn "nvidia-smi not found — GPU features will not be available."
fi

if command -v nvcc &>/dev/null; then
    _nvcc_out=$(nvcc --version 2>/dev/null || true)
    CUDA_TOOLKIT=$(echo "$_nvcc_out" | awk '/release/{print $6}' | tr -d ',')
    ok "CUDA Toolkit ${CUDA_TOOLKIT}"
else
    warn "nvcc not found."
fi

# Verify EGL is available (required for MuJoCo headless rendering)
_ldconfig_out=$(ldconfig -p 2>/dev/null || true)
if echo "$_ldconfig_out" | grep -q "libEGL_nvidia"; then
    ok "libEGL_nvidia found  →  MUJOCO_GL=egl will work (headless GPU rendering)"
    MUJOCO_GL_BACKEND="egl"
elif echo "$_ldconfig_out" | grep -q "libOSMesa"; then
    warn "libEGL_nvidia not found, but libOSMesa available → falling back to osmesa (software render)"
    MUJOCO_GL_BACKEND="osmesa"
else
    warn "No suitable GL/EGL library found.  MuJoCo rendering may fail."
    MUJOCO_GL_BACKEND="egl"
fi

# ── 2. Conda environment ──────────────────────────────────────────────────────
if $SKIP_CONDA; then
    info "Skipping conda env creation (--skip-conda)."
else
    CONDA_BASE=$(conda info --base 2>/dev/null || echo "")
    if [[ -z "$CONDA_BASE" ]]; then
        err_msg "conda not found — please install Miniconda/Anaconda first."
        exit 1
    fi

    # shellcheck source=/dev/null
    source "${CONDA_BASE}/etc/profile.d/conda.sh"

    _env_list=$(conda env list 2>/dev/null || true)
    if echo "$_env_list" | awk '{print $1}' | grep -qx "${ENV_NAME}"; then
        warn "Conda env '${ENV_NAME}' already exists.  Updating packages (not recreating)."
    else
        info "Creating conda env '${ENV_NAME}' (Python ${PYTHON_VERSION}) …"
        conda create -n "${ENV_NAME}" python="${PYTHON_VERSION}" -y
        ok "Created env '${ENV_NAME}'."
    fi

    info "Activating env '${ENV_NAME}' …"
    conda activate "${ENV_NAME}"
fi

# Sanity check — make sure we're in the right env
ACTIVE_PY=$(python -c "import sys; print(sys.executable)")
info "Using Python: ${ACTIVE_PY}  ($(python --version 2>&1))"

# ── 3. Upgrade pip / setuptools ───────────────────────────────────────────────
info "Upgrading pip …"
pip install --quiet --upgrade pip setuptools wheel

# ── 4. Core scientific stack ──────────────────────────────────────────────────
info "Installing core scientific packages …"
pip install --quiet \
    "numpy>=1.24.0,<2.0.0" \
    "scipy>=1.10.0" \
    "matplotlib>=3.7.0" \
    "tqdm>=4.65.0" \
    "pillow"
ok "numpy / scipy / matplotlib / tqdm"

# ── 5. MuJoCo ────────────────────────────────────────────────────────────────
# mujoco 3.x supports CUDA 12.x and Python 3.8–3.12.
# For headless servers we rely on EGL (NVIDIA) rather than GLFW.
info "Installing MuJoCo …"
pip install --quiet mujoco
ok "mujoco $(python -c 'import mujoco; print(mujoco.__version__)')"

# ── 6. Video / image I/O ──────────────────────────────────────────────────────
info "Installing imageio + ffmpeg backend …"
pip install --quiet "imageio>=2.28.0" imageio-ffmpeg
ok "imageio + imageio-ffmpeg"

# ── 7. Sim2Reason dependencies ────────────────────────────────────────────────
info "Installing Sim2Reason runtime dependencies …"
pip install --quiet \
    pyyaml \
    "omegaconf>=2.3.0" \
    "hydra-core>=1.3.0" \
    tabulate \
    pandas \
    ipdb
ok "pyyaml / omegaconf / hydra-core / tabulate / pandas / ipdb"

# ── 8. Dataset generation extras ─────────────────────────────────────────────
info "Installing dataset utilities …"
pip install --quiet \
    "networkx" \
    "rich"
ok "networkx / rich"

# ── 9. Write conda env activation hooks ───────────────────────────────────────
# Sets MUJOCO_GL and PYTHONPATH automatically on `conda activate`.
# Use `sys.prefix` from the *active* Python so we get the correct env path
# regardless of whether it lives in the user's home or the system anaconda.
if ! $SKIP_CONDA; then
    CONDA_ENV_PATH=$(python -c "import sys; print(sys.prefix)")
    ACT_DIR="${CONDA_ENV_PATH}/etc/conda/activate.d"
    DAC_DIR="${CONDA_ENV_PATH}/etc/conda/deactivate.d"
    mkdir -p "${ACT_DIR}" "${DAC_DIR}"

    cat > "${ACT_DIR}/phys-sim-env.sh" <<HOOK
#!/usr/bin/env bash
# Auto-set environment variables for phys-sim-cg

# MuJoCo headless rendering via NVIDIA EGL (no display required)
export MUJOCO_GL="${MUJOCO_GL_BACKEND}"

# Make the repo importable from anywhere
export PYTHONPATH="${REPO_ROOT}:\${PYTHONPATH:-}"

# Suppress MuJoCo/GL deprecation noise
export PYOPENGL_PLATFORM="egl"
HOOK

    cat > "${DAC_DIR}/phys-sim-env.sh" <<HOOK
#!/usr/bin/env bash
unset MUJOCO_GL
unset PYOPENGL_PLATFORM
HOOK

    chmod +x "${ACT_DIR}/phys-sim-env.sh" "${DAC_DIR}/phys-sim-env.sh"
    ok "Activation hooks written → MUJOCO_GL=${MUJOCO_GL_BACKEND} set automatically."
fi

# ── 10. Quick smoke test ──────────────────────────────────────────────────────
info "Running smoke tests …"

SMOKE_SCRIPT=$(cat <<'PYEOF'
import sys, importlib
REQUIRED = [
    ("numpy",      "np"),
    ("scipy",      None),
    ("matplotlib", None),
    ("mujoco",     None),
    ("imageio",    None),
    ("yaml",       None),
    ("omegaconf",  None),
    ("hydra",      None),
    ("tabulate",   None),
    ("pandas",     None),
    ("tqdm",       None),
]
ok = True
for mod, alias in REQUIRED:
    try:
        m = importlib.import_module(mod)
        ver = getattr(m, "__version__", "?")
        print(f"  ✓  {mod:<16} {ver}")
    except ImportError as e:
        print(f"  ✗  {mod:<16} MISSING — {e}", file=sys.stderr)
        ok = False

# MuJoCo headless render test
import os
os.environ.setdefault("MUJOCO_GL", "egl")
import mujoco, numpy as np
xml = """<mujoco><worldbody><geom type="sphere" size="0.1"/></worldbody></mujoco>"""
try:
    m = mujoco.MjModel.from_xml_string(xml)
    d = mujoco.MjData(m)
    r = mujoco.Renderer(m, 64, 64)
    mujoco.mj_step(m, d)
    r.update_scene(d)
    _ = r.render()
    print(f"  ✓  {'mujoco render':<16} headless EGL OK")
except Exception as e:
    print(f"  ✗  {'mujoco render':<16} FAILED — {e}", file=sys.stderr)
    ok = False

sys.exit(0 if ok else 1)
PYEOF
)

if MUJOCO_GL="${MUJOCO_GL_BACKEND}" python -c "${SMOKE_SCRIPT}"; then
    ok "All smoke tests passed."
else
    warn "Some imports failed — check the output above."
fi

# ── Done ──────────────────────────────────────────────────────────────────────
echo ""
echo "════════════════════════════════════════════════════════════════════"
ok  "Setup complete!"
echo ""
if ! $SKIP_CONDA; then
    echo -e "  Activate the environment:  ${CYAN}conda activate ${ENV_NAME}${NC}"
    echo -e "  MUJOCO_GL=${MUJOCO_GL_BACKEND} will be set automatically on activation."
fi
echo ""
echo "  Generate scipy dataset:   python generate_dataset_scipy.py --sims simple_pendulum"
echo "  Generate MuJoCo dataset:  python generate_dataset_mujoco.py --experiments spring_block_systems"
echo "  Generate Kubric dataset:  python generate_dataset_kubric.py --experiments bouncing_balls_arena"
echo "════════════════════════════════════════════════════════════════════"
