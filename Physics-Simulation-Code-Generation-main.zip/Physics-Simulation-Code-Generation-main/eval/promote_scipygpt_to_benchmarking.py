"""Promote dataset_scipygpt/ into a benchmarking-shaped folder and emit
manifest.csv matching the existing benchmarking_data schema.

Default target: benchmarking_data_rebuttal/ (a separate, isolated folder that
mirrors benchmarking_data's structure but only contains scipygpt).

Structure produced:
  <target-root>/
    scipygpt/
      <experiment>/
        <sample_id>/ {video.mp4, params.json, cot.json, simulation_code.py}
    manifest.csv          # engine,experiment,sample_id,original_path,
                          # video_path,target_fps,target_resolution,seed

Modes:
  --dry-run       print planned actions, don't copy or write
  --copy          copy files (default: symlink) — copy is safer if you plan
                  to modify sources later
  --target-root   base folder to write into (default: benchmarking_data_rebuttal)

Usage:
  python eval/promote_scipygpt_to_benchmarking.py --dry-run
  python eval/promote_scipygpt_to_benchmarking.py
  python eval/promote_scipygpt_to_benchmarking.py --copy
  python eval/promote_scipygpt_to_benchmarking.py --target-root benchmarking_data
"""
import argparse
import csv
import shutil
from pathlib import Path

ROOT = Path("/scr/adityag6/Physics-Simulation-Code-Generation")
SRC = ROOT / "dataset_scipygpt"

ENGINE = "scipygpt"
TARGET_FPS = 5      # matches existing scipy/kubric rows
TARGET_RES = "720x360"  # generation is aspect-varied; this is what the
                        # normalizer targets (matches scipy convention)
SEED = 42
REQUIRED_FILES = ("video.mp4", "params.json", "cot.json", "simulation_code.py")


def find_samples():
    """Yield (experiment_slug, sample_id, source_dir) tuples."""
    if not SRC.exists():
        raise SystemExit(f"Source not found: {SRC}")
    for exp_dir in sorted(SRC.iterdir()):
        if not exp_dir.is_dir():
            continue
        for sid_dir in sorted(exp_dir.iterdir()):
            if not sid_dir.is_dir():
                continue
            # Sanity check: all required files must be present
            missing = [f for f in REQUIRED_FILES if not (sid_dir / f).exists()]
            if missing:
                print(f"  SKIP {exp_dir.name}/{sid_dir.name}: missing {missing}")
                continue
            yield exp_dir.name, sid_dir.name, sid_dir


def promote_files(src_dir: Path, dst_dir: Path, mode: str, dry_run: bool):
    if dry_run:
        print(f"    [dry-run] would {mode} {src_dir} -> {dst_dir}")
        return
    dst_dir.mkdir(parents=True, exist_ok=True)
    for name in REQUIRED_FILES:
        src, dst = src_dir / name, dst_dir / name
        if dst.exists() or dst.is_symlink():
            dst.unlink()
        if mode == "symlink":
            dst.symlink_to(src.resolve())
        else:
            shutil.copy2(src, dst)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--copy", action="store_true",
                    help="copy files instead of symlinking (safer if you'll modify sources)")
    ap.add_argument("--target-root", type=str, default="benchmarking_data_rebuttal",
                    help="base folder to write into (relative to repo root)")
    args = ap.parse_args()
    mode = "copy" if args.copy else "symlink"

    dst_root = ROOT / args.target_root
    dst_engine_dir = dst_root / ENGINE
    manifest_csv = dst_root / "manifest.csv"

    print(f"Source:       {SRC}")
    print(f"Target root:  {dst_root}")
    print(f"Engine dir:   {dst_engine_dir}")
    print(f"Manifest:     {manifest_csv}")
    print(f"File mode:    {mode}")
    print(f"Dry-run:      {args.dry_run}")
    print()

    new_rows = []
    n = 0
    for slug, sid, src_dir in find_samples():
        dst_dir = dst_engine_dir / slug / sid
        promote_files(src_dir, dst_dir, mode, args.dry_run)

        row = {
            "engine": ENGINE,
            "experiment": slug,
            "sample_id": sid,
            "original_path": str(src_dir.resolve()),
            "video_path": str((dst_dir / "video.mp4").resolve()),
            "target_fps": TARGET_FPS,
            "target_resolution": TARGET_RES,
            "seed": SEED,
        }
        new_rows.append(row)
        n += 1

    print(f"\n{n} samples planned across {len({r['experiment'] for r in new_rows})} experiments")

    if args.dry_run:
        print("\n[dry-run] no files written. Sample rows:")
        for r in new_rows[:3]:
            print(f"  {r}")
        return

    dst_root.mkdir(parents=True, exist_ok=True)
    print(f"\nWriting manifest to {manifest_csv}")
    with open(manifest_csv, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(new_rows[0].keys()))
        w.writeheader()
        w.writerows(new_rows)

    print("\nDone. Verify with:")
    print(f"  ls {dst_root}/")
    print(f"  ls {dst_engine_dir} | head")
    print(f"  head {manifest_csv}")
    print(f"  wc -l {manifest_csv}   # expect 76 (1 header + 75 rows)")


if __name__ == "__main__":
    main()
