"""Build failure-case comparison grids.

For each chosen scenario, lay out a single representative frame from the
reference video and from each of the 10 model outputs.

Outputs (under eval_outputs/_failure_grids/):
  combined.png            single figure, k rows x 11 cols
  individual_<i>_<eng>_<exp>_<sid>.png   one figure per scenario
"""
import argparse
import json
import statistics
import subprocess
import tempfile
from pathlib import Path

import imageio.v3 as iio
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path("/scr/adityag6/Physics-Simulation-Code-Generation")
OUT = ROOT / "eval_outputs" / "_failure_grids"
OUT.mkdir(exist_ok=True)
EVAL = ROOT / "eval_outputs"
REF_ROOT = ROOT / "benchmarking_data"

CLOSED = ["gpt_5_mini", "gemini_2_5_pro", "claude_sonnet_4_6",
          "grok_4_fast_reasoning", "nova_2_lite"]
OPEN = ["qwen3vl_30b_a3b", "internvl3_5_30b_a3b", "gemma_3_12b_it",
        "glm_4_1v_9b_thinking", "pixtral_12b"]
MODELS = CLOSED + OPEN
PRETTY = {
    "gpt_5_mini": "GPT-5 Mini",
    "gemini_2_5_pro": "Gemini 2.5 Pro",
    "claude_sonnet_4_6": "Claude Sonnet 4.6",
    "grok_4_fast_reasoning": "Grok 4 Fast",
    "nova_2_lite": "Nova 2 Lite",
    "qwen3vl_30b_a3b": "Qwen3-VL-30B",
    "internvl3_5_30b_a3b": "InternVL3.5-30B",
    "gemma_3_12b_it": "Gemma-3-12B-IT",
    "glm_4_1v_9b_thinking": "GLM-4.1V-9B",
    "pixtral_12b": "Pixtral-12B",
}


def middle_frame(video_path: Path) -> np.ndarray:
    """Return the middle frame of a video as RGB ndarray (H, W, 3)."""
    if not video_path.exists():
        print(f"  MISSING: {video_path}")
        return _placeholder("missing")
    try:
        frames = []
        for f in iio.imiter(video_path):  # uses ffmpeg backend
            frames.append(f)
        if not frames:
            print(f"  EMPTY: {video_path}")
            return _placeholder("empty")
        return frames[len(frames) // 2]
    except Exception as e:
        print(f"  ERR {type(e).__name__} on {video_path}: {e}")
        return _placeholder(f"err:{type(e).__name__}")


def _placeholder(text: str, h=240, w=320):
    img = np.full((h, w, 3), 240, dtype=np.uint8)
    return img  # caption will be drawn by matplotlib if needed


def find_failure_scenarios(k: int):
    """Pick k scenarios with all 10 model outputs + reference, ranked by
    lowest mean DINO-cosine across models. Mix kubric+scipy if possible."""
    scen = []
    base = EVAL / "gpt_5_mini" / "runs"
    for eng_dir in base.iterdir():
        for exp_dir in eng_dir.iterdir():
            for sid_dir in exp_dir.iterdir():
                scen.append((eng_dir.name, exp_dir.name, sid_dir.name))

    def has_all(key):
        e, x, s = key
        return all((EVAL / m / "runs" / e / x / s / "video.mp4").exists() for m in MODELS)
    def has_ref(key):
        e, x, s = key
        return (REF_ROOT / e / x / s / "video.mp4").exists()
    full = [k_ for k_ in scen if has_all(k_) and has_ref(k_)]

    dino = {}
    for m in MODELS:
        p = EVAL / m / "video_similarity.jsonl"
        if not p.exists():
            continue
        with open(p) as f:
            for line in f:
                try:
                    d = json.loads(line)
                except Exception:
                    continue
                if d.get("status") != "ok":
                    continue
                key = (d["engine"], d["experiment"], d["sample_id"])
                dino.setdefault(m, {})[key] = d.get("dino_cosine")

    ranked = []
    for key in full:
        vals = [dino.get(m, {}).get(key) for m in MODELS]
        vals = [v for v in vals if v is not None]
        if len(vals) < len(MODELS) - 2:  # need most models
            continue
        ranked.append((statistics.mean(vals), key))
    ranked.sort()

    picked = []
    seen_eng = {"kubric": 0, "scipy": 0}
    for _, key in ranked:
        # Quota: at most ceil(k/2) per engine
        if seen_eng[key[0]] >= max(1, (k + 1) // 2):
            continue
        picked.append(key)
        seen_eng[key[0]] += 1
        if len(picked) == k:
            break
    if len(picked) < k:
        for _, key in ranked:
            if key not in picked:
                picked.append(key)
                if len(picked) == k:
                    break
    return picked


def render_grid(scenarios, fname_stem, scale=2.0, orientation="horizontal"):
    """orientation: 'horizontal' = scenarios as rows; 'vertical' = scenarios as cols."""
    row_models = ["Reference"] + [PRETTY[m] for m in MODELS]
    sources = [None] + MODELS  # None means reference

    if orientation == "horizontal":
        n_rows, n_cols = len(scenarios), len(row_models)
    else:
        n_rows, n_cols = len(row_models), len(scenarios)

    fig, axes = plt.subplots(n_rows, n_cols,
                              figsize=(scale * n_cols, scale * n_rows + 0.4))
    if n_rows == 1:
        axes = axes[None, :]
    if n_cols == 1:
        axes = axes[:, None]

    for ci, (eng, exp, sid) in enumerate(scenarios):
        ref_img = middle_frame(REF_ROOT / eng / exp / sid / "video.mp4")
        col_label = f"{eng}/{exp}\nsid={sid}"
        for ri, src in enumerate(sources):
            if src is None:
                img = ref_img
            else:
                img = middle_frame(EVAL / src / "runs" / eng / exp / sid / "video.mp4")
            if orientation == "horizontal":
                ax = axes[ci, ri]
            else:
                ax = axes[ri, ci]
            ax.imshow(img)

    if orientation == "horizontal":
        for ri, t in enumerate(row_models):
            axes[0, ri].set_title(t, fontsize=9, pad=4)
        for ci, (eng, exp, sid) in enumerate(scenarios):
            axes[ci, 0].set_ylabel(f"{eng}/{exp}\nsid={sid}",
                                    fontsize=8, rotation=0, ha="right", va="center",
                                    labelpad=8)
    else:
        for ci, (eng, exp, sid) in enumerate(scenarios):
            axes[0, ci].set_title(f"{eng}/{exp}\nsid={sid}", fontsize=9, pad=4)
        for ri, t in enumerate(row_models):
            axes[ri, 0].set_ylabel(t, fontsize=10, rotation=0,
                                    ha="right", va="center", labelpad=8)

    for ax in axes.ravel():
        ax.set_xticks([]); ax.set_yticks([])
        for s in ax.spines.values():
            s.set_visible(False)
    fig.tight_layout()
    for ext in ("png", "pdf"):
        fig.savefig(f"{fname_stem}.{ext}",
                    dpi=180 if ext == "png" else None,
                    bbox_inches="tight")
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-k", type=int, default=5,
                    help="number of failure scenarios to show")
    ap.add_argument("--scenarios", nargs="*",
                    help="optional: explicit scenario keys eng/exp/sid (overrides auto)")
    ap.add_argument("--orientation", choices=["horizontal", "vertical"],
                    default="horizontal")
    args = ap.parse_args()

    if args.scenarios:
        scenarios = []
        for s in args.scenarios:
            e, x, sid = s.split("/")
            scenarios.append((e, x, sid))
    else:
        scenarios = find_failure_scenarios(args.k)

    print("Selected scenarios (lowest mean DINO across 10 models):")
    for s in scenarios:
        print("  -", "/".join(s))

    # Combined figure (writes both .png and .pdf)
    suffix = "_vertical" if args.orientation == "vertical" else ""
    render_grid(scenarios, str(OUT / f"combined{suffix}"),
                orientation=args.orientation)

    # Individual per-scenario figures
    for i, s in enumerate(scenarios):
        stem = OUT / f"individual_{i:02d}_{s[0]}_{s[1]}_{s[2]}{suffix}"
        render_grid([s], str(stem), orientation=args.orientation)

    print(f"Wrote to {OUT}/")


if __name__ == "__main__":
    main()
