"""Dump the full rebuttal analysis: Delta tables, DiD, Kendall's tau, explanations.
Likert values on paper 1-5 scale (internal 0-4 + 1)."""
import json, statistics as st
from collections import defaultdict
from pathlib import Path
from scipy.stats import kendalltau, spearmanr

ROOT = Path("/scr/adityag6/Physics-Simulation-Code-Generation")
REBUTTAL_MODELS = ["claude_sonnet_4_6","gpt_5_mini","gemini_2_5_pro","qwen3vl_30b_a3b",
                   "glm_4_1v_9b_thinking","internvl3_5_30b_a3b","gemma_3_12b_it","pixtral_12b"]
PRETTY = {"claude_sonnet_4_6":"Claude Sonnet 4.6","gpt_5_mini":"GPT-5 Mini",
          "gemini_2_5_pro":"Gemini 2.5 Pro","qwen3vl_30b_a3b":"Qwen3-VL-30B",
          "glm_4_1v_9b_thinking":"GLM-4.1V-9B","internvl3_5_30b_a3b":"InternVL3.5-30B",
          "gemma_3_12b_it":"Gemma-3-12B-IT","pixtral_12b":"Pixtral-12B"}
PARENTS = ["ball_wrapping_pole","balls_in_basin","block_on_sphere_basin","block_strikes_spring_pair",
           "cylinder_piston_ball","discs_friction_coupling","half_cylinder_drop","projectile_bounce",
           "ring_sticky_collision","semicircular_track","slab_springs_block_drop","sliding_block_step_topple",
           "stacked_balls_drop","wheel_down_stairs","wheel_wall_bounce"]
SUBS = ["name","statement","formula","overall"]

def get_first5_sids(p):
    by = defaultdict(set)
    for l in open(p):
        d=json.loads(l)
        if d.get("engine")!="scipy" or d.get("experiment") not in PARENTS: continue
        by[d["experiment"]].add(d["sample_id"])
    return {e:set(sorted(by[e])[:5]) for e in PARENTS}

def summarize(path,keep=None,vpath=None,tpath=None):
    eq=defaultdict(list); va=defaultdict(list)
    rs,rr,rv,cb=[],[],[],[]
    for l in open(path):
        d=json.loads(l)
        if d.get("skipped"): continue
        if keep is not None:
            if d.get("experiment") not in keep: continue
            if d["sample_id"] not in keep[d["experiment"]]: continue
        s=d.get("scores") or {}
        sc=d.get("scorer")
        if sc=="law_equivalence":
            for sf in SUBS:
                v=s.get(sf)
                if v is not None: eq[sf].append(v)
        elif sc=="law_validity":
            for sf in SUBS:
                v=s.get(sf)
                if v is not None: va[sf].append(v)
        elif sc=="runnability":
            rs.append(bool(s.get("syntax_ok")))
            rr.append(bool(s.get("runs_without_error")))
            rv.append(bool(s.get("produces_video_mp4")))
        elif sc=="codebleu":
            v=s.get("codebleu")
            if v is not None: cb.append(float(v))
    out={}
    for sf in SUBS:
        out[f"eq_{sf}"] = st.mean(eq[sf])+1 if eq[sf] else float("nan")
        out[f"va_{sf}"] = st.mean(va[sf])+1 if va[sf] else float("nan")
    out["syntax_ok"]=100*sum(rs)/len(rs) if rs else float("nan")
    out["runs_ok"]=100*sum(rr)/len(rr) if rr else float("nan")
    out["video_ok"]=100*sum(rv)/len(rv) if rv else float("nan")
    out["codebleu"]=st.mean(cb) if cb else float("nan")
    for kk in ("dino","xclip"):
        vals=[]
        if vpath and vpath.exists():
            for l in open(vpath):
                d=json.loads(l)
                if d.get("status")!="ok": continue
                if keep is not None:
                    if d.get("experiment") not in keep: continue
                    if d["sample_id"] not in keep[d["experiment"]]: continue
                v=d.get("dino_cosine" if kk=="dino" else "xclip_cosine")
                if v is not None: vals.append(v)
        out[kk]=st.mean(vals) if vals else float("nan")
    for kk in ("traj_coverage","traj_fidelity","traj_physics"):
        vals=[]
        if tpath and tpath.exists():
            for l in open(tpath):
                d=json.loads(l)
                if d.get("status")!="ok": continue
                if keep is not None:
                    if d.get("experiment") not in keep: continue
                    if d["sample_id"] not in keep[d["experiment"]]: continue
                fk={"traj_coverage":"coverage","traj_fidelity":"fidelity","traj_physics":"physics_score"}[kk]
                v=d.get(fk)
                if v is not None: vals.append(v)
        out[kk]=st.mean(vals) if vals else float("nan")
    return out

def collect():
    d={}
    for m in REBUTTAL_MODELS:
        ge=ROOT/"eval_outputs_rebuttal"/m/"eval_results.jsonl"
        ce=ROOT/"eval_outputs"/m/"eval_results.jsonl"
        gv=ROOT/"eval_outputs_rebuttal"/m/"video_similarity.jsonl"
        cv=ROOT/"eval_outputs"/m/"video_similarity.jsonl"
        gt=ROOT/"eval_outputs_rebuttal"/m/"trajectory_similarity_scipy.jsonl"
        ct=ROOT/"eval_outputs"/m/"trajectory_similarity_scipy.jsonl"
        keep=get_first5_sids(ce)
        d[m]=(summarize(ge,None,gv,gt), summarize(ce,keep,cv,ct))
    return d

def fd(v,n=2): return f"{v:+.{n}f}" if v==v else "nan"
def fv(v,n=2): return f"{v:.{n}f}" if v==v else "nan"

def ranked(vals):
    idx=sorted(enumerate(vals), key=lambda x:-x[1])
    r=[0]*len(vals)
    for k,(i,_) in enumerate(idx,1): r[i]=k
    return r

def render(data):
    L=[]; p=L.append
    neutrals=[m for m in REBUTTAL_MODELS if m not in ("claude_sonnet_4_6","gpt_5_mini")]

    p("# Rebuttal analysis: GPT-authored vs Claude-authored ground truth\n")
    p("**Matched design**: 15 Scipy experiments × 5 samples per arm = 75 samples per arm.")
    p("- GPT arm = `eval_outputs_rebuttal/` (GPT-5.5-authored + v2 cleanup)")
    p("- Claude arm = `eval_outputs/` filtered to same 15 parents × first-5 lex sample_ids")
    p("- Likert values on paper 1-5 scale (internal 0-4 + 1)")
    p("- 8 models; grok_4_fast_reasoning and nova_2_lite absent (no rebuttal inference)\n")

    p("## 1. Aggregate per-model per-arm scores (Δ = GPT − Claude)\n")
    p("| Model | runs_ok G/C/Δ | video_ok G/C/Δ | codebleu G/C/Δ | law_eq overall G/C/Δ | law_va overall G/C/Δ |")
    p("|---|---|---|---|---|---|")
    for m in REBUTTAL_MODELS:
        g,c=data[m]
        p(f"| {PRETTY[m]} | {g['runs_ok']:.1f}/{c['runs_ok']:.1f}/{g['runs_ok']-c['runs_ok']:+.1f}pp | "
          f"{g['video_ok']:.1f}/{c['video_ok']:.1f}/{g['video_ok']-c['video_ok']:+.1f}pp | "
          f"{fv(g['codebleu'],3)}/{fv(c['codebleu'],3)}/{fd(g['codebleu']-c['codebleu'],3)} | "
          f"{fv(g['eq_overall'])}/{fv(c['eq_overall'])}/{fd(g['eq_overall']-c['eq_overall'])} | "
          f"{fv(g['va_overall'])}/{fv(c['va_overall'])}/{fd(g['va_overall']-c['va_overall'])} |")
    p("")

    p("## 2. Δ (GPT − Claude) per Likert sub-score, paper 1-5 scale\n")
    for pref,lbl in [("eq","Law Equivalence"),("va","Law Validity")]:
        p(f"### {lbl}\n")
        p("| Model | Δ Name | Δ Statement | Δ Formula | Δ Overall |")
        p("|---|---:|---:|---:|---:|")
        for m in REBUTTAL_MODELS:
            g,c=data[m]
            p(f"| {PRETTY[m]} | {fd(g[f'{pref}_name']-c[f'{pref}_name'])} | "
              f"{fd(g[f'{pref}_statement']-c[f'{pref}_statement'])} | "
              f"{fd(g[f'{pref}_formula']-c[f'{pref}_formula'])} | "
              f"{fd(g[f'{pref}_overall']-c[f'{pref}_overall'])} |")
        p("")

    p("## 3. Difference-in-Differences (DiD) vs Neutral\n")
    p("Neutral = mean over 6 models excluding Claude Sonnet 4.6 and GPT-5 Mini:")
    p("Gemini 2.5 Pro, Qwen3-VL, InternVL3.5, Gemma-3-12B, GLM-4.1V, Pixtral-12B.\n")
    p("DiD_model = Δ_model − Δ_neutral. Positive DiD = model outperformed peers on the GPT arm.\n")
    for pref,lbl in [("eq","Law Equivalence"),("va","Law Validity")]:
        p(f"### {lbl} — DiD per sub-score\n")
        p("| Sub-score | Claude Δ | GPT Δ | Neutral Δ | DiD Claude | DiD GPT | Claude−GPT (interaction) |")
        p("|---|---:|---:|---:|---:|---:|---:|")
        for sf in SUBS:
            k=f"{pref}_{sf}"
            cd=data["claude_sonnet_4_6"][0][k]-data["claude_sonnet_4_6"][1][k]
            gd=data["gpt_5_mini"][0][k]-data["gpt_5_mini"][1][k]
            ng=st.mean(data[m][0][k] for m in neutrals)
            nc=st.mean(data[m][1][k] for m in neutrals)
            nd=ng-nc
            p(f"| {sf} | {fd(cd)} | {fd(gd)} | {fd(nd)} | {fd(cd-nd)} | {fd(gd-nd)} | {fd(cd-gd)} |")
        p("")

    p("## 4. Rank stability across arms (Kendall's τ, Spearman's ρ)\n")
    p("τ = 1: identical ranking. τ = 0: chance. τ = -1: reversed. Best model gets rank 1.\n")
    p("| Metric | Kendall τ | Kendall p | Spearman ρ | Spearman p |")
    p("|---|---:|---:|---:|---:|")
    for key,lbl in [("runs_ok","Runnability — runs ok"),
                    ("video_ok","Runnability — video ok"),
                    ("codebleu","CodeBLEU"),
                    ("eq_name","Law-equivalence — name"),
                    ("eq_statement","Law-equivalence — statement"),
                    ("eq_formula","Law-equivalence — formula"),
                    ("eq_overall","Law-equivalence — overall"),
                    ("va_name","Law-validity — name"),
                    ("va_statement","Law-validity — statement"),
                    ("va_formula","Law-validity — formula"),
                    ("va_overall","Law-validity — overall")]:
        gv=[data[m][0][key] for m in REBUTTAL_MODELS]
        cv=[data[m][1][key] for m in REBUTTAL_MODELS]
        tau,ptau=kendalltau(ranked(gv),ranked(cv))
        rho,prho=spearmanr(ranked(gv),ranked(cv))
        p(f"| {lbl} | {tau:+.3f} | {ptau:.4f} | {rho:+.3f} | {prho:.4f} |")
    p("")

    p("### Actual ranks per arm for headline metrics\n")
    for key,lbl in [("eq_overall","Law equivalence overall"),
                    ("va_overall","Law validity overall"),
                    ("runs_ok","Runnability runs_ok")]:
        p(f"**{lbl}**\n")
        p("| Model | GPT arm value | GPT rank | Claude arm value | Claude rank |")
        p("|---|---:|---:|---:|---:|")
        gvv=[(m,data[m][0][key]) for m in REBUTTAL_MODELS]
        cvv=[(m,data[m][1][key]) for m in REBUTTAL_MODELS]
        gr={m:r for r,(m,_) in enumerate(sorted(gvv,key=lambda x:-x[1]),1)}
        cr={m:r for r,(m,_) in enumerate(sorted(cvv,key=lambda x:-x[1]),1)}
        for m in REBUTTAL_MODELS:
            p(f"| {PRETTY[m]} | {fv(data[m][0][key])} | {gr[m]} | {fv(data[m][1][key])} | {cr[m]} |")
        p("")

    p("## 5. Video-similarity + trajectory metrics\n")
    p("**Note**: Rebuttal-arm DINO/XCLIP/CoTracker only computed for Qwen (GPU work paused by user).\n")
    p("| Model | DINO G | DINO C | XCLIP G | XCLIP C | traj cov G | traj cov C | traj fid G | traj fid C | traj physics G | traj physics C |")
    p("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
    for m in REBUTTAL_MODELS:
        g,c=data[m]
        cells=[PRETTY[m]]
        for k in ("dino","xclip","traj_coverage","traj_fidelity","traj_physics"):
            cells.append(fv(g[k],3)); cells.append(fv(c[k],3))
        p("| " + " | ".join(cells) + " |")
    p("")

    p("## 6. DiD explanation\n")
    p("**Difference-in-Differences (DiD)** = model's Δ minus the neutral group's Δ.\n")
    p("```")
    p("Δ_model     = model's GPT-arm score − model's Claude-arm score")
    p("Δ_neutral   = neutral group's GPT-arm mean − Claude-arm mean")
    p("DiD_model   = Δ_model − Δ_neutral")
    p("```\n")
    p("**Why subtract**: any observed Δ bundles two effects: (1) universal shift — this arm is intrinsically")
    p("harder/easier — and (2) model-specific effect. The neutral group estimates effect #1 so we can")
    p("isolate effect #2. Without neutrals, we can't distinguish \"this arm is harder\" from \"this model")
    p("has a home-arm advantage.\"\n")
    p("**Interpretation**:")
    p("- DiD ≈ 0: model behaves like the average model.")
    p("- DiD > 0: unusual boost on the GPT arm relative to peers.")
    p("- DiD < 0: unusual hit on the GPT arm relative to peers.\n")
    p("**Hypothesis scenarios**:\n")
    p("| Scenario | Claude DiD | GPT DiD | Reading |")
    p("|---|---|---|---|")
    p("| **B (GPT-family bias)** | ≈ 0 | > 0 | Un-debiased GPT corpus advantages GPT specifically. |")
    p("| **C (Claude-family bias)** | < 0 | ≈ 0 | Claude uniquely lost a home advantage. |")
    p("| **D (both frontier outperform)** | ≈ GPT DiD | ≈ Claude DiD | Both are outliers, same direction. No family bias. |")
    p("")

    p("## 7. Bottom line\n")
    k="eq_overall"
    cd=data["claude_sonnet_4_6"][0][k]-data["claude_sonnet_4_6"][1][k]
    gd=data["gpt_5_mini"][0][k]-data["gpt_5_mini"][1][k]
    ng=st.mean(data[m][0][k] for m in neutrals); nc=st.mean(data[m][1][k] for m in neutrals)
    nd=ng-nc
    p("On **law-equivalence Overall** (paper 1-5 scale):\n")
    p(f"- Claude Δ = {cd:+.3f} — Claude gained on GPT arm")
    p(f"- GPT-5 Mini Δ = {gd:+.3f} — GPT-5 Mini gained on GPT arm")
    p(f"- Neutral Δ = {nd:+.3f} — average non-frontier model lost on GPT arm")
    p(f"- Claude DiD = {cd-nd:+.3f}")
    p(f"- GPT-5 Mini DiD = {gd-nd:+.3f}")
    p(f"- Claude − GPT interaction = {cd-gd:+.3f}\n")
    p(f"**Scenario D**: both frontier models are outperformers on the GPT arm vs peers, in the same")
    p(f"direction, by nearly the same magnitude. The interaction is small ({cd-gd:+.3f}), meaning no")
    p(f"measurable GPT-family bias in the un-debiased arm.\n")
    p("**Rank stability on law_eq overall**:")
    gv=[data[m][0]["eq_overall"] for m in REBUTTAL_MODELS]
    cv=[data[m][1]["eq_overall"] for m in REBUTTAL_MODELS]
    tau,ptau=kendalltau(ranked(gv),ranked(cv))
    idx_ng=[i for i,m in enumerate(REBUTTAL_MODELS) if m!="gemma_3_12b_it"]
    gvng=[gv[i] for i in idx_ng]; cvng=[cv[i] for i in idx_ng]
    tng,png=kendalltau(ranked(gvng),ranked(cvng))
    p(f"- τ = {tau:+.3f} (p = {ptau:.4f}) across 8 models")
    p(f"- τ = {tng:+.3f} (p = {png:.4f}) with Gemma-3-12B excluded")
    p("\nRanking survives arm swap for the top of the leaderboard. Gemma's collapse on the un-debiased")
    p("GPT arm is the single reranking that breaks correlation.")
    return "\n".join(L)

def main():
    d=collect()
    md=render(d)
    outp=ROOT/"eval_outputs_rebuttal"/"REBUTTAL_ANALYSIS.md"
    outp.write_text(md)
    print(md)
    print(f"\n[written to {outp}]")

if __name__=="__main__": main()
