"""Print a side-by-side of GT vs candidate `physical_law` blocks for every
record in a results.jsonl, optionally annotated with judge overall_scores
from an eval_results.jsonl.

Usage:
  python eval/show_law_diff.py                                 # results.jsonl + eval_results.jsonl
  python eval/show_law_diff.py --results other_run.jsonl --eval other_eval.jsonl
  python eval/show_law_diff.py --limit 3                       # first 3 only
  python eval/show_law_diff.py --experiments accelerating_beaker_water
"""
from __future__ import annotations
import argparse, json, sys, textwrap
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from eval._common import BENCH_ROOT, read_results, sample_filter


def _wrap(s: str, w: int):
    if not s: return ["(empty)"]
    return textwrap.wrap(str(s), width=w) or [str(s)]


def _field(label, gt, cand, w):
    L, R = _wrap(gt or "(empty)", w), _wrap(cand or "(empty)", w)
    while len(L) < len(R): L.append("")
    while len(R) < len(L): R.append("")
    print(f"  {label}:")
    for l, r in zip(L, R):
        print(f"    {l:<{w}} │ {r:<{w}}")
    print()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results.jsonl")
    ap.add_argument("--eval",    default="eval_results.jsonl",
                    help="optional eval_results.jsonl to annotate with judge scores")
    ap.add_argument("--limit",       type=int, default=None)
    ap.add_argument("--engines",     nargs="*", default=None)
    ap.add_argument("--experiments", nargs="*", default=None)
    ap.add_argument("--width",       type=int, default=46)
    args = ap.parse_args()

    recs = [r for r in read_results(args.results)
            if sample_filter(r, args.experiments, args.engines)]
    if args.limit:
        recs = recs[: args.limit]

    # Optional: per-(engine, exp, sid) overall scores for each scorer
    score_by = defaultdict(lambda: defaultdict(list))   # key -> scorer -> [overalls]
    if Path(args.eval).exists():
        for line in open(args.eval):
            r = json.loads(line)
            key = (r["engine"], r["experiment"], r["sample_id"])
            sc = (r.get("scores") or {}).get("overall")
            if r["scorer"] in ("law_equivalence", "law_validity") and sc is not None:
                score_by[key][r["scorer"]].append(sc)

    W = args.width
    SEP = "─" * (W * 2 + 7)
    GT_HEADER = "GROUND TRUTH"
    CD_HEADER = "CANDIDATE"

    for rec in recs:
        eng, exp, sid = rec["engine"], rec["experiment"], rec["sample_id"]
        gt = json.loads(
            (BENCH_ROOT / eng / exp / sid / "cot.json").read_text()
        )["physical_law"]
        cd = (rec.get("parsed_cot") or {}).get("physical_law") or {}
        ann = score_by.get((eng, exp, sid), {})
        ann_str = ""
        for k in ("law_equivalence", "law_validity"):
            if ann.get(k):
                ann_str += f"  {k}.overall={ann[k]}"

        print(SEP)
        print(f"{eng}/{exp}/{sid}    model={rec.get('model','?')}{ann_str}")
        print(SEP)
        print(f"  {'':<{W}}   {GT_HEADER:<{W}} │ {CD_HEADER + ' (' + str(rec.get('model','?')) + ')':<{W}}")
        print(f"  {'':<{W}}   {'─'*W} │ {'─'*W}")
        _field("name",      gt.get("name", ""),      cd.get("name", ""),      W)
        _field("statement", gt.get("statement", ""), cd.get("statement", ""), W)
        _field("formula",   gt.get("formula", ""),   cd.get("formula", ""),   W)


if __name__ == "__main__":
    main()
