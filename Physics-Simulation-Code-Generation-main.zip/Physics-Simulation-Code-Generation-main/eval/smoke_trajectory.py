"""Smoke test multiple trajectory-extraction methods on 10 hand-picked gpt_5_mini pairs.

Each method extracts a list of trajectories from a video. Trajectories are then matched
between (rendered, reference) via Hungarian assignment using DTW similarity, and an
overall physics_score is computed.

We then correlate physics_score with human physics labels.

Methods:
    A. background subtraction + connected-component tracking (cv2)
    B. RAFT optical flow + motion-blob tracking (torchvision)
    C. CoTracker3 dense point tracking + clustering (HF)
    D. SAM2 video-mask propagation (HF)

Usage:
    python eval/smoke_trajectory.py --method bgsub
    python eval/smoke_trajectory.py --method raft --device cuda:7
    python eval/smoke_trajectory.py --method cotracker --device cuda:7
    python eval/smoke_trajectory.py --method sam2 --device cuda:7
    python eval/smoke_trajectory.py --method all --device cuda:7
"""
from __future__ import annotations

import argparse
import json
import os
import statistics
import time
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import cv2
import numpy as np

# ─── trajectory dataclass + metric ──────────────────────────────────

@dataclass
class Trajectory:
    """A single object's trajectory through a video.

    points: list of (frame_idx, x_norm, y_norm) where x/y are in [0,1]
    (normalised to image dims so we can compare across resolutions)."""
    object_id: int
    points: list[tuple[int, float, float]]

    @property
    def length(self):
        return len(self.points)

    @property
    def motion_magnitude(self):
        """Total distance travelled (in normalised coords)."""
        if self.length < 2: return 0.0
        d = 0.0
        for (_, x1, y1), (_, x2, y2) in zip(self.points, self.points[1:]):
            d += ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
        return d


def resample_trajectory(traj: Trajectory, n: int = 32) -> np.ndarray:
    """Resample to n equally-spaced points → (n, 2) array of (x, y)."""
    if traj.length == 0:
        return np.zeros((n, 2))
    if traj.length == 1:
        x, y = traj.points[0][1], traj.points[0][2]
        return np.tile([x, y], (n, 1))
    pts = np.array([(p[1], p[2]) for p in traj.points])
    # Resample uniformly
    old_t = np.linspace(0, 1, len(pts))
    new_t = np.linspace(0, 1, n)
    out = np.empty((n, 2))
    for d in (0, 1):
        out[:, d] = np.interp(new_t, old_t, pts[:, d])
    return out


def dtw_similarity(a: np.ndarray, b: np.ndarray) -> float:
    """Quick DTW with O(n^2) cost. a, b: (n, 2). Returns similarity in [0,1]."""
    n, m = len(a), len(b)
    cost = np.full((n + 1, m + 1), np.inf)
    cost[0, 0] = 0
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            d = float(np.linalg.norm(a[i-1] - b[j-1]))
            cost[i, j] = d + min(cost[i-1, j], cost[i, j-1], cost[i-1, j-1])
    avg_dist = cost[n, m] / max(n, m)
    # Convert distance → similarity. Max possible distance in normalised coords ≈ √2 ≈ 1.41
    return float(np.exp(-2.0 * avg_dist))


def match_and_score(gen: list[Trajectory], ref: list[Trajectory],
                    motion_floor: float = 0.003,
                    top_k: int = 12) -> dict:
    """Filter to moving trajectories, keep top-K by motion magnitude, Hungarian-match,
    compute scores. Capping at top_k bounds DTW cost at K^2 comparisons."""
    from scipy.optimize import linear_sum_assignment
    gen_m = [t for t in gen if t.motion_magnitude > motion_floor]
    ref_m = [t for t in ref if t.motion_magnitude > motion_floor]
    # Keep top_k most-moving trajectories
    gen_m = sorted(gen_m, key=lambda t: -t.motion_magnitude)[:top_k]
    ref_m = sorted(ref_m, key=lambda t: -t.motion_magnitude)[:top_k]
    if not gen_m or not ref_m:
        return {
            'n_gen_total': len(gen), 'n_ref_total': len(ref),
            'n_gen_moving': len(gen_m), 'n_ref_moving': len(ref_m),
            'coverage': 0.0, 'fidelity': 0.0, 'physics_score': 0.0,
            'matched_pairs': [],
        }

    g_arr = [resample_trajectory(t) for t in gen_m]
    r_arr = [resample_trajectory(t) for t in ref_m]
    sim = np.zeros((len(g_arr), len(r_arr)))
    for i, ga in enumerate(g_arr):
        for j, rb in enumerate(r_arr):
            sim[i, j] = dtw_similarity(ga, rb)

    # Hungarian: maximise similarity → minimise (1 - sim)
    row, col = linear_sum_assignment(1 - sim)
    matched_sims = [sim[i, j] for i, j in zip(row, col)]
    fidelity = float(np.mean(matched_sims)) if matched_sims else 0.0
    # coverage: fraction of GT-moving trajectories matched
    coverage = len(matched_sims) / max(len(ref_m), 1)
    physics_score = float(coverage * fidelity)
    return {
        'n_gen_total': len(gen), 'n_ref_total': len(ref),
        'n_gen_moving': len(gen_m), 'n_ref_moving': len(ref_m),
        'coverage': coverage, 'fidelity': fidelity, 'physics_score': physics_score,
        'matched_pairs': [(int(i), int(j), float(sim[i, j])) for i, j in zip(row, col)],
    }


def read_video_frames(path: str, target_size: int = 224, max_frames: int = 32) -> np.ndarray:
    """Return uniform sample of N frames as (N, H, W, 3) uint8."""
    import imageio.v3 as iio
    try:
        all_frames = list(iio.imiter(str(path), plugin='pyav'))
    except Exception:
        return None
    if not all_frames:
        return None
    n = len(all_frames)
    idxs = np.linspace(0, n - 1, min(max_frames, n)).astype(int)
    out = []
    for i in idxs:
        f = all_frames[i]
        if f.ndim == 2: f = np.stack([f]*3, axis=-1)
        if f.shape[-1] == 4: f = f[..., :3]
        if f.dtype != np.uint8:
            f = (f * 255).clip(0, 255).astype(np.uint8) if f.max() <= 1.0 else f.astype(np.uint8)
        h, w = f.shape[:2]
        if h != w:
            side = max(h, w)
            pad_h = (side - h) // 2; pad_w = (side - w) // 2
            sq = np.zeros((side, side, 3), dtype=np.uint8)
            sq[pad_h:pad_h+h, pad_w:pad_w+w] = f
            f = sq
        out.append(cv2.resize(f, (target_size, target_size)))
    return np.stack(out)  # (N, H, W, 3)


# ────────────────────────────────────────────────────────────────────
#  Method A: Background subtraction + connected-component tracking
# ────────────────────────────────────────────────────────────────────

def method_bgsub(frames: np.ndarray, min_area_frac: float = 0.001) -> list[Trajectory]:
    """Simple BG subtraction using median frame, then per-frame connected
    components, linked across frames by nearest-centroid (greedy)."""
    n, h, w, _ = frames.shape
    gray = np.stack([cv2.cvtColor(f, cv2.COLOR_RGB2GRAY) for f in frames])
    bg = np.median(gray, axis=0).astype(np.uint8)
    fg_seq = []
    min_area = int(min_area_frac * h * w)
    for i in range(n):
        diff = cv2.absdiff(gray[i], bg)
        _, thr = cv2.threshold(diff, 25, 255, cv2.THRESH_BINARY)
        thr = cv2.morphologyEx(thr, cv2.MORPH_OPEN, np.ones((3,3), np.uint8))
        # Connected components
        num, _, stats, centroids = cv2.connectedComponentsWithStats(thr, connectivity=8)
        blobs = []
        for k in range(1, num):
            area = stats[k, cv2.CC_STAT_AREA]
            if area < min_area: continue
            cx, cy = centroids[k]
            blobs.append((cx / w, cy / h))
        fg_seq.append(blobs)

    # Greedy nearest-centroid track linking
    trajectories: list[list[tuple[int,float,float]]] = []
    active: list[int] = []  # indices into trajectories — last seen
    last_centroids: list[tuple[float,float]] = []
    for i, blobs in enumerate(fg_seq):
        # Match each blob to nearest active track
        used = set()
        new_active, new_centroids = [], []
        for cx, cy in blobs:
            best = -1; best_d = 0.06  # max linking distance ~6%
            for k, (lx, ly) in enumerate(zip([c[0] for c in last_centroids], [c[1] for c in last_centroids])):
                if k in used: continue
                d = ((cx-last_centroids[k][0])**2 + (cy-last_centroids[k][1])**2)**0.5
                if d < best_d: best_d = d; best = k
            if best >= 0:
                tid = active[best]
                used.add(best)
                trajectories[tid].append((i, cx, cy))
                new_active.append(tid); new_centroids.append((cx, cy))
            else:
                tid = len(trajectories)
                trajectories.append([(i, cx, cy)])
                new_active.append(tid); new_centroids.append((cx, cy))
        active = new_active; last_centroids = new_centroids

    return [Trajectory(i, pts) for i, pts in enumerate(trajectories) if len(pts) >= 3]


# ────────────────────────────────────────────────────────────────────
#  Method B: RAFT optical flow + blob tracking
# ────────────────────────────────────────────────────────────────────

_RAFT = {'model': None, 'transforms': None, 'device': None}

def _load_raft(device):
    if _RAFT['model'] is not None and _RAFT['device'] == device:
        return _RAFT['model'], _RAFT['transforms']
    import torch
    from torchvision.models.optical_flow import raft_small, Raft_Small_Weights
    weights = Raft_Small_Weights.DEFAULT
    model = raft_small(weights=weights).to(device).eval()
    transforms = weights.transforms()
    _RAFT['model'] = model
    _RAFT['transforms'] = transforms
    _RAFT['device'] = device
    return model, transforms


def method_raft(frames: np.ndarray, device='cuda:0') -> list[Trajectory]:
    """Compute per-frame optical flow magnitude → threshold → connected
    components → track centroids via nearest-neighbour linking."""
    import torch
    model, transforms = _load_raft(device)
    n, h, w, _ = frames.shape
    fg_seq = []
    min_area = int(0.001 * h * w)

    # Process frames in pairs
    with torch.no_grad():
        for i in range(n - 1):
            f1 = torch.from_numpy(frames[i]).permute(2, 0, 1).float().unsqueeze(0)
            f2 = torch.from_numpy(frames[i+1]).permute(2, 0, 1).float().unsqueeze(0)
            f1, f2 = transforms(f1, f2)
            f1, f2 = f1.to(device), f2.to(device)
            flow = model(f1, f2)[-1][0]  # (2, H, W)
            mag = torch.sqrt(flow[0]**2 + flow[1]**2).cpu().numpy()
            # Threshold = 95th percentile of mag, clamped
            thr_val = max(np.percentile(mag, 90), 0.5)
            thr = (mag > thr_val).astype(np.uint8) * 255
            thr = cv2.morphologyEx(thr, cv2.MORPH_CLOSE, np.ones((3,3), np.uint8))
            num, _, stats, centroids = cv2.connectedComponentsWithStats(thr, connectivity=8)
            blobs = []
            for k in range(1, num):
                if stats[k, cv2.CC_STAT_AREA] < min_area: continue
                cx, cy = centroids[k]
                blobs.append((cx / w, cy / h))
            fg_seq.append(blobs)
    fg_seq.append([])  # padding for last frame

    # Greedy linking
    trajectories: list[list[tuple[int,float,float]]] = []
    active: list[int] = []
    last_centroids: list[tuple[float,float]] = []
    for i, blobs in enumerate(fg_seq):
        used = set()
        new_active, new_centroids = [], []
        for cx, cy in blobs:
            best = -1; best_d = 0.08
            for k in range(len(active)):
                if k in used: continue
                lx, ly = last_centroids[k]
                d = ((cx-lx)**2 + (cy-ly)**2)**0.5
                if d < best_d: best_d = d; best = k
            if best >= 0:
                tid = active[best]; used.add(best)
                trajectories[tid].append((i, cx, cy))
                new_active.append(tid); new_centroids.append((cx, cy))
            else:
                tid = len(trajectories)
                trajectories.append([(i, cx, cy)])
                new_active.append(tid); new_centroids.append((cx, cy))
        active = new_active; last_centroids = new_centroids
    return [Trajectory(i, pts) for i, pts in enumerate(trajectories) if len(pts) >= 3]


# ────────────────────────────────────────────────────────────────────
#  Method C: CoTracker3
# ────────────────────────────────────────────────────────────────────

_COTRACKER = {'model': None, 'device': None}

def _load_cotracker(device):
    if _COTRACKER['model'] is not None and _COTRACKER['device'] == device:
        return _COTRACKER['model']
    import torch
    model = torch.hub.load('facebookresearch/co-tracker', 'cotracker3_offline').to(device).eval()
    _COTRACKER['model'] = model
    _COTRACKER['device'] = device
    return model


def method_cotracker(frames: np.ndarray, device='cuda:0',
                     n_grid: int = 12, max_clusters: int = 8) -> list[Trajectory]:
    """Dense point tracking via CoTracker3 → DBSCAN-cluster moving points → centroid trajectories.

    Tuned for synthetic videos: 12x12 grid (144 points), aggressive clustering
    (eps=0.15 in 4-D feature space), keep only top-K clusters by motion magnitude.
    This caps the trajectory count so DTW pairwise scoring stays fast."""
    import torch
    from sklearn.cluster import DBSCAN
    model = _load_cotracker(device)
    n, h, w, _ = frames.shape

    video = torch.from_numpy(frames).permute(0, 3, 1, 2).float().unsqueeze(0).to(device)
    with torch.no_grad():
        pred_tracks, _ = model(video, grid_size=n_grid)
    tracks = pred_tracks[0].cpu().numpy()  # (T, N, 2)

    # Filter by total path length (sum of step magnitudes)
    diffs = np.diff(tracks, axis=0)
    step_norms = np.linalg.norm(diffs, axis=-1)
    path_len = step_norms.sum(axis=0)
    moving_mask = path_len > 1.5
    if moving_mask.sum() < 2:
        return []

    moving_idxs = np.where(moving_mask)[0]
    start = tracks[0, moving_idxs] / max(h, w)
    end_disp = (tracks[-1, moving_idxs] - tracks[0, moving_idxs]) / max(h, w)
    features = np.concatenate([start, end_disp], axis=1)
    db = DBSCAN(eps=0.15, min_samples=2).fit(features)  # bigger eps → fewer clusters
    labels = db.labels_

    # Build cluster centroids and rank by total motion
    clusters = []
    for cl in sorted(set(labels)):
        if cl == -1: continue
        idxs = moving_idxs[labels == cl]
        cluster_tracks = tracks[:, idxs]
        centroid = cluster_tracks.mean(axis=1)
        # cluster motion = total path of the centroid
        c_path = np.linalg.norm(np.diff(centroid, axis=0), axis=-1).sum()
        clusters.append((c_path, cl, idxs, centroid))

    # Keep top-K most-moving clusters
    clusters.sort(reverse=True)
    clusters = clusters[:max_clusters]

    trajectories = []
    for _, cl, _, centroid in clusters:
        pts = [(t, float(centroid[t, 0])/w, float(centroid[t, 1])/h) for t in range(n)]
        trajectories.append(Trajectory(int(cl), pts))
    return trajectories


# ────────────────────────────────────────────────────────────────────
#  Method D: SAM2 video
# ────────────────────────────────────────────────────────────────────

_SAM2 = {'predictor': None, 'device': None}

def _load_sam2(device):
    if _SAM2['predictor'] is not None and _SAM2['device'] == device:
        return _SAM2['predictor']
    # Use HF transformers SAM2 pipeline
    from transformers import Sam2Model, Sam2Processor
    model_id = 'facebook/sam2-hiera-tiny'
    processor = Sam2Processor.from_pretrained(model_id)
    model = Sam2Model.from_pretrained(model_id).to(device).eval()
    _SAM2['predictor'] = (model, processor)
    _SAM2['device'] = device
    return _SAM2['predictor']


def method_sam2(frames: np.ndarray, device='cuda:0') -> list[Trajectory]:
    """Use SAM2 with auto-mask generation on the first frame to find objects,
    then propagate masks across frames. Returns mask-centroid trajectories.

    This is a heuristic: first frame is segmented automatically (grid prompts),
    then top-K largest masks are tracked. We don't have stable video propagation
    from the HF integration without specifying point/box prompts, so this is
    a simplified version: we segment EACH frame independently and link via centroid
    distance, similar to the BG subtraction approach but using semantic masks.
    """
    import torch
    from PIL import Image
    model, processor = _load_sam2(device)
    n, h, w, _ = frames.shape

    # Build a grid of points to prompt segmentation in each frame
    grid_n = 8
    xs = np.linspace(w*0.15, w*0.85, grid_n)
    ys = np.linspace(h*0.15, h*0.85, grid_n)
    grid_pts = np.array([[(x, y) for x in xs for y in ys]])  # (1, G, 2)

    fg_seq = []
    with torch.no_grad():
        for i in range(n):
            f_pil = Image.fromarray(frames[i])
            inputs = processor(images=f_pil,
                               input_points=grid_pts.tolist(),
                               return_tensors='pt').to(device)
            outputs = model(**inputs, multimask_output=False)
            # outputs.pred_masks: (1, 1, G, H, W) where G is number of prompts
            masks = outputs.pred_masks[0, 0].cpu().numpy() > 0  # (G, H, W) — boolean
            # Each grid point gets one mask. Take centroids.
            centroids = []
            for k in range(masks.shape[0]):
                m = masks[k]
                area = m.sum()
                if area < 0.001 * h * w: continue
                ys_, xs_ = np.where(m)
                if len(xs_) == 0: continue
                cx = float(xs_.mean()) / w
                cy = float(ys_.mean()) / h
                centroids.append((cx, cy))
            # Dedupe near-duplicate centroids
            unique = []
            for c in centroids:
                if all(((c[0]-u[0])**2 + (c[1]-u[1])**2)**0.5 > 0.02 for u in unique):
                    unique.append(c)
            fg_seq.append(unique)

    # Same greedy linking as bgsub
    trajectories: list[list[tuple[int,float,float]]] = []
    active: list[int] = []
    last_centroids: list[tuple[float,float]] = []
    for i, blobs in enumerate(fg_seq):
        used = set()
        new_active, new_centroids = [], []
        for cx, cy in blobs:
            best = -1; best_d = 0.06
            for k in range(len(active)):
                if k in used: continue
                lx, ly = last_centroids[k]
                d = ((cx-lx)**2 + (cy-ly)**2)**0.5
                if d < best_d: best_d = d; best = k
            if best >= 0:
                tid = active[best]; used.add(best)
                trajectories[tid].append((i, cx, cy))
                new_active.append(tid); new_centroids.append((cx, cy))
            else:
                tid = len(trajectories)
                trajectories.append([(i, cx, cy)])
                new_active.append(tid); new_centroids.append((cx, cy))
        active = new_active; last_centroids = new_centroids
    return [Trajectory(i, pts) for i, pts in enumerate(trajectories) if len(pts) >= 3]


# ────────────────────────────────────────────────────────────────────
#  Method E: SAM3 video — concept-prompted segmentation
# ────────────────────────────────────────────────────────────────────

_SAM3 = {'model': None, 'processor': None, 'device': None}

def _load_sam3(device):
    if _SAM3['model'] is not None and _SAM3['device'] == device:
        return _SAM3['model'], _SAM3['processor']
    import os
    from transformers import Sam3VideoModel, Sam3VideoProcessor
    token = os.environ.get('HF_TOKEN')
    if not token and os.path.exists(os.path.expanduser('~/.cache/huggingface/token')):
        token = open(os.path.expanduser('~/.cache/huggingface/token')).read().strip()
    proc = Sam3VideoProcessor.from_pretrained('facebook/sam3', token=token)
    model = Sam3VideoModel.from_pretrained('facebook/sam3', token=token).to(device).eval()
    _SAM3['model'] = model
    _SAM3['processor'] = proc
    _SAM3['device'] = device
    return model, proc


def method_sam3(frames: np.ndarray, device='cuda:0',
                prompt: str = 'moving object') -> list[Trajectory]:
    """SAM3 video with text-prompt segmentation. Returns mask-centroid trajectories."""
    import torch
    model, proc = _load_sam3(device)
    n, h, w, _ = frames.shape

    # Use the high-level processor methods. init_video_session sets up the
    # session with proper pixel pre-processing; add_text_prompt tokenises.
    pil_frames = [frames[i] for i in range(n)]
    session = proc.init_video_session(
        video=pil_frames,
        inference_device=torch.device(device),
        inference_state_device=torch.device(device),
        video_storage_device=torch.device('cpu'),
        dtype=torch.float32,
    )
    proc.add_text_prompt(session, prompt)

    trajectories: dict[int, list[tuple[int, float, float]]] = {}
    with torch.no_grad():
        for f_idx, output in enumerate(model.propagate_in_video_iterator(session)):
            obj_id_to_mask = getattr(output, 'obj_id_to_mask', None) or {}
            for obj_id, low_mask in obj_id_to_mask.items():
                if low_mask is None: continue
                m = low_mask.squeeze().cpu().numpy() > 0
                if m.sum() < 4: continue
                ys, xs = np.where(m)
                cx = float(xs.mean()) / m.shape[1]
                cy = float(ys.mean()) / m.shape[0]
                trajectories.setdefault(int(obj_id), []).append((int(f_idx), cx, cy))

    return [Trajectory(oid, sorted(pts)) for oid, pts in trajectories.items() if len(pts) >= 3]


# ────────────────────────────────────────────────────────────────────
#  Smoke runner
# ────────────────────────────────────────────────────────────────────

def run_method(method_name, pair, device):
    """Run one method on one pair, return scores + timing."""
    methods = {
        'bgsub': lambda f: method_bgsub(f),
        'raft':  lambda f: method_raft(f, device=device),
        'cotracker': lambda f: method_cotracker(f, device=device),
        'sam2': lambda f: method_sam2(f, device=device),
        'sam3': lambda f: method_sam3(f, device=device),
    }
    fn = methods[method_name]
    pid = pair['pair_id']
    eng = 'scipy' if 'scipy' in pid else 'kubric'
    parts = pid.split('_')
    exp = '_'.join(parts[3:-1])
    sid = parts[-1]
    rendered = f'eval_outputs/gpt_5_mini/runs/{eng}/{exp}/{sid}/video.mp4'
    reference = f'benchmarking_data/{eng}/{exp}/{sid}/video.mp4'

    t0 = time.time()
    try:
        f_gen = read_video_frames(rendered)
        f_ref = read_video_frames(reference)
        if f_gen is None or f_ref is None:
            return {'pair_id': pid, 'error': 'frame read failed', 'wall_s': time.time()-t0}
        traj_gen = fn(f_gen)
        traj_ref = fn(f_ref)
        scores = match_and_score(traj_gen, traj_ref)
        wall = time.time() - t0
        return {'pair_id': pid, 'human_physics': int(pair['physics']),
                'human_appearance': int(pair['appearance']),
                'human_plausibility': int(pair['plausibility']),
                'wall_s': round(wall, 2),
                **scores}
    except Exception as e:
        return {'pair_id': pid, 'error': f'{type(e).__name__}: {e}', 'wall_s': time.time()-t0}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--method', required=True,
                    choices=['bgsub', 'raft', 'cotracker', 'sam2', 'sam3', 'all'])
    ap.add_argument('--device', default='cuda:0')
    ap.add_argument('--pairs', default='/tmp/smoke_pairs.json')
    ap.add_argument('--out', default=None)
    args = ap.parse_args()

    with open(args.pairs) as f:
        pairs = json.load(f)
    methods = ['bgsub', 'raft', 'cotracker', 'sam2'] if args.method == 'all' else [args.method]

    for method in methods:
        print(f'\n{"="*70}\n  METHOD: {method}\n{"="*70}', flush=True)
        results = []
        out_path = Path(args.out) if args.out else Path(f'/tmp/smoke_{method}.jsonl')
        # Truncate output file at start
        out_path.write_text('')
        for p in pairs:
            r = run_method(method, p, args.device)
            results.append(r)
            # Append to disk immediately
            with out_path.open('a') as f:
                f.write(json.dumps(r) + '\n')
            if 'error' in r:
                print(f'  {r["pair_id"][:55]:<55s}  ERROR: {r["error"][:40]}', flush=True)
            else:
                print(f'  {r["pair_id"][:55]:<55s}  '
                      f'phys={r["human_physics"]}  '
                      f'gen={r["n_gen_moving"]:>2d}/{r["n_gen_total"]:>2d}  '
                      f'ref={r["n_ref_moving"]:>2d}/{r["n_ref_total"]:>2d}  '
                      f'cov={r["coverage"]:.2f}  fid={r["fidelity"]:.2f}  '
                      f'phy_score={r["physics_score"]:.3f}  '
                      f'{r["wall_s"]:.1f}s', flush=True)
        print(f'  wrote {out_path}', flush=True)

        # Quick correlation if we have numeric scores
        valid = [r for r in results if 'physics_score' in r]
        if len(valid) >= 4:
            phys = [r['human_physics'] for r in valid]
            scores = [r['physics_score'] for r in valid]
            from scipy.stats import spearmanr
            rho, p = spearmanr(scores, phys)
            high_phys = [s for s, h in zip(scores, phys) if h >= 4]
            low_phys = [s for s, h in zip(scores, phys) if h <= 2]
            print(f'\n  → Spearman ρ(phy_score, human_physics) = {rho:.3f} (p={p:.2f}, N={len(valid)})')
            if high_phys: print(f'     mean phy_score @ human_phys≥4 (N={len(high_phys)}) = {statistics.fmean(high_phys):.3f}')
            if low_phys:  print(f'     mean phy_score @ human_phys≤2 (N={len(low_phys)})  = {statistics.fmean(low_phys):.3f}')


if __name__ == '__main__':
    main()
