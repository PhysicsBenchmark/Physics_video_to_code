"""Audit every scipygpt experiment for integration readiness.

Checks (from strictest to weakest):
  A. Module contract  — 4 required functions present
  B. Sample dir shape — exactly {video.mp4, params.json, cot.json, simulation_code.py}
  C. Video properties — 30 fps, 12 s (the two enforced conventions)
  D. Params dict     — matches what's inside params.json; no nulls; all numeric
  E. CoT schema      — same top-level keys as scipy CoTs
  F. Manifest entry  — has required keys, sample_dir is relative
  G. Slug parity     — module SLUG matches file stem
  H. Standalone rerun — simulation_code.py executes cleanly and produces a video
"""
import json
import subprocess
import sys
import importlib
from pathlib import Path

import imageio.v3 as iio

ROOT = Path("/scr/adityag6/Physics-Simulation-Code-Generation")
sys.path.insert(0, str(ROOT))

MODULES_DIR = ROOT / "simulations" / "scipygpt"
DATA_DIR = ROOT / "dataset_scipygpt"

REQUIRED_FUNCS = ("sample_params", "build_cot", "make_standalone_script", "generate_sample")
REQUIRED_FILES = {"video.mp4", "params.json", "cot.json", "simulation_code.py"}
REQUIRED_COT_KEYS = {"simulation", "physical_observation", "physical_law",
                     "ode_system", "derivation_steps", "numerical_method",
                     "code_validation", "expected_behavior", "parameters"}
REQUIRED_MANIFEST_KEYS = {"sample_dir", "simulation", "params", "files"}
CONVENTION = {"fps": 30, "duration": 12.0}

RED = "\033[91m"; YELLOW = "\033[93m"; GREEN = "\033[92m"; RESET = "\033[0m"


def slugs():
    return sorted(p.stem for p in MODULES_DIR.glob("*.py") if p.name != "__init__.py")


def audit_module_contract(slug):
    issues = []
    try:
        mod = importlib.import_module(f"simulations.scipygpt.{slug}")
    except Exception as e:
        return [f"IMPORT FAIL: {type(e).__name__}: {e}"], None
    for fn in REQUIRED_FUNCS:
        if not hasattr(mod, fn):
            issues.append(f"missing function: {fn}")
    if hasattr(mod, "SLUG") and mod.SLUG != slug:
        issues.append(f"SLUG constant is '{mod.SLUG}' but module file is '{slug}.py'")
    elif not hasattr(mod, "SLUG"):
        issues.append("no SLUG constant defined")
    return issues, mod


def audit_sample_dir(sample_dir):
    issues = []
    files = set(f.name for f in sample_dir.iterdir() if f.is_file())
    missing = REQUIRED_FILES - files
    extra = files - REQUIRED_FILES
    if missing: issues.append(f"missing files: {sorted(missing)}")
    if extra: issues.append(f"extra files: {sorted(extra)}")
    # File sizes
    for f in REQUIRED_FILES:
        p = sample_dir / f
        if p.exists() and p.stat().st_size == 0:
            issues.append(f"empty file: {f}")
    return issues


def audit_video(sample_dir):
    issues = []
    vp = sample_dir / "video.mp4"
    if not vp.exists(): return ["video.mp4 missing"]
    try:
        m = iio.immeta(vp)
        fps = m.get("fps"); dur = m.get("duration"); size = m.get("size")
        if fps and abs(fps - CONVENTION["fps"]) > 0.5:
            issues.append(f"fps={fps} (expected {CONVENTION['fps']})")
        if dur and abs(dur - CONVENTION["duration"]) > 0.5:
            issues.append(f"duration={dur:.2f}s (expected {CONVENTION['duration']})")
        if not size or size[0] < 200 or size[1] < 200:
            issues.append(f"suspicious video size: {size}")
    except Exception as e:
        issues.append(f"video metadata read fail: {type(e).__name__}")
    return issues


def audit_params(sample_dir):
    issues = []
    pp = sample_dir / "params.json"
    if not pp.exists(): return ["params.json missing"]
    try:
        d = json.load(open(pp))
    except Exception as e:
        return [f"params.json parse fail: {e}"]
    if not isinstance(d, dict):
        return ["params.json is not a dict"]
    numeric = [(k, v) for k, v in d.items() if isinstance(v, (int, float))]
    nonnumeric = [(k, type(v).__name__) for k, v in d.items() if not isinstance(v, (int, float, str))]
    if len(numeric) < 3:
        issues.append(f"only {len(numeric)} numeric params (parameter-estimation eval needs more)")
    if nonnumeric:
        issues.append(f"non-numeric non-string params: {nonnumeric}")
    if None in d.values():
        issues.append("null values in params.json")
    return issues


def audit_cot(sample_dir):
    issues = []
    cp = sample_dir / "cot.json"
    if not cp.exists(): return ["cot.json missing"]
    try:
        d = json.load(open(cp))
    except Exception as e:
        return [f"cot.json parse fail: {e}"]
    if not isinstance(d, dict): return ["cot.json is not a dict"]
    missing = REQUIRED_COT_KEYS - set(d.keys())
    if missing: issues.append(f"missing CoT keys: {sorted(missing)}")
    pl = d.get("physical_law", {})
    if not isinstance(pl, dict) or not pl.get("formula"):
        issues.append("physical_law.formula empty (LLM-judge scorer needs this)")
    if not d.get("parameters") or not isinstance(d["parameters"], dict):
        issues.append("cot.parameters missing/empty (parameter-estimation eval needs this)")
    return issues


def audit_manifest(slug):
    issues = []
    mp = DATA_DIR / slug / "manifest.json"
    if not mp.exists(): return ["experiment manifest.json missing"]
    try:
        entries = json.load(open(mp))
    except Exception as e:
        return [f"manifest.json parse fail: {e}"]
    if not isinstance(entries, list) or not entries:
        return ["manifest.json empty or not a list"]
    entry = entries[0]
    missing = REQUIRED_MANIFEST_KEYS - set(entry.keys())
    if missing: issues.append(f"manifest missing keys: {sorted(missing)}")
    sd = entry.get("sample_dir", "")
    if sd.startswith("/") or ":" in sd:
        issues.append(f"sample_dir is absolute path: {sd[:60]}...")
    if "engine" not in entry:
        issues.append("no 'engine' key in manifest entry (downstream eval keys off this)")
    return issues


def audit_rerun(sample_dir):
    """Confirm simulation_code.py re-executes and produces a video."""
    tmp = ROOT / f"_audit_tmp_{sample_dir.parent.name}_{sample_dir.name}"
    tmp.mkdir(exist_ok=True)
    (tmp / "simulation_code.py").write_text(
        (sample_dir / "simulation_code.py").read_text()
    )
    try:
        r = subprocess.run([sys.executable, "simulation_code.py"],
                           cwd=tmp, capture_output=True, timeout=180)
        if r.returncode != 0:
            err = r.stderr.decode()[-400:]
            return [f"standalone rerun exited {r.returncode}: ...{err}"]
        if not (tmp / "video.mp4").exists():
            return ["standalone rerun succeeded but no video.mp4 produced"]
        return []
    except subprocess.TimeoutExpired:
        return ["standalone rerun timed out (>180s)"]
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)


def main():
    all_slugs = slugs()
    print(f"{'='*90}\nAuditing {len(all_slugs)} scipygpt experiments\n{'='*90}\n")
    summary = {}
    for slug in all_slugs:
        print(f"── {slug} ─────────────────────────────────────────────")
        issues = {}

        c_issues, mod = audit_module_contract(slug)
        if c_issues: issues["A. contract"] = c_issues

        exp_dir = DATA_DIR / slug
        if not exp_dir.exists():
            issues["B–H. dataset"] = ["dataset_scipygpt/{slug}/ does not exist"]
        else:
            sids = sorted([d for d in exp_dir.iterdir() if d.is_dir()])
            if len(sids) != 5:
                issues["B. sample count"] = [f"{len(sids)} samples (expected 5)"]
            if sids:
                sd = sids[0]
                s_issues = audit_sample_dir(sd)
                if s_issues: issues["B. sample dir"] = s_issues
                v_issues = audit_video(sd)
                if v_issues: issues["C. video"] = v_issues
                p_issues = audit_params(sd)
                if p_issues: issues["D. params"] = p_issues
                cot_issues = audit_cot(sd)
                if cot_issues: issues["E. cot"] = cot_issues
            m_issues = audit_manifest(slug)
            if m_issues: issues["F. manifest"] = m_issues
            # rerun test only if all previous checks pass to save time
            if not issues and sids:
                rr_issues = audit_rerun(sids[0])
                if rr_issues: issues["H. rerun"] = rr_issues

        if not issues:
            print(f"  {GREEN}PASS{RESET}")
        else:
            for cat, items in issues.items():
                for it in items:
                    color = RED if cat.startswith(("A", "B")) else YELLOW
                    print(f"  {color}[{cat}]{RESET} {it}")
        summary[slug] = issues
        print()

    # Aggregate
    print(f"\n{'='*90}\nSUMMARY\n{'='*90}")
    total = len(summary)
    passing = sum(1 for iss in summary.values() if not iss)
    print(f"  {passing}/{total} pass all checks")
    print()
    from collections import Counter
    cat_counter = Counter()
    for iss in summary.values():
        for cat in iss:
            cat_counter[cat] += 1
    print("  Issues by category (# experiments affected):")
    for cat, n in sorted(cat_counter.items()):
        print(f"    {cat}: {n}")


if __name__ == "__main__":
    main()
