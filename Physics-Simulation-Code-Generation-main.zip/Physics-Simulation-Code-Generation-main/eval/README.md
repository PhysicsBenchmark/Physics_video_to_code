# eval/

Evaluation pipeline for benchmark runs of MLLMs that try to recreate physics
simulations from videos alone. Reads `inference_outputs/<model>/results.jsonl`
(one row per `(model, video)` attempt) and writes scoring results to
`eval_outputs/<model>/eval_results.jsonl` (one row per `(sample, scorer,
judge)`).

## Quick start

```bash
# Install dependencies
pip install -r eval/requirements_eval.txt

# Set API keys in a .env at repo root (auto-loaded via python-dotenv)
# OPENAI_API_KEY=sk-...
# GEMINI_API_KEY=AIza...
# XAI_API_KEY=xai-...

# 1) Recover any parse failures in raw inference outputs (writes results_recovered.jsonl)
python eval/recover_inference_outputs.py --inference_root inference_outputs/

# 2) Run all four scorers (three LLM + codebleu + runnability) on every model
python eval/run_dataset.py --inference_root inference_outputs/ --out_root eval_outputs/

# 3) Produce per-model REPORT.md summaries
python eval/make_model_report.py --model gpt_5_mini
python eval/aggregate.py --in eval_outputs/gpt_5_mini/eval_results.jsonl
```

Rough cost: **~$8.50 per model for the full 2,430-sample benchmark** (judges are
GPT-5-Nano / Gemini-2.5-Flash / Grok-4.1-Fast, all "small" tiers). CodeBLEU and
runnability are local CPU.

---

## Layout

### Core pipeline

```
eval/
├── README.md                        this file
├── _common.py                       shared schema / paths / fan-out
│                                    - BENCH_ROOT / INFER_ROOT / EVAL_OUT_ROOT
│                                    - LIKERT_SCHEMA (0-4 integer, per sub-field)
│                                    - env override: PHYSIM_BENCH_ROOT
├── run_dataset.py                   PRIMARY entry point — walks inference_outputs/
│                                    supports --bench_root, --sample_manifest,
│                                    --inference_root, --out_root, --models,
│                                    --scorers, --judges, --concurrency
├── run_all.py                       legacy single-file variant (use run_dataset.py)
├── requirements_eval.txt            openai, google-genai, xai-sdk-python, codebleu 0.7,
│                                    tree-sitter (pinned), python-dotenv, imageio
├── judges/
│   ├── base.py                      JudgeClient interface
│   ├── openai_judge.py              GPT-5-Nano
│   ├── gemini_judge.py              Gemini-2.5-Flash
│   └── grok_judge.py                Grok-4.1-Fast (xAI OpenAI-compatible)
├── prompts/
│   ├── law_equivalence.md           judge sees GT + candidate physical_law
│   └── law_validity.md              judge sees only candidate physical_law
├── score_law_equivalence.py         scorer 1 (3 judges × 4 sub-scores per sample)
├── score_law_validity.py            scorer 2 (same shape, no GT comparison)
├── score_codebleu.py                scorer 3 (deterministic, codebleu==0.7.0)
├── score_runnability.py             scorer 4 (subprocess-executes candidate code)
├── recover_cot.py                   tolerant CoT JSON recovery (Python arithmetic,
│                                    LaTeX escapes, JSON5, arithmetic evaluation)
├── recover_inference_outputs.py     walks inference_outputs/, writes _recovered.jsonl
├── aggregate.py                     per-model summary tables from eval_results.jsonl
├── make_model_report.py             renders eval_outputs/<model>/REPORT.md
```

### GPU-only scorers (separately invoked, not part of run_dataset.py)

```
├── score_video_similarity.py        DINOv2 + X-CLIP frame-embedding cosine
│                                    reads generated + reference videos, writes
│                                    eval_outputs/<model>/video_similarity.jsonl
│                                    env override: PHYSIM_BENCH_ROOT, PHYSIM_EVAL_ROOT
├── score_trajectory.py              CoTracker3 point-tracking + DBSCAN + DTW
│                                    scipy only; writes trajectory_similarity_scipy.jsonl
│                                    env override: PHYSIM_BENCH_ROOT, PHYSIM_EVAL_ROOT
├── smoke_trajectory.py              shared frame-reading + tracker helpers
```

### Parameter-estimation scorer (external — copy from Sourajak's tree)

The paper's Table 9 "Param. Estimation Acc. ±20%" metric comes from a script
that is NOT currently in this eval/ folder. It lives at:

```
/scr/sourajak/physics_video/physics_sim_dataset/inference/eval_parameters.py
```

It implements greedy bipartite matching over alias sets (Greek/Latin synonyms,
deabbreviation, unit normalization) and produces `parameter_evaluation.jsonl` +
`parameter_evaluation_summary.csv` per inference-output tree. **Copy this file
into `eval/` before publishing.** It's ~500 lines and self-contained.

### Aggregators + rebuttal analyses

```
├── aggregate_per_engine.py          Scipy vs Kubric code-gen split (paper Table 4 variant)
├── param_error_report.py            exact-name-match Param Est fallback (lower bound vs
│                                    the alias-matched official version)
├── failure_modes.py                 per-model error class distribution (traceback tail)
├── failure_case_grid.py             visual grid of representative failure cases

Rebuttal-specific:
├── compare_gpt_vs_claude_arm.py     GPT-arm (rebuttal) vs Claude-arm (matched subset)
├── dump_rebuttal_analysis.py        full rebuttal report on 1-5 paper scale
├── kappa_human_vs_metrics.py        human-vs-auto-metric kappa plots (main-text +
│                                    appendix figures)
├── sensitivity_analysis.py          perturbation-based parameter sensitivity study
│                                    (108 params × 5 samples × ±10% = 1,080 renders,
│                                    ~15 min CPU-only)
├── audit_scipygpt.py                integration validator for GPT-authored GT
├── promote_scipygpt_to_benchmarking.py  copies dataset_scipygpt/ → benchmarking-shaped
```

### Utility

```
├── plot_human_calibration.py        scatter plots: human labels vs auto metrics
├── show_law_diff.py                 inspect judge disagreements interactively
├── compute_kappa.py                 pairwise Cohen's kappa across judges (paper Fig 4)
├── judge_stats.py                   judge-level cost + latency summary
├── recover_cot.py                   see above (also directly invokable)
└── judges/                          per-provider judge wrappers
```

---

## API keys

Set in a `.env` file at the repo root (auto-loaded by `python-dotenv`):

```
OPENAI_API_KEY=sk-...
GEMINI_API_KEY=AIza...
XAI_API_KEY=xai-...
```

Or `export` them in your shell — the provider SDKs read environment variables
directly.

Never commit `.env` — a `.env.example` template ships with the release.

---

## Environment / dependencies

```bash
pip install -r eval/requirements_eval.txt
```

Two conda environments were used in practice:

- **`phys_eval`** — for dataset generation (matplotlib.animation, PyBullet,
  pyrender, imageio). Also fine for `score_runnability` and `score_codebleu`
  once `codebleu` is `pip install`ed.
- **`py310`** — the primary eval environment, has `codebleu==0.7.0`,
  `tree-sitter==0.22.3`, `tree-sitter-python==0.21.0` (later versions break
  CodeBLEU), all judge SDKs, `imageio`, `dotenv`. Recommended for the eval
  pipeline.

The path is `/home/adityag6/miniconda3/envs/py310/bin/python`; substitute your
own Python.

---

## Scoring rubric (0–4 Likert, per sub-field)

Both `law_equivalence` and `law_validity` produce four integer scores plus a
one-sentence justification:

| field | meaning |
|---|---|
| `name`      | does the candidate's law name match (equivalence) / look like a real law (validity) |
| `statement` | does the prose statement convey the same physical content / make sense |
| `formula`   | algebraically equivalent / dimensionally consistent and standard |
| `overall`   | judge's holistic assessment, **not** a derived mean |

**Scale note**: internal 0–4 scale (5 discrete levels: 0/1/2/3/4). Paper Table 2
reports on a 1–5 scale by adding 1 to every value for display. All scripts
here emit the raw 0–4 value; add 1 for paper-facing tables.

`codebleu` produces no Likert scores; instead the five components from the
`codebleu==0.7.0` PyPI package: `codebleu`, `ngram_match_score`,
`weighted_ngram_match_score`, `syntax_match_score`, `dataflow_match_score`,
computed with equal weights `(0.25, 0.25, 0.25, 0.25)`, `lang="python"`,
`tokenizer=None`.

---

## What the judges see

* **Equivalence**: the GT and candidate `physical_law` blocks (`name`,
  `statement`, `formula`). **Nothing else** — not `ode_system`, not the code,
  not the parameters. There are many ways to solve the same physics problem;
  including ODEs would conflate "got the law" with "wrote it the same way."
* **Validity**: only the candidate's `physical_law` block. The judge has no
  reference to anchor on, so the score is purely "is this a real, internally
  consistent piece of physics."

---

## Generated-video storage

When `score_runnability` is invoked via `run_dataset.py` **without**
`--no-keep-videos`, every successful `video.mp4` produced by a candidate is
copied to:

```
eval_outputs/<model>/runs/<engine>/<experiment>/<sample_id>/video.mp4
```

The `scores.video_path` field on each runnability row records this path so
downstream tools (video-similarity, trajectory scoring) can locate it without
re-running the candidate.

Videos for failed runs (or runs that didn't reach the rendering stage) are not
saved. To disable saving entirely, pass `--no-keep-videos` to
`run_dataset.py`. To choose a different root, use `score_runnability.py`
directly with `--videos_root <dir>`.

Storage estimate: a 12-second 720×360 mp4 is typically 50–500 KB. Across
2,430 candidates with ~30–95% producing a video (depending on model), the
persisted `runs/` trees come to ~1–2 GB total.

---

## Skipped rows

* `parse_ok_cot=False` → law-equivalence and law-validity rows are written with
  `skipped=True, skip_reason="parse_ok_cot=False"`. No judge call.
* `parse_ok_code=False` → codebleu and runnability rows are written with
  `skipped=True, skip_reason="parse_ok_code=False"`. No CodeBLEU computation
  and no subprocess execution.

These rows still appear in `eval_results.jsonl` so aggregate counts are honest.
Run `recover_inference_outputs.py` first to reduce parse fails; every model
typically gets a 3–20 pp bump on `parse_ok_cot` via tolerant recovery.

---

## `eval_results.jsonl` schema

Every row has the same shape; some fields are `null` when not applicable.

```jsonc
{
  "engine":      "scipy",
  "experiment":  "accelerating_beaker_water",
  "sample_id":   "012",
  "model":       "qwen3vl_30b_a3b",         // model under test
  "scorer":      "law_equivalence",          // or "law_validity" / "codebleu" / "runnability"
  "judge_model": "gpt-5-nano",                // null for codebleu + runnability

  "scores": {
    "name": 4, "statement": 3, "formula": 2, "overall": 3
  },                                          // for codebleu: 5-key dict of match scores
  "justification": "candidate uses Newton's 2nd Law in disguise; formula is rearranged form.",
  "raw_response":  "...",                     // full judge JSON, for audit
  "latency_s":   1.21,
  "tokens_in":   820,
  "tokens_out":  118,
  "judge_error": null,                        // string if API call failed
  "skipped":     false,
  "skip_reason": null
}
```

For the **runnability** scorer, `scores` carries:

```jsonc
{
  "syntax_ok":          true,    // ast.parse(parsed_code) succeeds
  "runs_without_error": true,    // subprocess exits 0 within timeout
  "produces_video_mp4": true,    // video.mp4 of nonzero size in run dir
  "exit_code":          0,
  "wall_time_s":        4.13,
  "timed_out":          false,
  "video_bytes":        11977,
  "video_path":         "/.../eval_outputs/<model>/runs/<engine>/<exp>/<sid>/video.mp4"
}
```

---

## Usage recipes

### Full pipeline on a fresh model

```bash
# 1. Build recovery file (recommended, cheap, rescues parse failures)
python eval/recover_inference_outputs.py --inference_root inference_outputs/ \
                                          --models qwen3vl_30b_a3b

# 2. Run everything (all 4 scorers, 3 judges, resume-safe)
python eval/run_dataset.py \
  --inference_root inference_outputs/ \
  --out_root       eval_outputs/ \
  --models         qwen3vl_30b_a3b \
  --concurrency    8

# 3. Aggregate + emit per-model REPORT.md
python eval/make_model_report.py --model qwen3vl_30b_a3b
```

### Just one scorer or subset

```bash
# Only CodeBLEU + runnability (no LLM judges, no API cost, CPU-only, ~5x faster)
python eval/run_dataset.py --scorers runnability codebleu \
                            --models qwen3vl_30b_a3b

# Only one judge
python eval/run_dataset.py --judges openai --models qwen3vl_30b_a3b

# Subset by engine or experiment
python eval/run_dataset.py --engines scipy --models qwen3vl_30b_a3b
python eval/run_dataset.py --experiments simple_pendulum --models qwen3vl_30b_a3b
```

### Rebuttal-style eval (custom bench root and sample manifest)

If you want to score inference outputs against a *different* GT root — e.g.
against a cleaned/normalized version of the benchmark — the pipeline supports it:

```bash
python eval/run_dataset.py \
  --bench_root      <path>/normalized_benchmarking_data \
  --sample_manifest <path>/normalized_benchmarking_data/manifest.csv \
  --inference_root  inference_outputs_rebuttal/ \
  --out_root        eval_outputs_rebuttal/ \
  --concurrency     8
```

`--sample_manifest` filters the eval to only the (engine, experiment, sample_id)
triples in that CSV. The bench root override lets you swap in a differently-
authored GT set (Claude-authored vs GPT-authored, as in the rebuttal).

### Video similarity + trajectory (GPU required)

```bash
# Requires generated videos on disk from a run_dataset.py invocation with --keep-videos
export HF_HOME=/scr/adityag6/hf_cache
python eval/score_video_similarity.py --models qwen3vl_30b_a3b --device cuda:0
python eval/score_trajectory.py       --model  qwen3vl_30b_a3b --engine scipy --device cuda:0

# For rebuttal-style trees:
PHYSIM_BENCH_ROOT=<bench> PHYSIM_EVAL_ROOT=<eval_out> \
  python eval/score_video_similarity.py --models qwen3vl_30b_a3b --device cuda:0
```

### Parameter estimation (external script)

Copy `eval_parameters.py` from `/scr/sourajak/…/inference/` into `eval/`, then:

```bash
python eval/eval_parameters.py                         # Claude arm, full benchmark
python eval/eval_parameters.py --bench benchmarking_data_gpt \
                                --infer inference_outputs_gpt   # GPT arm
```

Outputs `parameter_evaluation.jsonl` (per-sample) and `parameter_evaluation_summary.csv`
(paper's Table 9) into the `--infer` directory.

### Perturbation-based sensitivity study

```bash
python eval/sensitivity_analysis.py

# ~15 min wall clock, CPU-only, no APIs
# Renders 1,080 perturbed videos (108 params × 5 samples × ±10% of config range)
# for the 15 rebuttal-parent scipy experiments, computes frame-MSE, normalizes
# per-experiment, tiers via k-means. Outputs in eval_outputs/_sensitivity/.
```

---

## Debugging flags

```bash
python eval/run_dataset.py --limit 3                 # first 3 rows per model only
python eval/run_dataset.py --no-resume               # don't skip already-scored samples
python eval/run_dataset.py --no-keep-videos          # don't persist candidate MP4s
python eval/run_dataset.py --runnability_timeout 30  # tighter per-render timeout
```

---

## Dependencies

```
pip install openai google-genai xai-sdk-python codebleu python-dotenv imageio scikit-learn
pip install "tree-sitter==0.22.3" "tree-sitter-python==0.21.0"   # codebleu pin (mandatory)
```

CodeBLEU 0.7 is incompatible with newer `tree-sitter`/`tree-sitter-python`; the
pin above is what works. Additionally for GPU scorers:

```
pip install torch transformers  # DINOv2 + X-CLIP
# CoTracker3 loads via torch.hub at runtime
```

---

## Cost notes

- All three LLM judges are the cheap "small/fast" tiers; for 6 calls/sample (3
  judges × 2 prompts) the per-sample LLM cost is **~$0.0035** at current
  pricing.
- 10 records (one experiment, one model): ~$0.04
- Full scipy+kubric (2,430 records, one model): **~$8.50**
- CodeBLEU + runnability + recovery: local CPU, $0
- Video similarity / trajectory / sensitivity study: local GPU or CPU, $0

**Cost breakdown observed** on the ~1,000-row rebuttal pilot:

| Judge | Rows | Cost |
|---|---:|---:|
| GPT-5 Nano | ~525 | ~$0.29 (dominates cost — 2× more output tokens than input) |
| Gemini 2.5 Flash | ~525 | ~$0.03 |
| Grok 4 Fast | ~525 | ~$0.10 |

No response cache by design — re-runs cost the same.

---

## Reproducibility notes

- The scorers are deterministic modulo judge-model non-determinism. The
  judges' `raw_response` is stored in full so any downstream analysis can be
  re-done offline without re-invoking APIs.
- `run_dataset.py` uses `--resume` by default (walks the existing eval_results
  to skip already-scored samples), so mid-run interruptions are safe.
- All hardcoded paths in `_common.py` are `Path(__file__).resolve().parent`-based
  or env-overridable via `PHYSIM_BENCH_ROOT`. If you move the repo, no code
  edits are needed.
