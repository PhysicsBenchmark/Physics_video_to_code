"""Orchestrator: run all three scorers (equivalence, validity, codebleu) over a
results.jsonl and write everything to eval_results.jsonl."""
from __future__ import annotations
import argparse, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from eval import score_law_equivalence, score_law_validity, score_codebleu
from eval._common import read_results, sample_filter, write_jsonl
from eval.judges import OpenAIJudge, GeminiJudge, GrokJudge


JUDGE_FACTORY = {"openai": OpenAIJudge, "gemini": GeminiJudge, "grok": GrokJudge}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results",     default="results.jsonl")
    ap.add_argument("--out",         default="eval_results.jsonl")
    ap.add_argument("--limit",       type=int, default=None)
    ap.add_argument("--engines",     nargs="*", default=None)
    ap.add_argument("--experiments", nargs="*", default=None)
    ap.add_argument("--judges",      nargs="*", default=["openai", "gemini", "grok"])
    ap.add_argument("--scorers",     nargs="*",
                    default=["equivalence", "validity", "codebleu"])
    ap.add_argument("--truncate",    action="store_true",
                    help="Empty the output file before writing.")
    args = ap.parse_args()

    if args.truncate:
        open(args.out, "w").close()

    judges = [JUDGE_FACTORY[name]() for name in args.judges]
    print(f"[run_all] judges = {[j.name for j in judges]}")
    print(f"[run_all] scorers = {args.scorers}")

    recs = [r for r in read_results(args.results)
            if sample_filter(r, args.experiments, args.engines)]
    if args.limit:
        recs = recs[:args.limit]
    print(f"[run_all] {len(recs)} input records")

    if "equivalence" in args.scorers:
        print("\n=== law equivalence ===")
        rows = []
        for i, rec in enumerate(recs, 1):
            r = score_law_equivalence.score_one_record(rec, judges)
            rows.extend(r)
            print(f"  [{i}/{len(recs)}] equiv: {rec['engine']}/{rec['experiment']}/{rec['sample_id']} "
                  f"({len(r)} rows)")
        write_jsonl(rows, args.out, append=True)

    if "validity" in args.scorers:
        print("\n=== law validity ===")
        rows = []
        for i, rec in enumerate(recs, 1):
            r = score_law_validity.score_one_record(rec, judges)
            rows.extend(r)
            print(f"  [{i}/{len(recs)}] valid: {rec['engine']}/{rec['experiment']}/{rec['sample_id']} "
                  f"({len(r)} rows)")
        write_jsonl(rows, args.out, append=True)

    if "codebleu" in args.scorers:
        print("\n=== codebleu ===")
        rows = [score_codebleu.score_one_record(rec) for rec in recs]
        write_jsonl(rows, args.out, append=True)
        print(f"  wrote {len(rows)} codebleu rows")

    print(f"\n[run_all] done. all rows appended to {args.out}")


if __name__ == "__main__":
    main()
