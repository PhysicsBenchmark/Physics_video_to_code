#!/bin/bash
# Finish all pending work:
#   Stage A (parallel):
#     - vsim chain: pixtral -> nova -> glm
#     - eval: internvl3_5
#   Stage B (sequential after A):
#     - vsim: internvl3_5
set -e
cd /scr/adityag6/Physics-Simulation-Code-Generation
export HF_HOME=/scr/adityag6/hf_cache
PY=/home/adityag6/miniconda3/envs/py310/bin/python

echo "=== STAGE A start $(date +%H:%M:%S) ==="

# ── Stage A: vsim chain (pixtral, nova, glm) ───────────────────────────
{
    for M in pixtral_12b nova_2_lite glm_4_1v_9b_thinking; do
        echo "[vsimA] start $M $(date +%H:%M:%S)"
        $PY eval/score_video_similarity.py --models $M --device cuda:7 --shard 0 --num-shards 2 \
            > eval_outputs/$M/video_sim.log.s0 2>&1 &
        P0=$!
        $PY eval/score_video_similarity.py --models $M --device cuda:4 --shard 1 --num-shards 2 \
            > eval_outputs/$M/video_sim.log.s1 2>&1 &
        P1=$!
        wait $P0
        wait $P1
        $PY eval/make_video_sim_report.py $M
        echo "[vsimA] done $M $(date +%H:%M:%S)"
    done
    echo "[vsimA] CHAIN DONE $(date +%H:%M:%S)"
} > /tmp/finish_vsimA.log 2>&1 &
VSIM_A_PID=$!

# ── Stage A: internvl3_5 eval pipeline ────────────────────────────────
{
    M=internvl3_5_30b_a3b
    echo "[evalA] start $M $(date +%H:%M:%S)"
    $PY eval/recover_inference_outputs.py --models $M 2>&1 | tail -5
    mkdir -p eval_outputs/$M
    $PY eval/run_dataset.py --models $M --concurrency 128 --runnability_timeout 120 \
        > eval_outputs/$M/run.log 2>&1
    $PY eval/make_model_report.py $M
    $PY eval/compute_kappa.py $M
    echo "[evalA] CHAIN DONE $(date +%H:%M:%S)"
} > /tmp/finish_evalA.log 2>&1 &
EVAL_A_PID=$!

wait $VSIM_A_PID
wait $EVAL_A_PID
echo "=== STAGE A done $(date +%H:%M:%S) ==="

# ── Stage B: vsim for internvl3_5 (now that eval finished) ────────────
echo "=== STAGE B (internvl3_5 vsim) start $(date +%H:%M:%S) ==="
M=internvl3_5_30b_a3b
$PY eval/score_video_similarity.py --models $M --device cuda:7 --shard 0 --num-shards 2 \
    > eval_outputs/$M/video_sim.log.s0 2>&1 &
P0=$!
$PY eval/score_video_similarity.py --models $M --device cuda:4 --shard 1 --num-shards 2 \
    > eval_outputs/$M/video_sim.log.s1 2>&1 &
P1=$!
wait $P0
wait $P1
$PY eval/make_video_sim_report.py $M
echo "=== STAGE B done $(date +%H:%M:%S) ==="
echo "ALL DONE"
