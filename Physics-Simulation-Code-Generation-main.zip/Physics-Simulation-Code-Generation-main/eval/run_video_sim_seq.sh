#!/bin/bash
# Run video similarity sequentially across 3 models, using 2 GPUs per model.
set -e
cd /scr/adityag6/Physics-Simulation-Code-Generation
export HF_HOME=/scr/adityag6/hf_cache
PY=/home/adityag6/miniconda3/envs/py310/bin/python

for M in gpt_5_mini gemma_3_12b_it grok_4_fast_reasoning; do
    LOG=eval_outputs/$M/video_sim.log
    echo "=== START $M $(date +%H:%M:%S) ===" >> $LOG

    # Spawn shard 0 on cuda:0 and shard 1 on cuda:1 in parallel
    $PY eval/score_video_similarity.py --models $M --device cuda:0 \
        --shard 0 --num-shards 2 >> ${LOG}.s0 2>&1 &
    SHARD0_PID=$!
    $PY eval/score_video_similarity.py --models $M --device cuda:1 \
        --shard 1 --num-shards 2 >> ${LOG}.s1 2>&1 &
    SHARD1_PID=$!

    # Wait for both shards to finish
    wait $SHARD0_PID
    rc0=$?
    wait $SHARD1_PID
    rc1=$?
    echo "=== SCORE $M done s0=$rc0 s1=$rc1 $(date +%H:%M:%S) ===" >> $LOG

    # Generate report
    $PY eval/make_video_sim_report.py $M >> $LOG 2>&1
    echo "=== REPORT $M done $(date +%H:%M:%S) ===" >> $LOG
done
echo "ALL DONE" >> /tmp/video_sim_done.flag
