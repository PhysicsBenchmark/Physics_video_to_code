"""Score trajectory similarity (CoTracker3 + DBSCAN clustering + DTW matching)
for all rendered/reference video pairs of a model, restricted to one engine.

Output: eval_outputs/<model>/trajectory_similarity_<engine>.jsonl
        one row per pair: pair_id, engine, experiment, sample_id,
        n_gen_moving, n_ref_moving, coverage, fidelity, physics_score, wall_s

Usage:
    python eval/score_trajectory.py --model gpt_5_mini --engine scipy --device cuda:7
    python eval/score_trajectory.py --model gpt_5_mini --engine scipy --shard 0 --num-shards 2
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

# Reuse the smoke pipeline (CoTracker + match_and_score + read_video_frames)
sys.path.insert(0, 'eval')
from smoke_trajectory import (read_video_frames, method_cotracker, match_and_score,
                              _load_cotracker)


def find_pairs(model: str, engine: str, ref_root: Path, runs_root: Path,
               min_size: int = 1024) -> list[dict]:
    pairs = []
    eng_dir = runs_root / engine
    if not eng_dir.exists():
        return pairs
    for vid in sorted(eng_dir.rglob('video.mp4')):
        rel = vid.relative_to(runs_root)
        parts = rel.parts
        if len(parts) < 4: continue
        eng, exp, sid = parts[0], parts[1], parts[2]
        if eng != engine: continue
        ref = ref_root / eng / exp / sid / 'video.mp4'
        if not ref.exists(): continue
        if vid.stat().st_size < min_size: continue
        pairs.append({'engine': eng, 'experiment': exp, 'sample_id': sid,
                      'rendered': str(vid), 'reference': str(ref)})
    return pairs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True)
    ap.add_argument('--engine', default='scipy', choices=['scipy', 'kubric'])
    ap.add_argument('--device', default='cuda:0')
    ap.add_argument('--shard', type=int, default=0)
    ap.add_argument('--num-shards', type=int, default=1)
    ap.add_argument('--limit', type=int, default=None)
    ap.add_argument('--no-resume', dest='resume', action='store_false')
    args = ap.parse_args()

    import os
    eval_root = Path(os.environ.get('PHYSIM_EVAL_ROOT', 'eval_outputs'))
    ref_root  = Path(os.environ.get('PHYSIM_BENCH_ROOT', 'benchmarking_data'))
    eval_dir = eval_root / args.model
    runs_root = eval_dir / 'runs'
    out_path = eval_dir / f'trajectory_similarity_{args.engine}.jsonl'

    pairs = find_pairs(args.model, args.engine, ref_root, runs_root)
    if args.num_shards > 1:
        pairs = [p for i, p in enumerate(pairs) if i % args.num_shards == args.shard]

    # Resume
    done = set()
    if args.resume and out_path.exists():
        for line in out_path.read_text().splitlines():
            line = line.strip()
            if not line: continue
            try:
                r = json.loads(line)
                done.add((r['engine'], r['experiment'], r['sample_id']))
            except: pass
    pending = [p for p in pairs if (p['engine'], p['experiment'], p['sample_id']) not in done]
    if args.limit is not None:
        pending = pending[:args.limit]

    print(f'[traj] {args.model}/{args.engine}  total={len(pairs)}  '
          f'done={len(done)}  pending={len(pending)}  device={args.device}',
          flush=True)
    if not pending:
        return

    # Warm up model
    _load_cotracker(args.device)

    f_out = out_path.open('a', buffering=1)
    n_done = n_err = 0
    t0 = time.time()
    for i, p in enumerate(pending):
        row = {'model': args.model, 'engine': p['engine'],
               'experiment': p['experiment'], 'sample_id': p['sample_id']}
        try:
            t1 = time.time()
            f_gen = read_video_frames(p['rendered'])
            f_ref = read_video_frames(p['reference'])
            if f_gen is None or f_ref is None:
                raise RuntimeError('frame read failed')
            traj_gen = method_cotracker(f_gen, device=args.device)
            traj_ref = method_cotracker(f_ref, device=args.device)
            scores = match_and_score(traj_gen, traj_ref)
            row.update(scores)
            row['wall_s'] = round(time.time() - t1, 2)
            row['status'] = 'ok'
            n_done += 1
        except Exception as e:
            row['status'] = 'error'
            row['error'] = f'{type(e).__name__}: {str(e)[:100]}'
            row['wall_s'] = round(time.time() - t1, 2)
            n_err += 1
        f_out.write(json.dumps(row) + '\n')

        if (i + 1) % 50 == 0 or (i + 1) == len(pending):
            rate = (i + 1) / max(time.time() - t0, 0.1)
            print(f'  [{i+1:>4d}/{len(pending)}]  ok={n_done}  err={n_err}  {rate:.2f}/s',
                  flush=True)
    f_out.close()


if __name__ == '__main__':
    main()
