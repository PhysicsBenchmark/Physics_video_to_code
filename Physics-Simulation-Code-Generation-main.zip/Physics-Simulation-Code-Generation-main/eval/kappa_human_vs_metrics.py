"""Compute Cohen's quadratic-weighted kappa between human physics-equivalence
ratings and (a) automated similarity metrics, (b) LLM judges, then save plots.

Outputs go to eval_outputs/_kappa_plots/:
  per_model_auto_<model>.png           (10 plots: DINO/CLIP/CoTracker)
  per_model_judge_<model>.png          (10 plots: gpt-5-nano/gemini-flash/grok-fast)
  avg_auto_all.png, avg_auto_open.png, avg_auto_closed.png
  avg_judge_all.png, avg_judge_open.png, avg_judge_closed.png
  kappa_table.csv                      (raw values)
"""
import csv
import json
import os
from collections import defaultdict
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import cohen_kappa_score

ROOT = Path("/scr/adityag6/Physics-Simulation-Code-Generation/eval_outputs")
OUT = ROOT / "_kappa_plots"
OUT.mkdir(exist_ok=True)

CLOSED = ["gpt_5_mini", "gemini_2_5_pro", "claude_sonnet_4_6",
          "grok_4_fast_reasoning", "nova_2_lite"]
OPEN = ["qwen3vl_30b_a3b", "internvl3_5_30b_a3b", "gemma_3_12b_it",
        "glm_4_1v_9b_thinking", "pixtral_12b"]
ALL_MODELS = CLOSED + OPEN

PRETTY = {
    "gpt_5_mini": "GPT-5 Mini",
    "gemini_2_5_pro": "Gemini 2.5 Pro",
    "claude_sonnet_4_6": "Claude Sonnet 4.6",
    "grok_4_fast_reasoning": "Grok 4 Fast Reasoning",
    "nova_2_lite": "Nova 2 Lite",
    "qwen3vl_30b_a3b": "Qwen3-VL-30B-A3B",
    "internvl3_5_30b_a3b": "InternVL3.5-30B-A3B",
    "gemma_3_12b_it": "Gemma-3-12B-IT",
    "glm_4_1v_9b_thinking": "GLM-4.1V-9B-Thinking",
    "pixtral_12b": "Pixtral-12B-2409",
}

JUDGES = ["gpt-5-nano", "gemini-2.5-flash", "grok-4-1-fast"]
JUDGE_LABEL = {"gpt-5-nano": "GPT-5-nano",
               "gemini-2.5-flash": "Gemini-2.5-Flash",
               "grok-4-1-fast": "Grok-4.1-Fast"}
AUTO_LABELS = ["DINOv2", "VideoCLIP", "CoTracker"]


def parse_pair_id(pair_id: str):
    """pair_000_kubric_coin_spin_topple_674 -> (kubric, coin_spin_topple, 674)."""
    parts = pair_id.split("_", 2)  # ['pair', '000', 'rest']
    rest = parts[2]
    engine, rest2 = rest.split("_", 1)
    last_underscore = rest2.rfind("_")
    experiment = rest2[:last_underscore]
    sample_id = rest2[last_underscore + 1:]
    return engine, experiment, sample_id


def load_human(model: str, column: str = "physics"):
    """Return dict (engine, experiment, sample_id) -> rating (int 1-5).

    column: one of "physics", "appearance", "plausibility".
    """
    path = ROOT / model / "human_labels.csv"
    out = {}
    with open(path) as f:
        for row in csv.DictReader(f):
            key = parse_pair_id(row["pair_id"])
            out[key] = int(row[column])
    return out


def load_video_sim(model: str):
    """Return dict key -> (dino, xclip)."""
    path = ROOT / model / "video_similarity.jsonl"
    out = {}
    with open(path) as f:
        for line in f:
            d = json.loads(line)
            if d.get("status") != "ok":
                continue
            key = (d["engine"], d["experiment"], d["sample_id"])
            out[key] = (d.get("dino_cosine"), d.get("xclip_cosine"))
    return out


def load_traj(model: str):
    """Return dict key -> physics_score (scipy only)."""
    path = ROOT / model / "trajectory_similarity_scipy.jsonl"
    out = {}
    if not path.exists():
        return out
    with open(path) as f:
        for line in f:
            try:
                d = json.loads(line)
            except Exception:
                continue
            if d.get("status") != "ok":
                continue
            key = (d["engine"], d["experiment"], d["sample_id"])
            score = d.get("physics_score")
            if score is None:
                continue
            out[key] = float(score)
    return out


def load_judge(model: str):
    """Return dict key -> {judge -> overall 0-4}."""
    path = ROOT / model / "eval_results.jsonl"
    out = defaultdict(dict)
    with open(path) as f:
        for line in f:
            d = json.loads(line)
            if d.get("scorer") != "law_equivalence":
                continue
            scores = d.get("scores")
            if not scores:
                continue
            judge = d.get("judge_model")
            if judge not in JUDGES:
                continue
            key = (d["engine"], d["experiment"], d["sample_id"])
            out[key][judge] = scores.get("overall")
    return out


def quintile_bin(values, edges=None):
    """Discretize a 1-D array into 5 ordinal bins (1..5).

    If edges is None, compute quintile edges from values; else use provided.
    Returns (bins, edges).
    """
    arr = np.asarray(values, dtype=float)
    if edges is None:
        qs = np.quantile(arr[~np.isnan(arr)], [0.2, 0.4, 0.6, 0.8])
        edges = qs
    bins = np.digitize(arr, edges, right=False) + 1  # 1..5
    bins = np.clip(bins, 1, 5)
    return bins, edges


def compute_global_edges():
    """Pool DINO/XCLIP/Tracker scores across ALL models; produce shared edges."""
    dinos, clips, traks = [], [], []
    for m in ALL_MODELS:
        v = load_video_sim(m)
        for d, c in v.values():
            if d is not None: dinos.append(d)
            if c is not None: clips.append(c)
        for s in load_traj(m).values():
            traks.append(s)
    _, e_d = quintile_bin(dinos)
    _, e_c = quintile_bin(clips)
    _, e_t = quintile_bin(traks)
    return e_d, e_c, e_t


def kappa(a, b):
    a = np.asarray(a, dtype=int)
    b = np.asarray(b, dtype=int)
    if len(a) < 5 or len(np.unique(a)) < 2 or len(np.unique(b)) < 2:
        return float("nan"), len(a)
    return float(cohen_kappa_score(a, b, weights="quadratic")), len(a)


def per_model_kappas(model, edges):
    e_d, e_c, e_t = edges
    human = load_human(model)
    vid = load_video_sim(model)
    trj = load_traj(model)
    jud = load_judge(model)

    h_list, dino_raw, clip_raw, trak_raw = [], [], [], []
    j_lists = {j: [] for j in JUDGES}
    h_judge_list = []  # human ratings paired w/ judge entries (different N)
    for k, h in human.items():
        d, c = vid.get(k, (None, None))
        t = trj.get(k)
        h_list.append(h)
        dino_raw.append(d if d is not None else np.nan)
        clip_raw.append(c if c is not None else np.nan)
        trak_raw.append(t if t is not None else np.nan)

    # Auto kappas (drop NaN per metric)
    h_arr = np.array(h_list)
    out = {}
    for name, raw, edge in zip(["DINOv2", "VideoCLIP", "CoTracker"],
                                [dino_raw, clip_raw, trak_raw],
                                [e_d, e_c, e_t]):
        raw_arr = np.array(raw, dtype=float)
        mask = ~np.isnan(raw_arr)
        if mask.sum() < 5:
            out[name] = (float("nan"), int(mask.sum()))
            continue
        bins, _ = quintile_bin(raw_arr[mask], edges=edge)
        out[name] = kappa(h_arr[mask], bins)

    # Judge kappas: judge "overall" is 0-4; map to 1-5 by +1.
    judge_out = {}
    for j in JUDGES:
        h_j, j_vals = [], []
        for k, h in human.items():
            v = jud.get(k, {}).get(j)
            if v is None:
                continue
            h_j.append(h)
            j_vals.append(int(v) + 1)
        judge_out[j] = kappa(h_j, j_vals) if len(h_j) >= 5 else (float("nan"), len(h_j))
    return out, judge_out


def bar_plot(values, errs, labels, title, fname, ylim=(-0.05, 0.6), ns=None):
    fig, ax = plt.subplots(figsize=(5.0, 3.4))
    x = np.arange(len(labels))
    colors = ["#4477AA", "#EE6677", "#228833", "#CCBB44"][:len(labels)]
    bars = ax.bar(x, values, color=colors, edgecolor="black", linewidth=0.6,
                  yerr=errs if errs is not None else None,
                  capsize=4, error_kw=dict(elinewidth=1.0))
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=10)
    ax.axhline(0, color="black", lw=0.6)
    ax.set_ylim(*ylim)
    ax.set_ylabel(r"Quadratic-weighted Cohen's $\kappa$", fontsize=10)
    ax.set_title(title, fontsize=11)
    for i, (b, v) in enumerate(zip(bars, values)):
        if not np.isnan(v):
            txt = f"{v:.2f}"
            if ns is not None:
                txt += f"\n(n={ns[i]})"
            ax.text(b.get_x() + b.get_width() / 2, v + 0.015 if v >= 0 else v - 0.05,
                    txt, ha="center", fontsize=8)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout()
    fig.savefig(fname, dpi=200)
    plt.close(fig)


def box_plot(series, labels, title, fname, ylim=(-0.4, 0.6)):
    """series: list of arrays (one per box). Overlay individual model points."""
    fig, ax = plt.subplots(figsize=(5.0, 3.6))
    bp = ax.boxplot(series, labels=labels, widths=0.55, patch_artist=True,
                    medianprops=dict(color="black", lw=1.4),
                    boxprops=dict(linewidth=0.8),
                    whiskerprops=dict(linewidth=0.8),
                    capprops=dict(linewidth=0.8),
                    flierprops=dict(marker="x", markersize=4, alpha=0.5))
    colors = ["#4477AA", "#EE6677", "#228833", "#CCBB44"][:len(series)]
    for patch, c in zip(bp["boxes"], colors):
        patch.set_facecolor(c); patch.set_alpha(0.35)
    rng = np.random.default_rng(0)
    for i, vals in enumerate(series, start=1):
        v = np.asarray(vals, dtype=float)
        v = v[~np.isnan(v)]
        x = rng.normal(loc=i, scale=0.05, size=v.shape)
        ax.scatter(x, v, color=colors[i - 1], edgecolor="black", linewidth=0.4,
                   zorder=3, s=28, alpha=0.85)
        ax.text(i, ax.get_ylim()[1] if False else 0.99 * ylim[1],
                f"$\\bar\\kappa$={np.nanmean(v):.2f}",
                ha="center", fontsize=8, transform=ax.transData)
    ax.axhline(0, color="black", lw=0.6, ls=":")
    ax.set_ylim(*ylim)
    ax.set_ylabel(r"Quadratic-weighted Cohen's $\kappa$", fontsize=10)
    ax.set_title(title, fontsize=11)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout()
    fig.savefig(fname, dpi=200)
    plt.close(fig)


def heatmap_plot(K, names, title, fname, cbar_label="Weighted Cohen's Kappa"):
    """Lower-triangular pairwise-kappa heatmap matching kappa_law_equivalence_*.png."""
    import math
    import matplotlib.colors as mcolors
    from matplotlib.ticker import FormatStrFormatter, NullFormatter

    n = len(names)
    K = np.asarray(K, dtype=float)

    cmap = mcolors.LinearSegmentedColormap.from_list(
        "muted_cols", ["#FFFDE7", "#FFF5CC", "#FFE0B2", "#FFCC80", "#FFAB91"])
    plotted = [K[i, j] for i in range(1, n) for j in range(i)
               if not np.isnan(K[i, j])]
    vmin = max(min(plotted) if plotted else 1e-3, 1e-3)
    vmax = max(max(plotted) if plotted else 1.0, 1e-3)
    if vmin >= vmax:
        vmin, vmax = 1e-3, 1.0
    norm = mcolors.LogNorm(vmin=vmin, vmax=vmax)

    fig, ax = plt.subplots(figsize=(max(10, n * 3.2), max(8, n * 3.0)))
    for i in range(1, n):
        for j in range(i):
            v = K[i, j]
            if np.isnan(v):
                continue
            color = cmap(norm(max(v, 1e-3)))
            rect = plt.Rectangle((j, i - 1), 1, 1, facecolor=color, edgecolor="gray")
            ax.add_patch(rect)
            ax.text(j + 0.5, i - 0.5, f"{v:.3f}",
                    ha="center", va="center",
                    color="black", fontsize=24, weight="bold")

    ax.set_xlim(0, n - 1)
    ax.set_ylim(0, n - 1)
    ax.set_xticks(np.arange(n - 1) + 0.5)
    ax.set_yticks(np.arange(n - 1) + 0.5)
    ax.set_xticklabels(names[:-1], rotation=45, ha="right", fontsize=18)
    ax.set_yticklabels(names[1:], fontsize=18)
    ax.invert_yaxis()
    ax.set_aspect("equal")
    ax.set_title(title, fontsize=22, weight="bold", pad=20)
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.tick_params(top=False, bottom=False, left=False, right=False)

    sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
    sm.set_array([])
    cbar = fig.colorbar(sm, ax=ax, fraction=0.046, pad=0.04)
    if vmin < vmax:
        cbar.set_ticks(np.logspace(math.log10(vmin), math.log10(vmax), 5))
    cbar.set_label(cbar_label, fontsize=18)
    cbar.ax.tick_params(labelsize=14)
    cbar.ax.yaxis.set_major_formatter(FormatStrFormatter("%.2f"))
    cbar.ax.yaxis.set_minor_formatter(NullFormatter())
    cbar.ax.minorticks_off()

    plt.tight_layout()
    plt.savefig(fname, dpi=200, bbox_inches="tight")
    plt.close(fig)


def collect_pooled_streams(models, edges, human_column="physics"):
    """Build aligned per-pair streams pooled across given models.

    Returns dict of arrays keyed by name; values are np.float arrays.
    Tracker is NaN for kubric pairs (only scipy pairs have it).
    Judges may be NaN where parsing failed.
    """
    e_d, e_c, e_t = edges
    rows = {"human": [], "dino_raw": [], "clip_raw": [], "trak_raw": [],
            "j_nano": [], "j_gem": [], "j_grok": []}
    for m in models:
        human = load_human(m, column=human_column)
        vid = load_video_sim(m)
        trj = load_traj(m)
        jud = load_judge(m)
        for k, h in human.items():
            rows["human"].append(h)
            d, c = vid.get(k, (None, None))
            rows["dino_raw"].append(d if d is not None else np.nan)
            rows["clip_raw"].append(c if c is not None else np.nan)
            rows["trak_raw"].append(trj.get(k, np.nan))
            jr = jud.get(k, {})
            rows["j_nano"].append((jr.get("gpt-5-nano") + 1) if jr.get("gpt-5-nano") is not None else np.nan)
            rows["j_gem"].append((jr.get("gemini-2.5-flash") + 1) if jr.get("gemini-2.5-flash") is not None else np.nan)
            rows["j_grok"].append((jr.get("grok-4-1-fast") + 1) if jr.get("grok-4-1-fast") is not None else np.nan)
    arr = {k: np.asarray(v, dtype=float) for k, v in rows.items()}
    # Bin the continuous metrics with the global edges
    for raw, edge, key in [("dino_raw", e_d, "dino"),
                           ("clip_raw", e_c, "clip"),
                           ("trak_raw", e_t, "trak")]:
        x = arr[raw]
        b = np.full_like(x, np.nan, dtype=float)
        m = ~np.isnan(x)
        bins, _ = quintile_bin(x[m], edges=edge)
        b[m] = bins
        arr[key] = b
    return arr


def pairwise_kappa_matrix(arr, names, keys):
    """Build a len(names) x len(names) matrix of pairwise kappas using the
    given column keys; NaN-aligned per pair."""
    n = len(names)
    K = np.full((n, n), np.nan)
    for i in range(n):
        for j in range(n):
            if i <= j:
                continue
            a = arr[keys[i]]; b = arr[keys[j]]
            mask = ~np.isnan(a) & ~np.isnan(b)
            if mask.sum() < 5:
                continue
            K[i, j] = float(cohen_kappa_score(a[mask].astype(int),
                                              b[mask].astype(int),
                                              weights="quadratic"))
    return K


def make_pairwise_heatmaps(edges):
    groups = [("all", ALL_MODELS), ("open", OPEN), ("closed", CLOSED)]
    for label, models in groups:
        # Judges (3x3) — independent of human dimension
        arr_phys = collect_pooled_streams(models, edges, human_column="physics")
        names = ["gpt-5-nano", "gemini-2.5-flash", "grok-4-1-fast"]
        keys = ["j_nano", "j_gem", "j_grok"]
        K = pairwise_kappa_matrix(arr_phys, names, keys)
        heatmap_plot(K, names,
                     f"Inter-judge agreement ({label} models, pooled)",
                     OUT / f"pairwise_judge_{label}.png")

        # Auto-metric heatmaps for each human dimension
        for human_col in ("physics", "appearance"):
            arr = (arr_phys if human_col == "physics"
                   else collect_pooled_streams(models, edges, human_column=human_col))

            # Human + image/video (3x3, no tracker)
            names = [f"human-{human_col}", "DINOv2", "VideoCLIP"]
            keys = ["human", "dino", "clip"]
            K = pairwise_kappa_matrix(arr, names, keys)
            heatmap_plot(K, names,
                         f"Human ({human_col}) + image/video ({label} models, pooled)",
                         OUT / f"pairwise_auto_no_tracker_{label}_{human_col}.png")

            # Human + image/video + tracker (4x4)
            names = [f"human-{human_col}", "DINOv2", "VideoCLIP", "CoTracker"]
            keys = ["human", "dino", "clip", "trak"]
            K = pairwise_kappa_matrix(arr, names, keys)
            heatmap_plot(K, names,
                         f"Human ({human_col}) + image/video/tracker ({label} models, pooled)",
                         OUT / f"pairwise_auto_with_tracker_{label}_{human_col}.png")


def make_box_plots(auto, judge):
    groups = [("all", ALL_MODELS), ("open", OPEN), ("closed", CLOSED)]
    # Judge boxes
    for label, models in groups:
        series = [[judge[m][j][0] for m in models] for j in JUDGES]
        box_plot(series, [JUDGE_LABEL[j] for j in JUDGES],
                 f"LLM judges vs. human physics ({label} models)",
                 OUT / f"box_judge_{label}.png")
    # Auto without CoTracker
    for label, models in groups:
        keys = ["DINOv2", "VideoCLIP"]
        series = [[auto[m][k][0] for m in models] for k in keys]
        box_plot(series, keys,
                 f"Image/video sim vs. human physics ({label} models)",
                 OUT / f"box_auto_no_tracker_{label}.png")
    # Auto with CoTracker
    for label, models in groups:
        keys = ["DINOv2", "VideoCLIP", "CoTracker"]
        series = [[auto[m][k][0] for m in models] for k in keys]
        box_plot(series, keys,
                 f"Image/video/tracker sim vs. human physics ({label} models)",
                 OUT / f"box_auto_with_tracker_{label}.png")


def main():
    edges = compute_global_edges()
    print("DINO edges:", edges[0])
    print("CLIP edges:", edges[1])
    print("Trak edges:", edges[2])

    auto = {}   # model -> {metric -> (kappa, n)}
    judge = {}  # model -> {judge -> (kappa, n)}
    for m in ALL_MODELS:
        auto[m], judge[m] = per_model_kappas(m, edges)
        print(f"{m}: auto={auto[m]}  judge={judge[m]}")

    # Pairwise heatmaps (9 total) — same style as kappa_law_equivalence_*.png
    make_pairwise_heatmaps(edges)

    # Dump CSV
    with open(OUT / "kappa_table.csv", "w") as f:
        w = csv.writer(f)
        w.writerow(["model", "comparator", "kappa", "n"])
        for m in ALL_MODELS:
            for n in AUTO_LABELS:
                k, nn = auto[m][n]
                w.writerow([m, n, f"{k:.4f}" if not np.isnan(k) else "nan", nn])
            for j in JUDGES:
                k, nn = judge[m][j]
                w.writerow([m, JUDGE_LABEL[j], f"{k:.4f}" if not np.isnan(k) else "nan", nn])

    print(f"\nWrote plots to {OUT}/")


if __name__ == "__main__":
    main()
