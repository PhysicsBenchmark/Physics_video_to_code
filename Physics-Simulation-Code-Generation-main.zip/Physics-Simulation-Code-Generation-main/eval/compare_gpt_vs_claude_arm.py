"""Compare each model's performance on GPT-authored vs Claude-authored GT.

Matched design: 15 experiments × 5 samples per arm = 75 samples per arm.
  GPT arm:    eval_outputs_rebuttal/<model>/eval_results.jsonl
              (75 rows, engine=scipy, experiment=*_gpt, sample_id=000..004)
  Claude arm: eval_outputs/<model>/eval_results.jsonl
              (filter to same 15 parents + first 5 lex sample_ids)

Usage:
  # single model with sub-score breakdown
  python eval/compare_gpt_vs_claude_arm.py --model qwen3vl_30b_a3b
  # cross-model summary table
  python eval/compare_gpt_vs_claude_arm.py --all
"""
import argparse
import json
import statistics as st
from collections import defaultdict
from pathlib import Path

ROOT = Path("/scr/adityag6/Physics-Simulation-Code-Generation")

ALL_MODELS = ["claude_sonnet_4_6", "gemini_2_5_pro", "gpt_5_mini",
              "grok_4_fast_reasoning", "nova_2_lite",
              "qwen3vl_30b_a3b", "internvl3_5_30b_a3b", "gemma_3_12b_it",
              "glm_4_1v_9b_thinking", "pixtral_12b"]

# Only 8 models have rebuttal data (grok + nova excluded)
REBUTTAL_MODELS = ["claude_sonnet_4_6", "gemini_2_5_pro", "gpt_5_mini",
                   "qwen3vl_30b_a3b", "internvl3_5_30b_a3b", "gemma_3_12b_it",
                   "glm_4_1v_9b_thinking", "pixtral_12b"]


def paths_for(model):
    return {
        "gpt_eval": ROOT / "eval_outputs_rebuttal" / model / "eval_results.jsonl",
        "cld_eval": ROOT / "eval_outputs" / model / "eval_results.jsonl",
        "gpt_vsim": ROOT / "eval_outputs_rebuttal" / model / "video_similarity.jsonl",
        "cld_vsim": ROOT / "eval_outputs" / model / "video_similarity.jsonl",
        "gpt_traj": ROOT / "eval_outputs_rebuttal" / model / "trajectory_similarity_scipy.jsonl",
        "cld_traj": ROOT / "eval_outputs" / model / "trajectory_similarity_scipy.jsonl",
    }

PARENTS = ["ball_wrapping_pole", "balls_in_basin", "block_on_sphere_basin",
           "block_strikes_spring_pair", "cylinder_piston_ball",
           "discs_friction_coupling", "half_cylinder_drop", "projectile_bounce",
           "ring_sticky_collision", "semicircular_track",
           "slab_springs_block_drop", "sliding_block_step_topple",
           "stacked_balls_drop", "wheel_down_stairs", "wheel_wall_bounce"]


def collect_claude_first5(claude_eval_path):
    """Filter Claude-arm eval to the 15 parents, first 5 lex sample_ids each."""
    by_exp = defaultdict(set)
    all_rows = []
    with open(claude_eval_path) as f:
        for line in f:
            d = json.loads(line)
            if d.get("engine") != "scipy":
                continue
            exp = d.get("experiment")
            if exp not in PARENTS:
                continue
            by_exp[exp].add(d.get("sample_id"))
            all_rows.append(d)
    keep = {}
    for exp in PARENTS:
        keep[exp] = set(sorted(by_exp[exp])[:5])
    kept = [r for r in all_rows
            if r["sample_id"] in keep.get(r["experiment"], set())]
    return kept


def collect_gpt(gpt_eval_path):
    with open(gpt_eval_path) as f:
        return [json.loads(l) for l in f]


def load_vsim(path):
    """Return list of {engine, experiment, sample_id, dino, xclip}."""
    out = []
    if not path.exists(): return out
    with open(path) as f:
        for l in f:
            d = json.loads(l)
            if d.get("status") != "ok": continue
            out.append({
                "engine": d["engine"], "experiment": d["experiment"], "sample_id": d["sample_id"],
                "dino": d.get("dino_cosine"), "xclip": d.get("xclip_cosine"),
            })
    return out


def load_traj(path):
    out = []
    if not path.exists(): return out
    with open(path) as f:
        for l in f:
            d = json.loads(l)
            if d.get("status") != "ok": continue
            out.append({
                "engine": d["engine"], "experiment": d["experiment"], "sample_id": d["sample_id"],
                "coverage": d.get("coverage"), "fidelity": d.get("fidelity"),
                "physics_score": d.get("physics_score"),
            })
    return out


def filter_claude_first5(rows, all_claude_eval_rows):
    """Filter a list of rows (any dict with experiment/sample_id) to the same
    parents + first 5 lex sample_ids as `collect_claude_first5`."""
    by_exp = defaultdict(set)
    for d in all_claude_eval_rows:
        if d.get("engine") != "scipy": continue
        exp = d.get("experiment")
        if exp not in PARENTS: continue
        by_exp[exp].add(d.get("sample_id"))
    keep = {}
    for exp in PARENTS:
        keep[exp] = set(sorted(by_exp[exp])[:5])
    return [r for r in rows
            if r["experiment"] in PARENTS
            and r["sample_id"] in keep.get(r["experiment"], set())]


def summarize(rows, arm_label):
    """Extract per-metric aggregates from a list of eval rows."""
    runn_syntax = []; runn_runs = []; runn_video = []
    codebleu = []
    # law_eq[judge][subfield] -> list of ints; subfield in {name,statement,formula,overall}
    law_eq = defaultdict(lambda: defaultdict(list))
    law_va = defaultdict(lambda: defaultdict(list))
    n_samples = set()

    for r in rows:
        n_samples.add((r["experiment"], r["sample_id"]))
        scorer = r.get("scorer")
        skipped = r.get("skipped", False)
        scores = r.get("scores") or {}
        if scorer == "runnability" and not skipped:
            runn_syntax.append(bool(scores.get("syntax_ok")))
            runn_runs.append(bool(scores.get("runs_without_error")))
            runn_video.append(bool(scores.get("produces_video_mp4")))
        elif scorer == "codebleu" and not skipped:
            v = scores.get("codebleu")
            if v is not None: codebleu.append(float(v))
        elif scorer == "law_equivalence" and not skipped:
            j = r.get("judge_model")
            for sf in ("name", "statement", "formula", "overall"):
                v = scores.get(sf)
                if v is not None: law_eq[j][sf].append(int(v))
        elif scorer == "law_validity" and not skipped:
            j = r.get("judge_model")
            for sf in ("name", "statement", "formula", "overall"):
                v = scores.get(sf)
                if v is not None: law_va[j][sf].append(int(v))

    def rate(bools):
        return 100.0 * sum(bools) / len(bools) if bools else float("nan")
    def mean(vals):
        return st.mean(vals) if vals else float("nan")

    JUDGES = ["gpt-5-nano", "gemini-2.5-flash", "grok-4-1-fast"]
    SUBS = ["name", "statement", "formula", "overall"]

    def per_judge(store, judge, sf):
        return mean(store[judge][sf])
    def cross_judge(store, sf):
        return mean([v for j in JUDGES for v in store[j][sf]])

    d = {
        "arm": arm_label,
        "n_samples": len(n_samples),
        "syntax_ok_pct": rate(runn_syntax),
        "runs_ok_pct":   rate(runn_runs),
        "video_ok_pct":  rate(runn_video),
        "runn_n": len(runn_runs),
        "codebleu": mean(codebleu),
        "codebleu_n": len(codebleu),
    }
    # Backwards-compat overall keys
    d["law_eq_gpt5nano"]     = per_judge(law_eq, "gpt-5-nano", "overall")
    d["law_eq_gemini_flash"] = per_judge(law_eq, "gemini-2.5-flash", "overall")
    d["law_eq_grok_fast"]    = per_judge(law_eq, "grok-4-1-fast", "overall")
    d["law_eq_avg"] = cross_judge(law_eq, "overall")
    d["law_va_gpt5nano"]     = per_judge(law_va, "gpt-5-nano", "overall")
    d["law_va_gemini_flash"] = per_judge(law_va, "gemini-2.5-flash", "overall")
    d["law_va_grok_fast"]    = per_judge(law_va, "grok-4-1-fast", "overall")
    d["law_va_avg"] = cross_judge(law_va, "overall")
    # NEW: 3-judge averages of each sub-score (matches paper Table 2 columns)
    for sf in SUBS:
        d[f"law_eq_{sf}_avg"] = cross_judge(law_eq, sf)
        d[f"law_va_{sf}_avg"] = cross_judge(law_va, sf)
    return d


def per_experiment_breakdown(gpt_rows, cld_rows):
    """Per-experiment runnability + judge-mean side by side."""
    def group_by_exp(rows):
        exp_rows = defaultdict(list)
        for r in rows:
            key = r["experiment"].replace("_gpt", "")  # strip suffix
            exp_rows[key].append(r)
        return exp_rows

    gpt_g = group_by_exp(gpt_rows)
    cld_g = group_by_exp(cld_rows)

    rows = []
    for exp in PARENTS:
        rows.append({
            "experiment": exp,
            "gpt":    summarize(gpt_g.get(exp, []), "gpt"),
            "claude": summarize(cld_g.get(exp, []), "claude"),
        })
    return rows


def format_pct(v):
    return f"{v:5.1f}%" if v == v else "  --  "


def format_num(v, w=6, d=3):
    return f"{v:{w}.{d}f}" if v == v else " " * (w - 3) + "--  "


def compute_arm_summaries(model):
    """Return (gpt_summary, claude_summary) for one model — all metrics on 0-4 scale."""
    p = paths_for(model)
    gpt = collect_gpt(p["gpt_eval"])
    cld = collect_claude_first5(p["cld_eval"])
    all_claude_eval = [json.loads(l) for l in open(p["cld_eval"])]
    gpt_vsim = load_vsim(p["gpt_vsim"])
    cld_vsim = filter_claude_first5(load_vsim(p["cld_vsim"]), all_claude_eval)
    gpt_traj = load_traj(p["gpt_traj"])
    cld_traj = filter_claude_first5(load_traj(p["cld_traj"]), all_claude_eval)
    sg = summarize(gpt, "gpt")
    sc = summarize(cld, "claude")
    # Append video-sim/traj means as extra keys
    def mn(vals, key):
        vs = [r[key] for r in vals if r.get(key) is not None]
        return st.mean(vs) if vs else float("nan")
    for label, dset_g, dset_c, key in [
        ("dino_mean",  gpt_vsim, cld_vsim, "dino"),
        ("xclip_mean", gpt_vsim, cld_vsim, "xclip"),
        ("traj_coverage_mean",  gpt_traj, cld_traj, "coverage"),
        ("traj_fidelity_mean",  gpt_traj, cld_traj, "fidelity"),
        ("traj_physics_mean",   gpt_traj, cld_traj, "physics_score"),
    ]:
        sg[label] = mn(dset_g, key)
        sc[label] = mn(dset_c, key)
    sg["n_vsim"] = len(gpt_vsim); sc["n_vsim"] = len(cld_vsim)
    sg["n_traj"] = len(gpt_traj); sc["n_traj"] = len(cld_traj)
    return sg, sc


def print_all_models_summary(models):
    """Cross-model side-by-side summary table."""
    print("=" * 138)
    print("CROSS-MODEL: GPT arm vs Claude arm  (Δ = GPT − Claude)  (Likert on 0-4 scale)")
    print("=" * 138)
    hdr = ("{:<25} | {:>18} | {:>18} | {:>18} | {:>18} | {:>18} | {:>18}").format(
        "model", "runs_ok  G / C / Δ", "video_ok  G / C / Δ",
        "codebleu  G / C / Δ", "law_eq  G / C / Δ", "law_va  G / C / Δ",
        "DINO  G / C / Δ")
    print(hdr)
    print("-" * len(hdr))

    def fmt3(g, c, kind):
        d = g - c if (g == g and c == c) else float("nan")
        if kind == "pct":
            return f"{g:4.1f}/{c:4.1f}/{d:+4.1f}"
        return f"{g:5.2f}/{c:5.2f}/{d:+5.2f}"

    for m in models:
        try:
            sg, sc = compute_arm_summaries(m)
        except FileNotFoundError as e:
            print(f"{m:<25} | SKIP: {e}")
            continue
        row = ("{:<25} | {:>18} | {:>18} | {:>18} | {:>18} | {:>18} | {:>18}").format(
            m,
            fmt3(sg["runs_ok_pct"], sc["runs_ok_pct"], "pct"),
            fmt3(sg["video_ok_pct"], sc["video_ok_pct"], "pct"),
            fmt3(sg["codebleu"], sc["codebleu"], "num"),
            fmt3(sg["law_eq_avg"], sc["law_eq_avg"], "num"),
            fmt3(sg["law_va_avg"], sc["law_va_avg"], "num"),
            fmt3(sg["dino_mean"], sc["dino_mean"], "num"),
        )
        print(row)

    # 2nd table: law_eq sub-scores per model
    print()
    print("=" * 138)
    print("Law-equivalence sub-scores (avg of 3 judges, 0-4 scale)  |  G = GPT arm, C = Claude arm")
    print("=" * 138)
    hdr = ("{:<25} | {:>16} | {:>16} | {:>16} | {:>16}").format(
        "model", "name  G / C", "statement  G / C", "formula  G / C", "overall  G / C")
    print(hdr)
    print("-" * len(hdr))
    for m in models:
        try: sg, sc = compute_arm_summaries(m)
        except FileNotFoundError: continue
        fmt = lambda g, c: f"{g:5.2f} / {c:5.2f}"
        print(("{:<25} | {:>16} | {:>16} | {:>16} | {:>16}").format(
            m,
            fmt(sg["law_eq_name_avg"],      sc["law_eq_name_avg"]),
            fmt(sg["law_eq_statement_avg"], sc["law_eq_statement_avg"]),
            fmt(sg["law_eq_formula_avg"],   sc["law_eq_formula_avg"]),
            fmt(sg["law_eq_overall_avg"],   sc["law_eq_overall_avg"]),
        ))

    # 3rd table: CoTracker per model
    print()
    print("=" * 130)
    print("CoTracker trajectory metrics (scipy pairs only)  |  G = GPT arm, C = Claude arm")
    print("=" * 130)
    hdr = ("{:<25} | {:>16} | {:>18} | {:>18} | {:>18}").format(
        "model", "n_traj  G / C", "coverage  G / C", "fidelity  G / C", "physics  G / C")
    print(hdr)
    print("-" * len(hdr))
    for m in models:
        try: sg, sc = compute_arm_summaries(m)
        except FileNotFoundError: continue
        fmt = lambda g, c: f"{g:5.2f} / {c:5.2f}"
        print(("{:<25} | {:>16} | {:>18} | {:>18} | {:>18}").format(
            m,
            f"{sg['n_traj']:>4d} / {sc['n_traj']:<4d}",
            fmt(sg["traj_coverage_mean"], sc["traj_coverage_mean"]),
            fmt(sg["traj_fidelity_mean"], sc["traj_fidelity_mean"]),
            fmt(sg["traj_physics_mean"], sc["traj_physics_mean"]),
        ))


def main_single(model):
    p = paths_for(model)
    gpt = collect_gpt(p["gpt_eval"])
    cld = collect_claude_first5(p["cld_eval"])

    # Video-sim + trajectory: filter Claude by same parents+first5
    all_claude_eval = [json.loads(l) for l in open(p["cld_eval"])]
    gpt_vsim = load_vsim(p["gpt_vsim"])
    cld_vsim = filter_claude_first5(load_vsim(p["cld_vsim"]), all_claude_eval)
    gpt_traj = load_traj(p["gpt_traj"])
    cld_traj = filter_claude_first5(load_traj(p["cld_traj"]), all_claude_eval)

    print(f"Model: {model}")
    print(f"Loaded {len(gpt)} GPT-arm eval rows, {len(cld)} Claude-arm eval rows")
    print(f"       {len(gpt_vsim)} GPT-arm vsim rows, {len(cld_vsim)} Claude-arm vsim rows")
    print(f"       {len(gpt_traj)} GPT-arm traj rows, {len(cld_traj)} Claude-arm traj rows")
    print()

    sg = summarize(gpt, "gpt")
    sc = summarize(cld, "claude")

    # Overall table
    print("=" * 78)
    print(f"QWEN3-VL-30B-A3B: overall  |  GPT-arm (N={sg['n_samples']}) vs Claude-arm (N={sc['n_samples']})")
    print("=" * 78)
    fmt = f"{{:<32}} {{:>12}} {{:>12}} {{:>12}}"
    print(fmt.format("Metric", "GPT arm", "Claude arm", "Δ (G−C)"))
    print("-" * 78)
    for label, gk, ck, kind in [
        ("Runnability — syntax ok",   sg["syntax_ok_pct"], sc["syntax_ok_pct"], "pct"),
        ("Runnability — runs ok",     sg["runs_ok_pct"],   sc["runs_ok_pct"],   "pct"),
        ("Runnability — video ok",    sg["video_ok_pct"],  sc["video_ok_pct"],  "pct"),
        ("CodeBLEU (mean)",           sg["codebleu"],      sc["codebleu"],      "num"),
        # Sub-scores mirror paper Table 2 layout: name/statement/formula/overall
        ("Law-equivalence: name (avg)",      sg["law_eq_name_avg"],      sc["law_eq_name_avg"],      "num"),
        ("Law-equivalence: statement (avg)", sg["law_eq_statement_avg"], sc["law_eq_statement_avg"], "num"),
        ("Law-equivalence: formula (avg)",   sg["law_eq_formula_avg"],   sc["law_eq_formula_avg"],   "num"),
        ("Law-equivalence: overall (avg)",   sg["law_eq_overall_avg"],   sc["law_eq_overall_avg"],   "num"),
        ("  ↳ gpt-5-nano (overall)",         sg["law_eq_gpt5nano"],     sc["law_eq_gpt5nano"],     "num"),
        ("  ↳ gemini-flash (overall)",       sg["law_eq_gemini_flash"], sc["law_eq_gemini_flash"], "num"),
        ("  ↳ grok-fast (overall)",          sg["law_eq_grok_fast"],    sc["law_eq_grok_fast"],    "num"),
        ("Law-validity: name (avg)",         sg["law_va_name_avg"],      sc["law_va_name_avg"],      "num"),
        ("Law-validity: statement (avg)",    sg["law_va_statement_avg"], sc["law_va_statement_avg"], "num"),
        ("Law-validity: formula (avg)",      sg["law_va_formula_avg"],   sc["law_va_formula_avg"],   "num"),
        ("Law-validity: overall (avg)",      sg["law_va_overall_avg"],   sc["law_va_overall_avg"],   "num"),
        ("  ↳ gpt-5-nano (overall)",         sg["law_va_gpt5nano"],     sc["law_va_gpt5nano"],     "num"),
        ("  ↳ gemini-flash (overall)",       sg["law_va_gemini_flash"], sc["law_va_gemini_flash"], "num"),
        ("  ↳ grok-fast (overall)",          sg["law_va_grok_fast"],    sc["law_va_grok_fast"],    "num"),
        # Video similarity
        ("DINOv2 cosine (mean)",             st.mean([r["dino"] for r in gpt_vsim if r["dino"] is not None])   if gpt_vsim else float("nan"),
                                              st.mean([r["dino"] for r in cld_vsim if r["dino"] is not None])   if cld_vsim else float("nan"), "num"),
        ("X-CLIP cosine (mean)",             st.mean([r["xclip"] for r in gpt_vsim if r["xclip"] is not None]) if gpt_vsim else float("nan"),
                                              st.mean([r["xclip"] for r in cld_vsim if r["xclip"] is not None]) if cld_vsim else float("nan"), "num"),
        ("CoTracker coverage (mean)",        st.mean([r["coverage"] for r in gpt_traj if r["coverage"] is not None]) if gpt_traj else float("nan"),
                                              st.mean([r["coverage"] for r in cld_traj if r["coverage"] is not None]) if cld_traj else float("nan"), "num"),
        ("CoTracker fidelity (mean)",        st.mean([r["fidelity"] for r in gpt_traj if r["fidelity"] is not None]) if gpt_traj else float("nan"),
                                              st.mean([r["fidelity"] for r in cld_traj if r["fidelity"] is not None]) if cld_traj else float("nan"), "num"),
        ("CoTracker physics_score (mean)",   st.mean([r["physics_score"] for r in gpt_traj if r["physics_score"] is not None]) if gpt_traj else float("nan"),
                                              st.mean([r["physics_score"] for r in cld_traj if r["physics_score"] is not None]) if cld_traj else float("nan"), "num"),
    ]:
        if kind == "pct":
            g_s, c_s = format_pct(gk), format_pct(ck)
            d = gk - ck if (gk == gk and ck == ck) else float("nan")
            d_s = f"{d:+6.1f}pp" if d == d else "  --  "
        else:
            g_s, c_s = format_num(gk), format_num(ck)
            d = gk - ck if (gk == gk and ck == ck) else float("nan")
            d_s = f"{d:+6.3f}" if d == d else "  --  "
        print(fmt.format(label, g_s, c_s, d_s))

    # Per-experiment table
    per_exp = per_experiment_breakdown(gpt, cld)
    print()
    print("=" * 90)
    print("Per-experiment breakdown (runs_ok% and law-eq avg-of-3 judges)")
    print("=" * 90)
    hdr = f"{{:<30}} {{:>10}} {{:>10}} {{:>8}} {{:>10}} {{:>10}} {{:>8}}"
    print(hdr.format("experiment (Claude parent)", "runs G", "runs C", "Δ", "lawEq G", "lawEq C", "Δ"))
    print("-" * 90)
    for row in per_exp:
        g, c = row["gpt"], row["claude"]
        d_run = g["runs_ok_pct"] - c["runs_ok_pct"] if (g["runs_ok_pct"] == g["runs_ok_pct"] and c["runs_ok_pct"] == c["runs_ok_pct"]) else float("nan")
        d_leq = g["law_eq_avg"] - c["law_eq_avg"] if (g["law_eq_avg"] == g["law_eq_avg"] and c["law_eq_avg"] == c["law_eq_avg"]) else float("nan")
        print(hdr.format(
            row["experiment"][:30],
            format_pct(g["runs_ok_pct"]),
            format_pct(c["runs_ok_pct"]),
            f"{d_run:+5.1f}pp" if d_run == d_run else "  --",
            format_num(g["law_eq_avg"], 6, 2),
            format_num(c["law_eq_avg"], 6, 2),
            f"{d_leq:+5.2f}" if d_leq == d_leq else "  --",
        ))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="qwen3vl_30b_a3b",
                    help="single-model detailed comparison")
    ap.add_argument("--all", action="store_true",
                    help="cross-model summary tables for all 8 rebuttal models")
    args = ap.parse_args()
    if args.all:
        print_all_models_summary(REBUTTAL_MODELS)
    else:
        main_single(args.model)


if __name__ == "__main__":
    main()
