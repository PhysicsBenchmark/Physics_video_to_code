#!/usr/bin/env python3
"""Prepare a non-destructive, normalized GPT rebuttal GT benchmark root.

This script performs the four pre-evaluation cleanup steps requested for the
GPT-generated scipygpt arm:
  1. Audit every GT script for syntax, execution, MP4 creation, and finite params.
  2. Strip comments/docstrings from GT simulation_code.py in a derived copy.
  3. Normalize CoT equation/law surface forms into LaTeX/Python-style notation.
  4. Preserve OG-style parameter keys in GT files; write canonical aliases as sidecars.

Raw inputs are never modified. Each run writes to a fresh timestamped directory
under rebuttal_artifacts/prep_runs/ by default.
"""
from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import io
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import tokenize
import unicodedata
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional

REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_MANIFEST = Path(
    "/scr/sourajak/physics_video/physics_sim_dataset/benchmarking_data_rebuttal/manifest.csv"
)
DEFAULT_INTERPRETER = Path("/scr/adityag6/conda_envs/phys_eval/bin/python")
if not DEFAULT_INTERPRETER.exists():
    DEFAULT_INTERPRETER = Path(sys.executable)

STDOUT_TAIL_BYTES = 1200
STDERR_TAIL_BYTES = 2500

GREEK_ASCII = {
    "α": "alpha", "β": "beta", "γ": "gamma", "δ": "delta",
    "ε": "epsilon", "ζ": "zeta", "η": "eta", "θ": "theta",
    "ι": "iota", "κ": "kappa", "λ": "lambda", "μ": "mu",
    "ν": "nu", "ξ": "xi", "π": "pi", "ρ": "rho",
    "σ": "sigma", "τ": "tau", "υ": "upsilon", "φ": "phi",
    "χ": "chi", "ψ": "psi", "ω": "omega",
    "Α": "alpha", "Β": "beta", "Γ": "gamma", "Δ": "delta",
    "Θ": "theta", "Λ": "lambda", "Π": "pi", "Σ": "sigma",
    "Φ": "phi", "Ω": "omega",
}
OG_GREEK_ASCII = {
    "α": "alpha", "β": "beta", "γ": "gamma", "δ": "delta",
    "ε": "epsilon", "ζ": "zeta", "η": "eta", "θ": "theta",
    "ι": "iota", "κ": "kappa", "λ": "lambda", "μ": "mu",
    "ν": "nu", "ξ": "xi", "π": "pi", "ρ": "rho",
    "σ": "sigma", "τ": "tau", "υ": "upsilon", "φ": "phi",
    "χ": "chi", "ψ": "psi", "ω": "omega",
    "Α": "Alpha", "Β": "Beta", "Γ": "Gamma", "Δ": "Delta",
    "Θ": "Theta", "Λ": "Lambda", "Π": "Pi", "Σ": "Sigma",
    "Φ": "Phi", "Ω": "Omega",
}
GREEK_LATEX = {
    "alpha": r"\alpha", "beta": r"\beta", "gamma": r"\gamma",
    "delta": r"\delta", "epsilon": r"\epsilon", "zeta": r"\zeta",
    "eta": r"\eta", "theta": r"\theta", "iota": r"\iota",
    "kappa": r"\kappa", "lambda": r"\lambda", "mu": r"\mu",
    "nu": r"\nu", "xi": r"\xi", "pi": r"\pi", "rho": r"\rho",
    "sigma": r"\sigma", "tau": r"\tau", "upsilon": r"\upsilon",
    "phi": r"\phi", "chi": r"\chi", "psi": r"\psi", "omega": r"\omega",
}
SUBSCRIPT_ASCII = {
    "₀": "0", "₁": "1", "₂": "2", "₃": "3", "₄": "4",
    "₅": "5", "₆": "6", "₇": "7", "₈": "8", "₉": "9",
}
SUPERSCRIPT_ASCII = {
    "⁰": "0", "¹": "1", "²": "2", "³": "3", "⁴": "4",
    "⁵": "5", "⁶": "6", "⁷": "7", "⁸": "8", "⁹": "9",
}
COMBINING_MARKS = {"̇": "_dot", "̈": "_ddot"}

LATEX_FALLBACK = {
    "−": "-", "·": " \\cdot ", "×": " \\times ", "÷": " / ",
    "±": " \\pm ", "≤": " \\le ", "≥": " \\ge ", "≠": " \\ne ",
    "≈": " \\approx ", "→": " \\to ", "∞": " \\infty ",
    "√": " \\sqrt ", "°": "^{\\circ}",
    "—": "---", "–": "--", "…": "...", "“": '"', "”": '"',
    "‘": "'", "’": "'",
}
PY_FALLBACK = {
    "−": "-", "·": " * ", "×": " * ", "÷": " / ", "≤": " <= ",
    "≥": " >= ", "≠": " != ", "≈": " ~= ", "∞": "float('inf')",
    "√": "np.sqrt", "°": "*np.pi/180",
    "—": "---", "–": "--", "…": "...", "“": '"', "”": '"',
    "‘": "'", "’": "'",
}
MATH_FUNCS = ("sin", "cos", "tan", "sqrt", "exp", "log", "ln")


def utc_run_id() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_utc")


def dump_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as f:
        for row in rows:
            f.write(json.dumps(row, sort_keys=True) + "\n")


def sha256_file(path: Path) -> Optional[str]:
    if not path.exists() or not path.is_file():
        return None
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def read_manifest(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open(newline="") as f:
        reader = csv.DictReader(f)
        return list(reader.fieldnames or []), list(reader)


def write_manifest(path: Path, fieldnames: list[str], rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k, "") for k in fieldnames})


def count_non_ascii(obj: Any) -> int:
    if isinstance(obj, str):
        return sum(1 for ch in obj if ord(ch) > 127)
    if isinstance(obj, dict):
        return sum(count_non_ascii(k) + count_non_ascii(v) for k, v in obj.items())
    if isinstance(obj, list):
        return sum(count_non_ascii(v) for v in obj)
    return 0


def finite_issues(obj: Any, path: str = "$", max_issues: int = 50) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []

    def walk(value: Any, loc: str) -> None:
        if len(issues) >= max_issues:
            return
        if isinstance(value, bool) or value is None:
            return
        if isinstance(value, (int, float)):
            if not math.isfinite(float(value)):
                issues.append({"path": loc, "value": repr(value)})
            return
        if isinstance(value, dict):
            for k, v in value.items():
                walk(v, f"{loc}.{k}")
            return
        if isinstance(value, list):
            for i, v in enumerate(value):
                walk(v, f"{loc}[{i}]")

    walk(obj, path)
    return issues


def og_ascii_param_name(name: Any) -> str:
    """Match the original scipy CoT key cleanup: unicode symbols only.

    This intentionally preserves casing, underscores, and trailing digits, e.g.
    `L_0`, `R_pole`, `theta0`, and `cart_x0` remain in the same style.
    """
    norm = unicodedata.normalize("NFD", str(name))
    out: list[str] = []
    for ch in norm:
        if ch in OG_GREEK_ASCII:
            out.append(OG_GREEK_ASCII[ch])
        elif ch in SUBSCRIPT_ASCII:
            out.append(SUBSCRIPT_ASCII[ch])
        elif ch in COMBINING_MARKS:
            out.append(COMBINING_MARKS[ch])
        elif unicodedata.category(ch).startswith("M"):
            continue
        else:
            out.append(ch)
    return "".join(out)


def canonical_param_name(name: Any) -> str:
    """Aggressive snake_case alias used only in sidecars/logs, not GT keys."""
    raw = str(name)
    norm = unicodedata.normalize("NFD", raw)
    parts: list[str] = []
    for ch in norm:
        if ch in GREEK_ASCII:
            parts.append("_" + GREEK_ASCII[ch] + "_")
        elif ch in SUBSCRIPT_ASCII:
            parts.append("_" + SUBSCRIPT_ASCII[ch])
        elif ch in SUPERSCRIPT_ASCII:
            parts.append("_pow_" + SUPERSCRIPT_ASCII[ch])
        elif ch in COMBINING_MARKS:
            parts.append(COMBINING_MARKS[ch])
        elif unicodedata.category(ch).startswith("M"):
            continue
        else:
            parts.append(ch)
    s = "".join(parts)
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s)
    s = s.lower()
    s = re.sub(r"[^a-z0-9]+", "_", s)
    s = re.sub(r"([a-z])([0-9]+)(?=$|_)", r"\1_\2", s)
    s = re.sub(r"_+", "_", s).strip("_")
    if not s:
        s = "param"
    if s[0].isdigit():
        s = "p_" + s
    return s


def normalize_keyed_mapping(
    mapping: dict[str, Any],
    *,
    stored_key_fn: Callable[[Any], str] = og_ascii_param_name,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    out: dict[str, Any] = {}
    logs: list[dict[str, Any]] = []
    used: dict[str, int] = {}
    for original, value in mapping.items():
        stored = stored_key_fn(original)
        canonical_alias = canonical_param_name(original)
        stored_collision = False
        if stored in out:
            stored_collision = True
            used[stored] = used.get(stored, 0) + 1
            stored = f"{stored}__dup{used[stored]}"
        else:
            used.setdefault(stored, 0)
        out[stored] = value
        logs.append({
            "original": str(original),
            "stored": stored,
            "canonical_alias": canonical_alias,
            "changed": str(original) != stored,
            "stored_key_changed": str(original) != stored,
            "canonical_alias_changed": str(original) != canonical_alias,
            "collision": stored_collision,
        })
    return out, logs


def latexize_ascii_math_text(s: Any) -> tuple[Any, int]:
    if not isinstance(s, str) or not s:
        return s, 0
    original = s
    text = s
    rewrites = 0

    def sub_literal(pattern: str, repl: str) -> None:
        nonlocal text, rewrites
        text, n = re.subn(pattern, lambda _m: repl, text)
        rewrites += n

    def sub_func(pattern: str, repl_fn: Callable[[re.Match[str]], str]) -> None:
        nonlocal text, rewrites
        text, n = re.subn(pattern, repl_fn, text)
        rewrites += n

    for fn in ("sin", "cos", "tan", "sinh", "cosh", "tanh", "sqrt", "exp", "log"):
        sub_literal(rf"(?<!\\)\b{fn}\s*\(", rf"\{fn}(")
    sub_literal(r"(?<!\\)\bln\s*\(", r"\log(")

    # Dot/ddot forms before bare Greek replacement: theta_ddot -> \ddot{\theta}.
    for name, latex in sorted(GREEK_LATEX.items(), key=lambda kv: -len(kv[0])):
        sub_literal(rf"(?<!\\)\b{name}_ddot\b", rf"\ddot{{{latex}}}")
        sub_literal(rf"(?<!\\)\b{name}_dot\b", rf"\dot{{{latex}}}")
        sub_func(rf"(?<!\\)\b{name}([0-9]+)\b", lambda m, latex=latex: f"{latex}_{{{m.group(1)}}}")
        sub_literal(rf"(?<!\\)\b{name}\b", latex)

    return text, rewrites if text != original else 0


def latexize_ascii_math_value(value: Any, path: tuple[str, ...] = ()) -> tuple[Any, int]:
    if path[-1:] == ("equations_python",):
        return value, 0
    if isinstance(value, str):
        return latexize_ascii_math_text(value)
    if isinstance(value, list):
        out = []
        total = 0
        for item in value:
            new_item, n = latexize_ascii_math_value(item, path)
            out.append(new_item)
            total += n
        return out, total
    if isinstance(value, dict):
        out = {}
        total = 0
        for k, v in value.items():
            new_v, n = latexize_ascii_math_value(v, path + (str(k),))
            out[k] = new_v
            total += n
        return out, total
    return value, 0


def fallback_unicode_to_latex(s: Any) -> Any:
    if not isinstance(s, str):
        return s
    s = unicodedata.normalize("NFD", s)
    out: list[str] = []
    for ch in s:
        if ch in GREEK_ASCII:
            out.append("\\" + GREEK_ASCII[ch])
        elif ch in SUBSCRIPT_ASCII:
            out.append("_" + SUBSCRIPT_ASCII[ch])
        elif ch in SUPERSCRIPT_ASCII:
            out.append("^" + SUPERSCRIPT_ASCII[ch])
        elif ch in COMBINING_MARKS:
            out.append(COMBINING_MARKS[ch].replace("_", "\\"))
        elif ch in LATEX_FALLBACK:
            out.append(LATEX_FALLBACK[ch])
        elif unicodedata.category(ch).startswith("M"):
            continue
        else:
            out.append(ch)
    text = "".join(out)
    for fn in MATH_FUNCS:
        text = re.sub(rf"(?<![\\A-Za-z]){fn}(?![A-Za-z])", rf"\\{fn}", text)
    return text


def fallback_unicode_to_python(s: Any) -> Any:
    if not isinstance(s, str):
        return s
    s = unicodedata.normalize("NFD", s)
    out: list[str] = []
    for ch in s:
        if ch in GREEK_ASCII:
            out.append(GREEK_ASCII[ch])
        elif ch in SUBSCRIPT_ASCII:
            out.append(SUBSCRIPT_ASCII[ch])
        elif ch in SUPERSCRIPT_ASCII:
            out.append("**" + SUPERSCRIPT_ASCII[ch])
        elif ch in COMBINING_MARKS:
            out.append(COMBINING_MARKS[ch])
        elif ch in PY_FALLBACK:
            out.append(PY_FALLBACK[ch])
        elif unicodedata.category(ch).startswith("M"):
            continue
        else:
            out.append(ch)
    text = "".join(out)
    for fn in MATH_FUNCS:
        repl = "np.log" if fn == "ln" else f"np.{fn}"
        text = re.sub(rf"(?<!np\.)(?<!\.)\b{fn}\b", repl, text)
    return text


def fallback_walk_latex(value: Any) -> Any:
    if isinstance(value, str):
        return fallback_unicode_to_latex(value)
    if isinstance(value, list):
        return [fallback_walk_latex(v) for v in value]
    if isinstance(value, dict):
        return {
            fallback_unicode_to_latex(k) if isinstance(k, str) else k: fallback_walk_latex(v)
            for k, v in value.items()
        }
    return value


def fallback_transform_cot(cot: dict[str, Any]) -> dict[str, Any]:
    cot = json.loads(json.dumps(cot))
    ode = cot.get("ode_system")
    if isinstance(ode, dict) and "equations" in ode:
        equations = ode.pop("equations")
        if isinstance(equations, list):
            ode["equations_latex"] = [fallback_unicode_to_latex(e) for e in equations]
            ode["equations_python"] = [fallback_unicode_to_python(e) for e in equations]
    py_eqs = None
    if isinstance(cot.get("ode_system"), dict) and "equations_python" in cot["ode_system"]:
        py_eqs = cot["ode_system"].pop("equations_python")
    cot = fallback_walk_latex(cot)
    if py_eqs is not None:
        cot.setdefault("ode_system", {})["equations_python"] = py_eqs
    return cot


def load_cot_transformer() -> tuple[Callable[[dict[str, Any]], dict[str, Any]], str]:
    sys.path.insert(0, str(REPO_ROOT))
    try:
        from cot_generator_scipy import _transform_cot_equations  # type: ignore
        return _transform_cot_equations, "cot_generator_scipy._transform_cot_equations"
    except Exception as exc:
        return fallback_transform_cot, f"fallback_transform_cot ({type(exc).__name__}: {exc})"


def strip_comments_only(source: str) -> tuple[str, int]:
    comments_removed = 0
    out_tokens = []
    try:
        for tok in tokenize.generate_tokens(io.StringIO(source).readline):
            if tok.type == tokenize.COMMENT:
                comments_removed += 1
                continue
            out_tokens.append(tok)
        return tokenize.untokenize(out_tokens), comments_removed
    except tokenize.TokenError:
        return source, comments_removed


def docstring_ranges(tree: ast.AST) -> list[tuple[int, int]]:
    ranges: list[tuple[int, int]] = []

    def maybe_add(body: list[ast.stmt]) -> None:
        if not body:
            return
        first = body[0]
        if isinstance(first, ast.Expr) and isinstance(getattr(first, "value", None), ast.Constant):
            if isinstance(first.value.value, str):
                start = getattr(first, "lineno", None)
                end = getattr(first, "end_lineno", start)
                if start is not None and end is not None:
                    ranges.append((int(start), int(end)))

    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            maybe_add(node.body)  # type: ignore[arg-type]
    return sorted(set(ranges), reverse=True)


def blank_docstring_lines(source: str) -> tuple[str, int]:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return source, 0
    ranges = docstring_ranges(tree)
    if not ranges:
        return source, 0
    lines = source.splitlines(keepends=True)
    for start, end in ranges:
        for idx in range(start - 1, end):
            if 0 <= idx < len(lines):
                newline = "\n" if lines[idx].endswith("\n") else ""
                lines[idx] = newline
    return "".join(lines), len(ranges)


def strip_comments_and_docstrings(source: str) -> tuple[str, dict[str, Any]]:
    commentless, comments_removed = strip_comments_only(source)
    docless, docstrings_removed = blank_docstring_lines(commentless)
    chosen = docless
    fallback = None
    try:
        ast.parse(chosen)
        syntax_ok = True
    except SyntaxError as exc:
        fallback = f"docstring_strip_syntax_error: {exc.msg} line {exc.lineno}"
        chosen = commentless
        try:
            ast.parse(chosen)
            syntax_ok = True
        except SyntaxError as exc2:
            fallback = f"comment_strip_syntax_error: {exc2.msg} line {exc2.lineno}"
            chosen = source
            syntax_ok = False
    return chosen, {
        "comments_removed": comments_removed,
        "docstrings_removed": docstrings_removed,
        "syntax_ok_after_strip": syntax_ok,
        "fallback": fallback,
        "changed": chosen != source,
        "raw_sha256": sha256_text(source),
        "normalized_sha256": sha256_text(chosen),
    }


def tail_bytes(data: bytes, max_bytes: int) -> str:
    return data[-max_bytes:].decode(errors="replace") if data else ""


def probe_video(path: Path) -> dict[str, Any]:
    out: dict[str, Any] = {
        "exists": path.exists(),
        "bytes": path.stat().st_size if path.exists() else -1,
        "ffprobe_ok": None,
        "duration_s": None,
        "nb_frames": None,
    }
    ffprobe = shutil.which("ffprobe")
    if not path.exists() or not ffprobe:
        return out
    cmd = [
        ffprobe, "-v", "error", "-select_streams", "v:0",
        "-show_entries", "stream=duration,nb_frames", "-of", "json", str(path),
    ]
    try:
        cp = subprocess.run(cmd, timeout=20, capture_output=True, text=True)
        out["ffprobe_ok"] = cp.returncode == 0
        if cp.returncode == 0:
            info = json.loads(cp.stdout or "{}")
            streams = info.get("streams") or []
            if streams:
                stream = streams[0]
                dur = stream.get("duration")
                frames = stream.get("nb_frames")
                out["duration_s"] = float(dur) if dur not in (None, "N/A") else None
                out["nb_frames"] = int(frames) if frames not in (None, "N/A") else None
        else:
            out["ffprobe_error"] = tail_bytes(cp.stderr.encode(), 500)
    except Exception as exc:
        out["ffprobe_ok"] = False
        out["ffprobe_error"] = f"{type(exc).__name__}: {exc}"
    return out


def audit_one(row: dict[str, str], interpreter: Path, timeout_s: float) -> dict[str, Any]:
    engine = row.get("engine", "")
    experiment = row.get("experiment", "")
    sample_id = row.get("sample_id", "")
    src_dir = Path(row.get("original_path", ""))
    video_src = Path(row.get("video_path", ""))
    code_path = src_dir / "simulation_code.py"
    cot_path = src_dir / "cot.json"
    params_path = src_dir / "params.json"

    audit: dict[str, Any] = {
        "engine": engine,
        "experiment": experiment,
        "sample_id": sample_id,
        "source_dir": str(src_dir),
        "source_video": str(video_src),
        "code_path": str(code_path),
        "cot_path": str(cot_path),
        "params_path": str(params_path),
        "source_video_probe": probe_video(video_src),
        "code_sha256": sha256_file(code_path),
        "cot_sha256": sha256_file(cot_path),
        "params_sha256": sha256_file(params_path),
        "syntax_ok": False,
        "params_finite": False,
        "run_exit_code": None,
        "run_wall_time_s": None,
        "run_timed_out": False,
        "run_video_probe": None,
        "stdout_tail": "",
        "stderr_tail": "",
        "audit_pass": False,
        "fail_reasons": [],
    }

    missing = [str(p) for p in (code_path, cot_path, params_path) if not p.exists()]
    if missing:
        audit["fail_reasons"].append("missing_source_files")
        audit["missing_files"] = missing
        return audit
    if not video_src.exists() or video_src.stat().st_size <= 0:
        audit["fail_reasons"].append("missing_or_empty_source_video")

    try:
        code = code_path.read_text()
        ast.parse(code)
        audit["syntax_ok"] = True
    except Exception as exc:
        audit["syntax_error"] = f"{type(exc).__name__}: {exc}"
        audit["fail_reasons"].append("syntax_error")
        return audit

    try:
        params = json.loads(params_path.read_text())
        issues = finite_issues(params)
        audit["params_finite"] = not issues
        audit["params_finite_issues"] = issues
        if issues:
            audit["fail_reasons"].append("nonfinite_params")
    except Exception as exc:
        audit["params_error"] = f"{type(exc).__name__}: {exc}"
        audit["fail_reasons"].append("params_json_error")

    env = os.environ.copy()
    env.setdefault("MPLBACKEND", "Agg")
    with tempfile.TemporaryDirectory(prefix="gt_audit_") as tmp:
        tmp_path = Path(tmp)
        script_path = tmp_path / "simulation_code.py"
        script_path.write_text(code)
        t0 = time.time()
        try:
            cp = subprocess.run(
                [str(interpreter), "simulation_code.py"],
                cwd=tmp_path,
                timeout=timeout_s,
                capture_output=True,
                env=env,
            )
            audit["run_exit_code"] = cp.returncode
            audit["stdout_tail"] = tail_bytes(cp.stdout, STDOUT_TAIL_BYTES)
            audit["stderr_tail"] = tail_bytes(cp.stderr, STDERR_TAIL_BYTES)
        except subprocess.TimeoutExpired as exc:
            audit["run_timed_out"] = True
            audit["run_exit_code"] = -1
            audit["stdout_tail"] = tail_bytes(exc.stdout or b"", STDOUT_TAIL_BYTES)
            audit["stderr_tail"] = tail_bytes(exc.stderr or b"", STDERR_TAIL_BYTES)
            audit["fail_reasons"].append("run_timeout")
        except Exception as exc:
            audit["run_exit_code"] = -2
            audit["spawn_error"] = f"{type(exc).__name__}: {exc}"
            audit["fail_reasons"].append("spawn_error")
        audit["run_wall_time_s"] = time.time() - t0
        generated_video = tmp_path / "video.mp4"
        audit["run_video_probe"] = probe_video(generated_video)

    run_ok = audit["run_exit_code"] == 0 and not audit["run_timed_out"]
    run_video_ok = bool((audit.get("run_video_probe") or {}).get("bytes", -1) > 0)
    if not run_ok:
        audit["fail_reasons"].append("run_failed")
    if not run_video_ok:
        audit["fail_reasons"].append("no_generated_video")
    if re.search(r"\bnan\b", (audit["stdout_tail"] + audit["stderr_tail"]).lower()):
        audit["fail_reasons"].append("runtime_nan_text")
    if re.search(r"\binf\b", (audit["stdout_tail"] + audit["stderr_tail"]).lower()):
        audit["fail_reasons"].append("runtime_inf_text")

    audit["fail_reasons"] = sorted(set(audit["fail_reasons"]))
    audit["audit_pass"] = (
        audit["syntax_ok"]
        and audit["params_finite"]
        and run_ok
        and run_video_ok
        and bool(audit["source_video_probe"].get("bytes", -1) > 0)
        and not any(r in audit["fail_reasons"] for r in ("runtime_nan_text", "runtime_inf_text"))
    )
    return audit


def copy_video(src: Path, dst: Path, mode: str) -> str:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        raise FileExistsError(dst)
    if mode == "symlink":
        dst.symlink_to(src)
        return "symlink"
    if mode == "hardlink":
        try:
            os.link(src, dst)
            return "hardlink"
        except OSError:
            shutil.copy2(src, dst)
            return "copy_fallback"
    shutil.copy2(src, dst)
    return "copy"


def prepare_sample(
    row: dict[str, str],
    audit: dict[str, Any],
    normalized_root: Path,
    transform_cot: Callable[[dict[str, Any]], dict[str, Any]],
    transform_source: str,
    video_mode: str,
) -> tuple[dict[str, str], dict[str, Any], dict[str, Any], list[dict[str, Any]]]:
    src_dir = Path(row["original_path"])
    dest_dir = normalized_root / row["engine"] / row["experiment"] / row["sample_id"]
    dest_dir.mkdir(parents=True, exist_ok=False)

    code_raw = (src_dir / "simulation_code.py").read_text()
    code_clean, code_log = strip_comments_and_docstrings(code_raw)
    (dest_dir / "simulation_code.py").write_text(code_clean)

    cot_raw = json.loads((src_dir / "cot.json").read_text())
    cot_before_non_ascii = count_non_ascii(cot_raw)
    cot_normalized = transform_cot(json.loads(json.dumps(cot_raw)))
    cot_normalized, ascii_math_rewrites = latexize_ascii_math_value(cot_normalized)
    cot_param_logs: list[dict[str, Any]] = []
    if isinstance(cot_normalized.get("parameters"), dict):
        cot_params, cot_param_logs = normalize_keyed_mapping(cot_normalized["parameters"])
        cot_normalized["parameters"] = cot_params
    cot_after_non_ascii = count_non_ascii(cot_normalized)
    dump_json(dest_dir / "cot.json", cot_normalized)
    dump_json(dest_dir / "cot_raw.json", cot_raw)

    params_raw = json.loads((src_dir / "params.json").read_text())
    params_normalized, param_logs = normalize_keyed_mapping(params_raw) if isinstance(params_raw, dict) else (params_raw, [])
    dump_json(dest_dir / "params.json", params_normalized)
    dump_json(dest_dir / "params_raw.json", params_raw)
    dump_json(dest_dir / "param_name_map.json", {
        "sample": {"engine": row["engine"], "experiment": row["experiment"], "sample_id": row["sample_id"]},
        "params_json": param_logs,
        "cot_parameters": cot_param_logs,
    })

    video_method = copy_video(Path(row["video_path"]), dest_dir / "video.mp4", video_mode)
    dump_json(dest_dir / "source_paths.json", {
        "manifest_original_path": row.get("original_path"),
        "manifest_video_path": row.get("video_path"),
        "video_copy_method": video_method,
        "audit_pass": audit.get("audit_pass"),
    })

    manifest_row = dict(row)
    manifest_row["original_path"] = str(dest_dir)
    manifest_row["video_path"] = str(dest_dir / "video.mp4")

    code_log = {
        **code_log,
        "engine": row["engine"],
        "experiment": row["experiment"],
        "sample_id": row["sample_id"],
        "source_path": str(src_dir / "simulation_code.py"),
        "normalized_path": str(dest_dir / "simulation_code.py"),
    }
    cot_log = {
        "engine": row["engine"],
        "experiment": row["experiment"],
        "sample_id": row["sample_id"],
        "transform_source": transform_source,
        "non_ascii_before": cot_before_non_ascii,
        "non_ascii_after": cot_after_non_ascii,
        "ascii_math_rewrites": ascii_math_rewrites,
        "parameters_stored_key_changed": sum(1 for x in cot_param_logs if x["stored_key_changed"]),
        "parameters_canonical_alias_changed": sum(1 for x in cot_param_logs if x["canonical_alias_changed"]),
        "source_path": str(src_dir / "cot.json"),
        "normalized_path": str(dest_dir / "cot.json"),
    }
    param_logs_enriched = []
    for entry in param_logs:
        param_logs_enriched.append({
            **entry,
            "engine": row["engine"],
            "experiment": row["experiment"],
            "sample_id": row["sample_id"],
            "source": "params.json",
        })
    for entry in cot_param_logs:
        param_logs_enriched.append({
            **entry,
            "engine": row["engine"],
            "experiment": row["experiment"],
            "sample_id": row["sample_id"],
            "source": "cot.parameters",
        })
    return manifest_row, code_log, cot_log, param_logs_enriched


def write_review_checklist(path: Path, manifest_rows: list[dict[str, str]]) -> None:
    first_by_experiment: dict[str, dict[str, str]] = {}
    for row in manifest_rows:
        first_by_experiment.setdefault(row["experiment"], row)
    lines = [
        "# Rebuttal GT Sample Video Review Checklist",
        "",
        "One valid sample per experiment, selected mechanically from the cleaned manifest.",
        "Mark `pending_manual_review` after eyeballing the video.",
        "",
        "| experiment | sample_id | video_path | status |",
        "| --- | ---: | --- | --- |",
    ]
    for exp, row in sorted(first_by_experiment.items()):
        lines.append(
            f"| {exp} | {row['sample_id']} | `{row['video_path']}` | pending_manual_review |"
        )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n")


def fail_reason_counts(audits: list[dict[str, Any]]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for audit in audits:
        for reason in audit.get("fail_reasons", []):
            counts[reason] = counts.get(reason, 0) + 1
    return dict(sorted(counts.items()))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    ap.add_argument("--out_root", type=Path, default=REPO_ROOT / "rebuttal_artifacts")
    ap.add_argument("--run_id", default=None,
                    help="optional run id; must not already exist")
    ap.add_argument("--interpreter", type=Path, default=DEFAULT_INTERPRETER)
    ap.add_argument("--timeout", type=float, default=120.0)
    ap.add_argument("--audit_workers", type=int, default=4)
    ap.add_argument("--video_mode", choices=["hardlink", "copy", "symlink"], default="hardlink")
    ap.add_argument("--skip_audit", action="store_true",
                    help="copy/normalize every manifest row without executing GT code")
    args = ap.parse_args()

    fieldnames, manifest_rows = read_manifest(args.manifest)
    run_id = args.run_id or (utc_run_id() + "_gt_cleanup")
    run_dir = args.out_root / "prep_runs" / run_id
    run_dir.mkdir(parents=True, exist_ok=False)

    normalized_root = run_dir / "normalized_benchmarking_data"
    audit_dir = run_dir / "gt_audit"
    log_dir = run_dir / "normalization_logs"
    config_dir = run_dir / "config"

    shutil.copy2(args.manifest, run_dir / "raw_manifest_snapshot.csv")
    transform_cot, transform_source = load_cot_transformer()

    audits: list[dict[str, Any]] = []
    if args.skip_audit:
        for row in manifest_rows:
            audits.append({
                "engine": row.get("engine", ""),
                "experiment": row.get("experiment", ""),
                "sample_id": row.get("sample_id", ""),
                "audit_pass": True,
                "fail_reasons": [],
                "audit_skipped": True,
            })
    else:
        with ThreadPoolExecutor(max_workers=max(1, args.audit_workers)) as pool:
            futs = [pool.submit(audit_one, row, args.interpreter, args.timeout) for row in manifest_rows]
            for i, fut in enumerate(as_completed(futs), 1):
                audit = fut.result()
                audits.append(audit)
                status = "PASS" if audit.get("audit_pass") else "FAIL"
                print(f"[{i:03d}/{len(futs):03d}] {status} {audit['engine']}/{audit['experiment']}/{audit['sample_id']}")
    audits.sort(key=lambda r: (r.get("engine", ""), r.get("experiment", ""), r.get("sample_id", "")))
    write_jsonl(audit_dir / "gt_audit.jsonl", audits)

    audit_by_key = {
        (a.get("engine"), a.get("experiment"), a.get("sample_id")): a
        for a in audits
    }
    valid_rows = [
        row for row in manifest_rows
        if audit_by_key.get((row.get("engine"), row.get("experiment"), row.get("sample_id")), {}).get("audit_pass")
    ]

    cleaned_manifest_rows: list[dict[str, str]] = []
    code_logs: list[dict[str, Any]] = []
    cot_logs: list[dict[str, Any]] = []
    param_logs: list[dict[str, Any]] = []
    for row in valid_rows:
        key = (row.get("engine"), row.get("experiment"), row.get("sample_id"))
        manifest_row, code_log, cot_log, param_log_rows = prepare_sample(
            row, audit_by_key[key], normalized_root, transform_cot, transform_source, args.video_mode
        )
        cleaned_manifest_rows.append(manifest_row)
        code_logs.append(code_log)
        cot_logs.append(cot_log)
        param_logs.extend(param_log_rows)

    write_manifest(normalized_root / "manifest.csv", fieldnames, cleaned_manifest_rows)
    write_manifest(config_dir / "valid_samples.csv", fieldnames, cleaned_manifest_rows)
    write_jsonl(log_dir / "code_comment_strip.jsonl", code_logs)
    write_jsonl(log_dir / "cot_normalization.jsonl", cot_logs)
    write_jsonl(log_dir / "param_name_normalization.jsonl", param_logs)
    write_review_checklist(audit_dir / "sampled_video_review.md", cleaned_manifest_rows)

    summary = {
        "run_id": run_id,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "raw_manifest": str(args.manifest),
        "raw_manifest_rows": len(manifest_rows),
        "valid_rows": len(cleaned_manifest_rows),
        "invalid_rows": len(manifest_rows) - len(cleaned_manifest_rows),
        "fail_reason_counts": fail_reason_counts(audits),
        "normalized_benchmark_root": str(normalized_root),
        "normalized_manifest": str(normalized_root / "manifest.csv"),
        "audit_jsonl": str(audit_dir / "gt_audit.jsonl"),
        "video_review_checklist": str(audit_dir / "sampled_video_review.md"),
        "cot_transform_source": transform_source,
        "interpreter": str(args.interpreter),
        "timeout_s": args.timeout,
        "audit_workers": args.audit_workers,
        "video_mode": args.video_mode,
        "param_key_policy": "og_ascii_keys_in_gt_files; snake_case aliases_sidecar_only",
    }
    dump_json(audit_dir / "gt_audit_summary.json", summary)
    dump_json(config_dir / "paths.json", summary)

    readme = f"""# Rebuttal GT Cleanup Run

Run id: `{run_id}`

Raw manifest: `{args.manifest}`

This directory is a derived, non-destructive cleanup of the GPT-generated rebuttal GT set. Raw `dataset_scipygpt` and Sourajak benchmark files were not modified.

## Outputs

- Clean benchmark root: `{normalized_root}`
- Clean manifest: `{normalized_root / 'manifest.csv'}`
- GT audit: `{audit_dir / 'gt_audit.jsonl'}`
- GT audit summary: `{audit_dir / 'gt_audit_summary.json'}`
- Comment stripping log: `{log_dir / 'code_comment_strip.jsonl'}`
- CoT normalization log: `{log_dir / 'cot_normalization.jsonl'}`
- Parameter-name normalization log: `{log_dir / 'param_name_normalization.jsonl'}`

Parameter keys in cleaned `params.json` and `cot.parameters` use OG-style ASCII cleanup only. Aggressive snake_case names are recorded as `canonical_alias` sidecars/logs, not as GT keys.
- Manual video checklist: `{audit_dir / 'sampled_video_review.md'}`

## Summary

- Raw rows: {len(manifest_rows)}
- Valid rows copied into clean root: {len(cleaned_manifest_rows)}
- Invalid rows filtered out: {len(manifest_rows) - len(cleaned_manifest_rows)}
- CoT transformer: `{transform_source}`
"""
    (run_dir / "README.md").write_text(readme)

    print("\nDONE")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
