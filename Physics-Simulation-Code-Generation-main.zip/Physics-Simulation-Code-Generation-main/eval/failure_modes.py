"""Rank the most common runtime failure modes per engine.

For each runnability row with runs_without_error=False, extract the FINAL
exception class from the stderr traceback (that's what Python raised), plus
the last non-empty stderr line as a fallback. Aggregate counts per engine
and per (engine, model) group.
"""
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path("/scr/adityag6/Physics-Simulation-Code-Generation")

OPEN = ["qwen3vl_30b_a3b", "internvl3_5_30b_a3b", "gemma_3_12b_it",
        "glm_4_1v_9b_thinking", "pixtral_12b"]
CLOSED = ["gpt_5_mini", "gemini_2_5_pro", "claude_sonnet_4_6",
          "grok_4_fast_reasoning", "nova_2_lite"]
ALL = OPEN + CLOSED

# Match "ExceptionClass: message" (last one wins — that's the raised exception)
EXC_RE = re.compile(r"^([A-Z][A-Za-z0-9_.]*(?:Error|Exception|Warning))(?::| $)",
                    re.MULTILINE)


def failure_signature(row):
    scores = row.get("scores") or {}
    if scores.get("runs_without_error"):
        return None  # success

    if scores.get("timed_out"):
        return ("timeout", None)

    if not scores.get("syntax_ok"):
        # Syntax-error path — raw_response's syntax_err has details
        raw = row.get("raw_response")
        if raw:
            try:
                obj = json.loads(raw)
                se = obj.get("syntax_err") or ""
                # Pull "SyntaxError: msg" if present
                m = re.search(r"(SyntaxError|IndentationError|TabError)", se)
                if m:
                    return ("syntax", m.group(1))
            except Exception:
                pass
        return ("syntax", "SyntaxError")

    raw = row.get("raw_response")
    if not raw:
        return ("unknown", None)
    try:
        obj = json.loads(raw)
    except Exception:
        return ("unknown", None)
    stderr = obj.get("stderr_tail") or ""
    if not stderr.strip():
        # Exited non-zero without stderr
        ec = scores.get("exit_code")
        return ("exit_nonzero", f"exit={ec}")

    exc_matches = EXC_RE.findall(stderr)
    if exc_matches:
        return ("exception", exc_matches[-1])  # last one = actually raised
    # Fallback: last non-empty stderr line
    last = [l for l in stderr.strip().splitlines() if l.strip()][-1]
    return ("stderr", last[:120])


def main():
    per_engine = defaultdict(Counter)         # engine -> Counter[(kind, detail)]
    per_engine_model = defaultdict(Counter)   # (engine, model) -> ...
    n_fail = Counter()
    n_total = Counter()

    for m in ALL:
        path = ROOT / "eval_outputs" / m / "eval_results.jsonl"
        with open(path) as f:
            for line in f:
                d = json.loads(line)
                if d.get("scorer") != "runnability" or d.get("skipped"):
                    continue
                eng = d.get("engine")
                if eng not in ("scipy", "kubric"):
                    continue
                n_total[eng] += 1
                sig = failure_signature(d)
                if sig is None:
                    continue
                n_fail[eng] += 1
                per_engine[eng][sig] += 1
                per_engine_model[(eng, m)][sig] += 1

    print("=" * 78)
    print(f"OVERALL FAILURE RATES")
    print("=" * 78)
    for eng in ("scipy", "kubric"):
        pct = 100.0 * n_fail[eng] / n_total[eng] if n_total[eng] else 0
        print(f"  {eng:<7s}: {n_fail[eng]:>5d} failures / {n_total[eng]:>5d} scored  ({pct:.1f}%)")

    for eng in ("scipy", "kubric"):
        print()
        print("=" * 78)
        print(f"TOP FAILURE MODES — {eng.upper()}")
        print("=" * 78)
        top = per_engine[eng].most_common(20)
        print(f"{'rank':>4s}  {'count':>6s}  {'%_fail':>7s}  {'kind':<12s}  {'detail'}")
        print("-" * 78)
        for i, ((kind, detail), c) in enumerate(top, 1):
            pct = 100.0 * c / n_fail[eng] if n_fail[eng] else 0
            print(f"{i:>4d}  {c:>6d}  {pct:>6.1f}%  {kind:<12s}  {detail}")

    # Per-model dominant mode
    print()
    print("=" * 78)
    print("PER-MODEL DOMINANT FAILURE MODE PER ENGINE")
    print("=" * 78)
    print(f"{'model':<28s}  {'engine':<7s}  {'top failure':<50s}  {'count'}")
    print("-" * 100)
    for m in ALL:
        for eng in ("scipy", "kubric"):
            c = per_engine_model[(eng, m)]
            if not c:
                continue
            (kind, detail), count = c.most_common(1)[0]
            print(f"{m:<28s}  {eng:<7s}  {kind + ':' + str(detail)[:44]:<50s}  {count}")


if __name__ == "__main__":
    main()
