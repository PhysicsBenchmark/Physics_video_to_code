"""Perturbation-based parameter sensitivity analysis.

For each (experiment, sample, param) where the config has a [min, max] range,
render two perturbed videos (+10% and -10% of range), compare each to the
unperturbed baseline via frame-MSE, aggregate into a per-param sensitivity
score, normalize per experiment, and tier into sensitive / moderate /
insensitive via k-means.

Outputs to /scr/adityag6/Physics-Simulation-Code-Generation/eval_outputs/_sensitivity/
"""
from __future__ import annotations
import dataclasses
import importlib
import json
import multiprocessing as mp
import os
import re
import shutil
import statistics as st
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import imageio.v3 as iio
import numpy as np
from sklearn.cluster import KMeans

ROOT = Path("/scr/adityag6/Physics-Simulation-Code-Generation")
sys.path.insert(0, str(ROOT))
CONFIG_PATH = ROOT / "configs" / "parameter_ranges_scipy.json"
BENCH = ROOT / "benchmarking_data" / "scipy"
OUT = ROOT / "eval_outputs" / "_sensitivity"
OUT.mkdir(exist_ok=True, parents=True)

PARENTS = ["ball_wrapping_pole","balls_in_basin","block_on_sphere_basin","block_strikes_spring_pair",
           "cylinder_piston_ball","discs_friction_coupling","half_cylinder_drop","projectile_bounce",
           "ring_sticky_collision","semicircular_track","slab_springs_block_drop","sliding_block_step_topple",
           "stacked_balls_drop","wheel_down_stairs","wheel_wall_bounce"]
CLASS = {
    "ball_wrapping_pole": "BallWrappingPoleParams",
    "balls_in_basin": "BallsInBasinParams",
    "block_on_sphere_basin": "BlockOnSphereBasinParams",
    "block_strikes_spring_pair": "BlockStrikesSpringPairParams",
    "cylinder_piston_ball": "CylinderPistonBallParams",
    "discs_friction_coupling": "DiscsFrictionCouplingParams",
    "half_cylinder_drop": "HalfCylinderDropParams",
    "projectile_bounce": "ProjectileBounceParams",
    "ring_sticky_collision": "RingStickyCollisionParams",
    "semicircular_track": "SemicircularTrackParams",
    "slab_springs_block_drop": "SlabSpringsBlockDropParams",
    "sliding_block_step_topple": "SlidingBlockStepToppleParams",
    "stacked_balls_drop": "StackedBallsDropParams",
    "wheel_down_stairs": "WheelDownStairsParams",
    "wheel_wall_bounce": "WheelWallBounceParams",
}
SKIP_EXACT = {"g","experiment","category","camera_eye","camera_target","camera_pos","colors","color",
              "object_shapes","shapes","positions","velocities","duration","fps","n_frames","seed",
              "n_objects","n_pucks","n_pit","n_arch_blocks","floor_size"}
SKIP_SUBSTR = ("_pos","pos_","color","shape","camera")

ALPHA = 0.10
FRAMES_FOR_DIFF = 16
RES_FOR_DIFF = 128
TIMEOUT_S = 90


def resolve_config(exp, cfg):
    if exp not in cfg: return {}
    spec = cfg[exp]
    if "_extends" in spec:
        base = resolve_config(spec["_extends"], cfg)
        base.update({k:v for k,v in spec.items() if not k.startswith("_")})
        return base
    return {k:v for k,v in spec.items() if not k.startswith("_")}


def is_phys(k):
    if k.lower() in SKIP_EXACT: return False
    if any(s in k.lower() for s in SKIP_SUBSTR): return False
    return True


def sample_frames(video_path, n_frames, res):
    """Uniformly sample n_frames from video, downsample to res x res grayscale."""
    try:
        frames = []
        for f in iio.imiter(video_path):
            frames.append(f)
        if not frames: return None
        n = len(frames)
        idx = np.linspace(0, n-1, n_frames).astype(int)
        picked = [frames[i] for i in idx]
        # RGB -> gray, downsample
        arr = np.array(picked, dtype=np.float32)
        if arr.ndim == 4 and arr.shape[-1] >= 3:
            gray = arr[...,:3].mean(-1)
        else:
            gray = arr.squeeze(-1) if arr.ndim == 4 else arr
        # simple resize via strided sampling
        h, w = gray.shape[1:3]
        y_idx = np.linspace(0, h-1, res).astype(int)
        x_idx = np.linspace(0, w-1, res).astype(int)
        gray = gray[:, y_idx][:, :, x_idx]
        return gray / 255.0  # in [0,1]
    except Exception:
        return None


def frame_diff(base_video, pert_video):
    """Return {mean_mse, peak_mse} between two videos. None if either unreadable."""
    A = sample_frames(base_video, FRAMES_FOR_DIFF, RES_FOR_DIFF)
    B = sample_frames(pert_video, FRAMES_FOR_DIFF, RES_FOR_DIFF)
    if A is None or B is None: return None
    per_frame = ((A - B) ** 2).mean(axis=(1,2))
    return {"mean_mse": float(per_frame.mean()), "peak_mse": float(per_frame.max())}


def perturb_one(job):
    """Worker: render one perturbed video and diff it against baseline."""
    exp, sid, param, direction = job["exp"], job["sid"], job["param"], job["direction"]
    step = job["step"]
    baseline = ROOT / "benchmarking_data" / "scipy" / exp / sid / "video.mp4"
    if not baseline.exists():
        return {**job, "status": "no_baseline"}

    # Load original params
    p_orig = json.load(open(ROOT / "benchmarking_data" / "scipy" / exp / sid / "params.json"))
    v_orig = p_orig[param]
    v_new = v_orig + (step if direction == "+" else -step)
    # Clamp for restitution-like params
    if param.startswith("e_") or param.endswith("_restitution") or param.endswith("restitution"):
        v_new = max(0.0, min(1.0, v_new))
    p_new = dict(p_orig)
    p_new[param] = v_new

    # Set up tempdir
    tmp = Path(tempfile.mkdtemp(prefix=f"sens_{exp}_{sid}_{param}_{direction}_"))
    try:
        # Regenerate standalone via module's make_standalone_script
        mod = importlib.import_module(f"simulations.scipy.{exp}")
        ParamCls = getattr(mod, CLASS[exp])
        # Filter to fields the dataclass accepts
        fields = {f.name for f in dataclasses.fields(ParamCls)}
        p_filt = {k:v for k,v in p_new.items() if k in fields}
        params_obj = ParamCls(**p_filt)
        # Get duration from original if present
        duration = p_orig.get("duration", 12.0)
        try:
            code = mod.make_standalone_script(params_obj, duration=duration)
        except TypeError:
            code = mod.make_standalone_script(params_obj)
        (tmp / "simulation_code.py").write_text(code)

        # Run
        try:
            r = subprocess.run([sys.executable, "simulation_code.py"],
                               cwd=tmp, capture_output=True, timeout=TIMEOUT_S)
            if r.returncode != 0:
                return {**job, "status": "sim_crash",
                        "stderr_tail": r.stderr.decode()[-200:]}
        except subprocess.TimeoutExpired:
            return {**job, "status": "sim_timeout"}

        # Find produced video
        candidates = sorted(tmp.glob("*.mp4"), key=lambda p: p.stat().st_size, reverse=True)
        if not candidates:
            return {**job, "status": "no_video_produced"}
        pert_vid = candidates[0]
        if pert_vid.stat().st_size < 1000:
            return {**job, "status": "video_too_small"}

        # Compute frame diff
        diff = frame_diff(baseline, pert_vid)
        if diff is None:
            return {**job, "status": "diff_failed"}

        # Persist perturbed video
        save_dir = OUT / "videos" / exp / sid / f"{param}_{direction}"
        save_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy(pert_vid, save_dir / "video.mp4")

        return {**job, "status": "ok", **diff, "v_new": v_new, "v_orig": v_orig}
    except Exception as e:
        return {**job, "status": "exception", "error": f"{type(e).__name__}: {str(e)[:200]}"}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def build_jobs():
    cfg_raw = json.load(open(CONFIG_PATH))
    jobs = []
    for exp in PARENTS:
        cfg = resolve_config(exp, cfg_raw)
        sid_list = sorted((BENCH / exp).iterdir())[:5]
        sid_list = [s.name for s in sid_list if (s / "params.json").exists()]
        # First sample's params.json to enumerate params
        p_baseline = json.load(open(BENCH / exp / sid_list[0] / "params.json"))
        for k, v in p_baseline.items():
            if not isinstance(v, (int, float)): continue
            if not is_phys(k): continue
            spec = cfg.get(k, {})
            if not ("min" in spec and "max" in spec):
                continue  # fixed or no config → skip
            step = ALPHA * (spec["max"] - spec["min"])
            for sid in sid_list:
                for direction in ("+", "-"):
                    jobs.append({"exp": exp, "sid": sid, "param": k,
                                 "direction": direction, "step": step,
                                 "cfg_min": spec["min"], "cfg_max": spec["max"]})
    return jobs


def normalize_and_tier(rows):
    """Per-experiment mean-normalization; k-means tier assignment across all params."""
    # rows: list of dicts with exp, param, mean_mse (only status=ok)
    by_exp = {}
    for r in rows:
        if r.get("status") != "ok": continue
        by_exp.setdefault(r["exp"], []).append(r)

    normalized = []
    for exp, exp_rows in by_exp.items():
        base_div = st.mean([r["mean_mse"] for r in exp_rows]) or 1.0
        for r in exp_rows:
            r["sensitivity_normalized"] = r["mean_mse"] / base_div
            r["exp_baseline_diversity"] = base_div
            normalized.append(r)

    # Aggregate per (exp, param)
    agg = {}
    for r in normalized:
        key = (r["exp"], r["param"])
        agg.setdefault(key, []).append(r["sensitivity_normalized"])

    scores = []
    for (exp, param), vals in agg.items():
        scores.append({"exp": exp, "param": param,
                       "sensitivity": st.mean(vals),
                       "std": st.stdev(vals) if len(vals)>1 else 0.0,
                       "n_measurements": len(vals)})

    # k-means (k=3) on sensitivity
    X = np.array([[s["sensitivity"]] for s in scores])
    km = KMeans(n_clusters=3, random_state=42, n_init=10)
    labels = km.fit_predict(X)
    centers = km.cluster_centers_.flatten()
    # sort clusters by center: 0=insensitive, 1=moderate, 2=sensitive
    order = np.argsort(centers)
    label_map = {int(order[0]): "insensitive", int(order[1]): "moderate", int(order[2]): "sensitive"}
    for s, lbl in zip(scores, labels):
        s["tier"] = label_map[int(lbl)]

    return scores


def main():
    print(f"[sensitivity] planning jobs...")
    jobs = build_jobs()
    print(f"[sensitivity] {len(jobs)} render jobs planned")

    # Save plan
    (OUT / "plan.json").write_text(json.dumps(jobs, indent=2))

    # Render in parallel
    print(f"[sensitivity] rendering with {min(mp.cpu_count(), 16)}-way parallelism...")
    t0 = time.time()
    n_workers = min(mp.cpu_count(), 16)
    with mp.Pool(processes=n_workers) as pool:
        results = []
        for i, r in enumerate(pool.imap_unordered(perturb_one, jobs, chunksize=4), 1):
            results.append(r)
            if i % 50 == 0 or i == len(jobs):
                elapsed = time.time() - t0
                rate = i / elapsed
                eta = (len(jobs) - i) / rate
                n_ok = sum(1 for r in results if r.get("status") == "ok")
                print(f"  [{i}/{len(jobs)}] ok={n_ok} rate={rate:.1f}/s eta={eta:.0f}s")

    # Save raw
    with open(OUT / "perturbation_results.jsonl", "w") as f:
        for r in results: f.write(json.dumps(r) + "\n")

    n_ok = sum(1 for r in results if r.get("status") == "ok")
    print(f"[sensitivity] renders done: {n_ok}/{len(results)} succeeded")

    # Normalize + tier
    scores = normalize_and_tier(results)
    with open(OUT / "sensitivity_scores.json", "w") as f:
        json.dump(scores, f, indent=2)

    # Emit param_tier_map.json
    tier_map = {}
    for s in scores:
        tier_map.setdefault(s["exp"], {})[s["param"]] = {
            "tier": s["tier"], "sensitivity": s["sensitivity"], "std": s["std"],
            "source": "data_driven"
        }
    # Mark fixed / no-config params in each experiment
    cfg_raw = json.load(open(CONFIG_PATH))
    for exp in PARENTS:
        cfg = resolve_config(exp, cfg_raw)
        p = json.load(open(BENCH / exp / sorted(os.listdir(BENCH / exp))[0] / "params.json"))
        for k, v in p.items():
            if not isinstance(v, (int, float)) or not is_phys(k): continue
            if k in tier_map.get(exp, {}): continue
            spec = cfg.get(k, {})
            if "fixed" in spec:
                tier_map.setdefault(exp, {})[k] = {"tier": "config_fixed",
                                                    "source": "config_fixed"}
            elif not spec:
                tier_map.setdefault(exp, {})[k] = {"tier": "no_config",
                                                    "source": "no_config"}
    with open(OUT / "param_tier_map.json", "w") as f:
        json.dump(tier_map, f, indent=2)

    # Summary
    from collections import Counter
    tier_counts = Counter()
    for exp, params in tier_map.items():
        for p, info in params.items():
            tier_counts[info["tier"]] += 1
    print(f"[sensitivity] Tier distribution:")
    for tier, n in sorted(tier_counts.items()):
        print(f"  {tier:<20s} {n}")

    total_sec = time.time() - t0
    print(f"[sensitivity] Total wall clock: {total_sec/60:.1f} min")
    print(f"[sensitivity] Outputs in {OUT}/")


if __name__ == "__main__":
    main()
