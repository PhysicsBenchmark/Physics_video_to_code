"""Generate calibration plots for one model's human labels.

Reads:   eval_outputs/<model>/{human_labels.csv, video_similarity.jsonl, eval_results.jsonl}
Writes:  eval_outputs/<model>/calibration_plots/*.png

Usage:   python eval/plot_human_calibration.py <model>
"""
from __future__ import annotations
import argparse, csv, json, statistics
from collections import defaultdict
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from scipy import stats
from sklearn.metrics import roc_curve, roc_auc_score

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "DejaVu Serif", "Palatino", "STIXGeneral"],
    "axes.titlesize": 12,
    "axes.labelsize": 11,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "legend.fontsize": 10,
})


def parse_pair_id(pid):
    parts = pid.split('_')
    return parts[2], '_'.join(parts[3:-1]), parts[-1]


def load_data(model: str):
    eval_dir = Path(f'eval_outputs/{model}')

    with open(eval_dir / 'human_labels.csv') as f:
        human = {r['pair_id']: {k: int(r[k]) for k in ('plausibility', 'appearance', 'physics')}
                 for r in csv.DictReader(f)}

    vsim = {}
    for line in (eval_dir / 'video_similarity.jsonl').read_text().splitlines():
        line = line.strip()
        if not line: continue
        r = json.loads(line)
        if r.get('status') != 'ok': continue
        vsim[(r['engine'], r['experiment'], r['sample_id'])] = (r['dino_cosine'], r['xclip_cosine'])

    eval_rows = [json.loads(l) for l in (eval_dir / 'eval_results.jsonl').read_text().splitlines() if l.strip()]
    llm_eq = defaultdict(list); llm_val = defaultdict(list)
    llm_eq_pj = defaultdict(dict); llm_val_pj = defaultdict(dict)
    for r in eval_rows:
        if r.get('skipped') or r.get('judge_error'): continue
        s = r.get('scores') or {}
        if 'overall' not in s: continue
        k = (r['engine'], r['experiment'], r['sample_id'])
        if r['scorer'] == 'law_equivalence':
            llm_eq[k].append(s['overall']); llm_eq_pj[k][r['judge_model']] = s['overall']
        elif r['scorer'] == 'law_validity':
            llm_val[k].append(s['overall']); llm_val_pj[k][r['judge_model']] = s['overall']

    joined = []
    for pid, h in human.items():
        eng, exp, sid = parse_pair_id(pid)
        k = (eng, exp, sid)
        if k not in vsim: continue
        dino, xclip = vsim[k]
        eq_m = statistics.fmean(llm_eq[k]) if llm_eq[k] else None
        val_m = statistics.fmean(llm_val[k]) if llm_val[k] else None
        joined.append({
            'pair_id': pid, 'engine': eng,
            'h_plausibility': h['plausibility'],
            'h_appearance': h['appearance'],
            'h_physics': h['physics'],
            'dino': dino, 'xclip': xclip,
            'llm_eq': eq_m, 'llm_val': val_m,
            'llm_eq_pj': llm_eq_pj[k], 'llm_val_pj': llm_val_pj[k],
        })
    return joined


def jitter_scatter(ax, x_int, y_cont, color_by_engine=None, alpha=0.55, s=42, jitter=0.18):
    """Scatter integer x vs continuous y with horizontal jitter for visibility."""
    x_arr = np.array(x_int) + np.random.uniform(-jitter, jitter, len(x_int))
    y_arr = np.array(y_cont)
    if color_by_engine is not None:
        cmap = {'scipy': '#1f77b4', 'kubric': '#d62728'}
        for eng, color in cmap.items():
            mask = np.array([e == eng for e in color_by_engine])
            ax.scatter(x_arr[mask], y_arr[mask], c=color, alpha=alpha, s=s,
                       label=f'{eng} (N={mask.sum()})', edgecolor='white', linewidth=0.5)
    else:
        ax.scatter(x_arr, y_arr, alpha=alpha, s=s, c='#2ca02c',
                   edgecolor='white', linewidth=0.5)


def fit_line(ax, x, y, color='black', label_prefix=''):
    """Add linear regression line + Spearman ρ annotation."""
    m, b = np.polyfit(x, y, 1)
    x_line = np.array([min(x) - 0.3, max(x) + 0.3])
    ax.plot(x_line, m * x_line + b, color=color, linewidth=2.0, alpha=0.85)
    rho, p = stats.spearmanr(x, y)
    pearson_r, _ = stats.pearsonr(x, y)
    ax.text(0.04, 0.95,
            f'{label_prefix}Spearman ρ = {rho:.3f}\nPearson r = {pearson_r:.3f}',
            transform=ax.transAxes, va='top', ha='left',
            fontsize=10, bbox=dict(boxstyle='round,pad=0.4', facecolor='white', alpha=0.85))


def boxplot_per_bin(ax, x_int, y_cont, x_label='', y_label=''):
    """Box plot of y_cont grouped by x_int."""
    by_bin = defaultdict(list)
    for x, y in zip(x_int, y_cont):
        by_bin[int(x)].append(y)
    bins = sorted(by_bin.keys())
    data = [by_bin[b] for b in bins]
    bp = ax.boxplot(data, positions=bins, widths=0.6, patch_artist=True,
                    medianprops=dict(color='black', linewidth=1.4),
                    flierprops=dict(marker='o', markersize=4, alpha=0.4))
    for patch in bp['boxes']:
        patch.set_facecolor('#a3c4f3')
        patch.set_alpha(0.6)
    # Annotate N per bin
    for b in bins:
        ax.text(b, ax.get_ylim()[0] if False else min(min(d) for d in data) - 0.02 * (max(max(d) for d in data) - min(min(d) for d in data)),
                f'N={len(by_bin[b])}', ha='center', fontsize=9, color='gray')
    ax.set_xlabel(x_label)
    ax.set_ylabel(y_label)
    ax.set_xticks(bins)
    ax.grid(axis='y', alpha=0.3)


def fig_appearance(joined, out: Path):
    """Figure A: DINO/XCLIP vs human appearance."""
    fig, axes = plt.subplots(2, 2, figsize=(13, 10))
    fig.suptitle('A. Video similarity (DINO / X-CLIP) vs human APPEARANCE', fontsize=14, fontweight='bold')

    app = [j['h_appearance'] for j in joined]
    eng = [j['engine'] for j in joined]

    # Scatter DINO vs appearance
    ax = axes[0, 0]
    np.random.seed(7)
    jitter_scatter(ax, app, [j['dino'] for j in joined], eng)
    fit_line(ax, app, [j['dino'] for j in joined])
    ax.set_xticks([1, 2, 3, 4, 5]); ax.set_xlabel('Human appearance score'); ax.set_ylabel('DINOv2 cosine')
    ax.set_title('DINOv2 cosine vs appearance'); ax.grid(alpha=0.3); ax.legend(loc='lower right')

    # Scatter XCLIP vs appearance
    ax = axes[0, 1]
    np.random.seed(7)
    jitter_scatter(ax, app, [j['xclip'] for j in joined], eng)
    fit_line(ax, app, [j['xclip'] for j in joined])
    ax.set_xticks([1, 2, 3, 4, 5]); ax.set_xlabel('Human appearance score'); ax.set_ylabel('X-CLIP cosine')
    ax.set_title('X-CLIP cosine vs appearance'); ax.grid(alpha=0.3); ax.legend(loc='lower right')

    # Box DINO per bin
    ax = axes[1, 0]
    boxplot_per_bin(ax, app, [j['dino'] for j in joined],
                    x_label='Human appearance score', y_label='DINOv2 cosine')
    ax.set_title('DINOv2 distribution by appearance bin')

    # Box XCLIP per bin
    ax = axes[1, 1]
    boxplot_per_bin(ax, app, [j['xclip'] for j in joined],
                    x_label='Human appearance score', y_label='X-CLIP cosine')
    ax.set_title('X-CLIP distribution by appearance bin')

    plt.tight_layout(rect=[0, 0, 1, 0.97])
    plt.savefig(out, dpi=180, bbox_inches='tight')
    plt.close()


def fig_physics(joined, out: Path):
    """Figure B: LLM equivalence vs human physics."""
    have = [j for j in joined if j['llm_eq'] is not None]
    eq = [j['llm_eq'] for j in have]
    phys = [j['h_physics'] for j in have]
    eng = [j['engine'] for j in have]

    fig, axes = plt.subplots(1, 3, figsize=(17, 5.5))
    fig.suptitle('B. LLM-judge EQUIVALENCE vs human PHYSICS', fontsize=14, fontweight='bold')

    # Scatter
    ax = axes[0]
    np.random.seed(7)
    jitter_scatter(ax, phys, eq, eng)
    fit_line(ax, phys, eq)
    ax.set_xticks([1, 2, 3, 4, 5]); ax.set_yticks([0, 1, 2, 3, 4])
    ax.set_xlabel('Human physics score'); ax.set_ylabel('Mean LLM equivalence (0-4)')
    ax.set_title(f'Mean of 3 judges (N={len(have)})')
    ax.grid(alpha=0.3); ax.legend(loc='upper left')

    # Box per bin
    ax = axes[1]
    boxplot_per_bin(ax, phys, eq, x_label='Human physics score', y_label='Mean LLM equivalence')
    ax.set_title('LLM equivalence distribution by physics bin')

    # Per-judge correlation bars
    ax = axes[2]
    judges = ['gpt-5-nano', 'gemini-2.5-flash', 'grok-4-1-fast']
    rhos = []
    for jm in judges:
        xs, ys = [], []
        for j in have:
            if jm in j['llm_eq_pj']:
                xs.append(j['llm_eq_pj'][jm]); ys.append(j['h_physics'])
        rho, p = stats.spearmanr(xs, ys)
        rhos.append((jm, rho, p, len(xs)))
    bars = ax.bar([r[0] for r in rhos], [r[1] for r in rhos],
                  color=['#ff7f0e', '#1f77b4', '#9467bd'], edgecolor='black')
    for bar, (jm, rho, p, n) in zip(bars, rhos):
        sig = '*' if p < 0.05 else ''
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.005,
                f'{rho:.3f}{sig}\n(p={p:.2f})', ha='center', fontsize=10)
    ax.axhline(0, color='black', linewidth=0.6)
    ax.set_ylabel('Spearman ρ vs human physics'); ax.set_title('Per-judge correlation')
    ax.set_ylim(min(0, min(r[1] for r in rhos) - 0.1), max(max(r[1] for r in rhos) + 0.05, 0.4))
    plt.setp(ax.get_xticklabels(), rotation=12, ha='right')
    ax.grid(axis='y', alpha=0.3)

    plt.tight_layout(rect=[0, 0, 1, 0.94])
    plt.savefig(out, dpi=180, bbox_inches='tight')
    plt.close()


def fig_plausibility(joined, out: Path):
    """Figure C: LLM validity vs human plausibility."""
    have = [j for j in joined if j['llm_val'] is not None]
    val = [j['llm_val'] for j in have]
    pl = [j['h_plausibility'] for j in have]
    eng = [j['engine'] for j in have]

    fig, axes = plt.subplots(1, 3, figsize=(17, 5.5))
    fig.suptitle('C. LLM-judge VALIDITY vs human PLAUSIBILITY', fontsize=14, fontweight='bold')

    ax = axes[0]
    np.random.seed(7)
    jitter_scatter(ax, pl, val, eng)
    fit_line(ax, pl, val)
    ax.set_xticks([1, 2, 3, 4, 5]); ax.set_yticks([0, 1, 2, 3, 4])
    ax.set_xlabel('Human plausibility score'); ax.set_ylabel('Mean LLM validity (0-4)')
    ax.set_title(f'Mean of 3 judges (N={len(have)})')
    ax.grid(alpha=0.3); ax.legend(loc='lower right')

    ax = axes[1]
    boxplot_per_bin(ax, pl, val, x_label='Human plausibility score', y_label='Mean LLM validity')
    ax.set_title('LLM validity distribution by plausibility bin')

    ax = axes[2]
    judges = ['gpt-5-nano', 'gemini-2.5-flash', 'grok-4-1-fast']
    rhos = []
    for jm in judges:
        xs, ys = [], []
        for j in have:
            if jm in j['llm_val_pj']:
                xs.append(j['llm_val_pj'][jm]); ys.append(j['h_plausibility'])
        rho, p = stats.spearmanr(xs, ys)
        rhos.append((jm, rho, p, len(xs)))
    bars = ax.bar([r[0] for r in rhos], [r[1] for r in rhos],
                  color=['#ff7f0e', '#1f77b4', '#9467bd'], edgecolor='black')
    for bar, (jm, rho, p, n) in zip(bars, rhos):
        sig = '*' if p < 0.05 else ''
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.005,
                f'{rho:.3f}{sig}\n(p={p:.3f})', ha='center', fontsize=10)
    ax.axhline(0, color='black', linewidth=0.6)
    ax.set_ylabel('Spearman ρ vs human plausibility'); ax.set_title('Per-judge correlation')
    ax.set_ylim(0, max(r[1] for r in rhos) + 0.08)
    plt.setp(ax.get_xticklabels(), rotation=12, ha='right')
    ax.grid(axis='y', alpha=0.3)

    plt.tight_layout(rect=[0, 0, 1, 0.94])
    plt.savefig(out, dpi=180, bbox_inches='tight')
    plt.close()


def fig_deceptive(joined, out: Path):
    """Figure D: Cross-dimensional analysis (deceptive samples)."""
    fig, axes = plt.subplots(2, 2, figsize=(14, 11))
    fig.suptitle('D. Cross-dimensional patterns (visually deceptive vs truth-hidden)',
                 fontsize=14, fontweight='bold')

    # Heatmap of count: appearance × physics
    ax = axes[0, 0]
    counts = np.zeros((5, 5))
    for j in joined:
        counts[j['h_appearance'] - 1, j['h_physics'] - 1] += 1
    im = ax.imshow(counts, cmap='Blues', origin='lower', aspect='equal')
    ax.set_xticks(range(5)); ax.set_xticklabels([1, 2, 3, 4, 5])
    ax.set_yticks(range(5)); ax.set_yticklabels([1, 2, 3, 4, 5])
    ax.set_xlabel('Human physics score'); ax.set_ylabel('Human appearance score')
    ax.set_title('Joint distribution (count)')
    for i in range(5):
        for j in range(5):
            if counts[i, j] > 0:
                color = 'white' if counts[i, j] > counts.max() * 0.5 else 'black'
                ax.text(j, i, int(counts[i, j]), ha='center', va='center', color=color, fontsize=11)
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    # Highlight deceptive (top-left of heat): app≥4 phys≤2
    ax.add_patch(plt.Rectangle((-0.5, 2.5), 2, 2.5, fill=False, edgecolor='red', linewidth=2.4, label='deceptive'))
    # truth hidden: app≤2 phys≥4
    ax.add_patch(plt.Rectangle((2.5, -0.5), 2.5, 2, fill=False, edgecolor='green', linewidth=2.4, label='truth hidden'))
    ax.legend(loc='lower left', fontsize=9)

    # Scatter: appearance vs physics, colored by DINO
    np.random.seed(11)
    app = np.array([j['h_appearance'] for j in joined]) + np.random.uniform(-0.18, 0.18, len(joined))
    phys = np.array([j['h_physics'] for j in joined]) + np.random.uniform(-0.18, 0.18, len(joined))
    dino_arr = np.array([j['dino'] for j in joined])
    ax = axes[0, 1]
    sc = ax.scatter(phys, app, c=dino_arr, s=64, cmap='RdYlGn', edgecolor='black',
                    linewidth=0.5, vmin=0.3, vmax=0.9)
    ax.set_xticks([1, 2, 3, 4, 5]); ax.set_yticks([1, 2, 3, 4, 5])
    ax.set_xlabel('Human physics score'); ax.set_ylabel('Human appearance score')
    ax.set_title('Color = DINOv2 cosine\n(red=low similarity, green=high)')
    cbar = plt.colorbar(sc, ax=ax, fraction=0.046, pad=0.04); cbar.set_label('DINOv2 cosine')
    ax.add_patch(plt.Rectangle((0.5, 3.5), 2, 2, fill=False, edgecolor='red', linewidth=2.4))
    ax.text(1.5, 5.4, 'deceptive zone', ha='center', color='red', fontweight='bold')

    # Scatter colored by llm_eq
    have = [j for j in joined if j['llm_eq'] is not None]
    np.random.seed(11)
    app = np.array([j['h_appearance'] for j in have]) + np.random.uniform(-0.18, 0.18, len(have))
    phys = np.array([j['h_physics'] for j in have]) + np.random.uniform(-0.18, 0.18, len(have))
    eq_arr = np.array([j['llm_eq'] for j in have])
    ax = axes[1, 0]
    sc = ax.scatter(phys, app, c=eq_arr, s=64, cmap='RdYlGn', edgecolor='black',
                    linewidth=0.5, vmin=0, vmax=4)
    ax.set_xticks([1, 2, 3, 4, 5]); ax.set_yticks([1, 2, 3, 4, 5])
    ax.set_xlabel('Human physics score'); ax.set_ylabel('Human appearance score')
    ax.set_title(f'Color = LLM equivalence (mean of 3 judges)\nN={len(have)}')
    cbar = plt.colorbar(sc, ax=ax, fraction=0.046, pad=0.04); cbar.set_label('LLM equivalence (0-4)')
    ax.add_patch(plt.Rectangle((0.5, 3.5), 2, 2, fill=False, edgecolor='red', linewidth=2.4))

    # Bar chart: deceptive vs all-pairs metric means
    dec = [j for j in joined if j['h_appearance'] >= 4 and j['h_physics'] <= 2]
    dec_with_llm = [j for j in dec if j['llm_eq'] is not None]
    ax = axes[1, 1]
    metrics = ['DINO', 'XCLIP', 'llm_eq', 'llm_val']
    avg_all = [
        statistics.fmean(j['dino'] for j in joined),
        statistics.fmean(j['xclip'] for j in joined),
        statistics.fmean(j['llm_eq'] for j in joined if j['llm_eq'] is not None) / 4,
        statistics.fmean(j['llm_val'] for j in joined if j['llm_val'] is not None) / 4,
    ]
    avg_dec = [
        statistics.fmean(j['dino'] for j in dec),
        statistics.fmean(j['xclip'] for j in dec),
        statistics.fmean(j['llm_eq'] for j in dec_with_llm) / 4 if dec_with_llm else 0,
        statistics.fmean(j['llm_val'] for j in dec_with_llm) / 4 if dec_with_llm else 0,
    ]
    x = np.arange(len(metrics))
    w = 0.35
    bars1 = ax.bar(x - w/2, avg_all, w, label=f'All pairs (N={len(joined)})', color='#1f77b4')
    bars2 = ax.bar(x + w/2, avg_dec, w, label=f'Deceptive (N={len(dec)})', color='#d62728')
    for b in bars1:
        ax.text(b.get_x() + b.get_width()/2, b.get_height() + 0.005, f'{b.get_height():.3f}',
                ha='center', fontsize=9)
    for b in bars2:
        ax.text(b.get_x() + b.get_width()/2, b.get_height() + 0.005, f'{b.get_height():.3f}',
                ha='center', fontsize=9)
    ax.set_xticks(x); ax.set_xticklabels(metrics)
    ax.set_ylabel('Score (llm_eq/llm_val rescaled to 0-1)')
    ax.set_title('Deceptive samples: which metrics are fooled?')
    ax.legend()
    ax.grid(axis='y', alpha=0.3)

    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.savefig(out, dpi=180, bbox_inches='tight')
    plt.close()


def fig_roc(joined, out: Path):
    """Figure E: ROC curves for binary classification."""
    fig, axes = plt.subplots(1, 3, figsize=(17, 5.5))
    fig.suptitle('E. ROC curves — automated metrics as binary classifiers',
                 fontsize=14, fontweight='bold')

    # appearance >= 4
    ax = axes[0]
    y_app = [1 if j['h_appearance'] >= 4 else 0 for j in joined]
    for label, scores, color in [
        ('DINOv2 cosine', [j['dino'] for j in joined], '#2ca02c'),
        ('X-CLIP cosine', [j['xclip'] for j in joined], '#9467bd'),
    ]:
        fpr, tpr, _ = roc_curve(y_app, scores)
        auc = roc_auc_score(y_app, scores)
        ax.plot(fpr, tpr, label=f'{label} (AUC={auc:.3f})', linewidth=2)
    ax.plot([0, 1], [0, 1], 'k--', alpha=0.4, linewidth=1)
    ax.set_xlabel('False positive rate'); ax.set_ylabel('True positive rate')
    ax.set_title(f'Predicting human appearance ≥ 4\n(positives = {sum(y_app)} / {len(y_app)})')
    ax.legend(loc='lower right'); ax.grid(alpha=0.3)
    ax.set_aspect('equal')

    # physics >= 4 (using llm_eq)
    ax = axes[1]
    have = [j for j in joined if j['llm_eq'] is not None]
    y_phys = [1 if j['h_physics'] >= 4 else 0 for j in have]
    for label, scores, color in [
        ('LLM equivalence (mean)', [j['llm_eq'] for j in have], '#ff7f0e'),
        ('DINOv2 cosine', [j['dino'] for j in have], '#2ca02c'),
        ('X-CLIP cosine', [j['xclip'] for j in have], '#9467bd'),
    ]:
        fpr, tpr, _ = roc_curve(y_phys, scores)
        auc = roc_auc_score(y_phys, scores)
        ax.plot(fpr, tpr, label=f'{label} (AUC={auc:.3f})', linewidth=2)
    ax.plot([0, 1], [0, 1], 'k--', alpha=0.4, linewidth=1)
    ax.set_xlabel('False positive rate'); ax.set_ylabel('True positive rate')
    ax.set_title(f'Predicting human physics ≥ 4\n(positives = {sum(y_phys)} / {len(y_phys)})')
    ax.legend(loc='lower right'); ax.grid(alpha=0.3)
    ax.set_aspect('equal')

    # plausibility >= 4 (using llm_val)
    ax = axes[2]
    have_v = [j for j in joined if j['llm_val'] is not None]
    y_pl = [1 if j['h_plausibility'] >= 4 else 0 for j in have_v]
    for label, scores, color in [
        ('LLM validity (mean)', [j['llm_val'] for j in have_v], '#ff7f0e'),
        ('grok-4-1-fast (best)',
         [j['llm_val_pj'].get('grok-4-1-fast', np.nan) for j in have_v if 'grok-4-1-fast' in j['llm_val_pj']],
         '#9467bd'),
    ]:
        # Filter out nans
        valid_mask = [not np.isnan(s) for s in scores]
        if not any(valid_mask): continue
        scores_arr = np.array(scores)[valid_mask]
        y_arr = np.array(y_pl)[valid_mask] if len(valid_mask) == len(y_pl) else np.array([y_pl[i] for i, m in enumerate(valid_mask) if m])
        if len(set(y_arr)) < 2:
            continue
        fpr, tpr, _ = roc_curve(y_arr, scores_arr)
        auc = roc_auc_score(y_arr, scores_arr)
        ax.plot(fpr, tpr, label=f'{label} (AUC={auc:.3f})', linewidth=2)
    ax.plot([0, 1], [0, 1], 'k--', alpha=0.4, linewidth=1)
    ax.set_xlabel('False positive rate'); ax.set_ylabel('True positive rate')
    ax.set_title(f'Predicting human plausibility ≥ 4\n(positives = {sum(y_pl)} / {len(y_pl)})')
    ax.legend(loc='lower right'); ax.grid(alpha=0.3)
    ax.set_aspect('equal')

    plt.tight_layout(rect=[0, 0, 1, 0.94])
    plt.savefig(out, dpi=180, bbox_inches='tight')
    plt.close()


def fig_per_engine(joined, out: Path):
    """Figure F: per-engine breakdown of correlations."""
    pairs = [
        ('DINO vs appearance', 'dino', 'h_appearance'),
        ('XCLIP vs appearance', 'xclip', 'h_appearance'),
        ('llm_eq vs physics', 'llm_eq', 'h_physics'),
        ('llm_val vs plausibility', 'llm_val', 'h_plausibility'),
    ]
    engines = ['scipy', 'kubric']
    fig, ax = plt.subplots(figsize=(11, 6))
    n = len(pairs)
    width = 0.35
    x = np.arange(n)
    rhos = {eng: [] for eng in engines}
    for label, x_key, y_key in pairs:
        for eng in engines:
            sub = [j for j in joined if j['engine'] == eng and j[x_key] is not None]
            if len(sub) < 2:
                rhos[eng].append(0); continue
            xs = [j[x_key] for j in sub]; ys = [j[y_key] for j in sub]
            rho, _ = stats.spearmanr(xs, ys)
            rhos[eng].append(rho)
    colors = {'scipy': '#1f77b4', 'kubric': '#d62728'}
    for i, eng in enumerate(engines):
        offset = -width/2 + i * width
        bars = ax.bar(x + offset, rhos[eng], width, label=eng, color=colors[eng], edgecolor='black')
        for b in bars:
            h = b.get_height()
            ax.text(b.get_x() + b.get_width()/2, h + (0.01 if h >= 0 else -0.04),
                    f'{h:.3f}', ha='center', fontsize=10)
    ax.axhline(0, color='black', linewidth=0.6)
    ax.set_xticks(x); ax.set_xticklabels([p[0] for p in pairs])
    ax.set_ylabel('Spearman ρ')
    ax.set_title('F. Per-engine breakdown of automated-vs-human correlations',
                 fontsize=13, fontweight='bold')
    ax.legend(); ax.grid(axis='y', alpha=0.3)
    ax.set_ylim(min(min(rhos[e]) for e in engines) - 0.1, max(max(rhos[e]) for e in engines) + 0.1)
    plt.tight_layout()
    plt.savefig(out, dpi=180, bbox_inches='tight')
    plt.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('model')
    args = ap.parse_args()

    joined = load_data(args.model)
    print(f'Loaded {len(joined)} joined pairs for {args.model}')

    out_dir = Path(f'eval_outputs/{args.model}/calibration_plots')
    out_dir.mkdir(parents=True, exist_ok=True)

    fig_appearance(joined, out_dir / 'A_appearance.png')
    print(f'  wrote {out_dir / "A_appearance.png"}')
    fig_physics(joined, out_dir / 'B_physics.png')
    print(f'  wrote {out_dir / "B_physics.png"}')
    fig_plausibility(joined, out_dir / 'C_plausibility.png')
    print(f'  wrote {out_dir / "C_plausibility.png"}')
    fig_deceptive(joined, out_dir / 'D_deceptive.png')
    print(f'  wrote {out_dir / "D_deceptive.png"}')
    fig_roc(joined, out_dir / 'E_roc.png')
    print(f'  wrote {out_dir / "E_roc.png"}')
    fig_per_engine(joined, out_dir / 'F_per_engine.png')
    print(f'  wrote {out_dir / "F_per_engine.png"}')


if __name__ == '__main__':
    main()
