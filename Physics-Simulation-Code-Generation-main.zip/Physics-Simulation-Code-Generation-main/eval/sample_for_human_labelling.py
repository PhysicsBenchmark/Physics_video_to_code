"""Build a human-labelling package: 100 (generated, ground-truth) video pairs
from a model's runs, organised into per-pair folders, plus a CSV label
template, README, and a zip archive.

For each sampled pair the package contains:
    pair_<NNN>_<engine>_<experiment>_<sample_id>/
        generated.mp4        — model's rendered video
        ground_truth.mp4     — the corresponding benchmark reference
        meta.json            — engine/experiment/sample_id + paths

Top-level files in the package:
    README.md                — instructions for the human labeller
    labels_template.csv      — one row per pair, blank columns to fill in
    INDEX.txt                — quick reference list of pair folders

Usage:
    python eval/sample_for_human_labelling.py \\
        --model gpt_5_mini --n 100 --out human_labelling_gpt5mini

A zip is written next to the output dir: <out>.zip
"""
from __future__ import annotations
import argparse
import csv
import json
import random
import shutil
import zipfile
from pathlib import Path


def find_pairs(model: str, ref_root: Path, runs_root: Path,
               min_size: int = 1024) -> list[dict]:
    """Return every (engine, experiment, sample_id) for which both the
    rendered and reference video exist (and rendered isn't a broken stub)."""
    pairs: list[dict] = []
    for vid in sorted(runs_root.rglob("video.mp4")):
        rel = vid.relative_to(runs_root)
        parts = rel.parts
        if len(parts) < 4:
            continue
        eng, exp, sid = parts[0], parts[1], parts[2]
        ref = ref_root / eng / exp / sid / "video.mp4"
        if not ref.exists():
            continue
        if vid.stat().st_size < min_size:
            continue
        pairs.append({
            "engine": eng,
            "experiment": exp,
            "sample_id": sid,
            "rendered": vid,
            "reference": ref,
        })
    return pairs


def stratified_sample(pairs: list[dict], n: int, seed: int) -> list[dict]:
    """Sample n items with roughly balanced engine representation."""
    by_eng: dict[str, list[dict]] = {}
    for p in pairs:
        by_eng.setdefault(p["engine"], []).append(p)
    engines = sorted(by_eng.keys())
    rng = random.Random(seed)
    # Allocate roughly evenly, leftover to first engine
    per_engine = n // len(engines)
    leftover = n - per_engine * len(engines)
    selected: list[dict] = []
    for i, eng in enumerate(engines):
        take = per_engine + (1 if i < leftover else 0)
        avail = by_eng[eng]
        if take > len(avail):
            take = len(avail)
        selected.extend(rng.sample(avail, take))
    return selected


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--n", type=int, default=100)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--ref_root", default="benchmarking_data")
    ap.add_argument("--out", default=None,
                    help="output dir (default: human_labelling_<model>)")
    ap.add_argument("--no-zip", dest="make_zip", action="store_false")
    args = ap.parse_args()

    ref_root = Path(args.ref_root)
    runs_root = Path("eval_outputs") / args.model / "runs"
    if not runs_root.exists():
        raise SystemExit(f"missing {runs_root}")
    if not ref_root.exists():
        raise SystemExit(f"missing {ref_root}")

    out_dir = Path(args.out) if args.out else Path(f"human_labelling_{args.model}")
    if out_dir.exists():
        raise SystemExit(f"{out_dir} already exists; pick a different --out or remove it")
    out_dir.mkdir(parents=True)

    print(f"[scan] {runs_root}")
    pairs = find_pairs(args.model, ref_root, runs_root)
    print(f"[scan] found {len(pairs)} valid (rendered, reference) pairs")
    by_eng = {}
    for p in pairs:
        by_eng[p["engine"]] = by_eng.get(p["engine"], 0) + 1
    print(f"  by engine: {by_eng}")

    selected = stratified_sample(pairs, args.n, args.seed)
    print(f"[sample] selected {len(selected)} pairs (stratified by engine, seed={args.seed})")

    # Copy + write per-pair manifest
    csv_rows = []
    for i, p in enumerate(selected):
        folder = out_dir / f"pair_{i:03d}_{p['engine']}_{p['experiment']}_{p['sample_id']}"
        folder.mkdir(parents=True)
        shutil.copy(p["rendered"], folder / "generated.mp4")
        shutil.copy(p["reference"], folder / "ground_truth.mp4")
        meta = {
            "pair_id": i,
            "engine": p["engine"],
            "experiment": p["experiment"],
            "sample_id": p["sample_id"],
            "rendered_source": str(p["rendered"]),
            "reference_source": str(p["reference"]),
        }
        (folder / "meta.json").write_text(json.dumps(meta, indent=2))
        csv_rows.append({
            "pair_id": f"{i:03d}",
            "folder": folder.name,
            "engine": p["engine"],
            "experiment": p["experiment"],
            "sample_id": p["sample_id"],
            "equivalence_score": "",
            "plausibility_score": "",
            "notes": "",
        })

    # Top-level CSV template
    csv_path = out_dir / "labels_template.csv"
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "pair_id", "folder", "engine", "experiment", "sample_id",
            "equivalence_score", "plausibility_score", "notes",
        ])
        writer.writeheader()
        for r in csv_rows:
            writer.writerow(r)

    # Top-level INDEX
    index_path = out_dir / "INDEX.txt"
    index_path.write_text("\n".join(
        f"{r['pair_id']}  {r['engine']:<7s}  {r['experiment']}/{r['sample_id']}  → {r['folder']}"
        for r in csv_rows
    ) + "\n")

    # README
    readme = out_dir / "README.md"
    n_sel = len(selected)
    eng_counts = {}
    for s in selected:
        eng_counts[s["engine"]] = eng_counts.get(s["engine"], 0) + 1
    readme.write_text(README_TEMPLATE.format(
        model=args.model, n=n_sel, seed=args.seed,
        last_idx=f"{n_sel-1:03d}",
        engine_counts=", ".join(f"{e}={c}" for e, c in sorted(eng_counts.items())),
    ))

    # Zip
    if args.make_zip:
        zip_path = Path(str(out_dir) + ".zip")
        print(f"[zip] writing {zip_path}")
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in sorted(out_dir.rglob("*")):
                if f.is_file():
                    zf.write(f, f.relative_to(out_dir.parent))
        size_mb = zip_path.stat().st_size / (1024 * 1024)
        print(f"[zip] {zip_path}  {size_mb:.1f} MB")

    print(f"\n[done] folder: {out_dir}")
    print(f"        labels_template.csv with {len(csv_rows)} blank rows")
    print(f"        per-pair folders: {len(csv_rows)}")


README_TEMPLATE = """\
# Human labelling package — {model}

This folder contains **{n} (generated, ground-truth) video pairs** from
the {model} model evaluation, sampled with seed={seed}. Engine breakdown: {engine_counts}.

Each `pair_NNN_<engine>_<experiment>_<sample_id>/` folder contains:

| file | description |
|------|-------------|
| `generated.mp4` | The model's rendered output |
| `ground_truth.mp4` | The benchmark reference video for the same scenario |
| `meta.json` | Identifiers and source paths |

## Your task

For each pair you watch (in any order), record **two binary 0/1 scores**
in `labels_template.csv`:

### 1. Equivalence (`equivalence_score`) — 0 or 1

Does the **generated** video show the **same physics scenario and outcome**
as the **ground truth**?

| score | meaning |
|------|---------|
| **0** | Not equivalent — different objects, different motion, different outcome, or so visibly off that it would not be confused for the ground truth |
| **1** | Equivalent — recognisably the same scenario; objects, motion, and outcome match within reasonable tolerance |

When in doubt, ask: *if these two clips were shown side-by-side without
labels, would a viewer say they depict the same physical experiment?*
If yes → 1, if no → 0.

### 2. Physical plausibility (`plausibility_score`) — 0 or 1

Independent of the ground truth — does the **generated** video alone
show plausible physics?

| score | meaning |
|------|---------|
| **0** | Not plausible — clear physical violations (objects clipping through each other, gaining energy from nothing, gravity wrong, jittery / broken motion, blank or empty scene) |
| **1** | Plausible — motion is consistent with real physics; no obvious violations even if the visuals are stylised |

Plausibility is *independent of correctness*. A video can show wrong
physics for the prompt but still be physically plausible (1), or correct
physics but visually broken (0).

### Notes column

Optional free-text observations. Use this for failure modes you find
interesting ("ball clips through floor", "scene is empty", "video is blank",
"objects pass through each other"), edge cases, or anything that might
affect downstream calibration of automated metrics.

## How to fill in `labels_template.csv`

Open the CSV in any spreadsheet (LibreOffice, Excel, or as a text editor).
Pre-filled columns are read-only — only edit `equivalence_score`,
`plausibility_score`, and `notes`. Save in CSV format when done.

Both score columns must be exactly `0` or `1`.

Recommended workflow:

1. Open both `pair_NNN/.../generated.mp4` and `ground_truth.mp4` side by side.
2. Watch each at least once before scoring.
3. Score equivalence first (compare to ground truth), then plausibility
   (judge the generated video on its own — even if it's not equivalent,
   it can still be plausible).
4. Move to the next pair.

Estimated time: ~30-60 seconds per pair = 50-100 minutes total.

## What this is for

The equivalence labels will be used to **calibrate automated metrics**
(DINOv2 cosine + X-CLIP cosine) against human judgement: we'll compute
correlation / AUC / agreement between human binary equivalence and the
cosine similarities, to determine whether the automated metrics are a
fair proxy.

The plausibility labels are an **independent quality measurement** — they
don't depend on the ground truth and tell us how often the model produces
output that *looks* like real physics regardless of whether it's the right
physics.

## Files in this package

- `README.md` (this file)
- `labels_template.csv` — fill this in
- `INDEX.txt` — quick reference list
- `pair_000_*/` through `pair_{last_idx}_*/` — the {n} video pairs

When complete, save the filled CSV (and any annotated notes) and return.
"""


if __name__ == "__main__":
    main()
