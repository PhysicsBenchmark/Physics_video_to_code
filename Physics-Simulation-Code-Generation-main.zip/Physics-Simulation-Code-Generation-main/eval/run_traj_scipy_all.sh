#!/bin/bash
# Run trajectory similarity (CoTracker3) on scipy pairs for all 10 models.
# Sequential per model, 2 parallel shards per model on cuda:1.
# NOTE: --resume default ON, so already-completed rows are skipped automatically.
# Removed `set -e` so a crash on one model doesn't kill the whole chain.
cd /scr/adityag6/Physics-Simulation-Code-Generation
PY=/home/adityag6/miniconda3/envs/py310/bin/python
DEVICE=cuda:1

MODELS=(
  grok_4_fast_reasoning nova_2_lite
  qwen3vl_30b_a3b internvl3_5_30b_a3b gemma_3_12b_it glm_4_1v_9b_thinking pixtral_12b
)

for M in "${MODELS[@]}"; do
    echo "=== $M start $(date +%H:%M:%S) ==="
    $PY eval/score_trajectory.py --model $M --engine scipy --device $DEVICE \
        --shard 0 --num-shards 2 > /tmp/traj_${M}_s0.log 2>&1 &
    P0=$!
    $PY eval/score_trajectory.py --model $M --engine scipy --device $DEVICE \
        --shard 1 --num-shards 2 > /tmp/traj_${M}_s1.log 2>&1 &
    P1=$!
    wait $P0; rc0=$?
    wait $P1; rc1=$?
    echo "=== $M done s0=$rc0 s1=$rc1 $(date +%H:%M:%S) ==="
done
echo "ALL DONE"
