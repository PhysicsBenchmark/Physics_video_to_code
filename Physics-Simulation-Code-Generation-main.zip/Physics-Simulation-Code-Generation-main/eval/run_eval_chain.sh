#!/bin/bash
# Eval chain: pixtral → gemini, full per-model pipeline (recover + eval + REPORT + KAPPA).
set -e
cd /scr/adityag6/Physics-Simulation-Code-Generation
PY=/home/adityag6/miniconda3/envs/py310/bin/python

for M in pixtral_12b gemini_2_5_pro; do
    echo "=== START eval $M $(date +%H:%M:%S) ==="
    $PY eval/recover_inference_outputs.py --models $M 2>&1 | tail -5
    mkdir -p eval_outputs/$M
    $PY eval/run_dataset.py --models $M --concurrency 128 --runnability_timeout 120 \
        > eval_outputs/$M/run.log 2>&1
    echo "=== eval $M finished $(date +%H:%M:%S) ==="
    $PY eval/make_model_report.py $M
    $PY eval/compute_kappa.py $M
    echo "=== REPORT+KAPPA $M done $(date +%H:%M:%S) ==="
done
echo "EVAL CHAIN DONE"
