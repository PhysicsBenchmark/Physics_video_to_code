"""Per-parameter estimation error across all 10 models.

For each parameter name, computes the mean |relative error| when the model's
parsed_cot.parameters contains a name that also appears in the ground-truth
params.json for the same (engine, experiment, sample_id).

CAVEAT: the model invents its own parameter vocabulary (~7% name overlap with GT
overall), so any single parameter row here is measured from a limited subset of
(model, sample) pairs where the model happened to use the GT's name. This is
the honest lower bound — semantic name-matching would grow the coverage but was
out of scope.
"""
import csv
import json
import math
import statistics as st
from collections import defaultdict
from pathlib import Path

ROOT = Path("/scr/adityag6/Physics-Simulation-Code-Generation")
OUT = ROOT / "eval_outputs" / "_tables" / "param_error_report.csv"
OUT.parent.mkdir(exist_ok=True)

MODELS = ["gpt_5_mini", "gemini_2_5_pro", "claude_sonnet_4_6",
          "grok_4_fast_reasoning", "nova_2_lite",
          "qwen3vl_30b_a3b", "internvl3_5_30b_a3b", "gemma_3_12b_it",
          "glm_4_1v_9b_thinking", "pixtral_12b"]


def pred_value(v):
    """Model's parameters[name] can be a bare number OR {'value': x, ...}."""
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, dict) and "value" in v and isinstance(v["value"], (int, float)):
        return float(v["value"])
    return None


def load_ground_truth():
    gt = {}  # (engine, experiment, sample_id) -> {name: float}
    for eng in ("scipy", "kubric"):
        for exp_dir in (ROOT / "benchmarking_data" / eng).iterdir():
            for sid_dir in exp_dir.iterdir():
                p = sid_dir / "params.json"
                if not p.exists():
                    continue
                try:
                    d = json.load(open(p))
                except Exception:
                    continue
                if not isinstance(d, dict):
                    continue
                gt[(eng, exp_dir.name, sid_dir.name)] = {
                    k: float(v) for k, v in d.items()
                    if isinstance(v, (int, float))
                }
    return gt


def collect_errors():
    """param_name -> list of {rel_err, abs_err, model, key}"""
    gt = load_ground_truth()
    errors = defaultdict(list)
    n_pairs = 0
    n_matched = 0
    n_gt_total = 0

    for m in MODELS:
        path = ROOT / "inference_outputs" / m / "results.jsonl"
        with open(path) as f:
            for line in f:
                d = json.loads(line)
                cot = d.get("parsed_cot")
                if not isinstance(cot, dict):
                    continue
                params = cot.get("parameters")
                if not isinstance(params, dict):
                    continue
                key = (d["engine"], d["experiment"], d["sample_id"])
                gt_map = gt.get(key)
                if not gt_map:
                    continue
                n_pairs += 1
                n_gt_total += len(gt_map)
                for name, val in params.items():
                    if name not in gt_map:
                        continue
                    pv = pred_value(val)
                    if pv is None:
                        continue
                    gv = gt_map[name]
                    abs_err = abs(pv - gv)
                    denom = max(abs(gv), 1e-9)
                    # Handle GT=0 case (angles etc): relative error meaningless; use abs
                    rel_err = abs_err / denom if abs(gv) > 1e-6 else float("inf")
                    n_matched += 1
                    errors[name].append({
                        "rel_err": rel_err, "abs_err": abs_err,
                        "pred": pv, "gt": gv,
                        "model": m, "engine": key[0],
                        "exp": key[1], "sid": key[2],
                    })
    return errors, n_pairs, n_matched, n_gt_total


def main():
    errors, n_pairs, n_matched, n_gt_total = collect_errors()
    print(f"Total (model x sample) pairs with cot.parameters + GT: {n_pairs}")
    print(f"Total name-matched (pred name in GT):                   {n_matched}")
    print(f"Total GT numeric params:                                {n_gt_total}")
    print(f"Overall match coverage: {100*n_matched/max(n_gt_total,1):.1f}%")
    print()

    # Aggregate per parameter name
    rows = []
    for name, obs in errors.items():
        rels = [o["rel_err"] for o in obs if math.isfinite(o["rel_err"])]
        abss = [o["abs_err"] for o in obs]
        n = len(obs)
        n_finite = len(rels)
        within20 = sum(1 for r in rels if r <= 0.20)
        within50 = sum(1 for r in rels if r <= 0.50)
        rows.append({
            "param": name,
            "n_obs": n,
            "n_models_used_it": len({o["model"] for o in obs}),
            "mean_rel_err": st.mean(rels) if rels else float("nan"),
            "median_rel_err": st.median(rels) if rels else float("nan"),
            "mean_abs_err": st.mean(abss),
            "within_pm20pct": within20 / n_finite if n_finite else float("nan"),
            "within_pm50pct": within50 / n_finite if n_finite else float("nan"),
        })

    # Rank by mean_rel_err ascending among params with >=20 observations
    rows.sort(key=lambda r: (r["n_obs"] < 20, r["mean_rel_err"]))

    with open(OUT, "w") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f"Wrote per-param CSV to: {OUT}")
    print()

    print("=" * 80)
    print("PARAMS ESTIMATED BEST — sorted by mean rel-err (n_obs>=30)")
    print("=" * 80)
    print(f"{'param':<24s} {'n':>4s} {'mods':>4s} {'mean_rel':>8s} {'median':>8s} {'±20%':>7s}")
    print("-" * 80)
    top = [r for r in rows if r["n_obs"] >= 30][:25]
    for r in top:
        print(f"{r['param']:<24s} {r['n_obs']:>4d} {r['n_models_used_it']:>4d} "
              f"{r['mean_rel_err']:>8.3f} {r['median_rel_err']:>8.3f} "
              f"{100*r['within_pm20pct']:>6.1f}%")

    print()
    print("=" * 80)
    print("PARAMS ESTIMATED WORST — sorted by mean rel-err DESC (n_obs>=30)")
    print("=" * 80)
    print(f"{'param':<24s} {'n':>4s} {'mods':>4s} {'mean_rel':>8s} {'median':>8s} {'±20%':>7s}")
    print("-" * 80)
    worst = sorted([r for r in rows if r["n_obs"] >= 30],
                   key=lambda r: -r["mean_rel_err"])[:25]
    for r in worst:
        print(f"{r['param']:<24s} {r['n_obs']:>4d} {r['n_models_used_it']:>4d} "
              f"{r['mean_rel_err']:>8.3f} {r['median_rel_err']:>8.3f} "
              f"{100*r['within_pm20pct']:>6.1f}%")

    print()
    print("=" * 80)
    print("MOST-USED PARAM NAMES (n_obs high) — with error stats")
    print("=" * 80)
    print(f"{'param':<24s} {'n':>4s} {'mods':>4s} {'mean_rel':>8s} {'median':>8s} {'±20%':>7s}")
    print("-" * 80)
    heavy = sorted(rows, key=lambda r: -r["n_obs"])[:25]
    for r in heavy:
        print(f"{r['param']:<24s} {r['n_obs']:>4d} {r['n_models_used_it']:>4d} "
              f"{r['mean_rel_err']:>8.3f} {r['median_rel_err']:>8.3f} "
              f"{100*r['within_pm20pct']:>6.1f}%")


if __name__ == "__main__":
    main()
