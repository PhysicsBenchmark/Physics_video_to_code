#!/bin/bash
# Video similarity chain: gemma → claude, 2-GPU sharded each.
set -e
cd /scr/adityag6/Physics-Simulation-Code-Generation
export HF_HOME=/scr/adityag6/hf_cache
PY=/home/adityag6/miniconda3/envs/py310/bin/python

for M in gemma_3_12b_it claude_sonnet_4_6; do
    echo "=== START vsim $M $(date +%H:%M:%S) ==="
    $PY eval/score_video_similarity.py --models $M --device cuda:7 --shard 0 --num-shards 2 \
        > eval_outputs/$M/video_sim.log.s0 2>&1 &
    P0=$!
    $PY eval/score_video_similarity.py --models $M --device cuda:4 --shard 1 --num-shards 2 \
        > eval_outputs/$M/video_sim.log.s1 2>&1 &
    P1=$!
    wait $P0; rc0=$?
    wait $P1; rc1=$?
    echo "=== SCORE vsim $M done s0=$rc0 s1=$rc1 $(date +%H:%M:%S) ==="
    $PY eval/make_video_sim_report.py $M
    echo "=== REPORT vsim $M done $(date +%H:%M:%S) ==="
done
echo "VSIM CHAIN DONE"
