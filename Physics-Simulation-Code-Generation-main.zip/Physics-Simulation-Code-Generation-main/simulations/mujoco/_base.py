"""Shared MuJoCo/Sim2Reason dataset generation utilities."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import types
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError:  # pragma: no cover - dependency checked at runtime
    yaml = None  # type: ignore

PACKAGE_DIR = Path(__file__).resolve().parent
ROOT_DIR = PACKAGE_DIR.parents[1]
SIM2REASON_DIR = PACKAGE_DIR / "sim"

if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))
if SIM2REASON_DIR.exists() and str(PACKAGE_DIR) not in sys.path:
    sys.path.insert(0, str(PACKAGE_DIR))

from . import generate_mujoco_script  # noqa: E402
from .param_extractor import extract_raw_params  # noqa: E402
from .sim2reason_cot import build_cot_for_scene  # noqa: E402


def _json_safe(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {str(k): _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_json_safe(v) for v in obj]
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    try:
        import numpy as np
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, (np.integer, np.floating)):
            return obj.item()
    except ImportError:
        pass
    return str(obj)


def write_json(path: Path, data: Any) -> None:
    path.write_text(json.dumps(_json_safe(data), indent=2), encoding="utf-8")


def _install_sim2reason_import_stubs() -> None:
    """SceneGenerator only needs these optional modules for its Hydra CLI path."""
    if "hydra" not in sys.modules:
        hydra = types.ModuleType("hydra")

        def main(*_args, **_kwargs):
            def decorator(fn):
                return fn
            return decorator

        hydra.main = main
        sys.modules["hydra"] = hydra
    if "omegaconf" not in sys.modules:
        omegaconf = types.ModuleType("omegaconf")
        omegaconf.DictConfig = dict
        sys.modules["omegaconf"] = omegaconf
    if "ipdb" not in sys.modules:
        ipdb = types.ModuleType("ipdb")
        ipdb.set_trace = lambda *args, **kwargs: None
        sys.modules["ipdb"] = ipdb


def generate_scene_yaml(subtype: str, seed: int) -> dict[str, Any]:
    if yaml is None:
        raise ImportError("PyYAML is required to generate MuJoCo scenes")
    if not SIM2REASON_DIR.exists():
        raise FileNotFoundError(f"MuJoCo scene generator package not found: {SIM2REASON_DIR}")
    _install_sim2reason_import_stubs()
    from sim.scene_generator import SceneGenerator

    generator = SceneGenerator(subtype=subtype, seed=seed)
    return generator.generate_scene_yaml()


def generate_sample_for_subtype(
    subtype: str,
    seed: int,
    out_dir: str | Path,
    duration: float = 10.0,
    fps: int = 30,
    run_video: bool = True,
) -> dict[str, Any]:
    """Generate one MuJoCo sample with exactly the four dataset artifacts."""
    if yaml is None:
        raise ImportError("PyYAML is required to generate MuJoCo scenes")

    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="mujoco_scene_") as tmp:
        yaml_path = Path(tmp) / "scene_output.yaml"
        scene_yaml = generate_scene_yaml(subtype, seed)
        yaml_path.write_text(yaml.dump(scene_yaml, sort_keys=False), encoding="utf-8")

        code = generate_mujoco_script(yaml_path, duration=duration, fps=fps)
        (out_path / "simulation_code.py").write_text(code, encoding="utf-8")

        _entity_type, params = extract_raw_params(yaml_path)
        write_json(out_path / "params.json", params)

        _cot_entity_type, cot, _ = build_cot_for_scene(yaml_path)
        write_json(out_path / "cot.json", cot)

    video_path = out_path / "video.mp4"
    if run_video:
        env = os.environ.copy()
        if "MUJOCO_GL" not in env and not env.get("DISPLAY"):
            env["MUJOCO_GL"] = "egl"
        subprocess.run([sys.executable, "simulation_code.py"], cwd=out_path, check=True, env=env)
        generated = out_path / "simulation.mp4"
        if generated.exists():
            if video_path.exists():
                video_path.unlink()
            generated.rename(video_path)
    elif not video_path.exists():
        video_path.touch()

    # Keep sample folders restricted to the four requested files.
    for child in out_path.iterdir():
        if child.name not in {"simulation_code.py", "cot.json", "params.json", "video.mp4"}:
            if child.is_dir():
                shutil.rmtree(child)
            else:
                child.unlink()

    return {
        "sample_dir": str(out_path),
        "simulation": subtype,
        "seed": seed,
        "files": {
            "video": "video.mp4",
            "code": "simulation_code.py",
            "cot": "cot.json",
            "params": "params.json",
        },
    }
