"""
sim2reason_cot.py
=================
Chain-of-Thought (CoT) JSON generator for Pipeline B (Sim2Reason / MuJoCo) scenes.

For every Sim2Reason ``scene_output.yaml`` the step-3 post-processor can call
``build_cot_for_scene(yaml_path)`` to obtain a dict whose schema mirrors the
Pipeline-A CoT files (e.g. ``dataset/billiard_2d/000/cot.json``):

    simulation, category, physical_observation, physical_law,
    modeling_assumptions, ode_system, derivation_steps,
    numerical_method, code_validation, expected_behavior, parameters

One template function per Sim2Reason entity family lives in ``COT_REGISTRY``.
Each template takes the *raw* params dict (exactly what Sim2Reason stored in
the YAML, after minimal key normalisation) plus the full entity list for the
scene (so composite scenes such as pulleys can see every mass/prism entity).
"""

from __future__ import annotations
import math
from pathlib import Path
from typing import Any

from .param_extractor import _load_yaml, _normalize_for_builder


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _f(val: Any, default: float = 0.0) -> float:
    """Robust scalar-from-anything conversion (handles lists / None)."""
    if val is None:
        return default
    if isinstance(val, (list, tuple)):
        return float(val[0]) if val else default
    try:
        return float(val)
    except (TypeError, ValueError):
        return default


def _param_entry(value, unit: str = "", description: str = "") -> dict:
    return {"value": value, "unit": unit, "description": description}


_MUJOCO_NUMERICAL_METHOD = {
    "solver": "MuJoCo mj_step (semi-implicit Euler by default; RK4 is used for "
              "gravity-disabled scenes with external force loops).",
    "timestep": "0.002-0.01 s depending on scene (set in <option timestep=.../>).",
    "frame_rate": "30 fps (steps_per_frame = 1/(fps*timestep)).",
    "note": "Contact stiffness and restitution are encoded via the <solref> "
            "and <solimp> attributes; per-pair coefficients of restitution use "
            "negative solref (time-constant -> stiffness) values.",
}


# ─────────────────────────────────────────────────────────────────────────────
# 1. Projectile / ThrowingMotionEntity
# ─────────────────────────────────────────────────────────────────────────────

def cot_projectile(raw: dict, _entities: list[dict]) -> dict:
    h0      = _f(raw.get("initial_height", raw.get("y0", 1.0)), 1.0)
    v0      = _f(raw.get("initial_speed",  raw.get("v0", 5.0)), 5.0)
    ang_deg = _f(raw.get("initial_angle",  raw.get("theta_deg", 45.0)), 45.0)
    m       = _f(raw.get("ball_mass",      raw.get("mass", 1.0)), 1.0)
    r       = _f(raw.get("ball_radius",    raw.get("radius", 0.1)), 0.1)
    mu      = _f(raw.get("coefficient_of_friction", raw.get("mu", 0.0)), 0.0)
    ang_r   = math.radians(ang_deg)
    vx0     = v0 * math.cos(ang_r)
    vz0     = v0 * math.sin(ang_r)
    g       = 9.8
    t_peak  = max(vz0 / g, 0.0)
    h_peak  = h0 + vz0 * t_peak - 0.5 * g * t_peak ** 2
    t_land  = (vz0 + math.sqrt(vz0 ** 2 + 2 * g * h0)) / g if (vz0 ** 2 + 2 * g * h0) >= 0 else 0.0
    x_range = vx0 * t_land

    return {
        "simulation": "projectile_motion",
        "category": "kinematics",
        "physical_observation": (
            f"A ball of mass m={m:.3f} kg, radius r={r:.3f} m, is launched from height "
            f"h0={h0:.3f} m with speed v0={v0:.3f} m/s at angle {ang_deg:.2f} deg above horizontal. "
            f"It traces a parabolic arc under uniform gravity until it strikes the ground "
            f"(friction coefficient with ground mu={mu:.3f})."
        ),
        "physical_law": {
            "name": "Newton's second law in a uniform gravitational field",
            "statement": "With no air drag, the projectile has constant horizontal velocity and "
                         "constant vertical acceleration -g.",
            "formula": "m * a = -m * g * z_hat  =>  x(t)=x0+vx0*t,  z(t)=h0+vz0*t-(1/2)*g*t^2",
        },
        "modeling_assumptions": [
            "Point-mass / rigid sphere under uniform gravity (g=9.8 m/s^2).",
            "No air drag (drag coefficient set to 0 in the MuJoCo model).",
            f"Launch decomposed into vx0=v0*cos(theta)={vx0:.3f} m/s, "
            f"vz0=v0*sin(theta)={vz0:.3f} m/s.",
            "Contact with the ground resolved by MuJoCo's rigid-contact solver "
            f"(Coulomb friction coeff mu={mu:.3f}).",
        ],
        "ode_system": {
            "state_variables": ["x (m)", "z (m)", "vx (m/s)", "vz (m/s)"],
            "equations_latex": [
                "dx/dt = vx",
                "dz/dt = vz",
                "dvx/dt = 0",
                "dvz/dt = -g",
            ],
            "equations_python": [
                "dx_dt = vx",
                "dz_dt = vz",
                "dvx_dt = 0.0",
                "dvz_dt = -g",
            ],
        },
        "derivation_steps": [
            "Choose a 2-D frame with x horizontal (ground) and z vertical.",
            f"Decompose the launch velocity: vx0 = v0*cos(theta) = {vx0:.3f} m/s, "
            f"vz0 = v0*sin(theta) = {vz0:.3f} m/s.",
            "Newton II gives a_x = 0 (no horizontal force) and a_z = -g.",
            "Integrate twice:  x(t) = x0 + vx0*t,  z(t) = h0 + vz0*t - (1/2)*g*t^2.",
            f"Time to apex: t_peak = vz0/g = {t_peak:.3f} s;  apex height = {h_peak:.3f} m.",
            f"Landing time (z=0): t_land = (vz0 + sqrt(vz0^2 + 2*g*h0))/g = {t_land:.3f} s; "
            f"horizontal range = vx0*t_land = {x_range:.3f} m.",
        ],
        "numerical_method": _MUJOCO_NUMERICAL_METHOD,
        "code_validation": {
            "ode_source": "Newton II in a uniform gravity field; MuJoCo <option gravity='0 0 -9.8'/>.",
            "conservation_check": "Mechanical energy E = 0.5*m*(vx^2+vz^2) + m*g*z conserved "
                                  "in free flight; decreases only during ground contact impulses.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Parabolic trajectory; apex at ~({vx0*t_peak:.2f} m, {h_peak:.2f} m).",
            f"Horizontal range before first bounce: ~{x_range:.2f} m.",
            "Subsequent bounces decay under Coulomb friction / restitution.",
        ],
        "parameters": {
            "m":       _param_entry(m,       "kg",    "ball mass"),
            "r":       _param_entry(r,       "m",     "ball radius"),
            "h0":      _param_entry(h0,      "m",     "launch height above ground"),
            "v0":      _param_entry(v0,      "m/s",   "launch speed"),
            "angle":   _param_entry(ang_deg, "deg",   "launch angle above horizontal"),
            "vx0":     _param_entry(vx0,     "m/s",   "initial horizontal velocity"),
            "vz0":     _param_entry(vz0,     "m/s",   "initial vertical velocity"),
            "mu":      _param_entry(mu,      "",      "ground friction coefficient"),
            "g":       _param_entry(g,       "m/s^2", "gravitational acceleration"),
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# 2. Inclined plane (TwoSideMassPlane, MassPrismPlaneEntity, StackedMassPlane,
#    MassBoxPlaneEntity)
# ─────────────────────────────────────────────────────────────────────────────

def cot_inclined_plane(raw: dict, entities: list[dict]) -> dict:
    # Collect the slope angle from any entity that carries one
    slope_deg = _f(raw.get("plane_slope", raw.get("theta_deg", 0.0)), 0.0)
    if slope_deg == 0.0:
        for ent in entities:
            p = ent.get("parameters", ent.get("params", {}))
            for k in ("plane_slope", "prism_left_slope", "prism_right_slope"):
                if k in p and _f(p[k]) != 0.0:
                    slope_deg = _f(p[k])
                    break
            if slope_deg != 0.0:
                break
    mu = _f(raw.get("coefficient_of_friction", raw.get("mu", 0.0)), 0.0)
    mass_values = raw.get("mass_values") or [raw.get("block_mass_value", raw.get("m", 1.0))]
    m = _f(mass_values[0] if mass_values else 1.0, 1.0)
    theta = math.radians(slope_deg)
    g = 9.8
    tan_t = math.tan(theta) if abs(math.cos(theta)) > 1e-9 else float("inf")
    mu_crit = abs(tan_t)
    a_slide = g * (math.sin(theta) - mu * math.cos(theta)) if mu < mu_crit else 0.0

    return {
        "simulation": "inclined_plane",
        "category": "mechanics",
        "physical_observation": (
            f"Block of mass m={m:.3f} kg rests on an incline of angle theta={slope_deg:.2f} deg "
            f"with Coulomb friction coefficient mu={mu:.3f}. Gravity pulls it along the slope; "
            f"friction resists motion."
        ),
        "physical_law": {
            "name": "Newton's second law with Coulomb friction on an incline",
            "statement": "Decompose weight into slope-parallel and slope-perpendicular components; "
                         "parallel gravity accelerates the block, friction opposes motion with "
                         "magnitude mu*N, N = m*g*cos(theta).",
            "formula": "m*ddx = -m*g*sin(theta) - mu*m*g*cos(theta)*sign(dx/dt)  (kinetic regime)",
        },
        "modeling_assumptions": [
            "Rigid block on a rigid inclined plane (no deformation).",
            "Uniform gravity g=9.8 m/s^2 in -z world direction.",
            "Coulomb friction with single coefficient (no stick-slip distinction in MuJoCo default).",
            "Plane tilted about the world-y axis by theta.",
        ],
        "ode_system": {
            "state_variables": [
                "x (position along slope, m)",
                "v = dx/dt (m/s)",
            ],
            "equations_latex": [
                "dx/dt = v",
                "dv/dt = -g*sin(theta) - mu*g*cos(theta)*sign(v)   (|v| > eps)",
                "dv/dt = 0                                      (|v| <= eps, |tan(theta)| <= mu)",
            ],
            "equations_python": [
                "dx_dt = v",
                "dv_dt = -g * math.sin(theta) - mu * g * math.cos(theta) * np.sign(v)",
            ],
        },
        "derivation_steps": [
            "Coordinate x along the slope (positive up-slope).",
            "Decompose gravity: parallel = -m*g*sin(theta), perpendicular = -m*g*cos(theta).",
            "Normal force N = m*g*cos(theta) (contact preserved).",
            "Kinetic friction f_k = mu*N = mu*m*g*cos(theta), directed opposite to v.",
            f"Critical friction to hold the block at rest: mu_crit = tan(theta) = {mu_crit:.4f}.",
            "Newton II along slope: m*ddx = -m*g*sin(theta) - mu*m*g*cos(theta)*sign(dx/dt).",
            f"Cancel m: ddx = -g*sin(theta) - mu*g*cos(theta)*sign(dx/dt) "
            f"= {a_slide:.4f} m/s^2 (current sliding regime).",
        ],
        "numerical_method": _MUJOCO_NUMERICAL_METHOD,
        "code_validation": {
            "ode_source": "Newton II on an incline + Coulomb friction; MuJoCo rigid-contact solver.",
            "energy_check": "E = 0.5*m*v^2 + m*g*sin(theta)*x decreases at rate "
                            "-mu*m*g*cos(theta)*|v| (friction dissipation).",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"mu_crit = tan(theta) = {mu_crit:.4f};  "
            + ("block slides (friction insufficient to hold)." if mu < mu_crit
               else "block stays at rest or comes to rest."),
            f"Sliding deceleration: |a| = g*(sin(theta) + mu*cos(theta)) = "
            f"{g*(math.sin(theta) + mu*math.cos(theta)):.3f} m/s^2.",
        ],
        "parameters": {
            "m":        _param_entry(m,         "kg",    "block mass"),
            "theta":    _param_entry(theta,     "rad",   "slope angle"),
            "theta_deg":_param_entry(slope_deg, "deg",   "slope angle"),
            "mu":       _param_entry(mu,        "",      "Coulomb friction coefficient"),
            "g":        _param_entry(g,         "m/s^2", "gravitational acceleration"),
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# 3. Pulley / Atwood machine (MassWithFixedPulley variants, MassPrismPulleyPlane)
# ─────────────────────────────────────────────────────────────────────────────

def cot_pulley(raw: dict, entities: list[dict]) -> dict:
    # Gather masses across all pulley/mass entities
    masses = []
    slopes = []
    for ent in entities:
        p = ent.get("parameters", ent.get("params", {}))
        if "mass_values" in p and isinstance(p["mass_values"], list):
            masses.extend(float(m) for m in p["mass_values"])
        if "block_left_mass_value" in p:
            masses.append(float(p["block_left_mass_value"]))
        if "block_right_mass_value" in p:
            masses.append(float(p["block_right_mass_value"]))
        if "prism_mass_value" in p:
            masses.append(float(p["prism_mass_value"]))
        for k in ("plane_slope", "prism_left_slope", "prism_right_slope"):
            if k in p and _f(p[k]) != 0.0:
                slopes.append(_f(p[k]))
    if not masses:
        masses = [_f(raw.get("m1", 1.5)), _f(raw.get("m2", 2.0))]
    m1 = masses[0]
    m2 = masses[1] if len(masses) > 1 else m1
    g = 9.8
    a_atwood = (m2 - m1) * g / (m1 + m2) if (m1 + m2) > 0 else 0.0
    T_atwood = 2 * m1 * m2 * g / (m1 + m2) if (m1 + m2) > 0 else 0.0

    return {
        "simulation": "pulley_atwood",
        "category": "mechanics",
        "physical_observation": (
            f"Two (or more) masses coupled by an inextensible string over one or more pulleys. "
            f"Primary masses: m1={m1:.3f} kg, m2={m2:.3f} kg"
            + (f"; slope(s) present (deg): {[round(s,2) for s in slopes]}" if slopes else "")
            + ". The heavier side accelerates downward; the lighter side accelerates upward."
        ),
        "physical_law": {
            "name": "Newton's second law + constraint from an inextensible string",
            "statement": "Each mass obeys m_i * a_i = T - m_i*g (or similar) along its direction "
                         "of motion; the string imposes |a_1| = |a_2| (equal-and-opposite for a "
                         "single fixed pulley).",
            "formula": "a = (m2 - m1)*g / (m1 + m2),   T = 2*m1*m2*g / (m1 + m2)  "
                       "(ideal Atwood machine)",
        },
        "modeling_assumptions": [
            "Inextensible, massless string; tension uniform along the string.",
            "Frictionless, massless pulley (MuJoCo <tendon><fixed>...</fixed></tendon>).",
            "Uniform gravity g=9.8 m/s^2.",
            "Each mass's vertical DOF is a <joint type='slide'/> along world-z.",
        ],
        "ode_system": {
            "state_variables": [
                "z_1 (left mass height, m)",
                "z_2 (right mass height, m)",
                "v_1, v_2 (corresponding velocities, m/s)",
            ],
            "equations_latex": [
                "m1*a1 = T - m1*g",
                "m2*a2 = T - m2*g   with  a2 = -a1  (string constraint)",
                "=>  a1 = (m2 - m1)*g / (m1 + m2)",
            ],
            "equations_python": [
                "a = (m2 - m1) * g / (m1 + m2)",
                "T = 2 * m1 * m2 * g / (m1 + m2)",
            ],
        },
        "derivation_steps": [
            "Let z_1, z_2 be the two masses' heights, string total length L.",
            "String constraint: z_1 + z_2 = const  =>  a_2 = -a_1.",
            "Free-body diagram on m1: m1*a1 = T - m1*g  (T is string tension).",
            "Free-body diagram on m2: m2*a2 = T - m2*g  =>  -m2*a1 = T - m2*g.",
            "Add the two equations to eliminate T: (m1 - m2)*a1 = -(m2 - m1)*g.",
            f"Solve: a1 = (m2 - m1)*g / (m1 + m2) = {a_atwood:.4f} m/s^2, "
            f"T = 2*m1*m2*g/(m1+m2) = {T_atwood:.4f} N.",
            "For composite scenes (movable pulleys, inclined prisms) the same procedure applies "
            "with additional constraint equations; MuJoCo resolves these via its tendon solver.",
        ],
        "numerical_method": _MUJOCO_NUMERICAL_METHOD,
        "code_validation": {
            "ode_source": "Newton II per mass + string constraint.",
            "string_constraint": "MuJoCo <tendon><fixed> with coefficients summing joint positions "
                                 "enforces z1 + z2 = const.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Ideal two-mass Atwood acceleration: a = {a_atwood:.4f} m/s^2.",
            f"Ideal two-mass Atwood tension:     T = {T_atwood:.4f} N.",
            "Heavier mass accelerates downward; lighter mass accelerates upward.",
        ],
        "parameters": {
            "m1":    _param_entry(m1,  "kg",    "primary left mass"),
            "m2":    _param_entry(m2,  "kg",    "primary right mass"),
            "all_masses": _param_entry(masses, "kg", "every mass/prism value extracted from the scene"),
            "slopes_deg": _param_entry(slopes, "deg", "any non-zero plane/prism slope angles"),
            "g":     _param_entry(g,   "m/s^2", "gravitational acceleration"),
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# 4. Collision (TwoDCollisionPlane, ComplexCollisionPlane)
# ─────────────────────────────────────────────────────────────────────────────

def cot_collision(raw: dict, _entities: list[dict]) -> dict:
    slope_deg = _f(raw.get("plane_slope", 0.0), 0.0)

    # ComplexCollisionPlane stores per-body dicts; TwoDCollisionPlane stores parallel lists
    collision_bodies = raw.get("collision_bodies")
    if collision_bodies:
        mass_values = [_f(b.get("mass_value", 1.0)) for b in collision_bodies]
        positions   = [_f(b.get("position",   0.0)) for b in collision_bodies]
        velocities  = [_f(b.get("init_velocity", 0.0)) for b in collision_bodies]
    else:
        mass_values = [float(m) for m in raw.get("mass_values", [1.0, 1.0])]
        positions   = raw.get("mass_positions", [[-1.0, 0.0], [1.0, 0.0]])
        velocities  = raw.get("mass_initial_velocities", [[1.0, 0.0], [-1.0, 0.0]])

    rc_list = raw.get("resolution_coefficients") or raw.get("resolution_coefficient_list") or []
    # rc_list entries can be either a scalar or [i, j, e]
    e_values = []
    for e in rc_list:
        if isinstance(e, (list, tuple)) and len(e) >= 3:
            e_values.append(_f(e[2]))
        else:
            e_values.append(_f(e))
    e_mean = sum(e_values) / len(e_values) if e_values else 1.0

    n = len(mass_values)
    total_p = 0.0
    total_ke = 0.0
    for i, mi in enumerate(mass_values):
        if isinstance(velocities[i], (list, tuple)):
            vx, vy = float(velocities[i][0]), float(velocities[i][1])
        else:
            vx, vy = float(velocities[i]), 0.0
        total_p  += mi * vx
        total_ke += 0.5 * mi * (vx * vx + vy * vy)

    return {
        "simulation": "collision_2d",
        "category": "collision_contact",
        "physical_observation": (
            f"{n} rigid bodies on a "
            + ("tilted " if abs(slope_deg) > 1e-3 else "")
            + f"2D plane (slope={slope_deg:.2f} deg) exchange momentum through "
            f"circle-circle contacts. Coefficients of restitution per pair are in the range "
            f"{min(e_values) if e_values else 1.0:.3f} - {max(e_values) if e_values else 1.0:.3f} "
            f"(mean {e_mean:.3f})."
        ),
        "physical_law": {
            "name": "Conservation of momentum + Newton's coefficient of restitution in 2D",
            "statement": "Between collisions each body moves with constant velocity on the plane. "
                         "At each pairwise contact, momentum is exchanged along the contact normal; "
                         "normal relative velocity reverses scaled by e. Tangential velocity is "
                         "preserved (frictionless bodies).",
            "formula": "J = -(1+e) * v_rel_n / (1/m_i + 1/m_j),   dv_i = -(J/m_i)*n, "
                       "dv_j = +(J/m_j)*n",
        },
        "modeling_assumptions": [
            "Bodies are rigid spheres constrained to a 2-D plane (two <slide> joints).",
            "Frictionless ball-ball contact (condim=1 in the MuJoCo <default>).",
            "Per-pair restitution encoded via stiff-spring contact pairs (negative solref).",
            "No gravity along the plane (slope only tilts the world-z direction).",
        ],
        "ode_system": {
            "state_variables": [
                "x_i, y_i, vx_i, vy_i for i = 0..N-1  (4N state variables)"
            ],
            "equations_latex": [
                "dx_i/dt = vx_i,   dy_i/dt = vy_i",
                "dvx_i/dt = 0,     dvy_i/dt = 0    (between collisions)",
            ],
            "equations_python": [
                "# Free-flight integration, instantaneous impulse on contact:",
                "J = -(1.0 + e) * v_rel_n / (1.0/m_i + 1.0/m_j)",
                "v_i -= (J / m_i) * n",
                "v_j += (J / m_j) * n",
            ],
        },
        "derivation_steps": [
            "Free flight: bodies travel in straight lines on the plane.",
            "Detect overlap between every pair of spheres each sub-step.",
            "For an approaching pair: compute line-of-centers unit vector n, "
            "relative normal velocity v_rel_n = (v_j - v_i) . n.",
            "Impulse magnitude J = -(1+e) * v_rel_n / (1/m_i + 1/m_j).",
            "Apply dv_i = -(J/m_i)*n, dv_j = +(J/m_j)*n.  Correct overlap by mass-weighted "
            "positional separation.",
            "MuJoCo's contact solver reproduces this via stiff-spring normal contacts; the "
            "'e' per pair is encoded in <contact><pair solref='-k 0'/></contact>.",
        ],
        "numerical_method": _MUJOCO_NUMERICAL_METHOD,
        "code_validation": {
            "ode_source": "Linear momentum conservation + Newton's restitution.",
            "conservation_check": "Total momentum P = sum(m_i * v_i) conserved except for wall "
                                  "impulses; total KE decreases when any e < 1.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Initial total momentum (x-component) = {total_p:.3f} kg*m/s.",
            f"Initial total kinetic energy       = {total_ke:.3f} J.",
            "KE decreases on every collision with e < 1; momentum preserved.",
        ],
        "parameters": {
            "N":           _param_entry(n,            "",      "number of colliding bodies"),
            "mass_values": _param_entry(mass_values,  "kg",    "mass of each body"),
            "positions":   _param_entry(positions,    "m",     "initial position of each body"),
            "velocities":  _param_entry(velocities,   "m/s",   "initial velocity of each body"),
            "e_values":    _param_entry(e_values,     "",      "coefficient of restitution per pair"),
            "e_mean":      _param_entry(e_mean,       "",      "mean restitution"),
            "plane_slope": _param_entry(slope_deg,    "deg",   "tilt of the plane about world-y"),
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# 5. Spring-block (SpringBlockEntity, SpringMassPlaneEntity)
# ─────────────────────────────────────────────────────────────────────────────

def cot_spring_block(raw: dict, _entities: list[dict]) -> dict:
    k_list = raw.get("stiffnesses") or [_f(c.get("k", 5.0)) for c in raw.get("spring_configs", [])]
    if not k_list:
        k_list = [_f(raw.get("spring_constant", raw.get("k", 5.0)), 5.0)]
    k_list = [float(k) for k in k_list]

    len_list = raw.get("original_lengths") or [_f(c.get("original_length", 1.0))
                                                for c in raw.get("spring_configs", [])]
    if not len_list:
        len_list = [1.0] * len(k_list)

    mass_list = raw.get("mass_values") or [_f(raw.get("mass", raw.get("m", 1.0)), 1.0)]
    mass_list = [float(m) for m in mass_list]
    m = mass_list[0]
    k = k_list[0]

    b = _f(raw.get("damping", 0.2), 0.2)
    omega0 = math.sqrt(k / m) if m > 0 else 0.0
    T = 2 * math.pi / omega0 if omega0 > 0 else float("inf")
    zeta = b / (2 * m * omega0) if (m > 0 and omega0 > 0) else 0.0
    if zeta < 1:
        regime = "underdamped (decaying oscillation)"
    elif abs(zeta - 1) < 0.02:
        regime = "critically damped"
    else:
        regime = "overdamped"

    return {
        "simulation": "spring_mass",
        "category": "oscillation",
        "physical_observation": (
            f"{len(mass_list)} block(s) connected by {len(k_list)} linear spring(s). "
            f"Primary block mass m={m:.3f} kg; primary spring constant k={k:.3f} N/m; "
            f"damping b={b:.3f} N*s/m. Motion is {regime}."
        ),
        "physical_law": {
            "name": "Newton II + Hooke's law + viscous damping",
            "statement": "Spring force is -k*(u - L_rest); viscous damping force is -b*v; "
                         "Newton II gives m*d2u/dt2 = F_spring + F_damp + F_external.",
            "formula": "m*ddu + b*du + k*u = 0   =>   ddu = -(k/m)*u - (b/m)*du",
        },
        "modeling_assumptions": [
            "Each spring is linear (Hookean) with natural length L_rest.",
            "Damping linear-viscous in the relative velocity along the spring axis.",
            "Blocks rigid (<geom type='box'/>) sliding on a frictionless plane.",
            "Springs implemented via MuJoCo <tendon><spatial springlength='...' stiffness='k' "
            "damping='b'/>.",
        ],
        "ode_system": {
            "state_variables": ["u_i (block displacement, m)", "v_i = du_i/dt (m/s)"],
            "equations_latex": [
                "du/dt = v",
                "dv/dt = -(k/m) * u - (b/m) * v   (1-DOF case)",
            ],
            "equations_python": [
                "du_dt = v",
                "dv_dt = -(k / m) * u - (b / m) * v",
            ],
        },
        "derivation_steps": [
            "Let u = x - x_eq (displacement from the spring's equilibrium position).",
            "Hooke's law: F_spring = -k * u.",
            "Viscous damping: F_damp = -b * v.",
            "Newton II: m * ddu = -k * u - b * v.",
            f"Divide by m: ddu = -(k/m) * u - (b/m) * v  (omega0 = sqrt(k/m) = {omega0:.3f} rad/s).",
            f"Damping ratio zeta = b/(2*m*omega0) = {zeta:.4f} -> {regime}.",
            "For multi-block systems each block's equation has terms from every spring connected "
            "to it (coupled linear ODE system).",
        ],
        "numerical_method": _MUJOCO_NUMERICAL_METHOD,
        "code_validation": {
            "ode_source": "Newton II + Hooke's law; MuJoCo tendon spring.",
            "energy_check": "E = 0.5*m*v^2 + 0.5*k*u^2 decreases monotonically when b>0.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Natural angular frequency (1-DOF mode) omega0 = {omega0:.3f} rad/s.",
            f"Natural period (undamped) T0 = {T:.3f} s." if math.isfinite(T)
            else "Undamped period undefined (k=0 or m=0).",
            f"Damping ratio zeta = {zeta:.4f} -> {regime}.",
        ],
        "parameters": {
            "masses":         _param_entry(mass_list, "kg",    "block masses"),
            "k_values":       _param_entry(k_list,    "N/m",   "spring stiffnesses"),
            "rest_lengths":   _param_entry(len_list,  "m",     "spring natural lengths"),
            "m_primary":      _param_entry(m,         "kg",    "primary block mass"),
            "k_primary":      _param_entry(k,         "N/m",   "primary spring constant"),
            "b":              _param_entry(b,         "N*s/m", "viscous damping"),
            "omega0":         _param_entry(omega0,    "rad/s", "natural angular frequency"),
            "zeta":           _param_entry(zeta,      "",      "damping ratio"),
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# 6. Pendulum (PendulumEntity)
# ─────────────────────────────────────────────────────────────────────────────

def cot_pendulum(raw: dict, _entities: list[dict]) -> dict:
    L      = _f(raw.get("rope_length", raw.get("length", raw.get("L", 1.0))), 1.0)
    m      = _f(raw.get("mass_value",  raw.get("mass",   raw.get("m", 1.0))), 1.0)
    theta0 = raw.get("angle", raw.get("init_angle", raw.get("theta0", 0.5)))
    theta0 = _f(theta0, 0.5)
    # Sim2Reason stores angle in degrees if it looks > pi
    if abs(theta0) > math.pi:
        theta0_rad = math.radians(theta0)
    else:
        theta0_rad = theta0
    b = _f(raw.get("damping", 0.1), 0.1)
    g = 9.8
    omega_nat = math.sqrt(g / L) if L > 0 else 0.0
    T_small = 2 * math.pi / omega_nat if omega_nat > 0 else float("inf")
    mlsq = m * L * L
    zeta = b / (2 * mlsq * omega_nat) if (mlsq > 0 and omega_nat > 0) else 0.0

    return {
        "simulation": "simple_pendulum",
        "category": "oscillation",
        "physical_observation": (
            f"A point mass m={m:.3f} kg hangs from a massless rod of length L={L:.3f} m, "
            f"swinging in a vertical plane from a fixed pivot. Initial angle theta0="
            f"{theta0_rad:.3f} rad ({math.degrees(theta0_rad):.1f} deg); "
            f"angular damping b={b:.3f} kg*m^2/s."
        ),
        "physical_law": {
            "name": "Newton's second law for rotational motion (tau = I * alpha)",
            "statement": "Net torque about a fixed axis equals the moment of inertia times the "
                         "angular acceleration.",
            "formula": "I * ddtheta = -m*g*L*sin(theta) - b*dtheta/dt   with  I = m*L^2",
        },
        "modeling_assumptions": [
            "Point mass at distance L from the pivot (massless rod).",
            "Uniform gravity g=9.8 m/s^2 acting downward.",
            "Linear viscous damping about the pivot axis (<joint damping='b'/>).",
            "Plane swing about the world-y axis (<joint type='hinge' axis='0 1 0'/>).",
        ],
        "ode_system": {
            "state_variables": [
                "theta (angle from vertical, rad)",
                "omega = dtheta/dt (rad/s)",
            ],
            "equations_latex": [
                "dtheta/dt = omega",
                "domega/dt = -(g/L)*sin(theta) - (b/(m*L^2))*omega",
            ],
            "equations_python": [
                "dtheta_dt = omega",
                "domega_dt = -(g / L) * math.sin(theta) - (b / (m * L ** 2)) * omega",
            ],
        },
        "derivation_steps": [
            "Generalised coordinate theta = angle of rod from the downward vertical.",
            "Moment of inertia: I = m*L^2.",
            "Restoring gravity torque: tau_g = -m*g*L*sin(theta).",
            "Damping torque: tau_d = -b*omega.",
            "Newton II rotational: I*ddtheta = sum(tau)  =>  m*L^2 * ddtheta = -m*g*L*sin(theta) - b*omega.",
            "Divide by m*L^2: ddtheta = -(g/L)*sin(theta) - (b/(m*L^2))*omega.",
            f"Small-angle natural frequency: omega_nat = sqrt(g/L) = {omega_nat:.3f} rad/s, "
            f"period T0 = {T_small:.3f} s.",
        ],
        "numerical_method": _MUJOCO_NUMERICAL_METHOD,
        "code_validation": {
            "ode_source": "Newton II for rotation + small-angle consistency.",
            "energy_check": "Total mechanical energy E = 0.5*m*L^2*omega^2 + m*g*L*(1 - cos(theta)) "
                            "decreases monotonically when b > 0.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Small-angle period: T0 = 2*pi*sqrt(L/g) = {T_small:.3f} s.",
            f"Damping ratio: zeta = {zeta:.4f} -> "
            + ("underdamped (oscillation with decay)." if zeta < 1 else
               "overdamped (no oscillation)."),
        ],
        "parameters": {
            "L":       _param_entry(L,        "m",      "rod length"),
            "m":       _param_entry(m,        "kg",     "bob mass"),
            "theta0":  _param_entry(theta0_rad, "rad",  "initial angle from vertical"),
            "b":       _param_entry(b,        "kg*m^2/s", "angular damping"),
            "g":       _param_entry(g,        "m/s^2",  "gravitational acceleration"),
            "omega_nat": _param_entry(omega_nat, "rad/s", "small-angle natural frequency"),
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# 7. Rigid rotation (RigidRotationEntity)
# ─────────────────────────────────────────────────────────────────────────────

def cot_rigid_rotation(raw: dict, _entities: list[dict]) -> dict:
    bodies = raw.get("rigid_bodies", [])
    omega0 = _f(raw.get("omega0", raw.get("init_omega", 0.0)), 0.0)
    tau    = _f(raw.get("tau", raw.get("torque", 0.0)), 0.0)
    b      = _f(raw.get("damping", raw.get("b", 0.1)), 0.1)
    axis   = raw.get("axis", (raw.get("joint") or {}).get("axis", [0, 1, 0]))

    total_mass = sum(_f(body.get("mass", 0.0)) for body in bodies) if bodies else \
                 _f(raw.get("mass", raw.get("m", 1.0)), 1.0)

    return {
        "simulation": "rigid_rotation",
        "category": "mechanics",
        "physical_observation": (
            f"A rigid body assembly (total mass M={total_mass:.3f} kg) rotates about a fixed "
            f"axis {list(axis)} through the origin. Applied torque tau={tau:.3f} N*m, "
            f"damping b={b:.3f}, initial angular velocity omega0={omega0:.3f} rad/s."
        ),
        "physical_law": {
            "name": "Newton's second law for rotational motion",
            "statement": "About a fixed axis: tau_net = I * alpha, where I is the moment of "
                         "inertia about the axis.",
            "formula": "I * ddtheta = tau_applied - b * dtheta/dt",
        },
        "modeling_assumptions": [
            "Rigid-body assembly composed of primitive geoms (cylinder/box/sphere).",
            "Single hinge joint fixes the rotation axis.",
            "Applied torque is constant (optional MuJoCo <motor> actuator).",
            "Linear-viscous damping about the hinge.",
        ],
        "ode_system": {
            "state_variables": [
                "theta (rotation angle about axis, rad)",
                "omega = dtheta/dt (rad/s)",
            ],
            "equations_latex": [
                "dtheta/dt = omega",
                "domega/dt = (tau - b*omega) / I",
            ],
            "equations_python": [
                "dtheta_dt = omega",
                "domega_dt = (tau - b * omega) / I",
            ],
        },
        "derivation_steps": [
            "Choose the fixed rotation axis (hinge.axis).",
            "Compute I about that axis from the rigid-body geometry (MuJoCo does this "
            "from geom masses + shapes via mj_forward).",
            "Net torque: tau_net = tau_applied - b * omega.",
            "Newton II rotational: I * alpha = tau_net  =>  domega/dt = (tau - b*omega) / I.",
            "Steady-state angular velocity (if tau > 0 and b > 0): omega_ss = tau / b.",
        ],
        "numerical_method": _MUJOCO_NUMERICAL_METHOD,
        "code_validation": {
            "ode_source": "Newton II rotational; MuJoCo auto-computes I from geom mass distribution.",
            "energy_check": "Without applied torque, kinetic energy 0.5*I*omega^2 decreases "
                            "monotonically when b > 0.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            "Angular velocity relaxes exponentially when tau = 0 and b > 0.",
            "With constant tau and b>0, omega -> tau/b at steady state.",
        ],
        "parameters": {
            "total_mass": _param_entry(total_mass, "kg",     "total rotator mass"),
            "omega0":     _param_entry(omega0,     "rad/s",  "initial angular velocity"),
            "tau":        _param_entry(tau,        "N*m",    "applied torque"),
            "b":          _param_entry(b,          "N*m*s",  "angular damping"),
            "axis":       _param_entry(list(axis), "",       "rotation axis"),
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# 8. Bar / plank on a support (BarPlaneSupport)
# ─────────────────────────────────────────────────────────────────────────────

def cot_bar_support(raw: dict, _entities: list[dict]) -> dict:
    length  = _f(raw.get("bar_length",  1.0), 1.0)
    width   = _f(raw.get("bar_width",   0.08), 0.08)
    height  = _f(raw.get("bar_height",  0.04), 0.04)
    ratio   = _f(raw.get("support_ratio", 0.5), 0.5)
    angle   = _f(raw.get("bar_angle", 0.0), 0.0)
    m       = _f(raw.get("mass", raw.get("m", 1.0)), 1.0)
    b       = _f(raw.get("damping", 0.05), 0.05)
    g       = 9.8
    # Distance from pivot to bar centre
    d_cm = (0.5 - ratio) * length
    # Bar moment of inertia about its pivot (thin rod parallel-axis)
    I_rod = m * length ** 2 / 12.0
    I_pivot = I_rod + m * d_cm ** 2

    return {
        "simulation": "bar_on_support",
        "category": "mechanics",
        "physical_observation": (
            f"A uniform bar of length {length:.3f} m, mass {m:.3f} kg sits on a support "
            f"at {ratio*100:.1f}% of its length. When displaced, gravity creates a restoring torque "
            f"about the support; the bar oscillates like a physical pendulum about the pivot."
        ),
        "physical_law": {
            "name": "Physical pendulum (Newton II rotational about a pivot)",
            "statement": "For a rigid body free to rotate about a fixed pivot at distance d from "
                         "the centre of mass, I_pivot * ddtheta = -m*g*d*sin(theta) + tau_damp.",
            "formula": "I_pivot * ddtheta = -m*g*d*sin(theta) - b*dtheta/dt",
        },
        "modeling_assumptions": [
            "Uniform bar; I_cm = m*L^2 / 12 (thin rod).",
            "Pivot is frictionless hinge at fraction 'support_ratio' along the bar.",
            "Small-amplitude motion -> sin(theta) ~ theta (linearised)."
            " Large-amplitude motion handled by the MuJoCo integrator directly.",
            "Uniform gravity g=9.8 m/s^2.",
        ],
        "ode_system": {
            "state_variables": ["theta (bar tilt, rad)", "omega = dtheta/dt (rad/s)"],
            "equations_latex": [
                "dtheta/dt = omega",
                "domega/dt = -(m*g*d/I_pivot) * sin(theta) - (b/I_pivot) * omega",
            ],
            "equations_python": [
                "dtheta_dt = omega",
                "domega_dt = -(m * g * d / I_pivot) * math.sin(theta) - (b / I_pivot) * omega",
            ],
        },
        "derivation_steps": [
            "Place the pivot at support_ratio*L from the left end -> distance d from centre of mass "
            f"= (0.5 - support_ratio) * L = {d_cm:.4f} m.",
            f"Moment of inertia about the centre of mass: I_cm = m*L^2/12 = {I_rod:.4f} kg*m^2.",
            f"Parallel-axis theorem: I_pivot = I_cm + m*d^2 = {I_pivot:.4f} kg*m^2.",
            "Gravity torque about the pivot: tau_g = -m*g*d*sin(theta).",
            "Damping torque: tau_d = -b*omega.",
            "Newton II rotational: I_pivot * ddtheta = tau_g + tau_d.",
        ],
        "numerical_method": _MUJOCO_NUMERICAL_METHOD,
        "code_validation": {
            "ode_source": "Physical pendulum equations; MuJoCo hinge joint with damping.",
            "energy_check": "Total E = 0.5*I*omega^2 + m*g*d*(1 - cos(theta)) decreases "
                            "monotonically for b > 0.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Small-amplitude period: T ~ 2*pi*sqrt(I_pivot / (m*g*d)) "
            f"~ {2*math.pi*math.sqrt(I_pivot / max(m*g*abs(d_cm), 1e-9)):.3f} s "
            "(if d != 0)." if abs(d_cm) > 1e-6 else "Pivot at the centre -> no restoring torque.",
        ],
        "parameters": {
            "length":        _param_entry(length, "m",   "bar length"),
            "width":         _param_entry(width,  "m",   "bar width"),
            "height":        _param_entry(height, "m",   "bar thickness"),
            "support_ratio": _param_entry(ratio,  "",    "pivot position along bar (0 = left end)"),
            "bar_angle0":    _param_entry(angle,  "deg", "initial tilt"),
            "m":             _param_entry(m,      "kg",  "bar mass"),
            "b":             _param_entry(b,      "N*m*s", "angular damping"),
            "I_pivot":       _param_entry(I_pivot,"kg*m^2","moment of inertia about pivot"),
            "g":             _param_entry(g,      "m/s^2", "gravitational acceleration"),
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# 9. Orbital motion (OrbitalMotionEntity, SolarSystemEntity, GeneralCelestialEntity)
# ─────────────────────────────────────────────────────────────────────────────

def cot_orbital(raw: dict, _entities: list[dict]) -> dict:
    G = _f(raw.get("G_constant", raw.get("G", 1.0)), 1.0)
    if "masses" in raw:
        masses = [float(m) for m in raw["masses"]]
        positions = list(zip(raw.get("x_init", []), raw.get("y_init", [])))
        velocities = list(zip(raw.get("vx_init", []), raw.get("vy_init", [])))
    else:
        # SolarSystemEntity layout
        star_mass = _f(raw.get("star_mass", 1.0), 1.0)
        planets = raw.get("planets", [])
        masses = [star_mass] + [_f(p.get("mass", 1.0)) for p in planets]
        positions = [(0.0, 0.0)] + [
            (_f(p.get("position", [0, 0])[0]), _f(p.get("position", [0, 0])[1]))
            for p in planets
        ]
        velocities = [(0.0, 0.0)] + [
            (_f(p.get("velocity", [0, 0])[0]), _f(p.get("velocity", [0, 0])[1]))
            for p in planets
        ]
    n = len(masses)

    return {
        "simulation": "orbital_motion",
        "category": "celestial_mechanics",
        "physical_observation": (
            f"N-body problem with N={n} bodies under mutual Newtonian gravity (G={G}). "
            f"Body 0 acts as the central mass (m={masses[0]:.3f}); the remaining bodies "
            f"follow conic orbits around it (elliptical/parabolic/hyperbolic depending on energy)."
        ),
        "physical_law": {
            "name": "Newton's law of universal gravitation",
            "statement": "Every pair of point masses attracts with force F = G*m_i*m_j / r_ij^2 "
                         "directed along r_ij.",
            "formula": "m_i * d2r_i/dt2 = sum_{j != i} G * m_i * m_j * (r_j - r_i) / |r_j - r_i|^3",
        },
        "modeling_assumptions": [
            "Point masses; no extended-body tidal effects.",
            "Gravity softening epsilon included to avoid singular close encounters.",
            "MuJoCo built-in gravity is disabled; forces are applied per step via "
            "data.xfrc_applied[...].",
            "Integrator: RK4 for higher energy-conservation fidelity.",
        ],
        "ode_system": {
            "state_variables": [
                "r_i = (x_i, y_i) for i = 0..N-1",
                "v_i = (vx_i, vy_i) for i = 0..N-1  (total 4N state variables)",
            ],
            "equations_latex": [
                "dr_i/dt = v_i",
                "dv_i/dt = sum_{j != i} G * m_j * (r_j - r_i) / (|r_j - r_i|^2 + eps^2)^{3/2}",
            ],
            "equations_python": [
                "dr_i_dt = v_i",
                "dv_i_dt = sum(G * m[j] * (r[j] - r[i]) / "
                "(np.dot(r[j]-r[i], r[j]-r[i]) + eps**2)**1.5 for j in range(N) if j != i)",
            ],
        },
        "derivation_steps": [
            "Place the origin at the system barycentre (or leave free; energy/angular-momentum "
            "checks still hold).",
            "For each body i, the net gravitational acceleration is the vector sum over every "
            "other body j of G*m_j*(r_j - r_i) / |r_j - r_i|^3.",
            "Convert to Cartesian dv/dt components and pair with dr/dt = v.",
            "Total energy E = sum 0.5*m_i*|v_i|^2 - sum_{i<j} G*m_i*m_j / |r_j - r_i| "
            "should be conserved (up to integrator drift).",
            "Total linear and angular momentum also conserved.",
        ],
        "numerical_method": _MUJOCO_NUMERICAL_METHOD,
        "code_validation": {
            "ode_source": "Newton's law of gravitation; explicit pairwise forces.",
            "energy_check": "Relative energy error < 1e-3 over 10 s with RK4 + small softening.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            "Planets follow closed elliptical orbits when energy is negative (bound).",
            "Hyperbolic / parabolic escape when energy >= 0.",
            "Central body remains nearly stationary if m0 >> m_planets.",
        ],
        "parameters": {
            "N":         _param_entry(n,         "",    "number of bodies"),
            "masses":    _param_entry(masses,    "M*",  "mass of each body (code units)"),
            "positions": _param_entry(positions, "L*",  "initial 2-D positions"),
            "velocities":_param_entry(velocities, "L/T*", "initial 2-D velocities"),
            "G":         _param_entry(G,         "",    "gravitational constant (code units)"),
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# 10. Rolling plane (RollingPlaneEntity)
# ─────────────────────────────────────────────────────────────────────────────

def cot_rolling(raw: dict, _entities: list[dict]) -> dict:
    m     = _f(raw.get("mass", raw.get("m", 1.0)), 1.0)
    r     = _f(raw.get("radius", raw.get("r", 0.15)), 0.15)
    slope = _f(raw.get("angle", raw.get("theta_deg", 17.0)), 17.0)
    mu    = _f(raw.get("friction", raw.get("mu", 0.4)), 0.4)
    v0    = _f(raw.get("init_vel", raw.get("v0", 0.0)), 0.0)
    shape = str(raw.get("shape", "sphere")).lower()
    beta_map = {
        "sphere": 2.0 / 5.0, "solid_sphere": 2.0 / 5.0,
        "cylinder": 1.0 / 2.0, "solid_cylinder": 1.0 / 2.0,
        "hollow_cylinder": 1.0, "ring": 1.0,
        "hollow_sphere": 2.0 / 3.0,
    }
    beta = beta_map.get(shape, 2.0 / 5.0)   # I / (m*r^2)
    g = 9.8
    theta = math.radians(slope)
    a = g * math.sin(theta) / (1.0 + beta)

    return {
        "simulation": "rolling_plane",
        "category": "mechanics",
        "physical_observation": (
            f"A {shape} (mass {m:.3f} kg, radius {r:.3f} m) rolls without slipping down an "
            f"inclined plane of angle {slope:.2f} deg. Friction coefficient "
            f"mu={mu:.3f} provides the torque that couples rotation to translation."
        ),
        "physical_law": {
            "name": "Newton II (translational) + Newton II (rotational) + rolling constraint",
            "statement": "m*a = m*g*sin(theta) - f_s; I*alpha = f_s*r; rolling constraint a = "
                         "alpha*r.",
            "formula": "a = g*sin(theta) / (1 + beta),  beta = I/(m*r^2) = "
                       f"{beta:.4f} for {shape}",
        },
        "modeling_assumptions": [
            f"I = beta * m * r^2 with beta={beta:.4f} for a {shape}.",
            "Static friction sufficient to prevent slipping (mu large enough).",
            "Uniform gravity g=9.8 m/s^2.",
        ],
        "ode_system": {
            "state_variables": ["x (position along slope, m)", "v = dx/dt (m/s)"],
            "equations_latex": [
                "dx/dt = v",
                "dv/dt = g*sin(theta) / (1 + beta)",
            ],
            "equations_python": [
                "dx_dt = v",
                "dv_dt = g * math.sin(theta) / (1.0 + beta)",
            ],
        },
        "derivation_steps": [
            "Translational: m*a = m*g*sin(theta) - f_s  (f_s = static friction, opposes motion).",
            "Rotational about the centre of mass: I*alpha = f_s * r.",
            "Rolling constraint: v = omega*r, so a = alpha*r.",
            "From rotational eqn: f_s = I*alpha/r = I*a/r^2 = beta*m*a.",
            "Substitute into translational: m*a = m*g*sin(theta) - beta*m*a.",
            f"Solve: a = g*sin(theta)/(1 + beta) = {a:.4f} m/s^2.",
        ],
        "numerical_method": _MUJOCO_NUMERICAL_METHOD,
        "code_validation": {
            "ode_source": "Combined Newton II translational + rotational; MuJoCo condim=6 contact.",
            "energy_check": "E = 0.5*m*v^2 + 0.5*I*omega^2 + m*g*z  (conserved for pure rolling).",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Acceleration down the slope: a = {a:.4f} m/s^2 (pure rolling).",
            f"Comparison to frictionless slide a = g*sin(theta) = "
            f"{g*math.sin(theta):.4f} m/s^2 -> rolling is slower.",
        ],
        "parameters": {
            "m":        _param_entry(m,     "kg",    "rolling-body mass"),
            "r":        _param_entry(r,     "m",     "rolling-body radius"),
            "theta_deg":_param_entry(slope, "deg",   "slope angle"),
            "mu":       _param_entry(mu,    "",      "friction coefficient"),
            "v0":       _param_entry(v0,    "m/s",   "initial speed down the slope"),
            "shape":    _param_entry(shape, "",      "rolling body shape"),
            "beta":     _param_entry(beta,  "",      "I / (m*r^2) for the given shape"),
            "g":        _param_entry(g,     "m/s^2", "gravitational acceleration"),
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# 11. Rocket (RocketEntity)
# ─────────────────────────────────────────────────────────────────────────────

def cot_rocket(raw: dict, _entities: list[dict]) -> dict:
    m0      = _f(raw.get("rocket_mass", raw.get("m", 1.0)), 1.0)
    pm      = _f(raw.get("planet_mass", 0.0), 0.0)
    pr      = _f(raw.get("planet_radius", 0.0), 0.0)
    v_ex    = _f(raw.get("v_exhaust", 0.0), 0.0)
    dm_dt   = _f(raw.get("dm_dt", 0.0), 0.0)
    m_min   = _f(raw.get("min_mass", m0 * 0.5), m0 * 0.5)
    angle   = _f(raw.get("launch_angle", raw.get("angle_deg", 90.0)), 90.0)
    thrust  = -v_ex * dm_dt  # thrust = -v_ex * dm/dt, with dm/dt < 0 during burn
    g       = 9.8
    dv_max  = v_ex * math.log(m0 / m_min) if (v_ex > 0 and m_min > 0) else 0.0

    return {
        "simulation": "rocket",
        "category": "variable_mass",
        "physical_observation": (
            f"A rocket of initial mass m0={m0:.3f} kg expels propellant at exhaust speed "
            f"v_ex={v_ex:.3f} m/s with mass-flow rate dm/dt={dm_dt:.3f} kg/s, launched at "
            f"angle {angle:.2f} deg from vertical."
        ),
        "physical_law": {
            "name": "Tsiolkovsky rocket equation (Newton II + conservation of momentum for "
                    "variable-mass systems)",
            "statement": "The thrust equals -v_ex * dm/dt and acts along the rocket body axis. "
                         "Net equation of motion: m(t)*dv/dt = -v_ex*dm/dt - m(t)*g.",
            "formula": "Delta_v = v_ex * ln(m0 / m_f)   (gravity-free limit)",
        },
        "modeling_assumptions": [
            "Constant exhaust velocity v_ex (effective ISP).",
            "Constant mass-flow rate dm/dt until burnout (m = m_min).",
            "Aerodynamic drag approximated by quadratic drag term in the script "
            "(drag_coeff = 0.01 by default).",
            "Uniform gravity g=9.8 m/s^2 in the world frame (planet as flat earth).",
            "Thrust vector aligned with the rocket body axis at the fixed launch angle.",
        ],
        "ode_system": {
            "state_variables": ["x, z (position, m)", "vx, vz (velocity, m/s)", "m (mass, kg)"],
            "equations_latex": [
                "dx/dt = vx,  dz/dt = vz",
                "m * dvx/dt = thrust*sin(angle) - c*|v|*vx",
                "m * dvz/dt = thrust*cos(angle) - m*g - c*|v|*vz",
                "dm/dt = dm_dt   (for m > m_min, else 0)",
            ],
            "equations_python": [
                "dx_dt, dz_dt = vx, vz",
                "dvx_dt = (thrust * math.sin(math.radians(angle)) - c * speed * vx) / m",
                "dvz_dt = (thrust * math.cos(math.radians(angle)) - c * speed * vz) / m - g",
                "dm_dt_val = dm_dt if m > m_min else 0.0",
            ],
        },
        "derivation_steps": [
            "Define m(t) decreasing linearly from m0 to m_min.",
            f"Thrust magnitude F = -v_ex * dm/dt = {thrust:.4f} N (positive during burn).",
            "Decompose thrust into world components at the launch angle.",
            "Add gravity (world-z) and quadratic drag (opposing velocity) terms.",
            "Integrate coupled ODE for (x, z, vx, vz, m).",
            f"Gravity-free delta-v (ideal): v_ex * ln(m0/m_min) = {dv_max:.3f} m/s.",
        ],
        "numerical_method": _MUJOCO_NUMERICAL_METHOD,
        "code_validation": {
            "ode_source": "Tsiolkovsky rocket equation + drag + gravity.",
            "momentum_check": "Total momentum of rocket + expelled gas conserved (in free space).",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            "Thrust phase: rocket accelerates upward; mass decreases.",
            "Burnout: m = m_min; rocket coasts under gravity + drag.",
            f"Approximate ideal delta-v (Tsiolkovsky): {dv_max:.3f} m/s.",
        ],
        "parameters": {
            "m0":            _param_entry(m0,      "kg",    "initial rocket mass"),
            "m_min":         _param_entry(m_min,   "kg",    "burnout mass"),
            "v_exhaust":     _param_entry(v_ex,    "m/s",   "effective exhaust speed"),
            "dm_dt":         _param_entry(dm_dt,   "kg/s",  "mass flow rate (negative while burning)"),
            "thrust":        _param_entry(thrust,  "N",     "instantaneous thrust -v_ex * dm/dt"),
            "launch_angle":  _param_entry(angle,   "deg",   "launch angle from vertical"),
            "planet_mass":   _param_entry(pm,      "kg",    "planet mass (if scene models gravity)"),
            "planet_radius": _param_entry(pr,      "m",     "planet radius"),
            "g":             _param_entry(g,       "m/s^2", "surface gravity"),
            "dv_ideal":      _param_entry(dv_max,  "m/s",   "ideal (gravity-free) delta-v"),
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# 12. Electromagnetic (MagneticElectricEntity, ElectroMagneticEntity)
# ─────────────────────────────────────────────────────────────────────────────

def cot_em(raw: dict, _entities: list[dict]) -> dict:
    m   = _f(raw.get("mass", raw.get("m", 1.0)), 1.0)
    q   = _f(raw.get("q", raw.get("charge", 1.0)), 1.0)
    iv  = raw.get("init_velocity", [])
    vx0 = _f(iv[0] if len(iv) > 0 else 0.0)
    vy0 = _f(iv[1] if len(iv) > 1 else 0.0)
    vz0 = _f(iv[2] if len(iv) > 2 else 0.0)
    fields = raw.get("field_configs", [])
    E_field: list = [0.0, 0.0, 0.0]
    B_field: list = [0.0, 0.0, 0.0]
    field_notes: list[str] = []
    for fc in fields:
        if not isinstance(fc, dict):
            continue
        ftype = str(fc.get("field_type", "")).lower()
        raw_val = fc.get("value", fc.get("field_strength"))
        # Sim2Reason sometimes encodes non-uniform fields as a string label
        # ('field_polynomial') + a 'field_polynomial' coefficient dict; keep the
        # label for the CoT and fall back to 0 for the scalar summary.
        if isinstance(raw_val, list):
            vec = [_f(v) for v in raw_val[:3]] + [0.0] * max(0, 3 - len(raw_val))
        elif isinstance(raw_val, str):
            # Non-numeric label such as 'field_polynomial' means the YAML stores
            # a spatially-varying field; the uniform-field summary is zero and
            # we record the label for downstream consumers.
            vec = [0.0, 0.0, 0.0]
            field_notes.append(f"{ftype} field is non-uniform: {raw_val}")
        elif raw_val is None:
            vec = [0.0, 0.0, 0.0]
        else:
            vec = [_f(raw_val), 0.0, 0.0]
        if "electric" in ftype or ftype == "e":
            E_field = vec
        elif "magnetic" in ftype or ftype == "b":
            B_field = vec
    B_mag = math.sqrt(sum(b * b for b in B_field))
    omega_c = abs(q) * B_mag / m if m > 0 else 0.0   # cyclotron frequency
    r_c = m * math.hypot(vx0, vy0) / (abs(q) * B_mag) if (abs(q) * B_mag > 1e-12) else float("inf")

    return {
        "simulation": "charged_particle_em",
        "category": "electromagnetism",
        "physical_observation": (
            f"A charged particle (m={m:.3f} kg, q={q:.3f} C) moves through a region with "
            f"electric field E={E_field} V/m and magnetic field B={B_field} T (|B|={B_mag:.3f}). "
            f"Initial velocity v0=({vx0:.3f}, {vy0:.3f}, {vz0:.3f}) m/s."
        ),
        "physical_law": {
            "name": "Lorentz force law",
            "statement": "F = q*(E + v x B); Newton II gives m*dv/dt = q*(E + v x B).",
            "formula": "m * dv/dt = q * (E + v x B)",
        },
        "modeling_assumptions": [
            "Non-relativistic particle (|v| << c).",
            "Static uniform E and B within the region of interest (piecewise uniform allowed).",
            "No radiation reaction (no Larmor backreaction).",
            "MuJoCo gravity disabled; Lorentz force applied manually via data.xfrc_applied.",
        ],
        "ode_system": {
            "state_variables": ["r = (x, y, z) (m)", "v = (vx, vy, vz) (m/s)"],
            "equations_latex": [
                "dr/dt = v",
                "dv/dt = (q/m) * (E + v x B)",
            ],
            "equations_python": [
                "dr_dt = v",
                "dv_dt = (q / m) * (E + np.cross(v, B))",
            ],
        },
        "derivation_steps": [
            "Lorentz force on a point charge: F = q*(E + v x B).",
            "Newton II: m*dv/dt = F.",
            "Decompose into 3 scalar equations in Cartesian coordinates.",
            f"Cyclotron (gyro) frequency: omega_c = |q|*|B|/m = {omega_c:.4f} rad/s.",
            f"Gyro radius: r_c = m*|v_perp| / (|q|*|B|) = {r_c if r_c != float('inf') else 'inf'}.",
            "Electric field produces a constant (q*E/m) drift; magnetic field causes circular "
            "motion in the plane perpendicular to B; combined E x B drift "
            "v_drift = (E x B) / |B|^2 for |B| > 0.",
        ],
        "numerical_method": _MUJOCO_NUMERICAL_METHOD,
        "code_validation": {
            "ode_source": "Lorentz force law; MuJoCo integrator='RK4' for accuracy.",
            "energy_check": "Magnetic force does no work (F . v = 0); kinetic energy should be "
                            "conserved when E = 0.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            "With B only: helical motion (circular in B-perpendicular plane, uniform along B).",
            "With E only: uniform acceleration along E.",
            "With E and B: E x B drift + cyclotron gyration about the drift frame.",
            f"Cyclotron frequency omega_c = {omega_c:.4f} rad/s.",
        ],
        "parameters": {
            "m":         _param_entry(m,       "kg",    "particle mass"),
            "q":         _param_entry(q,       "C",     "particle charge"),
            "v0":        _param_entry([vx0, vy0, vz0], "m/s", "initial velocity"),
            "E_field":   _param_entry(E_field, "V/m",   "uniform electric field"),
            "B_field":   _param_entry(B_field, "T",     "uniform magnetic field"),
            "B_mag":     _param_entry(B_mag,   "T",     "|B|"),
            "omega_c":   _param_entry(omega_c, "rad/s", "cyclotron angular frequency"),
            "field_notes": _param_entry(field_notes, "", "non-uniform field descriptors"),
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# Registry
# ─────────────────────────────────────────────────────────────────────────────

COT_REGISTRY = {
    "ThrowingMotionEntity":          cot_projectile,

    "TwoSideMassPlane":              cot_inclined_plane,
    "MassPrismPlaneEntity":          cot_inclined_plane,
    "StackedMassPlane":              cot_inclined_plane,
    "MassBoxPlaneEntity":            cot_inclined_plane,

    "MassWithFixedPulley":           cot_pulley,
    "MassWithMovablePulley":         cot_pulley,
    "MassWithReversedMovablePulley": cot_pulley,
    "ConstantForceFixedPulley":      cot_pulley,
    "DirectedMass":                  cot_pulley,
    "MassPrismPulleyPlane":          cot_pulley,

    "TwoDCollisionPlane":            cot_collision,
    "ComplexCollisionPlane":         cot_collision,

    "SpringBlockEntity":             cot_spring_block,
    "SpringMassPlaneEntity":         cot_spring_block,

    "PendulumEntity":                cot_pendulum,
    "RigidRotationEntity":           cot_rigid_rotation,
    "BarPlaneSupport":               cot_bar_support,

    "OrbitalMotionEntity":           cot_orbital,
    "SolarSystemEntity":             cot_orbital,
    "GeneralCelestialEntity":        cot_orbital,

    "RollingPlaneEntity":            cot_rolling,

    "RocketEntity":                  cot_rocket,

    "MagneticElectricEntity":        cot_em,
    "ElectroMagneticEntity":         cot_em,
}


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def _primary_entity_type(entities: list[dict]) -> str:
    """Pick the 'main' physics entity class from a scene's entity list."""
    # First non-pulley/structural entity
    for ent in entities:
        cls = ent.get("type", ent.get("class_name", ""))
        if cls in COT_REGISTRY and cls not in {
            "MassWithFixedPulley", "MassWithMovablePulley",
            "MassWithReversedMovablePulley", "ConstantForceFixedPulley",
            "DirectedMass",
        }:
            return cls
    # Otherwise, the first pulley-family entity is the primary one
    for ent in entities:
        cls = ent.get("type", ent.get("class_name", ""))
        if cls in COT_REGISTRY:
            return cls
    # Fall back to the very first entity
    return entities[0].get("type", entities[0].get("class_name", "Unknown")) if entities else "Unknown"


def build_cot_for_scene(yaml_path: str | Path) -> tuple[str, dict, dict]:
    """
    Parse a Sim2Reason ``scene_output.yaml`` and return:

        (entity_type, cot_dict, raw_params_for_primary_entity)

    ``cot_dict`` is JSON-serializable and follows the Pipeline-A CoT schema.
    Raises ``KeyError`` if the primary entity type is not in ``COT_REGISTRY``.
    """
    raw_yaml = _load_yaml(yaml_path)
    scene = raw_yaml.get("scene", raw_yaml)
    entities = scene.get("entities", []) or []
    if not entities:
        raise ValueError(f"No entities found in {yaml_path}")

    entity_type = _primary_entity_type(entities)
    if entity_type not in COT_REGISTRY:
        raise KeyError(f"No CoT template for entity type '{entity_type}'")

    # Locate the primary entity's raw params
    primary_params: dict = {}
    for ent in entities:
        cls = ent.get("type", ent.get("class_name", ""))
        if cls == entity_type:
            primary_params = ent.get("parameters", ent.get("params", {})) or {}
            break
    # _normalize_for_builder is strict about some field types; if it chokes on
    # an unusual YAML (e.g. EM field_strength='field_polynomial'), fall back to
    # the raw parameter dict so CoT generation still succeeds.
    try:
        raw_norm = _normalize_for_builder(entity_type, primary_params)
    except Exception:
        raw_norm = dict(primary_params)

    cot = COT_REGISTRY[entity_type](raw_norm, entities)

    # Enrich CoT with scene-level metadata
    cot.setdefault("scene_tag", scene.get("tag", ""))
    cot.setdefault("entity_type", entity_type)

    return entity_type, cot, raw_norm
