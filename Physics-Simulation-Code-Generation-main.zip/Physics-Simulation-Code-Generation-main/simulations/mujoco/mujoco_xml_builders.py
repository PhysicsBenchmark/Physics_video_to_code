"""
mujoco_xml_builders.py
======================
One function per Sim2Reason entity type that builds a MuJoCo XML string from
extracted physics parameters.  The XML is designed to be embedded verbatim in
a standalone simulation script.

Each builder returns a dict with:
    {
        "xml":           str   — the full MuJoCo XML string (no f-string escaping)
        "param_lines":   str   — Python variable declarations for the physics params
        "init_code":     str   — extra Python lines to set initial velocities etc.
                                 after model/data are created (may be empty)
        "force_code":    str   — lines to call inside the inner physics loop
                                 (e.g. for orbital gravity or EM forces; may be empty)
        "description":   str   — one-line description for the script docstring
    }

All builders accept a `params` dict (as returned by param_extractor.extract_params).
"""

from __future__ import annotations
import math
from typing import Any


# ── helpers ────────────────────────────────────────────────────────────────

def _rgba(r, g, b, a=1.0):
    return f"{r} {g} {b} {a}"


def _xml_body(name, pos, quat=None, joints="", geoms="", sites=""):
    q = f' quat="{quat[0]} {quat[1]} {quat[2]} {quat[3]}"' if quat else ""
    return (f'      <body name="{name}" pos="{pos[0]:.4f} {pos[1]:.4f} {pos[2]:.4f}"{q}>\n'
            f'{joints}{geoms}{sites}'
            f'      </body>\n')


# ─────────────────────────────────────────────────────────────────────────────
# 1. Throwing / Projectile Motion (ThrowingMotionEntity)
# ─────────────────────────────────────────────────────────────────────────────

def build_xml_throwing(params: dict[str, Any]) -> dict:
    m       = _scalar(params.get("ball_mass",   params.get("m",    1.0)), 1.0)
    r       = _scalar(params.get("ball_radius", params.get("r",    0.1)), 0.1)
    h0      = _scalar(params.get("initial_height", params.get("y0", 1.0)), 1.0)
    speed   = _scalar(params.get("initial_speed",  params.get("v0", 5.0)), 5.0)
    angle_d = _scalar(params.get("initial_angle",  params.get("theta_deg", 45.0)), 45.0)
    mu      = _scalar(params.get("coefficient_of_friction", params.get("mu", 0.0)), 0.0)
    angle_r = math.radians(angle_d)
    vx      = speed * math.cos(angle_r)
    vz      = speed * math.sin(angle_r)

    xml = f"""<mujoco model="throwing_motion">
  <option gravity="0 0 -9.8" timestep="0.005"/>
  <default>
    <geom friction="{mu:.3f} 0.005 0.0001" condim="3"/>
  </default>
  <worldbody>
    <!-- Ground plane -->
    <geom name="ground" type="plane" size="20 20 0.1" pos="0 0 0"
          rgba="0.4 0.6 0.4 1" friction="{mu:.3f} 0.005 0.0001"/>
    <!-- Projectile ball -->
    <body name="ball" pos="0 0 {h0:.4f}">
      <freejoint name="ball_free"/>
      <geom name="ball_geom" type="sphere" size="{r:.4f}" mass="{m:.4f}"
            rgba="0.85 0.25 0.2 1"/>
    </body>
    <camera name="side" pos="10 -12 {h0+2:.2f}" xyaxes="1 0 0 0 0.3 1"/>
  </worldbody>
</mujoco>"""

    param_lines = (
        f"m           = {m}        # ball mass (kg)\n"
        f"r           = {r}        # ball radius (m)\n"
        f"h0          = {h0}       # initial height (m)\n"
        f"speed       = {speed}    # launch speed (m/s)\n"
        f"angle_deg   = {angle_d}  # launch angle (degrees)\n"
        f"mu          = {mu}       # friction coefficient\n"
        f"angle_rad   = math.radians(angle_deg)\n"
        f"vx0         = speed * math.cos(angle_rad)   # initial x velocity\n"
        f"vz0         = speed * math.sin(angle_rad)   # initial z velocity"
    )

    init_code = (
        "# Set initial velocity on the ball's freejoint (qvel order: vx vy vz wx wy wz)\n"
        "ball_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, 'ball_free')\n"
        "data.qvel[ball_id * 6]     = vx0   # x\n"
        "data.qvel[ball_id * 6 + 2] = vz0   # z\n"
    )

    return {
        "xml": xml,
        "param_lines": param_lines,
        "init_code": init_code,
        "force_code": "",
        "description": f"Projectile motion: speed={speed} m/s, angle={angle_d}°, h0={h0} m",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 2. Inclined Plane (TwoSideMassPlane, MassPrismPlaneEntity, MassBoxPlaneEntity)
# ─────────────────────────────────────────────────────────────────────────────

def _scalar(val, default: float = 0.0) -> float:
    """Safely convert a value that may be a list, None, or scalar to float."""
    if val is None:
        return default
    if isinstance(val, (list, tuple)):
        return float(val[0]) if val else default
    return float(val)


def build_xml_inclined_plane(params: dict[str, Any]) -> dict:
    mass_values = params.get("mass_values", [params.get("m", 1.0)])
    m      = float(mass_values[0]) if mass_values else 1.0
    slope  = _scalar(params.get("plane_slope", params.get("theta_deg",
                     math.degrees(params.get("theta", 0.4)))), default=0.0)
    mu     = _scalar(params.get("coefficient_of_friction", params.get("mu", 0.2)), default=0.2)
    v0     = float(params.get("v0", 0.0))

    slope_r = math.radians(slope)
    # Euler angle to tilt the plane: rotate around y-axis by slope
    # In MuJoCo we tilt the floor geom and put the block on top
    cos_s, sin_s = math.cos(slope_r), math.sin(slope_r)

    xml = f"""<mujoco model="inclined_plane">
  <option gravity="0 0 -9.8" timestep="0.005"/>
  <default>
    <geom friction="{mu:.4f} 0.005 0.0001" condim="6" solimp="0.9 0.95 0.001" solref="0.02 1"/>
  </default>
  <worldbody>
    <!-- Inclined plane surface (tilted around Y axis by {slope:.1f} degrees) -->
    <geom name="slope" type="box" size="3 0.5 0.05"
          pos="0 0 0" euler="0 {-slope:.3f} 0"
          rgba="0.55 0.65 0.75 1" friction="{mu:.4f} 0.005 0.0001"/>
    <!-- Block on slope -->
    <body name="block" pos="{-1.0*cos_s:.4f} 0 {1.0*sin_s + 0.1:.4f}">
      <joint name="block_slide" type="slide" axis="{cos_s:.4f} 0 {sin_s:.4f}"/>
      <geom name="block_geom" type="box" size="0.15 0.15 0.1" mass="{m:.4f}"
            rgba="0.85 0.25 0.2 1"/>
    </body>
    <camera name="side" pos="0 -5 2" xyaxes="1 0 0 0 0.4 1"/>
  </worldbody>
</mujoco>"""

    param_lines = (
        f"m         = {m}      # block mass (kg)\n"
        f"slope_deg = {slope}  # incline angle (degrees)\n"
        f"mu        = {mu}     # friction coefficient\n"
        f"v0        = {v0}     # initial velocity along slope (m/s)"
    )

    init_code = (
        "# Set initial velocity along the slope\n"
        "import math\n"
        "slope_r = math.radians(slope_deg)\n"
        "slide_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, 'block_slide')\n"
        "data.qvel[slide_id] = v0\n"
    )

    return {
        "xml": xml,
        "param_lines": param_lines,
        "init_code": init_code,
        "force_code": "",
        "description": f"Inclined plane: slope={slope:.1f}°, mass={m} kg, friction={mu}",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 3. Pulley / Atwood Machine (MassWithFixedPulley and variants)
# ─────────────────────────────────────────────────────────────────────────────

def build_xml_pulley(params: dict[str, Any]) -> dict:
    mass_values = params.get("mass_values", [])
    m1 = float(params.get("m1", mass_values[0] if len(mass_values) > 0 else 1.5))
    m2 = float(params.get("m2", mass_values[1] if len(mass_values) > 1 else 2.0))
    L  = float(params.get("L", 2.0))   # total rope length

    xml = f"""<mujoco model="atwood_machine">
  <option gravity="0 0 -9.8" timestep="0.005"/>
  <worldbody>
    <!-- Ceiling anchor -->
    <geom name="ceiling" type="box" size="0.6 0.05 0.02" pos="0 0 {L/2+0.3:.3f}"
          rgba="0.5 0.5 0.5 1" contype="0" conaffinity="0"/>
    <site name="pulley_site" pos="0 0 {L/2+0.3:.3f}" size="0.02"/>
    <!-- Left mass (m1) -->
    <body name="mass1" pos="{-0.3:.3f} 0 0">
      <joint name="j1" type="slide" axis="0 0 1"
             range="{-L/2:.3f} {L/2:.3f}"/>
      <geom name="m1_geom" type="box" size="0.12 0.12 0.12" mass="{m1:.4f}"
            rgba="0.2 0.45 0.85 1"/>
    </body>
    <!-- Right mass (m2) -->
    <body name="mass2" pos="0.3 0 0">
      <joint name="j2" type="slide" axis="0 0 1"
             range="{-L/2:.3f} {L/2:.3f}"/>
      <geom name="m2_geom" type="box" size="0.12 0.12 0.12" mass="{m2:.4f}"
            rgba="0.85 0.25 0.2 1"/>
    </body>
    <camera name="front" pos="0 -4 0" xyaxes="1 0 0 0 0 1"/>
  </worldbody>
  <!-- Rope: j1 and j2 sum to constant (inextensible string) -->
  <tendon>
    <fixed name="rope">
      <joint joint="j1" coef="1"/>
      <joint joint="j2" coef="1"/>
    </fixed>
  </tendon>
</mujoco>"""

    param_lines = (
        f"m1 = {m1}   # left mass (kg)\n"
        f"m2 = {m2}   # right mass (kg)\n"
        f"L  = {L}    # rope length (m)"
    )

    return {
        "xml": xml,
        "param_lines": param_lines,
        "init_code": "",
        "force_code": "",
        "description": f"Atwood machine: m1={m1} kg, m2={m2} kg, rope={L} m",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 4. Collision (TwoDCollisionPlane, ComplexCollisionPlane)
# ─────────────────────────────────────────────────────────────────────────────

def build_xml_collision(params: dict[str, Any]) -> dict:
    mass_values = params.get("mass_values", [1.0, 1.0])
    positions   = params.get("mass_positions", [[-1.0, 0.0], [1.0, 0.0]])
    velocities  = params.get("mass_initial_velocities", [[1.0, 0.0], [-1.0, 0.0]])
    radii       = params.get("radii", [0.15] * len(mass_values))
    rc_list     = params.get("resolution_coefficient_list", [])
    slope_deg   = float(params.get("plane_slope", 0.0))
    slope_r     = math.radians(slope_deg)

    # Parse per-pair restitution from resolution_coefficient_list.
    # Each entry is [idx_a, idx_b, e] — used in <contact><pair solref="-stiffness 0"/>
    # A negative solref timeconst encodes a stiff spring contact (Sim2Reason's COR approach).
    pair_contacts = []
    for entry in rc_list:
        try:
            ia, ib = int(entry[0]), int(entry[1])
            pair_contacts.append((ia, ib))
        except Exception:
            pass

    _COLORS = [
        "0.85 0.2 0.2 1", "0.2 0.5 0.85 1", "0.2 0.75 0.35 1",
        "0.9 0.7 0.1 1",  "0.6 0.2 0.8 1",  "0.9 0.5 0.1 1",
    ]

    # Bodies use two slide joints (x + tilted-y) matching Sim2Reason's 2D constraint.
    # This keeps balls on the plane and prevents gravity from acting in z.
    cos_s = math.cos(slope_r)
    sin_s = math.sin(slope_r)
    bodies_xml = ""
    for i, (mass, pos_xy, radius) in enumerate(
        zip(mass_values, positions, radii)
    ):
        x = float(pos_xy[0])
        y = float(pos_xy[1])
        col = _COLORS[i % len(_COLORS)]
        bodies_xml += (
            f'    <body name="sphere_{i}" pos="{x:.4f} {y:.4f} 0">\n'
            f'      <joint name="sphere_{i}_x" type="slide" axis="1 0 0"/>\n'
            f'      <joint name="sphere_{i}_y" type="slide" axis="0 {cos_s:.6f} {sin_s:.6f}"/>\n'
            f'      <geom name="sphere_{i}_geom" type="sphere" size="{float(radius):.4f}"'
            f' mass="{float(mass):.4f}" rgba="{col}" condim="1" contype="1" conaffinity="1"/>\n'
            f'    </body>\n'
        )

    # Contact pairs with stiff spring contacts (negative solref = spring stiffness)
    contact_xml = ""
    if pair_contacts:
        contact_xml = "\n  <contact>\n"
        for ia, ib in pair_contacts:
            contact_xml += (
                f'    <pair geom1="sphere_{ia}_geom" geom2="sphere_{ib}_geom"'
                f' solref="-2500 0"/>\n'
            )
        contact_xml += "  </contact>"

    xml = f"""<mujoco model="collision_plane">
  <option gravity="0 0 -9.81" timestep="0.002"/>
  <default>
    <!-- Zero friction, condim=1 (normal only): matches Sim2Reason's 2D billiard model -->
    <geom friction="0 0 0" solimp="0.9 1 0.001 0.01 20" solref="0.02 1" condim="1"/>
  </default>
  <worldbody>
    <!-- Bodies constrained to 2D plane via slide joints (no freejoint) -->
{bodies_xml}    <camera name="top" pos="0 0 18" xyaxes="1 0 0 0 1 0"/>
  </worldbody>{contact_xml}
</mujoco>"""

    # Build init velocity code using joint names (not freejoint DOF index)
    init_lines = ["# Set initial velocities via joint DOF indices"]
    for i, vel_xy in enumerate(velocities):
        vx = float(vel_xy[0])
        vy = float(vel_xy[1])
        init_lines.append(
            f"_jx = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, 'sphere_{i}_x')\n"
            f"_jy = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, 'sphere_{i}_y')\n"
            f"data.qvel[model.jnt_dofadr[_jx]] = {vx:.4f}\n"
            f"data.qvel[model.jnt_dofadr[_jy]] = {vy:.4f}"
        )

    n = len(mass_values)
    param_lines = (
        f"mass_values = {[float(m) for m in mass_values]}\n"
        f"radii       = {[float(r) for r in radii]}\n"
        f"positions   = {[[float(p[0]), float(p[1])] for p in positions]}\n"
        f"velocities  = {[[float(v[0]), float(v[1])] for v in velocities]}\n"
        f"slope_deg   = {slope_deg}"
    )

    return {
        "xml": xml,
        "param_lines": param_lines,
        "init_code": "\n".join(init_lines),
        "force_code": "",
        "description": f"2D collision: {n} bodies, slope={slope_deg:.1f}°",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 5. Spring-Block (SpringBlockEntity, SpringMassPlaneEntity)
# ─────────────────────────────────────────────────────────────────────────────

def build_xml_spring_block(params: dict[str, Any]) -> dict:
    m     = _scalar(params.get("mass", params.get("m", 1.0)), 1.0)
    k     = _scalar(params.get("spring_constant", params.get("k", 5.0)), 5.0)
    b     = _scalar(params.get("damping", params.get("b", 0.2)), 0.2)
    x0    = _scalar(params.get("displacement", params.get("u0", 0.5)), 0.5)
    v0    = _scalar(params.get("init_velocity", params.get("v0", 0.0)), 0.0)
    slope = _scalar(params.get("plane_slope", 0.0), 0.0)
    slope_r = math.radians(slope)

    xml = f"""<mujoco model="spring_block">
  <option gravity="0 0 -9.8" timestep="0.005"/>
  <worldbody>
    <!-- Horizontal surface (tilted {slope:.1f} degrees) -->
    <geom name="surface" type="plane" size="5 2 0.1"
          euler="0 {-slope:.3f} 0" rgba="0.45 0.55 0.65 1"/>
    <!-- Wall anchor for spring -->
    <geom name="wall" type="box" size="0.05 0.3 0.3"
          pos="{-2.0*math.cos(slope_r):.4f} 0 {2.0*math.sin(slope_r)+0.3:.4f}"
          euler="0 {-slope:.3f} 0" rgba="0.5 0.5 0.5 1" contype="0" conaffinity="0"/>
    <site name="spring_anchor" pos="{-2.0*math.cos(slope_r):.4f} 0 {2.0*math.sin(slope_r)+0.15:.4f}"/>
    <!-- Block -->
    <body name="block" pos="{x0*math.cos(slope_r):.4f} 0 {x0*math.sin(slope_r)+0.15:.4f}">
      <joint name="slide" type="slide" axis="{math.cos(slope_r):.4f} 0 {math.sin(slope_r):.4f}"/>
      <geom name="block_geom" type="box" size="0.15 0.15 0.12" mass="{m:.4f}"
            rgba="0.85 0.3 0.2 1"/>
      <site name="block_site" pos="0 0 0"/>
    </body>
    <camera name="side" pos="0 -5 1.5" xyaxes="1 0 0 0 0.3 1"/>
  </worldbody>
  <!-- Spring: equilibrium at x=0 (natural length 2.0 m from anchor to block) -->
  <tendon>
    <spatial name="spring_tendon" springlength="2.0" stiffness="{k:.4f}" damping="{b:.4f}">
      <site site="spring_anchor"/>
      <site site="block_site"/>
    </spatial>
  </tendon>
</mujoco>"""

    param_lines = (
        f"m     = {m}    # block mass (kg)\n"
        f"k     = {k}    # spring constant (N/m)\n"
        f"b     = {b}    # damping (N·s/m)\n"
        f"x0    = {x0}   # initial displacement from equilibrium (m)\n"
        f"v0    = {v0}   # initial velocity (m/s)\n"
        f"slope_deg = {slope}  # slope angle (degrees)"
    )

    init_code = (
        "slide_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, 'slide')\n"
        "data.qvel[slide_id] = v0\n"
    )

    return {
        "xml": xml,
        "param_lines": param_lines,
        "init_code": init_code,
        "force_code": "",
        "description": f"Spring-block: k={k} N/m, m={m} kg, b={b}, x0={x0} m",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 6. Pendulum (PendulumEntity)
# ─────────────────────────────────────────────────────────────────────────────

def build_xml_pendulum(params: dict[str, Any]) -> dict:
    L      = _scalar(params.get("length", params.get("L", 1.0)), 1.0)
    m      = _scalar(params.get("mass",   params.get("m", 1.0)), 1.0)
    theta0 = _scalar(params.get("theta0", params.get("init_angle", 0.5)), 0.5)
    omega0 = _scalar(params.get("omega0", 0.0), 0.0)
    b      = _scalar(params.get("damping", params.get("b", 0.1)), 0.1)

    xml = f"""<mujoco model="pendulum">
  <option gravity="0 0 -9.8" timestep="0.005"/>
  <worldbody>
    <!-- Pivot point (ceiling anchor) -->
    <body name="pivot" pos="0 0 0">
      <geom name="pivot_geom" type="sphere" size="0.04" rgba="0.8 0.8 0.8 1"
            contype="0" conaffinity="0"/>
      <!-- Rod + Bob -->
      <body name="bob" pos="0 0 {-L:.4f}">
        <joint name="theta" type="hinge" axis="0 1 0" pos="0 0 {L:.4f}"
               damping="{b:.4f}"/>
        <geom name="rod" type="capsule" fromto="0 0 {L:.4f} 0 0 0"
              size="0.02" rgba="0.7 0.75 0.8 1" mass="0.01"
              contype="0" conaffinity="0"/>
        <geom name="bob_geom" type="sphere" size="0.08" mass="{m:.4f}"
              rgba="0.85 0.25 0.2 1"/>
      </body>
    </body>
    <camera name="side" pos="0 -3 0" xyaxes="1 0 0 0 0 1"/>
  </worldbody>
</mujoco>"""

    param_lines = (
        f"L      = {L}          # rod length (m)\n"
        f"m      = {m}          # bob mass (kg)\n"
        f"theta0 = {theta0:.6f} # initial angle (rad)\n"
        f"omega0 = {omega0:.6f} # initial angular velocity (rad/s)\n"
        f"b      = {b}          # angular damping"
    )

    init_code = (
        "import math\n"
        "theta_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, 'theta')\n"
        "data.qpos[theta_id] = theta0\n"
        "data.qvel[theta_id] = omega0\n"
        "mujoco.mj_forward(model, data)\n"
    )

    return {
        "xml": xml,
        "param_lines": param_lines,
        "init_code": init_code,
        "force_code": "",
        "description": f"Simple pendulum: L={L} m, m={m} kg, theta0={theta0:.3f} rad",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 7. Rigid Rotation (RigidRotationEntity)
# ─────────────────────────────────────────────────────────────────────────────

def build_xml_rigid_rotation(params: dict[str, Any]) -> dict:
    rigid_bodies = params.get("rigid_bodies", [])
    joint_info   = params.get("joint", {})

    # Default to a single cylinder if no rigid_bodies given
    if not rigid_bodies:
        rigid_bodies = [{
            "body_type": "cylinder",
            "mass": params.get("m", 1.0),
            "radius": params.get("r", 0.2),
            "height": params.get("height", 0.4),
            "pos": (0, 0, 0),
        }]

    axis = joint_info.get("axis", [0, 1, 0]) if joint_info else [0, 1, 0]
    omega0 = float(params.get("omega0", 0.0))
    tau    = float(params.get("tau", 0.0))

    # Build geoms
    geoms_xml = ""
    total_mass = 0.0
    for i, body in enumerate(rigid_bodies):
        btype  = str(body.get("body_type", "cylinder")).lower()
        mass   = float(body.get("mass", 1.0))
        total_mass += mass
        bpos   = body.get("pos", (0, 0, 0))
        px, py, pz = float(bpos[0]), float(bpos[1]), float(bpos[2])
        color  = ["0.85 0.3 0.2 1", "0.2 0.5 0.85 1", "0.2 0.75 0.35 1"][i % 3]
        if btype in ("cylinder", "disk"):
            rad = float(body.get("radius", 0.2))
            h   = float(body.get("height", 0.4))
            geoms_xml += (f'      <geom type="cylinder" size="{rad:.4f} {h/2:.4f}"'
                          f' pos="{px:.4f} {py:.4f} {pz:.4f}" mass="{mass:.4f}" rgba="{color}"/>\n')
        elif btype == "sphere":
            rad = float(body.get("radius", 0.2))
            geoms_xml += (f'      <geom type="sphere" size="{rad:.4f}"'
                          f' pos="{px:.4f} {py:.4f} {pz:.4f}" mass="{mass:.4f}" rgba="{color}"/>\n')
        else:  # bar / box
            lx = float(body.get("length", body.get("width", 0.5))) / 2
            ly = float(body.get("width", 0.1)) / 2
            lz = float(body.get("height", 0.1)) / 2
            geoms_xml += (f'      <geom type="box" size="{lx:.4f} {ly:.4f} {lz:.4f}"'
                          f' pos="{px:.4f} {py:.4f} {pz:.4f}" mass="{mass:.4f}" rgba="{color}"/>\n')

    ax, ay, az = float(axis[0]), float(axis[1]), float(axis[2])
    # Optional motor for applied torque
    actuator_xml = ""
    if abs(tau) > 1e-9:
        actuator_xml = (f'\n  <actuator>\n'
                        f'    <motor name="torque_motor" joint="hinge" gear="1" ctrllimited="false"/>\n'
                        f'  </actuator>')

    xml = f"""<mujoco model="rigid_rotation">
  <option gravity="0 0 -9.8" timestep="0.005"/>
  <worldbody>
    <!-- Rigid body rotating about hinge at origin -->
    <body name="rotor" pos="0 0 0">
      <joint name="hinge" type="hinge" axis="{ax:.4f} {ay:.4f} {az:.4f}" pos="0 0 0"
             damping="{float(params.get('b', 0.1)):.4f}"/>
{geoms_xml}    </body>
    <camera name="front" pos="0 -4 0" xyaxes="1 0 0 0 0 1"/>
  </worldbody>{actuator_xml}
</mujoco>"""

    param_lines = (
        f"total_mass = {total_mass:.4f}  # total rotator mass (kg)\n"
        f"omega0     = {omega0}          # initial angular velocity (rad/s)\n"
        f"tau        = {tau}             # applied torque (N·m)\n"
        f"b          = {float(params.get('b', 0.1))}  # damping coefficient\n"
        f"axis       = [{ax:.4f}, {ay:.4f}, {az:.4f}]  # rotation axis"
    )

    init_code = (
        "hinge_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, 'hinge')\n"
        "data.qvel[hinge_id] = omega0\n"
    )

    force_code = ""
    if abs(tau) > 1e-9:
        force_code = f"data.ctrl[0] = {tau}  # constant torque\n"

    return {
        "xml": xml,
        "param_lines": param_lines,
        "init_code": init_code,
        "force_code": force_code,
        "description": f"Rigid body rotation: tau={tau} N·m, omega0={omega0} rad/s",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 8. Rolling Plane (RollingPlaneEntity)
# ─────────────────────────────────────────────────────────────────────────────

def build_xml_rolling(params: dict[str, Any]) -> dict:
    m     = _scalar(params.get("mass",   params.get("m",  1.0)), 1.0)
    r     = _scalar(params.get("radius", params.get("r",  0.15)), 0.15)
    slope = _scalar(params.get("angle",  params.get("theta_deg",
                  math.degrees(params.get("theta", 0.3)))), 17.0)
    mu    = _scalar(params.get("friction", params.get("mu", 0.4)), 0.4)
    v0    = _scalar(params.get("init_vel", params.get("v0", 0.0)), 0.0)
    slope_r = math.radians(slope)

    xml = f"""<mujoco model="rolling_plane">
  <option gravity="0 0 -9.8" timestep="0.002"/>
  <default>
    <!-- Rolling friction requires condim=6 and nonzero torsional friction -->
    <geom condim="6" friction="{mu:.4f} 0.005 0.0001" solimp="0.99 0.999 0.001"/>
  </default>
  <worldbody>
    <!-- Inclined surface -->
    <geom name="slope" type="box" size="4 0.5 0.05"
          euler="0 {-slope:.4f} 0" pos="0 0 0" rgba="0.5 0.65 0.6 1"/>
    <!-- Rolling sphere -->
    <body name="sphere" pos="{-1.5*math.cos(slope_r):.4f} 0 {1.5*math.sin(slope_r)+r:.4f}">
      <freejoint name="sphere_free"/>
      <geom name="sphere_geom" type="sphere" size="{r:.4f}" mass="{m:.4f}"
            rgba="0.85 0.3 0.2 1"/>
    </body>
    <camera name="side" pos="0 -5 2" xyaxes="1 0 0 0 0.35 1"/>
  </worldbody>
</mujoco>"""

    param_lines = (
        f"m         = {m}      # sphere mass (kg)\n"
        f"r         = {r}      # sphere radius (m)\n"
        f"slope_deg = {slope}  # incline angle (degrees)\n"
        f"mu        = {mu}     # friction coefficient (must be high enough for rolling)\n"
        f"v0        = {v0}     # initial speed along slope (m/s)"
    )

    init_code = (
        "import math\n"
        "slope_r = math.radians(slope_deg)\n"
        "free_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, 'sphere_free')\n"
        "# Set velocity along the slope direction (down)\n"
        "data.qvel[free_id * 6]     =  v0 * math.cos(slope_r)  # x\n"
        "data.qvel[free_id * 6 + 2] = -v0 * math.sin(slope_r)  # z (down slope)\n"
    )

    return {
        "xml": xml,
        "param_lines": param_lines,
        "init_code": init_code,
        "force_code": "",
        "description": f"Rolling sphere: slope={slope:.1f}°, m={m} kg, r={r} m, mu={mu}",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 9. Orbital Motion (OrbitalMotionEntity, SolarSystemEntity)
#    MuJoCo doesn't have built-in N-body gravity; we apply forces via xfrc_applied
# ─────────────────────────────────────────────────────────────────────────────

def build_xml_orbital(params: dict[str, Any]) -> dict:
    # Scalar Kepler params (from our OrbitalMotionParams) or list-based
    if "masses" in params:
        masses = [float(m) for m in params["masses"]]
        x_init  = [float(x) for x in params.get("x_init",  [0.0, 1.5])]
        y_init  = [float(y) for y in params.get("y_init",  [0.0, 0.0])]
        vx_init = [float(v) for v in params.get("vx_init", [0.0, 0.0])]
        vy_init = [float(v) for v in params.get("vy_init", [1.4, -4.2])]
        G       = float(params.get("G", 1.0))
        eps     = float(params.get("eps", 0.02))
    else:
        # Scalar Kepler params
        m1, m2 = float(params.get("m1", 3.0)), float(params.get("m2", 1.0))
        G       = float(params.get("G", 1.0))
        eps     = float(params.get("eps", 0.02))
        r0      = float(params.get("r0", 1.5))
        e       = float(params.get("e", 0.0))
        angle   = float(params.get("angle", 0.0))
        M = m1 + m2
        rx, ry = r0 * math.cos(angle), r0 * math.sin(angle)
        v_rel = math.sqrt(G * M * (1 + e) / max(r0, eps))
        vx_rel, vy_rel = -v_rel * math.sin(angle), v_rel * math.cos(angle)
        masses  = [m1, m2]
        x_init  = [-m2/M*rx,  m1/M*rx]
        y_init  = [-m2/M*ry,  m1/M*ry]
        vx_init = [-m2/M*vx_rel, m1/M*vx_rel]
        vy_init = [-m2/M*vy_rel, m1/M*vy_rel]

    n = len(masses)
    _COLS = ["0.85 0.2 0.2 1", "0.2 0.6 0.9 1", "0.2 0.85 0.4 1", "0.9 0.75 0.1 1"]
    max_m = max(masses)

    bodies_xml = ""
    for i, (m, xi, yi) in enumerate(zip(masses, x_init, y_init)):
        r_vis = min(0.08 + 0.12 * m / max_m, 0.25)
        col   = _COLS[i % len(_COLS)]
        bodies_xml += (
            f'    <body name="body_{i}" pos="{xi:.6f} 0 {yi:.6f}">\n'
            f'      <freejoint name="free_{i}"/>\n'
            f'      <geom type="sphere" size="{r_vis:.4f}" mass="{m:.6f}" rgba="{col}"/>\n'
            f'    </body>\n'
        )

    xml = f"""<mujoco model="orbital_motion">
  <!-- Gravity disabled; mutual gravitational forces applied manually in the loop -->
  <option gravity="0 0 0" timestep="0.01" integrator="RK4"/>
  <worldbody>
{bodies_xml}    <camera name="top" pos="0 -8 0" xyaxes="1 0 0 0 0 1"/>
  </worldbody>
</mujoco>"""

    param_lines = (
        f"masses  = {masses}\n"
        f"x_init  = {[round(x,6) for x in x_init]}\n"
        f"y_init  = {[round(y,6) for y in y_init]}\n"
        f"vx_init = {[round(v,6) for v in vx_init]}\n"
        f"vy_init = {[round(v,6) for v in vy_init]}\n"
        f"G       = {G}     # gravitational constant (scaled)\n"
        f"eps     = {eps}   # softening length\n"
        f"n_bodies = {n}"
    )

    init_code = "\n".join(
        f"_fid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, 'free_{i}')\n"
        f"data.qvel[_fid*6], data.qvel[_fid*6+2] = vx_init[{i}], vy_init[{i}]"
        for i in range(n)
    )

    force_code = (
        "# N-body gravity: apply mutual gravitational forces via xfrc_applied\n"
        "data.xfrc_applied[:] = 0\n"
        "for _i in range(n_bodies):\n"
        "    for _j in range(n_bodies):\n"
        "        if _i == _j: continue\n"
        f"        _bi = model.body(f'body_{{_i}}').id\n"
        f"        _bj = model.body(f'body_{{_j}}').id\n"
        "        _dr = data.xpos[_bj] - data.xpos[_bi]\n"
        "        _d3 = (float(np.dot(_dr, _dr)) + eps**2)**1.5\n"
        "        _F  = G * masses[_j] / _d3 * _dr\n"
        "        data.xfrc_applied[_bi, :3] += _F * masses[_i]\n"
    )

    return {
        "xml": xml,
        "param_lines": param_lines,
        "init_code": init_code,
        "force_code": force_code,
        "description": f"N-body orbital motion: {n} bodies, G={G}",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 10. Rocket (RocketEntity)
# ─────────────────────────────────────────────────────────────────────────────

def build_xml_rocket(params: dict[str, Any]) -> dict:
    mass_dry   = float(params.get("mass_dry",   params.get("m", 1.0)))
    thrust     = float(params.get("thrust",     params.get("force", 15.0)))
    burn_time  = float(params.get("burn_time",  params.get("burn_duration", 3.0)))
    angle_deg  = float(params.get("launch_angle", params.get("angle_deg", 90.0)))
    drag_coeff = float(params.get("drag",        params.get("c", 0.01)))

    xml = f"""<mujoco model="rocket">
  <option gravity="0 0 -9.8" timestep="0.005"/>
  <worldbody>
    <!-- Launch pad -->
    <geom name="pad" type="box" size="0.3 0.3 0.05" pos="0 0 0.05"
          rgba="0.4 0.4 0.4 1" contype="0" conaffinity="0"/>
    <!-- Rocket body -->
    <body name="rocket" pos="0 0 0.5">
      <freejoint name="rocket_free"/>
      <!-- Main body cylinder -->
      <geom name="body" type="cylinder" size="0.06 0.3" mass="{mass_dry:.4f}"
            rgba="0.85 0.85 0.85 1"/>
      <!-- Nose cone -->
      <geom name="nose" type="capsule" fromto="0 0 0.3 0 0 0.45" size="0.05"
            mass="0.1" rgba="0.85 0.3 0.2 1"/>
    </body>
    <camera name="side" pos="0 -8 5" xyaxes="1 0 0 0 0.4 0.9"/>
  </worldbody>
</mujoco>"""

    param_lines = (
        f"mass_dry   = {mass_dry}    # dry mass (kg)\n"
        f"thrust     = {thrust}      # thrust force (N)\n"
        f"burn_time  = {burn_time}   # burn duration (s)\n"
        f"angle_deg  = {angle_deg}   # launch angle from vertical (degrees)\n"
        f"drag_coeff = {drag_coeff}  # aerodynamic drag coefficient"
    )

    init_code = (
        "import math\n"
        "free_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, 'rocket_free')\n"
        "# Orient rocket to launch angle\n"
        "angle_r = math.radians(angle_deg)\n"
    )

    force_code = (
        "# Thrust force along rocket's body axis (z-axis in body frame)\n"
        "if data.time <= burn_time:\n"
        "    _rid = model.body('rocket').id\n"
        "    # Thrust in world z direction (simplified: assume vertical launch)\n"
        "    _ax = math.sin(math.radians(angle_deg))\n"
        "    _az = math.cos(math.radians(angle_deg))\n"
        "    data.xfrc_applied[_rid, 0] = thrust * _ax\n"
        "    data.xfrc_applied[_rid, 2] = thrust * _az\n"
        "else:\n"
        "    data.xfrc_applied[:] = 0\n"
        "# Quadratic drag\n"
        "_rid = model.body('rocket').id\n"
        "_vel = data.cvel[_rid, 3:6].copy()  # linear velocity\n"
        "_spd = float(np.linalg.norm(_vel))\n"
        "if _spd > 1e-6:\n"
        "    data.xfrc_applied[_rid, :3] -= drag_coeff * _spd * _vel\n"
    )

    return {
        "xml": xml,
        "param_lines": param_lines,
        "init_code": init_code,
        "force_code": force_code,
        "description": f"Rocket: thrust={thrust} N, burn={burn_time} s, angle={angle_deg}°",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 11. Electromagnetic (MagneticElectricEntity, ElectroMagneticEntity)
#     MuJoCo doesn't model EM; forces applied manually via xfrc_applied
# ─────────────────────────────────────────────────────────────────────────────

def build_xml_em(params: dict[str, Any]) -> dict:
    mass   = float(params.get("mass", params.get("m", 1.0)))
    q      = float(params.get("q",    params.get("charge", 1.0)))
    v_init = params.get("init_velocity", params.get("v_init", [1.0, 0.0, 0.0]))
    vx0    = float(v_init[0]) if len(v_init) > 0 else 1.0
    vy0    = float(v_init[1]) if len(v_init) > 1 else 0.0
    vz0    = float(v_init[2]) if len(v_init) > 2 else 0.0

    # Extract field configs
    field_configs = params.get("field_configs", [])
    E = [0.0, 0.0, 0.0]
    B = [0.0, 0.0, 1.0]   # default: B along z
    for cfg in field_configs:
        if isinstance(cfg, dict):
            ftype = cfg.get("type", "").lower()
            if "electric" in ftype or ftype == "e":
                E = [float(v) for v in cfg.get("value", [0, 0, 0])]
            elif "magnetic" in ftype or ftype == "b":
                B = [float(v) for v in cfg.get("value", [0, 0, 1])]

    xml = f"""<mujoco model="em_particle">
  <!-- Gravity disabled; EM forces applied manually -->
  <option gravity="0 0 0" timestep="0.005" integrator="RK4"/>
  <worldbody>
    <!-- Charged particle -->
    <body name="particle" pos="0 0 0">
      <freejoint name="particle_free"/>
      <geom type="sphere" size="0.08" mass="{mass:.4f}" rgba="0.9 0.8 0.1 1"/>
    </body>
    <camera name="side" pos="0 -8 0" xyaxes="1 0 0 0 0 1"/>
  </worldbody>
</mujoco>"""

    param_lines = (
        f"mass   = {mass}      # particle mass (kg)\n"
        f"q      = {q}         # particle charge (C)\n"
        f"vx0    = {vx0}       # initial vx (m/s)\n"
        f"vy0    = {vy0}       # initial vy (m/s)\n"
        f"vz0    = {vz0}       # initial vz (m/s)\n"
        f"E      = [{E[0]}, {E[1]}, {E[2]}]   # electric field (V/m)\n"
        f"B      = [{B[0]}, {B[1]}, {B[2]}]   # magnetic field (T)"
    )

    init_code = (
        "free_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, 'particle_free')\n"
        "data.qvel[free_id*6]   = vx0\n"
        "data.qvel[free_id*6+1] = vy0\n"
        "data.qvel[free_id*6+2] = vz0\n"
    )

    force_code = (
        "# Lorentz force: F = q*(E + v × B)\n"
        "_pid = model.body('particle').id\n"
        "_v   = data.cvel[_pid, 3:6].copy()  # world-frame linear velocity (cvel[:3] is angular)\n"
        "_E_arr = np.array(E, dtype=float)\n"
        "_B_arr = np.array(B, dtype=float)\n"
        "_F   = q * (_E_arr + np.cross(_v, _B_arr))\n"
        "data.xfrc_applied[_pid, :3] = _F\n"
    )

    return {
        "xml": xml,
        "param_lines": param_lines,
        "init_code": init_code,
        "force_code": force_code,
        "description": f"Charged particle: q={q} C, m={mass} kg, B={B}, E={E}",
    }


# ─────────────────────────────────────────────────────────────────────────────
# 12. Bar / Plank on Support (BarPlaneSupport)
# ─────────────────────────────────────────────────────────────────────────────

def build_xml_bar_support(params: dict[str, Any]) -> dict:
    length  = float(params.get("bar_length",  1.0))
    width   = float(params.get("bar_width",   0.08))
    height  = float(params.get("bar_height",  0.04))
    ratio   = float(params.get("support_ratio", 0.5))
    angle   = float(params.get("bar_angle",   0.0))
    m       = float(params.get("mass", params.get("m", 1.0)))
    b       = float(params.get("damping", 0.05))

    pivot_x = -length/2 + ratio * length

    xml = f"""<mujoco model="bar_support">
  <option gravity="0 0 -9.8" timestep="0.005"/>
  <worldbody>
    <!-- Support pivot -->
    <geom name="support" type="cylinder" size="0.03 0.15" pos="{pivot_x:.4f} 0 0"
          rgba="0.5 0.5 0.5 1" contype="0" conaffinity="0"/>
    <!-- Bar (rotates about pivot) -->
    <body name="bar" pos="{pivot_x:.4f} 0 0.15">
      <joint name="pivot" type="hinge" axis="0 1 0" pos="0 0 0" damping="{b:.4f}"/>
      <geom name="bar_geom" type="box"
            pos="{-pivot_x:.4f} 0 0"
            size="{length/2:.4f} {width/2:.4f} {height/2:.4f}"
            mass="{m:.4f}" rgba="0.6 0.45 0.3 1"/>
    </body>
    <camera name="side" pos="0 -4 1" xyaxes="1 0 0 0 0.2 1"/>
  </worldbody>
</mujoco>"""

    param_lines = (
        f"bar_length    = {length}   # bar length (m)\n"
        f"bar_width     = {width}    # bar width (m)\n"
        f"bar_height    = {height}   # bar thickness (m)\n"
        f"support_ratio = {ratio}    # support position (0=left end, 1=right end)\n"
        f"bar_angle0    = {angle}    # initial tilt angle (degrees)\n"
        f"m             = {m}        # bar mass (kg)"
    )

    init_code = (
        "import math\n"
        "pivot_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, 'pivot')\n"
        "data.qpos[pivot_id] = math.radians(bar_angle0)\n"
        "mujoco.mj_forward(model, data)\n"
    )

    return {
        "xml": xml,
        "param_lines": param_lines,
        "init_code": init_code,
        "force_code": "",
        "description": f"Bar on support: L={length} m, pivot at {ratio*100:.0f}% from left",
    }


# ─────────────────────────────────────────────────────────────────────────────
# Registry: maps entity type → builder function
# ─────────────────────────────────────────────────────────────────────────────

BUILDER_REGISTRY: dict[str, callable] = {
    # Throwing / projectile
    "ThrowingMotionEntity":          build_xml_throwing,
    # Inclined plane / mass on slope
    "TwoSideMassPlane":              build_xml_inclined_plane,
    "MassPrismPlaneEntity":          build_xml_inclined_plane,
    "StackedMassPlane":              build_xml_inclined_plane,
    "MassBoxPlaneEntity":            build_xml_inclined_plane,
    # Pulley / Atwood
    "MassWithFixedPulley":           build_xml_pulley,
    "MassWithMovablePulley":         build_xml_pulley,
    "MassWithReversedMovablePulley": build_xml_pulley,
    "ConstantForceFixedPulley":      build_xml_pulley,
    "DirectedMass":                  build_xml_pulley,
    "MassPrismPulleyPlane":          build_xml_pulley,
    # Collision
    "TwoDCollisionPlane":            build_xml_collision,
    "ComplexCollisionPlane":         build_xml_collision,
    # Spring
    "SpringBlockEntity":             build_xml_spring_block,
    "SpringMassPlaneEntity":         build_xml_spring_block,
    # Pendulum / rotation
    "PendulumEntity":                build_xml_pendulum,
    "RigidRotationEntity":           build_xml_rigid_rotation,
    "BarPlaneSupport":               build_xml_bar_support,
    # Orbital / celestial
    "OrbitalMotionEntity":           build_xml_orbital,
    "SolarSystemEntity":             build_xml_orbital,
    "GeneralCelestialEntity":        build_xml_orbital,
    # Rolling
    "RollingPlaneEntity":            build_xml_rolling,
    # Rocket
    "RocketEntity":                  build_xml_rocket,
    # Electromagnetic
    "MagneticElectricEntity":        build_xml_em,
    "ElectroMagneticEntity":         build_xml_em,
}
