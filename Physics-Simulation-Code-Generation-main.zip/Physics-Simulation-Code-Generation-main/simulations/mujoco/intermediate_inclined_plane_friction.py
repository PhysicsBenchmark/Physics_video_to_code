"""MuJoCo experiment wrapper for Sim2Reason subtype IntermediateInclinedPlaneFriction."""

from ._base import generate_sample_for_subtype

SUBTYPE = "IntermediateInclinedPlaneFriction"


def generate_sample(seed: int, out_dir: str, duration: float = 10.0, fps: int = 30, run_video: bool = True):
    return generate_sample_for_subtype(SUBTYPE, seed, out_dir, duration=duration, fps=fps, run_video=run_video)
