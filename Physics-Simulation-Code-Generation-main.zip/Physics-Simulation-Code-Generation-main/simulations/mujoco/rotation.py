"""MuJoCo experiment wrapper for Sim2Reason subtype Rotation."""

from ._base import generate_sample_for_subtype

SUBTYPE = "Rotation"


def generate_sample(seed: int, out_dir: str, duration: float = 10.0, fps: int = 30, run_video: bool = True):
    return generate_sample_for_subtype(SUBTYPE, seed, out_dir, duration=duration, fps=fps, run_video=run_video)
