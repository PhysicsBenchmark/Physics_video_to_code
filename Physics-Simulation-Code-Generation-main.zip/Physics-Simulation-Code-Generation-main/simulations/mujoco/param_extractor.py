"""
param_extractor.py
==================
Reads a Sim2Reason scene_output.yaml and extracts physics parameters
into a plain Python dict, along with the primary entity type string.

Sim2Reason stores scene data as a YAML file whose top-level keys include:
  - entities: list of entity dicts, each with:
      - class_name: str (e.g. "PendulumEntity", "OrbitalMotionEntity", ...)
      - name: str
      - params: dict  (entity-specific physics params)
  - tendons: list (pulley string connections)

The extractor walks the entity list, identifies the PRIMARY physics entity
(i.e. the first non-pulley, non-structural entity), and returns its params.

For composite scenes (pulley + mass systems), it synthesises an Atwood/Inclined
params dict from the mass and pulley entities it finds.
"""

from __future__ import annotations
import math
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError:
    yaml = None  # type: ignore

# ── Structural entity classes that are NOT the "primary" physics entity ────
_STRUCTURAL = {
    "FixedPulleyEntity",
    "MassWithFixedPulley",        # is both structural and "primary" — handled below
    "ConstantForceFixedPulley",
    "MassWithMovablePulley",
    "MassWithReversedMovablePulley",
    "DirectedMass",
}

# Entities whose params we directly pass through
_DIRECT_PASS = {
    "PendulumEntity",
    "SpringBlockEntity",
    "TwoDCollisionPlane",
    "ComplexCollisionPlane",
    "RigidRotationEntity",
    "OrbitalMotionEntity",
    "SolarSystemEntity",
    "RollingPlaneEntity",
    "ThrowingMotionEntity",
    "SpringMassPlaneEntity",
    "MagneticElectricEntity",
    "ElectroMagneticEntity",
    "RocketEntity",
    "MassPrismPulleyPlane",
}


def _load_yaml(path: str | Path) -> dict:
    if yaml is None:
        raise ImportError("PyYAML is required: pip install pyyaml")
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _first_entity(scene: dict) -> dict | None:
    """Return the first entity dict from the scene."""
    scene = scene.get("scene", scene)  # unwrap top-level "scene:" key if present
    entities = scene.get("entities", [])
    if isinstance(entities, list) and entities:
        return entities[0]
    if isinstance(entities, dict):
        first_key = next(iter(entities))
        return {"class_name": first_key, **entities[first_key]}
    return None


def _collect_masses(scene: dict) -> list[dict]:
    """Return all entities that have a 'mass' or 'masses' param."""
    result = []
    for ent in scene.get("entities", []):
        p = ent.get("params", {})
        if "mass" in p or "masses" in p or "mass_list" in p:
            result.append(ent)
    return result


# ── Per-entity-type param extraction ──────────────────────────────────────

def _extract_pendulum(params: dict) -> dict:
    """PendulumEntity → SimplePendulumParams fields."""
    return {
        "L":      float(params.get("length", params.get("L", 1.0))),
        "m":      float(params.get("mass",   params.get("m",   1.0))),
        "g":      float(params.get("g", 9.8)),
        "b":      float(params.get("damping", params.get("b", 0.2))),
        "A":      0.0,
        "k_freq": 0.0,
        "theta0": float(params.get("theta0", params.get("init_angle", 0.5))),
        "omega0": float(params.get("omega0", 0.0)),
    }


def _extract_spring_block(params: dict) -> dict:
    """SpringBlockEntity → SingleSpringParams fields."""
    return {
        "k":  float(params.get("spring_constant", params.get("k", 5.0))),
        "m":  float(params.get("mass", params.get("m", 1.0))),
        "b":  float(params.get("damping", params.get("b", 0.2))),
        "u0": float(params.get("displacement", params.get("u0", 0.5))),
        "v0": float(params.get("init_velocity", params.get("v0", 0.0))),
    }


def _extract_collision(params: dict) -> dict:
    """TwoDCollisionPlane / ComplexCollisionPlane → Billiard2DParams fields."""
    n = int(params.get("num_objects", params.get("N", 4)))
    return {
        "N":       n,
        "m":       float(params.get("mass", 0.17)),
        "R":       float(params.get("radius", params.get("R", 0.057))),
        "mu":      float(params.get("friction", params.get("mu", 0.02))),
        "g":       9.81,
        "e_ball":  float(params.get("restitution", params.get("e_ball", 0.95))),
        "e_wall":  0.9,
        "table_w": float(params.get("width",  2.54)),
        "table_h": float(params.get("height", 1.27)),
        "cue_x0":  -0.9,
        "cue_y0":  0.0,
        "cue_vx0": float(params.get("init_speed", 5.0)),
        "cue_vy0": 0.0,
        "seed":    0,
    }


def _extract_rigid_rotation(params: dict) -> dict:
    """RigidRotationEntity → RigidRotationParams fields."""
    shape_map = {
        "disk":     "disk",
        "cylinder": "disk",
        "rod":      "rod",
        "ring":     "ring",
        "bar":      "rod",
    }
    raw_shape = str(params.get("shape", "disk")).lower()
    shape = shape_map.get(raw_shape, "disk")
    return {
        "m":      float(params.get("mass", params.get("m", 1.0))),
        "r":      float(params.get("radius", params.get("length", params.get("r", 0.5)))),
        "b":      float(params.get("damping", params.get("b", 0.2))),
        "tau":    float(params.get("torque", params.get("tau", 0.5))),
        "theta0": float(params.get("init_angle", params.get("theta0", 0.0))),
        "omega0": float(params.get("init_omega", params.get("omega0", 0.0))),
        "shape":  shape,
    }


def _extract_orbital(params: dict) -> dict:
    """OrbitalMotionEntity / SolarSystemEntity → OrbitalMotionParams (scalar Kepler) fields.

    Sim2Reason stores list-based relative_positions and init_velocities.
    We extract the two primary bodies and compute the Kepler scalars (r0, e, angle).
    """
    mass_list = params.get("mass_list", params.get("masses", [3.0, 1.0]))
    rel_pos   = params.get("relative_positions", [(0, 0), (1.5, 0.0)])
    init_vel  = params.get("init_velocities", [0.0, 1.4])

    m1 = float(mass_list[0]) if mass_list else 3.0
    m2 = float(mass_list[1]) if len(mass_list) > 1 else 1.0

    # Separation and angle from the first pair of bodies
    if len(rel_pos) >= 2:
        r1, theta1_deg = rel_pos[1][0], rel_pos[1][1]
        r0    = float(r1)
        angle = math.radians(float(theta1_deg))
    else:
        r0, angle = 1.5, 0.0

    # Estimate eccentricity from the tangential speed vs circular speed
    G = float(params.get("G_constant", 1.0))
    M = m1 + m2
    v_circ = math.sqrt(G * M / max(r0, 1e-6))
    v_actual = float(init_vel[1]) if len(init_vel) > 1 else v_circ
    # v_peri = sqrt(G*M*(1+e)/r0) → e = v²*r0/(G*M) - 1
    e = max(0.0, min(0.9, v_actual ** 2 * r0 / (G * M) - 1.0))

    return {
        "m1":    m1,
        "m2":    m2,
        "G":     G,
        "r0":    r0,
        "e":     e,
        "angle": angle,
        "eps":   0.02,
        "trail_len": 90,
    }


def _extract_throwing(params: dict) -> dict:
    """ThrowingMotionEntity → ProjectileMotionParams fields."""
    vx = float(params.get("init_vx", params.get("velocity_x", 10.0)))
    vy = float(params.get("init_vy", params.get("velocity_y", 10.0)))
    speed = math.hypot(vx, vy)
    angle = math.atan2(vy, vx)
    return {
        "m":     float(params.get("mass", params.get("m", 1.0))),
        "g":     float(params.get("g", 9.8)),
        "c":     float(params.get("drag", params.get("c", 0.0))),
        "v0":    speed,
        "theta": angle,
        "x0":    float(params.get("x", 0.0)),
        "y0":    float(params.get("y", 0.0)),
        "trail_len": 120,
    }


def _extract_rolling(params: dict) -> dict:
    """RollingPlaneEntity → RollingPlaneParams fields."""
    shape_map = {
        "sphere":           "solid_sphere",
        "solid_sphere":     "solid_sphere",
        "cylinder":         "solid_cylinder",
        "solid_cylinder":   "solid_cylinder",
        "hollow_cylinder":  "hollow_cylinder",
        "ring":             "hollow_cylinder",
        "hollow_sphere":    "hollow_sphere",
    }
    raw = str(params.get("shape", "sphere")).lower()
    shape = shape_map.get(raw, "solid_sphere")
    return {
        "m":       float(params.get("mass", params.get("m", 1.0))),
        "r":       float(params.get("radius", params.get("r", 0.15))),
        "g":       float(params.get("g", 9.8)),
        "theta":   float(params.get("angle", params.get("theta", 0.35))),
        "b":       float(params.get("damping", params.get("b", 0.02))),
        "L_plane": float(params.get("length", params.get("L_plane", 5.0))),
        "x0":      float(params.get("init_pos", params.get("x0", 0.0))),
        "v0":      float(params.get("init_vel", params.get("v0", 0.5))),
        "shape":   shape,
    }


def _extract_atwood(entities: list[dict]) -> dict:
    """MassWithFixedPulley scene → AtwoodMachineParams fields.
    Takes the two mass entities and builds an Atwood machine params dict.
    """
    masses = []
    for ent in entities:
        p = ent.get("parameters", ent.get("params", {}))
        m = float(p.get("mass", p.get("m", 1.0)))
        masses.append(m)
    while len(masses) < 2:
        masses.append(1.0)
    return {
        "m1": masses[0],
        "m2": masses[1],
        "g":  9.8,
        "b":  0.05,
        "L":  2.0,
        "x0": 0.0,
        "v0": 0.0,
    }


def _extract_inclined(params: dict) -> dict:
    """TwoSideMassPlane / MassPrismPlaneEntity → InclinedPlaneParams fields."""
    return {
        "m":       float(params.get("mass", params.get("m", 1.0))),
        "g":       float(params.get("g", 9.8)),
        "theta":   float(params.get("angle", params.get("theta", 0.4))),
        "mu":      float(params.get("friction", params.get("mu", 0.15))),
        "L_plane": float(params.get("length", params.get("L_plane", 4.0))),
        "x0":      float(params.get("init_pos", params.get("x0", 0.5))),
        "v0":      float(params.get("init_vel", params.get("v0", 2.0))),
    }


# ── Public API ─────────────────────────────────────────────────────────────

def _normalize_for_builder(entity_class: str, raw: dict) -> dict:
    """
    Convert Sim2Reason native YAML param keys into the keys that the
    MuJoCo XML builders expect.  Only applied when the two naming schemes differ.
    """
    # ── PendulumEntity ─────────────────────────────────────────────────────────
    if entity_class == "PendulumEntity":
        out = dict(raw)
        out.setdefault("length",     raw.get("rope_length", 1.0))
        out.setdefault("mass",       raw.get("mass_value",  1.0))
        out.setdefault("init_angle", raw.get("angle",       0.5))
        # init_velocity_dict → scalar omega0
        if "init_velocity_dict" in raw and "omega0" not in raw:
            vd = raw["init_velocity_dict"]
            if isinstance(vd, dict):
                first = next(iter(vd.values()), [0.0])
                out["omega0"] = float(first[0]) if first else 0.0
        return out

    # ── SolarSystemEntity → masses + x/y/vx/vy lists ─────────────────────────
    if entity_class == "SolarSystemEntity":
        star_mass = float(raw.get("star_mass", 1.0))
        star_r    = float(raw.get("star_radius", 0.5))
        planets   = raw.get("planets", [])
        masses  = [star_mass] + [float(p.get("mass", 1.0)) for p in planets]
        x_init  = [0.0]  + [float(p["position"][0]) for p in planets]
        y_init  = [0.0]  + [float(p["position"][1]) for p in planets]
        vx_init = [0.0]  + [float(p["velocity"][0]) for p in planets]
        vy_init = [0.0]  + [float(p["velocity"][1]) for p in planets]
        return {
            "masses": masses,
            "x_init": x_init,
            "y_init": y_init,
            "vx_init": vx_init,
            "vy_init": vy_init,
            "G":   float(raw.get("G_constant", 1.0)),
            "eps": 0.05,
            "_star_radius": star_r,
        }

    # ── SpringBlockEntity / SpringMassPlaneEntity ─────────────────────────────
    # These have lists of springs; pick the first spring for a single-block sim
    if entity_class in ("SpringBlockEntity", "SpringMassPlaneEntity"):
        out = dict(raw)
        # SpringBlockEntity: stiffnesses / original_lengths lists
        stiffnesses = raw.get("stiffnesses", [])
        if stiffnesses and "spring_constant" not in raw and "k" not in raw:
            out["spring_constant"] = float(stiffnesses[0])
        lengths = raw.get("original_lengths", [])
        if lengths and "displacement" not in raw and "u0" not in raw:
            out["displacement"] = float(lengths[0])
        # SpringMassPlaneEntity: spring_configs list
        cfgs = raw.get("spring_configs", [])
        if cfgs and "spring_constant" not in out:
            out["spring_constant"] = float(cfgs[0].get("k", 5.0))
            out.setdefault("damping", float(cfgs[0].get("damping", 0.2)))
        # mass from mass_values list
        mvs = raw.get("mass_values", [])
        if mvs and "mass" not in raw and "m" not in raw:
            out["mass"] = float(mvs[0])
        return out

    # ── RigidRotationEntity ───────────────────────────────────────────────────
    if entity_class == "RigidRotationEntity":
        out = dict(raw)
        bodies = raw.get("rigid_bodies", [])
        if bodies:
            b0 = bodies[0]
            out.setdefault("mass",   float(b0.get("mass", 1.0)))
            out.setdefault("length", float(b0.get("length", b0.get("radius", 0.5))))
            out.setdefault("shape",  str(b0.get("body_type", "bar")))
        joint = raw.get("joint", {})
        ax = joint.get("axis", [0, 1, 0])
        out.setdefault("axis", ax)
        return out

    # ── ElectroMagneticEntity / MagneticElectricEntity ────────────────────────
    if entity_class in ("ElectroMagneticEntity", "MagneticElectricEntity"):
        out = dict(raw)
        iv = raw.get("init_velocity", [0.0]*6)
        if isinstance(iv, list):
            out.setdefault("vx0", float(iv[0]) if len(iv) > 0 else 0.0)
            out.setdefault("vy0", float(iv[1]) if len(iv) > 1 else 0.0)
            out.setdefault("vz0", float(iv[2]) if len(iv) > 2 else 0.0)
        # flatten field_configs into simple keys
        # field_strength can be a number, a list [Fx,Fy,Fz], or a string label
        # like 'field_polynomial' for non-uniform fields; coerce safely.
        def _scalar_field_strength(fs):
            if fs is None:
                return 0.0
            if isinstance(fs, (list, tuple)):
                return float(fs[0]) if fs else 0.0
            try:
                return float(fs)
            except (TypeError, ValueError):
                return 0.0
        B, E = 0.0, 0.0
        for fc in raw.get("field_configs", []):
            if fc.get("field_type") == "magnetic":
                B = _scalar_field_strength(fc.get("field_strength"))
            elif fc.get("field_type") == "electric":
                E = _scalar_field_strength(fc.get("field_strength"))
        out.setdefault("B", B)
        out.setdefault("E", E)
        return out

    # ── TwoSideMassPlane / MassPrismPlaneEntity ───────────────────────────────
    # The slope lives on the MassWithFixedPulley entity in the same scene,
    # so we fall back to 0 for now (not enough info in just the primary entity).
    if entity_class in ("TwoSideMassPlane", "MassPrismPlaneEntity", "StackedMassPlane"):
        out = dict(raw)
        mvs = raw.get("mass_values", [])
        if mvs and "m" not in raw:
            out["m"] = float(mvs[0])
        return out

    # ── MassPrismPulleyPlane → two-mass pulley ────────────────────────────────
    if entity_class == "MassPrismPulleyPlane":
        out = dict(raw)
        out.setdefault("m1", float(raw.get("block_left_mass_value",  1.5)))
        out.setdefault("m2", float(raw.get("block_right_mass_value", 1.0)))
        return out

    # Default: pass through unchanged
    return dict(raw)


def extract_raw_params(yaml_path: str | Path) -> tuple[str, dict[str, Any]]:
    """
    Read a Sim2Reason scene_output.yaml and return:
        (entity_type: str, params_dict: dict)

    Unlike extract_params(), this extracts the raw YAML parameters and applies
    only the minimal key-renaming needed for the MuJoCo XML builders to work.
    This preserves all scene-specific values (masses, positions, velocities, radii, etc.)
    so the generated MuJoCo script faithfully reproduces the Sim2Reason scene.
    """
    raw = _load_yaml(yaml_path)
    scene = raw.get("scene", raw)
    entities: list[dict] = scene.get("entities", [])

    if not entities:
        raise ValueError(f"No entities found in {yaml_path}")

    def _cls(ent):
        return ent.get("type", ent.get("class_name", ""))

    def _params(ent):
        return ent.get("parameters", ent.get("params", {}))

    # Find primary entity
    primary = None
    primary_class = None

    for ent in entities:
        cls = _cls(ent)
        if cls in _DIRECT_PASS:
            primary = ent
            primary_class = cls
            break

    if primary is None:
        all_classes = [_cls(e) for e in entities]
        if any(c in ("TwoSideMassPlane", "MassPrismPlaneEntity", "StackedMassPlane")
               for c in all_classes):
            primary_class = "TwoSideMassPlane"
            for ent in entities:
                if _cls(ent) in ("TwoSideMassPlane", "MassPrismPlaneEntity"):
                    primary = ent
                    break
        elif any(c in ("MassWithFixedPulley", "MassWithMovablePulley",
                       "MassWithReversedMovablePulley") for c in all_classes):
            primary_class = "MassWithFixedPulley"
            primary = None

    if primary_class is None:
        primary = entities[0]
        primary_class = _cls(primary) or "Unknown"

    if primary_class == "MassWithFixedPulley":
        masses = []
        for ent in entities:
            p = _params(ent)
            mvs = p.get("mass_values", [])
            m = float(mvs[0]) if mvs else float(p.get("mass", p.get("m", 1.0)))
            masses.append(m)
        while len(masses) < 2:
            masses.append(1.0)
        raw_params: dict[str, Any] = {"m1": masses[0], "m2": masses[1]}
    else:
        raw_params = _normalize_for_builder(primary_class, _params(primary or {}))

    return primary_class, raw_params


def extract_params(yaml_path: str | Path) -> tuple[str, dict[str, Any]]:
    """
    Read a Sim2Reason scene_output.yaml and return:
        (entity_type: str, params_dict: dict)

    entity_type is one of the Sim2Reason class names (e.g. "PendulumEntity").
    params_dict contains the extracted physics parameters ready to pass to our
    simulation modules.
    """
    raw = _load_yaml(yaml_path)
    # Sim2Reason YAMLs nest everything under a top-level "scene:" key
    scene = raw.get("scene", raw)
    entities: list[dict] = scene.get("entities", [])

    if not entities:
        raise ValueError(f"No entities found in {yaml_path}")

    def _cls(ent):
        """Get entity class name — YAML uses 'type', legacy uses 'class_name'."""
        return ent.get("type", ent.get("class_name", ""))

    def _params(ent):
        """Get entity params dict — YAML uses 'parameters', legacy uses 'params'."""
        return ent.get("parameters", ent.get("params", {}))

    # --- Find primary entity ---
    primary = None
    primary_class = None

    for ent in entities:
        cls = _cls(ent)
        if cls in _DIRECT_PASS:
            primary = ent
            primary_class = cls
            break

    # --- Pulley / inclined plane composite scenes ---
    if primary is None:
        all_classes = [_cls(e) for e in entities]

        if any(c in ("TwoSideMassPlane", "MassPrismPlaneEntity", "StackedMassPlane")
               for c in all_classes):
            primary_class = "TwoSideMassPlane"
            for ent in entities:
                if _cls(ent) in ("TwoSideMassPlane", "MassPrismPlaneEntity"):
                    primary = ent
                    break

        elif any(c in ("MassWithFixedPulley", "MassWithMovablePulley",
                       "MassWithReversedMovablePulley") for c in all_classes):
            primary_class = "MassWithFixedPulley"
            primary = None  # will use multi-entity extraction below

    if primary_class is None:
        # Fall back to first entity
        primary = entities[0]
        primary_class = _cls(primary) or "Unknown"

    # --- Extract params ---
    raw_params = _params(primary or {})

    _EXTRACTORS = {
        "PendulumEntity":               _extract_pendulum,
        "SpringBlockEntity":            _extract_spring_block,
        "SpringMassPlaneEntity":        _extract_spring_block,
        "TwoDCollisionPlane":           _extract_collision,
        "ComplexCollisionPlane":        _extract_collision,
        "RigidRotationEntity":          _extract_rigid_rotation,
        "OrbitalMotionEntity":          _extract_orbital,
        "SolarSystemEntity":            _extract_orbital,
        "RollingPlaneEntity":           _extract_rolling,
        "ThrowingMotionEntity":         _extract_throwing,
        "TwoSideMassPlane":             _extract_inclined,
        "MassPrismPlaneEntity":         _extract_inclined,
        "StackedMassPlane":             _extract_inclined,
    }

    if primary_class == "MassWithFixedPulley":
        params_dict = _extract_atwood(entities)
    elif primary_class in _EXTRACTORS:
        params_dict = _EXTRACTORS[primary_class](raw_params)
    else:
        # Generic fallback: return raw params as-is
        params_dict = dict(raw_params)

    return primary_class, params_dict
