"""MuJoCo/Sim2Reason engine helpers."""

from pathlib import Path
from typing import Union

from .param_extractor import extract_params, extract_raw_params
from .mujoco_xml_builders import BUILDER_REGISTRY
from .mujoco_script_writer import make_mujoco_script


def generate_mujoco_script(
    yaml_path: Union[str, Path],
    duration: float = 10.0,
    fps: int = 30,
) -> str:
    """
    Generate a standalone MuJoCo simulation script for the scene described in
    *yaml_path* (a Sim2Reason ``scene_output.yaml`` file).

    The returned string is valid Python source code.  Save it as e.g.
    ``simulation_mujoco.py`` and run it directly::

        python simulation_mujoco.py   # writes simulation.mp4

    Requirements for the generated script:  ``mujoco``  ``imageio``  ``numpy``

    Parameters
    ----------
    yaml_path : str | Path
        Path to a Sim2Reason ``scene_output.yaml`` file.
    duration : float
        Simulation duration in seconds (default 10.0).
    fps : int
        Output video frame rate (default 30).

    Returns
    -------
    str
        Complete Python source code for the standalone simulation.

    Raises
    ------
    KeyError
        If the entity type found in the YAML is not yet supported.
    """
    entity_type, params = extract_raw_params(Path(yaml_path))
    return make_mujoco_script(entity_type, params, duration=duration, fps=fps)


__all__ = [
    "extract_params",
    "BUILDER_REGISTRY",
    "generate_mujoco_script",
    "make_mujoco_script",
]
