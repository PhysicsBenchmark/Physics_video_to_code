"""seesaw_with_falling_mass — real-life PyBullet/pyrender teaching scene."""
from __future__ import annotations

from dataclasses import asdict

from ._real_life_scenes import Params, build_params, generate_sample_from_experiment, make_standalone_code as _make_code

EXPERIMENT = "seesaw_with_falling_mass"


def random_params(seed: int) -> Params:
    return build_params(EXPERIMENT, seed)


def make_standalone_code(params: Params) -> str:
    return _make_code(params)


def generate_sample(seed: int, out_dir: str):
    return generate_sample_from_experiment(EXPERIMENT, seed, out_dir)


if __name__ == "__main__":
    generate_sample(seed=0, out_dir=f"/tmp/test_seesaw_with_falling_mass")
    print("OK")
