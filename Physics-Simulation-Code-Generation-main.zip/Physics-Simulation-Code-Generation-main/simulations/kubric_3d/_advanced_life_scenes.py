"""Additional robust real-life Kubric/PyBullet teaching scenes."""
from __future__ import annotations

import math
import random
from dataclasses import asdict
from typing import Any

from ._real_life_scenes import (
    CAM_DEFAULT,
    TARGET_DEFAULT,
    N_FRAMES,
    Params,
    _base_summary,
    _box,
    _capsule,
    _color,
    _cylinder,
    _sphere,
    _visual,
)

EXPERIMENTS = [
    "spinning_rod_balloon_tether",
    "balloon_tether_wall_pull",
    "stick_support_catapult_release",
    "elastic_coupled_cart_collision",
    "crank_push_friction_stop",
    "double_pendulum_impact_transfer",
    "carried_pendulum_inertia",
    "turntable_mirror_blocks",
    "wind_balanced_falling_panel",
    "fan_push_stationary_block",
    "moving_cart_hits_stationary_cart",
    "moving_cart_hits_moving_cart",
    "plasticine_ball_inelastic_drop",
    "oblique_projectile_hits_slope",
    "rolling_ball_up_slope",
    "accelerating_panel_spins_objects",
    "center_vs_offset_seesaw",
    "spring_compress_vs_stretch",
    "concave_bowl_spin_orbit",
    "springboard_rebound_ball",
    "vertical_fall_spinning_panel",
    "rod_spin_hits_balloon",
    "block_wall_hit_by_tethered_mass",
    "offset_load_turntable",
    "ramp_to_spring_projectile",
]


def build_params(experiment: str, seed: int) -> Params:
    rng = random.Random(seed + abs(hash(experiment)) % 100000)
    red=[0.85,0.18,0.14,1]; blue=[0.16,0.42,0.86,1]; green=[0.2,0.72,0.34,1]
    yellow=[0.94,0.74,0.18,1]; grey=[0.45,0.45,0.5,1]; wood=[0.55,0.34,0.16,1]
    objects=[]; summary={}; cam=CAM_DEFAULT; target=TARGET_DEFAULT; floor=7.0
    if experiment == "spinning_rod_balloon_tether":
        omega=rng.uniform(1.6,3.0); L=rng.uniform(0.9,1.3)
        objects += [_visual(_cylinder("center_post",0.04,0.8,[0,0,0.45],0,grey)),
                    _visual(_box("spinning_rod",[L/2,0.035,0.035],[0,0,0.92],0,wood,orn=[0,0,0.25])),
                    _sphere("balloon",0.15,[L,0,0.94],0.06,blue,vel=[0,omega*L,0],friction=0.05,restitution=0.65),
                    _visual(_capsule("tether",0.01,L,[L/2,0,0.94],0,yellow,orn=[0,math.pi/2,0]))]
        summary={"angular_speed_rad_s":omega,"tether_length":L,"centripetal_accel":omega*omega*L}
    elif experiment == "balloon_tether_wall_pull":
        for i in range(4):
            for j in range(3): objects.append(_box(f"wall_{i}_{j}",[0.16,0.12,0.10],[0.15*i,0,0.12+0.21*j],0.35,_color(rng),friction=0.6,restitution=0.25))
        objects += [_sphere("balloon",0.18,[0.35,0,1.05],0.04,blue,vel=[0.30,0,0.45],restitution=0.35), _visual(_capsule("tether",0.01,0.7,[0.28,0,0.82],0,yellow))]
        summary={"n_wall_blocks":12,"visible_tether_pull":"initial balloon velocity pulls visible tether"}
    elif experiment == "stick_support_catapult_release":
        objects += [_box("lever",[0.9,0.08,0.04],[0,0,0.35],0.7,wood,orn=[0,-0.18,0],ang_vel=[0,-2.0,0],friction=0.5), _cylinder("pivot",0.08,0.35,[-0.15,0,0.22],0,grey,orn=[math.pi/2,0,0]), _visual(_capsule("failed_support",0.025,0.55,[0.42,0,0.25],0,red,orn=[0.35,0,0])), _sphere("projectile",0.11,[0.62,0,0.55],0.25,yellow,vel=[0.9,0,1.3],restitution=0.5)]
        summary={"lever_arm_m":0.9,"projectile_launch_speed":"visible lever angular velocity"}
    elif experiment == "elastic_coupled_cart_collision":
        objects += [_box("cart_left",[0.22,0.16,0.12],[-0.75,0,0.22],0.5,blue,friction=0.1,restitution=0.8), _box("cart_right",[0.22,0.16,0.12],[-0.30,0,0.22],0.5,green,friction=0.1,restitution=0.8), _sphere("incoming_cart",0.14,[-1.55,0,0.25],0.35,red,vel=[1.4,0,0],restitution=0.9), _visual(_capsule("spring_between",0.018,0.45,[-0.52,0,0.28],0,yellow,orn=[0,math.pi/2,0]))]
        summary={"spring_visual_length":0.45,"incoming_speed":1.4}
    elif experiment == "crank_push_friction_stop":
        objects += [_visual(_cylinder("crank_center",0.08,0.08,[-0.8,0,0.35],0,grey,orn=[math.pi/2,0,0])), _box("crank_arm",[0.42,0.04,0.04],[-0.48,0,0.35],0.2,yellow,vel=[0.7,0,0],ang_vel=[0,0,2.5]), _box("block",[0.24,0.22,0.18],[0.25,0,0.28],0.8,red,vel=[0.9,0,0],friction=0.8,restitution=0.2)]
        summary={"block_friction":0.8,"work_to_heat":"friction dissipates crank impulse"}
    elif experiment == "double_pendulum_impact_transfer":
        objects += [_sphere("bob1",0.12,[-0.4,0,1.05],0.35,blue,vel=[0.7,0,-0.2],restitution=0.7), _sphere("bob2",0.11,[0.0,0,0.55],0.3,green,vel=[1.3,0,0],restitution=0.8), _box("target",[0.18,0.18,0.16],[0.65,0,0.24],0.45,red,friction=0.45,restitution=0.7), _visual(_capsule("rod1",0.01,0.7,[-0.22,0,1.25],0,yellow,orn=[0.45,0,0])), _visual(_capsule("rod2",0.01,0.65,[-0.18,0,0.80],0,yellow,orn=[0.65,0,0]))]
        summary={"impact_target":"second bob to block","chaotic_transfer":"visible double pendulum-like linkage"}
    elif experiment == "carried_pendulum_inertia":
        objects += [_box("cart",[0.55,0.28,0.16],[-0.6,0,0.24],0.9,blue,vel=[1.1,0,0],friction=0.7), _sphere("bob",0.13,[-0.75,0,0.95],0.25,red,vel=[0.2,0,0],restitution=0.5), _visual(_capsule("string",0.01,0.75,[-0.68,0,1.25],0,yellow,orn=[0.22,0,0]))]
        summary={"cart_acceleration_proxy":"cart starts moving; bob lags by inertia"}
    elif experiment == "turntable_mirror_blocks":
        objects += [_visual(_cylinder("turntable",0.9,0.08,[0,0,0.12],0,grey,orn=[0,0,0]))]
        for i in range(4): objects.append(_box(f"block_{i}",[0.12,0.10,0.08],[0.25*math.cos(i*math.pi/2),0.25*math.sin(i*math.pi/2),0.24],0.2,_color(rng),vel=[-0.4*math.sin(i),0.4*math.cos(i),0],friction=0.35,restitution=0.5))
        summary={"turntable_omega_rad_s":2.5,"friction_limit":"blocks slide when m omega^2 r > mu m g"}
    elif experiment == "wind_balanced_falling_panel":
        objects += [_box("light_panel",[0.35,0.03,0.45],[-0.4,0,1.5],0.18,blue,vel=[0.45,0,-0.5],friction=0.2,restitution=0.4)]
        for i in range(10): objects.append(_sphere(f"fan_particle_{i}",0.035,[-1.4,0.05*(i-5),0.7+0.08*i],0.03,green,vel=[1.6,0,0.1],restitution=0.9))
        summary={"visible_fan_particles":10,"force_balance":"panel has gravity and visible particle impacts"}
    elif experiment == "fan_push_stationary_block":
        objects += [_box("light_block",[0.22,0.18,0.18],[-0.25,0,0.28],0.25,red,friction=0.25,restitution=0.5), _box("fixed_stop",[0.08,0.45,0.35],[0.9,0,0.35],0,grey)]
        for i in range(12): objects.append(_sphere(f"air_particle_{i}",0.03,[-1.3,0.04*(i-6),0.25+0.03*(i%4)],0.025,green,vel=[1.8,0,0],restitution=0.9))
        summary={"visible_particles":12,"block_mass":0.25}
    elif experiment == "moving_cart_hits_stationary_cart":
        objects += [_box("moving_cart",[0.28,0.18,0.14],[-1.0,0,0.22],0.7,red,vel=[1.4,0,0],friction=0.12,restitution=0.8), _box("stationary_cart",[0.28,0.18,0.14],[0.0,0,0.22],0.8,blue,friction=0.12,restitution=0.8)]
        summary={"moving_cart_speed":1.4,"stationary_cart_speed":0.0}
    elif experiment == "moving_cart_hits_moving_cart":
        objects += [_box("cart_A",[0.28,0.18,0.14],[-1.0,0,0.22],0.7,red,vel=[1.5,0,0],friction=0.12,restitution=0.85), _box("cart_B",[0.28,0.18,0.14],[0.6,0,0.22],0.9,blue,vel=[-0.7,0,0],friction=0.12,restitution=0.85)]
        summary={"relative_speed":2.2,"center_of_mass_frame":"both carts moving before impact"}
    elif experiment == "plasticine_ball_inelastic_drop":
        objects += [_box("plate",[0.9,0.6,0.06],[0,0,0.08],0,grey,friction=0.6,restitution=0.05), _sphere("plasticine_ball",0.18,[0,0,1.5],0.4,[0.65,0.15,0.75,1],vel=[0,0,-0.2],friction=0.8,restitution=0.02)]
        summary={"restitution":0.02,"collision_type":"nearly perfectly inelastic"}
    elif experiment == "oblique_projectile_hits_slope":
        theta=math.radians(25); objects += [_box("slope",[1.4,0.55,0.06],[0.3,0,0.45],0,grey,orn=[0,-theta,0],friction=0.45,restitution=0.55), _sphere("projectile",0.11,[-1.2,0,1.0],0.25,red,vel=[1.7,0,0.4],friction=0.2,restitution=0.75)]
        summary={"slope_angle_deg":25,"impact_components":"normal and tangential velocities differ"}
    elif experiment == "rolling_ball_up_slope":
        theta=math.radians(18); objects += [_box("ramp",[1.8,0.6,0.06],[0.3,0,0.35],0,grey,orn=[0,-theta,0],friction=0.8), _sphere("ball",0.14,[-1.2,0,0.32],0.35,red,vel=[1.8,0,0.55],friction=0.9,restitution=0.25)]
        summary={"ramp_angle_deg":18,"turning_point":"when kinetic energy converts to gravitational potential"}
    elif experiment == "accelerating_panel_spins_objects":
        objects += [_box("accelerating_panel",[1.2,0.7,0.05],[0,0,0.12],0,grey,vel=[0.7,0,0],friction=0.75)]
        for i in range(5): objects.append(_cylinder(f"puck_{i}",0.10,0.06,[-0.45+0.22*i,0.1*((i%2)*2-1),0.23],0.18,_color(rng),vel=[0.3,0.1*(i-2),0],ang_vel=[0,0,3.0],friction=0.6,restitution=0.4))
        summary={"panel_velocity":0.7,"spin_source":"contact friction and initial angular velocity"}
    elif experiment == "center_vs_offset_seesaw":
        objects += [_box("center_seesaw",[0.9,0.12,0.04],[-0.8,0,0.48],0.5,wood,orn=[0,0,0.12]), _cylinder("center_pivot",0.10,0.25,[-0.8,0,0.28],0,grey,orn=[math.pi/2,0,0]), _sphere("center_left_mass",0.12,[-1.35,0,0.62],0.5,red), _sphere("center_right_mass",0.12,[-0.25,0,0.62],0.5,blue), _box("offset_seesaw",[0.9,0.12,0.04],[0.9,0,0.48],0.5,wood,orn=[0,0,-0.22]), _cylinder("offset_pivot",0.10,0.25,[0.6,0,0.28],0,grey,orn=[math.pi/2,0,0]), _sphere("offset_left_mass",0.12,[0.35,0,0.62],0.5,red), _sphere("offset_right_mass",0.12,[1.45,0,0.62],0.5,blue)]
        summary={"comparison":"same masses, different pivot lever arms"}
    elif experiment == "spring_compress_vs_stretch":
        objects += [_box("compression_cart",[0.2,0.16,0.12],[-1.2,-0.35,0.22],0.45,red,vel=[1.1,0,0],friction=0.2), _box("compression_wall",[0.06,0.25,0.25],[-0.25,-0.35,0.25],0,grey), _visual(_capsule("compressed_spring",0.015,0.65,[-0.65,-0.35,0.28],0,yellow,orn=[0,math.pi/2,0])), _box("stretch_cart",[0.2,0.16,0.12],[-1.2,0.35,0.22],0.45,blue,vel=[-0.4,0,0],friction=0.2), _visual(_capsule("stretched_spring",0.015,1.0,[-0.65,0.35,0.28],0,green,orn=[0,math.pi/2,0]))]
        summary={"spring_law":"F=-kx for compression and stretch"}
    elif experiment == "concave_bowl_spin_orbit":
        objects += [_visual(_cylinder("bowl_visual",0.75,0.12,[0,0,0.12],0,grey)), _sphere("orbit_ball",0.10,[0.45,0,0.45],0.2,red,vel=[0,1.2,0],friction=0.2,restitution=0.4)]
        summary={"bowl_radius_visual":0.75,"orbit":"normal force provides centripetal acceleration"}
    elif experiment == "springboard_rebound_ball":
        objects += [_box("springboard",[0.8,0.18,0.04],[0,0,0.28],0.35,wood,orn=[0,0.12,0],restitution=0.8), _box("support",[0.08,0.24,0.25],[-0.55,0,0.18],0,grey), _sphere("falling_ball",0.14,[0.25,0,1.5],0.4,red,vel=[0,0,-0.5],restitution=0.85)]
        summary={"springboard_restitution":0.85,"energy_storage":"board collision redirects impulse"}
    elif experiment == "vertical_fall_spinning_panel":
        objects += [_box("spinning_panel",[0.42,0.035,0.65],[0,0,1.8],0.55,blue,vel=[0,0,-0.6],ang_vel=[0,3.5,0],friction=0.45,restitution=0.35)]
        summary={"initial_angular_velocity":3.5,"rotational_inertia":"rectangular plate tumbling under gravity"}
    elif experiment == "rod_spin_hits_balloon":
        objects += [_visual(_cylinder("spin_post",0.05,0.8,[0,0,0.5],0,grey)), _box("spinning_rod",[0.75,0.04,0.04],[0,0,0.9],0.3,wood,ang_vel=[0,0,4.0],restitution=0.6), _sphere("balloon",0.17,[0.85,0.05,0.9],0.06,blue,vel=[0,0.3,0],restitution=0.7)]
        summary={"rod_angular_speed":4.0,"tangential_impact_speed":"omega r"}
    elif experiment == "block_wall_hit_by_tethered_mass":
        objects += [_sphere("swinging_mass",0.16,[-0.9,0,0.85],0.8,red,vel=[1.8,0,0],restitution=0.7), _visual(_capsule("tether",0.012,1.0,[-1.1,0,1.25],0,yellow,orn=[0.5,0,0]))]
        for i in range(4):
            for j in range(3): objects.append(_box(f"wall_{i}_{j}",[0.14,0.12,0.10],[0.2+i*0.22,0,0.12+j*0.21],0.3,_color(rng),friction=0.6,restitution=0.3))
        summary={"wall_blocks":12,"pendulum_energy":"mgh plus initial velocity"}
    elif experiment == "offset_load_turntable":
        objects += [_visual(_cylinder("turntable",0.8,0.08,[0,0,0.12],0,grey)), _box("offcenter_load",[0.18,0.14,0.12],[0.45,0,0.25],0.45,red,vel=[0,0.8,0],friction=0.45), _visual(_cylinder("rim",0.82,0.04,[0,0,0.22],0,yellow))]
        summary={"turntable_speed":2.2,"offcenter_radius":0.45}
    elif experiment == "ramp_to_spring_projectile":
        objects += [_box("ramp",[1.1,0.5,0.05],[-0.8,0,0.35],0,grey,orn=[0,-0.35,0],friction=0.8), _sphere("ball",0.12,[-1.45,0,0.75],0.28,red,vel=[1.4,0,-0.1],friction=0.75,restitution=0.45), _box("spring_bumper",[0.08,0.35,0.25],[0.5,0,0.30],0,blue,restitution=0.85), _visual(_capsule("spring_visual",0.018,0.55,[0.15,0,0.32],0,yellow,orn=[0,math.pi/2,0]))]
        summary={"energy_chain":"gravitational potential to kinetic to spring-like rebound"}
    else:
        raise KeyError(experiment)
    return Params(seed=seed, experiment=experiment, objects=objects, camera_eye=cam, camera_target=target, floor_size=floor, summary=summary)


def _entries(params: Params):
    from simulations.kubric_3d._base import param_entry
    data=_base_summary(params)
    return {k:param_entry(v,"various",k) for k,v in data.items()}

_COMMON_EQ=["\\dot{r}=v","m\\dot{v}=mg+F_{contact}","I\\dot{\\omega}=\\tau_{contact}-\\omega\\times I\\omega"]
_COMMON_ASSUMPTIONS=["Rigid bodies","Uniform gravity","Coulomb friction","Visible contact or visible initial velocity only; no hidden forces"]
_COMMON_DERIV=["Use Newton-Euler equations for free motion.","Resolve collision normal velocity with a restitution impulse.","Clamp tangential impulse using Coulomb friction.","PyBullet integrates the rigid-body system at 240 Hz."]
_SPEC={name:("real_life_rigid_body", "Newton-Euler rigid-body mechanics", "m a = F_{net}; I alpha = tau_{net}") for name in EXPERIMENTS}
_SPEC.update({
"spinning_rod_balloon_tether":("rotating_frame", "Centripetal acceleration and tether tension", "T=m omega^2 r"),
"stick_support_catapult_release":("lever_projectile", "Torque and launch energy transfer", "tau=I alpha; E_rot -> E_proj"),
"moving_cart_hits_stationary_cart":("collision", "Momentum conservation with restitution", "m1u1+m2u2=m1v1+m2v2"),
"moving_cart_hits_moving_cart":("collision", "Relative velocity and center-of-mass frame", "v_rel^+ = -e v_rel^-"),
"plasticine_ball_inelastic_drop":("inelastic_collision", "Inelastic collision energy loss", "e approximately 0; Delta E < 0"),
"rolling_ball_up_slope":("rolling_energy", "Rolling energy on an incline", "mgh + 1/2 m v^2 + 1/2 I omega^2 = const"),
"center_vs_offset_seesaw":("torque", "Torque balance and lever arm", "tau = r x mg"),
"spring_compress_vs_stretch":("spring", "Hooke law", "F=-kx; U=1/2 kx^2"),
"springboard_rebound_ball":("impulse", "Elastic impulse and rebound", "J=m(v^+-v^-)"),
})

def cot_for_params(params: Params):
    from simulations.kubric_3d._base import build_cot
    category, law, formula = _SPEC[params.experiment]
    return build_cot(params.experiment, category, params.seed,
        f"{params.experiment}: visible rigid-body scene with shapes {[o['shape'] for o in params.objects]}.",
        law, f"{law}; PyBullet resolves contacts, constraints, and impulses numerically.", formula,
        _COMMON_ASSUMPTIONS, ["position r (m)", "velocity v (m/s)", "orientation q", "angular velocity omega (rad/s)"], _COMMON_EQ,
        "j_n=-(1+e)(v_rel dot n)/m_eff; |j_t|<=mu|j_n|", _COMMON_DERIV,
        ["Motion follows the visible initial conditions and contact geometry.", "Contacts do not interpenetrate under the Bullet solver.", "Energy changes through gravity, restitution, friction, and constraint work."],
        _entries(params))


def make_standalone_code(params: Params) -> str:
    from simulations.kubric_3d._real_life_scenes import make_standalone_code as _make
    return _make(params)


def generate_sample_from_experiment(experiment: str, seed: int, out_dir: str):
    from simulations.kubric_3d._base import Physics, Renderer, run_loop, save_sample
    import pybullet as pb
    params=build_params(experiment, seed)
    phys=Physics(); ren=Renderer(params.camera_eye, params.camera_target); dyn=[]
    phys.add_plane(friction=0.55); ren.add_plane_mesh("floor", params.floor_size, [0.42,0.42,0.45,1.0])
    for obj in params.objects:
        orn=pb.getQuaternionFromEuler(obj.get("orn_euler",[0,0,0])); sh=obj["shape"]
        if obj.get("visual_only"):
            if sh=="sphere": ren.add_sphere(obj["name"], obj["radius"], obj["color"])
            elif sh=="box": ren.add_box(obj["name"], obj["half_ext"], obj["color"])
            elif sh=="cylinder": ren.add_cylinder(obj["name"], obj["radius"], obj["height"], obj["color"])
            elif sh=="capsule": ren.add_capsule(obj["name"], obj["radius"], obj["height"], obj["color"])
            ren.set_static_pose(obj["name"], obj["pos"], orn); continue
        if sh=="sphere": bid=phys.add_sphere(obj["radius"],obj["pos"],mass=obj.get("mass",1),friction=obj.get("friction",.5),restitution=obj.get("restitution",.5),vel=obj.get("vel",[0,0,0]),ang_vel=obj.get("ang_vel",[0,0,0])); ren.add_sphere(obj["name"],obj["radius"],obj["color"])
        elif sh=="box": bid=phys.add_box(obj["half_ext"],obj["pos"],orn=orn,mass=obj.get("mass",1),friction=obj.get("friction",.5),restitution=obj.get("restitution",.5),vel=obj.get("vel",[0,0,0]),ang_vel=obj.get("ang_vel",[0,0,0])); ren.add_box(obj["name"],obj["half_ext"],obj["color"])
        elif sh=="cylinder": bid=phys.add_cylinder(obj["radius"],obj["height"],obj["pos"],orn=orn,mass=obj.get("mass",1),friction=obj.get("friction",.5),restitution=obj.get("restitution",.5),vel=obj.get("vel",[0,0,0]),ang_vel=obj.get("ang_vel",[0,0,0])); ren.add_cylinder(obj["name"],obj["radius"],obj["height"],obj["color"])
        elif sh=="capsule": bid=phys.add_capsule(obj["radius"],obj["height"],obj["pos"],orn=orn,mass=obj.get("mass",1),friction=obj.get("friction",.5),restitution=obj.get("restitution",.5),vel=obj.get("vel",[0,0,0]),ang_vel=obj.get("ang_vel",[0,0,0])); ren.add_capsule(obj["name"],obj["radius"],obj["height"],obj["color"])
        else: continue
        ren.set_static_pose(obj["name"],obj["pos"],orn); dyn.append((obj["name"],bid))
    frames=run_loop(phys,ren,dyn,150)
    data=asdict(params); data.update(_base_summary(params))
    save_sample(out_dir,data,cot_for_params(params),make_standalone_code(params),frames)
    phys.close(); ren.close()
