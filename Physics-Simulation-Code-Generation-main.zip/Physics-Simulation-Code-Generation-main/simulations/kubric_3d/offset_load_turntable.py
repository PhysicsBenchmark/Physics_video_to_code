"""offset_load_turntable — block sits off-center on a motor-driven disc; static
friction provides the centripetal force until ω² r exceeds μ g, then the block
slides outward along a spiral and flies off the rim."""
from __future__ import annotations
import math, random
from dataclasses import asdict

import numpy as np
import pybullet as pb

from ._advanced_life_scenes import _COMMON_ASSUMPTIONS, _COMMON_DERIV, _COMMON_EQ, _SPEC
from ._real_life_scenes import (
    CAM_DEFAULT,
    N_FRAMES,
    Params,
    TARGET_DEFAULT,
    _base_summary,
    _box,
    _cylinder,
    _sphere,
    _visual,
)

EXPERIMENT = "offset_load_turntable"

# Geometry / dynamics
TT_R           = 0.55
TT_H           = 0.06
TT_M           = 8.0
TT_Z           = 0.32                          # turntable centre height
TT_OMEGA_FINAL = 3.6                           # rad/s after spin-up
TT_OMEGA_RAMP  = 1.0                           # rad/s² (ramp of ω)
TT_FRICTION    = 0.30

BLOCK_HALF     = (0.06, 0.06, 0.06)
BLOCK_M        = 0.30
BLOCK_R0       = 0.32                          # initial offset from spin axis
BLOCK_FRICTION = 0.30

POLE_R         = 0.05
POLE_TOP_Z     = TT_Z - TT_H / 2

MARK_HALF      = (0.18, 0.025, 0.005)          # thin radial stripe (visual only)
MARK_OFFSET_X  = 0.18                          # stripe centre relative to disc centre, in disc-local frame

TT_COLOR     = [0.35, 0.55, 0.75, 1.0]
RIM_COLOR    = [0.94, 0.74, 0.18, 1.0]
BLOCK_COLOR  = [0.85, 0.18, 0.14, 1.0]
MARK_COLOR   = [0.20, 0.72, 0.34, 1.0]
DARK         = [0.30, 0.30, 0.34, 1.0]


def random_params(seed: int) -> Params:
    rng = random.Random(seed + abs(hash(EXPERIMENT)) % 100000)
    block_pos = [BLOCK_R0, 0.0, TT_Z + TT_H / 2 + BLOCK_HALF[2] + 0.001]
    mark_pos  = [MARK_OFFSET_X, 0.0,
                 TT_Z + TT_H / 2 + MARK_HALF[2] + 0.001]
    objects = [
        # Visible support pole (visual).
        _visual(_cylinder("pole", POLE_R, POLE_TOP_Z,
                          [0.0, 0.0, POLE_TOP_Z / 2], 0, DARK)),
        # Turntable (real, motor-driven disc).
        _cylinder("turntable", TT_R, TT_H, [0.0, 0.0, TT_Z],
                  TT_M, TT_COLOR,
                  friction=TT_FRICTION, restitution=0.05),
        # Visual radial stripe — drawn each frame at the turntable's current
        # orientation so rotation is unmistakable. Stays inside the block's
        # initial radius so it never collides with the block.
        _visual(_box("spin_stripe", list(MARK_HALF), mark_pos, 0, MARK_COLOR)),
        # Block (free body — what the experiment is about).
        _box("block", list(BLOCK_HALF), block_pos, BLOCK_M, BLOCK_COLOR,
             friction=BLOCK_FRICTION, restitution=0.25),
    ]
    summary = {
        "turntable_radius_m":         TT_R,
        "turntable_omega_target_rad_s": TT_OMEGA_FINAL,
        "turntable_omega_ramp_rad_s2":  TT_OMEGA_RAMP,
        "block_initial_radius_m":     BLOCK_R0,
        "block_mass_kg":              BLOCK_M,
        "friction_coefficient":       BLOCK_FRICTION,
        "critical_radius_at_final_omega_m":
            (BLOCK_FRICTION * 9.81) / (TT_OMEGA_FINAL ** 2),
        "phenomena_demonstrated": [
            "Centripetal acceleration: a_c = ω² r",
            "Static friction limit: |f_s| ≤ μ_s m g",
            "Slip condition: m ω² r > μ_s m g → block slides outward",
            "Inertia in a non-inertial frame: block leaves the rim along its instantaneous tangent",
            "Free flight under gravity after the block clears the disc",
        ],
    }
    return Params(seed=seed, experiment=EXPERIMENT, objects=objects,
                  camera_eye=CAM_DEFAULT, camera_target=TARGET_DEFAULT,
                  floor_size=7.0, summary=summary)


def _cot(params: Params):
    from simulations.kubric_3d._base import build_cot, param_entry
    category, law, formula = _SPEC[EXPERIMENT]
    entries = {k: param_entry(v, "various", k)
               for k, v in _base_summary(params).items()}
    return build_cot(
        EXPERIMENT, category, params.seed,
        f"{EXPERIMENT}: a heavy disc is spun up about its vertical axis at a "
        "controlled angular velocity. A block sits off-centre on the disc; "
        "static friction provides the centripetal acceleration until ω² r "
        "exceeds μ g, after which the block slides outward and is flung off.",
        law,
        f"{law}; PyBullet drives the turntable with a per-substep angular "
        "velocity reset and resolves the block-disc Coulomb friction contact.",
        formula, _COMMON_ASSUMPTIONS,
        ["block r,v,q,ω", "turntable ω(t)", "centripetal accel a_c=ω²r",
         "friction limit μmg"],
        _COMMON_EQ + ["a_c = \\omega^2 r",
                      "|f_s| \\le \\mu_s m g",
                      "r_{crit} = \\mu g / \\omega^2"],
        "j_n=-(1+e)(v_rel·n)/m_eff; |j_t|<=mu|j_n|",
        _COMMON_DERIV + [
            "Spin-up phase: turntable angular velocity ramps linearly to ω_f.",
            "Block at radius r needs centripetal force m·ω²·r, supplied by static friction.",
            "When ω² r > μ_s g, friction can no longer hold the block; it slips outward.",
            "Once slipping, kinetic friction acts opposite to the block's velocity relative to the disc surface.",
            "Block radius grows; centripetal demand grows further; runaway slip until the block leaves the rim.",
        ],
        ["Block initially comoves with the disc on a circular arc.",
         "Block then spirals outward across the disc surface.",
         "Block falls off the rim and undergoes parabolic free flight.",
         "Block lands on the floor, slides/rolls, then rests; turntable continues rotating at ω_f.",
        ],
        entries)


def _omega_at(t):
    """Linearly ramp ω from 0 up to TT_OMEGA_FINAL."""
    return min(TT_OMEGA_RAMP * t, TT_OMEGA_FINAL)


def make_standalone_code(params: Params) -> str:
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f'''
# {EXPERIMENT}  seed={params.seed}
N_FRAMES={N_FRAMES}; CAM_EYE={repr(params.camera_eye)}; CAM_TARGET={repr(params.camera_target)}
TT_R={TT_R}; TT_H={TT_H}; TT_M={TT_M}; TT_Z={TT_Z}
TT_OMEGA_FINAL={TT_OMEGA_FINAL}; TT_OMEGA_RAMP={TT_OMEGA_RAMP}; TT_FRICTION={TT_FRICTION}
BLOCK_HALF={list(BLOCK_HALF)}; BLOCK_M={BLOCK_M}; BLOCK_R0={BLOCK_R0}; BLOCK_FRICTION={BLOCK_FRICTION}
POLE_R={POLE_R}; POLE_TOP_Z={POLE_TOP_Z}
MARK_HALF={list(MARK_HALF)}; MARK_OFFSET_X={MARK_OFFSET_X}
TT_COLOR={TT_COLOR}; BLOCK_COLOR={BLOCK_COLOR}; MARK_COLOR={MARK_COLOR}; DARK={DARK}
FLOOR=7.0
SUBSTEPS=STEP_RATE//FPS

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    p.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"floor",nodes,[FLOOR/2,FLOOR/2,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["floor"],[0,0,-0.02],[0,0,0,1])
    _add_cylinder(sc,"pole",nodes,POLE_R,POLE_TOP_Z,DARK)
    _set_pose(sc,nodes["pole"],[0,0,POLE_TOP_Z/2],[0,0,0,1])
    st=p.createCollisionShape(p.GEOM_CYLINDER,radius=TT_R,height=TT_H,physicsClientId=c)
    tt=p.createMultiBody(TT_M,st,-1,[0,0,TT_Z],[0,0,0,1],physicsClientId=c)
    p.changeDynamics(tt,-1,lateralFriction=TT_FRICTION,restitution=0.05,
        linearDamping=0.0,angularDamping=0.0,physicsClientId=c)
    sb=p.createCollisionShape(p.GEOM_BOX,halfExtents=BLOCK_HALF,physicsClientId=c)
    block=p.createMultiBody(BLOCK_M,sb,-1,[BLOCK_R0,0,TT_Z+TT_H/2+BLOCK_HALF[2]+0.001],[0,0,0,1],physicsClientId=c)
    p.changeDynamics(block,-1,lateralFriction=BLOCK_FRICTION,restitution=0.25,
        linearDamping=0.0,angularDamping=0.05,physicsClientId=c)
    cid_tt=p.createConstraint(tt,-1,-1,-1,p.JOINT_POINT2POINT,[0,0,1],
        [0,0,0],[0,0,TT_Z],physicsClientId=c)
    p.changeConstraint(cid_tt,maxForce=200000,physicsClientId=c)
    _add_cylinder(sc,"turntable",nodes,TT_R,TT_H,TT_COLOR)
    _add_box(sc,"spin_stripe",nodes,MARK_HALF,MARK_COLOR)
    _add_box(sc,"block",nodes,BLOCK_HALF,BLOCK_COLOR)
    bodies=[("turntable",tt),("block",block)]
    frames=[]
    for fi in range(N_FRAMES):
        for ss in range(SUBSTEPS):
            t=(fi*SUBSTEPS+ss)/STEP_RATE
            omega=min(TT_OMEGA_RAMP*t, TT_OMEGA_FINAL)
            p.resetBaseVelocity(tt,[0,0,0],[0,0,omega],physicsClientId=c)
            p.stepSimulation(physicsClientId=c)
        for nm,bid in bodies:
            pp,oo=p.getBasePositionAndOrientation(bid,physicsClientId=c); _set_pose(sc,nodes[nm],pp,oo)
        tp,tq=p.getBasePositionAndOrientation(tt,physicsClientId=c)
        Rt=np.array(p.getMatrixFromQuaternion(tq)).reshape(3,3)
        stripe=(np.array(tp)+Rt@np.array([MARK_OFFSET_X,0,TT_H/2+MARK_HALF[2]+0.001])).tolist()
        _set_pose(sc,nodes["spin_stripe"],stripe,tq)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); p.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
'''


def generate_sample(seed: int, out_dir: str):
    from simulations.kubric_3d._base import (
        Physics, Renderer, save_sample, STEP_RATE, FPS, metadata_only,
    )
    params = random_params(seed)

    phys = Physics()
    ren = Renderer(params.camera_eye, params.camera_target)
    phys.add_plane(friction=0.6)
    ren.add_plane_mesh("floor", params.floor_size, [0.42, 0.42, 0.45, 1.0])

    ren.add_cylinder("pole", POLE_R, POLE_TOP_Z, DARK)
    ren.set_static_pose("pole", [0, 0, POLE_TOP_Z / 2], (0, 0, 0, 1))

    tt_id = phys.add_cylinder(TT_R, TT_H, [0, 0, TT_Z], mass=TT_M,
                              friction=TT_FRICTION, restitution=0.05)
    pb.changeDynamics(tt_id, -1, linearDamping=0.0, angularDamping=0.0,
                      physicsClientId=phys.client)

    block_pos = [BLOCK_R0, 0, TT_Z + TT_H / 2 + BLOCK_HALF[2] + 0.001]
    block_id = phys.add_box(list(BLOCK_HALF), block_pos, mass=BLOCK_M,
                            friction=BLOCK_FRICTION, restitution=0.25,
                            lin_damp=0.0, ang_damp=0.05)

    ren.add_cylinder("turntable", TT_R, TT_H, TT_COLOR)
    ren.add_box("spin_stripe", list(MARK_HALF), MARK_COLOR)
    ren.add_box("block", list(BLOCK_HALF), BLOCK_COLOR)

    # Pin turntable centre to (0,0,TT_Z); only its angular velocity moves it.
    phys.create_constraint(
        tt_id, -1, -1, -1,
        pb.JOINT_POINT2POINT, [0, 0, 1],
        [0, 0, 0], [0, 0, TT_Z],
        max_force=200000.0)

    bodies = [("turntable", tt_id), ("block", block_id)]

    if metadata_only():
        save_sample(out_dir, asdict(params), _cot(params),
                    make_standalone_code(params), [])
        phys.close(); ren.close()
        return

    substeps = STEP_RATE // FPS
    frames = []
    for fi in range(N_FRAMES):
        for ss in range(substeps):
            t = (fi * substeps + ss) / STEP_RATE
            omega = _omega_at(t)
            # Force the turntable's angular velocity (motor); pin enforces
            # zero linear motion for us via the JOINT_POINT2POINT constraint.
            pb.resetBaseVelocity(tt_id, [0, 0, 0], [0, 0, omega],
                                 physicsClientId=phys.client)
            phys.step()
        for name, bid in bodies:
            pos, orn = phys.get_pose(bid)
            ren.set_pose(name, pos, orn)
        # Visual stripe follows the turntable's rotation.
        tp, tq = phys.get_pose(tt_id)
        Rt = np.array(pb.getMatrixFromQuaternion(tq.tolist())).reshape(3, 3)
        stripe_world = (np.array(tp) +
                        Rt @ np.array([MARK_OFFSET_X, 0,
                                       TT_H / 2 + MARK_HALF[2] + 0.001])).tolist()
        ren.set_pose("spin_stripe", stripe_world, tq)
        frames.append(ren.render_frame())

    save_sample(out_dir, asdict(params), _cot(params),
                make_standalone_code(params), frames)
    phys.close(); ren.close()


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_offset_load_turntable")
    print("OK")
