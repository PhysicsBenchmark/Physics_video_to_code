"""wedge_collision — moving box slides along floor and collides with a static wedge."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (5.0, -3.0, 3.0)
CAM_TARGET = (0.0,  0.0, 0.5)
N_FRAMES   = 120  # 4 s @ 30 fps


@dataclass
class Params:
    seed:           int
    box_speed:      float   # initial speed of sliding box in +X (m/s)
    box_mass:       float   # kg
    box_half:       float   # half-extent of sliding box (m), cube
    wedge_angle_deg: float  # wedge face angle from vertical (degrees)
    restitution:    float
    friction:       float
    box_color:      List[float]
    wedge_color:    List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        box_speed=random.uniform(2.0, 6.0),
        box_mass=random.uniform(0.5, 3.0),
        box_half=random.uniform(0.10, 0.25),
        wedge_angle_deg=random.uniform(30.0, 60.0),
        restitution=random.uniform(0.2, 0.7),
        friction=random.uniform(0.2, 0.6),
        box_color=[random.uniform(0.4, 0.9), random.uniform(0.3, 0.8),
                   random.uniform(0.2, 0.7), 1.0],
        wedge_color=[0.60, 0.52, 0.42, 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.friction, restitution=p.restitution)
    ren.add_plane_mesh("floor", 12.0, [0.37, 0.37, 0.40, 1.0])
    ren.set_static_pose("floor", [0, 0, 0])

    # Wedge: modelled as a static tilted box (half-extent in X tilted by wedge_angle)
    # The wedge sits at the origin, its front face tilted toward incoming box
    angle = math.radians(p.wedge_angle_deg)
    wedge_hl = 0.4   # half-length
    wedge_hw = 0.5   # half-width (Y)
    wedge_ht = 0.4   # half-height
    # Rotate wedge around Y axis by wedge_angle so front face is inclined
    wedge_orn = [0.0, math.sin(angle / 2), 0.0, math.cos(angle / 2)]
    wedge_pos = [1.5, 0.0, wedge_ht]

    phys.add_box([wedge_hl, wedge_hw, wedge_ht], wedge_pos,
                 orn=wedge_orn, mass=0.0, friction=p.friction,
                 restitution=p.restitution)
    ren.add_box("wedge", [wedge_hl, wedge_hw, wedge_ht], p.wedge_color)
    ren.set_static_pose("wedge", wedge_pos, wedge_orn)

    # Second static wedge block mirrored to form a V-shape
    wedge_orn2 = [0.0, -math.sin(angle / 2), 0.0, math.cos(angle / 2)]
    wedge_pos2 = [2.2, 0.0, wedge_ht]
    phys.add_box([wedge_hl, wedge_hw, wedge_ht], wedge_pos2,
                 orn=wedge_orn2, mass=0.0, friction=p.friction,
                 restitution=p.restitution)
    ren.add_box("wedge2", [wedge_hl, wedge_hw, wedge_ht], p.wedge_color)
    ren.set_static_pose("wedge2", wedge_pos2, wedge_orn2)

    # Sliding box: starts at -X, shot in +X direction
    bx = p.box_half
    bid = phys.add_box([bx, bx, bx],
                       [-2.5, 0.0, bx],
                       mass=p.box_mass, friction=p.friction,
                       restitution=p.restitution,
                       vel=[p.box_speed, 0.0, 0.0])
    ren.add_box("box", [bx, bx, bx], p.box_color)
    dyn = [("box", bid)]

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="wedge_collision",
        category="rigid_body_constrained",
        seed=seed,
        physical_observation=(
            f"Box (half={p.box_half:.2f} m, m={p.box_mass:.2f} kg) "
            f"slides at {p.box_speed:.1f} m/s and strikes a static wedge "
            f"(angle={p.wedge_angle_deg:.1f}°) with e={p.restitution:.2f}."),
        law_name="Newton-Euler dynamics + oblique contact impulse",
        law_statement=(
            "Contact impulse at wedge surface has normal component (restitution) "
            "and tangential component (friction), deflecting the box."),
        law_formula="j = -(1+e)*v_n / (1/m + n^T*I^-1*(r×n)×r)",
        assumptions=[
            "Wedge is perfectly rigid and fixed to the ground.",
            "Box is a rigid body; edge/face contact treated as point contact.",
            "Coulomb friction at all contact surfaces.",
        ],
        state_variables=["position r (m)", "velocity v (m/s)",
                         "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg+F_c",
            "I\\dot{\\omega}=\\tau_c-\\omega\\times I\\omega",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B + cross_terms)",
        derivation_steps=[
            f"Box moves at v={p.box_speed:.1f} m/s in +X.",
            f"Wedge inclined at {p.wedge_angle_deg:.1f}° from vertical.",
            "Normal to wedge face: n=(cos θ, 0, -sin θ) approximately.",
            "Contact impulse deflects box upward and possibly laterally.",
            "Friction decelerates box on floor before and after collision.",
        ],
        expected_behavior=[
            "Box slides along floor and strikes wedge face.",
            "Box deflects upward/sideways based on wedge angle.",
            f"Energy retained: ~{p.restitution**2 * 100:.0f}% (e²={p.restitution**2:.2f}).",
        ],
        parameters={
            "box_speed_mps":    param_entry(p.box_speed,       "m/s", "Box initial speed"),
            "box_mass_kg":      param_entry(p.box_mass,        "kg",  "Box mass"),
            "box_half_m":       param_entry(p.box_half,        "m",   "Box half-extent"),
            "wedge_angle_deg":  param_entry(p.wedge_angle_deg, "deg", "Wedge face angle"),
            "restitution":      param_entry(p.restitution,     "",    "Coefficient of restitution"),
            "friction":         param_entry(p.friction,        "",    "Friction coefficient"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    angle = math.radians(p.wedge_angle_deg)
    wedge_hl, wedge_hw, wedge_ht = 0.4, 0.5, 0.4
    wedge_orn  = [0.0,  math.sin(angle / 2), 0.0, math.cos(angle / 2)]
    wedge_pos  = [1.5, 0.0, wedge_ht]
    wedge_orn2 = [0.0, -math.sin(angle / 2), 0.0, math.cos(angle / 2)]
    wedge_pos2 = [2.2, 0.0, wedge_ht]
    bx = p.box_half
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# wedge_collision  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[6.0,6.0,0.02],[0.37,0.37,0.40,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    ws=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[{wedge_hl},{wedge_hw},{wedge_ht}],physicsClientId=c)
    pb.createMultiBody(0,ws,-1,{list(wedge_pos)},{list(wedge_orn)},physicsClientId=c)
    _add_box(sc,"wedge",nodes,[{wedge_hl},{wedge_hw},{wedge_ht}],{p.wedge_color})
    _set_pose(sc,nodes["wedge"],{list(wedge_pos)},{list(wedge_orn)})
    ws2=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[{wedge_hl},{wedge_hw},{wedge_ht}],physicsClientId=c)
    pb.createMultiBody(0,ws2,-1,{list(wedge_pos2)},{list(wedge_orn2)},physicsClientId=c)
    _add_box(sc,"wedge2",nodes,[{wedge_hl},{wedge_hw},{wedge_ht}],{p.wedge_color})
    _set_pose(sc,nodes["wedge2"],{list(wedge_pos2)},{list(wedge_orn2)})
    bx={bx}
    bs=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[bx,bx,bx],physicsClientId=c)
    bid=pb.createMultiBody({p.box_mass},bs,-1,[-2.5,0.0,bx],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(bid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
    pb.resetBaseVelocity(bid,[{p.box_speed},0.0,0.0],[0,0,0],physicsClientId=c)
    _add_box(sc,"box",nodes,[bx,bx,bx],{p.box_color})
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
        _set_pose(sc,nodes["box"],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_wedge_collision")
    print("OK")
