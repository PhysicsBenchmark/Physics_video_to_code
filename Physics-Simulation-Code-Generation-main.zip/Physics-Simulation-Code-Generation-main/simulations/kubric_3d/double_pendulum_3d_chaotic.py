"""double_pendulum_3d_chaotic — double pendulum showing chaotic motion."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (4, -3, 4)
CAM_TARGET = (0, 0, 1)
N_FRAMES   = 180


@dataclass
class Params:
    seed: int
    L1: float
    L2: float
    m1: float
    m2: float
    r1: float
    r2: float
    angle1_deg: float
    angle2_deg: float
    pivot_height: float
    color1: List[float]
    color2: List[float]


def _rand_color():
    h = random.random()
    s, v = 0.85, 0.90
    hi = int(h * 6) % 6
    f  = h * 6 - int(h * 6)
    p_ = v * (1 - s); q = v * (1 - f*s); t = v * (1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return [r, g, b, 1.0]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    L1 = random.uniform(0.8, 1.5)
    L2 = random.uniform(0.6, 1.2)
    return Params(
        seed=seed,
        L1=L1, L2=L2,
        m1=random.uniform(0.3, 1.5),
        m2=random.uniform(0.3, 1.5),
        r1=random.uniform(0.05, 0.10),
        r2=random.uniform(0.04, 0.09),
        angle1_deg=random.uniform(30.0, 90.0),
        angle2_deg=random.uniform(30.0, 150.0),
        pivot_height=L1 + L2 + 0.5,
        color1=_rand_color(),
        color2=_rand_color(),
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=0.5)
    ren.add_plane_mesh("floor", 8.0, [0.42, 0.42, 0.45, 1.0])

    pivot = [0.0, 0.0, p.pivot_height]

    # Sphere 1: hangs from fixed pivot by L1
    theta1 = math.radians(p.angle1_deg)
    x1 = p.L1 * math.sin(theta1)
    z1 = p.pivot_height - p.L1 * math.cos(theta1)
    pos1 = [x1, 0.0, z1]

    sphere1_id = phys.add_sphere(
        radius=p.r1, pos=pos1, mass=p.m1,
        friction=0.1, restitution=0.4)

    # Sphere 2: hangs from sphere1 by L2
    theta2 = math.radians(p.angle2_deg)
    x2 = x1 + p.L2 * math.sin(theta2)
    z2 = z1 - p.L2 * math.cos(theta2)
    pos2 = [x2, 0.0, z2]

    sphere2_id = phys.add_sphere(
        radius=p.r2, pos=pos2, mass=p.m2,
        friction=0.1, restitution=0.4)

    # Fixed anchor at world pivot (mass=0 → already static; no extra JOINT_FIXED needed)
    anchor_id = phys.add_sphere(radius=0.03, pos=pivot, mass=0.0,
                                friction=0.0, restitution=0.0)

    # Constraint: anchor -> sphere1 (rod of length L1)
    # child_pos = vector from sphere1 center to pivot1 in sphere1's local frame
    pivot1_in_ball1 = [pivot[0]-pos1[0], pivot[1]-pos1[1], pivot[2]-pos1[2]]
    phys.create_constraint(
        anchor_id, -1, sphere1_id, -1,
        pb_mod.JOINT_POINT2POINT, [0, 0, 0],
        [0.0, 0.0, 0.0], pivot1_in_ball1,
        max_force=5000.0)

    # Constraint: sphere1 -> sphere2 (rod of length L2)
    # child_pos = vector from sphere2 center to sphere1 center in sphere2's local frame
    ball1_in_ball2 = [pos1[0]-pos2[0], pos1[1]-pos2[1], pos1[2]-pos2[2]]
    phys.create_constraint(
        sphere1_id, -1, sphere2_id, -1,
        pb_mod.JOINT_POINT2POINT, [0, 0, 0],
        [0.0, 0.0, 0.0], ball1_in_ball2,
        max_force=5000.0)

    ren.add_sphere("s1", p.r1, p.color1)
    ren.add_sphere("s2", p.r2, p.color2)
    ren.set_static_pose("s1", pos1)
    ren.set_static_pose("s2", pos2)

    _pivot = pivot  # capture for closure
    _s1_id = sphere1_id
    _s2_id = sphere2_id
    ren.add_sphere("pivot", 0.04, [0.85, 0.85, 0.85, 1.0])
    ren.set_static_pose("pivot", pivot)

    str_radius = 0.012
    str_color = [0.25, 0.18, 0.10, 1.0]

    def extra_sync_fn(phys, ren, fi):
        p1_pos, _ = phys.get_pose(_s1_id)
        p2_pos, _ = phys.get_pose(_s2_id)
        ren.update_string("str1", _pivot, p1_pos.tolist(), str_radius, str_color)
        ren.update_string("str2", p1_pos.tolist(), p2_pos.tolist(), str_radius, str_color)

    dyn = [("s1", sphere1_id), ("s2", sphere2_id)]
    frames = run_loop(phys, ren, dyn, N_FRAMES, extra_sync_fn=extra_sync_fn)

    cot = build_cot(
        simulation="double_pendulum_3d_chaotic",
        category="articulated_jointed",
        seed=seed,
        physical_observation=(
            f"Double pendulum: L1={p.L1:.2f}m, L2={p.L2:.2f}m, "
            f"m1={p.m1:.2f}kg, m2={p.m2:.2f}kg, "
            f"θ1={p.angle1_deg:.1f}°, θ2={p.angle2_deg:.1f}°. Exhibits chaotic motion."
        ),
        law_name="Lagrangian mechanics of double pendulum (chaotic system)",
        law_statement=(
            "The double pendulum is a canonical chaotic system; tiny changes in "
            "initial conditions lead to exponentially diverging trajectories."
        ),
        law_formula=(
            "L = (1/2)(m1+m2)L1²θ̇1² + (1/2)m2L2²θ̇2² "
            "+ m2L1L2θ̇1θ̇2cos(θ1-θ2) - (m1+m2)gL1cosθ1 - m2gL2cosθ2"
        ),
        assumptions=[
            "Point masses at ends of massless rods",
            "JOINT_POINT2POINT constraints maintain rod lengths",
            "No damping in analytical model (small numerical damping in simulator)",
            "3D extension: pendulum free to move in full 3D space",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg+T_1\\hat{r}_1+T_2\\hat{r}_2+F_c",
            "\\text{Lyapunov exponent}>0\\Rightarrow\\text{chaos}",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            "Four coupled ODEs in θ1, θ2, θ̇1, θ̇2",
            "Coupling term m2·L1·L2·θ̇1·θ̇2·cos(θ1-θ2) drives non-linearity",
            "Positive Lyapunov exponent confirms chaos for large initial angles",
            f"Energy E = {p.m1*9.81*p.L1*(1-math.cos(math.radians(p.angle1_deg))) + p.m2*9.81*(p.L1*(1-math.cos(math.radians(p.angle1_deg)))+p.L2*(1-math.cos(math.radians(p.angle2_deg)))):.3f} J initially",
        ],
        expected_behavior=[
            "First bob swings in arc",
            "Second bob exhibits irregular whipping motion",
            "System appears to rotate fully at high energies",
            "Highly sensitive to initial conditions",
        ],
        parameters={
            "L1": param_entry(p.L1, "m",  "length of first rod"),
            "L2": param_entry(p.L2, "m",  "length of second rod"),
            "m1": param_entry(p.m1, "kg", "mass of first bob"),
            "m2": param_entry(p.m2, "kg", "mass of second bob"),
            "angle1_deg": param_entry(p.angle1_deg, "°", "initial angle of first rod from vertical"),
            "angle2_deg": param_entry(p.angle2_deg, "°", "initial angle of second rod from vertical"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    theta1 = math.radians(p.angle1_deg)
    theta2 = math.radians(p.angle2_deg)
    x1 = p.L1 * math.sin(theta1)
    z1 = p.pivot_height - p.L1 * math.cos(theta1)
    x2 = x1 + p.L2 * math.sin(theta2)
    z2 = z1 - p.L2 * math.cos(theta2)
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# double_pendulum_3d_chaotic  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[4.0,4.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    # fixed anchor
    sa=pb.createCollisionShape(pb.GEOM_SPHERE,radius=0.03,physicsClientId=c)
    anc=pb.createMultiBody(0,sa,-1,[0,0,{p.pivot_height}],[0,0,0,1],physicsClientId=c)
    pb.createConstraint(anc,-1,-1,-1,pb.JOINT_FIXED,[0,0,0],[0,0,0],[0,0,{p.pivot_height}],physicsClientId=c)
    # sphere 1
    s1s=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.r1},physicsClientId=c)
    s1=pb.createMultiBody({p.m1},s1s,-1,[{x1:.4f},0,{z1:.4f}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(s1,-1,lateralFriction=0.1,restitution=0.4,physicsClientId=c)
    cid1=pb.createConstraint(anc,-1,s1,-1,pb.JOINT_POINT2POINT,[0,0,0],
        [0,0,0],[{-x1:.4f},0,{p.pivot_height-z1:.4f}],physicsClientId=c)
    pb.changeConstraint(cid1,maxForce=2000,physicsClientId=c)
    # sphere 2
    s2s=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.r2},physicsClientId=c)
    s2=pb.createMultiBody({p.m2},s2s,-1,[{x2:.4f},0,{z2:.4f}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(s2,-1,lateralFriction=0.1,restitution=0.4,physicsClientId=c)
    cid2=pb.createConstraint(s1,-1,s2,-1,pb.JOINT_POINT2POINT,[0,0,0],
        [0,0,0],[{x1-x2:.4f},0,{z1-z2:.4f}],physicsClientId=c)
    pb.changeConstraint(cid2,maxForce=2000,physicsClientId=c)
    _add_sphere(sc,"s1",nodes,{p.r1},{p.color1})
    _add_sphere(sc,"s2",nodes,{p.r2},{p.color2})
    bids=[("s1",s1),("s2",s2)]; frames=[]; pivot_pos=[0,0,{p.pivot_height}]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn)
        p1p,_=pb.getBasePositionAndOrientation(s1,physicsClientId=c)
        p2p,_=pb.getBasePositionAndOrientation(s2,physicsClientId=c)
        _update_string(sc,nodes,"str1",pivot_pos,list(p1p),0.006,[0.25,0.18,0.10,1.0])
        _update_string(sc,nodes,"str2",list(p1p),list(p2p),0.006,[0.25,0.18,0.10,1.0])
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_double_pendulum_3d_chaotic")
    print("OK")
