"""ramp_slide_friction — box or sphere slides down an inclined ramp under friction."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (6.0, -4.0, 3.0)
CAM_TARGET = (0.0,  0.0, 0.5)
N_FRAMES   = 120  # 4 s @ 30 fps
FLOOR_VISUAL_SIZE = 200.0


@dataclass
class Params:
    seed:            int
    ramp_angle_deg:  float   # inclination angle (degrees)
    ramp_length:     float   # half-length of ramp (m)
    slide_mass:      float   # kg
    friction:        float   # sliding friction coefficient
    restitution:     float
    obj_type:        str     # "box" or "sphere"
    obj_color:       List[float]
    ramp_color:      List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        ramp_angle_deg=random.uniform(20.0, 45.0),
        ramp_length=random.uniform(1.0, 2.0),
        slide_mass=random.uniform(0.3, 2.0),
        friction=random.uniform(0.05, 0.55),
        restitution=random.uniform(0.2, 0.6),
        obj_type=random.choice(["box", "sphere"]),
        obj_color=[random.uniform(0.5, 1.0), random.uniform(0.3, 0.8),
                   random.uniform(0.2, 0.7), 1.0],
        ramp_color=[0.55, 0.45, 0.35, 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.friction)
    ren.add_plane_mesh("floor", FLOOR_VISUAL_SIZE, [0.38, 0.38, 0.40, 1.0])
    ren.set_static_pose("floor", [0, 0, -0.02])

    # Ramp: static tilted box
    angle = math.radians(p.ramp_angle_deg)
    ramp_hl = p.ramp_length   # half-length along slope
    ramp_hw = 0.5              # half-width
    ramp_ht = 0.05             # thin slab

    # Quaternion for rotation around -Y axis by angle (ramp slopes up in XZ plane)
    ramp_orn = [0.0, -math.sin(angle / 2), 0.0, math.cos(angle / 2)]
    # Position ramp centre so its bottom edge sits near x=0, z≈0
    ramp_cx = ramp_hl * math.cos(angle)
    ramp_cz = ramp_hl * math.sin(angle)
    ramp_pos = [ramp_cx, 0.0, ramp_cz]

    phys.add_box([ramp_hl, ramp_hw, ramp_ht], ramp_pos,
                 orn=ramp_orn, mass=0.0, friction=p.friction,
                 restitution=p.restitution)
    ren.add_box("ramp", [ramp_hl, ramp_hw, ramp_ht], p.ramp_color)
    ren.set_static_pose("ramp", ramp_pos, ramp_orn)

    # Sliding object placed near the top of the ramp
    # Normal to ramp top face (for -Y rotation): [-sin(angle), 0, cos(angle)]
    obj_r = 0.10  # radius / half-size
    top_x = 2 * ramp_hl * math.cos(angle) - (obj_r + ramp_ht) * math.sin(angle)
    top_z = 2 * ramp_hl * math.sin(angle) + (obj_r + ramp_ht) * math.cos(angle)

    dyn = []
    if p.obj_type == "sphere":
        bid = phys.add_sphere(obj_r, [top_x, 0.0, top_z],
                              mass=p.slide_mass, friction=p.friction,
                              restitution=p.restitution)
        ren.add_sphere("obj", obj_r, p.obj_color)
    else:
        bid = phys.add_box([obj_r] * 3, [top_x, 0.0, top_z],
                           mass=p.slide_mass, friction=p.friction,
                           restitution=p.restitution)
        ren.add_box("obj", [obj_r] * 3, p.obj_color)
    dyn.append(("obj", bid))

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    a = math.radians(p.ramp_angle_deg)
    acc_theory = 9.81 * (math.sin(a) - p.friction * math.cos(a))
    cot = build_cot(
        simulation="ramp_slide_friction",
        category="rigid_body_constrained",
        seed=seed,
        physical_observation=(
            f"A {p.obj_type} (m={p.slide_mass:.2f} kg) slides down a ramp "
            f"inclined at {p.ramp_angle_deg:.1f}° "
            f"with friction μ={p.friction:.2f}. "
            f"Theoretical acceleration ≈ {acc_theory:.2f} m/s²."),
        law_name="Newton's 2nd law on inclined plane with Coulomb friction",
        law_statement=(
            "Net force along slope = mg·sin(θ) - μ·mg·cos(θ); "
            "object accelerates if sin(θ) > μ·cos(θ)."),
        law_formula="a = g*(sin(θ) - μ*cos(θ))",
        assumptions=[
            "Ramp is rigid and static.",
            "Coulomb friction model: f_k = μ·N.",
            "Object modelled as rigid body (box or sphere).",
        ],
        state_variables=["position r (m)", "velocity v (m/s)",
                         "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg+N+f",
            "I\\dot{\\omega}=\\tau_c-\\omega\\times I\\omega",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            f"Ramp inclined at θ={p.ramp_angle_deg:.1f}°.",
            f"Normal force N = m·g·cos(θ) = {p.slide_mass*9.81*math.cos(a):.2f} N.",
            f"Friction force f_k = μ·N = {p.friction*p.slide_mass*9.81*math.cos(a):.2f} N.",
            f"Net along-slope force = {p.slide_mass*9.81*math.sin(a):.2f} - {p.friction*p.slide_mass*9.81*math.cos(a):.2f} N.",
            f"Expected acceleration ≈ {acc_theory:.2f} m/s².",
        ],
        expected_behavior=[
            f"Object slides {'down' if acc_theory > 0 else 'stays on'} ramp.",
            f"Reaches floor after sliding ~{p.ramp_length*2:.1f} m along slope.",
            "May bounce/tumble after leaving ramp and hitting floor.",
        ],
        parameters={
            "ramp_angle_deg": param_entry(p.ramp_angle_deg, "deg", "Ramp inclination"),
            "ramp_length_m":  param_entry(p.ramp_length,    "m",   "Ramp half-length"),
            "slide_mass_kg":  param_entry(p.slide_mass,     "kg",  "Sliding object mass"),
            "friction":       param_entry(p.friction,       "",    "Friction coefficient"),
            "restitution":    param_entry(p.restitution,    "",    "Coefficient of restitution"),
            "obj_type":       param_entry(p.obj_type,       "",    "Object shape: box or sphere"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    angle = math.radians(p.ramp_angle_deg)
    ramp_hl = p.ramp_length
    ramp_hw = 0.5
    ramp_ht = 0.05
    ramp_orn = [0.0, -math.sin(angle / 2), 0.0, math.cos(angle / 2)]
    ramp_cx = ramp_hl * math.cos(angle)
    ramp_cz = ramp_hl * math.sin(angle)
    ramp_pos = [ramp_cx, 0.0, ramp_cz]
    obj_r = 0.10
    top_x = 2 * ramp_hl * math.cos(angle) - (obj_r + ramp_ht) * math.sin(angle)
    top_z = 2 * ramp_hl * math.sin(angle) + (obj_r + ramp_ht) * math.cos(angle)
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# ramp_slide_friction  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[{FLOOR_VISUAL_SIZE/2:.1f},{FLOOR_VISUAL_SIZE/2:.1f},0.02],[0.38,0.38,0.40,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    ramp_pos={list(ramp_pos)}; ramp_orn={list(ramp_orn)}
    rs=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[{ramp_hl},{ramp_hw},{ramp_ht}],physicsClientId=c)
    pb.createMultiBody(0,rs,-1,ramp_pos,ramp_orn,physicsClientId=c)
    _add_box(sc,"ramp",nodes,[{ramp_hl},{ramp_hw},{ramp_ht}],{p.ramp_color})
    _set_pose(sc,nodes["ramp"],ramp_pos,ramp_orn)
    obj_r=0.10; bids=[]
    top_pos=[{top_x},0.0,{top_z}]
    {"s=pb.createCollisionShape(pb.GEOM_SPHERE,radius=obj_r,physicsClientId=c)" if p.obj_type=="sphere" else "s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[obj_r,obj_r,obj_r],physicsClientId=c)"}
    bid=pb.createMultiBody({p.slide_mass},s,-1,top_pos,[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(bid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
    {"_add_sphere(sc,'obj',nodes,obj_r," + str(p.obj_color) + ")" if p.obj_type=="sphere" else "_add_box(sc,'obj',nodes,[obj_r,obj_r,obj_r]," + str(p.obj_color) + ")"}
    bids.append(("obj",bid))
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_ramp_slide_friction")
    print("OK")
