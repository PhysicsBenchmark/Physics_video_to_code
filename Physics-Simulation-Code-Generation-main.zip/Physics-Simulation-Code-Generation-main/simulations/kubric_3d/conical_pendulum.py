"""conical_pendulum — sphere orbits in horizontal circle on a rod, tracing a cone."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (4, -4, 5)
CAM_TARGET = (0, 0, 2)
N_FRAMES   = 180


@dataclass
class Params:
    seed: int
    rod_length: float
    ball_radius: float
    ball_mass: float
    cone_half_angle_deg: float
    init_tangential_speed: float
    pivot_height: float
    color: List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    h = random.random()
    s, v = 0.85, 0.90
    hi = int(h * 6) % 6
    f  = h * 6 - int(h * 6)
    p_ = v * (1 - s); q = v * (1 - f*s); t = v * (1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    color = [r, g, b, 1.0]
    rod_len = random.uniform(1.5, 3.0)
    cone_angle = random.uniform(10.0, 30.0)
    # Ideal tangential speed for conical pendulum: v = sqrt(g * r_orbit / cos(alpha) * tan(alpha))
    # r_orbit = L * sin(alpha)
    alpha = math.radians(cone_angle)
    r_orbit = rod_len * math.sin(alpha)
    ideal_v = math.sqrt(9.81 * r_orbit * math.tan(alpha))
    # perturb slightly
    actual_v = ideal_v * random.uniform(0.85, 1.15)
    return Params(
        seed=seed,
        rod_length=rod_len,
        ball_radius=random.uniform(0.04, 0.09),
        ball_mass=random.uniform(0.3, 1.5),
        cone_half_angle_deg=cone_angle,
        init_tangential_speed=actual_v,
        pivot_height=rod_len + 0.3,
        color=color,
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=0.5)
    ren.add_plane_mesh("floor", 10.0, [0.42, 0.42, 0.45, 1.0])

    pivot = [0.0, 0.0, p.pivot_height]

    # Ball starts displaced along x-axis by L*sin(alpha)
    alpha = math.radians(p.cone_half_angle_deg)
    r_orbit = p.rod_length * math.sin(alpha)
    bz = p.pivot_height - p.rod_length * math.cos(alpha)
    ball_pos = [r_orbit, 0.0, bz]

    # Tangential velocity is in y direction (perpendicular to x in horizontal plane)
    ball_vel = [0.0, p.init_tangential_speed, 0.0]

    ball_id = phys.add_sphere(
        radius=p.ball_radius, pos=ball_pos, mass=p.ball_mass,
        friction=0.05, restitution=0.3, vel=ball_vel)

    # Fixed anchor at pivot (mass=0 → already static; no extra JOINT_FIXED needed)
    anchor_id = phys.add_sphere(radius=0.03, pos=pivot, mass=0.0,
                                friction=0.0, restitution=0.0)

    # Connect ball to anchor
    # child_pos = vector from ball center to pivot in ball's local frame
    pivot_in_ball = [pivot[0]-ball_pos[0], pivot[1]-ball_pos[1], pivot[2]-ball_pos[2]]
    phys.create_constraint(
        anchor_id, -1, ball_id, -1,
        pb_mod.JOINT_POINT2POINT, [0, 0, 0],
        [0.0, 0.0, 0.0], pivot_in_ball,
        max_force=1500.0)

    ren.add_sphere("ball", p.ball_radius, p.color)
    ren.set_static_pose("ball", ball_pos)

    _pivot = pivot  # capture for closure
    _ball_id = ball_id
    ren.add_sphere("pivot", 0.04, [0.85, 0.85, 0.85, 1.0])
    ren.set_static_pose("pivot", pivot)

    str_radius = 0.012
    str_color = [0.25, 0.18, 0.10, 1.0]

    def extra_sync_fn(phys, ren, fi):
        ball_p, _ = phys.get_pose(_ball_id)
        ren.update_string("string", _pivot, ball_p.tolist(), str_radius, str_color)

    dyn = [("ball", ball_id)]
    frames = run_loop(phys, ren, dyn, N_FRAMES, extra_sync_fn=extra_sync_fn)

    orbit_period = 2 * math.pi * r_orbit / p.init_tangential_speed if p.init_tangential_speed > 0 else 0
    cot = build_cot(
        simulation="conical_pendulum",
        category="articulated_jointed",
        seed=seed,
        physical_observation=(
            f"Conical pendulum: L={p.rod_length:.2f}m, α={p.cone_half_angle_deg:.1f}°, "
            f"m={p.ball_mass:.2f}kg, v_tan={p.init_tangential_speed:.2f} m/s. "
            f"Orbit radius r={r_orbit:.3f}m."
        ),
        law_name="Conical pendulum dynamics",
        law_statement=(
            "A mass on an inextensible rod, given horizontal tangential velocity, "
            "orbits in a horizontal circle: tension balances gravity and provides centripetal force."
        ),
        law_formula=(
            "T·cosα = mg; T·sinα = mω²·r; r = L·sinα; "
            "ω = sqrt(g·tanα/r) = sqrt(g/(L·cosα))"
        ),
        assumptions=[
            "Massless inextensible rod (JOINT_POINT2POINT constraint)",
            "No air drag",
            "Steady circular orbit requires exactly v = sqrt(g·L·sin²α/cosα)",
            "Slight perturbation leads to precessing conical-like motion",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "T\\cos\\alpha = mg",
            "T\\sin\\alpha = m\\omega^2 r",
            "\\omega = \\sqrt{\\frac{g}{L\\cos\\alpha}}",
            "v_{\\text{tan}} = \\omega L\\sin\\alpha",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            f"Orbit radius: r = L·sinα = {r_orbit:.4f} m",
            f"Required angular velocity: ω = sqrt(g/(L·cosα)) = {math.sqrt(9.81/(p.rod_length*math.cos(alpha))):.3f} rad/s",
            f"Required tangential speed: v = {math.sqrt(9.81*r_orbit*math.tan(alpha)):.3f} m/s",
            f"Actual tangential speed set to: {p.init_tangential_speed:.3f} m/s",
            f"Approximate orbital period: {orbit_period:.3f} s",
        ],
        expected_behavior=[
            "Ball orbits in approximately horizontal circle",
            "Height of orbit determined by cone angle",
            "If v != ideal, ball oscillates while orbiting (precessing ellipse on cone)",
            "Orbit visible as nearly circular path from above",
        ],
        parameters={
            "rod_length":           param_entry(p.rod_length,           "m",    "rod length"),
            "ball_radius":          param_entry(p.ball_radius,          "m",    "sphere radius"),
            "ball_mass":            param_entry(p.ball_mass,            "kg",   "bob mass"),
            "cone_half_angle_deg":  param_entry(p.cone_half_angle_deg,  "°",    "half-angle of cone"),
            "init_tangential_speed":param_entry(p.init_tangential_speed,"m/s",  "initial tangential speed"),
            "pivot_height":         param_entry(p.pivot_height,         "m",    "pivot height above ground"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    alpha = math.radians(p.cone_half_angle_deg)
    r_orbit = p.rod_length * math.sin(alpha)
    bz = p.pivot_height - p.rod_length * math.cos(alpha)
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# conical_pendulum  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[5.0,5.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    sa=pb.createCollisionShape(pb.GEOM_SPHERE,radius=0.03,physicsClientId=c)
    anc=pb.createMultiBody(0,sa,-1,[0,0,{p.pivot_height}],[0,0,0,1],physicsClientId=c)
    pb.createConstraint(anc,-1,-1,-1,pb.JOINT_FIXED,[0,0,0],[0,0,0],[0,0,{p.pivot_height}],physicsClientId=c)
    sb=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.ball_radius},physicsClientId=c)
    ball=pb.createMultiBody({p.ball_mass},sb,-1,[{r_orbit:.4f},0,{bz:.4f}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(ball,-1,lateralFriction=0.05,restitution=0.3,physicsClientId=c)
    pb.resetBaseVelocity(ball,[0,{p.init_tangential_speed:.4f},0],[0,0,0],physicsClientId=c)
    cid=pb.createConstraint(anc,-1,ball,-1,pb.JOINT_POINT2POINT,[0,0,0],
        [0,0,0],[{-r_orbit:.4f},0,{p.pivot_height-bz:.4f}],physicsClientId=c)
    pb.changeConstraint(cid,maxForce=1500,physicsClientId=c)
    _add_sphere(sc,"ball",nodes,{p.ball_radius},{p.color})
    bids=[("ball",ball)]; frames=[]; pivot_pos=[0,0,{p.pivot_height}]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn)
        ball_pos2,_=pb.getBasePositionAndOrientation(ball,physicsClientId=c)
        _update_string(sc,nodes,"string",pivot_pos,list(ball_pos2),0.006,[0.25,0.18,0.10,1.0])
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_conical_pendulum")
    print("OK")
