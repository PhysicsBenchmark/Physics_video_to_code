"""billiard_break_3d — cue ball breaks a triangle rack of 10 pool balls."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (0, -6, 5)
CAM_TARGET = (0, 0, 0)
N_FRAMES   = 120  # 4 s @ 30 fps

# Ball radius for pool balls
BALL_RADIUS = 0.028  # m


@dataclass
class Params:
    seed:        int
    cue_speed:   float   # m/s
    ball_mass:   float   # kg
    restitution: float
    friction:    float
    cue_color:   List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        cue_speed=random.uniform(4.0, 8.0),
        ball_mass=random.uniform(0.15, 0.20),
        restitution=random.uniform(0.85, 0.97),
        friction=random.uniform(0.05, 0.25),
        cue_color=[0.95, 0.95, 0.88, 1.0],
    )


# Triangle rack positions (rows 1-4 in the +Y half of the table)
def _rack_positions(r: float) -> List[List[float]]:
    """Return [x, y, z] for all 10 rack balls in a triangle."""
    gap = r * 2.05  # slight gap to avoid initial penetration
    positions = []
    y0 = 0.5  # front of rack
    for row in range(4):
        n = row + 1
        x_start = -(row * gap / 2.0)
        for col in range(n):
            x = x_start + col * gap
            y = y0 + row * gap * math.sqrt(3) / 2.0
            positions.append([x, y, BALL_RADIUS])
    return positions


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    # Green felt table as the floor
    phys.add_plane(friction=p.friction, restitution=0.2)
    ren.add_plane_mesh("floor", 5.0, [0.10, 0.55, 0.15, 1.0])
    ren.set_static_pose("floor", [0, 0, 0])

    # Billiard table rails (static walls)
    table_half_x = 1.5  # half-width in X direction
    table_half_y = 2.5  # half-length in Y direction
    rail_h = 0.08       # height of rail above table
    rail_t = 0.06       # thickness of rail
    rail_col = [0.3, 0.18, 0.08, 1.0]  # dark wood color

    for rname, he, pos in [
        ("rN",  [table_half_x, rail_t, rail_h], [0,  table_half_y + rail_t, rail_h]),
        ("rS",  [table_half_x, rail_t, rail_h], [0, -table_half_y - rail_t, rail_h]),
        ("rE",  [rail_t, table_half_y, rail_h], [ table_half_x + rail_t, 0, rail_h]),
        ("rW",  [rail_t, table_half_y, rail_h], [-table_half_x - rail_t, 0, rail_h])]:
        phys.add_box(he, pos, mass=0, friction=0.3, restitution=0.7)
        ren.add_box(rname, he, rail_col)
        ren.set_static_pose(rname, pos)

    # Ball colours for rack
    ball_colors = [
        [0.9, 0.7, 0.1, 1.0], [0.1, 0.2, 0.8, 1.0], [0.8, 0.1, 0.1, 1.0],
        [0.5, 0.1, 0.5, 1.0], [0.9, 0.4, 0.1, 1.0], [0.1, 0.5, 0.2, 1.0],
        [0.7, 0.1, 0.1, 1.0], [0.1, 0.1, 0.1, 1.0], [0.9, 0.8, 0.2, 1.0],
        [0.2, 0.4, 0.8, 1.0],
    ]

    dyn = []
    rack_pos = _rack_positions(BALL_RADIUS)
    for i, pos in enumerate(rack_pos):
        bid = phys.add_sphere(BALL_RADIUS, pos,
                              mass=p.ball_mass, friction=p.friction,
                              restitution=p.restitution)
        name = f"ball_{i}"
        ren.add_sphere(name, BALL_RADIUS, ball_colors[i])
        dyn.append((name, bid))

    # Cue ball: starts at -Y, shoots in +Y
    cue_bid = phys.add_sphere(BALL_RADIUS,
                              [0.0, -1.2, BALL_RADIUS],
                              mass=p.ball_mass, friction=p.friction,
                              restitution=p.restitution,
                              vel=[0.0, p.cue_speed, 0.0])
    ren.add_sphere("cue", BALL_RADIUS, p.cue_color)
    dyn.append(("cue", cue_bid))

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="billiard_break_3d",
        category="rigid_body_free_dynamics",
        seed=seed,
        physical_observation=(
            f"Cue ball (r={BALL_RADIUS} m, m={p.ball_mass:.3f} kg) "
            f"launched at {p.cue_speed:.1f} m/s strikes a 10-ball triangle rack. "
            f"Restitution e={p.restitution:.2f}, friction μ={p.friction:.2f}."),
        law_name="Newton-Euler rigid-body dynamics + elastic sphere collision",
        law_statement=(
            "Cue ball transfers momentum to rack balls via contact impulse; "
            "momentum and (approximately) kinetic energy are conserved."),
        law_formula="m*v_cue = sum(m*v_i) [momentum conservation]",
        assumptions=[
            "All balls are perfect spheres of equal mass and radius.",
            "Table provides uniform friction; no cushion bounce.",
            "Collisions are nearly elastic (high restitution).",
        ],
        state_variables=["position r (m)", "velocity v (m/s)",
                         "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg+F_c",
            "I\\dot{\\omega}=\\tau_c-\\omega\\times I\\omega",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            f"Cue ball launched at {p.cue_speed:.1f} m/s toward rack apex.",
            "Contact impulse at apex propagates through triangle.",
            "Balls scatter according to collision geometry.",
            "Friction decelerates all balls on felt surface.",
        ],
        expected_behavior=[
            "Cue ball strikes rack apex ball, scattering all 10 balls.",
            "Balls roll/slide across table and decelerate due to friction.",
            f"High restitution ({p.restitution:.2f}) results in energetic break.",
        ],
        parameters={
            "cue_speed_mps":  param_entry(p.cue_speed,   "m/s", "Cue ball launch speed"),
            "ball_mass_kg":   param_entry(p.ball_mass,   "kg",  "Mass of each ball"),
            "restitution":    param_entry(p.restitution, "",    "Coefficient of restitution"),
            "friction":       param_entry(p.friction,    "",    "Felt friction coefficient"),
            "ball_radius_m":  param_entry(BALL_RADIUS,   "m",   "Ball radius"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    rack_pos = _rack_positions(BALL_RADIUS)
    ball_colors = [
        [0.9, 0.7, 0.1, 1.0], [0.1, 0.2, 0.8, 1.0], [0.8, 0.1, 0.1, 1.0],
        [0.5, 0.1, 0.5, 1.0], [0.9, 0.4, 0.1, 1.0], [0.1, 0.5, 0.2, 1.0],
        [0.7, 0.1, 0.1, 1.0], [0.1, 0.1, 0.1, 1.0], [0.9, 0.8, 0.2, 1.0],
        [0.2, 0.4, 0.8, 1.0],
    ]
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# billiard_break_3d  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}
BALL_RADIUS={BALL_RADIUS}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[2.5,2.5,0.02],[0.10,0.55,0.15,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    rack={rack_pos}
    bcolors={ball_colors}
    bids=[]
    for i,(pos,bc) in enumerate(zip(rack,bcolors)):
        s=pb.createCollisionShape(pb.GEOM_SPHERE,radius=BALL_RADIUS,physicsClientId=c)
        bid=pb.createMultiBody({p.ball_mass},s,-1,pos,[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
        nm=f"ball_{{i}}"; _add_sphere(sc,nm,nodes,BALL_RADIUS,bc); bids.append((nm,bid))
    s=pb.createCollisionShape(pb.GEOM_SPHERE,radius=BALL_RADIUS,physicsClientId=c)
    cid=pb.createMultiBody({p.ball_mass},s,-1,[0,-1.2,BALL_RADIUS],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(cid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
    pb.resetBaseVelocity(cid,[0,{p.cue_speed},0],[0,0,0],physicsClientId=c)
    _add_sphere(sc,"cue",nodes,BALL_RADIUS,{p.cue_color}); bids.append(("cue",cid))
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_billiard_break_3d")
    print("OK")
