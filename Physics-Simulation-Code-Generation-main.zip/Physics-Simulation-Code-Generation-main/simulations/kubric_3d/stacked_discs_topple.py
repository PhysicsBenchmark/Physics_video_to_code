"""stacked_discs_topple — tower of discs with decreasing radius perturbed and toppled."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (4, -3, 4)
CAM_TARGET = (0, 0, 1)
N_FRAMES   = 150


@dataclass
class Params:
    seed: int
    n_discs: int
    base_radius: float
    radius_decrease: float
    disc_height: float
    disc_mass: float
    restitution: float
    perturbation_ang_vel: float
    floor_friction: float
    colors: List[List[float]]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    n = random.randint(4, 8)
    return Params(
        seed=seed,
        n_discs=n,
        base_radius=random.uniform(0.35, 0.55),
        radius_decrease=random.uniform(0.04, 0.08),
        disc_height=random.uniform(0.06, 0.12),
        disc_mass=random.uniform(0.5, 1.5),
        restitution=random.uniform(0.2, 0.5),
        perturbation_ang_vel=random.uniform(0.5, 2.5),
        floor_friction=random.uniform(0.4, 0.7),
        colors=[_rand_hue() for _ in range(n)],
    )


def _rand_hue():
    h = random.random(); s, v = 0.85, 0.90
    hi = int(h*6) % 6; f = h*6 - int(h*6)
    p_ = v*(1-s); q = v*(1-f*s); t = v*(1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return [r, g, b, 1.0]


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 8.0, [0.42, 0.42, 0.45, 1.0])

    # Tower starts with slight overall lean (2.5°) so gravity drives cascade
    lean_angle = math.radians(2.5)

    dyn = []
    z_base = 0.0
    for i in range(p.n_discs):
        r = max(0.06, p.base_radius - i * p.radius_decrease)
        dz = p.disc_height / 2.0
        z_center = z_base + dz
        # Lean offset: each disc is shifted slightly in X proportional to height
        lean_ox = math.sin(lean_angle) * z_center
        # Small random offset for instability
        ox = lean_ox + random.uniform(-0.005, 0.005)
        oy = random.uniform(-0.005, 0.005)
        # Apply perturbation to ALL discs, magnitude proportional to height (top gets most)
        frac = (i + 1) / p.n_discs  # 0→1 from bottom to top
        vel_x = p.perturbation_ang_vel * frac * 2.0
        ang_vel = (p.perturbation_ang_vel * frac, 0.0, 0.0)
        vel = (vel_x, 0.0, 0.0)
        nm = f"disc{i}"
        color = p.colors[i]
        # Reduce disc-to-disc friction so they slide off each other during collapse
        disc_friction = p.floor_friction * 0.4
        bid = phys.add_cylinder(r, p.disc_height, [ox, oy, z_center],
                                  mass=p.disc_mass, friction=disc_friction,
                                  restitution=p.restitution, ang_vel=ang_vel,
                                  vel=vel)
        ren.add_cylinder(nm, r, p.disc_height, color)
        ren.set_static_pose(nm, [ox, oy, z_center])
        dyn.append((nm, bid))
        z_base += p.disc_height

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    total_height = p.n_discs * p.disc_height
    cot = build_cot(
        simulation="stacked_discs_topple",
        category="mixed_complex",
        seed=seed,
        physical_observation=(
            f"Tower of {p.n_discs} discs stacked vertically (base r={p.base_radius:.2f}m, "
            f"shrinking by {p.radius_decrease:.3f}m per disc, h={p.disc_height:.3f}m each), "
            f"total height={total_height:.3f}m; top disc perturbed at ω={p.perturbation_ang_vel:.2f} rad/s."
        ),
        law_name="Rigid-body tipping and cascade collapse",
        law_statement=(
            "Tower becomes unstable when center of mass moves outside base support polygon; "
            "angular perturbation initiates tip, contact impulses propagate collapse downward."
        ),
        law_formula="τ_tip = m·g·d_cm; I·α = τ_net",
        assumptions=[
            "Each disc is a rigid cylinder",
            "Coulomb friction between discs and floor",
            "Disc radii decrease linearly from base to top",
            "Perturbation applied only to topmost disc",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg+\\sum F_c",
            "I\\dot{\\omega}=\\sum\\tau_c-\\omega\\times I\\omega",
            "\\tau_{tip}=mgd_{cm}",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B + cross_terms)",
        derivation_steps=[
            f"Tower center of mass at height ≈{total_height/2:.3f}m",
            "Top disc angular perturbation shifts CM outside support",
            "Tipping torque τ = m·g·d grows as disc tilts",
            "Upper disc falls onto lower; cascade topple propagates downward",
            "Floor friction determines slide vs. pure tip trajectory",
        ],
        expected_behavior=[
            "Top disc begins to tilt and lean",
            "Upper discs fall and hit lower discs",
            "Cascade collapse of full tower",
            "Discs scatter on floor",
        ],
        parameters={
            "n_discs":              param_entry(p.n_discs,              "",       "number of discs in stack"),
            "base_radius":          param_entry(p.base_radius,          "m",      "radius of bottom disc"),
            "radius_decrease":      param_entry(p.radius_decrease,      "m/disc", "radius reduction per disc"),
            "disc_height":          param_entry(p.disc_height,          "m",      "height of each disc"),
            "disc_mass":            param_entry(p.disc_mass,            "kg",     "mass of each disc"),
            "perturbation_ang_vel": param_entry(p.perturbation_ang_vel, "rad/s",  "initial angular velocity of top disc"),
            "restitution":          param_entry(p.restitution,          "",       "coefficient of restitution"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    random.seed(p.seed); np.random.seed(p.seed)
    random_params(p.seed)  # consume rng
    random.seed(p.seed); np.random.seed(p.seed)
    pp = random_params(p.seed)
    disc_lines = []
    z_base = 0.0
    random.seed(p.seed + 7777); np.random.seed(p.seed + 7777)
    for i in range(pp.n_discs):
        r = max(0.06, pp.base_radius - i * pp.radius_decrease)
        dz = pp.disc_height / 2.0
        z_center = z_base + dz
        ox = round(random.uniform(-0.01, 0.01), 5)
        oy = round(random.uniform(-0.01, 0.01), 5)
        ang_vel = [0.0, 0.0, 0.0]
        lin_vel = [0.0, 0.0, 0.0]
        if i == pp.n_discs - 1:
            ang_vel = [pp.perturbation_ang_vel, 0.0, 0.0]
            lin_vel = [pp.perturbation_ang_vel * 0.8, 0.0, 0.0]
        color = pp.colors[i]
        disc_lines.append(
            f"    sc_=pb.createCollisionShape(pb.GEOM_CYLINDER,radius={r:.4f},height={pp.disc_height},physicsClientId=c)\n"
            f"    disc{i}=pb.createMultiBody({pp.disc_mass},sc_,-1,[{ox},{oy},{z_center:.4f}],[0,0,0,1],physicsClientId=c)\n"
            f"    pb.changeDynamics(disc{i},-1,lateralFriction={pp.floor_friction},restitution={pp.restitution},physicsClientId=c)\n"
            f"    pb.resetBaseVelocity(disc{i},{lin_vel},{ang_vel},physicsClientId=c)\n"
            f"    _add_cylinder(sc,'disc{i}',nodes,{r:.4f},{pp.disc_height},{color})\n"
            f"    _set_pose(sc,nodes['disc{i}'],[{ox},{oy},{z_center:.4f}],[0,0,0,1])\n"
        )
        z_base += pp.disc_height
    bids_list = "[" + ",".join([f"('disc{i}',disc{i})" for i in range(pp.n_discs)]) + "]"
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# stacked_discs_topple  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[4.0,4.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
{"".join(disc_lines)}    bids={bids_list}
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete()
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_stacked_discs_topple")
    print("OK")
