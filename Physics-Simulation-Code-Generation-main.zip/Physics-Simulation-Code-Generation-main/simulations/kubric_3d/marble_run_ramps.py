"""marble_run_ramps — marble rolls down a series of angled ramps at decreasing heights."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (6, -3, 5)
CAM_TARGET = (1, 0, 1.5)
N_FRAMES   = 150


@dataclass
class Params:
    seed: int
    n_ramps: int
    ramp_angle_deg: float
    ramp_length: float
    ramp_width: float
    marble_radius: float
    marble_mass: float
    ramp_friction: float
    restitution: float
    color_marble: List[float]
    color_ramp: List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        n_ramps=random.randint(3, 4),
        ramp_angle_deg=random.uniform(15.0, 30.0),
        ramp_length=random.uniform(1.2, 2.0),
        ramp_width=random.uniform(0.25, 0.45),
        marble_radius=random.uniform(0.05, 0.09),
        marble_mass=random.uniform(0.05, 0.2),
        ramp_friction=random.uniform(0.3, 0.6),
        restitution=random.uniform(0.3, 0.6),
        color_marble=_rand_hue(),
        color_ramp=_rand_hue(),
    )


def _rand_hue():
    h = random.random(); s, v = 0.85, 0.90
    hi = int(h*6) % 6; f = h*6 - int(h*6)
    p_ = v*(1-s); q = v*(1-f*s); t = v*(1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return [r, g, b, 1.0]


def _ramp_geometry(n_ramps, ramp_length, ramp_angle_deg, start_height=2.5):
    """Compute ramp center positions and orientations for a zigzag marble run."""
    ramps = []
    angle = math.radians(ramp_angle_deg)
    dz = ramp_length * math.sin(angle)   # height drop per ramp
    dx = ramp_length * math.cos(angle)   # horizontal span per ramp
    ramp_h = 0.04  # half-thickness

    # Lay ramps along the X axis alternating tilt direction (slope in X)
    # Ramp i: starts at (x_start, y_i) and descends along X
    # Even ramps slope downward in +X; odd ramps slope downward in -X
    # Place ramps so the ball falls off the low end onto the high end of the next
    x_anchor = 0.0  # x position of the HIGH end of ramp i
    y_pos = 0.0

    for i in range(n_ramps):
        tilt_sign = 1 if i % 2 == 0 else -1
        # High-end x, low-end x of ramp i
        high_x = x_anchor
        low_x  = high_x + tilt_sign * dx

        # Center of ramp in X
        cx = (high_x + low_x) / 2.0
        cy = y_pos
        # Top (high) z of ramp surface at center
        top_z = start_height - i * (dz * 0.85)
        cz = top_z - dz / 2.0   # center z is halfway down

        # Orientation: rotate about Y axis
        rot_angle = -tilt_sign * angle   # negative because tilting in -Z direction as X increases
        qy = [0.0, math.sin(rot_angle / 2), 0.0, math.cos(rot_angle / 2)]

        # Surface normal in world frame: ramp top surface is tilted
        # normal points in direction [sin(angle)*tilt_sign, 0, cos(angle)]
        surface_normal = [math.sin(angle) * tilt_sign, 0.0, math.cos(angle)]

        # Ball start at the high end, on the surface
        ball_start_x = high_x - tilt_sign * 0.05  # slightly inset from high edge
        ball_start_z = (top_z + ramp_h +           # surface at high end
                        0.0)                        # ball radius added separately

        ramps.append({
            "cx": cx, "cy": cy, "cz": cz,
            "orn": qy,
            "he": [ramp_length / 2, 0.2, ramp_h],
            "top_x": ball_start_x,
            "top_z": ball_start_z,
            "surface_normal": surface_normal,
            "tilt_sign": tilt_sign,
            "angle": angle,
        })
        # Next ramp's high end is near this ramp's low end, offset in Y
        x_anchor = low_x
        y_pos += (1 if i % 2 == 0 else -1) * 0.0  # keep same Y for straight run
    return ramps


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.ramp_friction)
    ren.add_plane_mesh("floor", 10.0, [0.42, 0.42, 0.45, 1.0])

    ramps = _ramp_geometry(p.n_ramps, p.ramp_length, p.ramp_angle_deg)
    ramp_he = [p.ramp_length / 2, p.ramp_width / 2, 0.04]

    for i, r in enumerate(ramps):
        he = [p.ramp_length / 2, p.ramp_width / 2, 0.04]
        orn = r["orn"]
        pos = [r["cx"], r["cy"], r["cz"]]
        phys.add_box(he, pos, orn=orn, mass=0.0, friction=p.ramp_friction,
                     restitution=p.restitution)
        ren.add_box(f"ramp{i}", he, p.color_ramp)
        ren.set_static_pose(f"ramp{i}", pos, orn)

    # Marble starts on top surface of first ramp, exactly at the high end
    r0 = ramps[0]
    mx = r0["top_x"]
    my = r0["cy"]
    # Surface height at high end: ramp center z + half-thickness + slope offset
    # The ramp center is at cz, and at the high end (dx/2 along ramp), z is top_z
    # Place ball center = surface z + marble_radius * cos(angle) (along normal)
    angle0 = r0["angle"]
    ramp_surface_z = r0["top_z"] + r0["he"][2]  # top of ramp box at high end
    mz = ramp_surface_z + p.marble_radius        # ball center on surface

    # Initial velocity: down the slope (in direction of descent)
    tilt0 = r0["tilt_sign"]
    # Slope direction: [tilt_sign * cos(angle), 0, -sin(angle)] in world frame
    vx_init = tilt0 * math.cos(angle0) * 1.5   # m/s down the slope
    vz_init = -math.sin(angle0) * 1.5

    marble_id = phys.add_sphere(p.marble_radius, [mx, my, mz],
                                  mass=p.marble_mass, friction=p.ramp_friction,
                                  restitution=p.restitution,
                                  vel=(vx_init, 0.0, vz_init))
    ren.add_sphere("marble", p.marble_radius, p.color_marble, metallic=0.3, roughness=0.2)
    ren.set_static_pose("marble", [mx, my, mz])

    dyn = [("marble", marble_id)]
    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="marble_run_ramps",
        category="mixed_complex",
        seed=seed,
        physical_observation=(
            f"Marble r={p.marble_radius:.3f}m m={p.marble_mass:.3f}kg rolls down {p.n_ramps} ramps "
            f"at {p.ramp_angle_deg:.1f}° incline (length={p.ramp_length:.2f}m), "
            f"alternating left-right orientation."
        ),
        law_name="Rigid-body rolling dynamics on inclined planes",
        law_statement=(
            "Marble rolls down each inclined ramp, converting gravitational PE to translational "
            "and rotational KE; transitions between ramps via free-fall and contact impulse."
        ),
        law_formula="a = g·sin(θ) / (1 + I/(m·r²)) = (5/7)·g·sin(θ) for solid sphere",
        assumptions=[
            "Rigid sphere rolling without slipping on ramp surface",
            "Coulomb friction ensures rolling contact (no slip)",
            "Ramps are static (mass=0)",
            "No air resistance",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "a=\\frac{5}{7}g\\sin\\theta",
            "v(t)=v_0+at",
            "\\omega=v/r",
            "I=\\frac{2}{5}mr^2",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            f"Ramp angle θ={p.ramp_angle_deg:.1f}°; acceleration a={5/7*9.81*math.sin(math.radians(p.ramp_angle_deg)):.3f} m/s²",
            f"Ramp length={p.ramp_length:.2f}m; time to traverse ≈{math.sqrt(2*p.ramp_length/(5/7*9.81*math.sin(math.radians(p.ramp_angle_deg)))):.2f}s",
            "Marble leaves ramp edge as projectile, lands on next lower ramp",
            f"Height drop per ramp ≈{p.ramp_length*math.sin(math.radians(p.ramp_angle_deg)):.3f}m",
        ],
        expected_behavior=[
            "Marble accelerates down first ramp",
            "Falls from ramp edge to next lower ramp",
            "Cascades through all ramps gaining speed",
            "Lands on floor and rolls away",
        ],
        parameters={
            "n_ramps":        param_entry(p.n_ramps,        "",    "number of ramps"),
            "ramp_angle_deg": param_entry(p.ramp_angle_deg, "deg", "ramp inclination angle"),
            "ramp_length":    param_entry(p.ramp_length,    "m",   "ramp length"),
            "ramp_width":     param_entry(p.ramp_width,     "m",   "ramp width"),
            "marble_radius":  param_entry(p.marble_radius,  "m",   "marble radius"),
            "marble_mass":    param_entry(p.marble_mass,    "kg",  "marble mass"),
            "ramp_friction":  param_entry(p.ramp_friction,  "",    "ramp-marble friction coefficient"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    ramps = _ramp_geometry(p.n_ramps, p.ramp_length, p.ramp_angle_deg)
    r0 = ramps[0]
    mx = r0["top_x"]
    my = r0["cy"]
    mz = r0["top_z"] + p.marble_radius + 0.06
    ramp_lines = []
    for i, r in enumerate(ramps):
        he = [p.ramp_length / 2, p.ramp_width / 2, 0.04]
        ramp_lines.append(
            f"    sr=pb.createCollisionShape(pb.GEOM_BOX,halfExtents={he},physicsClientId=c)\n"
            f"    pb.createMultiBody(0,sr,-1,[{r['cx']:.4f},{r['cy']:.4f},{r['cz']:.4f}],{r['orn']},physicsClientId=c)\n"
            f"    _add_box(sc,'ramp{i}',nodes,{he},{p.color_ramp})\n"
            f"    _set_pose(sc,nodes['ramp{i}'],[{r['cx']:.4f},{r['cy']:.4f},{r['cz']:.4f}],{r['orn']})\n"
        )
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# marble_run_ramps  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[5.0,5.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
{"".join(ramp_lines)}    sm=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.marble_radius},physicsClientId=c)
    marble=pb.createMultiBody({p.marble_mass},sm,-1,[{mx:.4f},{my:.4f},{mz:.4f}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(marble,-1,lateralFriction={p.ramp_friction},restitution={p.restitution},physicsClientId=c)
    _add_sphere(sc,"marble",nodes,{p.marble_radius},{p.color_marble})
    _set_pose(sc,nodes["marble"],[{mx:.4f},{my:.4f},{mz:.4f}],[0,0,0,1])
    bids=[("marble",marble)]
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete()
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_marble_run_ramps")
    print("OK")
