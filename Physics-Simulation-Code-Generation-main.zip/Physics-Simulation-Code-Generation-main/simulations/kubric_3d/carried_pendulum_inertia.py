"""carried_pendulum_inertia — pendulum bob hung from a cart swings into a free-standing block.

A small cart on the floor carries a vertical mast.  An inextensible string
(POINT2POINT constraint) attaches the pendulum bob to a pivot at the top of
the mast.  The bob is given an initial horizontal velocity tangent to the arc
at the bottom of its swing; it swings forward and strikes a free-standing
block resting on the floor in front of the cart.  The block recoils visibly
under the impact impulse and the bob bounces back along its pendulum arc.
"""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (2.6, -3.4, 1.8)
CAM_TARGET = (-0.55, 0.0, 0.45)
N_FRAMES   = 150
FPS        = 30
G          = 9.81


@dataclass
class Params:
    seed: int
    cart_mass: float
    cart_half: List[float]
    cart_pos: List[float]
    cart_init_speed: float
    pivot_offset: List[float]          # local offset from cart centre to pivot
    pendulum_length: float
    bob_mass: float
    bob_radius: float
    bob_pos: List[float]               # initial world position
    bob_init_speed: float              # initial tangential (+x) speed
    target_mass: float
    target_half: List[float]
    target_pos: List[float]
    target_friction: float
    cart_color: List[float]
    bob_color: List[float]
    target_color: List[float]
    mast_color: List[float]


def random_params(seed: int) -> Params:
    rng = random.Random(seed)
    cart_half  = [0.20, 0.20, 0.10]
    cart_z     = cart_half[2]                                # cart sits on floor
    cart_x     = -1.20
    cart_pos   = [cart_x, 0.0, cart_z]
    pivot_off  = [cart_half[0], 0.0, 0.85]                   # at cart's front-top
    pivot_z    = cart_z + pivot_off[2]                       # world z of pivot
    L          = 0.60                                        # pendulum length
    bob_radius = rng.uniform(0.09, 0.12)
    bob_pos    = [cart_x + pivot_off[0], 0.0, pivot_z - L]   # straight down from pivot
    bob_init_speed = rng.uniform(2.4, 3.0)
    target_half = [0.12, 0.18, 0.22]
    target_x   = bob_pos[0] + 0.45                            # bob swings ~0.25m to reach back face
    target_pos = [target_x, 0.0, target_half[2]]              # sits on floor
    return Params(
        seed=seed,
        cart_mass=rng.uniform(0.9, 1.4),
        cart_half=cart_half,
        cart_pos=cart_pos,
        cart_init_speed=rng.uniform(0.0, 0.10),               # small drift only
        pivot_offset=pivot_off,
        pendulum_length=L,
        bob_mass=rng.uniform(0.30, 0.55),
        bob_radius=bob_radius,
        bob_pos=bob_pos,
        bob_init_speed=bob_init_speed,
        target_mass=rng.uniform(0.5, 0.9),
        target_half=target_half,
        target_pos=target_pos,
        target_friction=0.35,
        cart_color=[0.16, 0.42, 0.86, 1.0],
        bob_color=[0.86, 0.20, 0.16, 1.0],
        target_color=[0.20, 0.72, 0.34, 1.0],
        mast_color=[0.18, 0.14, 0.10, 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, save_sample, build_cot, param_entry,
        FPS as BASE_FPS, STEP_RATE, metadata_only)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)
    phys.add_plane(friction=0.65)
    ren.add_plane_mesh("floor", 5.5, [0.42, 0.42, 0.45, 1.0])

    cart_id = phys.add_box(p.cart_half, p.cart_pos, mass=p.cart_mass,
                           friction=0.7, restitution=0.20,
                           vel=[p.cart_init_speed, 0, 0],
                           lin_damp=0.05, ang_damp=0.2)
    ren.add_box("cart", p.cart_half, p.cart_color)
    ren.set_static_pose("cart", p.cart_pos)

    bob_id = phys.add_sphere(
        p.bob_radius, p.bob_pos, mass=p.bob_mass,
        friction=0.10, restitution=0.55,
        vel=[p.bob_init_speed, 0, 0],
        lin_damp=0.0, ang_damp=0.05)
    ren.add_sphere("bob", p.bob_radius, p.bob_color)
    ren.set_static_pose("bob", p.bob_pos)

    target_id = phys.add_box(p.target_half, p.target_pos, mass=p.target_mass,
                             friction=p.target_friction, restitution=0.30,
                             lin_damp=0.05, ang_damp=0.3)
    ren.add_box("target", p.target_half, p.target_color)
    ren.set_static_pose("target", p.target_pos)

    # Inextensible string: cart's pivot offset coincides with the bob's top
    # offset (length L straight down in bob's local frame at t=0).  Use a very
    # high maxForce so the rope-equivalent stays rigid through the impact.
    phys.create_constraint(
        cart_id, -1, bob_id, -1,
        pb_mod.JOINT_POINT2POINT, [0, 0, 0],
        list(p.pivot_offset),
        [0.0, 0.0, p.pendulum_length],
        max_force=50000.0)

    # Visual mast — a thin box from cart top to pivot, fixed to cart in world.
    mast_h = p.pivot_offset[2] - p.cart_half[2]              # length above cart top
    mast_half = [0.022, 0.022, mast_h / 2.0]
    mast_pos0 = [p.cart_pos[0] + p.pivot_offset[0], 0.0,
                 p.cart_pos[2] + p.cart_half[2] + mast_h / 2.0]
    ren.add_box("mast", mast_half, p.mast_color)
    ren.set_static_pose("mast", mast_pos0)

    bodies = [("cart", cart_id), ("bob", bob_id), ("target", target_id)]
    steps_per_frame = STEP_RATE // BASE_FPS

    frames = []
    if metadata_only():
        save_sample(out_dir, asdict(p), _build_cot(p, build_cot, param_entry),
                    make_standalone_code(p), frames)
        phys.close(); ren.close(); return

    for _fi in range(N_FRAMES):
        for _ in range(steps_per_frame):
            phys.step()
        for nm, bid in bodies:
            pos, orn = phys.get_pose(bid)
            ren.set_pose(nm, pos, orn)
        cart_p, _ = phys.get_pose(cart_id)
        bob_p, _  = phys.get_pose(bob_id)
        # Mast follows cart (rigid attachment in cart's local frame).
        mast_world = [float(cart_p[0] + p.pivot_offset[0]), float(cart_p[1]),
                      float(cart_p[2] + p.cart_half[2] + mast_h / 2.0)]
        ren.set_pose("mast", mast_world, [0, 0, 0, 1])
        # Render the string as a thin cylinder from pivot to bob.
        pivot_world = [float(cart_p[0] + p.pivot_offset[0]),
                       float(cart_p[1] + p.pivot_offset[1]),
                       float(cart_p[2] + p.pivot_offset[2])]
        ren.update_string("string", pivot_world, list(map(float, bob_p)),
                          radius=0.012, color=[0.22, 0.14, 0.06, 1.0])
        frames.append(ren.render_frame())

    save_sample(out_dir, asdict(p), _build_cot(p, build_cot, param_entry),
                make_standalone_code(p), frames)
    phys.close(); ren.close()


def _build_cot(p: Params, build_cot, param_entry):
    L = p.pendulum_length
    # Bob hits the target's back face when bob centre x = target.x - target_half_x - bob_r
    target_back = p.target_pos[0] - p.target_half[0]
    bob_hit_x   = target_back - p.bob_radius
    dx          = bob_hit_x - p.bob_pos[0]
    sin_theta   = max(-1.0, min(1.0, dx / L))
    theta       = math.asin(sin_theta)
    z_hit       = p.bob_pos[2] + L - L * math.cos(theta)     # height risen on arc
    pivot_z     = p.cart_pos[2] + p.pivot_offset[2]
    bob_hit_z   = pivot_z - L * math.cos(theta)
    energy_init = 0.5 * p.bob_mass * p.bob_init_speed ** 2
    pe_at_hit   = p.bob_mass * G * (z_hit)
    v_at_hit    = math.sqrt(max(0.0, 2.0 * (energy_init - pe_at_hit) / p.bob_mass))
    e           = 0.30
    v_bob_after = (p.bob_mass * v_at_hit - e * p.target_mass * v_at_hit) / (p.bob_mass + p.target_mass)
    v_target_after = (1.0 + e) * p.bob_mass * v_at_hit / (p.bob_mass + p.target_mass)
    return build_cot(
        simulation="carried_pendulum_inertia",
        category="articulated_collision",
        seed=p.seed,
        physical_observation=(
            f"A cart (m={p.cart_mass:.2f} kg) on the floor carries a vertical mast.  "
            f"A bob (m={p.bob_mass:.2f} kg, r={p.bob_radius:.3f} m) hangs from a pivot at "
            f"the top of the mast on a string of length L={L:.2f} m.  The bob is given an "
            f"initial tangential speed v0={p.bob_init_speed:.2f} m/s and swings forward to "
            f"strike a free-standing block (m={p.target_mass:.2f} kg) on the floor in front "
            f"of the cart.  Predicted impact angle theta={math.degrees(theta):.1f} deg, "
            f"impact speed {v_at_hit:.2f} m/s, post-collision: bob {v_bob_after:.2f} m/s, "
            f"target {v_target_after:.2f} m/s."
        ),
        law_name="Pendulum dynamics on a movable support, plus collision impulse",
        law_statement=(
            "The bob is constrained to the moving pivot by an inextensible string "
            "(POINT2POINT distance constraint).  In the cart's frame, gravity drives "
            "the simple-pendulum motion; the cart mass is large compared to the bob, "
            "so the cart barely moves while the bob swings.  At impact, momentum is "
            "exchanged via a normal contact impulse on the target block."
        ),
        law_formula="\\ddot\\theta + (g/L)\\sin\\theta = 0; J_n = -(1+e)(v_rel.n)/m_eff",
        assumptions=[
            "Inextensible string modelled by JOINT_POINT2POINT (rigid distance constraint).",
            "Rigid bodies; Coulomb friction; no air drag.",
            "Cart and target rest on the floor; the bob does not collide with the cart "
            "because the pendulum's lowest point is above the cart top.",
            "Restitution coefficient e (0.3 here) sets the bob's rebound and target launch.",
            "PyBullet integrates contacts and constraints at 240 Hz.",
        ],
        state_variables=["cart pose", "bob pose", "target pose",
                         "all linear and angular velocities"],
        equations_latex=[
            "L = |\\mathbf r_{bob} - \\mathbf r_{pivot}|",
            "\\ddot\\theta + \\dfrac{g}{L}\\sin\\theta = 0",
            "v_{hit} = \\sqrt{v_0^2 - 2 g L (1-\\cos\\theta_{hit})}",
            "J_n = -(1+e)\\,(v_{rel}\\cdot\\hat{n})/m_{eff}",
        ],
        contact_impulse="j_n = -(1+e)(v_rel . n)/m_eff;  |j_t| <= mu |j_n|",
        derivation_steps=[
            f"Bob start: ({p.bob_pos[0]:.2f}, 0, {p.bob_pos[2]:.2f}); pivot at z={pivot_z:.2f}.",
            f"Target back face at x={target_back:.2f}; bob centre reaches it at angle "
            f"theta = arcsin(({bob_hit_x:.2f} - {p.bob_pos[0]:.2f})/L) = {math.degrees(theta):.1f} deg.",
            f"Energy conservation gives impact speed {v_at_hit:.2f} m/s "
            f"(KE0 = {energy_init:.2f} J, height risen {z_hit:.3f} m).",
            f"1D impulse model with e={e:.2f}: bob -> {v_bob_after:.2f} m/s, "
            f"target -> {v_target_after:.2f} m/s; PyBullet refines this with the actual "
            f"contact normal direction.",
        ],
        expected_behavior=[
            "String stays visibly taut between cart pivot and bob.",
            "Bob swings forward as a simple pendulum and strikes the target's back face at "
            f"z={bob_hit_z:.2f} m (well within the target's vertical extent).",
            "Target slides forward and slows under floor friction; bob recoils.",
            "Cart drifts only slightly because its mass is much larger than the bob's.",
        ],
        parameters={
            "cart_mass":         param_entry(p.cart_mass,         "kg",  "cart mass"),
            "bob_mass":          param_entry(p.bob_mass,          "kg",  "pendulum bob mass"),
            "bob_radius":        param_entry(p.bob_radius,        "m",   "bob radius"),
            "target_mass":       param_entry(p.target_mass,       "kg",  "target block mass"),
            "pendulum_length":   param_entry(p.pendulum_length,   "m",   "pendulum string length"),
            "pivot_height":      param_entry(pivot_z,             "m",   "world z of pivot"),
            "bob_init_speed":    param_entry(p.bob_init_speed,    "m/s", "initial tangential bob speed"),
            "predicted_impact":  param_entry(v_at_hit,            "m/s", "energy-conservation impact speed"),
            "predicted_target":  param_entry(v_target_after,      "m/s", "1D impulse-model target launch speed"),
            "target_friction":   param_entry(p.target_friction,   "",    "target-floor Coulomb friction"),
        })


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    mast_h = p.pivot_offset[2] - p.cart_half[2]
    mast_half = [0.022, 0.022, mast_h / 2.0]
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# carried_pendulum_inertia  seed={p.seed}
import pybullet as pb
N_FRAMES = {N_FRAMES}; CAM_EYE = {CAM_EYE}; CAM_TARGET = {CAM_TARGET}

CART_HALF = {p.cart_half}; CART_POS = {p.cart_pos}; CART_MASS = {p.cart_mass}
CART_VEL  = [{p.cart_init_speed}, 0.0, 0.0]
PIVOT_OFF = {p.pivot_offset}
PEND_L    = {p.pendulum_length}
BOB_RADIUS = {p.bob_radius}; BOB_MASS = {p.bob_mass}
BOB_POS   = {p.bob_pos}; BOB_VEL = [{p.bob_init_speed}, 0.0, 0.0]
TARGET_HALF = {p.target_half}; TARGET_POS = {p.target_pos}
TARGET_MASS = {p.target_mass}; TARGET_FRICTION = {p.target_friction}
CART_COLOR = {p.cart_color}; BOB_COLOR = {p.bob_color}
TARGET_COLOR = {p.target_color}; MAST_COLOR = {p.mast_color}
MAST_HALF = {mast_half}

def main():
    c = _init_physics(); ren, sc = _make_renderer(CAM_EYE, CAM_TARGET); nodes = {{}}
    pb.loadURDF("plane.urdf", [0, 0, 0], physicsClientId=c)
    _add_box(sc, "floor", nodes, [2.75, 2.75, 0.02], [0.42, 0.42, 0.45, 1.0])
    _set_pose(sc, nodes["floor"], [0, 0, -0.02], [0, 0, 0, 1])

    csh = pb.createCollisionShape(pb.GEOM_BOX, halfExtents=CART_HALF, physicsClientId=c)
    cart = pb.createMultiBody(CART_MASS, csh, -1, CART_POS, [0,0,0,1], physicsClientId=c)
    pb.changeDynamics(cart, -1, lateralFriction=0.7, restitution=0.20,
                       linearDamping=0.05, angularDamping=0.2, physicsClientId=c)
    pb.resetBaseVelocity(cart, CART_VEL, [0,0,0], physicsClientId=c)
    _add_box(sc, "cart", nodes, CART_HALF, CART_COLOR)
    _set_pose(sc, nodes["cart"], CART_POS, [0,0,0,1])

    ssh = pb.createCollisionShape(pb.GEOM_SPHERE, radius=BOB_RADIUS, physicsClientId=c)
    bob = pb.createMultiBody(BOB_MASS, ssh, -1, BOB_POS, [0,0,0,1], physicsClientId=c)
    pb.changeDynamics(bob, -1, lateralFriction=0.10, restitution=0.55,
                       linearDamping=0.0, angularDamping=0.05, physicsClientId=c)
    pb.resetBaseVelocity(bob, BOB_VEL, [0,0,0], physicsClientId=c)
    _add_sphere(sc, "bob", nodes, BOB_RADIUS, BOB_COLOR)
    _set_pose(sc, nodes["bob"], BOB_POS, [0,0,0,1])

    tsh = pb.createCollisionShape(pb.GEOM_BOX, halfExtents=TARGET_HALF, physicsClientId=c)
    tgt = pb.createMultiBody(TARGET_MASS, tsh, -1, TARGET_POS, [0,0,0,1], physicsClientId=c)
    pb.changeDynamics(tgt, -1, lateralFriction=TARGET_FRICTION, restitution=0.30,
                       linearDamping=0.05, angularDamping=0.3, physicsClientId=c)
    _add_box(sc, "target", nodes, TARGET_HALF, TARGET_COLOR)
    _set_pose(sc, nodes["target"], TARGET_POS, [0,0,0,1])

    cid = pb.createConstraint(cart, -1, bob, -1, pb.JOINT_POINT2POINT, [0,0,0],
                               PIVOT_OFF, [0.0, 0.0, PEND_L], physicsClientId=c)
    pb.changeConstraint(cid, maxForce=50000.0, physicsClientId=c)

    _add_box(sc, "mast", nodes, MAST_HALF, MAST_COLOR)
    mast_z = CART_POS[2] + CART_HALF[2] + MAST_HALF[2]
    _set_pose(sc, nodes["mast"], [CART_POS[0]+PIVOT_OFF[0], 0.0, mast_z], [0,0,0,1])

    bodies = [("cart", cart), ("bob", bob), ("target", tgt)]
    frames = []
    for _ in range(N_FRAMES):
        for __ in range(8):
            pb.stepSimulation(physicsClientId=c)
        for nm, bid in bodies:
            pp, oo = pb.getBasePositionAndOrientation(bid, physicsClientId=c)
            _set_pose(sc, nodes[nm], pp, oo)
        cp, _ = pb.getBasePositionAndOrientation(cart, physicsClientId=c)
        bp, _ = pb.getBasePositionAndOrientation(bob, physicsClientId=c)
        _set_pose(sc, nodes["mast"], [cp[0]+PIVOT_OFF[0], cp[1], cp[2]+CART_HALF[2]+MAST_HALF[2]],
                   [0,0,0,1])
        pivot_world = [cp[0]+PIVOT_OFF[0], cp[1]+PIVOT_OFF[1], cp[2]+PIVOT_OFF[2]]
        _update_string(sc, nodes, "string", pivot_world, list(bp), 0.012, [0.22,0.14,0.06,1.0])
        rgba, _ = ren.render(sc, flags=pyrender.RenderFlags.RGBA)
        frames.append(rgba[:,:,:3])
    _save_video(frames, "video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")

if __name__ == "__main__":
    main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_carried_pendulum_inertia")
    print("OK")
