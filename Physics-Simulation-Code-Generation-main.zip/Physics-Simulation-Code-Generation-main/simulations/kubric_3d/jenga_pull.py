"""jenga_pull — block pulled from Jenga tower."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np
CAM_EYE=(4.5,-4.5,2.0); CAM_TARGET=(0.0,0.0,1.1); N_FRAMES=150
@dataclass
class Params:
    seed: int
    n_layers:int
    pull_layer:int
    pull_speed:float
    block_mass:float
    friction:float
    restitution:float
    color_a:List[float]
    color_b:List[float]
def random_params(seed):
    random.seed(seed); np.random.seed(seed)
    nl=random.randint(14,22)
    # Pull from lower half: layers 1-3 (0-indexed), ensuring tower destabilizes
    return Params(seed=seed,n_layers=nl,pull_layer=random.randint(1,3),
        pull_speed=random.uniform(3.5,5.0),block_mass=random.uniform(0.08,0.30),
        friction=random.uniform(0.35,0.70),restitution=random.uniform(0.05,0.30),
        color_a=[random.uniform(0.6,0.9),random.uniform(0.5,0.8),random.uniform(0.3,0.6),1.0],
        color_b=[random.uniform(0.3,0.6),random.uniform(0.4,0.7),random.uniform(0.6,0.9),1.0])
def generate_sample(seed, out_dir):
    _dir=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0,_dir)
    from simulations.kubric_3d._base import (Physics,Renderer,run_loop,save_sample,
        build_cot,param_entry,muted_grey,random_hue_color,STANDALONE_IMPORTS,STANDALONE_UTILS)
    import pybullet as pb
    random.seed(seed); np.random.seed(seed)
    p=random_params(seed)
    phys=Physics(); ren=Renderer(CAM_EYE,CAM_TARGET)
    _dyn=[]; _extra_sync=None
    p=random_params(seed)
    phys.add_plane(friction=p.friction); ren.add_plane_mesh("fl",5.0,muted_grey())
    bw,bd,bl=0.0265,0.0795,0.254; all_bids=[]
    for layer in range(p.n_layers):
        z=bw+layer*bw*2; col=p.color_a if layer%2==0 else p.color_b
        if layer%2==0:
            for j in range(3):
                x=(j-1)*bd*1.05
                bid=phys.add_box([bd/2,bl/2,bw],[x,0,z],mass=p.block_mass,friction=p.friction,restitution=p.restitution)
                nm=f"b{layer}_{j}"; ren.add_box(nm,[bd/2,bl/2,bw],col); all_bids.append((nm,bid,layer,j))
        else:
            for j in range(3):
                y=(j-1)*bd*1.05
                bid=phys.add_box([bl/2,bd/2,bw],[0,y,z],mass=p.block_mass,friction=p.friction,restitution=p.restitution)
                nm=f"b{layer}_{j}"; ren.add_box(nm,[bl/2,bd/2,bw],col); all_bids.append((nm,bid,layer,j))
    for _ in range(30): phys.step()
    # Find and extract the center block from the pull layer
    pull_bid = None
    pull_vx = 0; pull_vy = 0
    for nm,bid,layer,j in all_bids:
        if layer==p.pull_layer and j==1:
            pull_bid = bid
            pull_vx = p.pull_speed if layer%2==0 else 0
            pull_vy = 0 if layer%2==0 else p.pull_speed
            pb.resetBaseVelocity(bid,[pull_vx,pull_vy,0],[0,0,0],physicsClientId=phys.client)
    for nm,bid,layer,j in all_bids: _dyn.append((nm,bid))

    # Apply velocity continuously for first 20 frames so block pulls far enough out
    def _apply_pull(phys_obj, ren_obj, fi):
        if pull_bid is not None and fi < 20:
            pb.resetBaseVelocity(pull_bid,[pull_vx,pull_vy,0],[0,0,0],
                                 physicsClientId=phys_obj.client)
    _extra_sync = _apply_pull
    frames=run_loop(phys,ren,_dyn,N_FRAMES,extra_sync_fn=_extra_sync)
    cot=build_cot("jenga_pull","rigid_body",seed,
        f"Jenga {p.n_layers} layers mu={p.friction:.2f}; pull layer {p.pull_layer} at {p.pull_speed:.2f} m/s.",
        "Static friction limit","Extraction safe if F_pull < mu*N_above",r"F_{pull} < \mu N_{above}",
        ["Rigid Jenga blocks","Coulomb friction","No elastic deformation"],
        ["r (m)","v (m/s)","q","w (rad/s)"],
        ["dot_r=v","m*dot_v=mg+Fc","I*dot_w=tc-wxIw"],
        "j=-(1+e)*v_n/(1/mA+1/mB+cross)",
        [f"Weight above: n*{p.block_mass:.2f}*9.81 N","Max friction: mu*W_above","Tower stable if friction sufficient"],[f"Block at layer {p.pull_layer} extracted","Tower may or may not topple",f"mu={p.friction:.2f} determines stability"],
        {k:param_entry(getattr(p,k),"",k) for k in ["n_layers","pull_layer","pull_speed","block_mass","friction","restitution"]})
    save_sample(out_dir,asdict(p),cot,make_standalone_code(p),frames)
    phys.close(); ren.close()
def make_standalone_code(p):
    _dir=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0,_dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS,STANDALONE_UTILS
    body=f"""
# jenga_pull  seed={p.seed}
import pybullet as pb
N_FRAMES=150; CAM_EYE=(4.5,-4.5,2.0); CAM_TARGET=(0.0,0.0,1.1)
def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    bw,bd,bl=0.0265,0.0795,0.254; all_bids=[]
    for ly in range({p.n_layers}):
        z=bw+ly*bw*2; col={p.color_a} if ly%2==0 else {p.color_b}
        if ly%2==0:
            for j in range(3):
                x=(j-1)*bd*1.05
                s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[bd/2,bl/2,bw],physicsClientId=c)
                bid=pb.createMultiBody({p.block_mass},s,-1,[x,0,z],[0,0,0,1],physicsClientId=c)
                pb.changeDynamics(bid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
                nm=f"b_{{ly}}_{{j}}"; _add_box(sc,nm,nodes,[bd/2,bl/2,bw],col); all_bids.append((nm,bid,ly,j))
        else:
            for j in range(3):
                y=(j-1)*bd*1.05
                s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[bl/2,bd/2,bw],physicsClientId=c)
                bid=pb.createMultiBody({p.block_mass},s,-1,[0,y,z],[0,0,0,1],physicsClientId=c)
                pb.changeDynamics(bid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
                nm=f"b_{{ly}}_{{j}}"; _add_box(sc,nm,nodes,[bl/2,bd/2,bw],col); all_bids.append((nm,bid,ly,j))
    _add_box(sc,"fl",nodes,[2.5,2.5,0.02],muted_grey()); _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    for _ in range(30): pb.stepSimulation(physicsClientId=c)
    for nm,bid,ly,j in all_bids:
        if ly=={p.pull_layer} and j==1:
            vx={p.pull_speed} if ly%2==0 else 0; vy=0 if ly%2==0 else {p.pull_speed}
            pb.resetBaseVelocity(bid,[vx,vy,0],[0,0,0],physicsClientId=c)
    frames=[]
    for _ in range(150):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid,ly,j in all_bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""
    return STANDALONE_IMPORTS+STANDALONE_UTILS+body
if __name__=="__main__":
    generate_sample(seed=0,out_dir=f"/tmp/test_jenga_pull"); print("OK")
