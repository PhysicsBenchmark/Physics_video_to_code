"""funnel_sorting — two sizes of spheres; small ones pass, large ones caught."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np
try:
    import trimesh
    import pyrender
except ImportError:
    trimesh = None
    pyrender = None
CAM_EYE=(4.0,-4.0,3.5); CAM_TARGET=(0.0,0.0,1.2); N_FRAMES=80
@dataclass
class Params:
    seed: int
    n_small:int
    n_large:int
    r_small:float
    r_large:float
    neck_r:float
    mass_small:float
    mass_large:float
    friction:float
    restitution:float
def random_params(seed):
    random.seed(seed); np.random.seed(seed)
    rs=random.uniform(0.045,0.075); rl=random.uniform(0.10,0.17)
    neck=random.uniform(rs*1.15,rs*1.60)
    return Params(seed=seed,n_small=random.randint(4,8),n_large=random.randint(3,6),
        r_small=rs,r_large=rl,neck_r=neck,
        mass_small=random.uniform(0.02,0.08),mass_large=random.uniform(0.10,0.40),
        friction=random.uniform(0.25,0.55),restitution=random.uniform(0.25,0.60))
def _build_funnel_walls(phys, ren, neck_r, funnel_color, friction, restitution):
    """8 tilted static boxes arranged in a ring, angled inward ~45 deg to form a conical funnel."""
    import pybullet as pb
    n_panels = 8
    top_r = neck_r + 0.55       # funnel mouth radius
    panel_z_center = 1.80       # center height of the funnel panels
    panel_half_h = 0.42         # half-height of each panel (tall enough to guide balls)
    panel_half_w = 0.28         # half-width of each panel along the ring
    panel_half_t = 0.025        # half-thickness of each panel
    tilt_angle = math.radians(42)  # tilt inward from vertical

    ring_r = (top_r + neck_r) / 2.0  # place panel centers at mid-radius

    for i in range(n_panels):
        angle = 2 * math.pi * i / n_panels
        # Radial outward direction
        nx = math.cos(angle); ny = math.sin(angle)
        # Panel center position (at mid-radius, mid-height)
        px = ring_r * nx; py = ring_r * ny; pz = panel_z_center

        # Orientation: rotate about tangential axis to tilt inward at tilt_angle
        # Tangential axis (perpendicular to radial in XY plane)
        tx = -math.sin(angle); ty = math.cos(angle)

        # Build rotation: first rotate panel so its face is radially outward (yaw),
        # then tilt it inward (pitch around tangential axis)
        # Use PyBullet Euler: yaw = angle, then pitch inward
        # The panel is a box with half-ext [panel_half_t, panel_half_w, panel_half_h]
        # We want Z-axis of panel = radial+inward tilt direction
        # Compose: yaw around Z by angle, then pitch around local Y by tilt_angle
        import pybullet as _pb
        # Rotation: yaw so panel faces radially, then tilt inward from vertical
        orn = _pb.getQuaternionFromEuler([0, tilt_angle, angle])
        he = [panel_half_t, panel_half_w, panel_half_h]
        phys.add_box(he, [px, py, pz], orn=orn, mass=0,
                     friction=friction, restitution=restitution)
        wname = f"fw{i}"
        ren.add_box(wname, he, funnel_color)
        ren.set_static_pose(wname, [px, py, pz], orn)

def generate_sample(seed, out_dir):
    _dir=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0,_dir)
    from simulations.kubric_3d._base import (Physics,Renderer,run_loop,save_sample,
        build_cot,param_entry,muted_grey,random_hue_color,STANDALONE_IMPORTS,STANDALONE_UTILS)
    import pybullet as pb
    import trimesh
    random.seed(seed); np.random.seed(seed)
    p=random_params(seed)
    phys=Physics(); ren=Renderer(CAM_EYE,CAM_TARGET)
    _dyn=[]; _extra_sync=None
    p=random_params(seed)
    phys.add_plane(friction=p.friction); ren.add_plane_mesh("fl",6.0,muted_grey())
    nr=p.neck_r
    funnel_color = [0.5, 0.5, 0.55, 1.0]

    # --- Conical funnel visual using trimesh frustum (truncated cone) ---
    top_radius = nr + 0.55    # wide mouth
    bot_radius = nr           # narrow neck
    funnel_height = 0.90
    funnel_z_base = 1.40      # bottom of funnel cone
    # Build a frustum by creating a cylinder with two sections of different radii
    # Use trimesh cone (apex up) and flip: create via revolution of a trapezoid
    # Approach: use trimesh.creation.cone for top cap + open cylinder approx
    # Best approach: create a truncated cone mesh manually via trimesh
    n_sides = 32
    angles = np.linspace(0, 2*np.pi, n_sides, endpoint=False)
    # Bottom ring (small radius = neck)
    bot_pts = np.stack([bot_radius*np.cos(angles), bot_radius*np.sin(angles),
                        np.zeros(n_sides)], axis=1)
    # Top ring (large radius = mouth)
    top_pts = np.stack([top_radius*np.cos(angles), top_radius*np.sin(angles),
                        np.full(n_sides, funnel_height)], axis=1)
    verts = np.vstack([bot_pts, top_pts])  # shape (2*n_sides, 3)
    faces = []
    for i in range(n_sides):
        j = (i + 1) % n_sides
        # Side quad split into two triangles
        faces.append([i, j, n_sides + i])
        faces.append([j, n_sides + j, n_sides + i])
    funnel_mesh = trimesh.Trimesh(vertices=verts, faces=np.array(faces), process=False)
    # Position: bottom of frustum at funnel_z_base
    funnel_mat = pyrender.MetallicRoughnessMaterial(
        baseColorFactor=[0.55, 0.55, 0.65, 1.0],
        metallicFactor=0.1, roughnessFactor=0.4)
    funnel_pm = pyrender.Mesh.from_trimesh(funnel_mesh, material=funnel_mat, smooth=True)
    funnel_pose = np.eye(4)
    funnel_pose[2, 3] = funnel_z_base
    funnel_node = ren.scene.add(funnel_pm, pose=funnel_pose)

    # --- Physics funnel walls: 8 tilted boxes ---
    _build_funnel_walls(phys, ren, nr, funnel_color, p.friction, p.restitution)
    # Balls dropped from above, spread within funnel mouth
    drop_z_base = 2.55   # above funnel mouth at z=1.40+0.90=2.30
    spread = nr * 0.5     # spread within funnel mouth (inside top_radius)
    for i in range(p.n_small):
        angle = 2 * math.pi * i / max(p.n_small, 1)
        x = spread * math.cos(angle) * 0.6
        y = spread * math.sin(angle) * 0.6
        bid=phys.add_sphere(p.r_small,[x,y,drop_z_base+i*p.r_small*1.5],mass=p.mass_small,
                            friction=p.friction,restitution=p.restitution)
        ren.add_sphere(f"sm{i}",p.r_small,[0.2,0.85,0.3,1.0]); _dyn.append((f"sm{i}",bid))
    for i in range(p.n_large):
        angle = 2 * math.pi * i / max(p.n_large, 1) + math.pi / p.n_large
        x = spread * math.cos(angle) * 0.5
        y = spread * math.sin(angle) * 0.5
        bid=phys.add_sphere(p.r_large,[x,y,drop_z_base+0.4+i*p.r_large*1.5],mass=p.mass_large,
                            friction=p.friction,restitution=p.restitution)
        ren.add_sphere(f"lg{i}",p.r_large,[0.85,0.2,0.2,1.0]); _dyn.append((f"lg{i}",bid))
    frames=run_loop(phys,ren,_dyn,N_FRAMES,extra_sync_fn=_extra_sync)
    cot=build_cot("funnel_sorting","rigid_body",seed,
        f"{p.n_small} small (r={p.r_small:.3f}m) + {p.n_large} large (r={p.r_large:.3f}m); neck r={p.neck_r:.3f}m.",
        "Geometric size sorting","Pass iff r_ball < r_neck",r"\text{pass} \iff r_{ball} < r_{neck}",
        ["Rigid spheres","Funnel walls are rigid","No horizontal velocity at entry"],
        ["r (m)","v (m/s)","q","w (rad/s)"],
        ["dot_r=v","m*dot_v=mg+Fc","I*dot_w=tc-wxIw"],
        "j=-(1+e)*v_n/(1/mA+1/mB+cross)",
        [f"Small: r={p.r_small:.3f}m < neck_r={p.neck_r:.3f}m -> pass",f"Large: r={p.r_large:.3f}m > neck_r={p.neck_r:.3f}m -> blocked","Sorting by geometry alone"],[f"All {p.n_small} small balls (green) pass through",f"All {p.n_large} large balls (red) blocked","Clear visual separation"],
        {k:param_entry(getattr(p,k),"",k) for k in ["n_small","n_large","r_small","r_large","neck_r","mass_small","mass_large"]})
    save_sample(out_dir,asdict(p),cot,make_standalone_code(p),frames)
    phys.close(); ren.close()
def make_standalone_code(p):
    _dir=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0,_dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS,STANDALONE_UTILS
    top_radius = p.neck_r + 0.55
    body=f"""
# funnel_sorting  seed={p.seed}
import pybullet as pb
N_FRAMES=150; CAM_EYE=(4.0,-4.0,3.5); CAM_TARGET=(0.0,0.0,1.2)
def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    nr={p.neck_r}
    wall_specs=[([0.80,0.04,0.70],[-nr-0.40,0,1.80],"fwL"),
                ([0.80,0.04,0.70],[nr+0.40,0,1.80],"fwR"),
                ([0.04,0.80,0.70],[0,-nr-0.40,1.80],"fwB"),
                ([0.04,0.80,0.70],[0,nr+0.40,1.80],"fwF")]
    for he,pos,nm in wall_specs:
        s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=he,physicsClientId=c)
        pb.createMultiBody(0,s,-1,pos,[0,0,0,1],physicsClientId=c)
        _add_box(sc,nm,nodes,he,[0.55,0.55,0.65,0.92]); _set_pose(sc,nodes[nm],pos,[0,0,0,1])
    _add_cylinder(sc,"neck_ring",nodes,nr,0.04,[0.95,0.85,0.20,1.0])
    _set_pose(sc,nodes["neck_ring"],[0,0,1.42],pb.getQuaternionFromEuler([1.5708,0,0]))
    bids=[]
    for i in range({p.n_small}):
        x=(i%3-1)*{p.r_small}*1.0; y=(i//3)*{p.r_small}*1.0
        s=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.r_small},physicsClientId=c)
        bid=pb.createMultiBody({p.mass_small},s,-1,[x,y,2.15+i*{p.r_small}*0.22],[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
        pb.resetBaseVelocity(bid,[0,0,-0.7],[0,0,0],physicsClientId=c)
        _add_sphere(sc,f"sm{{i}}",nodes,{p.r_small},[0.2,0.85,0.3,1.0]); bids.append((f"sm{{i}}",bid))
    for i in range({p.n_large}):
        x=(i%2-0.5)*{p.r_large}*1.4
        s=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.r_large},physicsClientId=c)
        bid=pb.createMultiBody({p.mass_large},s,-1,[x,-0.25,2.35+i*{p.r_large}*0.25],[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
        pb.resetBaseVelocity(bid,[0,0,-0.35],[0,0,0],physicsClientId=c)
        _add_sphere(sc,f"lg{{i}}",nodes,{p.r_large},[0.85,0.2,0.2,1.0]); bids.append((f"lg{{i}}",bid))
    _add_box(sc,"fl",nodes,[3,3,0.02],muted_grey()); _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    frames=[]
    for _ in range(150):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""
    return STANDALONE_IMPORTS+STANDALONE_UTILS+body
if __name__=="__main__":
    generate_sample(seed=0,out_dir=f"/tmp/test_funnel_sorting"); print("OK")
