"""tumbling_dice — multiple dice thrown onto a surface with random angular velocities."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (4, -3, 4)
CAM_TARGET = (0, 0, 0.5)
N_FRAMES   = 120


@dataclass
class Params:
    seed: int
    n_dice: int
    die_half: float
    die_mass: float
    initial_height: float
    initial_ang_vel_scale: float
    restitution: float
    friction: float
    colors: List[List[float]]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    n = random.randint(3, 8)
    colors = []
    for _ in range(n):
        h = random.random()
        s, v = 0.85, 0.90
        hi = int(h * 6) % 6
        f  = h * 6 - int(h * 6)
        p_ = v * (1 - s); q = v * (1 - f*s); t = v * (1-(1-f)*s)
        r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
        colors.append([r, g, b, 1.0])
    return Params(
        seed=seed,
        n_dice=n,
        die_half=random.uniform(0.06, 0.12),
        die_mass=random.uniform(0.02, 0.08),
        initial_height=random.uniform(0.5, 2.0),
        initial_ang_vel_scale=random.uniform(5.0, 20.0),
        restitution=random.uniform(0.3, 0.7),
        friction=random.uniform(0.4, 0.8),
        colors=colors,
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.friction)
    ren.add_plane_mesh("floor", 8.0, [0.42, 0.42, 0.45, 1.0])

    dyn = []
    half = [p.die_half, p.die_half, p.die_half]
    spread = 1.5
    for i in range(p.n_dice):
        # random position in a spread
        dx = random.uniform(-spread, spread)
        dy = random.uniform(-spread, spread)
        dz = p.initial_height + random.uniform(0.0, 0.5)
        pos = [dx, dy, dz]

        # random orientation (as euler angles)
        ea = [random.uniform(0, math.pi*2),
              random.uniform(0, math.pi*2),
              random.uniform(0, math.pi*2)]
        orn = pb_mod.getQuaternionFromEuler(ea)

        # random angular velocity
        ang_vel = [
            random.uniform(-1, 1) * p.initial_ang_vel_scale,
            random.uniform(-1, 1) * p.initial_ang_vel_scale,
            random.uniform(-1, 1) * p.initial_ang_vel_scale,
        ]
        # small linear velocity to spread them
        lin_vel = [random.uniform(-0.5, 0.5), random.uniform(-0.5, 0.5), 0.0]

        bid = phys.add_box(
            half, pos, orn=orn,
            mass=p.die_mass,
            friction=p.friction,
            restitution=p.restitution,
            vel=lin_vel, ang_vel=ang_vel)

        name = f"die{i}"
        ren.add_box(name, half, p.colors[i])
        ren.set_static_pose(name, pos, orn)
        dyn.append((name, bid))

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="tumbling_dice",
        category="rigid_body_free_dynamics",
        seed=seed,
        physical_observation=(
            f"{p.n_dice} dice (half={p.die_half:.3f}m, m={p.die_mass:.3f}kg) "
            f"thrown from h={p.initial_height:.2f}m with angular velocity "
            f"scale={p.initial_ang_vel_scale:.1f} rad/s."
        ),
        law_name="Newton-Euler rigid body dynamics",
        law_statement=(
            "Free rigid bodies obey Newton's second law for translation and "
            "Euler's rotation equations; contacts resolved by impulse-based LCP solver."
        ),
        law_formula="m·a = F_gravity + F_contact; I·α = τ - ω × (I·ω)",
        assumptions=[
            "Each die is a uniform cube (Ixx = Iyy = Izz = m*a^2/6)",
            "Coulomb friction model",
            "Inelastic collisions with floor and between dice",
            "No aerodynamic drag",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg+F_c",
            "I\\dot{\\omega}=\\tau_c-\\omega\\times I\\omega",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            "Dice launched with random angular velocities; gravity decelerates z-component",
            "On impact with floor, normal impulse j = -(1+e)·v_n / (1/m + 1/M_floor)",
            "Tangential impulse bounded by μ·j_n (Coulomb friction)",
            "Angular velocity couples to linear via contact radius vector",
            f"Rotational KE ~ (1/2)·I·ω² with I={p.die_mass*p.die_half**2/6:.5f} kg·m² per axis",
        ],
        expected_behavior=[
            "Dice fall and bounce on floor",
            "Each die tumbles differently due to random angular velocity",
            "Dice may collide with each other",
            "Eventually all dice settle with random face up",
        ],
        parameters={
            "n_dice":               param_entry(p.n_dice,               "",   "number of dice"),
            "die_half":             param_entry(p.die_half,             "m",  "half-extent of each die"),
            "die_mass":             param_entry(p.die_mass,             "kg", "mass of each die"),
            "initial_height":       param_entry(p.initial_height,       "m",  "initial drop height"),
            "initial_ang_vel_scale":param_entry(p.initial_ang_vel_scale,"rad/s","angular velocity magnitude scale"),
            "restitution":          param_entry(p.restitution,          "",   "coefficient of restitution"),
            "friction":             param_entry(p.friction,             "",   "lateral friction coefficient"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    random.seed(p.seed); np.random.seed(p.seed)
    half = [p.die_half, p.die_half, p.die_half]
    spread = 1.5
    die_lines = []
    for i in range(p.n_dice):
        dx = random.uniform(-spread, spread)
        dy = random.uniform(-spread, spread)
        dz = p.initial_height + random.uniform(0.0, 0.5)
        ea = [random.uniform(0, math.pi*2),
              random.uniform(0, math.pi*2),
              random.uniform(0, math.pi*2)]
        import pybullet as _pb
        orn = _pb.getQuaternionFromEuler(ea)
        ang_vel = [
            random.uniform(-1, 1) * p.initial_ang_vel_scale,
            random.uniform(-1, 1) * p.initial_ang_vel_scale,
            random.uniform(-1, 1) * p.initial_ang_vel_scale,
        ]
        lin_vel = [random.uniform(-0.5, 0.5), random.uniform(-0.5, 0.5), 0.0]
        die_lines.append(
            f"    s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents={half},physicsClientId=c)\n"
            f"    bid=pb.createMultiBody({p.die_mass},s,-1,[{dx:.3f},{dy:.3f},{dz:.3f}],{list(orn)},physicsClientId=c)\n"
            f"    pb.changeDynamics(bid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)\n"
            f"    pb.resetBaseVelocity(bid,{lin_vel},{ang_vel},physicsClientId=c)\n"
            f"    _add_box(sc,'die{i}',nodes,{half},{p.colors[i]})\n"
            f"    _set_pose(sc,nodes['die{i}'],[{dx:.3f},{dy:.3f},{dz:.3f}],{list(orn)})\n"
            f"    bids.append(('die{i}',bid))\n"
        )
    die_code = "".join(die_lines)
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# tumbling_dice  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[4.0,4.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    bids=[]
{die_code}
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_tumbling_dice")
    print("OK")
