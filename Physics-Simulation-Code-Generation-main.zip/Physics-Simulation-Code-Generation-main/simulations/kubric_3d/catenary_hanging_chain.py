"""catenary_hanging_chain — chain fixed at both ends hangs in catenary curve."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (6, -4, 3)
CAM_TARGET = (0, 0, 1)
N_FRAMES   = 150


@dataclass
class Params:
    seed:          int
    n_links:       int
    link_radius:   float
    link_half_len: float
    mass_per_link: float
    span:          float    # distance between the two fixed endpoints (m)
    hang_height:   float    # height of both fixed endpoints (m)
    floor_friction: float
    chain_color:   List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        n_links=random.randint(12, 20),
        link_radius=random.uniform(0.02, 0.035),
        link_half_len=random.uniform(0.04, 0.07),
        mass_per_link=random.uniform(0.04, 0.10),
        span=random.uniform(2.0, 3.5),
        hang_height=random.uniform(2.0, 3.0),
        floor_friction=random.uniform(0.4, 0.7),
        chain_color=[random.uniform(0.5, 0.85), random.uniform(0.4, 0.75),
                     random.uniform(0.2, 0.6), 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 12.0, [0.42, 0.42, 0.45, 1.0])
    ren.set_static_pose("floor", [0, 0, 0])

    # Place chain horizontally from (-span/2, 0, hang_height) to (span/2, 0, hang_height)
    left_pivot  = [-p.span / 2, 0.0, p.hang_height]
    right_pivot = [ p.span / 2, 0.0, p.hang_height]

    # Distribute n_links evenly along x from left to right at hang_height
    chain_ids: List[int] = []
    segment = p.link_half_len * 2 + p.link_radius * 0.5
    for i in range(p.n_links):
        t   = i / max(p.n_links - 1, 1)
        x   = -p.span / 2 + t * p.span
        pos = [x, 0.0, p.hang_height]
        bid = phys.add_capsule(
            p.link_radius, p.link_half_len * 2, pos,
            orn=(0, 0, 0, 1),
            mass=p.mass_per_link,
            friction=0.4, restitution=0.3,
            lin_damp=0.05, ang_damp=0.1)
        if chain_ids:
            off = p.link_half_len + p.link_radius * 0.25
            phys.create_constraint(
                chain_ids[-1], -1, bid, -1,
                pb_mod.JOINT_POINT2POINT, [0, 0, 1],
                [0, 0, -off], [0, 0, off],
                max_force=300.0)
        chain_ids.append(bid)

    # Fix first link to left pivot
    pb_mod.createConstraint(
        chain_ids[0], -1, -1, -1,
        pb_mod.JOINT_FIXED, [0, 0, 0],
        [0, 0, 0], list(left_pivot),
        physicsClientId=phys.client)

    # Fix last link to right pivot
    pb_mod.createConstraint(
        chain_ids[-1], -1, -1, -1,
        pb_mod.JOINT_FIXED, [0, 0, 0],
        [0, 0, 0], list(right_pivot),
        physicsClientId=phys.client)

    # Render chain links
    for i in range(p.n_links):
        ren.add_capsule(f"link{i}", p.link_radius, p.link_half_len * 2, p.chain_color)

    # Render anchor spheres at endpoints
    ren.add_sphere("pivot_l", 0.06, [0.9, 0.85, 0.1, 1.0])
    ren.add_sphere("pivot_r", 0.06, [0.9, 0.85, 0.1, 1.0])
    ren.set_static_pose("pivot_l", left_pivot)
    ren.set_static_pose("pivot_r", right_pivot)

    dyn = [(f"link{i}", bid) for i, bid in enumerate(chain_ids)]
    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="catenary_hanging_chain",
        category="rope_chain",
        seed=seed,
        physical_observation=(
            f"Chain of {p.n_links} links (r={p.link_radius:.3f}m, "
            f"half-len={p.link_half_len:.3f}m) fixed at both ends "
            f"(span={p.span:.2f}m, height={p.hang_height:.2f}m). "
            f"Chain hangs under gravity forming catenary."),
        law_name="Catenary curve — hanging flexible chain",
        law_statement=(
            "A uniform flexible chain fixed at both ends hangs in a catenary "
            "y = a*cosh(x/a), where a = T_0/(rho*g)."),
        law_formula=r"y = a\cosh(x/a),\quad a = T_0/(\rho g)",
        assumptions=[
            "Chain is uniform (constant mass per unit length).",
            "Links are rigid capsules with flexible point-to-point joints.",
            "No air resistance; floor provides boundary.",
        ],
        state_variables=["r_i (m)", "v_i (m/s)", "q_i", "omega_i (rad/s)"],
        equations_latex=[
            r"\dot{r}_i = v_i",
            r"m_i\dot{v}_i = m_ig + T_i - T_{i-1}",
        ],
        contact_impulse="j = -(1+e)*v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            f"Chain starts horizontal at height {p.hang_height:.2f}m.",
            "Gravity pulls middle links down; tension builds in chain.",
            "System settles into catenary equilibrium.",
            f"Total chain length > span {p.span:.2f}m ensures sag.",
        ],
        expected_behavior=[
            "Chain sags downward from horizontal starting position.",
            "Middle of chain hangs lowest.",
            "System oscillates then settles into catenary shape.",
        ],
        parameters={
            "n_links":          param_entry(p.n_links, "", "Number of chain links"),
            "link_radius_m":    param_entry(p.link_radius, "m", "Link radius"),
            "link_half_len_m":  param_entry(p.link_half_len, "m", "Link half-length"),
            "mass_per_link_kg": param_entry(p.mass_per_link, "kg", "Mass per link"),
            "span_m":           param_entry(p.span, "m", "Horizontal span between endpoints"),
            "hang_height_m":    param_entry(p.hang_height, "m", "Height of fixed endpoints"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    off = p.link_half_len + p.link_radius * 0.25
    left_pivot  = [-p.span / 2, 0.0, p.hang_height]
    right_pivot = [ p.span / 2, 0.0, p.hang_height]
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# catenary_hanging_chain  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[6.0,6.0,0.02],[0.42,0.42,0.45,1.0]); _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    left_pivot={list(left_pivot)}; right_pivot={list(right_pivot)}
    lr={p.link_radius}; lhl={p.link_half_len}; off_={off}
    chain_ids=[]
    cap_shape=pb.createCollisionShape(pb.GEOM_CAPSULE,radius=lr,height=lhl*2,physicsClientId=c)
    for i in range({p.n_links}):
        t=i/max({p.n_links}-1,1); x=-{p.span}/2+t*{p.span}
        pos=[x,0.0,{p.hang_height}]
        bid=pb.createMultiBody({p.mass_per_link},cap_shape,-1,pos,[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction=0.4,restitution=0.3,linearDamping=0.05,angularDamping=0.1,physicsClientId=c)
        if chain_ids:
            cid=pb.createConstraint(chain_ids[-1],-1,bid,-1,pb.JOINT_POINT2POINT,[0,0,1],[0,0,-off_],[0,0,off_],physicsClientId=c)
            pb.changeConstraint(cid,maxForce=300.0,physicsClientId=c)
        chain_ids.append(bid)
    pb.createConstraint(chain_ids[0],-1,-1,-1,pb.JOINT_FIXED,[0,0,0],[0,0,0],left_pivot,physicsClientId=c)
    pb.createConstraint(chain_ids[-1],-1,-1,-1,pb.JOINT_FIXED,[0,0,0],[0,0,0],right_pivot,physicsClientId=c)
    for i in range({p.n_links}): _add_capsule(sc,f"link{{i}}",nodes,lr,lhl*2,{p.chain_color})
    _add_sphere(sc,"pivot_l",nodes,0.06,[0.9,0.85,0.1,1.0]); _set_pose(sc,nodes["pivot_l"],left_pivot,[0,0,0,1])
    _add_sphere(sc,"pivot_r",nodes,0.06,[0.9,0.85,0.1,1.0]); _set_pose(sc,nodes["pivot_r"],right_pivot,[0,0,0,1])
    bids=[(f"link{{i}}",bid) for i,bid in enumerate(chain_ids)]; frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_catenary_hanging_chain")
    print("OK")
