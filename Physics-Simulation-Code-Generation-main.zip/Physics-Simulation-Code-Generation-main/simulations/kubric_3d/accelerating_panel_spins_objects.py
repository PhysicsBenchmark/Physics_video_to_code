"""accelerating_panel_spins_objects — pucks with initial Z-spin ride a force-driven accelerating panel.

Implementation note: each puck uses a SPHERE collision body (single contact point → no
spinning-friction torque around the vertical axis, so the initial spin survives).  Rotation
around X and Y is locked via a huge inertia tensor so the small sphere does not tumble under
the friction torque from the moving panel.  An off-axis marker is drawn on top of each puck
so the rotation around the vertical axis is actually visible (a uniform-color cylinder
rotating around its own axis is otherwise invariant)."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (3.5, -4.5, 2.2)
CAM_TARGET = (0.5,  0.0, 0.4)
N_FRAMES   = 150


@dataclass
class Params:
    seed: int
    a_panel: float
    n_pucks: int
    puck_r: float
    puck_h: float
    puck_mass: float
    omega0: float
    friction: float
    panel_color: List[float]
    puck_colors: List[List[float]]
    marker_colors: List[List[float]]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    def _hue(s=0.85, v=0.90):
        h = random.random(); hi = int(h*6) % 6; f = h*6 - int(h*6)
        p_ = v*(1-s); q = v*(1-f*s); t = v*(1-(1-f)*s)
        r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
        return [r, g, b, 1.0]
    n = 5
    return Params(
        seed=seed,
        a_panel=random.uniform(1.0, 1.6),
        n_pucks=n,
        puck_r=0.10,
        puck_h=0.06,
        puck_mass=0.18,
        omega0=random.uniform(8.0, 14.0),
        friction=random.uniform(0.40, 0.65),
        panel_color=[0.50, 0.50, 0.55, 1.0],
        puck_colors=[_hue() for _ in range(n)],
        marker_colors=[_hue(s=0.95, v=1.00) for _ in range(n)],
    )


def _q2r(xyzw):
    x, y, z, w = xyzw
    return np.array([
        [1 - 2*(y*y + z*z), 2*(x*y - z*w),     2*(x*z + y*w)],
        [2*(x*y + z*w),     1 - 2*(x*x + z*z), 2*(y*z - x*w)],
        [2*(x*z - y*w),     2*(y*z + x*w),     1 - 2*(x*x + y*y)],
    ])


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, save_sample, build_cot, param_entry,
        STANDALONE_IMPORTS, STANDALONE_UTILS, FPS, STEP_RATE)
    import pybullet as pb

    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=0.04)
    ren.add_plane_mesh("floor", 8.0, [0.38, 0.38, 0.42, 1.0])
    ren.set_static_pose("floor", [0, 0, -0.02])

    panel_half = [1.0, 0.7, 0.04]
    panel_z    = panel_half[2]
    panel_mass = 50.0
    panel_bid = phys.add_box(panel_half, [0.0, 0.0, panel_z], mass=panel_mass,
                             friction=p.friction, restitution=0.10,
                             lin_damp=0.0, ang_damp=0.5)
    ren.add_box("panel", panel_half, p.panel_color)

    panel_top_z = 2 * panel_half[2]
    sphere_R    = p.puck_h / 2
    puck_z0     = panel_top_z + sphere_R + 0.001
    puck_bids   = []
    positions_xy = [(-0.55, -0.20), (-0.25,  0.25), (0.05, -0.20),
                    ( 0.30,  0.25), ( 0.60, -0.20)]

    disc_Iz = 0.5 * p.puck_mass * p.puck_r ** 2   # ½mR²
    big_I   = 100.0                               # locks X/Y rotation

    marker_r = 0.022
    marker_local_offset = np.array([p.puck_r * 0.78, 0.0, p.puck_h / 2 + marker_r])

    for i in range(p.n_pucks):
        x, y = positions_xy[i]
        omega_dir = 1 if i % 2 == 0 else -1
        bid = phys.add_sphere(sphere_R, [x, y, puck_z0], mass=p.puck_mass,
                              friction=p.friction, restitution=0.0,
                              ang_vel=[0, 0, p.omega0 * omega_dir],
                              lin_damp=0.0, ang_damp=0.0)
        pb.changeDynamics(bid, -1,
                          localInertiaDiagonal=[big_I, big_I, disc_Iz],
                          physicsClientId=phys.client)
        puck_bids.append(bid)
        ren.add_cylinder(f"puck{i}", p.puck_r, p.puck_h, p.puck_colors[i])
        ren.add_sphere(f"mark{i}", marker_r, p.marker_colors[i])

    F_apply = panel_mass * p.a_panel

    frames = []
    for fi in range(N_FRAMES):
        for _ in range(STEP_RATE // FPS):
            pb.applyExternalForce(panel_bid, -1, [F_apply, 0, 0], [0, 0, 0],
                                  pb.LINK_FRAME, physicsClientId=phys.client)
            phys.step()
        ppos, porn = phys.get_pose(panel_bid)
        ren.set_pose("panel", ppos, porn)
        for i, bid in enumerate(puck_bids):
            pp, po = phys.get_pose(bid)
            ren.set_pose(f"puck{i}", pp, po)
            R = _q2r(po)
            mw = np.array(pp) + R @ marker_local_offset
            ren.set_pose(f"mark{i}", mw.tolist(), po)
        frames.append(ren.render_frame())

    mu_g = p.friction * 9.81
    cot = build_cot(
        simulation="accelerating_panel_spins_objects",
        category="rigid_body_friction",
        seed=seed,
        physical_observation=(
            f"Panel accelerates at a={p.a_panel:.2f}m/s²; {p.n_pucks} pucks with initial "
            f"Z-spin ω₀={p.omega0:.1f}rad/s ride along. μg={mu_g:.2f}m/s² "
            f"({'sticks' if mu_g>p.a_panel else 'slips'})."
        ),
        law_name="Friction-driven coupling between accelerating surface and spinning pucks",
        law_statement=(
            "Friction force μ·m·g drags pucks horizontally. Spin around the vertical "
            "axis is preserved when the contact patch is point-like (no spinning-friction torque)."
        ),
        law_formula="F_f=\\mu m g;\\quad a_{puck}=\\min(a_p,\\mu g);\\quad I_z\\dot\\omega=\\tau_{contact}",
        assumptions=[
            "Coulomb friction at point contact between puck and panel.",
            "Pucks modelled as small spheres for collision (preserves spin).",
            "Lateral inertia locked so pucks don't tumble; vertical-axis inertia = ½mR².",
            "Panel mass ≫ puck mass so panel acceleration is unaffected by pucks.",
        ],
        state_variables=["x_panel (m)", "v_panel (m/s)", "x_puck (m)", "ω_z_puck (rad/s)"],
        equations_latex=[
            "F_{panel}=m_p a_p",
            "F_{f,puck}=\\mu m_{puck} g",
            "a_{puck}=\\min(a_p,\\mu g)",
            "\\dot{\\omega}_z\\approx 0\\ (\\text{point contact})",
        ],
        contact_impulse="j_t = μ·j_n; |j_t| ≤ μ |j_n|",
        derivation_steps=[
            f"Target panel acceleration: a={p.a_panel:.2f} m/s² (force F={F_apply:.1f} N)",
            f"Maximum puck acceleration via friction: μg = {mu_g:.2f} m/s²",
            f"Pucks {'stick to' if mu_g >= p.a_panel else 'slip on'} panel.",
            f"Vertical-axis inertia I_z = ½mR² = {disc_Iz:.5f} kg·m²",
            f"Initial spin ω₀ = ±{p.omega0:.1f} rad/s preserved through point contact.",
        ],
        expected_behavior=[
            f"Panel accelerates linearly in +x at {p.a_panel:.2f} m/s².",
            f"Pucks visibly spin around vertical axis at ω₀ = {p.omega0:.1f} rad/s "
            f"(off-axis markers trace circles).",
            "Pucks translate with panel (carried by friction).",
            "Spin is preserved long-term because contact is point-like.",
        ],
        parameters={
            "a_panel":   param_entry(p.a_panel,   "m/s²", "panel acceleration"),
            "n_pucks":   param_entry(p.n_pucks,   "",     "number of pucks"),
            "puck_r":    param_entry(p.puck_r,    "m",    "puck radius"),
            "puck_h":    param_entry(p.puck_h,    "m",    "puck height"),
            "puck_mass": param_entry(p.puck_mass, "kg",   "puck mass"),
            "omega0":    param_entry(p.omega0,    "rad/s","initial Z-spin magnitude"),
            "friction":  param_entry(p.friction,  "",     "friction coefficient"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# accelerating_panel_spins_objects  seed={p.seed}
import math, pybullet as pb, numpy as np
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}
A={p.a_panel}; OMG={p.omega0}; FR={p.friction}
PUCK_R={p.puck_r}; PUCK_H={p.puck_h}; PM={p.puck_mass}; NP={p.n_pucks}
PANEL_M=50.0
PUCK_COLS={p.puck_colors}
MARK_COLS={p.marker_colors}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    plane_bid=pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    pb.changeDynamics(plane_bid,-1,lateralFriction=0.04,physicsClientId=c)
    _add_box(sc,"fl",nodes,[4,4,0.02],[0.38,0.38,0.42,1.0]); _set_pose(sc,nodes["fl"],[0,0,-0.02],[0,0,0,1])
    he=[1.0,0.7,0.04]; pz=he[2]
    s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=he,physicsClientId=c)
    pbid=pb.createMultiBody(PANEL_M,s,-1,[0,0,pz],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(pbid,-1,lateralFriction=FR,restitution=0.1,linearDamping=0.0,angularDamping=0.5,physicsClientId=c)
    _add_box(sc,"panel",nodes,he,{p.panel_color}); bids=[("panel",pbid)]
    sphere_R=PUCK_H/2; top_z=2*he[2]; puck_z0=top_z+sphere_R+0.001
    pos_xy=[(-0.55,-0.20),(-0.25,0.25),(0.05,-0.20),(0.30,0.25),(0.60,-0.20)]
    disc_Iz=0.5*PM*PUCK_R*PUCK_R; big_I=100.0
    mark_r=0.022; mark_off=np.array([PUCK_R*0.78,0.0,PUCK_H/2+mark_r])
    for i in range(NP):
        x,y=pos_xy[i]; od=1 if i%2==0 else -1
        s=pb.createCollisionShape(pb.GEOM_SPHERE,radius=sphere_R,physicsClientId=c)
        bid=pb.createMultiBody(PM,s,-1,[x,y,puck_z0],[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction=FR,restitution=0.0,linearDamping=0.0,angularDamping=0.0,localInertiaDiagonal=[big_I,big_I,disc_Iz],physicsClientId=c)
        pb.resetBaseVelocity(bid,[0,0,0],[0,0,OMG*od],physicsClientId=c)
        _add_cylinder(sc,f"p{{i}}",nodes,PUCK_R,PUCK_H,PUCK_COLS[i])
        _add_sphere(sc,f"m{{i}}",nodes,mark_r,MARK_COLS[i]); bids.append((f"p{{i}}",bid))
    F=PANEL_M*A; frames=[]
    for fi in range(N_FRAMES):
        for __ in range(8):
            pb.applyExternalForce(pbid,-1,[F,0,0],[0,0,0],pb.LINK_FRAME,physicsClientId=c)
            pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c); _set_pose(sc,nodes[nm],pp,oo)
        for i in range(NP):
            _,bid=bids[i+1]; pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            R=_q2r(oo); mw=np.array(pp)+R@mark_off
            _set_pose(sc,nodes[f"m{{i}}"],mw.tolist(),oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_accelerating_panel_spins_objects")
    print("OK")
