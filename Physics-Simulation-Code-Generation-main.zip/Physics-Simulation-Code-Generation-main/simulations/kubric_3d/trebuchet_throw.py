"""trebuchet_throw — counterweight trebuchet arm flings a projectile."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (6, -3, 5)
CAM_TARGET = (0, 0, 2)
N_FRAMES   = 120


@dataclass
class Params:
    seed:              int
    arm_half_long:     float   # distance from pivot to long-end tip (m)
    arm_half_short:    float   # distance from pivot to short-end tip (m)
    arm_mass:          float   # kg
    counterweight_mass: float  # kg
    proj_mass:         float   # kg
    proj_radius:       float   # m
    fulcrum_height:    float   # m
    floor_friction:    float
    arm_color:         List[float]
    cw_color:          List[float]
    proj_color:        List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        arm_half_long=random.uniform(1.2, 2.0),
        arm_half_short=random.uniform(0.3, 0.6),
        arm_mass=random.uniform(0.5, 1.5),
        counterweight_mass=random.uniform(3.0, 7.0),
        proj_mass=random.uniform(0.1, 0.4),
        proj_radius=random.uniform(0.08, 0.14),
        fulcrum_height=random.uniform(1.2, 1.8),
        floor_friction=random.uniform(0.4, 0.7),
        arm_color=[random.uniform(0.4, 0.7), random.uniform(0.3, 0.6),
                   random.uniform(0.2, 0.5), 1.0],
        cw_color=[0.2, 0.2, 0.25, 1.0],
        proj_color=[random.uniform(0.6, 1.0), random.uniform(0.3, 0.7),
                    random.uniform(0.1, 0.5), 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 12.0, [0.42, 0.42, 0.45, 1.0])
    ren.set_static_pose("floor", [0, 0, 0])

    # Static fulcrum pole — pivot at its top
    fulcrum_r = 0.06
    fulcrum_h = p.fulcrum_height
    phys.add_cylinder(fulcrum_r, fulcrum_h, [0, 0, fulcrum_h / 2],
                      mass=0, friction=0.3, restitution=0.2)
    ren.add_cylinder("fulcrum", fulcrum_r, fulcrum_h, [0.3, 0.25, 0.2, 1.0])
    ren.set_static_pose("fulcrum", [0, 0, fulcrum_h / 2])

    # Arm geometry: pivot at world x=0, long arm to +x, short arm to -x
    #   long tip:  x = +arm_half_long
    #   short tip: x = -arm_half_short
    #   arm COM:   x = (arm_half_long - arm_half_short) / 2  (toward long side)
    total_half = p.arm_half_long + p.arm_half_short  # full arm length
    arm_thick  = 0.06
    arm_cx     = (p.arm_half_long - p.arm_half_short) / 2   # COM x in world
    arm_z      = fulcrum_h + arm_thick                        # arm just above pivot

    arm_id = phys.add_box(
        [total_half / 2, arm_thick, arm_thick],
        [arm_cx, 0.0, arm_z],
        mass=p.arm_mass, friction=0.3, restitution=0.1)
    pb_mod.changeDynamics(arm_id, -1,
        linearDamping=0.5, angularDamping=1.0,
        physicsClientId=phys.client)
    ren.add_box("arm", [total_half / 2, arm_thick, arm_thick], p.arm_color)

    pivot_world = [0.0, 0.0, fulcrum_h]
    hinge_axis_half = 0.35
    pivot_in_arm = [-arm_cx, 0.0, -arm_thick]
    # Two separated world pins define the fulcrum hinge axis along Y. A single
    # ball-joint pin let the arm yaw/roll and oscillate out of plane.
    for yoff in (-hinge_axis_half, hinge_axis_half):
        hinge_cid = pb_mod.createConstraint(
            arm_id, -1, -1, -1,
            pb_mod.JOINT_POINT2POINT,
            [0, 0, 0],
            [pivot_in_arm[0], yoff, pivot_in_arm[2]],
            [pivot_world[0], yoff, pivot_world[2]],
            physicsClientId=phys.client)
        pb_mod.changeConstraint(hinge_cid, maxForce=100000.0,
                                physicsClientId=phys.client)

    # Counterweight sphere fixed to short end of arm
    cw_pos = [-p.arm_half_short, 0.0, arm_z]
    cw_id = phys.add_sphere(0.15, cw_pos,
                             mass=p.counterweight_mass,
                             friction=0.3, restitution=0.1)
    ren.add_sphere("cw", 0.15, p.cw_color)

    # JOINT_FIXED: attach CW to arm's short-end tip
    cw_cid = pb_mod.createConstraint(
        arm_id, -1, cw_id, -1,
        pb_mod.JOINT_FIXED,
        [0, 0, 0],
        [-total_half / 2, 0.0, 0.0],
        [0.0, 0.0, 0.0],
        physicsClientId=phys.client)
    pb_mod.changeConstraint(cw_cid, maxForce=50000.0, physicsClientId=phys.client)
    pb_mod.setCollisionFilterPair(arm_id, cw_id, -1, -1, 0,
                                  physicsClientId=phys.client)

    # Projectile: free sphere resting on long-end tip — flung by arm contact
    proj_x   = p.arm_half_long - p.proj_radius
    proj_pos = [proj_x, 0.0, arm_z + arm_thick + p.proj_radius]
    proj_id  = phys.add_sphere(p.proj_radius, proj_pos,
                                mass=p.proj_mass,
                                friction=0.3, restitution=0.5)
    ren.add_sphere("proj", p.proj_radius, p.proj_color)

    dyn = [("arm", arm_id), ("cw", cw_id), ("proj", proj_id)]
    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="trebuchet_throw",
        category="articulated_jointed",
        seed=seed,
        physical_observation=(
            f"Trebuchet arm (long half {p.arm_half_long:.2f}m, short half "
            f"{p.arm_half_short:.2f}m) hinged on fulcrum at height "
            f"{p.fulcrum_height:.2f}m. Counterweight {p.counterweight_mass:.2f}kg "
            f"on short end; projectile {p.proj_mass:.2f}kg on long end."),
        law_name="Rigid-body rotational dynamics (trebuchet)",
        law_statement=(
            "Net torque about the fulcrum pivot causes angular acceleration; "
            "heavier counterweight rotates the arm and launches the projectile."),
        law_formula="tau_net = I * alpha;  tau = r x F",
        assumptions=[
            "Arm treated as rigid thin rod.",
            "Two point constraints define a hinge axis through the fulcrum.",
            "Counterweight rigidly fixed to short arm (JOINT_FIXED).",
            "Projectile is free body launched by contact force.",
            "Air resistance neglected.",
        ],
        state_variables=["r (m)", "v (m/s)", "q (quaternion)", "omega (rad/s)"],
        equations_latex=[
            r"\dot{r} = v",
            r"m\dot{v} = mg + F_c",
            r"I\dot{\omega} = \tau_c - \omega \times I\omega",
        ],
        contact_impulse="j = -(1+e)*v_n / (1/m_A + 1/m_B + cross_terms)",
        derivation_steps=[
            f"Counterweight torque: tau_cw = {p.counterweight_mass:.2f}*9.81*{p.arm_half_short:.2f} = "
            f"{p.counterweight_mass*9.81*p.arm_half_short:.2f} N·m",
            f"Projectile torque (opposing): tau_p = {p.proj_mass:.2f}*9.81*{p.arm_half_long:.2f} = "
            f"{p.proj_mass*9.81*p.arm_half_long:.2f} N·m",
            "Net torque rotates arm about hinge; projectile accelerates upward.",
            "Projectile detaches and follows parabolic trajectory under gravity.",
        ],
        expected_behavior=[
            "Counterweight pulls short end down, long end rises.",
            "Arm rotates about the fulcrum hinge axis with little out-of-plane wobble.",
            "Projectile accelerates upward and forward, then flies free.",
            "Projectile follows ballistic arc after launch.",
        ],
        parameters={
            "arm_half_long_m":      param_entry(p.arm_half_long, "m", "Long arm half-length"),
            "arm_half_short_m":     param_entry(p.arm_half_short, "m", "Short arm half-length"),
            "arm_mass_kg":          param_entry(p.arm_mass, "kg", "Arm mass"),
            "counterweight_mass_kg": param_entry(p.counterweight_mass, "kg", "Counterweight mass"),
            "proj_mass_kg":         param_entry(p.proj_mass, "kg", "Projectile mass"),
            "proj_radius_m":        param_entry(p.proj_radius, "m", "Projectile radius"),
            "fulcrum_height_m":     param_entry(p.fulcrum_height, "m", "Fulcrum height"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    total_half = p.arm_half_long + p.arm_half_short
    arm_thick  = 0.06
    arm_cx     = (p.arm_half_long - p.arm_half_short) / 2
    arm_z      = p.fulcrum_height + arm_thick
    cw_x       = -p.arm_half_short
    proj_x     = p.arm_half_long - p.proj_radius
    proj_z     = arm_z + arm_thick + p.proj_radius
    pivot_in_arm = [-arm_cx, 0.0, -arm_thick]
    hinge_axis_half = 0.35
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# trebuchet_throw  seed={p.seed}
import pybullet as pb
import math
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[6.0,6.0,0.02],[0.42,0.42,0.45,1.0]); _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])

    # fulcrum pole (static)
    fr={p.fulcrum_height:.4f}
    s=pb.createCollisionShape(pb.GEOM_CYLINDER,radius=0.06,height=fr,physicsClientId=c)
    pb.createMultiBody(0,s,-1,[0,0,fr/2],[0,0,0,1],physicsClientId=c)
    _add_cylinder(sc,"fulcrum",nodes,0.06,fr,[0.3,0.25,0.2,1.0]); _set_pose(sc,nodes["fulcrum"],[0,0,fr/2],[0,0,0,1])

    # arm (dynamic, hinged at x=0 via constraint)
    s2=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[{total_half/2:.4f},{arm_thick:.4f},{arm_thick:.4f}],physicsClientId=c)
    arm_id=pb.createMultiBody({p.arm_mass:.4f},s2,-1,[{arm_cx:.4f},0,{arm_z:.4f}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(arm_id,-1,lateralFriction=0.3,restitution=0.1,linearDamping=0.5,angularDamping=1.0,physicsClientId=c)
    _add_box(sc,"arm",nodes,[{total_half/2:.4f},{arm_thick:.4f},{arm_thick:.4f}],{p.arm_color})

    # two world pins form the fulcrum hinge axis along Y
    for yoff in [{-hinge_axis_half:.4f},{hinge_axis_half:.4f}]:
        hcid=pb.createConstraint(arm_id,-1,-1,-1,pb.JOINT_POINT2POINT,[0,0,0],
            [{pivot_in_arm[0]:.4f},yoff,{pivot_in_arm[2]:.4f}],[0,yoff,{p.fulcrum_height:.4f}],physicsClientId=c)
        pb.changeConstraint(hcid,maxForce=100000,physicsClientId=c)

    # counterweight (fixed to short arm end)
    s3=pb.createCollisionShape(pb.GEOM_SPHERE,radius=0.15,physicsClientId=c)
    cw_id=pb.createMultiBody({p.counterweight_mass:.4f},s3,-1,[{cw_x:.4f},0,{arm_z:.4f}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(cw_id,-1,lateralFriction=0.3,restitution=0.1,physicsClientId=c)
    _add_sphere(sc,"cw",nodes,0.15,{p.cw_color})

    # JOINT_FIXED: attach CW to arm's short-end tip
    cwcid=pb.createConstraint(arm_id,-1,cw_id,-1,pb.JOINT_FIXED,[0,0,0],
        [{-total_half/2:.4f},0,0],[0,0,0],physicsClientId=c)
    pb.changeConstraint(cwcid,maxForce=50000,physicsClientId=c)
    pb.setCollisionFilterPair(arm_id,cw_id,-1,-1,0,physicsClientId=c)

    # projectile (free body resting on long end)
    s4=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.proj_radius:.4f},physicsClientId=c)
    proj_id=pb.createMultiBody({p.proj_mass:.4f},s4,-1,[{proj_x:.4f},0,{proj_z:.4f}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(proj_id,-1,lateralFriction=0.3,restitution=0.5,physicsClientId=c)
    _add_sphere(sc,"proj",nodes,{p.proj_radius:.4f},{p.proj_color})

    bids=[("arm",arm_id),("cw",cw_id),("proj",proj_id)]; frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_trebuchet_throw")
    print("OK")
