"""bowling_strike — bowling ball rolled at 10 pins arranged in a triangle formation."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (0, -8, 4)
CAM_TARGET = (0, 0, 0.5)
N_FRAMES   = 120


@dataclass
class Params:
    seed: int
    pin_radius: float
    pin_height: float
    pin_mass: float
    ball_radius: float
    ball_mass: float
    ball_speed: float
    restitution: float
    friction: float
    color_ball: List[float]
    color_pin: List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        pin_radius=random.uniform(0.06, 0.10),
        pin_height=random.uniform(0.30, 0.45),
        pin_mass=random.uniform(0.8, 1.5),
        ball_radius=random.uniform(0.16, 0.22),
        ball_mass=random.uniform(4.0, 7.0),
        ball_speed=random.uniform(6.0, 12.0),
        restitution=random.uniform(0.3, 0.6),
        friction=random.uniform(0.4, 0.7),
        color_ball=_rand_hue(),
        color_pin=_rand_hue(),
    )


def _rand_hue():
    h = random.random(); s, v = 0.85, 0.90
    hi = int(h*6) % 6; f = h*6 - int(h*6)
    p_ = v*(1-s); q = v*(1-f*s); t = v*(1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return [r, g, b, 1.0]


# Bowling pin triangle: rows 1,2,3,4 pins (total 10)
# Row 0 at y=0, each row advances +Y by spacing
def _pin_positions(pr, spacing_mult=2.2):
    positions = []
    row_y = [0.0, 1.0, 2.0, 3.0]
    row_x_offsets = [
        [0.0],
        [-0.5, 0.5],
        [-1.0, 0.0, 1.0],
        [-1.5, -0.5, 0.5, 1.5],
    ]
    sp = pr * spacing_mult
    for row_idx, y_off in enumerate(row_y):
        for x_off in row_x_offsets[row_idx]:
            positions.append((x_off * sp, y_off * sp))
    return positions


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.friction)
    ren.add_plane_mesh("floor", 12.0, [0.42, 0.42, 0.45, 1.0])

    pin_pz = p.pin_height / 2.0
    pin_positions = _pin_positions(p.pin_radius)
    dyn = []

    for i, (px, py) in enumerate(pin_positions):
        nm = f"pin{i}"
        bid = phys.add_cylinder(p.pin_radius, p.pin_height, [px, py, pin_pz],
                                  mass=p.pin_mass, friction=p.friction,
                                  restitution=p.restitution)
        ren.add_cylinder(nm, p.pin_radius, p.pin_height, p.color_pin)
        ren.set_static_pose(nm, [px, py, pin_pz])
        dyn.append((nm, bid))

    # Ball rolls from -Y direction
    ball_z = p.ball_radius
    ball_y_start = -4.0
    ball_id = phys.add_sphere(p.ball_radius, [0.0, ball_y_start, ball_z],
                               mass=p.ball_mass, friction=p.friction,
                               restitution=p.restitution,
                               vel=(0.0, p.ball_speed, 0.0))
    ren.add_sphere("ball", p.ball_radius, p.color_ball, metallic=0.2, roughness=0.2)
    ren.set_static_pose("ball", [0.0, ball_y_start, ball_z])
    dyn.append(("ball", ball_id))

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="bowling_strike",
        category="mixed_complex",
        seed=seed,
        physical_observation=(
            f"Bowling ball r={p.ball_radius:.2f}m m={p.ball_mass:.1f}kg rolled at "
            f"{p.ball_speed:.1f}m/s toward 10 pins (r={p.pin_radius:.2f}m, "
            f"h={p.pin_height:.2f}m, m={p.pin_mass:.2f}kg) in triangle formation."
        ),
        law_name="Newton-Euler rigid-body dynamics + contact impulse",
        law_statement=(
            "Heavy ball transfers momentum to pins via collision impulses; "
            "pins scatter and topple according to rigid-body dynamics."
        ),
        law_formula="j_n = -(1+e)·v_n / (1/m_ball + 1/m_pin + r×n·I^{-1}·r×n)",
        assumptions=[
            "Rigid ball and pin cylinders",
            "Coulomb friction on floor and between objects",
            "Pins start upright; no pre-loading",
            "Ball rolls without significant spin initially",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg+\\sum F_c",
            "I\\dot{\\omega}=\\sum\\tau_c-\\omega\\times I\\omega",
            "j_n=-(1+e)v_{rel,n}/(1/m_A+1/m_B)",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B + cross_terms)",
        derivation_steps=[
            f"Ball KE = 0.5×{p.ball_mass:.1f}×{p.ball_speed:.1f}² = {0.5*p.ball_mass*p.ball_speed**2:.1f}J",
            "Ball contacts leading pin (row 0); impulse transfers to pin and causes tip",
            "Cascade: tipped pins contact adjacent pins in row 1, 2, 3",
            "Energy dissipated through successive inelastic collisions and friction",
        ],
        expected_behavior=[
            "Ball rolls forward and hits lead pin",
            "Lead pin knocked backward; collides with row-2 pins",
            "Pin cascade propagates through triangle",
            "Ball continues moving; pins scatter across floor",
        ],
        parameters={
            "pin_radius":  param_entry(p.pin_radius,  "m",   "pin cylinder radius"),
            "pin_height":  param_entry(p.pin_height,  "m",   "pin cylinder height"),
            "pin_mass":    param_entry(p.pin_mass,    "kg",  "mass of each pin"),
            "ball_radius": param_entry(p.ball_radius, "m",   "bowling ball radius"),
            "ball_mass":   param_entry(p.ball_mass,   "kg",  "bowling ball mass"),
            "ball_speed":  param_entry(p.ball_speed,  "m/s", "initial ball speed"),
            "restitution": param_entry(p.restitution, "",    "coefficient of restitution"),
            "friction":    param_entry(p.friction,    "",    "lateral friction coefficient"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    pin_pz = p.pin_height / 2.0
    pin_positions = _pin_positions(p.pin_radius)
    ball_z = p.ball_radius
    pin_lines = []
    for i, (px, py) in enumerate(pin_positions):
        pin_lines.append(
            f"    sp=pb.createCollisionShape(pb.GEOM_CYLINDER,radius={p.pin_radius},height={p.pin_height},physicsClientId=c)\n"
            f"    pin{i}=pb.createMultiBody({p.pin_mass},sp,-1,[{px:.4f},{py:.4f},{pin_pz:.4f}],[0,0,0,1],physicsClientId=c)\n"
            f"    pb.changeDynamics(pin{i},-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)\n"
            f"    _add_cylinder(sc,'pin{i}',nodes,{p.pin_radius},{p.pin_height},{p.color_pin})\n"
            f"    _set_pose(sc,nodes['pin{i}'],[{px:.4f},{py:.4f},{pin_pz:.4f}],[0,0,0,1])\n"
        )
    bids_list = "[" + ",".join([f"('pin{i}',pin{i})" for i in range(10)]) + ",(\"ball\",ball)]"
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# bowling_strike  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[6.0,6.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
{"".join(pin_lines)}    sb=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.ball_radius},physicsClientId=c)
    ball=pb.createMultiBody({p.ball_mass},sb,-1,[0,-4,{ball_z:.3f}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(ball,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
    pb.resetBaseVelocity(ball,[0,{p.ball_speed},0],[0,0,0],physicsClientId=c)
    _add_sphere(sc,"ball",nodes,{p.ball_radius},{p.color_ball})
    _set_pose(sc,nodes["ball"],[0,-4,{ball_z:.3f}],[0,0,0,1])
    bids={bids_list}
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete()
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_bowling_strike")
    print("OK")
