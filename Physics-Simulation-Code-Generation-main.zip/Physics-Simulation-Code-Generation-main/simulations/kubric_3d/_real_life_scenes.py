"""Shared builders for real-life Kubric/PyBullet teaching scenes."""
from __future__ import annotations

import math
import os
import random
import sys
from dataclasses import asdict, dataclass
from typing import Any

import numpy as np

CAM_DEFAULT = (4.5, -5.0, 3.5)
TARGET_DEFAULT = (0.0, 0.0, 0.8)
N_FRAMES = 150


@dataclass
class Params:
    seed: int
    experiment: str
    objects: list[dict[str, Any]]
    camera_eye: tuple[float, float, float]
    camera_target: tuple[float, float, float]
    floor_size: float
    summary: dict[str, Any]


def _color(rng: random.Random, base=None):
    if base is not None:
        return base
    return [rng.uniform(0.15, 0.9), rng.uniform(0.15, 0.9), rng.uniform(0.15, 0.9), 1.0]


def _sphere(name, radius, pos, mass, color, vel=(0, 0, 0), friction=0.5, restitution=0.5):
    return {"name": name, "shape": "sphere", "radius": radius, "pos": list(pos), "mass": mass,
            "color": color, "vel": list(vel), "friction": friction, "restitution": restitution}


def _box(name, half_ext, pos, mass, color, vel=(0, 0, 0), orn=(0, 0, 0),
         friction=0.5, restitution=0.5, ang_vel=(0, 0, 0)):
    return {"name": name, "shape": "box", "half_ext": list(half_ext), "pos": list(pos), "mass": mass,
            "color": color, "vel": list(vel), "orn_euler": list(orn), "friction": friction,
            "restitution": restitution, "ang_vel": list(ang_vel)}


def _cylinder(name, radius, height, pos, mass, color, vel=(0, 0, 0), orn=(0, 0, 0), friction=0.5, restitution=0.5, ang_vel=(0, 0, 0)):
    return {"name": name, "shape": "cylinder", "radius": radius, "height": height, "pos": list(pos), "mass": mass,
            "color": color, "vel": list(vel), "orn_euler": list(orn), "friction": friction, "restitution": restitution,
            "ang_vel": list(ang_vel)}


def _capsule(name, radius, height, pos, mass, color, vel=(0, 0, 0), orn=(0, 0, 0), friction=0.5, restitution=0.5, ang_vel=(0, 0, 0)):
    return {"name": name, "shape": "capsule", "radius": radius, "height": height, "pos": list(pos), "mass": mass,
            "color": color, "vel": list(vel), "orn_euler": list(orn), "friction": friction, "restitution": restitution,
            "ang_vel": list(ang_vel)}


def _visual(obj: dict[str, Any]) -> dict[str, Any]:
    obj["visual_only"] = True
    obj["mass"] = 0
    return obj


def _base_summary(params: Params):
    shapes = [obj["shape"] for obj in params.objects]
    return {
        "experiment": params.experiment,
        "object_shapes": shapes,
        "colors": [obj.get("color") for obj in params.objects],
        "masses": [obj.get("mass") for obj in params.objects],
        "positions": [obj.get("pos") for obj in params.objects],
        "velocities": [obj.get("vel", [0, 0, 0]) for obj in params.objects],
        "camera_eye": params.camera_eye,
        "camera_target": params.camera_target,
        **params.summary,
    }


def build_params(experiment: str, seed: int) -> Params:
    rng = random.Random(seed + abs(hash(experiment)) % 100000)
    g = 9.81
    red = [0.85, 0.18, 0.14, 1.0]
    blue = [0.16, 0.42, 0.86, 1.0]
    green = [0.20, 0.72, 0.34, 1.0]
    yellow = [0.94, 0.74, 0.18, 1.0]
    grey = [0.45, 0.45, 0.50, 1.0]
    wood = [0.55, 0.34, 0.16, 1.0]
    objects = []
    summary: dict[str, Any] = {}
    cam = CAM_DEFAULT
    target = TARGET_DEFAULT
    floor = 7.0

    if experiment == "rolling_vs_sliding_blocks":
        theta = rng.uniform(18, 32); ramp_len = 4.0
        objects += [_box("ramp", [ramp_len/2, 0.75, 0.08], [0.8, 0, 0.65], 0, grey, orn=[0, -math.radians(theta), 0], friction=0.7),
                    _sphere("rolling_ball", 0.18, [-0.7, -0.25, 1.55], 1.0, red, friction=0.9),
                    _box("sliding_block", [0.18, 0.18, 0.18], [-0.7, 0.35, 1.55], 1.0, blue, friction=0.08)]
        summary = {"ramp_angle_deg": theta, "rolling_inertia_factor_sphere": 0.4, "slide_friction": 0.08}
    elif experiment == "compound_pulley_lift":
        load_m = rng.uniform(1.5, 4.0); pull_m = rng.uniform(0.4, 1.2)
        objects += [_sphere("fixed_pulley", 0.16, [0, 0, 2.2], 0, yellow), _sphere("movable_pulley", 0.16, [0, 0, 1.25], 0.2, grey, vel=[0,0,0.25]),
                    _box("load", [0.28,0.28,0.22], [0,0,0.75], load_m, red, vel=[0,0,0.2]),
                    _sphere("pull_weight", 0.14, [1.0,0,1.8], pull_m, blue, vel=[0,0,-0.5])]
        summary = {"mechanical_advantage": 2, "load_mass": load_m, "pull_mass": pull_m}
    elif experiment == "two_car_collision_3d":
        m1 = rng.uniform(0.6, 1.5); m2 = rng.uniform(0.6, 1.5); e = rng.uniform(0.45, 0.9)
        objects += [_box("car_A", [0.35,0.20,0.14], [-1.0,-0.1,0.14], m1, red, vel=[1.6,0.15,0], friction=0.15, restitution=e),
                    _box("car_B", [0.35,0.20,0.14], [1.0,0.1,0.14], m2, blue, vel=[-1.1,-0.1,0], friction=0.15, restitution=e)]
        summary = {"mass_A": m1, "mass_B": m2, "restitution": e}
    elif experiment == "toppling_bookshelf_row":
        n = rng.randint(7, 11); spacing = rng.uniform(0.24, 0.34)
        for i in range(n):
            objects.append(_box(f"book_{i}", [0.035,0.16,0.42], [-1.2+i*spacing,0,0.44], 0.35, _color(rng), vel=[0,0.8 if i==0 else 0,0], friction=0.55, restitution=0.25))
        summary = {"n_books": n, "spacing": spacing, "tipping_threshold_angle": "arctan(thickness/height)"}
    elif experiment == "stacked_blocks_earthquake":
        n = rng.randint(5, 8); amp = rng.uniform(0.5, 1.2)
        objects.append(_box("moving_base", [0.75,0.75,0.06], [0,0,0.08], 0, grey, vel=[amp,0,0], friction=0.85))
        for i in range(n):
            objects.append(_box(f"block_{i}", [0.22,0.22,0.12], [0,0,0.24+i*0.25], 0.45, _color(rng), friction=0.65, restitution=0.2))
        summary = {"n_blocks": n, "base_velocity_mps": amp, "stability_condition": "topples when center of mass leaves support polygon"}
    elif experiment == "rolling_ball_loop_track":
        v0 = rng.uniform(2.2, 3.4); R = rng.uniform(0.55, 0.85)
        objects += [_box("entry_track", [1.5,0.12,0.05], [-0.7,0,0.13], 0, grey, friction=0.45),
                    _cylinder("loop_visual", R, 0.03, [0.85,0,0.75], 0, yellow, orn=[math.pi/2,0,0]),
                    _sphere("ball", 0.11, [-1.6,0,0.35], 0.3, red, vel=[v0,0,0], friction=0.75, restitution=0.25)]
        summary = {"loop_radius": R, "initial_speed": v0, "minimum_loop_speed_top": math.sqrt(g*R)}
    elif experiment == "mass_spring_collision_chain":
        n=4; v0=rng.uniform(1.0,2.0)
        objects.append(_sphere("projectile",0.12,[-1.8,0,0.26],0.25,red,vel=[v0,0,0],restitution=0.8))
        for i in range(n):
            objects.append(_box(f"cart_{i}",[0.2,0.16,0.12],[-0.8+i*0.45,0,0.22],0.5,blue if i%2 else green,friction=0.12,restitution=0.8))
        summary={"n_carts":n,"projectile_speed":v0,"wave_speed_note":"compression impulse propagates through cart chain"}
    elif experiment == "gyroscope_on_stand":
        spin=rng.uniform(20,45); m=rng.uniform(0.5,1.0)
        objects += [_cylinder("stand",0.04,1.2,[0,0,0.65],0,grey),
                    _cylinder("rotor",0.35,0.08,[0.35,0,1.25],m,yellow,orn=[0,math.pi/2,0],ang_vel=[spin,0,0],friction=0.4),
                    _capsule("axle",0.025,0.8,[0.18,0,1.25],0.1,blue,orn=[0,math.pi/2,0])]
        summary={"spin_rate_rad_s":spin,"rotor_mass":m,"precession_rate_ideal":"Omega = tau/L"}
    elif experiment == "coin_toss_spin_land":
        spin=rng.uniform(12,35); v=rng.uniform(0.8,1.6)
        objects.append(_cylinder("coin",0.22,0.035,[-0.5,0,1.2],0.05,yellow,vel=[v,0,1.2],orn=[math.pi/2,0,0],ang_vel=[0,spin,0],friction=0.45,restitution=0.35))
        summary={"spin_rate_rad_s":spin,"launch_speed_x":v,"rigid_body_inertia":"thin disk I_z=1/2 mR^2"}
    elif experiment == "granular_hourglass_3d":
        n=22; neck=0.18
        objects += [
            _capsule("upper_left_frame",0.018,1.35,[-0.34,0,1.28],0,grey,orn=[0,0.32,0],friction=0.35),
            _capsule("upper_right_frame",0.018,1.35,[0.34,0,1.28],0,grey,orn=[0,-0.32,0],friction=0.35),
            _capsule("lower_left_frame",0.018,1.05,[-0.32,0,0.52],0,grey,orn=[0,-0.25,0],friction=0.35),
            _capsule("lower_right_frame",0.018,1.05,[0.32,0,0.52],0,grey,orn=[0,0.25,0],friction=0.35),
            _box("neck_plate_L",[0.05,0.45,0.035],[-0.18,0,0.93],0,grey,friction=0.5),
            _box("neck_plate_R",[0.05,0.45,0.035],[0.18,0,0.93],0,grey,friction=0.5),
            _box("catch_floor",[0.7,0.7,0.035],[0,0,0.08],0,[0.36,0.36,0.40,1.0],friction=0.55),
        ]
        for i in range(n):
            layer=i//5; col=i%5
            objects.append(_sphere(f"grain_{i}",0.045,[(-0.16+0.08*col)+rng.uniform(-0.012,0.012),rng.uniform(-0.12,0.12),1.10+0.065*layer],0.025,_color(rng),friction=0.55,restitution=0.12))
        summary={"n_grains":n,"neck_radius":neck,"jamming_note":"flow depends on neck-to-grain diameter ratio"}
    elif experiment == "arch_collapse_keystone":
        n=9
        for i in range(n):
            x=-0.8+i*0.2; z=0.35+0.45*math.sin(i/(n-1)*math.pi)
            objects.append(_box(f"arch_block_{i}",[0.09,0.18,0.12],[x,0,z],0.25,grey,orn=[0,0,(i-4)*0.12],friction=0.6,restitution=0.2))
        objects.append(_sphere("keystone_marker",0.08,[0,0,0.9],0.05,red,vel=[0.0,0.8,0]))
        summary={"n_arch_blocks":n,"stability":"keystone removal disrupts compression force chain"}
    elif experiment == "bridge_truss_load_failure":
        objects += [_box("deck",[1.5,0.18,0.06],[0,0,0.7],0.5,grey,friction=0.6), _sphere("load",0.22,[0,0,1.25],2.5,red,vel=[0,0,-0.5])]
        for i,x in enumerate([-1.0,-0.5,0,0.5,1.0]):
            objects.append(_capsule(f"truss_{i}",0.025,0.8,[x,0,0.95],0.05,yellow,orn=[0.7 if i%2 else -0.7,0,0]))
        summary={"load_mass":2.5,"support_model":"bridge deck deforms/collides as load lands"}
    elif experiment == "seesaw_with_falling_mass":
        objects += [_box("plank",[1.2,0.16,0.05],[0,0,0.55],0.8,wood,orn=[0,0,0.08],friction=0.7), _cylinder("fulcrum",0.12,0.32,[0,0,0.32],0,grey,orn=[math.pi/2,0,0]), _sphere("falling_mass",0.18,[-0.75,0,2.0],1.1,red,vel=[0,0,-0.6],restitution=0.25), _sphere("right_mass",0.14,[0.75,0,0.75],0.35,blue)]
        summary={"falling_mass":1.1,"lever_arm_left":0.75,"angular_impulse":"Delta L = r x J"}
    else:
        raise KeyError(experiment)
    return Params(seed=seed, experiment=experiment, objects=objects, camera_eye=cam, camera_target=target, floor_size=floor, summary=summary)


def _param_entries(params: Params):
    from simulations.kubric_3d._base import param_entry

    data = _base_summary(params)
    return {k: param_entry(v, "various", k) for k, v in data.items()}


COMMON_ASSUMPTIONS = ["Rigid bodies", "Uniform gravity", "Coulomb friction", "Contact impulses are instantaneous at the frame substep scale"]
COMMON_EQ = ["\\dot{r}=v", "m\\dot{v}=mg+F_{contact}", "I\\dot{\\omega}=\\tau_{contact}-\\omega\\times I\\omega"]
COMMON_DERIV = ["Start from Newton-Euler rigid body equations.", "Resolve collision normal velocity with restitution impulse.", "Clamp tangential impulse by Coulomb friction.", "Integrate with PyBullet semi-implicit time stepping."]

COT_SPECS = {}
for _name, _title, _law, _formula, _expected in [
    ("rolling_vs_sliding_blocks", "A sphere and a block descend the same ramp with different friction and inertia.", "Rolling versus sliding down an incline", "a_{roll}=g\\sin\\theta/(1+I/(mr^2)), a_{slide}=g(\\sin\\theta-\\mu\\cos\\theta)", ["Sliding block initially accelerates differently from rolling sphere", "Rolling object stores energy in rotation"]),
    ("compound_pulley_lift", "A movable pulley visibly lifts a load with mechanical advantage.", "Mechanical advantage of a two-rope support", "2T-W=m a", ["Load rises more slowly than pulled side", "Two rope segments share the load"]),
    ("two_car_collision_3d", "Two toy carts collide obliquely on a table.", "Linear momentum plus restitution", "J=-(1+e)(v_{rel}\\cdot n)/m_{eff}", ["Cars exchange momentum", "Inelasticity reduces kinetic energy"]),
    ("toppling_bookshelf_row", "A row of books topples after the first book is pushed.", "Rigid body tipping about an edge", "I_{edge}\\ddot{\\theta}=m g d\\sin\\theta", ["Tipping wave moves down the row", "Spacing controls propagation"]),
    ("stacked_blocks_earthquake", "A stack of blocks sits on a base with lateral motion.", "Support polygon stability", "\\tau=r\\times mg; tip when COM exits support", ["Blocks slide or tip under base motion", "Tall stacks are less stable"]),
    ("rolling_ball_loop_track", "A ball rolls toward a visible loop guide.", "Loop energy and centripetal condition", "v_{top}^2\\ge gR", ["Ball enters loop region", "Insufficient speed would lose contact in the ideal model"]),
    ("mass_spring_collision_chain", "A projectile strikes a chain of carts coupled visually by spring-like spacing.", "Impulse propagation in coupled masses", "m\\ddot{x}_i=k(x_{i+1}-2x_i+x_{i-1})", ["Impulse propagates down the cart chain", "Carts separate after collision"]),
    ("gyroscope_on_stand", "A spinning rotor rests on a stand and precesses/tips under gravity/contact.", "Angular momentum and torque", "\\Omega=\\tau/L", ["Fast spin resists immediate fall", "Gravity torque changes angular momentum direction"]),
    ("coin_toss_spin_land", "A spinning coin is tossed and lands with bounces.", "Rigid disk projectile and collision dynamics", "I_z=\\tfrac12 mR^2", ["Coin translates and spins", "Bounces dissipate energy"]),
    ("granular_hourglass_3d", "Many small spheres drain through a visible narrow throat.", "Granular flow through constriction", "Q\\propto (D-kd)^{5/2}", ["Spheres flow through neck", "Jamming possible if neck is too small"]),
    ("arch_collapse_keystone", "A block arch loses its keystone and collapses.", "Compression force chain stability", "\\sum F=0, \\sum\\tau=0 until support is removed", ["Removing keystone breaks force chain", "Arch blocks fall outward"]),
    ("bridge_truss_load_failure", "A visible truss/deck is hit by a falling load.", "Beam/truss support under load", "\\sum F_y=0, \\sum\\tau=0 before failure", ["Load impacts deck", "Supports collide and shift"]),
    ("seesaw_with_falling_mass", "A falling mass lands on one side of a seesaw.", "Angular impulse about a pivot", "\\Delta L=r\\times J", ["Falling mass drives seesaw rotation", "Opposite side lifts"]),
]:
    COT_SPECS[_name] = {"observation": _title, "law_name": _law, "law_statement": _law + "; PyBullet resolves contacts and constraints numerically.", "law_formula": _formula, "assumptions": COMMON_ASSUMPTIONS, "equations": COMMON_EQ, "derivation": COMMON_DERIV, "expected": _expected}


def cot_for_params(params: Params):
    from simulations.kubric_3d._base import build_cot, param_entry
    spec = COT_SPECS[params.experiment]
    return build_cot(params.experiment, "real_life_rigid_body_teaching", params.seed, spec["observation"], spec["law_name"], spec["law_statement"], spec["law_formula"], spec["assumptions"], ["position r (m)", "linear velocity v (m/s)", "orientation q", "angular velocity omega (rad/s)"], spec["equations"], "j_n = -(1+e)(v_rel dot n) / effective_mass; |j_t| <= mu |j_n|", spec["derivation"], spec["expected"], _param_entries(params))


def make_standalone_code(params: Params) -> str:
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f'''
# {params.experiment}  seed={params.seed}
N_FRAMES={N_FRAMES}; CAM_EYE={repr(params.camera_eye)}; CAM_TARGET={repr(params.camera_target)}
OBJECTS={repr(params.objects)}; FLOOR_SIZE={repr(params.floor_size)}

def _orn(obj): return pb.getQuaternionFromEuler(obj.get("orn_euler", [0,0,0]))
def _add_body(c, sc, nodes, obj):
    sh=obj["shape"]; pos=obj["pos"]; mass=obj.get("mass",1.0); col=obj.get("color",[0.8,0.3,0.2,1]); orn=_orn(obj)
    fr=obj.get("friction",0.5); re=obj.get("restitution",0.5)
    if obj.get("visual_only"):
        bid = None
        if sh=="sphere": _add_sphere(sc,obj["name"],nodes,obj["radius"],col)
        elif sh=="box": _add_box(sc,obj["name"],nodes,obj["half_ext"],col)
        elif sh=="cylinder": _add_cylinder(sc,obj["name"],nodes,obj["radius"],obj["height"],col)
        elif sh=="capsule": _add_capsule(sc,obj["name"],nodes,obj["radius"],obj["height"],col)
        else: raise ValueError(sh)
        _set_pose(sc,nodes[obj["name"]],pos,orn)
        return None
    if sh=="sphere":
        s=pb.createCollisionShape(pb.GEOM_SPHERE, radius=obj["radius"], physicsClientId=c); bid=pb.createMultiBody(mass,s,-1,pos,orn,physicsClientId=c); _add_sphere(sc,obj["name"],nodes,obj["radius"],col)
    elif sh=="box":
        s=pb.createCollisionShape(pb.GEOM_BOX, halfExtents=obj["half_ext"], physicsClientId=c); bid=pb.createMultiBody(mass,s,-1,pos,orn,physicsClientId=c); _add_box(sc,obj["name"],nodes,obj["half_ext"],col)
    elif sh=="cylinder":
        s=pb.createCollisionShape(pb.GEOM_CYLINDER, radius=obj["radius"], height=obj["height"], physicsClientId=c); bid=pb.createMultiBody(mass,s,-1,pos,orn,physicsClientId=c); _add_cylinder(sc,obj["name"],nodes,obj["radius"],obj["height"],col)
    elif sh=="capsule":
        s=pb.createCollisionShape(pb.GEOM_CAPSULE, radius=obj["radius"], height=obj["height"], physicsClientId=c); bid=pb.createMultiBody(mass,s,-1,pos,orn,physicsClientId=c); _add_capsule(sc,obj["name"],nodes,obj["radius"],obj["height"],col)
    else: raise ValueError(sh)
    pb.changeDynamics(bid,-1,lateralFriction=fr,restitution=re,physicsClientId=c)
    pb.resetBaseVelocity(bid,obj.get("vel",[0,0,0]),obj.get("ang_vel",[0,0,0]),physicsClientId=c)
    _set_pose(sc,nodes[obj["name"]],pos,orn); return bid

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf", [0,0,0], physicsClientId=c)
    _add_box(sc,"floor",nodes,[FLOOR_SIZE/2,FLOOR_SIZE/2,0.02],[0.42,0.42,0.45,1.0]); _set_pose(sc,nodes["floor"],[0,0,-0.02],[0,0,0,1])
    bodies=[(obj["name"], bid) for obj in OBJECTS for bid in [_add_body(c,sc,nodes,obj)] if bid is not None]
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bodies:
            pp,oo=pb.getBasePositionAndOrientation(bid, physicsClientId=c); _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc, flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
'''


def generate_sample_from_experiment(experiment: str, seed: int, out_dir: str):
    from simulations.kubric_3d._base import Physics, Renderer, run_loop, save_sample
    import pybullet as pb
    params = build_params(experiment, seed)
    phys = Physics(); ren = Renderer(params.camera_eye, params.camera_target); dyn=[]
    phys.add_plane(friction=0.55); ren.add_plane_mesh("floor", params.floor_size, [0.42,0.42,0.45,1.0])
    for obj in params.objects:
        orn = pb.getQuaternionFromEuler(obj.get("orn_euler", [0,0,0])); sh=obj["shape"]
        if obj.get("visual_only"):
            if sh == "sphere": ren.add_sphere(obj["name"], obj["radius"], obj["color"])
            elif sh == "box": ren.add_box(obj["name"], obj["half_ext"], obj["color"])
            elif sh == "cylinder": ren.add_cylinder(obj["name"], obj["radius"], obj["height"], obj["color"])
            elif sh == "capsule": ren.add_capsule(obj["name"], obj["radius"], obj["height"], obj["color"])
            else: continue
            ren.set_static_pose(obj["name"], obj["pos"], orn)
            continue
        if sh == "sphere": bid=phys.add_sphere(obj["radius"], obj["pos"], mass=obj.get("mass",1.0), friction=obj.get("friction",0.5), restitution=obj.get("restitution",0.5), vel=obj.get("vel",[0,0,0]), ang_vel=obj.get("ang_vel",[0,0,0])); ren.add_sphere(obj["name"], obj["radius"], obj["color"])
        elif sh == "box": bid=phys.add_box(obj["half_ext"], obj["pos"], orn=orn, mass=obj.get("mass",1.0), friction=obj.get("friction",0.5), restitution=obj.get("restitution",0.5), vel=obj.get("vel",[0,0,0]), ang_vel=obj.get("ang_vel",[0,0,0])); ren.add_box(obj["name"], obj["half_ext"], obj["color"])
        elif sh == "cylinder": bid=phys.add_cylinder(obj["radius"], obj["height"], obj["pos"], orn=orn, mass=obj.get("mass",1.0), friction=obj.get("friction",0.5), restitution=obj.get("restitution",0.5), vel=obj.get("vel",[0,0,0]), ang_vel=obj.get("ang_vel",[0,0,0])); ren.add_cylinder(obj["name"], obj["radius"], obj["height"], obj["color"])
        elif sh == "capsule": bid=phys.add_capsule(obj["radius"], obj["height"], obj["pos"], orn=orn, mass=obj.get("mass",1.0), friction=obj.get("friction",0.5), restitution=obj.get("restitution",0.5), vel=obj.get("vel",[0,0,0]), ang_vel=obj.get("ang_vel",[0,0,0])); ren.add_capsule(obj["name"], obj["radius"], obj["height"], obj["color"])
        else: continue
        ren.set_static_pose(obj["name"], obj["pos"], orn); dyn.append((obj["name"], bid))
    frames = run_loop(phys, ren, dyn, N_FRAMES)
    data = asdict(params); data.update(_base_summary(params))
    save_sample(out_dir, data, cot_for_params(params), make_standalone_code(params), frames)
    phys.close(); ren.close()
