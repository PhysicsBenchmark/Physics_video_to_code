"""chain_on_peg — chain balanced over cylindrical peg falls off the heavier side."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (5, -3, 4)
CAM_TARGET = (0, 0, 1.5)
N_FRAMES   = 150


@dataclass
class Params:
    seed:          int
    n_links:       int
    link_radius:   float
    link_half_len: float
    mass_per_link: float
    peg_height:    float
    peg_radius:    float
    offset_n_links: int    # extra links on one side to break symmetry
    floor_friction: float
    chain_color:   List[float]
    peg_color:     List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        n_links=random.randint(16, 26),
        link_radius=random.uniform(0.022, 0.04),
        link_half_len=random.uniform(0.04, 0.07),
        mass_per_link=random.uniform(0.04, 0.10),
        peg_height=random.uniform(1.8, 2.5),
        peg_radius=random.uniform(0.05, 0.10),
        offset_n_links=random.randint(1, 3),
        floor_friction=random.uniform(0.4, 0.7),
        chain_color=[random.uniform(0.45, 0.8), random.uniform(0.35, 0.7),
                     random.uniform(0.2, 0.6), 1.0],
        peg_color=[random.uniform(0.5, 0.8), random.uniform(0.4, 0.65),
                   random.uniform(0.3, 0.55), 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 10.0, [0.42, 0.42, 0.45, 1.0])
    ren.set_static_pose("floor", [0, 0, 0])

    # Static peg (vertical cylinder)
    phys.add_cylinder(p.peg_radius, p.peg_height,
                      [0, 0, p.peg_height / 2],
                      mass=0, friction=0.3, restitution=0.1)
    ren.add_cylinder("peg", p.peg_radius, p.peg_height, p.peg_color)
    ren.set_static_pose("peg", [0, 0, p.peg_height / 2])

    # Two separate chains hanging on each side of the peg, each fixed at peg top
    segment  = p.link_half_len * 2 + p.link_radius * 0.5
    n_right  = (p.n_links + p.offset_n_links) // 2
    n_left   = p.n_links - n_right
    peg_top  = p.peg_height

    # Left side chain
    links_left = phys.create_chain(
        n_links=n_left,
        link_radius=p.link_radius,
        link_half_len=p.link_half_len,
        start_pos=[-p.peg_radius - p.link_radius, 0.0, peg_top],
        mass_per_link=p.mass_per_link,
        friction=0.4, restitution=0.3, max_force=200.0)

    # Right side chain
    links_right = phys.create_chain(
        n_links=n_right,
        link_radius=p.link_radius,
        link_half_len=p.link_half_len,
        start_pos=[p.peg_radius + p.link_radius, 0.0, peg_top],
        mass_per_link=p.mass_per_link,
        friction=0.4, restitution=0.3, max_force=200.0)

    # Fix tops of both chains to peg top (one on each side)
    pb_mod.createConstraint(links_left[0], -1, -1, -1,
        pb_mod.JOINT_FIXED, [0, 0, 0], [0, 0, 0],
        [-p.peg_radius - p.link_radius, 0.0, peg_top],
        physicsClientId=phys.client)
    pb_mod.createConstraint(links_right[0], -1, -1, -1,
        pb_mod.JOINT_FIXED, [0, 0, 0], [0, 0, 0],
        [p.peg_radius + p.link_radius, 0.0, peg_top],
        physicsClientId=phys.client)

    chain_ids = links_left + links_right

    for i in range(len(chain_ids)):
        ren.add_capsule(f"link{i}", p.link_radius, p.link_half_len * 2, p.chain_color)

    dyn = [(f"link{i}", bid) for i, bid in enumerate(chain_ids)]
    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="chain_on_peg",
        category="rope_chain",
        seed=seed,
        physical_observation=(
            f"Chain of {p.n_links} links draped over peg (r={p.peg_radius:.2f}m, "
            f"h={p.peg_height:.2f}m). Left: {n_left} links, Right: {n_right} links "
            f"({p.offset_n_links} extra on right). System falls toward heavier side."),
        law_name="Unbalanced chain on peg — asymmetric Atwood machine",
        law_statement=(
            "Chain draped over peg accelerates toward heavier side; "
            "net force proportional to mass imbalance."),
        law_formula="F_net = (n_right - n_left) * m_per_link * g",
        assumptions=[
            "Peg is frictionless cylinder (approximated).",
            "Chain links are rigid capsules with point joints.",
            "No air resistance.",
        ],
        state_variables=["r_i (m)", "v_i (m/s)", "q_i", "omega_i (rad/s)"],
        equations_latex=[
            r"\dot{r}_i = v_i",
            r"m_{total}\ddot{x} = \Delta m \cdot g",
        ],
        contact_impulse="j = -(1+e)*v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            f"Left side: {n_left} links, mass {n_left*p.mass_per_link:.3f} kg.",
            f"Right side: {n_right} links, mass {n_right*p.mass_per_link:.3f} kg.",
            f"Net force: {(n_right-n_left)*p.mass_per_link*9.81:.3f} N pulls right side down.",
            "Chain slides off peg toward right (heavier) side.",
        ],
        expected_behavior=[
            "Chain starts nearly balanced over peg.",
            "Right (heavier) side pulls chain down.",
            "Chain falls completely off peg to the right.",
        ],
        parameters={
            "n_links":           param_entry(p.n_links, "", "Total links"),
            "link_radius_m":     param_entry(p.link_radius, "m", "Link radius"),
            "link_half_len_m":   param_entry(p.link_half_len, "m", "Link half-length"),
            "mass_per_link_kg":  param_entry(p.mass_per_link, "kg", "Mass per link"),
            "peg_height_m":      param_entry(p.peg_height, "m", "Peg height"),
            "peg_radius_m":      param_entry(p.peg_radius, "m", "Peg radius"),
            "offset_n_links":    param_entry(p.offset_n_links, "", "Extra links on heavy side"),
            "n_left":            param_entry(n_left, "", "Links on left"),
            "n_right":           param_entry(n_right, "", "Links on right"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    segment = p.link_half_len * 2 + p.link_radius * 0.5
    n_right = (p.n_links + p.offset_n_links) // 2
    n_left  = p.n_links - n_right
    off     = p.link_half_len + p.link_radius * 0.25
    peg_top = p.peg_height
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# chain_on_peg  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[5.0,5.0,0.02],[0.42,0.42,0.45,1.0]); _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    ph={p.peg_height}; pr={p.peg_radius}
    s=pb.createCollisionShape(pb.GEOM_CYLINDER,radius=pr,height=ph,physicsClientId=c)
    pb.createMultiBody(0,s,-1,[0,0,ph/2],[0,0,0,1],physicsClientId=c)
    _add_cylinder(sc,"peg",nodes,pr,ph,{p.peg_color}); _set_pose(sc,nodes["peg"],[0,0,ph/2],[0,0,0,1])
    lr={p.link_radius}; lhl={p.link_half_len}; seg={segment}; off_={off}
    n_left={n_left}; n_right={n_right}; peg_top={peg_top}
    chain_ids=[]
    cap_shape=pb.createCollisionShape(pb.GEOM_CAPSULE,radius=lr,height=lhl*2,physicsClientId=c)
    for i in range(n_left):
        z=peg_top-(n_left-i)*seg; pos=[-pr-lr,0.0,max(z,lr+0.01)]
        bid=pb.createMultiBody({p.mass_per_link},cap_shape,-1,pos,[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction=0.4,restitution=0.3,linearDamping=0.05,angularDamping=0.1,physicsClientId=c)
        if chain_ids:
            cid=pb.createConstraint(chain_ids[-1],-1,bid,-1,pb.JOINT_POINT2POINT,[0,0,1],[0,0,-off_],[0,0,off_],physicsClientId=c)
            pb.changeConstraint(cid,maxForce=200.0,physicsClientId=c)
        chain_ids.append(bid)
    for i in range(n_right):
        z=peg_top-i*seg; pos=[pr+lr,0.0,max(z,lr+0.01)]
        bid=pb.createMultiBody({p.mass_per_link},cap_shape,-1,pos,[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction=0.4,restitution=0.3,linearDamping=0.05,angularDamping=0.1,physicsClientId=c)
        cid=pb.createConstraint(chain_ids[-1],-1,bid,-1,pb.JOINT_POINT2POINT,[0,0,1],[0,0,-off_],[0,0,off_],physicsClientId=c)
        pb.changeConstraint(cid,maxForce=200.0,physicsClientId=c)
        chain_ids.append(bid)
    for i in range({p.n_links}): _add_capsule(sc,f"link{{i}}",nodes,lr,lhl*2,{p.chain_color})
    bids=[(f"link{{i}}",bid) for i,bid in enumerate(chain_ids)]; frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_chain_on_peg")
    print("OK")
