"""multi_chain_collision — two chains swing toward each other and collide mid-air."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (6, -4, 4)
CAM_TARGET = (0, 0, 2)
N_FRAMES   = 180


@dataclass
class Params:
    seed: int
    n_links: int
    link_radius: float
    link_half_len: float
    mass_per_link: float
    chain_sep: float
    pivot_height: float
    init_swing_vel: float
    floor_friction: float
    restitution: float
    color_a: List[float]
    color_b: List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        n_links=random.randint(6, 10),
        link_radius=random.uniform(0.04, 0.08),
        link_half_len=random.uniform(0.10, 0.18),
        mass_per_link=random.uniform(0.05, 0.2),
        chain_sep=random.uniform(2.5, 4.0),
        pivot_height=random.uniform(3.5, 5.0),
        init_swing_vel=random.uniform(1.0, 2.5),
        floor_friction=random.uniform(0.4, 0.7),
        restitution=random.uniform(0.3, 0.6),
        color_a=_rand_hue(),
        color_b=_rand_hue(),
    )


def _rand_hue():
    h = random.random(); s, v = 0.85, 0.90
    hi = int(h*6) % 6; f = h*6 - int(h*6)
    p_ = v*(1-s); q = v*(1-f*s); t = v*(1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return [r, g, b, 1.0]


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 12.0, [0.42, 0.42, 0.45, 1.0])

    half_sep = p.chain_sep / 2.0

    # Chain A: fixed pivot at (-half_sep, 0, pivot_height), displaced +X
    ax, az = -half_sep, p.pivot_height
    anc_a = phys.add_sphere(0.05, [ax, 0.0, az], mass=0.0)
    phys.fix_body(anc_a, pos=[ax, 0.0, az])
    ren.add_sphere("anc_a", 0.05, [0.7, 0.7, 0.7, 1.0])
    ren.set_static_pose("anc_a", [ax, 0.0, az])

    links_a = phys.create_chain(p.n_links, p.link_radius, p.link_half_len,
                                 [ax, 0.0, az], mass_per_link=p.mass_per_link,
                                 friction=p.floor_friction, restitution=p.restitution)
    phys.create_constraint(anc_a, -1, links_a[0], -1,
                            pb_mod.JOINT_POINT2POINT, [0, 0, 0],
                            [0.0, 0.0, 0.0], [0.0, 0.0, p.link_half_len + p.link_radius * 0.25],
                            max_force=300.0)
    seg = p.link_half_len * 2 + p.link_radius * 0.5
    for i, lid in enumerate(links_a):
        nm = f"la{i}"
        lz = az - i * seg
        ren.add_capsule(nm, p.link_radius, p.link_half_len * 2, p.color_a)
        ren.set_static_pose(nm, [ax, 0.0, lz])
        phys.create_constraint(anc_a, -1, lid, -1,
                                pb_mod.JOINT_POINT2POINT, [0, 0, 0],
                                [0, 0, 0], [0, 0, 0], max_force=0.01) if False else None
    # give chain A initial velocity toward +X (toward center)
    # gradient from top (0) to bottom (full velocity) to avoid chain snap
    import pybullet as _pb
    n_a = len(links_a)
    for i, lid in enumerate(links_a):
        frac = (i + 1) / (n_a + 1)
        _pb.resetBaseVelocity(lid, [p.init_swing_vel * frac, 0.0, 0.0],
                               [0.0, 0.0, 0.0], physicsClientId=phys.client)

    # Chain B: fixed pivot at (+half_sep, 0, pivot_height), displaced -X
    bx = half_sep
    anc_b = phys.add_sphere(0.05, [bx, 0.0, az], mass=0.0)
    phys.fix_body(anc_b, pos=[bx, 0.0, az])
    ren.add_sphere("anc_b", 0.05, [0.7, 0.7, 0.7, 1.0])
    ren.set_static_pose("anc_b", [bx, 0.0, az])

    links_b = phys.create_chain(p.n_links, p.link_radius, p.link_half_len,
                                 [bx, 0.0, az], mass_per_link=p.mass_per_link,
                                 friction=p.floor_friction, restitution=p.restitution)
    phys.create_constraint(anc_b, -1, links_b[0], -1,
                            pb_mod.JOINT_POINT2POINT, [0, 0, 0],
                            [0.0, 0.0, 0.0], [0.0, 0.0, p.link_half_len + p.link_radius * 0.25],
                            max_force=300.0)
    for i, lid in enumerate(links_b):
        nm = f"lb{i}"
        lz = az - i * seg
        ren.add_capsule(nm, p.link_radius, p.link_half_len * 2, p.color_b)
        ren.set_static_pose(nm, [bx, 0.0, lz])
    n_b = len(links_b)
    for i, lid in enumerate(links_b):
        frac = (i + 1) / (n_b + 1)
        _pb.resetBaseVelocity(lid, [-p.init_swing_vel * frac, 0.0, 0.0],
                               [0.0, 0.0, 0.0], physicsClientId=phys.client)

    dyn = ([(f"la{i}", lid) for i, lid in enumerate(links_a)] +
           [(f"lb{i}", lid) for i, lid in enumerate(links_b)])
    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="multi_chain_collision",
        category="rope_chain",
        seed=seed,
        physical_observation=(
            f"Two {p.n_links}-link chains swing from pivots at x=±{half_sep:.2f}m, "
            f"height={p.pivot_height:.2f}m; each given initial velocity {p.init_swing_vel:.1f} m/s "
            f"toward center; links collide and entangle."
        ),
        law_name="Newton-Euler rigid-body dynamics + constraint impulse",
        law_statement=(
            "Chains swing as multi-body pendulums; link-to-link constraints transmit tension; "
            "collision impulses scatter and entangle the chains at center."
        ),
        law_formula="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        assumptions=[
            "Rigid capsule links with point-to-point joint constraints",
            "Coulomb friction at floor contacts",
            "Pivots are fixed kinematically",
            "No air resistance or rope elasticity beyond constraint stiffness",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg+T_{constraint}+F_c",
            "I\\dot{\\omega}=\\tau_c-\\omega\\times I\\omega",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B + cross_terms)",
        derivation_steps=[
            f"Chain A swings from x={-half_sep:.2f}m toward center with v_0={p.init_swing_vel:.1f} m/s",
            f"Chain B swings from x={+half_sep:.2f}m toward center with v_0={-p.init_swing_vel:.1f} m/s",
            "Chains meet near center; link-link collision impulses exchange momentum",
            "Entanglement arises from high angular momenta after impact",
        ],
        expected_behavior=[
            "Both chains swing inward simultaneously",
            "Links collide near the center at approximately half-travel time",
            "Chains entangle and wrap around each other",
            "System eventually settles under gravity and friction",
        ],
        parameters={
            "n_links":        param_entry(p.n_links,        "",    "number of links per chain"),
            "link_radius":    param_entry(p.link_radius,    "m",   "capsule radius of each link"),
            "link_half_len":  param_entry(p.link_half_len,  "m",   "half-length of each link"),
            "mass_per_link":  param_entry(p.mass_per_link,  "kg",  "mass per link"),
            "chain_sep":      param_entry(p.chain_sep,      "m",   "distance between the two pivot points"),
            "pivot_height":   param_entry(p.pivot_height,   "m",   "height of chain pivots above floor"),
            "init_swing_vel": param_entry(p.init_swing_vel, "m/s", "initial lateral velocity of each chain"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    half_sep = p.chain_sep / 2.0
    seg = p.link_half_len * 2 + p.link_radius * 0.5
    off = p.link_half_len + p.link_radius * 0.25
    az = p.pivot_height

    def chain_lines(prefix, px, vel_x, color):
        lines = []
        lines.append(
            f"    sa_{prefix}=pb.createCollisionShape(pb.GEOM_SPHERE,radius=0.05,physicsClientId=c)\n"
            f"    anc_{prefix}=pb.createMultiBody(0,sa_{prefix},-1,[{px:.3f},0,{az:.3f}],[0,0,0,1],physicsClientId=c)\n"
            f"    pb.createConstraint(anc_{prefix},-1,-1,-1,pb.JOINT_FIXED,[0,0,0],[0,0,0],[{px:.3f},0,{az:.3f}],physicsClientId=c)\n"
            f"    _add_sphere(sc,'anc_{prefix}',nodes,0.05,[0.7,0.7,0.7,1.0])\n"
            f"    _set_pose(sc,nodes['anc_{prefix}'],[{px:.3f},0,{az:.3f}],[0,0,0,1])\n"
        )
        prev = f"anc_{prefix}"
        for i in range(p.n_links):
            lz = az - i * seg
            nm = f"l{prefix}{i}"
            lines.append(
                f"    sl=pb.createCollisionShape(pb.GEOM_CAPSULE,radius={p.link_radius},height={p.link_half_len*2},physicsClientId=c)\n"
                f"    {nm}=pb.createMultiBody({p.mass_per_link},sl,-1,[{px:.3f},0,{lz:.3f}],[0,0,0,1],physicsClientId=c)\n"
                f"    pb.changeDynamics({nm},-1,lateralFriction={p.floor_friction},restitution={p.restitution},linearDamping=0.05,angularDamping=0.1,physicsClientId=c)\n"
                f"    pb.resetBaseVelocity({nm},[{vel_x},0,0],[0,0,0],physicsClientId=c)\n"
                f"    _add_capsule(sc,'{nm}',nodes,{p.link_radius},{p.link_half_len*2},{color})\n"
                f"    _set_pose(sc,nodes['{nm}'],[{px:.3f},0,{lz:.3f}],[0,0,0,1])\n"
            )
            if i == 0:
                lines.append(
                    f"    pb.createConstraint(anc_{prefix},-1,{nm},-1,pb.JOINT_POINT2POINT,[0,0,0],[0,0,0],[0,0,{off:.3f}],physicsClientId=c)\n"
                )
            else:
                prev_nm = f"l{prefix}{i-1}"
                lines.append(
                    f"    pb.createConstraint({prev_nm},-1,{nm},-1,pb.JOINT_POINT2POINT,[0,0,0],[0,0,{-off:.3f}],[0,0,{off:.3f}],physicsClientId=c)\n"
                )
        return "".join(lines)

    code_a = chain_lines("a", -half_sep, p.init_swing_vel, p.color_a)
    code_b = chain_lines("b",  half_sep, -p.init_swing_vel, p.color_b)
    bids_a = "+".join([f"[('la{i}',la{i})]" for i in range(p.n_links)])
    bids_b = "+".join([f"[('lb{i}',lb{i})]" for i in range(p.n_links)])

    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# multi_chain_collision  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[6.0,6.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
{code_a}{code_b}    bids={bids_a}+{bids_b}
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete()
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_multi_chain_collision")
    print("OK")
