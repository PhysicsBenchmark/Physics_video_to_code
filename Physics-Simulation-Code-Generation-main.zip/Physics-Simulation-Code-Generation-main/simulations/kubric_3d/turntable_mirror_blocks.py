"""turntable_mirror_blocks — blocks on a spinning disc demonstrate the centripetal-friction limit.

A solid cylindrical turntable rotates about the vertical axis at a constant
angular velocity omega.  Three mirror-symmetric pairs of identical blocks
sit on its surface at three different radii: a green pair near the centre,
a yellow pair at intermediate radius, and a red pair near the rim.

While a block stays at radius r the surface friction must supply its
centripetal force m omega^2 r.  Coulomb friction caps that force at mu m g,
so blocks slip outward whenever r > r_crit = mu g / omega^2.  In the clip the
inner two pairs (r << r_crit) ride along with the disc indefinitely, while
the outer pair (r > r_crit) drifts outward, slides off the rim, and falls to
the floor — a clean visual demonstration of the friction-limited orbit.
"""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np


CAM_EYE    = (2.4, -2.6, 3.2)
CAM_TARGET = (0.0,  0.0, 0.18)
N_FRAMES   = 150
FPS        = 30
G          = 9.81


@dataclass
class Params:
    seed: int
    turntable_radius: float
    turntable_height: float
    turntable_omega: float
    turntable_friction: float
    block_half: List[float]
    block_mass: float
    block_friction: float
    block_radii:  List[float]
    block_angles: List[float]
    block_colors: List[List[float]]
    floor_color: List[float]
    turntable_color: List[float]
    marker_color: List[float]


def random_params(seed: int) -> Params:
    rng = random.Random(seed)
    turntable_friction = 1.0                                 # disc kept "grippy"
    block_friction     = 0.40                                # contact mu = 1.0 * 0.40 = 0.40
    omega = rng.uniform(2.7, 3.3)                            # rad/s

    # Three mirror pairs of radii: well-inside, mid-inside, well-outside r_crit.
    r_inner  = rng.uniform(0.12, 0.18)                       # << r_crit
    r_middle = rng.uniform(0.27, 0.34)                       # < r_crit
    r_outer  = rng.uniform(0.48, 0.56)                       # > r_crit -> slides off
    th0 = rng.uniform(0.0, math.pi)
    th1 = rng.uniform(0.0, math.pi)
    th2 = rng.uniform(0.0, math.pi)
    radii  = [r_inner, r_inner,
              r_middle, r_middle,
              r_outer, r_outer]
    angles = [th0,            th0 + math.pi,
              th1 + 0.4,      th1 + 0.4 + math.pi,
              th2 + 0.8,      th2 + 0.8 + math.pi]
    green  = [0.20, 0.72, 0.34, 1.0]
    yellow = [0.94, 0.74, 0.18, 1.0]
    red    = [0.85, 0.18, 0.14, 1.0]
    colors = [green, green, yellow, yellow, red, red]

    return Params(
        seed=seed,
        turntable_radius=0.70,
        turntable_height=0.06,
        turntable_omega=omega,
        turntable_friction=turntable_friction,
        block_half=[0.06, 0.06, 0.05],
        block_mass=0.18,
        block_friction=block_friction,
        block_radii=radii,
        block_angles=angles,
        block_colors=colors,
        floor_color=[0.42, 0.42, 0.45, 1.0],
        turntable_color=[0.30, 0.32, 0.36, 1.0],
        marker_color=[0.95, 0.85, 0.20, 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, save_sample, build_cot, param_entry,
        STEP_RATE, metadata_only)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)
    phys.add_plane(friction=0.5)
    ren.add_plane_mesh("floor", 5.0, p.floor_color)

    # --- Turntable ----------------------------------------------------------
    # Kinematic body: mass=0 so PyBullet does not integrate motion, but we
    # update its pose AND base velocity each substep so the contact-friction
    # solver feels the spinning surface.
    turntable_z = p.turntable_height / 2.0
    turntable_id = phys.add_cylinder(
        p.turntable_radius, p.turntable_height,
        [0.0, 0.0, turntable_z], mass=0,
        friction=p.turntable_friction, restitution=0.0)
    ren.add_cylinder("turntable", p.turntable_radius, p.turntable_height, p.turntable_color)
    ren.set_static_pose("turntable", [0.0, 0.0, turntable_z])

    # Visual marker — a thin radial bar laid on top of the turntable so the
    # rotation is unambiguous to the viewer.  No collision; rendered only.
    marker_len = p.turntable_radius * 0.9
    marker_half = [marker_len / 2.0, 0.012, 0.006]
    ren.add_box("marker", marker_half, p.marker_color)
    ren.set_static_pose(
        "marker",
        [marker_len / 2.0, 0.0, p.turntable_height + marker_half[2]])

    # --- Blocks -------------------------------------------------------------
    block_z = p.turntable_height + p.block_half[2] + 0.001
    block_ids = []
    for i in range(len(p.block_radii)):
        r = p.block_radii[i]; angle = p.block_angles[i]
        bx = r * math.cos(angle)
        by = r * math.sin(angle)
        # Initial velocity matches the turntable surface velocity here
        # (no relative motion at t = 0).
        vx = -p.turntable_omega * by
        vy = +p.turntable_omega * bx
        bid = phys.add_box(
            p.block_half, [bx, by, block_z],
            mass=p.block_mass, friction=p.block_friction,
            restitution=0.0, vel=[vx, vy, 0.0],
            lin_damp=0.05, ang_damp=0.2)
        ren.add_box(f"block_{i}", p.block_half, p.block_colors[i])
        ren.set_static_pose(f"block_{i}", [bx, by, block_z])
        block_ids.append(bid)

    bodies = [(f"block_{i}", bid) for i, bid in enumerate(block_ids)]
    steps_per_frame = STEP_RATE // FPS

    frames = []
    if metadata_only():
        save_sample(out_dir, asdict(p), _build_cot(p, build_cot, param_entry),
                    make_standalone_code(p), frames)
        phys.close(); ren.close(); return

    for fi in range(N_FRAMES):
        for sub in range(steps_per_frame):
            elapsed_steps = fi * steps_per_frame + sub
            theta = p.turntable_omega * elapsed_steps / STEP_RATE
            quat = pb_mod.getQuaternionFromEuler([0.0, 0.0, theta])
            pb_mod.resetBasePositionAndOrientation(
                turntable_id, [0.0, 0.0, turntable_z], quat,
                physicsClientId=phys.client)
            pb_mod.resetBaseVelocity(
                turntable_id, [0.0, 0.0, 0.0],
                [0.0, 0.0, p.turntable_omega],
                physicsClientId=phys.client)
            phys.step()
        # Visual update for the disc and its rotating marker.
        theta_now = p.turntable_omega * (fi + 1) * steps_per_frame / STEP_RATE
        q_now = pb_mod.getQuaternionFromEuler([0.0, 0.0, theta_now])
        ren.set_pose("turntable", [0.0, 0.0, turntable_z], q_now)
        marker_centre = [
            (marker_len / 2.0) * math.cos(theta_now),
            (marker_len / 2.0) * math.sin(theta_now),
            p.turntable_height + marker_half[2],
        ]
        ren.set_pose("marker", marker_centre, q_now)
        for nm, bid in bodies:
            pos, orn = phys.get_pose(bid)
            ren.set_pose(nm, pos, orn)
        frames.append(ren.render_frame())

    save_sample(out_dir, asdict(p), _build_cot(p, build_cot, param_entry),
                make_standalone_code(p), frames)
    phys.close(); ren.close()


def _build_cot(p: Params, build_cot, param_entry):
    mu_eff = p.turntable_friction * p.block_friction
    r_crit = mu_eff * G / (p.turntable_omega * p.turntable_omega)
    sorted_radii = sorted(set(p.block_radii))
    inner_r, middle_r, outer_r = sorted_radii[0], sorted_radii[1], sorted_radii[2]
    return build_cot(
        simulation="turntable_mirror_blocks",
        category="rotational_friction_limit",
        seed=p.seed,
        physical_observation=(
            f"A turntable of radius R={p.turntable_radius:.2f} m spins about the vertical "
            f"axis at omega={p.turntable_omega:.2f} rad/s.  Three mirror pairs of identical "
            f"blocks (m={p.block_mass:.3f} kg each) ride at radii r_in={inner_r:.2f} m, "
            f"r_mid={middle_r:.2f} m, r_out={outer_r:.2f} m.  Contact friction "
            f"mu_eff={mu_eff:.2f} sets the critical orbit radius "
            f"r_crit = mu_eff * g / omega^2 = {r_crit:.3f} m: blocks at r < r_crit ride "
            f"with the disc, blocks at r > r_crit slide outward and fly off the rim."
        ),
        law_name="Centripetal force from contact friction (and its Coulomb upper bound)",
        law_statement=(
            "An object on a rotating surface at radius r and angular speed omega requires "
            "a centripetal force F_c = m omega^2 r directed toward the axis.  The only "
            "horizontal force available is friction with the disc, capped by mu m g.  The "
            "block stays in circular motion if and only if omega^2 r <= mu g, equivalently "
            "r <= r_crit = mu g / omega^2.  Above this threshold the block slips outward "
            "and the kinetic friction is no longer sufficient to keep it on the disc."
        ),
        law_formula="F_c = m omega^2 r;  |F_c| <= mu m g  =>  r <= r_crit = mu g / omega^2",
        assumptions=[
            "Turntable is a kinematic rigid body: pose and angular velocity are reset each "
            "substep, but PyBullet still computes contact friction against this moving "
            "surface (relative velocity at the contact point includes omega x r).",
            "Blocks are rigid; gravity 9.81 m/s^2; no air drag.",
            "Coulomb friction; PyBullet combines the two surface friction values by product, "
            "so mu_eff = mu_turntable * mu_block.",
            "Restitution is zero so blocks remain in contact with the disc until they slip "
            "off the rim.",
            "PyBullet integrates contacts at 240 Hz.",
        ],
        state_variables=["block positions r_i", "block velocities v_i",
                         "turntable orientation theta(t) = omega t"],
        equations_latex=[
            "F_{\\text{c}} = m\\,\\omega^2\\,r",
            "|F_{\\text{c}}| \\le \\mu\\,m\\,g \\;\\Longrightarrow\\; r \\le r_{\\text{crit}} = \\dfrac{\\mu g}{\\omega^2}",
            "\\theta(t) = \\omega t",
        ],
        contact_impulse="j_n = -(1+e)(v_rel . n)/m_eff;  |j_t| <= mu |j_n|",
        derivation_steps=[
            f"Contact friction coefficient: mu_eff = mu_table * mu_block "
            f"= {p.turntable_friction:.2f} * {p.block_friction:.2f} = {mu_eff:.3f}.",
            f"Critical radius: r_crit = mu_eff * g / omega^2 = "
            f"{mu_eff:.3f} * {G:.2f} / {p.turntable_omega:.2f}^2 = {r_crit:.3f} m.",
            f"Inner pair (r = {inner_r:.3f} m): r << r_crit -> blocks stay on the disc.",
            f"Middle pair (r = {middle_r:.3f} m): r < r_crit -> blocks stay on the disc.",
            f"Outer pair (r = {outer_r:.3f} m): r > r_crit -> blocks drift outward, slide "
            f"off the rim, and fall to the floor.",
        ],
        expected_behavior=[
            "The disc rotates steadily; the yellow marker traces a circle so the rotation "
            "is unambiguous to the viewer.",
            "Inner (green) and middle (yellow) pairs stay at constant radii on the disc.",
            "Outer (red) pair slides outward in the disc frame and flies off the rim onto "
            "the floor before t = 5 s.",
            "All pairs move continuously throughout the clip.",
        ],
        parameters={
            "turntable_radius":  param_entry(p.turntable_radius,  "m",     "disc radius"),
            "turntable_omega":   param_entry(p.turntable_omega,   "rad/s", "angular speed"),
            "mu_eff":            param_entry(mu_eff,              "",      "contact friction (mu_table * mu_block)"),
            "r_crit":            param_entry(r_crit,              "m",     "critical orbit radius"),
            "block_radii":       param_entry(p.block_radii,       "m",     "block initial radii"),
            "block_mass":        param_entry(p.block_mass,        "kg",    "block mass"),
        })


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# turntable_mirror_blocks  seed={p.seed}
import pybullet as pb
N_FRAMES = {N_FRAMES}; CAM_EYE = {CAM_EYE}; CAM_TARGET = {CAM_TARGET}
TT_R = {p.turntable_radius}; TT_H = {p.turntable_height}; TT_OMEGA = {p.turntable_omega}
TT_FR = {p.turntable_friction}
BLOCK_HALF = {p.block_half}; BLOCK_MASS = {p.block_mass}; BLOCK_FR = {p.block_friction}
BLOCK_RADII  = {p.block_radii}
BLOCK_ANGLES = {p.block_angles}
BLOCK_COLORS = {p.block_colors}
FLOOR_COLOR = {p.floor_color}; TT_COLOR = {p.turntable_color}
MARKER_COLOR = {p.marker_color}

def main():
    c = _init_physics(); ren, sc = _make_renderer(CAM_EYE, CAM_TARGET); nodes = {{}}
    pb.loadURDF("plane.urdf", [0, 0, 0], physicsClientId=c)
    _add_box(sc, "floor", nodes, [2.5, 2.5, 0.02], FLOOR_COLOR)
    _set_pose(sc, nodes["floor"], [0, 0, -0.02], [0, 0, 0, 1])

    tt_z = TT_H / 2.0
    tsh = pb.createCollisionShape(pb.GEOM_CYLINDER, radius=TT_R, height=TT_H,
                                    physicsClientId=c)
    tt = pb.createMultiBody(0, tsh, -1, [0, 0, tt_z], [0, 0, 0, 1], physicsClientId=c)
    pb.changeDynamics(tt, -1, lateralFriction=TT_FR, restitution=0.0, physicsClientId=c)
    _add_cylinder(sc, "turntable", nodes, TT_R, TT_H, TT_COLOR)
    _set_pose(sc, nodes["turntable"], [0, 0, tt_z], [0, 0, 0, 1])

    marker_len = TT_R * 0.9
    marker_half = [marker_len / 2.0, 0.012, 0.006]
    _add_box(sc, "marker", nodes, marker_half, MARKER_COLOR)
    _set_pose(sc, nodes["marker"],
              [marker_len / 2.0, 0.0, TT_H + marker_half[2]], [0, 0, 0, 1])

    block_z = TT_H + BLOCK_HALF[2] + 0.001
    blocks = []
    for i in range(len(BLOCK_RADII)):
        r = BLOCK_RADII[i]; angle = BLOCK_ANGLES[i]
        bx = r * math.cos(angle); by = r * math.sin(angle)
        vx = -TT_OMEGA * by; vy = +TT_OMEGA * bx
        bsh = pb.createCollisionShape(pb.GEOM_BOX, halfExtents=BLOCK_HALF,
                                        physicsClientId=c)
        bid = pb.createMultiBody(BLOCK_MASS, bsh, -1, [bx, by, block_z], [0, 0, 0, 1],
                                  physicsClientId=c)
        pb.changeDynamics(bid, -1, lateralFriction=BLOCK_FR, restitution=0.0,
                           linearDamping=0.05, angularDamping=0.2, physicsClientId=c)
        pb.resetBaseVelocity(bid, [vx, vy, 0], [0, 0, 0], physicsClientId=c)
        nm = f"block_{{i}}"
        _add_box(sc, nm, nodes, BLOCK_HALF, BLOCK_COLORS[i])
        _set_pose(sc, nodes[nm], [bx, by, block_z], [0, 0, 0, 1])
        blocks.append((nm, bid))

    spf = STEP_RATE // 30
    frames = []
    for fi in range(N_FRAMES):
        for sub in range(spf):
            elapsed = fi * spf + sub
            theta = TT_OMEGA * elapsed / STEP_RATE
            q = pb.getQuaternionFromEuler([0, 0, theta])
            pb.resetBasePositionAndOrientation(tt, [0, 0, tt_z], q, physicsClientId=c)
            pb.resetBaseVelocity(tt, [0, 0, 0], [0, 0, TT_OMEGA], physicsClientId=c)
            pb.stepSimulation(physicsClientId=c)
        theta_now = TT_OMEGA * (fi + 1) * spf / STEP_RATE
        q_now = pb.getQuaternionFromEuler([0, 0, theta_now])
        _set_pose(sc, nodes["turntable"], [0, 0, tt_z], q_now)
        mc = [(marker_len / 2.0) * math.cos(theta_now),
              (marker_len / 2.0) * math.sin(theta_now),
              TT_H + marker_half[2]]
        _set_pose(sc, nodes["marker"], mc, q_now)
        for nm, bid in blocks:
            pp, oo = pb.getBasePositionAndOrientation(bid, physicsClientId=c)
            _set_pose(sc, nodes[nm], pp, oo)
        rgba, _ = ren.render(sc, flags=pyrender.RenderFlags.RGBA)
        frames.append(rgba[:,:,:3])
    _save_video(frames, "video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")

if __name__ == "__main__":
    main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_turntable_mirror_blocks")
    print("OK")
