"""block_wall_hit_by_tethered_mass — wrecking-ball pendulum strikes a stacked block wall.

The ball is a real PyBullet pendulum: a JOINT_POINT2POINT constraint between a static
anchor at the pivot and the ball forces |r_ball - r_pivot| = L throughout the swing.
The tether is rendered each frame as a thin cylinder between the pivot and the ball.

The block wall is 4×3 = 12 boxes stacked with proper edge-to-edge alignment (a tiny
1mm gap to keep PyBullet's penetration solver from launching the wall apart on frame 1)."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (4.0, -4.5, 2.5)
CAM_TARGET = (-0.2,  0.0, 0.6)
N_FRAMES   = 180


@dataclass
class Params:
    seed: int
    L: float
    pivot_x: float
    pivot_z: float
    theta0_deg: float
    ball_r: float
    ball_mass: float
    block_mass: float
    block_friction: float
    block_restitution: float
    ball_color: List[float]
    block_colors: List[List[float]]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    def _hue():
        h = random.random(); s, v = 0.85, 0.90; hi = int(h*6) % 6; f = h*6 - int(h*6)
        p_ = v*(1-s); q = v*(1-f*s); t = v*(1-(1-f)*s)
        r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
        return [r, g, b, 1.0]
    return Params(
        seed=seed,
        L=1.60,
        pivot_x=-1.0,
        pivot_z=1.85,
        theta0_deg=random.uniform(72.0, 86.0),
        ball_r=0.16,
        ball_mass=random.uniform(0.7, 1.2),
        block_mass=random.uniform(0.25, 0.45),
        block_friction=0.6,
        block_restitution=0.20,
        ball_color=[0.85, 0.18, 0.14, 1.0],
        block_colors=[_hue() for _ in range(12)],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        STANDALONE_IMPORTS, STANDALONE_UTILS, FPS)
    import pybullet as pb_mod

    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=0.7)
    ren.add_plane_mesh("floor", 8.0, [0.42, 0.42, 0.45, 1.0])
    ren.set_static_pose("floor", [0, 0, -0.02])

    pivot = [p.pivot_x, 0.0, p.pivot_z]

    # Support gantry: pole at y=-0.6 (OUT of the swing plane), horizontal arm reaches to pivot.
    # All elements have static (mass=0) PyBullet bodies so they're real rigid obstacles.
    support_y   = -0.6
    base_he     = [0.16, 0.16, 0.04]
    pole_r      = 0.045
    pole_h      = p.pivot_z - 2 * base_he[2]
    pole_z      = 2 * base_he[2] + pole_h / 2
    arm_r       = 0.045
    arm_len     = abs(support_y)
    arm_y       = support_y / 2
    q_y_axis    = [math.sin(math.pi/4), 0.0, 0.0, math.cos(math.pi/4)]   # 90° around X → cyl axis Y

    phys.add_box(base_he, [p.pivot_x, support_y, base_he[2]], mass=0.0,
                 friction=0.5, restitution=0.05)
    ren.add_box("base", base_he, [0.55, 0.45, 0.32, 1.0])
    ren.set_static_pose("base", [p.pivot_x, support_y, base_he[2]])

    phys.add_cylinder(pole_r, pole_h, [p.pivot_x, support_y, pole_z], mass=0.0,
                      friction=0.5, restitution=0.05)
    ren.add_cylinder("post", pole_r, pole_h, [0.50, 0.42, 0.32, 1.0])
    ren.set_static_pose("post", [p.pivot_x, support_y, pole_z])

    phys.add_cylinder(arm_r, arm_len, [p.pivot_x, arm_y, p.pivot_z], orn=q_y_axis,
                      mass=0.0, friction=0.5, restitution=0.05)
    ren.add_cylinder("arm", arm_r, arm_len, [0.50, 0.42, 0.32, 1.0])
    ren.set_static_pose("arm", [p.pivot_x, arm_y, p.pivot_z], q_y_axis)

    ren.add_sphere("pivot_m", 0.05, [0.85, 0.85, 0.85, 1.0])
    ren.set_static_pose("pivot_m", pivot)

    # Static anchor body at pivot (mass=0 → static automatically; no JOINT_FIXED needed)
    anchor_id = phys.add_sphere(0.02, pivot, mass=0.0, friction=0.0, restitution=0.0)

    # Ball lifted to angle θ₀ to the LEFT of pivot, released from rest
    theta = math.radians(p.theta0_deg)
    bx = p.pivot_x - p.L * math.sin(theta)
    bz = p.pivot_z - p.L * math.cos(theta)
    ball_pos = [bx, 0.0, bz]

    ball_id = phys.add_sphere(p.ball_r, ball_pos, mass=p.ball_mass,
                              friction=0.4, restitution=0.5,
                              lin_damp=0.0, ang_damp=0.05)

    # JOINT_POINT2POINT: anchor centre ≡ ball CoM + child_offset_in_ball_frame
    # ball_orn=identity initially, so child_offset_local = pivot - ball_pos
    pivot_in_ball = [pivot[0]-ball_pos[0], pivot[1]-ball_pos[1], pivot[2]-ball_pos[2]]
    phys.create_constraint(
        anchor_id, -1, ball_id, -1,
        pb_mod.JOINT_POINT2POINT, [0, 0, 0],
        [0.0, 0.0, 0.0], pivot_in_ball,
        max_force=20000.0)

    ren.add_sphere("ball", p.ball_r, p.ball_color)
    ren.set_static_pose("ball", ball_pos)

    # Wall: 4 columns × 3 rows, x range [-0.40, +0.72], z range [0, 0.60]
    blk_half = [0.14, 0.12, 0.10]
    eps = 0.001
    dx  = 2 * blk_half[0] + eps
    dz  = 2 * blk_half[2] + eps
    x0  = -0.40
    block_pairs = []
    cnt = 0
    for j in range(3):
        for i in range(4):
            cx = x0 + blk_half[0] + i * dx
            cz = blk_half[2] + j * dz
            color = p.block_colors[cnt]; cnt += 1
            bid = phys.add_box(blk_half, [cx, 0.0, cz], mass=p.block_mass,
                               friction=p.block_friction, restitution=p.block_restitution,
                               lin_damp=0.05, ang_damp=0.10)
            ren.add_box(f"blk_{i}_{j}", blk_half, color)
            block_pairs.append((f"blk_{i}_{j}", bid))

    str_radius = 0.012
    str_color  = [0.30, 0.22, 0.14, 1.0]
    _ball_id   = ball_id
    _pivot     = pivot

    def extra_sync_fn(phys, ren, fi):
        bp, _ = phys.get_pose(_ball_id)
        ren.update_string("string", _pivot, bp.tolist(), str_radius, str_color)

    dyn = [("ball", ball_id)] + block_pairs
    frames = run_loop(phys, ren, dyn, N_FRAMES, extra_sync_fn=extra_sync_fn)

    g = 9.81
    h_drop  = p.L * (1 - math.cos(theta))
    v_bot   = math.sqrt(2 * g * h_drop)
    v_block = (1 + p.block_restitution) * p.ball_mass * v_bot / (p.ball_mass + p.block_mass)
    cot = build_cot(
        simulation="block_wall_hit_by_tethered_mass",
        category="articulated_jointed",
        seed=seed,
        physical_observation=(
            f"Ball (m={p.ball_mass:.2f}kg, r={p.ball_r:.2f}m) on rope L={p.L:.2f}m released "
            f"from θ₀={p.theta0_deg:.0f}°. Strikes wall of 12 blocks (m={p.block_mass:.2f}kg each)."
        ),
        law_name="Pendulum energy + collision impulse on stacked rigid bodies",
        law_statement=(
            "Pendulum drops PE→KE: v_bot=√(2gL(1-cosθ₀)). On impact, "
            "Newton's restitution gives block speed v'=(1+e)m_b·v_bot/(m_b+m_blk)."
        ),
        law_formula="v_{bot}=\\sqrt{2gL(1-\\cos\\theta_0)};\\quad v_{blk}'=\\frac{(1+e)m_b v_{bot}}{m_b+m_{blk}}",
        assumptions=[
            "Inextensible massless rope: JOINT_POINT2POINT enforces |r-r_pivot|=L.",
            "Rigid blocks with Coulomb friction.",
            "Energy losses through restitution and friction during collision cascade.",
        ],
        state_variables=["θ (rad)", "v (m/s)", "x_block_i (m)", "ω_block_i (rad/s)"],
        equations_latex=[
            "\\ddot{\\theta}=-\\frac{g}{L}\\sin\\theta",
            "v_{bot}^2=2gL(1-\\cos\\theta_0)",
            "v_{blk}'=\\frac{(1+e)m_b v_{bot}}{m_b+m_{blk}}",
        ],
        contact_impulse="j = -(1+e)·v_n / effective_mass",
        derivation_steps=[
            f"Ball drop height: L(1-cosθ₀) = {h_drop:.3f} m",
            f"Bottom speed: v = √(2gh) = {v_bot:.2f} m/s",
            f"Ball KE at bottom: ½mv² = {0.5*p.ball_mass*v_bot**2:.2f} J",
            f"Single-block post-collision speed: {v_block:.2f} m/s",
        ],
        expected_behavior=[
            f"Ball swings from θ₀={p.theta0_deg:.0f}° reaching v={v_bot:.2f}m/s at bottom.",
            "Tether stays attached to ball throughout (PyBullet constraint).",
            "Ball strikes wall on the +x side; first column blown back into stack.",
            "Wall topples; blocks scatter and tumble.",
            "Ball oscillates back after impact with reduced amplitude.",
        ],
        parameters={
            "L":           param_entry(p.L,           "m",  "rope length"),
            "theta0_deg":  param_entry(p.theta0_deg,  "°",  "release angle from vertical"),
            "ball_mass":   param_entry(p.ball_mass,   "kg", "ball mass"),
            "ball_r":      param_entry(p.ball_r,      "m",  "ball radius"),
            "block_mass":  param_entry(p.block_mass,  "kg", "block mass"),
            "n_blocks":    param_entry(12,             "",   "number of blocks (4×3)"),
            "v_bottom":    param_entry(v_bot,         "m/s","ball speed at bottom of swing"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    theta = math.radians(p.theta0_deg)
    bx = p.pivot_x - p.L * math.sin(theta)
    bz = p.pivot_z - p.L * math.cos(theta)
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# block_wall_hit_by_tethered_mass  seed={p.seed}
import math, pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}
PIV_X={p.pivot_x}; PIV_Z={p.pivot_z}; L={p.L}; BR={p.ball_r}; BM={p.ball_mass}
BX={bx}; BZ={bz}
BLK_M={p.block_mass}; BLK_FR={p.block_friction}; BLK_RE={p.block_restitution}
BLK_COLS={p.block_colors}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    plane_bid=pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    pb.changeDynamics(plane_bid,-1,lateralFriction=0.7,physicsClientId=c)
    _add_box(sc,"fl",nodes,[4,4,0.02],[0.42,0.42,0.45,1.0]); _set_pose(sc,nodes["fl"],[0,0,-0.02],[0,0,0,1])
    SY=-0.6; bhe=[0.16,0.16,0.04]; pole_r=0.045; pole_h=PIV_Z-2*bhe[2]; pole_z=2*bhe[2]+pole_h/2
    arm_r=0.045; arm_len=abs(SY); arm_y=SY/2; q_y=[math.sin(math.pi/4),0.0,0.0,math.cos(math.pi/4)]
    sb_=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=bhe,physicsClientId=c)
    pb.createMultiBody(0,sb_,-1,[PIV_X,SY,bhe[2]],[0,0,0,1],physicsClientId=c)
    _add_box(sc,"base",nodes,bhe,[0.55,0.45,0.32,1.0]); _set_pose(sc,nodes["base"],[PIV_X,SY,bhe[2]],[0,0,0,1])
    sc_=pb.createCollisionShape(pb.GEOM_CYLINDER,radius=pole_r,height=pole_h,physicsClientId=c)
    pb.createMultiBody(0,sc_,-1,[PIV_X,SY,pole_z],[0,0,0,1],physicsClientId=c)
    _add_cylinder(sc,"post",nodes,pole_r,pole_h,[0.50,0.42,0.32,1.0]); _set_pose(sc,nodes["post"],[PIV_X,SY,pole_z],[0,0,0,1])
    sa_=pb.createCollisionShape(pb.GEOM_CYLINDER,radius=arm_r,height=arm_len,physicsClientId=c)
    pb.createMultiBody(0,sa_,-1,[PIV_X,arm_y,PIV_Z],q_y,physicsClientId=c)
    _add_cylinder(sc,"arm",nodes,arm_r,arm_len,[0.50,0.42,0.32,1.0]); _set_pose(sc,nodes["arm"],[PIV_X,arm_y,PIV_Z],q_y)
    _add_sphere(sc,"piv",nodes,0.05,[0.85,0.85,0.85,1.0]); _set_pose(sc,nodes["piv"],[PIV_X,0,PIV_Z],[0,0,0,1])
    sa=pb.createCollisionShape(pb.GEOM_SPHERE,radius=0.02,physicsClientId=c)
    anc=pb.createMultiBody(0,sa,-1,[PIV_X,0,PIV_Z],[0,0,0,1],physicsClientId=c)
    sb=pb.createCollisionShape(pb.GEOM_SPHERE,radius=BR,physicsClientId=c)
    ball=pb.createMultiBody(BM,sb,-1,[BX,0,BZ],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(ball,-1,lateralFriction=0.4,restitution=0.5,linearDamping=0.0,angularDamping=0.05,physicsClientId=c)
    cid=pb.createConstraint(anc,-1,ball,-1,pb.JOINT_POINT2POINT,[0,0,0],
        [0,0,0],[PIV_X-BX,0,PIV_Z-BZ],physicsClientId=c)
    pb.changeConstraint(cid,maxForce=20000.0,physicsClientId=c)
    _add_sphere(sc,"ball",nodes,BR,{p.ball_color}); _set_pose(sc,nodes["ball"],[BX,0,BZ],[0,0,0,1])
    he=[0.14,0.12,0.10]; eps=0.001; dx=2*he[0]+eps; dz=2*he[2]+eps; x0=-0.40
    bids=[]; cnt=0
    for j in range(3):
        for i in range(4):
            cx=x0+he[0]+i*dx; cz=he[2]+j*dz
            sb2=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=he,physicsClientId=c)
            bid=pb.createMultiBody(BLK_M,sb2,-1,[cx,0,cz],[0,0,0,1],physicsClientId=c)
            pb.changeDynamics(bid,-1,lateralFriction=BLK_FR,restitution=BLK_RE,linearDamping=0.05,angularDamping=0.10,physicsClientId=c)
            _add_box(sc,f"b{{i}}_{{j}}",nodes,he,BLK_COLS[cnt]); cnt+=1
            bids.append((f"b{{i}}_{{j}}",bid))
    rope=[0.30,0.22,0.14,1.0]; frames=[]
    for fi in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        bp,bo=pb.getBasePositionAndOrientation(ball,physicsClientId=c); _set_pose(sc,nodes["ball"],bp,bo)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c); _set_pose(sc,nodes[nm],pp,oo)
        _update_string(sc,nodes,"str",[PIV_X,0,PIV_Z],list(bp),0.012,rope)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_block_wall_hit_by_tethered_mass")
    print("OK")
