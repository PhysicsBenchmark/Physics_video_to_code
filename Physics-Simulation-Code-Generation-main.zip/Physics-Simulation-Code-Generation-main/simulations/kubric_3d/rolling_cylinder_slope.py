"""rolling_cylinder_slope — cylinder rolls down an inclined slope without slipping."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (5.0, -2.0, 3.0)
CAM_TARGET = (0.0,  0.0, 0.5)
N_FRAMES   = 150  # 5 s @ 30 fps


@dataclass
class Params:
    seed:           int
    ramp_angle_deg: float   # slope inclination (degrees)
    cyl_radius:     float   # cylinder radius (m)
    cyl_height:     float   # cylinder height (m)
    cyl_mass:       float   # kg
    friction:       float   # must be high enough for rolling without slip
    restitution:    float
    cyl_color:      List[float]
    ramp_color:     List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        ramp_angle_deg=random.uniform(10.0, 35.0),
        cyl_radius=random.uniform(0.07, 0.18),
        cyl_height=random.uniform(0.15, 0.40),
        cyl_mass=random.uniform(0.3, 2.0),
        friction=random.uniform(0.5, 0.95),   # high friction for rolling
        restitution=random.uniform(0.2, 0.5),
        cyl_color=[random.uniform(0.4, 0.9), random.uniform(0.3, 0.8),
                   random.uniform(0.2, 0.7), 1.0],
        ramp_color=[0.55, 0.48, 0.38, 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.friction, restitution=p.restitution)
    ren.add_plane_mesh("floor", 10.0, [0.36, 0.36, 0.38, 1.0])
    ren.set_static_pose("floor", [0, 0, 0])

    # Ramp: static tilted box — tilted upward in +X direction
    angle = math.radians(p.ramp_angle_deg)
    ramp_hl = 2.0   # half-length along slope
    ramp_hw = 0.6   # half-width along Y
    ramp_ht = 0.05  # thin slab

    # Rotation around Y: positive angle tilts +X end upward
    ramp_orn = [0.0, math.sin(angle / 2), 0.0, math.cos(angle / 2)]
    ramp_cx = 0.0
    ramp_cz = ramp_hl * math.sin(angle)
    ramp_pos = [ramp_cx, 0.0, ramp_cz]

    phys.add_box([ramp_hl, ramp_hw, ramp_ht], ramp_pos,
                 orn=ramp_orn, mass=0.0, friction=p.friction,
                 restitution=p.restitution)
    ren.add_box("ramp", [ramp_hl, ramp_hw, ramp_ht], p.ramp_color)
    ren.set_static_pose("ramp", ramp_pos, ramp_orn)

    # Cylinder placed at the top of ramp, oriented so its axis is along Y (perpendicular to slope)
    # Initial orientation: cylinder axis along Y, so rotate 90° around X
    cyl_orn = [math.sin(math.pi / 4), 0.0, 0.0, math.cos(math.pi / 4)]
    # Position near the top of the ramp
    top_x = ramp_cx + ramp_hl * math.cos(angle) - p.cyl_radius * 2
    top_z = ramp_cz + ramp_hl * math.sin(angle) + p.cyl_radius + ramp_ht * 2

    bid = phys.add_cylinder(p.cyl_radius, p.cyl_height,
                            [top_x, 0.0, top_z],
                            orn=cyl_orn,
                            mass=p.cyl_mass, friction=p.friction,
                            restitution=p.restitution)
    ren.add_cylinder("cyl", p.cyl_radius, p.cyl_height, p.cyl_color)
    dyn = [("cyl", bid)]

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    # Rolling without slip: a = g*sin(θ) / (1 + I/(m*r²)) = g*sin(θ) * 2/3 for solid cylinder
    a_roll = 9.81 * math.sin(angle) * 2.0 / 3.0
    cot = build_cot(
        simulation="rolling_cylinder_slope",
        category="rigid_body_constrained",
        seed=seed,
        physical_observation=(
            f"Solid cylinder (r={p.cyl_radius:.3f} m, h={p.cyl_height:.3f} m, "
            f"m={p.cyl_mass:.2f} kg) rolls down a {p.ramp_angle_deg:.1f}° slope. "
            f"Rolling acceleration ≈ {a_roll:.2f} m/s² (2/3 g sin θ)."),
        law_name="Rolling without slip on inclined plane",
        law_statement=(
            "Cylinder rolls without slipping; translational and rotational "
            "DOFs coupled by no-slip constraint v=ω*r."),
        law_formula="a = g*sin(θ) / (1 + I_cm/(m*r²)) = (2/3)*g*sin(θ) [solid cylinder]",
        assumptions=[
            "Friction sufficient to prevent slipping: μ ≥ tan(θ)/3.",
            "Cylinder is uniform solid body: I = ½mr².",
            "Ramp is rigid and infinitely massive.",
        ],
        state_variables=["position r (m)", "velocity v (m/s)",
                         "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "a=\\frac{g\\sin\\theta}{1+I/(mr^2)}=\\frac{2}{3}g\\sin\\theta",
            "v=\\omega r\\quad(\\text{no-slip})",
            "I_{cyl}=\\frac{1}{2}mr^2",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            f"Slope angle θ={p.ramp_angle_deg:.1f}°, sin θ={math.sin(angle):.3f}.",
            f"Rolling acceleration a=(2/3)·g·sin θ≈{a_roll:.2f} m/s².",
            f"Compare: sliding (no friction) a=g sin θ={9.81*math.sin(angle):.2f} m/s².",
            f"Cylinder slower than sliding because rotational KE takes share.",
            f"Minimum friction for rolling: μ_min=tan θ/3={math.tan(angle)/3:.3f}; used μ={p.friction:.2f}.",
        ],
        expected_behavior=[
            "Cylinder rolls smoothly down ramp without slipping.",
            f"Reaches floor with v ≈ sqrt(2·a·L) for ramp length L.",
            "After leaving ramp, slides/rolls on floor.",
        ],
        parameters={
            "ramp_angle_deg": param_entry(p.ramp_angle_deg, "deg", "Ramp inclination"),
            "cyl_radius_m":   param_entry(p.cyl_radius,    "m",   "Cylinder radius"),
            "cyl_height_m":   param_entry(p.cyl_height,    "m",   "Cylinder length"),
            "cyl_mass_kg":    param_entry(p.cyl_mass,      "kg",  "Cylinder mass"),
            "friction":       param_entry(p.friction,      "",    "Friction coefficient"),
            "restitution":    param_entry(p.restitution,   "",    "Coefficient of restitution"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    angle = math.radians(p.ramp_angle_deg)
    ramp_hl, ramp_hw, ramp_ht = 2.0, 0.6, 0.05
    ramp_orn = [0.0, math.sin(angle / 2), 0.0, math.cos(angle / 2)]
    ramp_cz = ramp_hl * math.sin(angle)
    ramp_pos = [0.0, 0.0, ramp_cz]
    cyl_orn = [math.sin(math.pi / 4), 0.0, 0.0, math.cos(math.pi / 4)]
    top_x = ramp_hl * math.cos(angle) - p.cyl_radius * 2
    top_z = ramp_cz + ramp_hl * math.sin(angle) + p.cyl_radius + ramp_ht * 2
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# rolling_cylinder_slope  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[5.0,5.0,0.02],[0.36,0.36,0.38,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    ramp_pos={list(ramp_pos)}; ramp_orn={list(ramp_orn)}
    rs=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[{ramp_hl},{ramp_hw},{ramp_ht}],physicsClientId=c)
    pb.createMultiBody(0,rs,-1,ramp_pos,ramp_orn,physicsClientId=c)
    _add_box(sc,"ramp",nodes,[{ramp_hl},{ramp_hw},{ramp_ht}],{p.ramp_color})
    _set_pose(sc,nodes["ramp"],ramp_pos,ramp_orn)
    cyl_orn={list(cyl_orn)}
    cs=pb.createCollisionShape(pb.GEOM_CYLINDER,radius={p.cyl_radius},height={p.cyl_height},physicsClientId=c)
    bid=pb.createMultiBody({p.cyl_mass},cs,-1,[{top_x},0.0,{top_z}],cyl_orn,physicsClientId=c)
    pb.changeDynamics(bid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
    _add_cylinder(sc,"cyl",nodes,{p.cyl_radius},{p.cyl_height},{p.cyl_color})
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
        _set_pose(sc,nodes["cyl"],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_rolling_cylinder_slope")
    print("OK")
