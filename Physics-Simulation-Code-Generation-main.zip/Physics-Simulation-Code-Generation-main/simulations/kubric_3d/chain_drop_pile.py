"""chain_drop_pile — long chain dropped from height, piles up on floor."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (4, -4, 3)
CAM_TARGET = (0, 0, 2)
N_FRAMES   = 150


@dataclass
class Params:
    seed:          int
    n_links:       int
    link_radius:   float
    link_half_len: float
    mass_per_link: float
    drop_height:   float
    floor_friction: float
    chain_color:   List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        n_links=random.randint(15, 25),
        link_radius=random.uniform(0.025, 0.045),
        link_half_len=random.uniform(0.04, 0.08),
        mass_per_link=random.uniform(0.03, 0.10),
        drop_height=random.uniform(3.0, 5.0),
        floor_friction=random.uniform(0.5, 0.8),
        chain_color=[random.uniform(0.4, 0.8), random.uniform(0.35, 0.7),
                     random.uniform(0.2, 0.55), 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 10.0, [0.42, 0.42, 0.45, 1.0])
    ren.set_static_pose("floor", [0, 0, 0])

    chain_ids = phys.create_chain(
        n_links=p.n_links,
        link_radius=p.link_radius,
        link_half_len=p.link_half_len,
        start_pos=[0.0, 0.0, p.drop_height],
        mass_per_link=p.mass_per_link,
        friction=0.5,
        restitution=0.3,
        max_force=200.0)

    for i in range(p.n_links):
        ren.add_capsule(f"link{i}", p.link_radius, p.link_half_len * 2, p.chain_color)

    dyn = [(f"link{i}", bid) for i, bid in enumerate(chain_ids)]
    frames = run_loop(phys, ren, dyn, N_FRAMES)

    total_mass  = p.n_links * p.mass_per_link
    chain_len   = p.n_links * (p.link_half_len * 2 + p.link_radius * 0.5)
    impact_vel  = math.sqrt(2 * 9.81 * p.drop_height)

    cot = build_cot(
        simulation="chain_drop_pile",
        category="rope_chain",
        seed=seed,
        physical_observation=(
            f"Chain of {p.n_links} capsule links (r={p.link_radius:.3f}m, "
            f"half-len={p.link_half_len:.3f}m, mass/link={p.mass_per_link:.3f}kg) "
            f"dropped from height {p.drop_height:.2f}m. Total mass: {total_mass:.3f}kg, "
            f"total chain length: {chain_len:.2f}m."),
        law_name="Free fall + inelastic pile formation",
        law_statement=(
            "Chain in free fall: each link falls with g until floor contact. "
            "On impact, kinetic energy converts to heat/sound; links pile up."),
        law_formula="v_impact = sqrt(2*g*h);  E_k = 0.5*m*v^2",
        assumptions=[
            "Links connected by point constraints (flexible chain).",
            "Floor is rigid with Coulomb friction.",
            "No air resistance.",
        ],
        state_variables=["r_i (m)", "v_i (m/s)", "q_i", "omega_i (rad/s)"],
        equations_latex=[
            r"\dot{r}_i = v_i",
            r"m_i\dot{v}_i = m_ig + F_{c,i}",
        ],
        contact_impulse="j = -(1+e)*v_n / (1/m_A + 1/m_B + cross_terms)",
        derivation_steps=[
            f"Top link starts at height {p.drop_height:.2f}m.",
            f"Free-fall velocity at floor: v = sqrt(2*g*h) = {impact_vel:.2f} m/s.",
            "Links pile up in a coiled heap; constraint forces redistribute momentum.",
            "Final state: chain rests in tangled pile on floor.",
        ],
        expected_behavior=[
            "Chain falls downward under gravity.",
            "Lower links hit floor first and pile up.",
            "Chain coils into a heap on the floor.",
        ],
        parameters={
            "n_links":           param_entry(p.n_links, "", "Number of chain links"),
            "link_radius_m":     param_entry(p.link_radius, "m", "Link radius"),
            "link_half_len_m":   param_entry(p.link_half_len, "m", "Link half-length"),
            "mass_per_link_kg":  param_entry(p.mass_per_link, "kg", "Mass per link"),
            "drop_height_m":     param_entry(p.drop_height, "m", "Drop height"),
            "floor_friction":    param_entry(p.floor_friction, "", "Floor friction coefficient"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    off = p.link_half_len + p.link_radius * 0.25
    segment = p.link_half_len * 2 + p.link_radius * 0.5
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# chain_drop_pile  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[5.0,5.0,0.02],[0.42,0.42,0.45,1.0]); _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    lr={p.link_radius}; lhl={p.link_half_len}; seg={segment}
    pos=[0.0,0.0,{p.drop_height}]; chain_ids=[]
    cap_shape=pb.createCollisionShape(pb.GEOM_CAPSULE,radius=lr,height=lhl*2,physicsClientId=c)
    for i in range({p.n_links}):
        bid=pb.createMultiBody({p.mass_per_link},cap_shape,-1,pos,[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction=0.5,restitution=0.3,linearDamping=0.05,angularDamping=0.1,physicsClientId=c)
        if chain_ids:
            off_={off}
            cid=pb.createConstraint(chain_ids[-1],-1,bid,-1,pb.JOINT_POINT2POINT,[0,0,1],[0,0,-off_],[0,0,off_],physicsClientId=c)
            pb.changeConstraint(cid,maxForce=200.0,physicsClientId=c)
        chain_ids.append(bid); pos[2]-=seg
    for i in range({p.n_links}): _add_capsule(sc,f"link{{i}}",nodes,lr,lhl*2,{p.chain_color})
    bids=[(f"link{{i}}",bid) for i,bid in enumerate(chain_ids)]; frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_chain_drop_pile")
    print("OK")
