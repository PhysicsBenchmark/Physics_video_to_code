"""staircase_bounce — sphere bounces down a staircase of static boxes."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (6.0, -2.0, 4.0)
CAM_TARGET = (2.0,  0.0, 1.0)
N_FRAMES   = 150  # 5 s @ 30 fps


@dataclass
class Params:
    seed:          int
    n_stairs:      int
    stair_width:   float   # depth of each stair step in X (m)
    stair_height:  float   # height of each step (m)
    ball_radius:   float   # m
    ball_mass:     float   # kg
    restitution:   float
    initial_speed: float   # initial speed of ball in +X direction (m/s)
    ball_color:    List[float]
    stair_color:   List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        n_stairs=random.randint(5, 8),
        stair_width=random.uniform(0.4, 0.7),
        stair_height=random.uniform(0.2, 0.4),
        ball_radius=random.uniform(0.05, 0.12),
        ball_mass=random.uniform(0.1, 1.0),
        restitution=random.uniform(0.45, 0.80),
        initial_speed=random.uniform(0.5, 2.5),
        ball_color=[random.uniform(0.5, 1.0), random.uniform(0.3, 0.8),
                    random.uniform(0.2, 0.7), 1.0],
        stair_color=[0.60, 0.52, 0.42, 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=0.5, restitution=p.restitution)
    ren.add_plane_mesh("floor", 14.0, [0.35, 0.35, 0.37, 1.0])
    ren.set_static_pose("floor", [0, 0, 0])

    # Build stairs: each stair is a box. Step i has tread at z = (n-i)*stair_height
    # X increases with each step: x_i = i * stair_width
    stair_depth = p.stair_width      # half-width along X
    stair_hy    = 1.0                # half-width along Y (wide stair)
    total_height = p.n_stairs * p.stair_height

    for i in range(p.n_stairs):
        # Cumulative height: step i top surface = total_height - i*stair_height
        top_z    = total_height - i * p.stair_height
        half_hz  = top_z / 2.0
        cx       = i * p.stair_width + stair_depth / 2.0
        phys.add_box([stair_depth / 2.0, stair_hy, half_hz],
                     [cx, 0.0, half_hz],
                     mass=0.0, friction=0.5, restitution=p.restitution)
        name = f"stair_{i}"
        ren.add_box(name, [stair_depth / 2.0, stair_hy, half_hz], p.stair_color)
        ren.set_static_pose(name, [cx, 0.0, half_hz])

    # Ball placed at the top of the first stair, given a nudge in +X direction
    ball_start_x = -p.ball_radius - 0.05
    ball_start_z = total_height + p.ball_radius + 0.05
    bid = phys.add_sphere(p.ball_radius,
                          [ball_start_x, 0.0, ball_start_z],
                          mass=p.ball_mass, friction=0.3,
                          restitution=p.restitution,
                          vel=[p.initial_speed, 0.0, 0.0])
    ren.add_sphere("ball", p.ball_radius, p.ball_color)
    dyn = [("ball", bid)]

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="staircase_bounce",
        category="rigid_body_constrained",
        seed=seed,
        physical_observation=(
            f"Sphere (r={p.ball_radius:.3f} m, m={p.ball_mass:.2f} kg) "
            f"bounces down {p.n_stairs} stairs "
            f"(w={p.stair_width:.2f} m, h={p.stair_height:.2f} m per step) "
            f"with restitution e={p.restitution:.2f}."),
        law_name="Newton-Euler dynamics + contact impulse at each stair edge",
        law_statement=(
            "Ball loses energy at each stair contact per restitution coefficient; "
            "horizontal velocity advects it to next step."),
        law_formula="v_after = e*v_before [normal component]",
        assumptions=[
            "Stairs are rigid and static.",
            "Ball is a sphere; edge contact treated as point contact.",
            "Coulomb friction on stair treads.",
        ],
        state_variables=["position r (m)", "velocity v (m/s)",
                         "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg+F_c",
            "I\\dot{\\omega}=\\tau_c-\\omega\\times I\\omega",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            f"Ball dropped from height {total_height:.2f} m.",
            "At each stair edge, normal impulse reduces vertical speed by (1+e).",
            f"With e={p.restitution:.2f}, energy lost per bounce: {(1-p.restitution**2)*100:.0f}%.",
            f"Ball descends {p.n_stairs} steps of {p.stair_height:.2f} m each.",
        ],
        expected_behavior=[
            "Ball bounces from step to step, descending the staircase.",
            f"Bounce height decreases with each step (e={p.restitution:.2f}).",
            "Ball eventually reaches floor and rolls away.",
        ],
        parameters={
            "n_stairs":       param_entry(p.n_stairs,      "",    "Number of stairs"),
            "stair_width_m":  param_entry(p.stair_width,   "m",   "Stair tread depth"),
            "stair_height_m": param_entry(p.stair_height,  "m",   "Stair riser height"),
            "ball_radius_m":  param_entry(p.ball_radius,   "m",   "Ball radius"),
            "ball_mass_kg":   param_entry(p.ball_mass,     "kg",  "Ball mass"),
            "restitution":    param_entry(p.restitution,   "",    "Coefficient of restitution"),
            "initial_speed":  param_entry(p.initial_speed, "m/s", "Initial horizontal speed"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    total_height = p.n_stairs * p.stair_height
    stair_hy = 1.0
    ball_start_x = -p.ball_radius - 0.05
    ball_start_z = total_height + p.ball_radius + 0.05
    # Build stair geometry lists for embedding
    stair_data = []
    for i in range(p.n_stairs):
        top_z   = total_height - i * p.stair_height
        half_hz = top_z / 2.0
        cx      = i * p.stair_width + p.stair_width / 4.0
        stair_data.append((p.stair_width / 2.0, stair_hy, half_hz, cx, half_hz))
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# staircase_bounce  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[7.0,7.0,0.02],[0.35,0.35,0.37,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    stair_data={stair_data}; sc_col={p.stair_color}
    for i,(hw,hy,hz,cx,cz) in enumerate(stair_data):
        s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[hw,hy,hz],physicsClientId=c)
        pb.createMultiBody(0,s,-1,[cx,0.0,cz],[0,0,0,1],physicsClientId=c)
        nm=f"stair_{{i}}"; _add_box(sc,nm,nodes,[hw,hy,hz],sc_col); _set_pose(sc,nodes[nm],[cx,0.0,cz],[0,0,0,1])
    bs=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.ball_radius},physicsClientId=c)
    bid=pb.createMultiBody({p.ball_mass},bs,-1,[{ball_start_x},0.0,{ball_start_z}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(bid,-1,lateralFriction=0.3,restitution={p.restitution},physicsClientId=c)
    pb.resetBaseVelocity(bid,[{p.initial_speed},0.0,0.0],[0,0,0],physicsClientId=c)
    _add_sphere(sc,"ball",nodes,{p.ball_radius},{p.ball_color})
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
        _set_pose(sc,nodes["ball"],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_staircase_bounce")
    print("OK")
