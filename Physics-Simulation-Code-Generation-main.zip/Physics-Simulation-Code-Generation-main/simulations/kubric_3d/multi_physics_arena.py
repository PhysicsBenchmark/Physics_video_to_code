"""multi_physics_arena — walled arena with diverse object types, arrangements, and velocity modes."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (10, -9, 8.5)
CAM_TARGET = (0, 0, 0.8)
N_FRAMES   = 150

ARRANGEMENTS   = ['radial', 'scatter', 'two_groups', 'corner', 'drop']
VELOCITY_MODES = ['random', 'inward', 'outward', 'minimal']
TYPE_MIXES     = ['spheres_only', 'boxes_only', 'cylinders_only',
                  'spheres_boxes', 'spheres_cylinders', 'boxes_cylinders',
                  'all_types']


@dataclass
class Params:
    seed: int
    arena_half: float
    wall_height: float
    n_spheres: int
    n_boxes: int
    n_cylinders: int
    restitution: float
    friction: float
    arrangement: str
    velocity_mode: str
    speed_scale: float
    # per-object sizes and masses (lists)
    sphere_radii:  List[float]
    sphere_masses: List[float]
    box_halves:    List[List[float]]
    box_masses:    List[float]
    cyl_radii:     List[float]
    cyl_heights:   List[float]
    cyl_masses:    List[float]


def _rand_hue():
    h = random.random(); s, v = 0.85, 0.90
    hi = int(h*6) % 6; f = h*6 - int(h*6)
    p_ = v*(1-s); q = v*(1-f*s); t = v*(1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return [r, g, b, 1.0]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)

    mix = random.choice(TYPE_MIXES)
    if mix == 'spheres_only':
        n_s, n_b, n_c = random.randint(4, 12), 0, 0
    elif mix == 'boxes_only':
        n_s, n_b, n_c = 0, random.randint(3, 9), 0
    elif mix == 'cylinders_only':
        n_s, n_b, n_c = 0, 0, random.randint(3, 9)
    elif mix == 'spheres_boxes':
        n_s, n_b, n_c = random.randint(2, 7), random.randint(2, 5), 0
    elif mix == 'spheres_cylinders':
        n_s, n_b, n_c = random.randint(2, 7), 0, random.randint(2, 5)
    elif mix == 'boxes_cylinders':
        n_s, n_b, n_c = 0, random.randint(2, 5), random.randint(2, 5)
    else:  # all_types
        n_s = random.randint(2, 6)
        n_b = random.randint(1, 4)
        n_c = random.randint(1, 4)

    return Params(
        seed=seed,
        arena_half=random.uniform(2.8, 5.5),
        wall_height=random.uniform(0.20, 0.90),
        n_spheres=n_s,
        n_boxes=n_b,
        n_cylinders=n_c,
        restitution=random.uniform(0.10, 0.88),
        friction=random.uniform(0.20, 0.90),
        arrangement=random.choice(ARRANGEMENTS),
        velocity_mode=random.choice(VELOCITY_MODES),
        speed_scale=random.uniform(0.4, 4.5),
        sphere_radii =[random.uniform(0.07, 0.30) for _ in range(n_s)],
        sphere_masses=[random.uniform(0.15, 2.5)  for _ in range(n_s)],
        box_halves   =[[random.uniform(0.07, 0.30),
                        random.uniform(0.07, 0.30),
                        random.uniform(0.06, 0.28)] for _ in range(n_b)],
        box_masses   =[random.uniform(0.20, 3.0)  for _ in range(n_b)],
        cyl_radii    =[random.uniform(0.05, 0.22) for _ in range(n_c)],
        cyl_heights  =[random.uniform(0.12, 0.70) for _ in range(n_c)],
        cyl_masses   =[random.uniform(0.15, 2.0)  for _ in range(n_c)],
    )


def _obj_velocity(x, y, mode, speed, rng):
    if mode == 'inward':
        d = max(0.01, math.sqrt(x*x + y*y))
        return (-x/d * speed * rng.uniform(0.6, 1.4),
                -y/d * speed * rng.uniform(0.6, 1.4))
    elif mode == 'outward':
        d = max(0.01, math.sqrt(x*x + y*y))
        return ( x/d * speed * rng.uniform(0.6, 1.4),
                 y/d * speed * rng.uniform(0.6, 1.4))
    elif mode == 'minimal':
        return rng.uniform(-0.35, 0.35), rng.uniform(-0.35, 0.35)
    else:  # random
        return rng.uniform(-speed, speed), rng.uniform(-speed, speed)


def _place_xy(idx, n_total, arrangement, arena_half, margin, rng):
    """Return (x, y) for object idx given the arrangement mode."""
    ah = arena_half
    if arrangement == 'radial':
        angle = 2*math.pi * idx / max(n_total, 1) + rng.uniform(-0.25, 0.25)
        r = rng.uniform(max(0.3, ah*0.3), max(0.31, ah - margin))
        return r*math.cos(angle), r*math.sin(angle)
    elif arrangement == 'two_groups':
        m = margin
        if idx < n_total // 2:
            return rng.uniform(-ah+m, -0.4), rng.uniform(-ah+m, ah-m)
        else:
            return rng.uniform(0.4, ah-m),  rng.uniform(-ah+m, ah-m)
    elif arrangement == 'corner':
        m = margin
        return (rng.uniform(-ah+m, -ah+m + (ah-m)*0.55),
                rng.uniform(-ah+m, -ah+m + (ah-m)*0.55))
    else:  # 'scatter' or 'drop'
        m = margin
        return rng.uniform(-ah+m, ah-m), rng.uniform(-ah+m, ah-m)


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import trimesh as _trimesh

    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)
    rng = np.random.RandomState(seed + 1000)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.friction)
    ren.add_plane_mesh("floor", p.arena_half * 2 + 2.0, [0.42, 0.42, 0.45, 1.0])
    ren.set_static_pose("floor", [0, 0, -0.02])

    wall_t = 0.1
    wh = p.wall_height
    ah = p.arena_half
    walls = [
        ("wN", [ ah+wall_t, 0, wh/2], [wall_t, ah, wh/2]),
        ("wS", [-ah-wall_t, 0, wh/2], [wall_t, ah, wh/2]),
        ("wE", [0,  ah+wall_t, wh/2], [ah, wall_t, wh/2]),
        ("wW", [0, -ah-wall_t, wh/2], [ah, wall_t, wh/2]),
    ]
    for nm, pos, he in walls:
        phys.add_box(he, pos, mass=0.0, friction=p.friction, restitution=p.restitution)
        ren.add_box(nm, he, [0.55, 0.55, 0.58, 1.0])
        ren.set_static_pose(nm, pos)

    dyn = []
    n_total = p.n_spheres + p.n_boxes + p.n_cylinders
    obj_idx = 0

    # Spheres
    for i in range(p.n_spheres):
        r   = p.sphere_radii[i]
        m   = p.sphere_masses[i]
        margin = r + 0.35
        sx, sy = _place_xy(obj_idx, n_total, p.arrangement, ah, margin, rng)
        sx = float(np.clip(sx, -ah+margin, ah-margin))
        sy = float(np.clip(sy, -ah+margin, ah-margin))

        if p.arrangement == 'drop':
            sz = float(rng.uniform(0.8, 3.2))
            vx, vy = float(rng.uniform(-0.5, 0.5)), float(rng.uniform(-0.5, 0.5))
        else:
            sz = r + 0.04
            vx, vy = _obj_velocity(sx, sy, p.velocity_mode, p.speed_scale, rng)
        ang = (float(rng.uniform(-6.0, 6.0)),
               float(rng.uniform(-6.0, 6.0)),
               float(rng.uniform(-3.0, 3.0)))
        color = _rand_hue()

        bid = phys.add_sphere(r, [sx, sy, sz], mass=m,
                               friction=p.friction, restitution=p.restitution,
                               vel=(vx, vy, 0.0), ang_vel=ang)
        ren.add_sphere(f"sph{i}", r, color)
        spot_tm = _trimesh.creation.icosphere(subdivisions=2, radius=r*0.28)
        spot_tm.apply_translation([0.0, 0.0, r*0.78])
        ren._add_mesh(f"sph{i}_spot", spot_tm, [0.98, 0.98, 0.92, 1.0],
                      metallic=0.0, roughness=0.35)
        ren.set_static_pose(f"sph{i}", [sx, sy, sz])
        ren.set_static_pose(f"sph{i}_spot", [sx, sy, sz])
        dyn.append((f"sph{i}", bid))
        dyn.append((f"sph{i}_spot", bid))
        obj_idx += 1

    # Boxes
    for i in range(p.n_boxes):
        bh_i = p.box_halves[i]
        m    = p.box_masses[i]
        margin = max(bh_i)*1.4 + 0.3
        bx, by = _place_xy(obj_idx, n_total, p.arrangement, ah, margin, rng)
        bx = float(np.clip(bx, -ah+margin, ah-margin))
        by = float(np.clip(by, -ah+margin, ah-margin))

        if p.arrangement == 'drop':
            bz = float(rng.uniform(0.6, 3.0))
            vx, vy = float(rng.uniform(-0.4, 0.4)), float(rng.uniform(-0.4, 0.4))
        else:
            bz = bh_i[2] + 0.02
            vx, vy = _obj_velocity(bx, by, p.velocity_mode, p.speed_scale*0.6, rng)
        ang = (float(rng.uniform(-3.0, 3.0)),
               float(rng.uniform(-3.0, 3.0)),
               float(rng.uniform(-4.0, 4.0)))
        color = _rand_hue()

        bid = phys.add_box(bh_i, [bx, by, bz], mass=m,
                            friction=p.friction, restitution=p.restitution,
                            vel=(vx, vy, 0.0))
        ren.add_box(f"box{i}", bh_i, color)
        ren.set_static_pose(f"box{i}", [bx, by, bz])
        dyn.append((f"box{i}", bid))
        obj_idx += 1

    # Cylinders
    for i in range(p.n_cylinders):
        cr  = p.cyl_radii[i]
        ch  = p.cyl_heights[i]
        m   = p.cyl_masses[i]
        margin = cr + 0.40
        cx, cy = _place_xy(obj_idx, n_total, p.arrangement, ah, margin, rng)
        cx = float(np.clip(cx, -ah+margin, ah-margin))
        cy = float(np.clip(cy, -ah+margin, ah-margin))

        if p.arrangement == 'drop':
            cz = float(rng.uniform(0.5, 2.5))
            vx, vy = float(rng.uniform(-0.4, 0.4)), float(rng.uniform(-0.4, 0.4))
        else:
            cz = ch/2.0 + 0.02
            vx, vy = _obj_velocity(cx, cy, p.velocity_mode, p.speed_scale*0.5, rng)
        ang = (float(rng.uniform(-2.0, 2.0)),
               float(rng.uniform(-2.0, 2.0)),
               float(rng.uniform(-4.0, 4.0)))
        color = _rand_hue()

        bid = phys.add_cylinder(cr, ch, [cx, cy, cz], mass=m,
                                 friction=p.friction, restitution=p.restitution,
                                 vel=(vx, vy, 0.0), ang_vel=ang)
        ren.add_cylinder(f"cyl{i}", cr, ch, color)
        ren.set_static_pose(f"cyl{i}", [cx, cy, cz])
        dyn.append((f"cyl{i}", bid))
        obj_idx += 1

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="multi_physics_arena",
        category="mixed_complex",
        seed=seed,
        physical_observation=(
            f"Walled arena ({ah:.1f}m half-side, wall h={wh:.2f}m): "
            f"{p.n_spheres} spheres, {p.n_boxes} boxes, {p.n_cylinders} cylinders; "
            f"arrangement='{p.arrangement}', velocity_mode='{p.velocity_mode}', "
            f"speed_scale={p.speed_scale:.2f}, e={p.restitution:.2f}, μ={p.friction:.2f}."
        ),
        law_name="Newton-Euler rigid-body dynamics + contact impulse",
        law_statement=(
            "Multiple rigid bodies of mixed shapes interact via frictional contact impulses; "
            "walls confine and reflect objects causing cascading collisions."
        ),
        law_formula="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        assumptions=[
            "Rigid body assumption for all objects",
            "Coulomb friction model at all contacts",
            "Static walls (mass=0) provide infinite-mass contact response",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg+\\sum F_c",
            "I\\dot{\\omega}=\\sum\\tau_c-\\omega\\times I\\omega",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B + cross_terms)",
        derivation_steps=[
            f"Objects placed with arrangement='{p.arrangement}'",
            f"Velocities assigned with mode='{p.velocity_mode}', scale={p.speed_scale:.2f}",
            "Contact LCP solver handles sphere/box/cylinder interactions",
            f"Restitution e={p.restitution:.2f} controls bounce energy retention",
        ],
        expected_behavior=[
            f"{'Spheres roll and bounce' if p.n_spheres else 'No spheres'}; "
            f"{'boxes tumble and stack' if p.n_boxes else 'no boxes'}; "
            f"{'cylinders roll and tip' if p.n_cylinders else 'no cylinders'}.",
            f"Objects {'converge to center' if p.velocity_mode=='inward' else 'diverge outward' if p.velocity_mode=='outward' else 'move randomly' if p.velocity_mode=='random' else 'drift slowly'}.",
            "Wall collisions cause repeated redirections and cascades.",
        ],
        parameters={
            "arena_half":    param_entry(p.arena_half,    "m",  "half-width of walled arena"),
            "wall_height":   param_entry(p.wall_height,   "m",  "height of boundary walls"),
            "n_spheres":     param_entry(p.n_spheres,     "",   "number of spheres"),
            "n_boxes":       param_entry(p.n_boxes,       "",   "number of boxes"),
            "n_cylinders":   param_entry(p.n_cylinders,   "",   "number of cylinders"),
            "arrangement":   param_entry(p.arrangement,   "",   "initial placement pattern"),
            "velocity_mode": param_entry(p.velocity_mode, "",   "initial velocity direction mode"),
            "speed_scale":   param_entry(p.speed_scale,   "m/s","speed multiplier"),
            "restitution":   param_entry(p.restitution,   "",   "coefficient of restitution"),
            "friction":      param_entry(p.friction,      "",   "lateral friction coefficient"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS

    random.seed(p.seed); np.random.seed(p.seed)
    rng = np.random.RandomState(p.seed + 1000)
    ah  = p.arena_half
    wh  = p.wall_height
    wall_t = 0.1
    n_total = p.n_spheres + p.n_boxes + p.n_cylinders

    lines = []
    bids_var = []

    # walls
    walls = [
        ("wN", [ ah+wall_t, 0, wh/2], [wall_t, ah, wh/2]),
        ("wS", [-ah-wall_t, 0, wh/2], [wall_t, ah, wh/2]),
        ("wE", [0,  ah+wall_t, wh/2], [ah, wall_t, wh/2]),
        ("wW", [0, -ah-wall_t, wh/2], [ah, wall_t, wh/2]),
    ]
    for nm, pos, he in walls:
        lines.append(
            f"    sw=pb.createCollisionShape(pb.GEOM_BOX,halfExtents={he},physicsClientId=c)\n"
            f"    pb.createMultiBody(0,sw,-1,{[round(v,4) for v in pos]},[0,0,0,1],physicsClientId=c)\n"
            f"    _add_box(sc,'{nm}',nodes,{he},[0.55,0.55,0.58,1.0])\n"
            f"    _set_pose(sc,nodes['{nm}'],{[round(v,4) for v in pos]},[0,0,0,1])\n"
        )

    obj_idx = 0
    for i in range(p.n_spheres):
        r      = p.sphere_radii[i]
        m      = p.sphere_masses[i]
        margin = r + 0.35
        sx, sy = _place_xy(obj_idx, n_total, p.arrangement, ah, margin, rng)
        sx = float(np.clip(sx, -ah+margin, ah-margin))
        sy = float(np.clip(sy, -ah+margin, ah-margin))
        if p.arrangement == 'drop':
            sz = float(rng.uniform(0.8, 3.2))
            vx, vy = float(rng.uniform(-0.5, 0.5)), float(rng.uniform(-0.5, 0.5))
        else:
            sz = r + 0.04
            vx, vy = _obj_velocity(sx, sy, p.velocity_mode, p.speed_scale, rng)
        ang = [round(float(rng.uniform(-6.0, 6.0)), 4),
               round(float(rng.uniform(-6.0, 6.0)), 4),
               round(float(rng.uniform(-3.0, 3.0)), 4)]
        color = _rand_hue()
        lines.append(
            f"    ss=pb.createCollisionShape(pb.GEOM_SPHERE,radius={r:.4f},physicsClientId=c)\n"
            f"    sph{i}=pb.createMultiBody({m:.4f},ss,-1,[{sx:.4f},{sy:.4f},{sz:.4f}],[0,0,0,1],physicsClientId=c)\n"
            f"    pb.changeDynamics(sph{i},-1,lateralFriction={p.friction:.4f},restitution={p.restitution:.4f},physicsClientId=c)\n"
            f"    pb.resetBaseVelocity(sph{i},[{vx:.4f},{vy:.4f},0],{ang},physicsClientId=c)\n"
            f"    _add_sphere(sc,'sph{i}',nodes,{r:.4f},{color})\n"
            f"    _set_pose(sc,nodes['sph{i}'],[{sx:.4f},{sy:.4f},{sz:.4f}],[0,0,0,1])\n"
        )
        bids_var.append(f"('sph{i}',sph{i})")
        obj_idx += 1

    for i in range(p.n_boxes):
        bh_i   = p.box_halves[i]
        m      = p.box_masses[i]
        margin = max(bh_i)*1.4 + 0.3
        bx, by = _place_xy(obj_idx, n_total, p.arrangement, ah, margin, rng)
        bx = float(np.clip(bx, -ah+margin, ah-margin))
        by = float(np.clip(by, -ah+margin, ah-margin))
        if p.arrangement == 'drop':
            bz = float(rng.uniform(0.6, 3.0))
            vx, vy = float(rng.uniform(-0.4, 0.4)), float(rng.uniform(-0.4, 0.4))
        else:
            bz = bh_i[2] + 0.02
            vx, vy = _obj_velocity(bx, by, p.velocity_mode, p.speed_scale*0.6, rng)
        color = _rand_hue()
        lines.append(
            f"    sb=pb.createCollisionShape(pb.GEOM_BOX,halfExtents={[round(v,4) for v in bh_i]},physicsClientId=c)\n"
            f"    box{i}=pb.createMultiBody({m:.4f},sb,-1,[{bx:.4f},{by:.4f},{bz:.4f}],[0,0,0,1],physicsClientId=c)\n"
            f"    pb.changeDynamics(box{i},-1,lateralFriction={p.friction:.4f},restitution={p.restitution:.4f},physicsClientId=c)\n"
            f"    pb.resetBaseVelocity(box{i},[{vx:.4f},{vy:.4f},0],[0,0,0],physicsClientId=c)\n"
            f"    _add_box(sc,'box{i}',nodes,{[round(v,4) for v in bh_i]},{color})\n"
            f"    _set_pose(sc,nodes['box{i}'],[{bx:.4f},{by:.4f},{bz:.4f}],[0,0,0,1])\n"
        )
        bids_var.append(f"('box{i}',box{i})")
        obj_idx += 1

    for i in range(p.n_cylinders):
        cr     = p.cyl_radii[i]
        ch     = p.cyl_heights[i]
        m      = p.cyl_masses[i]
        margin = cr + 0.40
        cx, cy = _place_xy(obj_idx, n_total, p.arrangement, ah, margin, rng)
        cx = float(np.clip(cx, -ah+margin, ah-margin))
        cy = float(np.clip(cy, -ah+margin, ah-margin))
        if p.arrangement == 'drop':
            cz = float(rng.uniform(0.5, 2.5))
            vx, vy = float(rng.uniform(-0.4, 0.4)), float(rng.uniform(-0.4, 0.4))
        else:
            cz = ch/2.0 + 0.02
            vx, vy = _obj_velocity(cx, cy, p.velocity_mode, p.speed_scale*0.5, rng)
        ang = [round(float(rng.uniform(-2.0, 2.0)), 4),
               round(float(rng.uniform(-2.0, 2.0)), 4),
               round(float(rng.uniform(-4.0, 4.0)), 4)]
        color = _rand_hue()
        lines.append(
            f"    scy=pb.createCollisionShape(pb.GEOM_CYLINDER,radius={cr:.4f},height={ch:.4f},physicsClientId=c)\n"
            f"    cyl{i}=pb.createMultiBody({m:.4f},scy,-1,[{cx:.4f},{cy:.4f},{cz:.4f}],[0,0,0,1],physicsClientId=c)\n"
            f"    pb.changeDynamics(cyl{i},-1,lateralFriction={p.friction:.4f},restitution={p.restitution:.4f},physicsClientId=c)\n"
            f"    pb.resetBaseVelocity(cyl{i},[{vx:.4f},{vy:.4f},0],{ang},physicsClientId=c)\n"
            f"    _add_cylinder(sc,'cyl{i}',nodes,{cr:.4f},{ch:.4f},{color})\n"
            f"    _set_pose(sc,nodes['cyl{i}'],[{cx:.4f},{cy:.4f},{cz:.4f}],[0,0,0,1])\n"
        )
        bids_var.append(f"('cyl{i}',cyl{i})")
        obj_idx += 1

    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# multi_physics_arena  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[{ah+1:.1f},{ah+1:.1f},0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,-0.02],[0,0,0,1])
{"".join(lines)}    bids=[{",".join(bids_var)}]
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete()
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_multi_physics_arena")
    print("OK")
