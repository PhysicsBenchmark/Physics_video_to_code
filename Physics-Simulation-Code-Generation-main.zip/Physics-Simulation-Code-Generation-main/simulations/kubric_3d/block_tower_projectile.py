"""block_tower_projectile — stacked boxes hit by a flying sphere."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (5.0, -2.0, 3.5)
CAM_TARGET = (0.0,  0.0, 1.5)
N_FRAMES   = 120  # 4 s @ 30 fps


@dataclass
class Params:
    seed: int
    n_layers: int
    box_half: float          # half-extent of each cube
    tower_color: List[float]
    proj_radius: float
    proj_mass:   float
    proj_speed:  float
    proj_height: float       # z at which projectile is launched
    proj_y:      float       # starting Y (negative → coming from front)
    floor_friction: float
    box_mass:    float
    box_restitution: float


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    bh = random.uniform(0.12, 0.22)
    nl = random.randint(4, 7)
    ph = random.uniform(0.3, nl * bh * 2 * 0.8)   # hit somewhere in the middle
    return Params(
        seed=seed, n_layers=nl, box_half=bh,
        tower_color=[random.uniform(0.5,1.0), random.uniform(0.3,0.8), random.uniform(0.2,0.7), 1.0],
        proj_radius=random.uniform(0.08, 0.16),
        proj_mass=random.uniform(0.5, 3.0),
        proj_speed=random.uniform(3.5, 7.0),
        proj_height=ph,
        proj_y=random.uniform(-4.0, -3.0),
        floor_friction=random.uniform(0.4, 0.8),
        box_mass=random.uniform(0.3, 1.5),
        box_restitution=random.uniform(0.2, 0.6))


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_box([15, 15, 0.1], [0, 0, -0.1], mass=0,
                 friction=p.floor_friction, restitution=0.4)
    ren.add_plane_mesh("floor", 30.0, [0.42, 0.42, 0.45, 1.0])

    dyn = []
    bh = p.box_half
    for layer in range(p.n_layers):
        z = bh + layer * bh * 2
        for j in range(2):
            xoff = (j - 0.5) * bh * 1.1
            bid = phys.add_box([bh]*3, [xoff, 0.0, z],
                               mass=p.box_mass, friction=0.5,
                               restitution=p.box_restitution)
            name = f"box_{layer}_{j}"
            ren.add_box(name, [bh]*3, p.tower_color)
            dyn.append((name, bid))

    # projectile
    proj_col = [0.9, 0.3, 0.2, 1.0]
    pb = phys.add_sphere(p.proj_radius,
                         [0.0, p.proj_y, p.proj_height],
                         mass=p.proj_mass, restitution=0.4,
                         vel=[0.0, p.proj_speed, 0.0])
    ren.add_sphere("proj", p.proj_radius, proj_col)
    dyn.append(("proj", pb))

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="block_tower_projectile",
        category="rigid_body_free_dynamics",
        seed=seed,
        physical_observation=(
            f"A {p.n_layers}-layer tower of boxes (side {p.box_half*2:.2f} m, "
            f"mass {p.box_mass:.2f} kg each) struck by a sphere "
            f"(r={p.proj_radius:.3f} m, m={p.proj_mass:.2f} kg) "
            f"at speed {p.proj_speed:.1f} m/s, hitting at z={p.proj_height:.2f} m."),
        law_name="Newton-Euler rigid-body dynamics + contact impulse",
        law_statement="Projectile transfers linear and angular momentum to struck boxes via contact impulse.",
        law_formula="j = -(1+e)·v_rel·n̂ / (1/m_A + 1/m_B + r_A×n̂·I_A⁻¹·r_A×n̂ + ...)",
        assumptions=["Boxes are rigid; no elastic deformation",
                     "Stacked boxes in static equilibrium before collision",
                     "Friction between boxes follows Coulomb law"],
        state_variables=["position r (m)","velocity v (m/s)","quaternion q","angular velocity ω (rad/s)"],
        equations_latex=["\\dot{r}=v","m\\dot{v}=mg+F_c",
                         "I\\dot{\\omega}=\\tau_c-\\omega\\times I\\omega"],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A+1/m_B+cross_terms)",
        derivation_steps=[
            "Tower boxes in static equilibrium: net force/torque = 0.",
            f"Projectile launched at v = {p.proj_speed:.1f} m/s in +Y direction.",
            "Contact impulse at collision: j_n = -(1+e)·v_rel·n / (w_A + w_B).",
            "Impacted box receives impulse, propagating through the stack.",
            "Gravity causes any elevated boxes to fall after losing support."],
        expected_behavior=[
            f"Projectile hits tower at z≈{p.proj_height:.2f} m, scattering boxes.",
            "Boxes above impact point fly off; lower boxes may remain.",
            f"Tower with {p.n_layers} layers — {'top-heavy' if p.proj_height < p.n_layers*p.box_half else 'middle hit'}."],
        parameters={
            "n_layers":       param_entry(p.n_layers, "", "Number of box layers"),
            "box_half_m":     param_entry(p.box_half, "m", "Half-size of each box"),
            "box_mass_kg":    param_entry(p.box_mass, "kg", "Mass per box"),
            "proj_radius_m":  param_entry(p.proj_radius, "m", "Projectile radius"),
            "proj_mass_kg":   param_entry(p.proj_mass, "kg", "Projectile mass"),
            "proj_speed_mps": param_entry(p.proj_speed, "m/s", "Launch speed"),
            "proj_height_m":  param_entry(p.proj_height, "m", "Impact height")})
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# block_tower_projectile  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[3.5,3.5,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    bh={p.box_half}; tc={p.tower_color}
    bids=[]
    for ly in range({p.n_layers}):
        z=bh+ly*bh*2
        for j in range(2):
            xo=(j-0.5)*bh*1.1
            s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[bh,bh,bh],physicsClientId=c)
            bid=pb.createMultiBody({p.box_mass},s,-1,[xo,0,z],[0,0,0,1],physicsClientId=c)
            pb.changeDynamics(bid,-1,lateralFriction=0.5,restitution={p.box_restitution},physicsClientId=c)
            nm=f"b_{{ly}}_{{j}}"
            _add_box(sc,nm,nodes,[bh,bh,bh],tc); bids.append((nm,bid))
    s=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.proj_radius},physicsClientId=c)
    pb_id=pb.createMultiBody({p.proj_mass},s,-1,[0,{p.proj_y},{p.proj_height}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(pb_id,-1,lateralFriction=0.4,restitution=0.4,physicsClientId=c)
    pb.resetBaseVelocity(pb_id,[0,{p.proj_speed},0],[0,0,0],physicsClientId=c)
    _add_sphere(sc,"pr",nodes,{p.proj_radius},[0.9,0.3,0.2,1.0]); bids.append(("pr",pb_id))
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_block_tower")
    print("OK")
