"""atwood_machine — two masses over a pulley; heavier mass descends, lighter ascends."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (3.5, -3.0, 3.5)
CAM_TARGET = (0.0,  0.0, 2.0)
N_FRAMES   = 150


@dataclass
class Params:
    seed: int
    mass1: float
    mass2: float
    radius1: float
    radius2: float
    rope_half_length: float   # half-rope from pulley to each mass at rest
    color1: List[float]
    color2: List[float]


def _rand_color():
    h = random.random()
    s, v = 0.85, 0.90
    hi = int(h * 6) % 6
    f  = h * 6 - int(h * 6)
    p_ = v * (1 - s); q = v * (1 - f*s); t = v * (1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return [r, g, b, 1.0]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    m1 = random.uniform(0.5, 2.0)
    m2 = random.uniform(0.5, 2.0)
    if abs(m1 - m2) < 0.3:
        m2 = m1 + random.uniform(0.3, 1.0)
    return Params(
        seed=seed,
        mass1=m1,
        mass2=m2,
        radius1=random.uniform(0.07, 0.13),
        radius2=random.uniform(0.07, 0.13),
        rope_half_length=random.uniform(1.2, 2.0),
        color1=_rand_color(),
        color2=_rand_color(),
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS, FPS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    # Floor visual only
    phys.add_plane(friction=0.3)
    ren.add_plane_mesh("floor", 8.0, [0.42, 0.42, 0.45, 1.0])
    ren.set_static_pose("floor", [0, 0, -0.02])

    # Pulley at top: support pole + cylinder
    pulley_height = p.rope_half_length + 1.5   # high enough that both masses stay visible
    pulley_pos    = [0.0, 0.0, pulley_height]

    pole_h = pulley_height
    ren.add_cylinder("pole", 0.03, pole_h, [0.35, 0.28, 0.22, 1.0])
    ren.set_static_pose("pole", [0.0, 0.0, pole_h / 2])
    ren.add_cylinder("pulley", 0.09, 0.10, [0.6, 0.6, 0.65, 1.0])
    ren.set_static_pose("pulley", pulley_pos)

    # Masses hang directly below pulley — small x-offset for visual separation
    X1, X2 = -0.13, 0.13

    # Both masses start at the same height: rope_half_length below pulley
    z_start = pulley_height - p.rope_half_length

    ren.add_sphere("m1", p.radius1, p.color1)
    ren.add_sphere("m2", p.radius2, p.color2)
    ren.set_static_pose("m1", [X1, 0.0, z_start])
    ren.set_static_pose("m2", [X2, 0.0, z_start])

    str_color  = [0.25, 0.18, 0.10, 1.0]
    str_radius = 0.007

    # Atwood kinematics (analytic, inextensible rope)
    g   = 9.81
    a   = abs(p.mass2 - p.mass1) * g / (p.mass1 + p.mass2)
    # sign: +1 → m1 rises & m2 falls  (when m2 > m1)
    sign = 1.0 if p.mass2 >= p.mass1 else -1.0

    z_ceil   = pulley_height - 0.15        # don't let mass hit pulley
    z_floor1 = p.radius1 + 0.01
    z_floor2 = p.radius2 + 0.01

    # max dz before either mass hits its limit
    max_dz = min(
        (z_start - z_floor2) if sign > 0 else (z_ceil - z_start),  # m2 limit
        (z_ceil  - z_start)  if sign > 0 else (z_start - z_floor1), # m1 limit
    )

    frames = []
    for fi in range(N_FRAMES):
        t   = fi / float(FPS)
        dz  = min(0.5 * a * t * t, max_dz)   # freeze both once limit reached

        z1 = z_start + sign * dz
        z2 = z_start - sign * dz

        cur1 = [X1, 0.0, z1]
        cur2 = [X2, 0.0, z2]

        ren.set_pose("m1", np.array(cur1), [0, 0, 0, 1])
        ren.set_pose("m2", np.array(cur2), [0, 0, 0, 1])
        ren.update_string("str1", pulley_pos, cur1, str_radius, str_color)
        ren.update_string("str2", pulley_pos, cur2, str_radius, str_color)
        frames.append(ren.render_frame())

    # Atwood analytics for CoT
    a_val = abs(p.mass2 - p.mass1) * g / (p.mass1 + p.mass2)
    T_val = 2.0 * p.mass1 * p.mass2 * g / (p.mass1 + p.mass2)
    heavy, light = (p.mass2, p.mass1) if p.mass2 >= p.mass1 else (p.mass1, p.mass2)

    cot = build_cot(
        simulation="atwood_machine",
        category="articulated_jointed",
        seed=seed,
        physical_observation=(
            f"Atwood machine: m1={p.mass1:.2f}kg, m2={p.mass2:.2f}kg. "
            f"Net acceleration a = {a_val:.3f} m/s². "
            f"Heavier mass ({heavy:.2f}kg) descends, lighter ({light:.2f}kg) ascends."
        ),
        law_name="Atwood machine — Newton's second law for connected masses",
        law_statement=(
            "Two masses connected by an inextensible rope over a frictionless pulley "
            "accelerate at a = (m2-m1)g/(m1+m2); tension T = 2m1m2g/(m1+m2)."
        ),
        law_formula="a = (m2-m1)·g/(m1+m2); T = 2·m1·m2·g/(m1+m2)",
        assumptions=[
            "Massless inextensible rope; frictionless massless pulley.",
            "Masses move purely vertically (rope always vertical).",
            "Simulation is analytic (exact Atwood solution, no numerical drift).",
        ],
        state_variables=["z1 (m)", "z2 (m)", "v1 (m/s)", "v2 (m/s)"],
        equations_latex=[
            "m_1 a = T - m_1 g",
            "m_2 a = m_2 g - T",
            "a = \\frac{(m_2-m_1)g}{m_1+m_2}",
            "T = \\frac{2m_1 m_2 g}{m_1+m_2}",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            "Add Newton equations: (m1+m2)a = (m2-m1)g",
            f"a = {a_val:.4f} m/s²",
            f"T = {T_val:.3f} N",
            f"Heavier mass ({heavy:.2f}kg) descends; lighter ({light:.2f}kg) ascends.",
        ],
        expected_behavior=[
            f"Heavier mass ({heavy:.2f}kg) accelerates downward at {a_val:.3f} m/s².",
            f"Lighter mass ({light:.2f}kg) accelerates upward at {a_val:.3f} m/s².",
            "Rope string stays taut and constant-length throughout.",
            "System freezes when heavier mass reaches floor.",
        ],
        parameters={
            "mass1":            param_entry(p.mass1,            "kg", "mass of first object"),
            "mass2":            param_entry(p.mass2,            "kg", "mass of second object"),
            "radius1":          param_entry(p.radius1,          "m",  "radius of first sphere"),
            "radius2":          param_entry(p.radius2,          "m",  "radius of second sphere"),
            "rope_half_length": param_entry(p.rope_half_length, "m",  "half-rope from pulley to each mass at start"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    pulley_height = p.rope_half_length + 1.5
    z_start       = pulley_height - p.rope_half_length
    a             = abs(p.mass2 - p.mass1) * 9.81 / (p.mass1 + p.mass2)
    sign          = 1.0 if p.mass2 >= p.mass1 else -1.0
    z_ceil        = pulley_height - 0.15
    z_floor1      = p.radius1 + 0.01
    z_floor2      = p.radius2 + 0.01
    max_dz        = min(
        (z_start - z_floor2) if sign > 0 else (z_ceil - z_start),
        (z_ceil  - z_start)  if sign > 0 else (z_start - z_floor1),
    )
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# atwood_machine  seed={p.seed}
import math
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[4.0,4.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,-0.02],[0,0,0,1])
    # support pole + pulley (static visuals)
    ph={pulley_height:.4f}
    _add_cylinder(sc,"pole",nodes,0.03,{pulley_height:.4f},[0.35,0.28,0.22,1.0])
    _set_pose(sc,nodes["pole"],[0,0,{pulley_height/2:.4f}],[0,0,0,1])
    _add_cylinder(sc,"pulley",nodes,0.09,0.10,[0.6,0.6,0.65,1.0])
    _set_pose(sc,nodes["pulley"],[0,0,ph],[0,0,0,1])
    # masses
    _add_sphere(sc,"m1",nodes,{p.radius1},{p.color1})
    _add_sphere(sc,"m2",nodes,{p.radius2},{p.color2})
    pivot=[0,0,ph]; str_col=[0.25,0.18,0.10,1.0]
    z0={z_start:.4f}; a={a:.6f}; sign={sign:.1f}; max_dz={max_dz:.4f}
    frames=[]
    for fi in range(N_FRAMES):
        t=fi/30.0
        dz=min(0.5*a*t*t, max_dz)
        z1=z0+sign*dz; z2=z0-sign*dz
        c1=[-0.13,0.0,z1]; c2=[0.13,0.0,z2]
        _set_pose(sc,nodes["m1"],c1,[0,0,0,1]); _set_pose(sc,nodes["m2"],c2,[0,0,0,1])
        _update_string(sc,nodes,"str1",pivot,c1,0.007,str_col)
        _update_string(sc,nodes,"str2",pivot,c2,0.007,str_col)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_atwood_machine")
    print("OK")
