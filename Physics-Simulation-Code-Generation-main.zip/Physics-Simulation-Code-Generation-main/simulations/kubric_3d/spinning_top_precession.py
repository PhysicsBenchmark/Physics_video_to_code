"""spinning_top_precession — gyroscope precessing under gravity."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np
CAM_EYE=(2.5,-2.5,2.0); CAM_TARGET=(0.0,0.0,0.3); N_FRAMES=150
@dataclass
class Params:
    seed: int
    radius:float
    height:float
    mass:float
    spin:float
    tilt:float
    friction:float
    color:List[float]
def random_params(seed):
    random.seed(seed); np.random.seed(seed)
    return Params(seed=seed,radius=random.uniform(0.07,0.14),height=random.uniform(0.22,0.42),
        mass=random.uniform(0.05,0.30),spin=random.uniform(18.0,45.0),
        tilt=random.uniform(5.0,18.0),friction=random.uniform(0.5,0.9),
        color=[random.random(),random.random(),random.random(),1.0])
def generate_sample(seed, out_dir):
    _dir=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0,_dir)
    from simulations.kubric_3d._base import (Physics,Renderer,run_loop,save_sample,
        build_cot,param_entry,muted_grey,random_hue_color,STANDALONE_IMPORTS,STANDALONE_UTILS)
    import pybullet as pb
    random.seed(seed); np.random.seed(seed)
    p=random_params(seed)
    phys=Physics(); ren=Renderer(CAM_EYE,CAM_TARGET)
    _dyn=[]; _extra_sync=None
    p=random_params(seed)
    phys.add_plane(friction=p.friction); ren.add_plane_mesh("fl",3.0,muted_grey())
    tilt_r=math.radians(p.tilt); orn=pb.getQuaternionFromEuler([tilt_r,0,0])
    pos=[0,0,p.radius*0.15+p.height/2]
    top_id=phys.add_cylinder(p.radius,p.height,pos,orn=orn,mass=p.mass,
                             friction=p.friction,restitution=0.1)
    pb.resetBaseVelocity(top_id,[0,0,0],[0,0,p.spin],physicsClientId=phys.client)
    ren.add_cylinder("top",p.radius,p.height,p.color,metallic=0.3,roughness=0.2)
    _dyn.append(("top",top_id))
    frames=run_loop(phys,ren,_dyn,N_FRAMES,extra_sync_fn=_extra_sync)
    cot=build_cot("spinning_top_precession","rigid_body",seed,
        f"Top r={p.radius:.3f}m h={p.height:.3f}m m={p.mass:.3f}kg spin={p.spin:.1f}rad/s tilt={p.tilt:.1f}deg.",
        "Gyroscopic precession (Euler equations)","Tilted top precesses: Omega_p=Mgd/(Iz*wz)",r"\Omega_p = Mgd/(I_z \omega_z)",
        ["Solid cylinder: Iz=mr^2/2","Nutation neglected for high spin","Tip contact ~small sphere"],
        ["r (m)","v (m/s)","q","w (rad/s)"],
        ["dot_r=v","m*dot_v=mg+Fc","I*dot_w=tc-wxIw"],
        "j=-(1+e)*v_n/(1/mA+1/mB+cross)",
        ["Torque from gravity: tau=r_cm x mg","Precession: Omega_p = tau/(Iz*wz)","As wz decreases, Omega_p increases"],[f"Top precesses at ~{p.mass*9.81*(p.height/2)*math.sin(math.radians(p.tilt))/(0.5*p.mass*p.radius**2*p.spin):.3f} rad/s","Gradual energy loss via friction","Eventually falls flat"],
        {k:param_entry(getattr(p,k),"",k) for k in ["radius","height","mass","spin","tilt","friction"]})
    save_sample(out_dir,asdict(p),cot,make_standalone_code(p),frames)
    phys.close(); ren.close()
def make_standalone_code(p):
    _dir=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0,_dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS,STANDALONE_UTILS
    body=f"""
# spinning_top_precession  seed={p.seed}
import pybullet as pb
N_FRAMES=150; CAM_EYE=(2.5,-2.5,2.0); CAM_TARGET=(0.0,0.0,0.3)
def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    tilt_r=math.radians({p.tilt}); orn=pb.getQuaternionFromEuler([tilt_r,0,0])
    s=pb.createCollisionShape(pb.GEOM_CYLINDER,radius={p.radius},height={p.height},physicsClientId=c)
    tid=pb.createMultiBody({p.mass},s,-1,[0,0,{p.radius*0.15+p.height/2}],orn,physicsClientId=c)
    pb.changeDynamics(tid,-1,lateralFriction={p.friction},restitution=0.1,physicsClientId=c)
    pb.resetBaseVelocity(tid,[0,0,0],[0,0,{p.spin}],physicsClientId=c)
    _add_cylinder(sc,"top",nodes,{p.radius},{p.height},{p.color})
    _add_box(sc,"fl",nodes,[1.5,1.5,0.02],muted_grey()); _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    bids=[("top",tid)]; frames=[]
    for _ in range(150):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""
    return STANDALONE_IMPORTS+STANDALONE_UTILS+body
if __name__=="__main__":
    generate_sample(seed=0,out_dir=f"/tmp/test_spinning_top_precession"); print("OK")
