"""rope_pendulum_swing — chain pendulum with sphere weight swings from fixed pivot."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (5, -3, 4)
CAM_TARGET = (0, 0, 1.5)
N_FRAMES   = 180


@dataclass
class Params:
    seed:           int
    n_links:        int
    link_radius:    float
    link_half_len:  float
    weight_mass:    float
    weight_radius:  float
    pivot_height:   float
    init_swing_vel: float   # initial sideways velocity (m/s)
    floor_friction: float
    chain_color:    List[float]
    weight_color:   List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        n_links=random.randint(8, 14),
        link_radius=random.uniform(0.02, 0.04),
        link_half_len=random.uniform(0.04, 0.08),
        weight_mass=random.uniform(0.3, 1.0),
        weight_radius=random.uniform(0.06, 0.12),
        pivot_height=random.uniform(2.5, 3.5),
        init_swing_vel=random.uniform(0.5, 1.5),
        floor_friction=random.uniform(0.4, 0.7),
        chain_color=[random.uniform(0.4, 0.7), random.uniform(0.4, 0.7),
                     random.uniform(0.4, 0.7), 1.0],
        weight_color=[random.uniform(0.6, 1.0), random.uniform(0.2, 0.6),
                      random.uniform(0.1, 0.5), 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 10.0, [0.42, 0.42, 0.45, 1.0])
    ren.set_static_pose("floor", [0, 0, 0])

    pivot = [0.0, 0.0, p.pivot_height]
    rope_segment = p.link_half_len * 2 + p.link_radius * 0.5
    rope_length = max(0.8, min(p.n_links * rope_segment,
                               p.pivot_height - p.weight_radius - 0.25))
    bottom_z = p.pivot_height - rope_length

    anchor_id = phys.add_sphere(0.035, pivot, mass=0.0,
                                friction=0.0, restitution=0.0)
    phys.fix_body(anchor_id, pos=pivot)

    weight_id = phys.add_sphere(
        p.weight_radius, [0, 0, bottom_z],
        mass=p.weight_mass, friction=0.4, restitution=0.4,
        vel=[p.init_swing_vel, 0, 0], lin_damp=0.015, ang_damp=1.0)

    pivot_in_ball = [0.0, 0.0, rope_length]
    phys.create_constraint(
        anchor_id, -1, weight_id, -1,
        pb_mod.JOINT_POINT2POINT, [0, 0, 0],
        [0, 0, 0], pivot_in_ball,
        max_force=30000.0)

    ren.add_sphere("pivot", 0.035, [0.30, 0.26, 0.22, 1.0])
    ren.set_static_pose("pivot", pivot)
    ren.add_sphere("weight", p.weight_radius, p.weight_color)

    pivot_np = np.array(pivot, dtype=float)
    rope_radius = max(0.006, min(0.012, p.link_radius * 0.35))

    def extra_sync_fn(phys, ren, fi):
        weight_p, weight_orn = phys.get_pose(weight_id)
        diff = weight_p - pivot_np
        dist = float(np.linalg.norm(diff))
        if dist > 1e-8:
            direction = diff / dist
            corrected = pivot_np + direction * rope_length
            if abs(dist - rope_length) > rope_length * 0.01:
                vel, _ = pb_mod.getBaseVelocity(
                    weight_id, physicsClientId=phys.client)
                vel_np = np.array(vel, dtype=float)
                tangent_vel = vel_np - np.dot(vel_np, direction) * direction
                pb_mod.resetBasePositionAndOrientation(
                    weight_id, corrected.tolist(), weight_orn,
                    physicsClientId=phys.client)
                pb_mod.resetBaseVelocity(
                    weight_id, tangent_vel.tolist(), [0, 0, 0],
                    physicsClientId=phys.client)
                weight_p = corrected
        ren.set_pose("weight", weight_p, weight_orn)
        ren.update_string("rope", pivot, weight_p.tolist(),
                          rope_radius, p.chain_color)

    frames = run_loop(phys, ren, [("weight", weight_id)], N_FRAMES,
                      extra_sync_fn=extra_sync_fn)

    chain_len = rope_length
    cot = build_cot(
        simulation="rope_pendulum_swing",
        category="rope_chain",
        seed=seed,
        physical_observation=(
            f"Smooth inextensible rope of length {rope_length:.2f}m "
            f"(rendered from equivalent {p.n_links} link parameters) hangs from pivot at height "
            f"{p.pivot_height:.2f}m with sphere weight (r={p.weight_radius:.2f}m, "
            f"m={p.weight_mass:.2f}kg) at bottom. Initial swing velocity "
            f"{p.init_swing_vel:.2f} m/s sideways."),
        law_name="Spherical pendulum dynamics with inextensible rope",
        law_statement=(
            "A bob constrained to a fixed distance from a pivot oscillates under gravity; "
            "the rope transmits tension but does not stretch or compress."),
        law_formula=r"T \approx 2\pi\sqrt{L/g}",
        assumptions=[
            "Rope is massless and inextensible.",
            "Air resistance neglected.",
            "Floor provides inelastic boundary if chain reaches it.",
        ],
        state_variables=["r (m)", "v (m/s)", "q", "omega (rad/s)"],
        equations_latex=[
            r"\dot{r} = v",
            r"m\dot{v} = mg + \lambda(r-r_p)",
            r"|r-r_p| = L",
        ],
        contact_impulse="j = -(1+e)*v_n / (1/m_A + 1/m_B + cross_terms)",
        derivation_steps=[
            f"Effective pendulum length L_eff ≈ {chain_len:.2f}m.",
            f"Period T ≈ {2*math.pi*math.sqrt(chain_len/9.81):.2f}s for rigid equivalent.",
            "Constraint force removes radial acceleration that would stretch the rope.",
            "Weight at the tip follows a smooth pendulum arc.",
        ],
        expected_behavior=[
            "Rope stays taut and smooth with no crunching links.",
            "Bob swings sideways under initial velocity.",
            "Amplitude decreases slightly due to damping; system oscillates for several cycles.",
        ],
        parameters={
            "n_links":          param_entry(p.n_links, "", "Number of chain links"),
            "link_radius_m":    param_entry(p.link_radius, "m", "Link capsule radius"),
            "link_half_len_m":  param_entry(p.link_half_len, "m", "Link half-length"),
            "weight_mass_kg":   param_entry(p.weight_mass, "kg", "Bob weight mass"),
            "weight_radius_m":  param_entry(p.weight_radius, "m", "Bob weight radius"),
            "pivot_height_m":   param_entry(p.pivot_height, "m", "Pivot height"),
            "init_swing_vel_mps": param_entry(p.init_swing_vel, "m/s", "Initial swing velocity"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    segment  = p.link_half_len * 2 + p.link_radius * 0.5
    rope_length = max(0.8, min(p.n_links * segment,
                               p.pivot_height - p.weight_radius - 0.25))
    bottom_z = p.pivot_height - rope_length
    rope_radius = max(0.006, min(0.012, p.link_radius * 0.35))
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# rope_pendulum_swing  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[5.0,5.0,0.02],[0.42,0.42,0.45,1.0]); _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    pivot=[0.0,0.0,{p.pivot_height}]
    rope_len={rope_length}; rope_radius={rope_radius}
    anch_shape=pb.createCollisionShape(pb.GEOM_SPHERE,radius=0.035,physicsClientId=c)
    anch=pb.createMultiBody(0,anch_shape,-1,pivot,[0,0,0,1],physicsClientId=c)
    pb.createConstraint(anch,-1,-1,-1,pb.JOINT_FIXED,[0,0,0],[0,0,0],pivot,physicsClientId=c)
    sph_shape=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.weight_radius},physicsClientId=c)
    wid=pb.createMultiBody({p.weight_mass},sph_shape,-1,[0,0,{bottom_z}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(wid,-1,lateralFriction=0.4,restitution=0.4,linearDamping=0.015,angularDamping=1.0,physicsClientId=c)
    cid=pb.createConstraint(anch,-1,wid,-1,pb.JOINT_POINT2POINT,[0,0,0],[0,0,0],[0,0,rope_len],physicsClientId=c)
    pb.changeConstraint(cid,maxForce=30000,physicsClientId=c)
    pb.resetBaseVelocity(wid,[{p.init_swing_vel},0,0],[0,0,0],physicsClientId=c)
    _add_sphere(sc,"pivot",nodes,0.035,[0.30,0.26,0.22,1.0]); _set_pose(sc,nodes["pivot"],pivot,[0,0,0,1])
    _add_sphere(sc,"weight",nodes,{p.weight_radius},{p.weight_color})
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        pp,oo=pb.getBasePositionAndOrientation(wid,physicsClientId=c)
        pivot_np=np.array(pivot,float); pp_np=np.array(pp,float); diff=pp_np-pivot_np
        dist=float(np.linalg.norm(diff))
        if dist>1e-8:
            direction=diff/dist; corrected=pivot_np+direction*rope_len
            if abs(dist-rope_len)>rope_len*0.01:
                vel,ang=pb.getBaseVelocity(wid,physicsClientId=c)
                vel_np=np.array(vel,float); tangent_vel=vel_np-np.dot(vel_np,direction)*direction
                pb.resetBasePositionAndOrientation(wid,corrected.tolist(),oo,physicsClientId=c)
                pb.resetBaseVelocity(wid,tangent_vel.tolist(),[0,0,0],physicsClientId=c)
                pp_np=corrected
        _set_pose(sc,nodes["weight"],pp_np,oo)
        _update_string(sc,nodes,"rope",pivot,pp_np.tolist(),rope_radius,{p.chain_color})
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_rope_pendulum_swing")
    print("OK")
