"""rolling_ball_loop_track — ball rolls along flat track then through a circular loop."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (0.5, -5.5, 1.8)
CAM_TARGET = (0.5,  0.0, 0.5)
N_FRAMES   = 150
N_RING     = 24   # sphere markers forming the loop


@dataclass
class Params:
    seed: int
    R_loop: float     # loop radius (m)
    R_ball: float     # ball radius (m)
    v0: float         # entry speed at loop bottom (m/s)
    ball_color: List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    R_loop = random.uniform(0.30, 0.45)
    R_ball = 0.10
    R_inner = R_loop - R_ball
    v0_min = math.sqrt(5 * 9.81 * R_inner)
    v0 = v0_min * random.uniform(1.08, 1.25)
    h = random.random(); s, v = 0.85, 0.90; hi = int(h * 6) % 6; f = h * 6 - int(h * 6)
    p_ = v*(1-s); q = v*(1-f*s); t = v*(1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return Params(seed=seed, R_loop=R_loop, R_ball=R_ball, v0=v0,
                  ball_color=[r, g, b, 1.0])


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Renderer, save_sample, build_cot, param_entry,
        STANDALONE_IMPORTS, STANDALONE_UTILS, FPS)

    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    ren = Renderer(CAM_EYE, CAM_TARGET)

    g = 9.81
    R_inner = p.R_loop - p.R_ball

    # Geometry
    x_entry = -1.4          # left end of flat track
    x_loop  = 0.6           # x-centre of loop
    x_exit  = x_loop + p.R_loop + 0.8    # end of exit track

    # Floor
    ren.add_plane_mesh("floor", 10.0, [0.38, 0.38, 0.42, 1.0])
    ren.set_static_pose("floor", [0, 0, -0.02])

    # Flat entry track (narrow box)
    track_half = [(x_loop - p.R_loop - x_entry) / 2, 0.12, 0.02]
    track_cx   = x_entry + track_half[0]
    ren.add_box("trk_in", track_half, [0.50, 0.45, 0.40, 1.0])
    ren.set_static_pose("trk_in", [track_cx, 0.0, 0.02])

    # Exit track
    exit_half = [(x_exit - (x_loop + p.R_loop)) / 2, 0.12, 0.02]
    exit_cx   = x_loop + p.R_loop + exit_half[0]
    ren.add_box("trk_out", exit_half, [0.50, 0.45, 0.40, 1.0])
    ren.set_static_pose("trk_out", [exit_cx, 0.0, 0.02])

    # Loop visual: N_RING small spheres arranged in a vertical circle
    ring_r = 0.04
    for i in range(N_RING):
        ang = 2 * math.pi * i / N_RING
        rx = x_loop + p.R_loop * math.sin(ang)
        rz = p.R_loop - p.R_loop * math.cos(ang)   # 0 at bottom, 2*R at top
        ren.add_sphere(f"rng{i}", ring_r, [0.90, 0.75, 0.10, 1.0])
        ren.set_static_pose(f"rng{i}", [rx, 0.0, rz])

    # Ball
    ren.add_sphere("ball", p.R_ball, p.ball_color)

    # Kinematics
    # Phase 1: flat track — ball approaches at v0 from far left
    x0_flat = x_entry + p.R_ball
    # Time to reach loop entry (x = x_loop - R_inner at loop bottom)
    x_loop_entry = x_loop - R_inner   # rightmost x on flat before entering loop
    # With constant v0 on flat:
    t_entry = (x_loop_entry - x0_flat) / p.v0

    # Phase 2: loop — integrate dφ/dt = v(φ)/R_inner using small dt
    dt_phys = 1.0 / (FPS * 8)
    steps = 8

    # Phase 3: exit flat at same speed v0 (energy conserved, loop is smooth)
    # x_loop_exit = x_loop + 0  (bottom right of loop, φ=2π → same as entry)
    # Actually ball exits at x_loop + R_inner after traversing full loop
    # For simplicity: treat exit at same height as entry, speed = v0

    phi_state = [0.0, False, 0.0]   # [phi, in_loop, t_loop_done]
    t_loop_start = [0.0]
    t_loop_end   = [None]

    # Pre-compute loop trajectory by integrating
    loop_traj = []  # list of (phi) at each physics step
    phi = 0.0
    while phi < 2 * math.pi:
        v = math.sqrt(max(0.001, p.v0**2 - 2 * g * R_inner * (1 - math.cos(phi))))
        phi += (v / R_inner) * dt_phys
        loop_traj.append(min(phi, 2 * math.pi))

    frames = []
    for fi in range(N_FRAMES):
        t = fi / float(FPS)

        if t < t_entry:
            # Flat approach
            bx = x0_flat + p.v0 * t
            bz = p.R_ball
        elif t < t_entry + len(loop_traj) * dt_phys:
            # In loop
            step_idx = int((t - t_entry) / dt_phys)
            step_idx = min(step_idx, len(loop_traj) - 1)
            phi_cur = loop_traj[step_idx]
            bx = x_loop + R_inner * math.sin(phi_cur)
            bz = p.R_loop - R_inner * math.cos(phi_cur)
        else:
            # Exit flat
            t_after_loop = t - t_entry - len(loop_traj) * dt_phys
            bx = x_loop + R_inner + p.v0 * t_after_loop
            bz = p.R_ball

        ren.set_pose("ball", [bx, 0.0, bz], [0, 0, 0, 1])
        frames.append(ren.render_frame())

    v_top = math.sqrt(max(0, p.v0**2 - 4 * g * R_inner))
    cot = build_cot(
        simulation="rolling_ball_loop_track",
        category="rigid_body_constrained",
        seed=seed,
        physical_observation=(
            f"Ball (R={p.R_ball:.2f}m) enters loop (R_loop={p.R_loop:.2f}m) "
            f"at v₀={p.v0:.2f}m/s. v_top={v_top:.2f}m/s."
        ),
        law_name="Energy conservation on loop track — centripetal condition",
        law_statement=(
            "½mv²+mgh = const; at loop top v_top²≥gR for contact. "
            "v₀ ≥ √(5gR_inner) ensures full loop."
        ),
        law_formula="v(h)=\\sqrt{v_0^2-2gh};\\quad v_{top}\\ge\\sqrt{gR}",
        assumptions=[
            "No friction losses (ideal track).",
            "Ball point-mass for energy purposes; ball radius accounts for track geometry.",
            "Circular loop in vertical plane.",
        ],
        state_variables=["φ (rad)", "v (m/s)", "x (m)", "z (m)"],
        equations_latex=[
            "v(\\phi)=\\sqrt{v_0^2-2gR_{inner}(1-\\cos\\phi)}",
            "\\dot\\phi=v/R_{inner}",
        ],
        contact_impulse="N/A (smooth track, continuous constraint)",
        derivation_steps=[
            f"R_loop={p.R_loop:.3f}m, R_ball={p.R_ball:.2f}m, R_inner={R_inner:.3f}m",
            f"v_min for loop = √(5gR_inner) = {math.sqrt(5*g*R_inner):.2f} m/s",
            f"Actual v₀ = {p.v0:.2f} m/s → margin = {p.v0/math.sqrt(5*g*R_inner):.2f}×",
            f"Speed at top = {v_top:.2f} m/s (centripetal acc = {v_top**2/R_inner:.2f} m/s²)",
        ],
        expected_behavior=[
            f"Ball rolls along flat track at {p.v0:.2f} m/s.",
            f"Enters loop and climbs to top at z={2*p.R_loop:.2f}m.",
            f"v at top = {v_top:.2f} m/s > √(gR)={math.sqrt(g*R_inner):.2f} m/s.",
            "Ball exits loop and continues on exit track.",
        ],
        parameters={
            "R_loop": param_entry(p.R_loop, "m",   "loop radius"),
            "R_ball": param_entry(p.R_ball, "m",   "ball radius"),
            "v0":     param_entry(p.v0,     "m/s", "entry speed at loop bottom"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    R_inner = p.R_loop - p.R_ball
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# rolling_ball_loop_track  seed={p.seed}
import math
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}
R_LOOP={p.R_loop}; R_BALL={p.R_ball}; R_INNER={R_inner}; V0={p.v0}; G=9.81

def main():
    ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    _add_box(sc,"fl",nodes,[5,5,0.02],[0.38,0.38,0.42,1.0]); _set_pose(sc,nodes["fl"],[0,0,-0.02],[0,0,0,1])
    x_loop=0.6; x_entry=-1.4; N_RING={N_RING}
    for i in range(N_RING):
        ang=2*math.pi*i/N_RING
        _add_sphere(sc,f"rng{{i}}",nodes,0.04,[0.90,0.75,0.10,1.0])
        _set_pose(sc,nodes[f"rng{{i}}"],[x_loop+R_LOOP*math.sin(ang),0,R_LOOP-R_LOOP*math.cos(ang)],[0,0,0,1])
    _add_sphere(sc,"ball",nodes,R_BALL,{p.ball_color})
    dt=1/240.0; phi=0.0; traj=[]
    while phi<2*math.pi:
        v=math.sqrt(max(0.001,V0**2-2*G*R_INNER*(1-math.cos(phi)))); phi+=v/R_INNER*dt; traj.append(min(phi,2*math.pi))
    t_entry=(x_loop-R_INNER-(-1.4+R_BALL))/V0; frames=[]
    for fi in range(N_FRAMES):
        t=fi/30.0
        if t<t_entry: bx=-1.4+R_BALL+V0*t; bz=R_BALL
        elif t<t_entry+len(traj)*dt:
            idx=min(int((t-t_entry)/dt),len(traj)-1); phi_c=traj[idx]
            bx=x_loop+R_INNER*math.sin(phi_c); bz=R_LOOP-R_INNER*math.cos(phi_c)
        else: bx=x_loop+R_INNER+V0*(t-t_entry-len(traj)*dt); bz=R_BALL
        _set_pose(sc,nodes["ball"],[bx,0,bz],[0,0,0,1])
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_rolling_ball_loop_track")
    print("OK")
