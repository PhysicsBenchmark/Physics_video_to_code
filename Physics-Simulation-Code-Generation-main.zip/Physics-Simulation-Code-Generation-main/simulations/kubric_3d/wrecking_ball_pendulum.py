"""wrecking_ball_pendulum — heavy sphere swings on rope and demolishes a block wall."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (6, -3, 4)
CAM_TARGET = (0, 0, 1.5)
N_FRAMES   = 150


@dataclass
class Params:
    seed: int
    pivot_height: float
    rope_length: float
    ball_radius: float
    ball_mass: float
    release_angle_deg: float
    wall_n_blocks: int
    block_mass: float
    restitution: float
    floor_friction: float
    color_ball: List[float]
    color_block: List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    pivot_height = random.uniform(3.5, 5.0)
    # Ensure ball clears floor at bottom of arc (pivot_height - rope_length >= 1.2)
    rope_length = random.uniform(2.5, min(3.5, pivot_height - 1.2))
    return Params(
        seed=seed,
        pivot_height=pivot_height,
        rope_length=rope_length,
        ball_radius=random.uniform(0.2, 0.4),
        ball_mass=random.uniform(5.0, 15.0),
        release_angle_deg=random.uniform(30.0, 60.0),
        wall_n_blocks=random.randint(6, 12),
        block_mass=random.uniform(0.3, 1.0),
        restitution=random.uniform(0.3, 0.6),
        floor_friction=random.uniform(0.4, 0.7),
        color_ball=random_hue_color_static(),
        color_block=random_hue_color_static(),
    )


def random_hue_color_static():
    h = random.random()
    s, v = 0.85, 0.90
    hi = int(h * 6) % 6
    f  = h * 6 - int(h * 6)
    p_ = v * (1 - s); q = v * (1 - f*s); t = v * (1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return [r, g, b, 1.0]


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 10.0, [0.42, 0.42, 0.45, 1.0])
    ren.set_static_pose("floor", [0, 0, -0.02])

    # Place the wrecking ball at (L*sin(theta), 0, H - L*cos(theta))
    theta = math.radians(p.release_angle_deg)
    bx = p.rope_length * math.sin(theta)
    bz = p.pivot_height - p.rope_length * math.cos(theta)
    ball_pos = [bx, 0.0, bz]

    ball_id = phys.add_sphere(
        radius=p.ball_radius, pos=ball_pos,
        mass=p.ball_mass, friction=0.3, restitution=p.restitution)

    # Create a fixed anchor body at the pivot point (mass=0 → static)
    anchor_id = phys.add_sphere(radius=0.05, pos=[0.0, 0.0, p.pivot_height],
                                mass=0.0, friction=0.0, restitution=0.0)
    phys.fix_body(anchor_id, pos=[0.0, 0.0, p.pivot_height])

    # Connect ball to anchor with point2point constraint
    pivot = [0.0, 0.0, p.pivot_height]
    pivot_in_ball = [pivot[0]-ball_pos[0], pivot[1]-ball_pos[1], pivot[2]-ball_pos[2]]
    phys.create_constraint(
        anchor_id, -1, ball_id, -1,
        pb_mod.JOINT_POINT2POINT, [0, 0, 0],
        [0.0, 0.0, 0.0],
        pivot_in_ball,
        max_force=8000.0)

    ren.add_sphere("ball", p.ball_radius, p.color_ball, metallic=0.3, roughness=0.2)
    ren.set_static_pose("ball", ball_pos)

    # Build wall just past the bottom of the arc so ball hits it at lowest point
    # wall_x slightly negative so ball (swinging left through x=0) hits at near-minimum height
    wall_x = -(p.ball_radius + 0.3)
    # Ball height at bottom of arc = pivot_height - rope_length
    ball_bottom_z = p.pivot_height - p.rope_length
    dyn = [("ball", ball_id)]
    n_cols = max(1, p.wall_n_blocks // 3)
    rows = (p.wall_n_blocks + n_cols - 1) // n_cols
    # Scale block half-height so the stack reaches ball center height
    block_half_h = max(0.10, min(0.28, ball_bottom_z / (2.2 * rows)))
    block_he = [0.12, 0.22, block_half_h]
    idx = 0
    for row in range(rows):
        for col in range(n_cols):
            if idx >= p.wall_n_blocks:
                break
            bx_w = wall_x
            by_w = (col - n_cols / 2.0 + 0.5) * block_he[1] * 2.2
            bz_w = block_he[2] + row * block_he[2] * 2.1
            name = f"blk{idx}"
            bid = phys.add_box(
                block_he, [bx_w, by_w, bz_w],
                mass=p.block_mass, friction=p.floor_friction,
                restitution=p.restitution)
            ren.add_box(name, block_he, p.color_block)
            ren.set_static_pose(name, [bx_w, by_w, bz_w])
            dyn.append((name, bid))
            idx += 1

    _pivot = [0.0, 0.0, p.pivot_height]
    _ball_id = ball_id
    str_radius = 0.006
    str_color = [0.25, 0.18, 0.10, 1.0]

    def extra_sync_fn(phys, ren, fi):
        ball_p, _ = phys.get_pose(_ball_id)
        ren.update_string("string", _pivot, ball_p.tolist(), str_radius, str_color)

    frames = run_loop(phys, ren, dyn, N_FRAMES, extra_sync_fn=extra_sync_fn)

    cot = build_cot(
        simulation="wrecking_ball_pendulum",
        category="rigid_body_constrained",
        seed=seed,
        physical_observation=(
            f"Wrecking ball r={p.ball_radius:.2f}m m={p.ball_mass:.1f}kg swings "
            f"from pivot h={p.pivot_height:.2f}m on rope L={p.rope_length:.2f}m, "
            f"released at {p.release_angle_deg:.1f}° and demolishes {p.wall_n_blocks} blocks."
        ),
        law_name="Conservation of Energy + Impulse-Momentum",
        law_statement=(
            "A pendulum converts gravitational PE to KE; on collision kinetic energy "
            "transfers to target blocks via impulsive contact forces."
        ),
        law_formula="E_k = mgh = mgL(1-cos θ); j = -(1+e)·v_rel / (1/m_A + 1/m_B)",
        assumptions=[
            "Rigid ball and blocks",
            "Point-mass pendulum approximation for energy calculation",
            "Coulomb friction at floor and block contacts",
            "Constraint rope is massless and inextensible",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg+T\\hat{r}+F_c",
            "I\\dot{\\omega}=\\tau_c-\\omega\\times I\\omega",
            "E_k = mgL(1-\\cos\\theta)",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            "Initial PE = m·g·L·(1 - cos θ)",
            "At bottom: KE = m·g·L·(1 - cos θ) → v = sqrt(2gL(1-cosθ))",
            f"v_bottom ≈ {math.sqrt(2*9.81*p.rope_length*(1-math.cos(theta))):.2f} m/s",
            "Ball hits wall; impulse j proportional to relative normal velocity",
            "Lighter blocks scatter; energy partitions among translation and rotation",
        ],
        expected_behavior=[
            "Ball swings inward accelerating",
            "Strikes wall near bottom of arc",
            "Blocks scatter with angular momentum",
            "Ball continues swinging (reduced amplitude) after collision",
        ],
        parameters={
            "pivot_height":      param_entry(p.pivot_height,      "m",  "height of pivot above ground"),
            "rope_length":       param_entry(p.rope_length,       "m",  "pendulum rope length"),
            "ball_radius":       param_entry(p.ball_radius,       "m",  "wrecking ball radius"),
            "ball_mass":         param_entry(p.ball_mass,         "kg", "wrecking ball mass"),
            "release_angle_deg": param_entry(p.release_angle_deg, "°",  "release angle from vertical"),
            "wall_n_blocks":     param_entry(p.wall_n_blocks,     "",   "number of wall blocks"),
            "block_mass":        param_entry(p.block_mass,        "kg", "mass of each block"),
            "restitution":       param_entry(p.restitution,       "",   "coefficient of restitution"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    theta = math.radians(p.release_angle_deg)
    bx = p.rope_length * math.sin(theta)
    bz = p.pivot_height - p.rope_length * math.cos(theta)
    pivot_in_ball = [-bx, 0.0, p.pivot_height - bz]  # vector from ball to pivot in ball local frame
    wall_x_sa = -(p.ball_radius + 0.3)
    ball_bottom_z = p.pivot_height - p.rope_length
    n_cols = max(1, p.wall_n_blocks // 3)
    rows = (p.wall_n_blocks + n_cols - 1) // n_cols
    block_half_h = max(0.10, min(0.28, ball_bottom_z / (2.2 * rows)))
    block_he = [0.12, 0.22, block_half_h]
    block_setup_lines = []
    idx = 0
    for row in range(rows):
        for col in range(n_cols):
            if idx >= p.wall_n_blocks:
                break
            bx_w = wall_x_sa
            by_w = (col - n_cols / 2.0 + 0.5) * block_he[1] * 2.2
            bz_w = block_he[2] + row * block_he[2] * 2.1
            block_setup_lines.append(
                f"    s=p.createCollisionShape(p.GEOM_BOX,halfExtents={block_he},physicsClientId=c)\n"
                f"    bid=p.createMultiBody({p.block_mass},s,-1,[{bx_w:.3f},{by_w:.3f},{bz_w:.3f}],[0,0,0,1],physicsClientId=c)\n"
                f"    p.changeDynamics(bid,-1,lateralFriction={p.floor_friction},restitution={p.restitution},physicsClientId=c)\n"
                f"    _add_box(sc,'blk{idx}',nodes,{block_he},{p.color_block})\n"
                f"    _set_pose(sc,nodes['blk{idx}'],[{bx_w:.3f},{by_w:.3f},{bz_w:.3f}],[0,0,0,1])\n"
                f"    bids.append(('blk{idx}',bid))\n"
            )
            idx += 1
    block_code = "".join(block_setup_lines)
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# wrecking_ball_pendulum  seed={p.seed}
import pybullet as p
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    p.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[5.0,5.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,-0.02],[0,0,0,1])
    # anchor (static pinned body at pivot)
    sa=p.createCollisionShape(p.GEOM_SPHERE,radius=0.05,physicsClientId=c)
    anc=p.createMultiBody(0,sa,-1,[0,0,{p.pivot_height}],[0,0,0,1],physicsClientId=c)
    anc_cid=p.createConstraint(anc,-1,-1,-1,p.JOINT_FIXED,[0,0,0],[0,0,0],[0,0,{p.pivot_height}],physicsClientId=c)
    p.changeConstraint(anc_cid,maxForce=50000,physicsClientId=c)
    # ball
    sb=p.createCollisionShape(p.GEOM_SPHERE,radius={p.ball_radius},physicsClientId=c)
    ball=p.createMultiBody({p.ball_mass},sb,-1,[{bx:.3f},0,{bz:.3f}],[0,0,0,1],physicsClientId=c)
    p.changeDynamics(ball,-1,lateralFriction=0.3,restitution={p.restitution},physicsClientId=c)
    ball_cid=p.createConstraint(anc,-1,ball,-1,p.JOINT_POINT2POINT,[0,0,0],[0,0,0],{list(pivot_in_ball)},physicsClientId=c)
    p.changeConstraint(ball_cid,maxForce=8000,physicsClientId=c)
    _add_sphere(sc,"ball",nodes,{p.ball_radius},{p.color_ball})
    bids=[("ball",ball)]
{block_code}
    frames=[]; pivot_pos=[0,0,{p.pivot_height}]
    for _ in range(N_FRAMES):
        for __ in range(8): p.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn=p.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn)
        bp,_=p.getBasePositionAndOrientation(ball,physicsClientId=c)
        _update_string(sc,nodes,"string",pivot_pos,list(bp),0.006,[0.25,0.18,0.10,1.0])
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); p.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_wrecking_ball_pendulum")
    print("OK")
