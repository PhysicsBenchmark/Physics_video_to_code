"""balloon_tether_wall_pull — buoyant balloon drags a tethered block into a brick wall.

The balloon experiences a constant upward buoyancy force (helium model) plus a
constant horizontal "wind"/lateral force directed toward a stacked brick wall.
An inextensible tether (PyBullet POINT2POINT distance constraint) joins the
balloon to a small anchor block resting on a low-friction floor.  The
horizontal force tilts the balloon forward; the resulting tether tension drags
the anchor along the floor into the wall, where the impact dismantles the
stack.  The balloon's vertical buoyancy keeps it lifted throughout.
"""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (4.5, -5.0, 3.6)
CAM_TARGET = (0.0,  0.4, 1.0)
N_FRAMES   = 150
G          = 9.81
DRAG_COEF  = 4.0   # N·s/m  linear aerodynamic drag on the balloon
# Wind acts as an impulse: pushes the balloon forward only long enough to
# drive the anchor through the wall.  After this many frames it is switched
# off so drag pulls the system to a stop and keeps everything on-screen.
WIND_FRAMES = 45


@dataclass
class Params:
    seed: int
    balloon_radius: float
    balloon_mass: float
    balloon_pos: List[float]
    buoyancy_force: float
    wind_force: float
    anchor_pos: List[float]
    anchor_mass: float
    anchor_half_ext: List[float]
    tether_length: float
    floor_friction: float
    wall_columns: int
    wall_rows: int
    wall_block_half_ext: List[float]
    wall_origin: List[float]
    wall_block_mass: float
    wall_block_colors: List[List[float]]
    balloon_color: List[float]
    anchor_color: List[float]
    tether_color: List[float]


def random_params(seed: int) -> Params:
    rng = random.Random(seed)
    balloon_radius  = rng.uniform(0.16, 0.20)
    balloon_mass    = rng.uniform(0.03, 0.05)
    buoyancy_force  = rng.uniform(2.0, 3.0)             # vertical lift force (N)
    wind_force      = rng.uniform(4.5, 6.0)             # horizontal force (+y, N)
    anchor_mass     = rng.uniform(0.32, 0.55)           # heavy enough to stay grounded
    anchor_half_ext = [0.10, 0.10, 0.07]
    tether_length   = rng.uniform(0.75, 1.0)
    floor_friction  = 0.20                              # low so anchor slides on impact run
    anchor_pos = [0.0, -0.05, anchor_half_ext[2]]       # slightly behind origin -> runway to wall
    balloon_pos = [
        anchor_pos[0],
        anchor_pos[1],
        anchor_pos[2] + anchor_half_ext[2] + tether_length + balloon_radius,
    ]
    wall_columns = 4
    wall_rows    = 3
    wbhe = [0.16, 0.10, 0.10]
    wall_origin = [-wbhe[0] * (wall_columns - 1), 0.65, wbhe[2]]
    wall_block_colors = [
        [rng.uniform(0.30, 0.85), rng.uniform(0.30, 0.85), rng.uniform(0.30, 0.85), 1.0]
        for _ in range(wall_columns * wall_rows)
    ]
    return Params(
        seed=seed,
        balloon_radius=balloon_radius,
        balloon_mass=balloon_mass,
        balloon_pos=balloon_pos,
        buoyancy_force=buoyancy_force,
        wind_force=wind_force,
        anchor_pos=anchor_pos,
        anchor_mass=anchor_mass,
        anchor_half_ext=anchor_half_ext,
        tether_length=tether_length,
        floor_friction=floor_friction,
        wall_columns=wall_columns,
        wall_rows=wall_rows,
        wall_block_half_ext=wbhe,
        wall_origin=wall_origin,
        wall_block_mass=0.18,
        wall_block_colors=wall_block_colors,
        balloon_color=[0.16, 0.42, 0.86, 1.0],
        anchor_color=[0.85, 0.18, 0.14, 1.0],
        tether_color=[0.94, 0.74, 0.18, 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, save_sample, build_cot, param_entry,
        FPS, STEP_RATE, metadata_only)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)
    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 7.0, [0.42, 0.42, 0.45, 1.0])

    he = p.wall_block_half_ext
    wall_dyn = []
    for i in range(p.wall_columns):
        for j in range(p.wall_rows):
            pos = [p.wall_origin[0] + 2*he[0]*i,
                   p.wall_origin[1],
                   p.wall_origin[2] + 2*he[2]*j]
            color = p.wall_block_colors[i * p.wall_rows + j]
            bid = phys.add_box(he, pos, mass=p.wall_block_mass,
                               friction=0.5, restitution=0.2)
            ren.add_box(f"wall_{i}_{j}", he, color)
            ren.set_static_pose(f"wall_{i}_{j}", pos)
            wall_dyn.append((f"wall_{i}_{j}", bid))

    anchor_bid = phys.add_box(p.anchor_half_ext, p.anchor_pos, mass=p.anchor_mass,
                              friction=p.floor_friction, restitution=0.2,
                              lin_damp=0.05, ang_damp=0.2)
    ren.add_box("anchor", p.anchor_half_ext, p.anchor_color)
    ren.set_static_pose("anchor", p.anchor_pos)

    balloon_bid = phys.add_sphere(
        radius=p.balloon_radius, pos=p.balloon_pos, mass=p.balloon_mass,
        friction=0.05, restitution=0.3,
        lin_damp=0.05, ang_damp=0.5)
    ren.add_sphere("balloon", p.balloon_radius, p.balloon_color)
    ren.set_static_pose("balloon", p.balloon_pos)

    # Inextensible tether: POINT2POINT pins anchor's top to a virtual point at
    # tether_length + balloon_radius below the balloon centre, holding the two
    # bodies at that fixed separation while still allowing free rotation.
    phys.create_constraint(
        anchor_bid, -1, balloon_bid, -1,
        pb_mod.JOINT_POINT2POINT, [0, 0, 0],
        [0, 0,  p.anchor_half_ext[2]],
        [0, 0, -(p.tether_length + p.balloon_radius)],
        max_force=800.0)

    bodies = [("anchor", anchor_bid), ("balloon", balloon_bid)] + wall_dyn
    steps_per_frame = STEP_RATE // FPS

    frames = []
    if metadata_only():
        save_sample(out_dir, asdict(p), _build_cot(p, build_cot, param_entry),
                    make_standalone_code(p), frames)
        phys.close(); ren.close(); return

    for fi in range(N_FRAMES):
        wind_y = p.wind_force if fi < WIND_FRAMES else 0.0
        for _ in range(steps_per_frame):
            bal_pos, _ = phys.get_pose(balloon_bid)
            v_lin, _   = pb_mod.getBaseVelocity(balloon_bid,
                                                 physicsClientId=phys.client)
            net = [
                -DRAG_COEF * v_lin[0],
                -DRAG_COEF * v_lin[1] + wind_y,
                -DRAG_COEF * v_lin[2] + p.buoyancy_force,
            ]
            pb_mod.applyExternalForce(balloon_bid, -1, net, list(bal_pos),
                                       pb_mod.WORLD_FRAME,
                                       physicsClientId=phys.client)
            phys.step()
        for nm, bid in bodies:
            pos, orn = phys.get_pose(bid)
            ren.set_pose(nm, pos, orn)
        a_pos, _ = phys.get_pose(anchor_bid)
        b_pos, _ = phys.get_pose(balloon_bid)
        anc_top = [float(a_pos[0]), float(a_pos[1]),
                   float(a_pos[2] + p.anchor_half_ext[2])]
        bal_bot = [float(b_pos[0]), float(b_pos[1]),
                   float(b_pos[2] - p.balloon_radius)]
        ren.update_string("tether", anc_top, bal_bot,
                          radius=0.012, color=p.tether_color)
        frames.append(ren.render_frame())

    save_sample(out_dir, asdict(p), _build_cot(p, build_cot, param_entry),
                make_standalone_code(p), frames)
    phys.close(); ren.close()


def _build_cot(p: Params, build_cot, param_entry):
    net_lift     = p.buoyancy_force - p.balloon_mass * G
    block_weight = p.anchor_mass * G
    return build_cot(
        simulation="balloon_tether_wall_pull",
        category="buoyant_tethered_body",
        seed=p.seed,
        physical_observation=(
            f"A buoyant balloon (m={p.balloon_mass:.3f} kg, lift={p.buoyancy_force:.2f} N, "
            f"wind={p.wind_force:.2f} N along +y) is tethered to a block "
            f"(m={p.anchor_mass:.3f} kg) on a low-friction floor (mu={p.floor_friction}). "
            f"The wind tilts the balloon forward; the tether tension drags the anchor "
            f"into a {p.wall_columns}x{p.wall_rows} brick wall, dismantling it. "
            f"Net upward lift {net_lift:.2f} N is below anchor weight {block_weight:.2f} N, "
            f"so the anchor stays in contact with the floor through the slide and impact."
        ),
        law_name="Buoyancy with horizontal forcing on a tethered load",
        law_statement=(
            "The balloon obeys Newton's second law with constant buoyancy F_b (vertical) "
            "and constant wind force F_w (horizontal), opposed by linear aerodynamic drag "
            "and gravity.  An inextensible tether transmits tension T to the anchor; the "
            "anchor accelerates horizontally when the horizontal component of T exceeds "
            "Coulomb friction mu N at the floor.  The anchor's momentum then dismantles "
            "the wall via impact impulses."
        ),
        law_formula=(
            "F_w - c v_y - T_y = m_b dot v_y;  F_b - m_b g - c v_z - T_z = m_b dot v_z;  "
            "T_y - mu (m_a g - T_z) = m_a dot v_a"
        ),
        assumptions=[
            "Balloon experiences a constant upward buoyancy force and a constant horizontal wind force.",
            "Linear aerodynamic drag F_d = -c v on the balloon stabilises terminal velocity.",
            "Tether is inextensible (PyBullet POINT2POINT distance constraint).",
            "Coulomb friction at the floor; floor coefficient is low so the anchor slides.",
            "Wall blocks are rigid bodies that respond to contact impulses; the stack "
            "is held only by gravity and contact friction so a moderate impact dismantles it.",
            "PyBullet integrates contacts and constraints at 240 Hz.",
        ],
        state_variables=["position r (m)", "velocity v (m/s)",
                         "orientation q", "angular velocity omega (rad/s)"],
        equations_latex=[
            "F_w - c\\,v_{b,y} - T_y = m_{b}\\,\\dot{v}_{b,y}",
            "F_b - m_{b}\\,g - c\\,v_{b,z} - T_z = m_{b}\\,\\dot{v}_{b,z}",
            "T_y - \\mu\\,(m_{a}\\,g - T_z) = m_{a}\\,\\dot{v}_{a,y}",
            "\\Delta p_{wall} = (1+e)\\,m_{eff}\\,v_{rel}\\quad\\text{at impact}",
        ],
        contact_impulse="j_n = -(1+e)(v_rel . n)/m_eff;  |j_t| <= mu |j_n|",
        derivation_steps=[
            f"Net upward lift on balloon: F_b - m_b g = {net_lift:.3f} N",
            f"Anchor weight: m_a g = {block_weight:.3f} N (anchor stays on the floor).",
            f"Horizontal wind on balloon: F_w = {p.wind_force:.3f} N (+y).",
            f"Approx. terminal horizontal speed of balloon alone: F_w/c = {p.wind_force/DRAG_COEF:.2f} m/s.",
            "Tilted tether transmits a horizontal tension component to the anchor; once "
            "T_y exceeds mu (m_a g - T_z) the anchor slides forward toward the wall.",
            "Anchor impacts the bottom row of the brick wall and the contact impulses "
            "propagate through the stack, toppling it.",
        ],
        expected_behavior=[
            "Balloon tilts forward and rises; the rigid tether stays taut.",
            "Anchor block slides along the floor toward the wall (low floor friction).",
            "Anchor strikes the wall; bricks topple and scatter.",
            "Balloon continues forward and upward after the impact, dragging the anchor "
            "through or over the dismantled debris.",
        ],
        parameters={
            "balloon_mass":     param_entry(p.balloon_mass,    "kg",   "balloon mass"),
            "balloon_radius":   param_entry(p.balloon_radius,  "m",    "balloon radius"),
            "buoyancy_force":   param_entry(p.buoyancy_force,  "N",    "constant upward force on balloon"),
            "wind_force":       param_entry(p.wind_force,      "N",    "constant horizontal (+y) force on balloon"),
            "anchor_mass":      param_entry(p.anchor_mass,     "kg",   "tethered block mass"),
            "tether_length":    param_entry(p.tether_length,   "m",    "tether length (anchor top to balloon bottom)"),
            "floor_friction":   param_entry(p.floor_friction,  "",     "Coulomb friction coefficient at the floor"),
            "wall_columns":     param_entry(p.wall_columns,    "",     "wall columns"),
            "wall_rows":        param_entry(p.wall_rows,       "",     "wall rows"),
            "wall_block_mass":  param_entry(p.wall_block_mass, "kg",   "mass of each wall brick"),
            "drag_coefficient": param_entry(DRAG_COEF,         "N s/m","linear drag coefficient on balloon"),
        })


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# balloon_tether_wall_pull  seed={p.seed}
import pybullet as pb
N_FRAMES = {N_FRAMES}; CAM_EYE = {CAM_EYE}; CAM_TARGET = {CAM_TARGET}
DRAG_COEF = {DRAG_COEF}; WIND_FRAMES = {WIND_FRAMES}
WALL_COLORS = {p.wall_block_colors}

def main():
    c = _init_physics(); ren, sc = _make_renderer(CAM_EYE, CAM_TARGET); nodes = {{}}
    plane = pb.loadURDF("plane.urdf", [0, 0, 0], physicsClientId=c)
    pb.changeDynamics(plane, -1, lateralFriction={p.floor_friction}, restitution=0.5, physicsClientId=c)
    _add_box(sc, "floor", nodes, [3.5, 3.5, 0.02], [0.42, 0.42, 0.45, 1.0])
    _set_pose(sc, nodes["floor"], [0, 0, -0.02], [0, 0, 0, 1])

    he = {p.wall_block_half_ext}
    wall_origin = {p.wall_origin}
    wall = []
    for i in range({p.wall_columns}):
        for j in range({p.wall_rows}):
            pos = [wall_origin[0] + 2*he[0]*i,
                   wall_origin[1],
                   wall_origin[2] + 2*he[2]*j]
            color = WALL_COLORS[i * {p.wall_rows} + j]
            sh = pb.createCollisionShape(pb.GEOM_BOX, halfExtents=he, physicsClientId=c)
            bid = pb.createMultiBody({p.wall_block_mass}, sh, -1, pos, [0,0,0,1], physicsClientId=c)
            pb.changeDynamics(bid, -1, lateralFriction=0.5, restitution=0.2, physicsClientId=c)
            nm = f"wall_{{i}}_{{j}}"
            _add_box(sc, nm, nodes, he, color); _set_pose(sc, nodes[nm], pos, [0,0,0,1])
            wall.append((nm, bid))

    a_he  = {p.anchor_half_ext}; a_pos = {p.anchor_pos}
    a_sh  = pb.createCollisionShape(pb.GEOM_BOX, halfExtents=a_he, physicsClientId=c)
    anchor = pb.createMultiBody({p.anchor_mass}, a_sh, -1, a_pos, [0,0,0,1], physicsClientId=c)
    pb.changeDynamics(anchor, -1, lateralFriction={p.floor_friction}, restitution=0.2,
                       linearDamping=0.05, angularDamping=0.2, physicsClientId=c)
    _add_box(sc, "anchor", nodes, a_he, {p.anchor_color}); _set_pose(sc, nodes["anchor"], a_pos, [0,0,0,1])

    b_pos = {p.balloon_pos}
    b_sh  = pb.createCollisionShape(pb.GEOM_SPHERE, radius={p.balloon_radius}, physicsClientId=c)
    balloon = pb.createMultiBody({p.balloon_mass}, b_sh, -1, b_pos, [0,0,0,1], physicsClientId=c)
    pb.changeDynamics(balloon, -1, lateralFriction=0.05, restitution=0.3,
                       linearDamping=0.05, angularDamping=0.5, physicsClientId=c)
    _add_sphere(sc, "balloon", nodes, {p.balloon_radius}, {p.balloon_color})
    _set_pose(sc, nodes["balloon"], b_pos, [0,0,0,1])

    cid = pb.createConstraint(anchor, -1, balloon, -1, pb.JOINT_POINT2POINT, [0,0,0],
                               [0, 0,  a_he[2]],
                               [0, 0, -({p.tether_length} + {p.balloon_radius})],
                               physicsClientId=c)
    pb.changeConstraint(cid, maxForce=800.0, physicsClientId=c)

    bodies = [("anchor", anchor), ("balloon", balloon)] + wall
    frames = []
    for fi in range(N_FRAMES):
        wind_y = {p.wind_force} if fi < WIND_FRAMES else 0.0
        for __ in range(8):
            bp, _ = pb.getBasePositionAndOrientation(balloon, physicsClientId=c)
            vlin, _ = pb.getBaseVelocity(balloon, physicsClientId=c)
            net = [-DRAG_COEF*vlin[0],
                   -DRAG_COEF*vlin[1] + wind_y,
                   -DRAG_COEF*vlin[2] + {p.buoyancy_force}]
            pb.applyExternalForce(balloon, -1, net, list(bp),
                                   pb.WORLD_FRAME, physicsClientId=c)
            pb.stepSimulation(physicsClientId=c)
        for nm, bid in bodies:
            pp, oo = pb.getBasePositionAndOrientation(bid, physicsClientId=c)
            _set_pose(sc, nodes[nm], pp, oo)
        ap, _ = pb.getBasePositionAndOrientation(anchor, physicsClientId=c)
        bp, _ = pb.getBasePositionAndOrientation(balloon, physicsClientId=c)
        anc_top = [ap[0], ap[1], ap[2] + a_he[2]]
        bal_bot = [bp[0], bp[1], bp[2] - {p.balloon_radius}]
        _update_string(sc, nodes, "tether", anc_top, bal_bot, 0.012, {p.tether_color})
        rgba, _ = ren.render(sc, flags=pyrender.RenderFlags.RGBA)
        frames.append(rgba[:,:,:3])
    _save_video(frames, "video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")

if __name__ == "__main__":
    main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_balloon_tether_wall_pull")
    print("OK")
