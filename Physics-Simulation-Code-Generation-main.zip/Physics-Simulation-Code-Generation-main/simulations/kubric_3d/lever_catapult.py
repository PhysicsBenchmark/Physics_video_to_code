"""lever_catapult — plank on fulcrum launches a ball from the high end."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (6, -3, 4)
CAM_TARGET = (0, 0, 1)
N_FRAMES   = 120


@dataclass
class Params:
    seed:             int
    plank_half_length: float   # half-length of plank (m)
    plank_mass:       float    # kg
    push_vel:         float    # downward velocity applied to low end (m/s)
    ball_mass:        float    # kg
    ball_radius:      float    # m
    fulcrum_height:   float    # m
    friction:         float
    plank_color:      List[float]
    ball_color:       List[float]
    floor_friction:   float


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        plank_half_length=random.uniform(1.2, 2.0),
        plank_mass=random.uniform(0.5, 2.0),
        push_vel=random.uniform(2.0, 5.0),
        ball_mass=random.uniform(0.2, 0.8),
        ball_radius=random.uniform(0.08, 0.16),
        fulcrum_height=random.uniform(0.6, 1.2),
        friction=random.uniform(0.3, 0.7),
        plank_color=[random.uniform(0.5, 0.8), random.uniform(0.3, 0.6),
                     random.uniform(0.1, 0.4), 1.0],
        ball_color=[random.uniform(0.6, 1.0), random.uniform(0.3, 0.8),
                    random.uniform(0.2, 0.6), 1.0],
        floor_friction=random.uniform(0.4, 0.7),
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 12.0, [0.42, 0.42, 0.45, 1.0])
    ren.set_static_pose("floor", [0, 0, 0])

    # Static fulcrum cylinder at origin
    fulcrum_r = 0.07
    phys.add_cylinder(fulcrum_r, p.fulcrum_height,
                      [0, 0, p.fulcrum_height / 2],
                      mass=0, friction=0.2, restitution=0.1)
    ren.add_cylinder("fulcrum", fulcrum_r, p.fulcrum_height,
                     [0.35, 0.28, 0.20, 1.0])
    ren.set_static_pose("fulcrum", [0, 0, p.fulcrum_height / 2])

    plank_thick = 0.05
    plank_z     = p.fulcrum_height + plank_thick

    # Plank starts horizontal, centred over fulcrum
    plank_id = phys.add_box(
        [p.plank_half_length, 0.12, plank_thick],
        [0, 0, plank_z],
        mass=p.plank_mass,
        friction=p.friction, restitution=0.2)
    ren.add_box("plank", [p.plank_half_length, 0.12, plank_thick], p.plank_color)

    # Ball rests on high (positive-x) end of plank
    ball_x   = p.plank_half_length - p.ball_radius - 0.02
    ball_pos = [ball_x, 0, plank_z + plank_thick + p.ball_radius]
    ball_id  = phys.add_sphere(p.ball_radius, ball_pos,
                                mass=p.ball_mass,
                                friction=p.friction, restitution=0.5)
    ren.add_sphere("ball", p.ball_radius, p.ball_color)

    # Push low (negative-x) end of plank downward
    pb_mod.resetBaseVelocity(plank_id,
                             [-p.push_vel * 0.3, 0, -p.push_vel],
                             [0, 0, 0],
                             physicsClientId=phys.client)

    dyn = [("plank", plank_id), ("ball", ball_id)]
    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="lever_catapult",
        category="articulated_jointed",
        seed=seed,
        physical_observation=(
            f"Plank (half-length {p.plank_half_length:.2f}m, mass {p.plank_mass:.2f}kg) "
            f"rests on fulcrum at height {p.fulcrum_height:.2f}m. "
            f"Ball (r={p.ball_radius:.2f}m, m={p.ball_mass:.2f}kg) on high end. "
            f"Low end pushed down at {p.push_vel:.2f} m/s."),
        law_name="Lever mechanics + projectile motion",
        law_statement=(
            "Torque applied to one end of a lever rotates it about the fulcrum, "
            "accelerating the load on the other end upward."),
        law_formula="F1*d1 = F2*d2  (torque balance at fulcrum)",
        assumptions=[
            "Plank treated as uniform rigid rod.",
            "Ball sits freely on plank surface (no attachment).",
            "Fulcrum acts as pin joint.",
        ],
        state_variables=["r (m)", "v (m/s)", "q (quaternion)", "omega (rad/s)"],
        equations_latex=[
            r"\dot{r}=v",
            r"m\dot{v}=mg+F_c",
            r"I\dot{\omega}=\tau - \omega\times I\omega",
        ],
        contact_impulse="j = -(1+e)*v_n / (1/m_A + 1/m_B + cross_terms)",
        derivation_steps=[
            f"Plank low end given downward velocity {p.push_vel:.2f} m/s.",
            "Plank rotates about fulcrum contact point.",
            f"Ball on high end (lever arm {p.plank_half_length:.2f}m) accelerates upward.",
            "Ball separates from plank and follows parabolic trajectory.",
        ],
        expected_behavior=[
            "Plank low end moves down rapidly.",
            "High end rises and launches ball upward.",
            "Ball flies off in a ballistic arc.",
        ],
        parameters={
            "plank_half_length_m": param_entry(p.plank_half_length, "m", "Plank half-length"),
            "plank_mass_kg":       param_entry(p.plank_mass, "kg", "Plank mass"),
            "push_vel_mps":        param_entry(p.push_vel, "m/s", "Push velocity on low end"),
            "ball_mass_kg":        param_entry(p.ball_mass, "kg", "Ball mass"),
            "ball_radius_m":       param_entry(p.ball_radius, "m", "Ball radius"),
            "fulcrum_height_m":    param_entry(p.fulcrum_height, "m", "Fulcrum height"),
            "friction":            param_entry(p.friction, "", "Friction coefficient"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    plank_thick = 0.05
    plank_z     = p.fulcrum_height + plank_thick
    ball_x      = p.plank_half_length - p.ball_radius - 0.02
    ball_z      = plank_z + plank_thick + p.ball_radius
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# lever_catapult  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[6.0,6.0,0.02],[0.42,0.42,0.45,1.0]); _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    fh={p.fulcrum_height}
    s=pb.createCollisionShape(pb.GEOM_CYLINDER,radius=0.07,height=fh,physicsClientId=c)
    pb.createMultiBody(0,s,-1,[0,0,fh/2],[0,0,0,1],physicsClientId=c)
    _add_cylinder(sc,"fulcrum",nodes,0.07,fh,[0.35,0.28,0.20,1.0]); _set_pose(sc,nodes["fulcrum"],[0,0,fh/2],[0,0,0,1])
    s2=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[{p.plank_half_length},0.12,0.05],physicsClientId=c)
    plank_id=pb.createMultiBody({p.plank_mass},s2,-1,[0,0,{plank_z}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(plank_id,-1,lateralFriction={p.friction},restitution=0.2,physicsClientId=c)
    pb.resetBaseVelocity(plank_id,[{-p.push_vel*0.3},0,{-p.push_vel}],[0,0,0],physicsClientId=c)
    _add_box(sc,"plank",nodes,[{p.plank_half_length},0.12,0.05],{p.plank_color})
    s3=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.ball_radius},physicsClientId=c)
    ball_id=pb.createMultiBody({p.ball_mass},s3,-1,[{ball_x},0,{ball_z}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(ball_id,-1,lateralFriction={p.friction},restitution=0.5,physicsClientId=c)
    _add_sphere(sc,"ball",nodes,{p.ball_radius},{p.ball_color})
    bids=[("plank",plank_id),("ball",ball_id)]; frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_lever_catapult")
    print("OK")
