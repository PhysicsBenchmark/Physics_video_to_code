"""robot_arm_collapse — stacked box segments topple under gravity when perturbed."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (5, -3, 4)
CAM_TARGET = (0, 0, 1.5)
N_FRAMES   = 150


@dataclass
class Params:
    seed: int
    n_links: int
    link_mass: float
    link_half_height: float
    link_half_width: float
    link_half_depth: float
    initial_perturbation_vel: float
    friction: float
    restitution: float
    colors: List[List[float]]


def _rand_color():
    h = random.random()
    s, v = 0.85, 0.90
    hi = int(h * 6) % 6
    f  = h * 6 - int(h * 6)
    p_ = v * (1 - s); q = v * (1 - f*s); t = v * (1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return [r, g, b, 1.0]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    n = random.randint(3, 4)
    colors = [_rand_color() for _ in range(n)]
    return Params(
        seed=seed,
        n_links=n,
        link_mass=random.uniform(0.5, 2.0),
        link_half_height=random.uniform(0.25, 0.45),
        link_half_width=random.uniform(0.06, 0.10),
        link_half_depth=random.uniform(0.04, 0.08),
        initial_perturbation_vel=random.uniform(0.3, 1.5),
        friction=random.uniform(0.2, 0.5),
        restitution=random.uniform(0.1, 0.4),
        colors=colors,
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.friction)
    ren.add_plane_mesh("floor", 10.0, [0.42, 0.42, 0.45, 1.0])

    link_he = [p.link_half_width, p.link_half_depth, p.link_half_height]
    seg_h = p.link_half_height * 2.0  # full height of one segment

    dyn = []
    ids = []
    for i in range(p.n_links):
        z_center = link_he[2] + i * seg_h * 2.0
        pos = [0.0, 0.0, z_center]

        if i == 0:
            # Bottom segment: fixed to ground (this is the arm base)
            bid = phys.add_box(
                link_he, pos, mass=0.0,
                friction=p.friction, restitution=p.restitution)
            phys.fix_body(bid, pos=pos)
        else:
            # Give the arm a strong angular velocity so it sweeps into the blocks
            ang_vel = [0.0, 0.0, 6.0] if i == p.n_links - 1 else [0.0, 0.0, 0.0]
            bid = phys.add_box(
                link_he, pos, mass=p.link_mass,
                friction=p.friction, restitution=p.restitution,
                ang_vel=ang_vel)
            name = f"link{i}"
            dyn.append((name, bid))

        name = f"link{i}"
        ids.append(bid)
        ren.add_box(name, link_he, p.colors[i])
        ren.set_static_pose(name, pos)

    # Place a small stack of boxes directly in the arm's sweep path (positive Y side)
    arm_reach = seg_h * 2.0 * p.n_links  # approximate reach of the arm
    sweep_dist = arm_reach * 0.6           # place boxes at ~60% of arm reach
    block_he = [0.08, 0.08, 0.10]
    scatter_colors = [[0.9, 0.3, 0.2, 1.0], [0.2, 0.7, 0.3, 1.0],
                      [0.2, 0.4, 0.9, 1.0], [0.9, 0.8, 0.1, 1.0],
                      [0.8, 0.3, 0.8, 1.0], [0.1, 0.8, 0.8, 1.0]]
    for si in range(6):
        col = si % 2
        row = si // 2
        bx = sweep_dist + col * block_he[0] * 2.2
        by = (row - 0.5) * block_he[1] * 2.2
        bz = block_he[2] * (1 + 0)  # ground level
        sname = f"scat{si}"
        sbid = phys.add_box(block_he, [bx, by, bz],
                             mass=0.4, friction=p.friction, restitution=p.restitution)
        ren.add_box(sname, block_he, scatter_colors[si])
        ren.set_static_pose(sname, [bx, by, bz])
        dyn.append((sname, sbid))

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    total_h = seg_h * 2.0 * p.n_links
    cot = build_cot(
        simulation="robot_arm_collapse",
        category="articulated_jointed",
        seed=seed,
        physical_observation=(
            f"{p.n_links} stacked arm segments (link h={p.link_half_height*2:.2f}m, "
            f"w={p.link_half_width*2:.2f}m, m={p.link_mass:.2f}kg). "
            f"Base fixed; top link perturbed at {p.initial_perturbation_vel:.2f} m/s. "
            f"Tower collapses under gravity."
        ),
        law_name="Inverted pendulum instability and cascading toppling",
        law_statement=(
            "A stack of rigid bodies in unstable equilibrium collapses "
            "when perturbed; the toppling cascade is governed by torques exceeding "
            "contact friction."
        ),
        law_formula="τ_gravity = m·g·(L/2)·sinθ > μ·N·(L/2)·cosθ → toppling",
        assumptions=[
            "Low inter-segment friction to allow sliding",
            "Blocks are in unstable vertical stacking configuration",
            "Only base segment is fixed; others are free",
            "Perturbation initiates gravitational instability",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg+F_c",
            "I\\dot{\\omega}=\\tau_c-\\omega\\times I\\omega",
            "\\tau_{\\text{tip}} = mgL/2 \\cdot \\sin\\theta",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            "Each segment is initially stacked vertically (unstable equilibrium)",
            "Top segment given lateral velocity perturbation",
            f"Gravitational torque at small angle θ: τ ≈ m·g·(h/2)·θ",
            "Critical tipping when τ_gravity > friction torque",
            "Cascade: toppling segments strike lower ones, propagating collapse",
        ],
        expected_behavior=[
            "Top segment tips and falls laterally",
            "Remaining segments topple in sequence",
            "Segments scatter on floor",
            "Fixed base remains stationary",
        ],
        parameters={
            "n_links":                  param_entry(p.n_links,                  "",    "number of arm segments"),
            "link_mass":                param_entry(p.link_mass,                "kg",  "mass per segment"),
            "link_half_height":         param_entry(p.link_half_height,         "m",   "segment half-height"),
            "link_half_width":          param_entry(p.link_half_width,          "m",   "segment half-width"),
            "initial_perturbation_vel": param_entry(p.initial_perturbation_vel, "m/s", "lateral perturbation velocity on top link"),
            "friction":                 param_entry(p.friction,                 "",    "friction coefficient"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    link_he = [p.link_half_width, p.link_half_depth, p.link_half_height]
    seg_h = p.link_half_height * 2.0
    setup_lines = []
    for i in range(p.n_links):
        z_center = link_he[2] + i * seg_h * 2.0
        if i == 0:
            setup_lines.append(
                f"    s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents={list(link_he)},physicsClientId=c)\n"
                f"    bid=pb.createMultiBody(0,s,-1,[0,0,{z_center:.4f}],[0,0,0,1],physicsClientId=c)\n"
                f"    pb.createConstraint(bid,-1,-1,-1,pb.JOINT_FIXED,[0,0,0],[0,0,0],[0,0,{z_center:.4f}],physicsClientId=c)\n"
                f"    _add_box(sc,'link{i}',nodes,{list(link_he)},{p.colors[i]})\n"
                f"    _set_pose(sc,nodes['link{i}'],[0,0,{z_center:.4f}],[0,0,0,1])\n"
            )
        else:
            vel = [p.initial_perturbation_vel if i == p.n_links - 1 else 0.0, 0.0, 0.0]
            setup_lines.append(
                f"    s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents={list(link_he)},physicsClientId=c)\n"
                f"    bid=pb.createMultiBody({p.link_mass},s,-1,[0,0,{z_center:.4f}],[0,0,0,1],physicsClientId=c)\n"
                f"    pb.changeDynamics(bid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)\n"
                f"    pb.resetBaseVelocity(bid,{vel},[0,0,0],physicsClientId=c)\n"
                f"    _add_box(sc,'link{i}',nodes,{list(link_he)},{p.colors[i]})\n"
                f"    _set_pose(sc,nodes['link{i}'],[0,0,{z_center:.4f}],[0,0,0,1])\n"
                f"    bids.append(('link{i}',bid))\n"
            )
    setup_code = "".join(setup_lines)
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# robot_arm_collapse  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[5.0,5.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    bids=[]
{setup_code}
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_robot_arm_collapse")
    print("OK")
