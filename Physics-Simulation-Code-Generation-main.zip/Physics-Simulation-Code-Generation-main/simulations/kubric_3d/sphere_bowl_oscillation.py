"""sphere_bowl_oscillation — small sphere oscillates on the surface of a large static sphere (bowl)."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (5.0, -3.0, 3.5)
CAM_TARGET = (0.0, 0.0, 0.0)
N_FRAMES   = 150  # 5 s @ 30 fps


@dataclass
class Params:
    seed:             int
    bowl_radius:      float   # radius of the large static sphere (m)
    ball_radius:      float   # radius of small sphere (m)
    ball_mass:        float   # kg
    initial_offset_x: float   # horizontal offset from bowl centre (m)
    restitution:      float
    ball_color:       List[float]
    bowl_color:       List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    bowl_r = random.uniform(2.5, 4.0)
    return Params(
        seed=seed,
        bowl_radius=bowl_r,
        ball_radius=random.uniform(0.05, 0.12),
        ball_mass=random.uniform(0.1, 0.8),
        initial_offset_x=random.uniform(0.2, bowl_r * 0.5),
        restitution=random.uniform(0.3, 0.7),
        ball_color=[random.uniform(0.5, 1.0), random.uniform(0.3, 0.8),
                    random.uniform(0.2, 0.7), 1.0],
        bowl_color=[0.65, 0.55, 0.45, 0.85],
    )


def _make_bowl_mesh(bowl_radius: float):
    """Create bowl as upper hemisphere cap (open at top, inward-facing normals)."""
    import trimesh
    n_phi, n_theta = 32, 14
    depth = math.pi * 0.62   # 0→112° — generous bowl depth
    thetas = np.linspace(0, depth, n_theta + 1)
    phis   = np.linspace(0, 2 * math.pi, n_phi, endpoint=False)
    verts  = [[0.0, 0.0, bowl_radius]]   # apex at top (index 0)
    for t in thetas[1:]:
        for phi in phis:
            verts.append([bowl_radius * math.sin(t) * math.cos(phi),
                          bowl_radius * math.sin(t) * math.sin(phi),
                          bowl_radius * math.cos(t)])
    faces = []
    for i in range(n_phi):    # top fan — CW from outside = inward normals
        j = 1 + i;  k = 1 + (i + 1) % n_phi
        faces.append([0, k, j])
    for ring in range(n_theta - 1):  # ring quads
        b0 = 1 + ring * n_phi;  b1 = b0 + n_phi
        for i in range(n_phi):
            j  = b0 + i;           k  = b0 + (i + 1) % n_phi
            jj = b1 + i;           kk = b1 + (i + 1) % n_phi
            faces.append([j, kk, k]);  faces.append([j, jj, kk])
    return trimesh.Trimesh(vertices=np.array(verts, float),
                           faces=np.array(faces, int), process=False)


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import trimesh
    import pyrender
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    # rim_z: the bowl rim sits at this height above z=0
    rim_z = 0.5
    # Physics bowl: large static sphere positioned so its top (north pole) is at rim_z
    # Sphere centre is at z = rim_z - bowl_radius (deeply buried below floor)
    bowl_centre_z = rim_z - p.bowl_radius
    phys.add_sphere(p.bowl_radius, [0.0, 0.0, bowl_centre_z],
                    mass=0.0, friction=0.5, restitution=p.restitution)

    # Visual bowl: hemispherical mesh centred at bowl_centre_z
    bowl_tm = _make_bowl_mesh(p.bowl_radius)
    mat = pyrender.MetallicRoughnessMaterial(
        baseColorFactor=p.bowl_color, metallicFactor=0.1, roughnessFactor=0.6,
        doubleSided=True)
    bowl_pm = pyrender.Mesh.from_trimesh(bowl_tm, material=mat, smooth=True)
    bowl_pose = np.eye(4)
    bowl_pose[2, 3] = bowl_centre_z
    bowl_node = ren.scene.add(bowl_pm, pose=bowl_pose)

    # Floor plane (beneath bowl, mainly for safety)
    phys.add_plane(friction=0.3, restitution=0.5)
    ren.add_plane_mesh("floor", 10.0, [0.22, 0.22, 0.25, 1.0])
    ren.set_static_pose("floor", [0, 0, 0])

    # Small sphere placed on the bowl interior surface at initial_offset_x from centre
    # Surface point on interior: angle phi from vertical (downward axis)
    if p.initial_offset_x < p.bowl_radius:
        phi = math.asin(p.initial_offset_x / p.bowl_radius)
    else:
        phi = math.pi / 3.0
    # Interior surface point (in world coords relative to bowl centre)
    sx = p.bowl_radius * math.sin(phi)
    # Ball sits on inner surface of sphere: contact at bowl_centre + bowl_r*dir,
    # ball centre is bowl_r*cos(phi) above bowl_centre_z, offset inward by ball_radius
    sz = bowl_centre_z + p.bowl_radius * math.cos(phi) - p.ball_radius - 0.005

    # Give ball initial tangential velocity for oscillation (Y direction)
    init_tangential_vel = math.sqrt(9.81 * p.bowl_radius) * 0.25
    bid = phys.add_sphere(p.ball_radius, [sx, 0.0, sz],
                          mass=p.ball_mass, friction=0.15,
                          restitution=p.restitution,
                          vel=[0.0, init_tangential_vel, 0.0])
    ren.add_sphere("ball", p.ball_radius, p.ball_color)
    dyn = [("ball", bid)]

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    # Small-angle oscillation period T = 2π*sqrt(R/g)
    period = 2 * math.pi * math.sqrt(p.bowl_radius / 9.81)
    cot = build_cot(
        simulation="sphere_bowl_oscillation",
        category="rigid_body_constrained",
        seed=seed,
        physical_observation=(
            f"Small sphere (r={p.ball_radius:.3f} m, m={p.ball_mass:.3f} kg) "
            f"placed on large static sphere (R={p.bowl_radius:.2f} m) "
            f"at offset x={p.initial_offset_x:.2f} m from apex. "
            f"Small-angle period T≈{period:.2f} s."),
        law_name="Spherical pendulum / normal force constraint",
        law_statement=(
            "Ball constrained to bowl surface; restoring force is the component "
            "of gravity tangent to the sphere, giving pendulum-like oscillation."),
        law_formula="T=2π*sqrt(R/g)  [small-angle approximation]",
        assumptions=[
            "Bowl surface is frictionless at small angles (first-order analysis).",
            "Ball radius much smaller than bowl radius.",
            "Motion confined to xz-plane for small initial offsets.",
        ],
        state_variables=["position r (m)", "velocity v (m/s)",
                         "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\ddot{\\phi}=-\\frac{g}{R}\\sin\\phi \\approx -\\frac{g}{R}\\phi",
            "T=2\\pi\\sqrt{\\frac{R}{g}}",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            f"Bowl radius R={p.bowl_radius:.2f} m, ball placed at angle φ≈{math.degrees(phi):.1f}°.",
            "Gravity component tangent to sphere: F_t = -mg·sin(φ).",
            f"Small-angle period T=2π√(R/g)≈{period:.2f} s.",
            "Amplitude decreases due to friction and restitution losses.",
        ],
        expected_behavior=[
            "Ball slides/rolls from initial position toward apex.",
            "Oscillates back and forth with period ≈ {:.2f} s.".format(period),
            "Amplitude decays due to energy dissipation.",
        ],
        parameters={
            "bowl_radius_m":      param_entry(p.bowl_radius,      "m",  "Bowl sphere radius"),
            "ball_radius_m":      param_entry(p.ball_radius,      "m",  "Small ball radius"),
            "ball_mass_kg":       param_entry(p.ball_mass,        "kg", "Ball mass"),
            "initial_offset_x_m": param_entry(p.initial_offset_x, "m",  "Initial horizontal offset"),
            "restitution":        param_entry(p.restitution,      "",   "Coefficient of restitution"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    rim_z = 0.5
    bowl_centre_z = rim_z - p.bowl_radius
    if p.initial_offset_x < p.bowl_radius:
        phi = math.asin(p.initial_offset_x / p.bowl_radius)
    else:
        phi = math.pi / 3.0
    sx = p.bowl_radius * math.sin(phi)
    sz = bowl_centre_z + p.bowl_radius * math.cos(phi) - p.ball_radius - 0.005
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# sphere_bowl_oscillation  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[4.0,4.0,0.02],[0.22,0.22,0.25,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    bs=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.bowl_radius},physicsClientId=c)
    pb.createMultiBody(0,bs,-1,[0.0,0.0,{bowl_centre_z}],[0,0,0,1],physicsClientId=c)
    _add_sphere(sc,"bowl",nodes,{p.bowl_radius},{p.bowl_color})
    _set_pose(sc,nodes["bowl"],[0.0,0.0,{bowl_centre_z}],[0,0,0,1])
    ss=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.ball_radius},physicsClientId=c)
    bid=pb.createMultiBody({p.ball_mass},ss,-1,[{sx},0.0,{sz}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(bid,-1,lateralFriction=0.15,restitution={p.restitution},physicsClientId=c)
    import math as _math
    init_tangential_vel=_math.sqrt(9.81*{p.bowl_radius})*0.3
    pb.resetBaseVelocity(bid,[0.0,init_tangential_vel,0.0],[0,0,0],physicsClientId=c)
    _add_sphere(sc,"ball",nodes,{p.ball_radius},{p.ball_color})
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
        _set_pose(sc,nodes["ball"],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_sphere_bowl_oscillation")
    print("OK")
