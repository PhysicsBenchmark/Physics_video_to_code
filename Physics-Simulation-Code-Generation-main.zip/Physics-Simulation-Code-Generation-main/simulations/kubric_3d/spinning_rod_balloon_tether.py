"""spinning_rod_balloon_tether — rotating rod with a tethered balloon as a conical pendulum.

A horizontal rod is hinged to a vertical post via JOINT_REVOLUTE around the world Z axis
(multi-body). A balloon hangs from the rod's tip on a tether (POINT2POINT constraint
between the rod's link and the balloon body). When the rod spins at ω, the balloon's
inertia pulls it outward and the tether goes taut at angle θ from vertical, satisfying
the conical-pendulum equilibrium:

    T·sinθ = m·ω²·r          (centripetal balance)
    T·cosθ = m·g             (vertical balance)
    ⇒ tanθ = ω²·r / g,   r = L_rod + L_tether·sinθ

We seed the simulation directly at this θ with linear velocity (0, ω·r, 0) and angular
velocity (0, 0, ω) on the balloon so the constraint point velocities match exactly at t=0
— no transient, the balloon traces a clean horizontal circle for the full N_FRAMES."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (3.5, -3.5, 1.6)
CAM_TARGET = (0.0,  0.0, 1.0)
N_FRAMES   = 150


@dataclass
class Params:
    seed: int
    rod_length: float
    rod_mass: float
    omega0: float
    tether_length: float
    balloon_radius: float
    balloon_mass: float
    post_height: float
    rod_color: List[float]
    balloon_color: List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    def _hue():
        h = random.random(); s, v = 0.85, 0.92; hi = int(h*6) % 6; f = h*6 - int(h*6)
        p_ = v*(1-s); q = v*(1-f*s); t = v*(1-(1-f)*s)
        r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
        return [r, g, b, 1.0]
    return Params(
        seed=seed,
        rod_length=random.uniform(0.40, 0.65),
        rod_mass=random.uniform(0.30, 0.50),
        omega0=random.uniform(2.5, 3.8),
        tether_length=random.uniform(0.55, 0.85),
        balloon_radius=0.15,
        balloon_mass=random.uniform(0.04, 0.10),
        post_height=1.5,
        rod_color=[0.55, 0.34, 0.16, 1.0],
        balloon_color=_hue(),
    )


def _solve_conical_angle(omega: float, r_rod: float, L_tether: float, g: float = 9.81) -> float:
    """Numerically solve tan(θ) = ω²·(r_rod + L_tether·sinθ) / g."""
    theta = 0.6
    for _ in range(80):
        r = r_rod + L_tether * math.sin(theta)
        new_theta = math.atan(omega * omega * r / g)
        if abs(new_theta - theta) < 1e-7:
            break
        theta = new_theta
    return theta


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        STANDALONE_IMPORTS, STANDALONE_UTILS, FPS)
    import pybullet as pb_mod

    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    # Stiffer constraint solver — POINT2POINT between two free bodies drifts each frame
    # at the default 50 iterations, exciting the natural pendulum oscillation mode.
    pb_mod.setPhysicsEngineParameter(numSolverIterations=200, physicsClientId=phys.client)

    phys.add_plane(friction=0.3)
    ren.add_plane_mesh("floor", 8.0, [0.42, 0.42, 0.45, 1.0])
    ren.set_static_pose("floor", [0, 0, -0.02])

    post_h = p.post_height
    ren.add_cylinder("post", 0.04, post_h, [0.50, 0.42, 0.32, 1.0])
    ren.set_static_pose("post", [0, 0, post_h / 2])
    ren.add_sphere("pivot_m", 0.045, [0.85, 0.85, 0.85, 1.0])
    ren.set_static_pose("pivot_m", [0, 0, post_h])

    # 3-body multi-body: static base + rod (REVOLUTE around Z) + balloon (SPHERICAL at rod tip).
    # Multi-body internal joints are enforced rigidly by PyBullet's Featherstone dynamics
    # (no penalty forces / drift), so the conical-pendulum equilibrium stays clean.
    L_half = p.rod_length / 2.0
    arm_he = [L_half, 0.04, 0.04]
    g_const = 9.81
    theta = _solve_conical_angle(p.omega0, p.rod_length, p.tether_length, g=g_const)
    r_bln = p.rod_length + p.tether_length * math.sin(theta)
    bln_z = post_h - p.tether_length * math.cos(theta)

    anchor_shape  = pb_mod.createCollisionShape(pb_mod.GEOM_SPHERE, radius=0.025,
                                                physicsClientId=phys.client)
    arm_shape     = pb_mod.createCollisionShape(
        pb_mod.GEOM_BOX, halfExtents=arm_he,
        collisionFramePosition=[L_half, 0, 0],
        physicsClientId=phys.client)
    balloon_shape = pb_mod.createCollisionShape(pb_mod.GEOM_SPHERE,
                                                radius=p.balloon_radius,
                                                physicsClientId=phys.client)

    # The balloon's URDF frame sits at the joint (rod tip). Its CoM offset is along
    # local −z by L_tether, so by initialising the spherical joint with the equilibrium
    # tilt around +Y we land the balloon exactly at the steady-state position.
    rod_mb = pb_mod.createMultiBody(
        baseMass=0.0,
        baseCollisionShapeIndex=anchor_shape,
        basePosition=[0, 0, post_h],
        baseOrientation=[0, 0, 0, 1],
        linkMasses=[p.rod_mass, p.balloon_mass],
        linkCollisionShapeIndices=[arm_shape, balloon_shape],
        linkVisualShapeIndices=[-1, -1],
        linkPositions=[[0, 0, 0],          # rod URDF frame at base origin = pivot
                       [p.rod_length, 0, 0]],   # balloon joint at rod tip (in rod's frame)
        linkOrientations=[[0, 0, 0, 1], [0, 0, 0, 1]],
        linkInertialFramePositions=[[L_half, 0, 0],
                                    [0, 0, -p.tether_length]],   # balloon CoM is L_tether below joint
        linkInertialFrameOrientations=[[0, 0, 0, 1], [0, 0, 0, 1]],
        linkParentIndices=[0, 1],          # rod's parent = base; balloon's parent = rod
        linkJointTypes=[pb_mod.JOINT_REVOLUTE, pb_mod.JOINT_SPHERICAL],
        linkJointAxis=[[0, 0, 1], [0, 0, 0]],
        physicsClientId=phys.client,
    )
    # Rod (link 0) dynamics
    pb_mod.changeDynamics(rod_mb, 0, lateralFriction=0.0, restitution=0.0,
                          linearDamping=0.0, angularDamping=0.0,
                          jointDamping=0.0,
                          physicsClientId=phys.client)
    # Balloon (link 1) dynamics
    pb_mod.changeDynamics(rod_mb, 1, lateralFriction=0.0, restitution=0.3,
                          linearDamping=0.0, angularDamping=0.0,
                          jointDamping=0.0,
                          physicsClientId=phys.client)

    # Initial joint states:
    #   Rod: angle 0, ω₀ around Z.
    #   Balloon: SPHERICAL rotated by −θ around Y so its local −z (= CoM offset direction)
    #   points to (+sinθ, 0, −cosθ) in rod's frame → CoM at the steady-state world position.
    pb_mod.resetJointState(rod_mb, 0, targetValue=0.0, targetVelocity=p.omega0,
                           physicsClientId=phys.client)
    q_y_theta = [0.0, -math.sin(theta / 2), 0.0, math.cos(theta / 2)]
    pb_mod.resetJointStateMultiDof(rod_mb, 1, targetValue=q_y_theta,
                                   targetVelocity=[0.0, 0.0, 0.0],
                                   physicsClientId=phys.client)
    # Disable default motors so joints are free
    pb_mod.setJointMotorControl2(rod_mb, 0, controlMode=pb_mod.VELOCITY_CONTROL,
                                 force=0.0, physicsClientId=phys.client)
    pb_mod.setJointMotorControlMultiDof(rod_mb, 1,
                                        controlMode=pb_mod.POSITION_CONTROL,
                                        targetPosition=q_y_theta,
                                        positionGain=0.0, velocityGain=0.0,
                                        force=[0.0, 0.0, 0.0],
                                        physicsClientId=phys.client)

    ren.add_box("rod",    arm_he,             p.rod_color)
    ren.add_sphere("balloon", p.balloon_radius, p.balloon_color)

    _rod  = rod_mb
    _Lrod = p.rod_length

    def extra_sync_fn(phys, ren, fi):
        # Rod link state
        rod_ls = pb_mod.getLinkState(_rod, 0, physicsClientId=phys.client)
        ren.set_pose("rod", list(rod_ls[0]), list(rod_ls[1]))
        # Balloon link state (CoM in world)
        bln_ls = pb_mod.getLinkState(_rod, 1, physicsClientId=phys.client)
        ren.set_pose("balloon", list(bln_ls[0]), list(bln_ls[1]))
        # Tether: from rod tip (URDF + R · (L_rod, 0, 0)) to balloon CoM
        rmat = pb_mod.getMatrixFromQuaternion(rod_ls[5])
        tip  = [rod_ls[4][0] + rmat[0] * _Lrod,
                rod_ls[4][1] + rmat[3] * _Lrod,
                rod_ls[4][2] + rmat[6] * _Lrod]
        ren.update_string("tether", tip, list(bln_ls[0]), 0.012,
                          [0.95, 0.85, 0.10, 1.0])

    dyn = []  # rod and balloon are both inside the multi-body; sync them in extra_sync_fn
    frames = run_loop(phys, ren, dyn, N_FRAMES, extra_sync_fn=extra_sync_fn)

    # CoT — derived equilibrium quantities
    v_bln  = p.omega0 * r_bln
    T_tens = p.balloon_mass * g_const / max(math.cos(theta), 1e-3)
    period = 2 * math.pi / p.omega0
    cot = build_cot(
        simulation="spinning_rod_balloon_tether",
        category="rigid_body_constrained",
        seed=seed,
        physical_observation=(
            f"Rod (L={p.rod_length:.2f}m) spins at ω={p.omega0:.2f}rad/s about a vertical "
            f"axle. A balloon (m={p.balloon_mass:.3f}kg) tethered to the tip by a string of "
            f"length {p.tether_length:.2f}m sits at θ={math.degrees(theta):.1f}° from vertical, "
            f"orbiting at radius {r_bln:.2f}m, speed {v_bln:.2f}m/s, tether tension {T_tens:.2f}N."
        ),
        law_name="Conical pendulum / centripetal force on a tethered mass",
        law_statement=(
            "A mass on a tether rotating about a vertical axis sits at the angle θ from "
            "vertical where the tether tension provides both the vertical balance against "
            "gravity (T·cosθ = m·g) AND the horizontal centripetal force (T·sinθ = m·ω²·r). "
            "Equivalently, tanθ = ω²·r/g, where r = L_rod + L_tether·sinθ."
        ),
        law_formula="T\\sin\\theta = m\\omega^2 r;\\quad T\\cos\\theta = mg;\\quad \\tan\\theta = \\omega^2 r / g",
        assumptions=[
            "Massless rigid axle (JOINT_REVOLUTE around world Z).",
            "Massless rigid tether (POINT2POINT keeps |r_tip − r_balloon| = L_tether).",
            "No air drag; balloon is a point mass for tether geometry.",
            "Steady-state initial conditions: balloon co-rotates with rod at the equilibrium θ.",
        ],
        state_variables=["θ_rod (rad)", "ω_rod (rad/s)", "θ_tether (rad)", "T (N)"],
        equations_latex=[
            "T\\sin\\theta = m\\omega^2 r",
            "T\\cos\\theta = mg",
            "\\tan\\theta = \\omega^2(L_{rod}+L_{tether}\\sin\\theta)/g",
            "v_{balloon}=\\omega r",
        ],
        contact_impulse="N/A — pure constraint dynamics, no contact in steady state",
        derivation_steps=[
            f"Solve tan(θ) = ω²·(L_rod + L_tether·sinθ)/g for θ:",
            f"  ω={p.omega0:.2f}, L_rod={p.rod_length:.2f}, L_tether={p.tether_length:.2f}",
            f"  → θ ≈ {math.degrees(theta):.2f}°",
            f"Orbit radius:    r = L_rod + L_tether·sinθ = {r_bln:.3f} m",
            f"Tangential speed: v = ω·r = {v_bln:.2f} m/s",
            f"Period:           T = 2π/ω = {period:.2f} s",
            f"Tether tension:  T = m·g/cosθ = {T_tens:.3f} N",
        ],
        expected_behavior=[
            f"Rod rotates steadily at {p.omega0:.2f} rad/s about the vertical post.",
            f"Balloon traces a horizontal circle of radius {r_bln:.2f}m at constant height.",
            f"Tether stays taut at θ≈{math.degrees(theta):.0f}° below horizontal from rod tip.",
            f"Roughly {N_FRAMES/FPS/period:.1f} orbits visible over the {N_FRAMES/FPS:.1f}s clip.",
        ],
        parameters={
            "rod_length":     param_entry(p.rod_length,     "m",     "rod length"),
            "rod_mass":       param_entry(p.rod_mass,       "kg",    "rod mass"),
            "omega0":         param_entry(p.omega0,         "rad/s", "rod angular velocity"),
            "tether_length":  param_entry(p.tether_length,  "m",     "tether length"),
            "balloon_mass":   param_entry(p.balloon_mass,   "kg",    "balloon mass"),
            "balloon_radius": param_entry(p.balloon_radius, "m",     "balloon radius"),
            "post_height":    param_entry(p.post_height,    "m",     "post height (pivot height)"),
            "theta_eq_deg":   param_entry(math.degrees(theta), "deg","equilibrium tether angle"),
            "orbit_radius":   param_entry(r_bln,            "m",     "balloon orbit radius"),
            "tether_tension": param_entry(T_tens,           "N",     "steady-state tether tension"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    L_half = p.rod_length / 2.0
    g_const = 9.81
    theta   = _solve_conical_angle(p.omega0, p.rod_length, p.tether_length, g=g_const)
    r_bln   = p.rod_length + p.tether_length * math.sin(theta)
    bln_z   = p.post_height - p.tether_length * math.cos(theta)
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# spinning_rod_balloon_tether  seed={p.seed}
import math, pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}
ROD_L={p.rod_length}; RM={p.rod_mass}; OMG={p.omega0}
TL={p.tether_length}; BR={p.balloon_radius}; BM={p.balloon_mass}; POST_H={p.post_height}
LH={L_half}
THETA={theta}; R_BLN={r_bln}; BLN_Z={bln_z}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.setPhysicsEngineParameter(numSolverIterations=200,physicsClientId=c)
    plane_bid=pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    pb.changeDynamics(plane_bid,-1,lateralFriction=0.3,physicsClientId=c)
    _add_box(sc,"fl",nodes,[4,4,0.02],[0.42,0.42,0.45,1.0]); _set_pose(sc,nodes["fl"],[0,0,-0.02],[0,0,0,1])
    _add_cylinder(sc,"post",nodes,0.04,POST_H,[0.50,0.42,0.32,1.0]); _set_pose(sc,nodes["post"],[0,0,POST_H/2],[0,0,0,1])
    _add_sphere(sc,"piv",nodes,0.045,[0.85,0.85,0.85,1.0]); _set_pose(sc,nodes["piv"],[0,0,POST_H],[0,0,0,1])
    arm_he=[LH,0.04,0.04]
    asphere=pb.createCollisionShape(pb.GEOM_SPHERE,radius=0.025,physicsClientId=c)
    abox=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=arm_he,collisionFramePosition=[LH,0,0],physicsClientId=c)
    bsphere=pb.createCollisionShape(pb.GEOM_SPHERE,radius=BR,physicsClientId=c)
    rod=pb.createMultiBody(baseMass=0.0,baseCollisionShapeIndex=asphere,
        basePosition=[0,0,POST_H],baseOrientation=[0,0,0,1],
        linkMasses=[RM,BM],linkCollisionShapeIndices=[abox,bsphere],linkVisualShapeIndices=[-1,-1],
        linkPositions=[[0,0,0],[ROD_L,0,0]],
        linkOrientations=[[0,0,0,1],[0,0,0,1]],
        linkInertialFramePositions=[[LH,0,0],[0,0,-TL]],
        linkInertialFrameOrientations=[[0,0,0,1],[0,0,0,1]],
        linkParentIndices=[0,1],linkJointTypes=[pb.JOINT_REVOLUTE,pb.JOINT_SPHERICAL],
        linkJointAxis=[[0,0,1],[0,0,0]],
        physicsClientId=c)
    pb.changeDynamics(rod,0,lateralFriction=0.0,restitution=0.0,linearDamping=0.0,angularDamping=0.0,jointDamping=0.0,physicsClientId=c)
    pb.changeDynamics(rod,1,lateralFriction=0.0,restitution=0.3,linearDamping=0.0,angularDamping=0.0,jointDamping=0.0,physicsClientId=c)
    pb.resetJointState(rod,0,targetValue=0.0,targetVelocity=OMG,physicsClientId=c)
    qY=[0.0,-math.sin(THETA/2),0.0,math.cos(THETA/2)]
    pb.resetJointStateMultiDof(rod,1,targetValue=qY,targetVelocity=[0.0,0.0,0.0],physicsClientId=c)
    pb.setJointMotorControl2(rod,0,controlMode=pb.VELOCITY_CONTROL,force=0.0,physicsClientId=c)
    pb.setJointMotorControlMultiDof(rod,1,controlMode=pb.POSITION_CONTROL,targetPosition=qY,positionGain=0.0,velocityGain=0.0,force=[0.0,0.0,0.0],physicsClientId=c)
    _add_box(sc,"rod",nodes,arm_he,{p.rod_color})
    _add_sphere(sc,"bln",nodes,BR,{p.balloon_color})
    frames=[]
    for fi in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        rls=pb.getLinkState(rod,0,physicsClientId=c)
        _set_pose(sc,nodes["rod"],list(rls[0]),list(rls[1]))
        bls=pb.getLinkState(rod,1,physicsClientId=c)
        _set_pose(sc,nodes["bln"],list(bls[0]),list(bls[1]))
        rmat=pb.getMatrixFromQuaternion(rls[5])
        tip=[rls[4][0]+rmat[0]*ROD_L,rls[4][1]+rmat[3]*ROD_L,rls[4][2]+rmat[6]*ROD_L]
        _update_string(sc,nodes,"tether",tip,list(bls[0]),0.012,[0.95,0.85,0.10,1.0])
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_spinning_rod_balloon_tether")
    print("OK")
