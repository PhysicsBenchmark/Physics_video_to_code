"""rod_spin_hits_balloon — rotating rod tip strikes a light balloon, demonstrating v_tip=ωr.

A horizontal rod pivots around a vertical axle (multi-body with JOINT_REVOLUTE) and spins
with initial angular velocity ω₀. When its tip reaches a stationary low-mass, low-friction
balloon resting on the floor, momentum transfer launches the balloon at ≈(1+e)·m_eff·ωr/M
— much faster than a heavy block would move, because the balloon is light. The balloon
then decelerates from floor friction and bounces (high restitution), illustrating both
the v=ωr relationship and asymmetric-mass impulsive collision."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (2.6, -4.2, 2.0)
CAM_TARGET = (-0.4, -0.5, 0.20)
N_FRAMES   = 150


@dataclass
class Params:
    seed: int
    rod_length: float
    rod_mass: float
    omega0: float                # initial spin (rad/s, CCW around +Z)
    balloon_angle_deg: float     # balloon angular position from +x axis (deg, CCW)
    balloon_distance: float      # balloon distance from pivot (m)
    balloon_radius: float
    balloon_mass: float
    balloon_friction: float
    balloon_restitution: float
    angular_damping: float
    rod_color: List[float]
    balloon_color: List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    def _hue():
        h = random.random(); s, v = 0.85, 0.92; hi = int(h*6) % 6; f = h*6 - int(h*6)
        p_ = v*(1-s); q = v*(1-f*s); t = v*(1-(1-f)*s)
        r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
        return [r, g, b, 1.0]
    rod_length = 0.85
    # balloon_distance kept inside [L_rod − R_balloon, L_rod) so the rod tip overshoots
    # the balloon centre — guarantees solid contact across the angular sweep.
    balloon_distance = random.uniform(rod_length - 0.16, rod_length - 0.02)
    # Restrict balloon angle to the rear-and-side semicircle: rod sweeps through it within
    # ≤ ¾ turn at any of the omega values, and post-impact flight stays toward the camera.
    balloon_angle_deg = random.uniform(110.0, 245.0)
    return Params(
        seed=seed,
        rod_length=rod_length,
        rod_mass=random.uniform(0.30, 0.50),
        omega0=random.uniform(3.0, 6.5),
        balloon_angle_deg=balloon_angle_deg,
        balloon_distance=balloon_distance,
        balloon_radius=0.17,
        balloon_mass=random.uniform(0.04, 0.08),
        balloon_friction=random.uniform(0.05, 0.15),
        balloon_restitution=random.uniform(0.65, 0.85),
        # τ_decay = I_rod/jointDamping ≈ (m·L²/3)/jointDamping. With m≈0.4 and L=0.85
        # → I≈0.1, so jointDamping≈0.04 gives ~2.5s decay — rod completes the swing.
        angular_damping=0.04,
        rod_color=[0.55, 0.34, 0.16, 1.0],     # wood
        balloon_color=_hue(),
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        STANDALONE_IMPORTS, STANDALONE_UTILS, FPS)
    import pybullet as pb_mod

    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.balloon_friction)
    ren.add_plane_mesh("floor", 8.0, [0.42, 0.42, 0.45, 1.0])
    ren.set_static_pose("floor", [0, 0, -0.02])

    pivot  = [-1.0, 0.0, p.balloon_radius]    # rod height = balloon centre height
    L_half = p.rod_length / 2.0

    # Visible axle pole (decorative)
    ren.add_cylinder("pole", 0.04, 0.50, [0.45, 0.40, 0.32, 1.0])
    ren.set_static_pose("pole", [pivot[0], pivot[1], 0.25])
    ren.add_sphere("pivot_m", 0.045, [0.85, 0.85, 0.85, 1.0])
    ren.set_static_pose("pivot_m", pivot)

    # Spinning rod as 2-link multi-body: static base + arm with REVOLUTE joint around Z.
    # collisionFramePosition + linkInertialFramePosition place the rod so its near
    # end is at the pivot and it extends in +x; CoM is at the bar's centre.
    arm_he = [L_half, 0.04, 0.04]
    anchor_shape = pb_mod.createCollisionShape(pb_mod.GEOM_SPHERE, radius=0.025,
                                               physicsClientId=phys.client)
    arm_shape    = pb_mod.createCollisionShape(
        pb_mod.GEOM_BOX, halfExtents=arm_he,
        collisionFramePosition=[L_half, 0, 0],
        physicsClientId=phys.client)
    rod_mb = pb_mod.createMultiBody(
        baseMass=0.0,
        baseCollisionShapeIndex=anchor_shape,
        basePosition=pivot,
        baseOrientation=[0, 0, 0, 1],
        linkMasses=[p.rod_mass],
        linkCollisionShapeIndices=[arm_shape],
        linkVisualShapeIndices=[-1],
        linkPositions=[[0, 0, 0]],
        linkOrientations=[[0, 0, 0, 1]],
        linkInertialFramePositions=[[L_half, 0, 0]],
        linkInertialFrameOrientations=[[0, 0, 0, 1]],
        linkParentIndices=[0],
        linkJointTypes=[pb_mod.JOINT_REVOLUTE],
        linkJointAxis=[[0, 0, 1]],
        physicsClientId=phys.client,
    )
    pb_mod.changeDynamics(rod_mb, 0, lateralFriction=0.4, restitution=0.30,
                          linearDamping=0.0, angularDamping=0.0,
                          jointDamping=p.angular_damping,
                          physicsClientId=phys.client)
    pb_mod.resetJointState(rod_mb, jointIndex=0,
                           targetValue=0.0, targetVelocity=p.omega0,
                           physicsClientId=phys.client)
    pb_mod.setJointMotorControl2(rod_mb, 0, controlMode=pb_mod.VELOCITY_CONTROL,
                                 force=0.0, physicsClientId=phys.client)
    ren.add_box("rod", arm_he, p.rod_color)

    # Balloon (sphere) on floor in the rod's swing path; light + bouncy + low friction.
    # Position parametrised by (angle, distance) from the pivot: balloon sits inside
    # the rod's reach so the tip strikes it solidly when sweeping through θ_balloon.
    theta_b = math.radians(p.balloon_angle_deg)
    balloon_pos = [pivot[0] + p.balloon_distance * math.cos(theta_b),
                   pivot[1] + p.balloon_distance * math.sin(theta_b),
                   p.balloon_radius]
    balloon_id  = phys.add_sphere(p.balloon_radius, balloon_pos,
                                  mass=p.balloon_mass,
                                  friction=p.balloon_friction,
                                  restitution=p.balloon_restitution,
                                  lin_damp=0.02, ang_damp=0.05)
    ren.add_sphere("balloon", p.balloon_radius, p.balloon_color)

    _rod = rod_mb
    def extra_sync_fn(phys, ren, fi):
        ls = pb_mod.getLinkState(_rod, 0, physicsClientId=phys.client)
        ren.set_pose("rod", list(ls[0]), list(ls[1]))

    dyn = [("balloon", balloon_id)]
    frames = run_loop(phys, ren, dyn, N_FRAMES, extra_sync_fn=extra_sync_fn)

    g = 9.81
    v_tip   = p.omega0 * p.rod_length
    m_eff   = p.rod_mass / 3.0
    e       = p.balloon_restitution
    v_balloon = (1 + e) * m_eff * v_tip / (m_eff + p.balloon_mass)
    fly_d   = v_balloon ** 2 / (2 * p.balloon_friction * g) if p.balloon_friction > 0 else float("inf")
    cot = build_cot(
        simulation="rod_spin_hits_balloon",
        category="rigid_body_constrained",
        seed=seed,
        physical_observation=(
            f"Rod (L={p.rod_length:.2f}m, m={p.rod_mass:.2f}kg, ω₀={p.omega0:.1f}rad/s) "
            f"spins about a vertical axis. Tip travels at v=ωr={v_tip:.2f}m/s and strikes a "
            f"light balloon (m={p.balloon_mass:.3f}kg, e={e:.2f}). Balloon flies at ≈{v_balloon:.2f} m/s."
        ),
        law_name="Tangential velocity of rotation (v=ωr) + impulsive collision",
        law_statement=(
            "A point at radius r on a body rotating with angular speed ω has tangential "
            "linear velocity v = ω·r. On collision with a stationary mass M, Newton's law of "
            "restitution gives v' = (1+e)·m_eff·v / (m_eff + M), where m_eff = I/r²."
        ),
        law_formula="v_{tip}=\\omega r;\\quad v_{blln}'=\\frac{(1+e)\\,m_{eff}\\,v_{tip}}{m_{eff}+M}",
        assumptions=[
            "Massless rigid axle (JOINT_REVOLUTE around vertical).",
            "Uniform rod: I=⅓mL² about the pivoted end → effective tip mass m/3.",
            "Coulomb friction between balloon and floor.",
            "Restitution e captures the rod-balloon collision energy loss.",
        ],
        state_variables=["θ_rod (rad)", "ω_rod (rad/s)", "x_balloon (m)", "v_balloon (m/s)"],
        equations_latex=[
            "v_{tip}=\\omega L",
            "I\\dot\\omega=\\tau_{contact}-c_d\\omega",
            "M\\dot{v}=-\\mu M g",
            "v_{blln}'=\\frac{(1+e)(m/3)\\omega L}{m/3+M}",
        ],
        contact_impulse="j = (1+e)·m_eff·M·v_tip / (m_eff + M)",
        derivation_steps=[
            f"Tip tangential speed: v_tip = ω·L = {p.omega0:.2f}×{p.rod_length:.2f} = {v_tip:.2f} m/s",
            f"Effective tip mass: m_eff = m/3 = {m_eff:.3f} kg",
            f"Mass ratio M/m_eff = {p.balloon_mass/m_eff:.3f} (balloon ≪ rod ⇒ balloon flies fast)",
            f"Balloon post-impact: v' = (1+{e:.2f})·{m_eff:.3f}·{v_tip:.2f}/({m_eff:.3f}+{p.balloon_mass:.3f}) = {v_balloon:.2f} m/s",
            f"Balloon glide distance (μ={p.balloon_friction:.2f}): d = v'²/(2μg) ≈ {fly_d:.2f} m",
        ],
        expected_behavior=[
            f"Rod rotates CCW at {p.omega0:.1f} rad/s about pivot at (−1.0, 0).",
            f"Balloon sits at θ={p.balloon_angle_deg:.0f}°, distance {p.balloon_distance:.2f}m from pivot, "
            f"world position ({balloon_pos[0]:.2f}, {balloon_pos[1]:.2f}, {balloon_pos[2]:.2f}).",
            f"Tip sweeps through θ_balloon after {math.radians(p.balloon_angle_deg)/p.omega0:.2f}s and strikes the balloon.",
            f"Balloon flies tangent to the rod's circle at ≈{v_balloon:.2f} m/s.",
            f"Balloon decelerates from floor friction (μ={p.balloon_friction:.2f}); may bounce (e={e:.2f}).",
            "Rod continues to rotate slowly; joint damping bleeds remaining ω.",
        ],
        parameters={
            "rod_length":          param_entry(p.rod_length,          "m",    "rod length"),
            "rod_mass":            param_entry(p.rod_mass,            "kg",   "rod mass"),
            "omega0":              param_entry(p.omega0,              "rad/s","initial angular velocity"),
            "v_tip":               param_entry(v_tip,                 "m/s",  "tip tangential speed = ωL"),
            "balloon_angle_deg":   param_entry(p.balloon_angle_deg,   "deg",  "balloon angular position from +x"),
            "balloon_distance":    param_entry(p.balloon_distance,    "m",    "balloon distance from pivot"),
            "balloon_mass":        param_entry(p.balloon_mass,        "kg",   "balloon mass"),
            "balloon_radius":      param_entry(p.balloon_radius,      "m",    "balloon radius"),
            "balloon_restitution": param_entry(p.balloon_restitution, "",     "restitution"),
            "balloon_friction":    param_entry(p.balloon_friction,    "",     "balloon-floor friction"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    L_half = p.rod_length / 2.0
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# rod_spin_hits_balloon  seed={p.seed}
import math, pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}
ROD_L={p.rod_length}; RM={p.rod_mass}; OMG={p.omega0}; AD={p.angular_damping}
BR={p.balloon_radius}; BM={p.balloon_mass}; BFR={p.balloon_friction}; BRE={p.balloon_restitution}
B_ANGLE_DEG={p.balloon_angle_deg}; B_DIST={p.balloon_distance}
LH={L_half}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    plane_bid=pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    pb.changeDynamics(plane_bid,-1,lateralFriction=BFR,physicsClientId=c)
    _add_box(sc,"fl",nodes,[4,4,0.02],[0.42,0.42,0.45,1.0]); _set_pose(sc,nodes["fl"],[0,0,-0.02],[0,0,0,1])
    PIV=[-1.0,0,BR]
    _add_cylinder(sc,"pole",nodes,0.04,0.50,[0.45,0.40,0.32,1.0]); _set_pose(sc,nodes["pole"],[PIV[0],PIV[1],0.25],[0,0,0,1])
    _add_sphere(sc,"piv",nodes,0.045,[0.85,0.85,0.85,1.0]); _set_pose(sc,nodes["piv"],PIV,[0,0,0,1])
    arm_he=[LH,0.04,0.04]
    anchor_shape=pb.createCollisionShape(pb.GEOM_SPHERE,radius=0.025,physicsClientId=c)
    arm_shape=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=arm_he,collisionFramePosition=[LH,0,0],physicsClientId=c)
    rod=pb.createMultiBody(baseMass=0.0,baseCollisionShapeIndex=anchor_shape,
        basePosition=PIV,baseOrientation=[0,0,0,1],
        linkMasses=[RM],linkCollisionShapeIndices=[arm_shape],linkVisualShapeIndices=[-1],
        linkPositions=[[0,0,0]],linkOrientations=[[0,0,0,1]],
        linkInertialFramePositions=[[LH,0,0]],linkInertialFrameOrientations=[[0,0,0,1]],
        linkParentIndices=[0],linkJointTypes=[pb.JOINT_REVOLUTE],linkJointAxis=[[0,0,1]],
        physicsClientId=c)
    pb.changeDynamics(rod,0,lateralFriction=0.4,restitution=0.3,linearDamping=0.0,angularDamping=0.0,jointDamping=AD,physicsClientId=c)
    pb.resetJointState(rod,jointIndex=0,targetValue=0.0,targetVelocity=OMG,physicsClientId=c)
    pb.setJointMotorControl2(rod,0,controlMode=pb.VELOCITY_CONTROL,force=0.0,physicsClientId=c)
    _add_box(sc,"rod",nodes,arm_he,{p.rod_color})
    th_b=math.radians(B_ANGLE_DEG)
    bln_pos=[PIV[0]+B_DIST*math.cos(th_b),PIV[1]+B_DIST*math.sin(th_b),BR]
    sb=pb.createCollisionShape(pb.GEOM_SPHERE,radius=BR,physicsClientId=c)
    bln=pb.createMultiBody(BM,sb,-1,bln_pos,[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(bln,-1,lateralFriction=BFR,restitution=BRE,linearDamping=0.02,angularDamping=0.05,physicsClientId=c)
    _add_sphere(sc,"bln",nodes,BR,{p.balloon_color}); _set_pose(sc,nodes["bln"],bln_pos,[0,0,0,1])
    frames=[]
    for fi in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        ls=pb.getLinkState(rod,0,physicsClientId=c); _set_pose(sc,nodes["rod"],list(ls[0]),list(ls[1]))
        bp,bo=pb.getBasePositionAndOrientation(bln,physicsClientId=c); _set_pose(sc,nodes["bln"],bp,bo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_rod_spin_hits_balloon")
    print("OK")
