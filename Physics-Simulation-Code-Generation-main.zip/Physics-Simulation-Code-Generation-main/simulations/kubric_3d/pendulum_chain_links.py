"""pendulum_chain_links — chain of links fixed at top, swings as compound pendulum."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (4, -3, 4)
CAM_TARGET = (0, 0, 1.5)
N_FRAMES   = 180


@dataclass
class Params:
    seed:           int
    n_links:        int
    link_radius:    float
    link_half_len:  float
    mass_per_link:  float
    pivot_height:   float
    init_angle_deg: float   # initial tilt angle from vertical (degrees)
    floor_friction: float
    chain_color:    List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        n_links=random.randint(8, 12),
        link_radius=random.uniform(0.025, 0.045),
        link_half_len=random.uniform(0.05, 0.09),
        mass_per_link=random.uniform(0.05, 0.15),
        pivot_height=random.uniform(2.5, 3.5),
        init_angle_deg=random.uniform(20.0, 45.0),
        floor_friction=random.uniform(0.4, 0.7),
        chain_color=[random.uniform(0.4, 0.8), random.uniform(0.35, 0.75),
                     random.uniform(0.2, 0.6), 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 10.0, [0.42, 0.42, 0.45, 1.0])
    ren.set_static_pose("floor", [0, 0, 0])

    # Place chain links along a line tilted by init_angle_deg from vertical
    angle_rad = math.radians(p.init_angle_deg)
    segment   = p.link_half_len * 2 + p.link_radius * 0.5
    pivot     = [0.0, 0.0, p.pivot_height]

    chain_ids: List[int] = []
    for i in range(p.n_links):
        # Position: displace from pivot along the tilted direction
        dist = (i + 0.5) * segment
        x    = math.sin(angle_rad) * dist
        z    = p.pivot_height - math.cos(angle_rad) * dist
        pos  = [x, 0.0, max(z, p.link_radius + 0.01)]
        bid  = phys.add_capsule(
            p.link_radius, p.link_half_len * 2, pos,
            orn=(0, 0, 0, 1),
            mass=p.mass_per_link,
            friction=0.4, restitution=0.3,
            lin_damp=0.03, ang_damp=0.05)
        if chain_ids:
            off = p.link_half_len + p.link_radius * 0.25
            phys.create_constraint(
                chain_ids[-1], -1, bid, -1,
                pb_mod.JOINT_POINT2POINT, [0, 0, 1],
                [0, 0, -off], [0, 0, off],
                max_force=200.0)
        chain_ids.append(bid)

    # Fix top link to pivot
    pb_mod.createConstraint(
        chain_ids[0], -1, -1, -1,
        pb_mod.JOINT_FIXED, [0, 0, 0],
        [0, 0, 0], list(pivot),
        physicsClientId=phys.client)

    # Render pivot anchor
    ren.add_sphere("pivot", 0.07, [0.9, 0.85, 0.2, 1.0])
    ren.set_static_pose("pivot", pivot)

    for i in range(p.n_links):
        ren.add_capsule(f"link{i}", p.link_radius, p.link_half_len * 2, p.chain_color)

    dyn = [(f"link{i}", bid) for i, bid in enumerate(chain_ids)]
    frames = run_loop(phys, ren, dyn, N_FRAMES)

    chain_len  = p.n_links * segment
    rigid_T    = 2 * math.pi * math.sqrt(chain_len / 9.81)
    total_mass = p.n_links * p.mass_per_link

    cot = build_cot(
        simulation="pendulum_chain_links",
        category="rope_chain",
        seed=seed,
        physical_observation=(
            f"Chain of {p.n_links} capsule links (r={p.link_radius:.3f}m, "
            f"half-len={p.link_half_len:.3f}m, m/link={p.mass_per_link:.3f}kg) "
            f"fixed at pivot height {p.pivot_height:.2f}m. "
            f"Initial tilt: {p.init_angle_deg:.1f}°. "
            f"Total mass: {total_mass:.3f}kg, chain length: {chain_len:.2f}m."),
        law_name="Compound flexible pendulum",
        law_statement=(
            "A chain pendulum oscillates under gravity; effective period depends "
            "on the chain's mass distribution and flex between links."),
        law_formula=r"T_{rigid} \approx 2\pi\sqrt{L/g}",
        assumptions=[
            "Links connected by point-to-point constraints (flexible joints).",
            "Top link is rigidly pinned to world frame.",
            "Air resistance neglected; floor provides rigid boundary.",
        ],
        state_variables=["r_i (m)", "v_i (m/s)", "q_i", "omega_i (rad/s)"],
        equations_latex=[
            r"\dot{r}_i = v_i",
            r"m_i\dot{v}_i = m_ig + T_i - T_{i-1}",
            r"I_i\dot{\omega}_i = \tau_i - \omega_i \times I_i\omega_i",
        ],
        contact_impulse="j = -(1+e)*v_n / (1/m_A + 1/m_B + cross_terms)",
        derivation_steps=[
            f"Initial displacement angle: {p.init_angle_deg:.1f}°.",
            f"Rigid-rod period: T ≈ {rigid_T:.2f}s.",
            "Flexible chain has shorter apparent period due to link flex.",
            "Energy dissipates through damping; amplitude decreases each swing.",
        ],
        expected_behavior=[
            "Chain swings from tilted position toward vertical.",
            "Lower links lag behind upper links forming a curved shape.",
            "System oscillates several times with decreasing amplitude.",
        ],
        parameters={
            "n_links":           param_entry(p.n_links, "", "Number of links"),
            "link_radius_m":     param_entry(p.link_radius, "m", "Link radius"),
            "link_half_len_m":   param_entry(p.link_half_len, "m", "Link half-length"),
            "mass_per_link_kg":  param_entry(p.mass_per_link, "kg", "Mass per link"),
            "pivot_height_m":    param_entry(p.pivot_height, "m", "Pivot height"),
            "init_angle_deg":    param_entry(p.init_angle_deg, "deg", "Initial tilt angle"),
            "chain_length_m":    param_entry(chain_len, "m", "Total chain length"),
            "rigid_period_s":    param_entry(rigid_T, "s", "Equivalent rigid-rod period"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    segment   = p.link_half_len * 2 + p.link_radius * 0.5
    off       = p.link_half_len + p.link_radius * 0.25
    angle_rad = math.radians(p.init_angle_deg)
    pivot     = [0.0, 0.0, p.pivot_height]
    # Pre-calculate positions
    positions = []
    for i in range(p.n_links):
        dist = (i + 0.5) * segment
        x    = math.sin(angle_rad) * dist
        z    = p.pivot_height - math.cos(angle_rad) * dist
        positions.append((x, max(z, p.link_radius + 0.01)))
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# pendulum_chain_links  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[5.0,5.0,0.02],[0.42,0.42,0.45,1.0]); _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    pivot={list(pivot)}
    lr={p.link_radius}; lhl={p.link_half_len}; off_={off}
    positions={positions}
    chain_ids=[]
    cap_shape=pb.createCollisionShape(pb.GEOM_CAPSULE,radius=lr,height=lhl*2,physicsClientId=c)
    for i,(x,z) in enumerate(positions):
        bid=pb.createMultiBody({p.mass_per_link},cap_shape,-1,[x,0.0,z],[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction=0.4,restitution=0.3,linearDamping=0.03,angularDamping=0.05,physicsClientId=c)
        if chain_ids:
            cid=pb.createConstraint(chain_ids[-1],-1,bid,-1,pb.JOINT_POINT2POINT,[0,0,1],[0,0,-off_],[0,0,off_],physicsClientId=c)
            pb.changeConstraint(cid,maxForce=200.0,physicsClientId=c)
        chain_ids.append(bid)
    pb.createConstraint(chain_ids[0],-1,-1,-1,pb.JOINT_FIXED,[0,0,0],[0,0,0],pivot,physicsClientId=c)
    _add_sphere(sc,"pivot",nodes,0.07,[0.9,0.85,0.2,1.0]); _set_pose(sc,nodes["pivot"],pivot,[0,0,0,1])
    for i in range({p.n_links}): _add_capsule(sc,f"link{{i}}",nodes,lr,lhl*2,{p.chain_color})
    bids=[(f"link{{i}}",bid) for i,bid in enumerate(chain_ids)]; frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_pendulum_chain_links")
    print("OK")
