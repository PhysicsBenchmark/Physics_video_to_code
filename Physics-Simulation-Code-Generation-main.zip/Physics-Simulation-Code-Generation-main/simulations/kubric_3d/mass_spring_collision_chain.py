"""mass_spring_collision_chain — projectile hits a chain of carts; spring visuals between carts."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (0.5, -5.0, 1.5)
CAM_TARGET = (0.5,  0.0, 0.2)
N_FRAMES   = 150


@dataclass
class Params:
    seed: int
    n_carts: int
    v0: float            # projectile speed (m/s)
    cart_mass: float     # each cart mass (kg)
    proj_mass: float     # projectile mass (kg)
    proj_color: List[float]
    cart_colors: List[List[float]]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    def _hue():
        h = random.random(); s, v = 0.85, 0.90; hi = int(h*6) % 6; f = h*6 - int(h*6)
        p_ = v*(1-s); q = v*(1-f*s); t = v*(1-(1-f)*s)
        r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
        return [r, g, b, 1.0]
    n = random.randint(3, 5)
    return Params(seed=seed, n_carts=n, v0=random.uniform(1.2, 2.2),
                  cart_mass=random.uniform(0.4, 0.9), proj_mass=random.uniform(0.20, 0.45),
                  proj_color=_hue(), cart_colors=[_hue() for _ in range(n)])


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        STANDALONE_IMPORTS, STANDALONE_UTILS, FPS)

    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=0.05)
    ren.add_plane_mesh("floor", 8.0, [0.38, 0.38, 0.42, 1.0])
    ren.set_static_pose("floor", [0, 0, -0.02])

    cart_half = [0.18, 0.14, 0.10]
    cart_z    = cart_half[2]   # centre height = half-height (bottom on floor)
    gap       = 0.06           # initial gap between carts
    cart_step = 2 * cart_half[0] + gap   # x step between cart centres

    # Projectile: sphere starting to the left of cart 0
    proj_r  = 0.10
    proj_x0 = -0.8
    proj_bid = phys.add_sphere(proj_r, [proj_x0, 0.0, proj_r],
                               mass=p.proj_mass, friction=0.10, restitution=0.85,
                               vel=[p.v0, 0, 0])
    ren.add_sphere("proj", proj_r, p.proj_color)

    # Cart chain starting at x=0
    cart_bids = []
    x0_carts = []
    for i in range(p.n_carts):
        cx = i * cart_step
        x0_carts.append(cx)
        bid = phys.add_box(cart_half, [cx, 0.0, cart_z],
                           mass=p.cart_mass, friction=0.10, restitution=0.80)
        cart_bids.append(bid)
        ren.add_box(f"cart{i}", cart_half, p.cart_colors[i])

    dyn = [("proj", proj_bid)] + [(f"cart{i}", cart_bids[i]) for i in range(p.n_carts)]

    spring_col = [0.90, 0.75, 0.10, 1.0]
    N_SEG = 6   # zigzag segments per inter-cart spring

    def extra_sync(ph, re, fi):
        # Get cart x positions
        positions = []
        for bid in cart_bids:
            pos, _ = ph.get_pose(bid)
            positions.append(pos[0])

        # Draw zigzag spring between consecutive carts
        for i in range(len(positions) - 1):
            x1 = positions[i]   + cart_half[0]
            x2 = positions[i+1] - cart_half[0]
            if x2 - x1 < 0.005:
                continue
            seg = (x2 - x1) / N_SEG
            for j in range(N_SEG):
                xa = x1 + j * seg
                xb = x1 + (j + 1) * seg
                za = cart_z + (0.06 if j % 2 == 0 else -0.06)
                zb = cart_z + (-0.06 if j % 2 == 0 else 0.06)
                re.update_string(f"sp{i}_{j}", [xa, 0.0, za], [xb, 0.0, zb],
                                 0.010, spring_col)

    frames = run_loop(phys, ren, dyn, N_FRAMES, extra_sync_fn=extra_sync)

    cot = build_cot(
        simulation="mass_spring_collision_chain",
        category="rigid_body_constrained",
        seed=seed,
        physical_observation=(
            f"Projectile (m={p.proj_mass:.2f}kg, v₀={p.v0:.2f}m/s) "
            f"strikes chain of {p.n_carts} carts (m={p.cart_mass:.2f}kg each)."
        ),
        law_name="Impulse propagation in coupled masses",
        law_statement=(
            "Contact impulse from projectile propagates through cart chain. "
            "Each collision: impulse j = (1+e)m₁m₂(v_rel)/(m₁+m₂)."
        ),
        law_formula="j=\\frac{(1+e)m_1m_2\\Delta v}{m_1+m_2}",
        assumptions=[
            "Carts on frictionless track (μ=0.05 for stability).",
            "Contact impulses instantaneous per PyBullet substep.",
            "Spring visuals are cosmetic; dynamics from PyBullet contacts.",
        ],
        state_variables=["x_i (m)", "v_i (m/s)"],
        equations_latex=[
            "m_0 v_0 = m_0 v_0' + m_1 v_1'",
            "e=-(v_0'-v_1')/(v_0-v_1)",
        ],
        contact_impulse="j = (1+e)·m₁·m₂·Δv / (m₁+m₂)",
        derivation_steps=[
            f"Projectile p={p.proj_mass:.2f}kg at v₀={p.v0:.2f}m/s",
            f"Cart mass {p.cart_mass:.2f}kg, n={p.n_carts}",
            f"Momentum: {p.proj_mass*p.v0:.3f} kg·m/s",
        ],
        expected_behavior=[
            f"Projectile hits first cart at ~{(-0.8 - (-cart_half[0]))/p.v0:.2f}s.",
            "Impulse travels down cart chain visually.",
            "Last cart exits fastest (Newton's cradle effect).",
            "Spring visuals show inter-cart gaps.",
        ],
        parameters={
            "n_carts":    param_entry(p.n_carts,    "",    "number of carts"),
            "v0":         param_entry(p.v0,         "m/s", "projectile initial speed"),
            "cart_mass":  param_entry(p.cart_mass,  "kg",  "cart mass"),
            "proj_mass":  param_entry(p.proj_mass,  "kg",  "projectile mass"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# mass_spring_collision_chain  seed={p.seed}
import math, pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}
NC={p.n_carts}; V0={p.v0}; CM={p.cart_mass}; PM={p.proj_mass}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.setGravity(0,0,-9.81,physicsClientId=c); pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[4,4,0.02],[0.38,0.38,0.42,1.0]); _set_pose(sc,nodes["fl"],[0,0,-0.02],[0,0,0,1])
    pr=0.10; ph=[0.18,0.14,0.10]; gap=0.06; step=ph[0]*2+gap; sc_=[0.90,0.75,0.10,1.0]
    s=pb.createCollisionShape(pb.GEOM_SPHERE,radius=pr,physicsClientId=c)
    pbid=pb.createMultiBody(PM,s,-1,[-0.8,0,pr],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(pbid,-1,lateralFriction=0.1,restitution=0.85,physicsClientId=c)
    pb.resetBaseVelocity(pbid,[V0,0,0],[0,0,0],physicsClientId=c)
    _add_sphere(sc,"proj",nodes,pr,{p.proj_color}); bids=[(\"proj\",pbid)]
    for i in range(NC):
        cx=i*step; s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=ph,physicsClientId=c)
        bid=pb.createMultiBody(CM,s,-1,[cx,0,ph[2]],[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction=0.1,restitution=0.8,physicsClientId=c)
        _add_box(sc,f"c{{i}}",nodes,ph,{p.cart_colors}[i%{p.n_carts}]); bids.append((f"c{{i}}",bid))
    cbids=[bids[i+1][1] for i in range(NC)]; frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c); _set_pose(sc,nodes[nm],pp,oo)
        xs=[pb.getBasePositionAndOrientation(b,physicsClientId=c)[0][0] for b in cbids]
        for i in range(len(xs)-1):
            x1=xs[i]+ph[0]; x2=xs[i+1]-ph[0]
            if x2-x1>0.005:
                seg=(x2-x1)/6
                for j in range(6):
                    xa=x1+j*seg;xb=x1+(j+1)*seg;za=ph[2]+(0.06 if j%2==0 else -0.06);zb=ph[2]+(-0.06 if j%2==0 else 0.06)
                    _update_string(sc,nodes,f"sp{{i}}_{{j}}",[xa,0,za],[xb,0,zb],0.010,sc_)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_mass_spring_collision_chain")
    print("OK")
