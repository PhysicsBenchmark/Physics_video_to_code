"""rope_over_edge — chain draped over table edge; hanging half pulls the rest off."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (5, -3, 4)
CAM_TARGET = (0, 0, 1.5)
N_FRAMES   = 150


@dataclass
class Params:
    seed:              int
    n_links:           int
    link_radius:       float
    link_half_len:     float
    mass_per_link:     float
    table_height:      float
    table_half_x:      float   # half extent of table in x
    overhang_fraction: float   # fraction of chain links hanging over edge (0.2–0.5)
    floor_friction:    float
    chain_color:       List[float]
    table_color:       List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        n_links=random.randint(14, 22),
        link_radius=random.uniform(0.022, 0.04),
        link_half_len=random.uniform(0.04, 0.07),
        mass_per_link=random.uniform(0.04, 0.10),
        table_height=random.uniform(1.0, 1.6),
        table_half_x=random.uniform(0.8, 1.4),
        overhang_fraction=random.uniform(0.25, 0.45),
        floor_friction=random.uniform(0.4, 0.7),
        chain_color=[random.uniform(0.45, 0.8), random.uniform(0.35, 0.7),
                     random.uniform(0.2, 0.55), 1.0],
        table_color=[random.uniform(0.5, 0.75), random.uniform(0.35, 0.6),
                     random.uniform(0.2, 0.45), 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 12.0, [0.42, 0.42, 0.45, 1.0])
    ren.set_static_pose("floor", [0, 0, 0])

    table_thick = 0.1
    # Static table: box at height table_height/2 + thick/2
    table_z = p.table_height
    phys.add_box(
        [p.table_half_x, 0.8, table_thick / 2],
        [0, 0, table_z - table_thick / 2],
        mass=0, friction=0.5, restitution=0.1)
    ren.add_box("table", [p.table_half_x, 0.8, table_thick / 2], p.table_color)
    ren.set_static_pose("table", [0, 0, table_z - table_thick / 2])

    # Table legs (visual only)
    leg_h = table_z - table_thick / 2
    for lx, ly in [(-p.table_half_x + 0.1, 0.6), (-p.table_half_x + 0.1, -0.6),
                   ( p.table_half_x - 0.1, 0.6), ( p.table_half_x - 0.1, -0.6)]:
        name = f"leg_{lx:.2f}_{ly:.2f}".replace("-", "m").replace(".", "p")
        ren.add_box(name, [0.04, 0.04, leg_h / 2], [0.35, 0.25, 0.15, 1.0])
        ren.set_static_pose(name, [lx, ly, leg_h / 2])

    # Chain: starts on table, with overhang over right edge (x = +table_half_x)
    segment        = p.link_half_len * 2 + p.link_radius * 0.5
    n_hang         = max(1, int(p.n_links * p.overhang_fraction))
    n_table        = p.n_links - n_hang
    edge_x         = p.table_half_x

    chain_ids: List[int] = []
    for i in range(p.n_links):
        if i < n_table:
            # on table surface
            x   = edge_x - (n_table - i) * segment
            pos = [x, 0.0, table_z + p.link_radius + 0.01]
        else:
            # hanging over edge
            hang_i = i - n_table
            x      = edge_x
            z      = table_z - hang_i * segment
            pos    = [x, 0.0, z]

        bid = phys.add_capsule(
            p.link_radius, p.link_half_len * 2, pos,
            orn=(0, 0, 0, 1),
            mass=p.mass_per_link,
            friction=0.5, restitution=0.2,
            lin_damp=0.05, ang_damp=0.1)

        if chain_ids:
            off = p.link_half_len + p.link_radius * 0.25
            phys.create_constraint(
                chain_ids[-1], -1, bid, -1,
                pb_mod.JOINT_POINT2POINT, [0, 0, 1],
                [0, 0, -off], [0, 0, off],
                max_force=200.0)
        chain_ids.append(bid)

    for i in range(p.n_links):
        ren.add_capsule(f"link{i}", p.link_radius, p.link_half_len * 2, p.chain_color)

    dyn = [(f"link{i}", bid) for i, bid in enumerate(chain_ids)]
    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="rope_over_edge",
        category="rope_chain",
        seed=seed,
        physical_observation=(
            f"Chain of {p.n_links} links on table (height {p.table_height:.2f}m). "
            f"{n_hang} links ({p.overhang_fraction:.0%}) hang over edge. "
            f"Hanging portion pulls chain off table."),
        law_name="Chain-over-edge problem (Atwood-like)",
        law_statement=(
            "The hanging portion of a chain accelerates the whole chain off a "
            "table; acceleration a = g * x/L where x is the hanging length."),
        law_formula="a = g * (n_hang/n_total) * m_per_link / total_mass",
        assumptions=[
            "Chain is uniform and flexible.",
            "Table edge is sharp; friction on table surface present.",
            "No air resistance.",
        ],
        state_variables=["r_i (m)", "v_i (m/s)", "q_i", "omega_i (rad/s)"],
        equations_latex=[
            r"\dot{r}_i = v_i",
            r"m_{total}\ddot{x} = m_{hang} g - \mu m_{table} g",
        ],
        contact_impulse="j = -(1+e)*v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            f"Hanging mass: {n_hang} * {p.mass_per_link:.3f} = {n_hang*p.mass_per_link:.3f} kg.",
            f"Total mass: {p.n_links * p.mass_per_link:.3f} kg.",
            f"Ideal acceleration: a ≈ {n_hang*9.81/p.n_links:.3f} m/s² (frictionless).",
            "Chain accelerates until all links fall off table.",
        ],
        expected_behavior=[
            "Hanging portion pulls rest of chain toward edge.",
            "Chain slides off table and falls to floor.",
            "Final state: all links piled on floor.",
        ],
        parameters={
            "n_links":             param_entry(p.n_links, "", "Total number of links"),
            "link_radius_m":       param_entry(p.link_radius, "m", "Link radius"),
            "link_half_len_m":     param_entry(p.link_half_len, "m", "Link half-length"),
            "mass_per_link_kg":    param_entry(p.mass_per_link, "kg", "Mass per link"),
            "table_height_m":      param_entry(p.table_height, "m", "Table height"),
            "overhang_fraction":   param_entry(p.overhang_fraction, "", "Fraction of chain hanging"),
            "n_hang":              param_entry(n_hang, "", "Number of hanging links"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    segment  = p.link_half_len * 2 + p.link_radius * 0.5
    n_hang   = max(1, int(p.n_links * p.overhang_fraction))
    n_table  = p.n_links - n_hang
    edge_x   = p.table_half_x
    table_z  = p.table_height
    off      = p.link_half_len + p.link_radius * 0.25
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# rope_over_edge  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[6.0,6.0,0.02],[0.42,0.42,0.45,1.0]); _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    tz={table_z}; tx={p.table_half_x}
    s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[tx,0.8,0.05],physicsClientId=c)
    pb.createMultiBody(0,s,-1,[0,0,tz-0.05],[0,0,0,1],physicsClientId=c)
    _add_box(sc,"table",nodes,[tx,0.8,0.05],{p.table_color}); _set_pose(sc,nodes["table"],[0,0,tz-0.05],[0,0,0,1])
    lr={p.link_radius}; lhl={p.link_half_len}; seg={segment}; off_={off}
    n_table={n_table}; n_hang={n_hang}; edge_x={edge_x}
    chain_ids=[]
    cap_shape=pb.createCollisionShape(pb.GEOM_CAPSULE,radius=lr,height=lhl*2,physicsClientId=c)
    for i in range({p.n_links}):
        if i<n_table:
            x=edge_x-(n_table-i)*seg; pos=[x,0.0,tz+lr+0.01]
        else:
            hi=i-n_table; pos=[edge_x,0.0,tz-hi*seg]
        bid=pb.createMultiBody({p.mass_per_link},cap_shape,-1,pos,[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction=0.5,restitution=0.2,linearDamping=0.05,angularDamping=0.1,physicsClientId=c)
        if chain_ids:
            cid=pb.createConstraint(chain_ids[-1],-1,bid,-1,pb.JOINT_POINT2POINT,[0,0,1],[0,0,-off_],[0,0,off_],physicsClientId=c)
            pb.changeConstraint(cid,maxForce=200.0,physicsClientId=c)
        chain_ids.append(bid)
    for i in range({p.n_links}): _add_capsule(sc,f"link{{i}}",nodes,lr,lhl*2,{p.chain_color})
    bids=[(f"link{{i}}",bid) for i,bid in enumerate(chain_ids)]; frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_rope_over_edge")
    print("OK")
