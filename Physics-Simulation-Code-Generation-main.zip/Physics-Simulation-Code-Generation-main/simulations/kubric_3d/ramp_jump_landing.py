"""ramp_jump_landing — sphere rolls up a ramp, launches off, and lands on floor."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (6.0, -3.0, 3.0)
CAM_TARGET = (1.0,  0.0, 0.5)
N_FRAMES   = 120  # 4 s @ 30 fps
FLOOR_VISUAL_SIZE = 200.0


@dataclass
class Params:
    seed:           int
    ramp_angle_deg: float   # ramp inclination (degrees)
    launch_speed:   float   # initial speed of ball at base (m/s)
    ball_radius:    float   # m
    ball_mass:      float   # kg
    restitution:    float
    ball_color:     List[float]
    ramp_color:     List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        ramp_angle_deg=random.uniform(20.0, 50.0),
        launch_speed=random.uniform(3.0, 8.0),
        ball_radius=random.uniform(0.06, 0.14),
        ball_mass=random.uniform(0.2, 1.5),
        restitution=random.uniform(0.3, 0.75),
        ball_color=[random.uniform(0.5, 1.0), random.uniform(0.3, 0.8),
                    random.uniform(0.2, 0.7), 1.0],
        ramp_color=[0.55, 0.48, 0.38, 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=0.5, restitution=p.restitution)
    ren.add_plane_mesh("floor", FLOOR_VISUAL_SIZE, [0.38, 0.38, 0.40, 1.0])
    ren.set_static_pose("floor", [0, 0, -0.02])

    # Ramp: inclined static box
    angle = math.radians(p.ramp_angle_deg)
    ramp_hl = 1.5   # half-length along slope
    ramp_hw = 0.5   # half-width
    ramp_ht = 0.05  # thin slab

    # Ramp tilts upward from -X toward +X (rotation around -Y by angle)
    ramp_orn = [0.0, -math.sin(angle / 2), 0.0, math.cos(angle / 2)]
    # Place ramp so low end is near x=-ramp_hl*cos(angle), z≈0
    ramp_cx = 0.0
    ramp_cz = ramp_hl * math.sin(angle)
    ramp_pos = [ramp_cx, 0.0, ramp_cz]

    phys.add_box([ramp_hl, ramp_hw, ramp_ht], ramp_pos,
                 orn=ramp_orn, mass=0.0, friction=0.6,
                 restitution=0.3)
    ren.add_box("ramp", [ramp_hl, ramp_hw, ramp_ht], p.ramp_color)
    ren.set_static_pose("ramp", ramp_pos, ramp_orn)

    # Support wedge under elevated ramp end
    support_h = ramp_hl * math.sin(angle) / 2
    support_x = ramp_hl * math.cos(angle) * 0.6
    if support_h > 0.05:
        phys.add_box([0.08, ramp_hw * 0.8, support_h],
                     [support_x, 0.0, support_h], mass=0.0, friction=0.8)
        ren.add_box("support", [0.08, ramp_hw * 0.8, support_h], p.ramp_color)
        ren.set_static_pose("support", [support_x, 0.0, support_h])

    # Ball starts at the low (uphill-start) end of the ramp, placed ON the ramp surface.
    # The ramp surface normal (pointing away from the slab top face) in world space:
    #   normal = [-sin(angle), 0, cos(angle)]  (tilted by ramp rotation)
    # A point on the ramp top face at x-parameter t along the slope (in ramp local x):
    #   world_x = ramp_cx + t * cos(angle)
    #   world_z = ramp_cz + t * sin(angle)   (ramp centre at ramp_cz)
    # The ramp top face (in ramp local frame) is at local_z = +ramp_ht from ramp centre.
    # Start at the low end: t = -ramp_hl (the lowest x-point of the ramp).
    t_start = -ramp_hl + p.ball_radius / math.cos(angle)  # slight inset so ball is on ramp
    # World position of the ramp top surface at t_start:
    surf_x = ramp_cx + t_start * math.cos(angle)
    surf_z = ramp_cz + t_start * math.sin(angle) + ramp_ht * math.cos(angle)
    # Offset ball centre by ball_radius along the surface normal
    normal_x = -math.sin(angle)
    normal_z =  math.cos(angle)
    start_x = surf_x + normal_x * p.ball_radius
    start_z = surf_z + normal_z * p.ball_radius
    # Ensure ball is above floor
    start_z = max(start_z, p.ball_radius + 0.005)
    # Give ball a push along the ramp surface (up the slope)
    vx = p.launch_speed * math.cos(angle)
    vz = p.launch_speed * math.sin(angle)

    bid = phys.add_sphere(p.ball_radius,
                          [start_x, 0.0, start_z],
                          mass=p.ball_mass, friction=0.5,
                          restitution=p.restitution,
                          vel=[vx, 0.0, vz])
    ren.add_sphere("ball", p.ball_radius, p.ball_color)
    dyn = [("ball", bid)]

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    # Approximate launch height at ramp top
    h_launch = 2 * ramp_hl * math.sin(angle)
    cot = build_cot(
        simulation="ramp_jump_landing",
        category="rigid_body_constrained",
        seed=seed,
        physical_observation=(
            f"Sphere (r={p.ball_radius:.3f} m, m={p.ball_mass:.2f} kg) "
            f"launched up a {p.ramp_angle_deg:.1f}° ramp "
            f"at {p.launch_speed:.1f} m/s, "
            f"reaches launch height ≈ {h_launch:.2f} m, then becomes projectile."),
        law_name="Energy conservation on ramp + projectile motion",
        law_statement=(
            "Ball converts KE to PE climbing the ramp, "
            "launches as projectile from ramp tip, lands under gravity."),
        law_formula="½mv²=mgh → v_launch=sqrt(v0²-2gh); then parabolic flight",
        assumptions=[
            "Sphere rolls without slipping on ramp (high friction).",
            "Air resistance neglected during flight.",
            "Landing surface is flat and rigid.",
        ],
        state_variables=["position r (m)", "velocity v (m/s)",
                         "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg+F_c",
            "I\\dot{\\omega}=\\tau_c-\\omega\\times I\\omega",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            f"Ball enters ramp at v={p.launch_speed:.1f} m/s.",
            f"Ramp angle θ={p.ramp_angle_deg:.1f}°, component along slope: {p.launch_speed:.1f} m/s.",
            f"Estimated launch height: {h_launch:.2f} m at ramp tip.",
            "After ramp tip: projectile flight under gravity.",
            f"Lands with restitution e={p.restitution:.2f}, may bounce.",
        ],
        expected_behavior=[
            "Ball rolls up ramp, decelerating.",
            "Launches off ramp tip as projectile.",
            "Falls in parabolic arc, bounces on landing.",
        ],
        parameters={
            "ramp_angle_deg": param_entry(p.ramp_angle_deg, "deg", "Ramp inclination"),
            "launch_speed_mps": param_entry(p.launch_speed,  "m/s", "Initial ball speed"),
            "ball_radius_m":  param_entry(p.ball_radius,    "m",   "Ball radius"),
            "ball_mass_kg":   param_entry(p.ball_mass,      "kg",  "Ball mass"),
            "restitution":    param_entry(p.restitution,    "",    "Coefficient of restitution"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    angle = math.radians(p.ramp_angle_deg)
    ramp_hl, ramp_hw, ramp_ht = 1.5, 0.5, 0.05
    ramp_orn = [0.0, -math.sin(angle / 2), 0.0, math.cos(angle / 2)]
    ramp_cx = 0.0
    ramp_cz = ramp_hl * math.sin(angle)
    ramp_pos = [ramp_cx, 0.0, ramp_cz]
    t_start = -ramp_hl + p.ball_radius / math.cos(angle)
    surf_x = ramp_cx + t_start * math.cos(angle)
    surf_z = ramp_cz + t_start * math.sin(angle) + ramp_ht * math.cos(angle)
    start_x = surf_x + (-math.sin(angle)) * p.ball_radius
    start_z = max(surf_z + math.cos(angle) * p.ball_radius, p.ball_radius + 0.01)
    support_h = ramp_hl * math.sin(angle) / 2
    support_x = ramp_hl * math.cos(angle) * 0.6
    vx = p.launch_speed * math.cos(angle)
    vz = p.launch_speed * math.sin(angle)
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# ramp_jump_landing  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[{FLOOR_VISUAL_SIZE/2:.1f},{FLOOR_VISUAL_SIZE/2:.1f},0.02],[0.38,0.38,0.40,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    ramp_pos={list(ramp_pos)}; ramp_orn={list(ramp_orn)}
    rs=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[{ramp_hl},{ramp_hw},{ramp_ht}],physicsClientId=c)
    pb.createMultiBody(0,rs,-1,ramp_pos,ramp_orn,physicsClientId=c)
    _add_box(sc,"ramp",nodes,[{ramp_hl},{ramp_hw},{ramp_ht}],{p.ramp_color})
    _set_pose(sc,nodes["ramp"],ramp_pos,ramp_orn)
    {"" if support_h <= 0.05 else f"ss2=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[0.08,{ramp_hw*0.8},{support_h}],physicsClientId=c)"}
    {"" if support_h <= 0.05 else f"pb.createMultiBody(0,ss2,-1,[{support_x},0.0,{support_h}],[0,0,0,1],physicsClientId=c)"}
    {"" if support_h <= 0.05 else f"_add_box(sc,'support',nodes,[0.08,{ramp_hw*0.8},{support_h}],{p.ramp_color})"}
    {"" if support_h <= 0.05 else f"_set_pose(sc,nodes['support'],[{support_x},0.0,{support_h}],[0,0,0,1])"}
    bs=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.ball_radius},physicsClientId=c)
    bid=pb.createMultiBody({p.ball_mass},bs,-1,[{start_x},0.0,{start_z}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(bid,-1,lateralFriction=0.5,restitution={p.restitution},physicsClientId=c)
    pb.resetBaseVelocity(bid,[{vx},0.0,{vz}],[0,0,0],physicsClientId=c)
    _add_sphere(sc,"ball",nodes,{p.ball_radius},{p.ball_color})
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
        _set_pose(sc,nodes["ball"],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_ramp_jump_landing")
    print("OK")
