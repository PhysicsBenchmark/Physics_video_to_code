"""concave_bowl_spin_orbit — ball spirals down the inside of a real concave hemispherical bowl.

The bowl is a triangle-mesh hemisphere registered with PyBullet as a static
concave collision shape (GEOM_MESH + GEOM_FORCE_CONCAVE_TRIMESH).  The ball is
seated near the rim with a tangential velocity that is too slow for a stable
orbit at that latitude, so gravity pulls it toward the bottom while contact
friction drains energy — the result is a clearly visible spiral descent.
"""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (2.6, -3.4, 2.4)   # oblique 3D view; bowl is rendered semi-transparent
CAM_TARGET = (0.0,  0.0, 0.4)
N_FRAMES   = 150
G          = 9.81


@dataclass
class Params:
    seed: int
    bowl_radius: float
    bowl_z: float
    bowl_friction: float
    bowl_restitution: float
    bowl_subdivisions: int
    ball_radius: float
    ball_mass: float
    ball_orbit_radius: float
    ball_init_speed: float
    ball_color: List[float]
    bowl_color: List[float]


def random_params(seed: int) -> Params:
    rng = random.Random(seed)
    bowl_radius = rng.uniform(0.65, 0.85)
    ball_radius = rng.uniform(0.07, 0.11)
    ball_mass   = rng.uniform(0.15, 0.30)
    # Effective inner-sphere radius the ball centre sits on.
    eff_R = bowl_radius - ball_radius
    # Start the ball just inside the rim (large latitude angle from vertical).
    # Below R_eff*0.96 the surface tangent steepens enough that the ball would
    # fly out; staying around 0.88-0.94 keeps the seat stable.
    ball_orbit_radius = eff_R * rng.uniform(0.88, 0.94)
    # Tangential speed: well below the ideal circular-orbit speed at this
    # latitude (which is large/diverges as r -> R_eff), so the ball cannot
    # hold the rim height and spirals down.
    ball_init_speed = rng.uniform(1.8, 2.7)
    return Params(
        seed=seed,
        bowl_radius=bowl_radius,
        bowl_z=bowl_radius + 0.02,           # bowl bottom sits at z=0.02
        bowl_friction=rng.uniform(0.12, 0.20),
        bowl_restitution=0.20,               # low so the ball doesn't bounce off
        bowl_subdivisions=3,                 # icosphere subdivision -> ~624 hemi faces
        ball_radius=ball_radius,
        ball_mass=ball_mass,
        ball_orbit_radius=ball_orbit_radius,
        ball_init_speed=ball_init_speed,
        ball_color=[0.85, 0.18, 0.14, 1.0],
        bowl_color=[0.55, 0.70, 0.92, 0.35],   # glass-tinted, semi-transparent
    )


def _build_bowl_mesh(radius: float, subdivisions: int = 3):
    """Lower hemisphere of an icosphere — open at z=0, deepest at z=-radius."""
    import trimesh
    sphere = trimesh.creation.icosphere(subdivisions=subdivisions, radius=radius)
    verts = np.asarray(sphere.vertices, dtype=float)
    faces = np.asarray(sphere.faces,    dtype=np.int64)
    keep = np.all(verts[faces][:, :, 2] <= 1e-6, axis=1)
    new_faces = faces[keep]
    used = np.unique(new_faces.flatten())
    remap = np.zeros(len(verts), dtype=np.int64)
    remap[used] = np.arange(len(used))
    new_verts = verts[used]
    new_faces = remap[new_faces]
    return trimesh.Trimesh(vertices=new_verts, faces=new_faces, process=False)


def _ball_seat_position(p: Params) -> List[float]:
    """Place the ball center on the inner surface so it begins its orbit
    in contact with the bowl at the requested orbit radius."""
    R_eff = p.bowl_radius - p.ball_radius
    r     = min(p.ball_orbit_radius, R_eff * 0.95)
    z_below = math.sqrt(max(R_eff * R_eff - r * r, 0.0))
    return [r, 0.0, p.bowl_z - z_below]


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, save_sample, build_cot, param_entry,
        FPS, STEP_RATE, metadata_only)
    import pybullet as pb_mod
    import pyrender
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)
    phys.add_plane(friction=0.55)
    ren.add_plane_mesh("floor", 7.0, [0.42, 0.42, 0.45, 1.0])

    bowl_mesh = _build_bowl_mesh(p.bowl_radius, p.bowl_subdivisions)

    # PyBullet concave static collision shape.
    bowl_collision = pb_mod.createCollisionShape(
        pb_mod.GEOM_MESH,
        vertices=bowl_mesh.vertices.tolist(),
        indices=bowl_mesh.faces.flatten().tolist(),
        flags=pb_mod.GEOM_FORCE_CONCAVE_TRIMESH,
        physicsClientId=phys.client,
    )
    bowl_pos = [0.0, 0.0, p.bowl_z]
    bowl_id = pb_mod.createMultiBody(
        baseMass=0,
        baseCollisionShapeIndex=bowl_collision,
        basePosition=bowl_pos,
        baseOrientation=[0, 0, 0, 1],
        physicsClientId=phys.client,
    )
    pb_mod.changeDynamics(bowl_id, -1,
                          lateralFriction=p.bowl_friction,
                          restitution=p.bowl_restitution,
                          physicsClientId=phys.client)

    # Render the same hemisphere as a translucent glass shell so the orbiting
    # ball remains visible through the bowl wall from any oblique angle.
    if not metadata_only():
        material = pyrender.MetallicRoughnessMaterial(
            baseColorFactor=p.bowl_color, metallicFactor=0.05,
            roughnessFactor=0.25, doubleSided=True, alphaMode='BLEND')
        bowl_pyrender = pyrender.Mesh.from_trimesh(
            bowl_mesh, material=material, smooth=True)
        bowl_node = ren.scene.add(bowl_pyrender, pose=np.eye(4))
        ren._nodes["bowl"] = bowl_node
        ren.set_static_pose("bowl", bowl_pos)

    ball_pos = _ball_seat_position(p)
    ball_vel = [0.0, p.ball_init_speed, 0.0]
    ball_bid = phys.add_sphere(
        radius=p.ball_radius, pos=ball_pos, mass=p.ball_mass,
        friction=p.bowl_friction, restitution=p.bowl_restitution, vel=ball_vel,
        lin_damp=0.0, ang_damp=0.05)
    ren.add_sphere("ball", p.ball_radius, p.ball_color)
    ren.set_static_pose("ball", ball_pos)

    bodies = [("ball", ball_bid)]
    steps_per_frame = STEP_RATE // FPS

    frames = []
    if metadata_only():
        save_sample(out_dir, asdict(p), _build_cot(p, build_cot, param_entry),
                    make_standalone_code(p), frames)
        phys.close(); ren.close(); return

    for _fi in range(N_FRAMES):
        for _ in range(steps_per_frame):
            phys.step()
        for nm, bid in bodies:
            pos, orn = phys.get_pose(bid)
            ren.set_pose(nm, pos, orn)
        frames.append(ren.render_frame())

    save_sample(out_dir, asdict(p), _build_cot(p, build_cot, param_entry),
                make_standalone_code(p), frames)
    phys.close(); ren.close()


def _build_cot(p: Params, build_cot, param_entry):
    R_eff = p.bowl_radius - p.ball_radius
    r     = p.ball_orbit_radius
    z_below = math.sqrt(max(R_eff * R_eff - r * r, 1e-6))
    theta_deg = math.degrees(math.asin(min(r / R_eff, 1.0)))
    ideal_v = math.sqrt(G * r * r / z_below) if z_below > 1e-6 else float("inf")
    rim_height = R_eff - z_below           # height above bowl bottom at start
    return build_cot(
        simulation="concave_bowl_spin_orbit",
        category="dissipative_curved_motion",
        seed=p.seed,
        physical_observation=(
            f"A ball (m={p.ball_mass:.3f} kg, r={p.ball_radius:.3f} m) is released on the "
            f"interior of a concave hemispherical bowl (R={p.bowl_radius:.3f} m) near the "
            f"rim, at orbit radius r={r:.3f} m (theta={theta_deg:.1f} deg from vertical, "
            f"height {rim_height:.3f} m above the bowl bottom) with tangential speed "
            f"v={p.ball_init_speed:.3f} m/s.  Because v is well below the ideal circular-"
            f"orbit speed at this latitude ({ideal_v:.2f} m/s), the ball cannot hold the "
            f"rim height: gravity pulls it inward and Coulomb friction (mu={p.bowl_friction:.2f}) "
            f"drains its energy, producing a spiral descent toward the bottom."
        ),
        law_name="Spiral descent on a concave surface with friction",
        law_statement=(
            "The ball is constrained to the interior of a hemispherical surface.  Gravity, "
            "the contact normal N (radial, inward), and Coulomb friction f (tangent to the "
            "surface, opposite to motion) determine the trajectory.  Mechanical energy "
            "E = 1/2 m v^2 + m g h is dissipated by friction (dE/dt = f.v <= 0), "
            "so the ball loses height each circuit and spirals to the bottom.  Vertical "
            "equilibrium gives N = m g cos(theta) + m v_t^2 / R_eff (centripetal "
            "contribution); friction magnitude is bounded by mu N."
        ),
        law_formula="m a = m g + N + f;  f = -mu |N| v_hat;  dE/dt = f.v <= 0",
        assumptions=[
            "The bowl is a static rigid concave triangle mesh (GEOM_MESH, FORCE_CONCAVE_TRIMESH).",
            "The ball is a rigid sphere; contact friction follows Coulomb's law.",
            "Restitution is small so the ball stays in continuous contact (no bouncing).",
            "Faceted icosphere bowl introduces tiny nonidealities; the spiral is not perfectly smooth.",
            "Gravity g = 9.81 m/s^2.  PyBullet integrates at 240 Hz.",
        ],
        state_variables=["position r (m)", "velocity v (m/s)",
                         "orientation q", "angular velocity omega (rad/s)"],
        equations_latex=[
            "m \\ddot{\\mathbf r} = m \\mathbf g + \\mathbf N + \\mathbf f",
            "|\\mathbf f| \\le \\mu |\\mathbf N|, \\quad \\mathbf f \\parallel -\\mathbf v_{\\text{tan}}",
            "\\frac{dE}{dt} = \\mathbf f \\cdot \\mathbf v < 0",
            "h(t) \\downarrow,\\; r(t) \\downarrow \\;\\text{(spiral inward and downward)}",
        ],
        contact_impulse="j_n = -(1+e)(v_rel . n) / m_eff;  |j_t| <= mu |j_n|",
        derivation_steps=[
            f"Effective inner-sphere radius: R_eff = R - r_ball = {R_eff:.3f} m",
            f"Initial latitude: theta = arcsin(r / R_eff) = {theta_deg:.2f} deg",
            f"Initial height above bottom: h0 = R_eff - sqrt(R_eff^2 - r^2) = {rim_height:.3f} m",
            f"Ideal circular-orbit speed at this latitude: v_ideal = {ideal_v:.2f} m/s; "
            f"actual v_init = {p.ball_init_speed:.3f} m/s << v_ideal -> ball must fall.",
            "Friction work per circuit drains energy; angular momentum about the vertical "
            "axis decays, giving an inward spiral until the ball comes to rest at the bottom.",
        ],
        expected_behavior=[
            "Ball starts near the rim and stays in continuous contact with the bowl.",
            "Trajectory is a clear spiral: orbit radius and height both decrease monotonically.",
            "Energy is dissipated by Coulomb friction (and a small amount by restitution).",
            "Ball settles near the bottom of the bowl by the end of the run.",
        ],
        parameters={
            "bowl_radius":         param_entry(p.bowl_radius,       "m",   "outer hemispherical bowl radius"),
            "bowl_z":              param_entry(p.bowl_z,            "m",   "bowl centre height"),
            "ball_radius":         param_entry(p.ball_radius,       "m",   "ball radius"),
            "ball_mass":           param_entry(p.ball_mass,         "kg",  "ball mass"),
            "start_orbit_radius":  param_entry(p.ball_orbit_radius, "m",   "initial horizontal radius of ball centre"),
            "start_height":        param_entry(rim_height,          "m",   "initial height above bowl bottom"),
            "ball_init_speed":     param_entry(p.ball_init_speed,   "m/s", "initial tangential speed"),
            "ideal_orbit_speed":   param_entry(ideal_v,             "m/s", "speed required to hold a circular orbit at the start latitude"),
            "bowl_friction":       param_entry(p.bowl_friction,     "",    "Coulomb friction coefficient"),
            "bowl_restitution":    param_entry(p.bowl_restitution,  "",    "restitution coefficient"),
        })


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    ball_pos = _ball_seat_position(p)
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# concave_bowl_spin_orbit  seed={p.seed}
import pybullet as pb
N_FRAMES = {N_FRAMES}; CAM_EYE = {CAM_EYE}; CAM_TARGET = {CAM_TARGET}
BOWL_RADIUS = {p.bowl_radius}; BOWL_Z = {p.bowl_z}
BOWL_SUB = {p.bowl_subdivisions}
BOWL_FRICTION = {p.bowl_friction}; BOWL_RESTITUTION = {p.bowl_restitution}
BALL_RADIUS = {p.ball_radius}; BALL_MASS = {p.ball_mass}
BALL_POS = {ball_pos}; BALL_VEL = [0.0, {p.ball_init_speed}, 0.0]
BALL_COLOR = {p.ball_color}; BOWL_COLOR = {p.bowl_color}

def _bowl_mesh(R, sub):
    sphere = trimesh.creation.icosphere(subdivisions=sub, radius=R)
    verts = np.asarray(sphere.vertices, dtype=float)
    faces = np.asarray(sphere.faces,    dtype=np.int64)
    keep = np.all(verts[faces][:, :, 2] <= 1e-6, axis=1)
    nf = faces[keep]
    used = np.unique(nf.flatten())
    remap = np.zeros(len(verts), dtype=np.int64); remap[used] = np.arange(len(used))
    return trimesh.Trimesh(vertices=verts[used], faces=remap[nf], process=False)

def main():
    c = _init_physics(); ren, sc = _make_renderer(CAM_EYE, CAM_TARGET); nodes = {{}}
    pb.loadURDF("plane.urdf", [0, 0, 0], physicsClientId=c)
    _add_box(sc, "floor", nodes, [3.5, 3.5, 0.02], [0.42, 0.42, 0.45, 1.0])
    _set_pose(sc, nodes["floor"], [0, 0, -0.02], [0, 0, 0, 1])

    bowl = _bowl_mesh(BOWL_RADIUS, BOWL_SUB)
    bsh = pb.createCollisionShape(pb.GEOM_MESH,
        vertices=bowl.vertices.tolist(), indices=bowl.faces.flatten().tolist(),
        flags=pb.GEOM_FORCE_CONCAVE_TRIMESH, physicsClientId=c)
    bowl_id = pb.createMultiBody(0, bsh, -1, [0, 0, BOWL_Z], [0, 0, 0, 1], physicsClientId=c)
    pb.changeDynamics(bowl_id, -1, lateralFriction=BOWL_FRICTION,
                       restitution=BOWL_RESTITUTION, physicsClientId=c)
    bowl_mat = pyrender.MetallicRoughnessMaterial(
        baseColorFactor=BOWL_COLOR, metallicFactor=0.05,
        roughnessFactor=0.25, doubleSided=True, alphaMode='BLEND')
    nodes["bowl"] = sc.add(pyrender.Mesh.from_trimesh(bowl, material=bowl_mat, smooth=True),
                            pose=np.eye(4))
    _set_pose(sc, nodes["bowl"], [0, 0, BOWL_Z], [0, 0, 0, 1])

    ssh = pb.createCollisionShape(pb.GEOM_SPHERE, radius=BALL_RADIUS, physicsClientId=c)
    ball = pb.createMultiBody(BALL_MASS, ssh, -1, BALL_POS, [0, 0, 0, 1], physicsClientId=c)
    pb.changeDynamics(ball, -1, lateralFriction=BOWL_FRICTION, restitution=BOWL_RESTITUTION,
                       linearDamping=0.0, angularDamping=0.05, physicsClientId=c)
    pb.resetBaseVelocity(ball, BALL_VEL, [0, 0, 0], physicsClientId=c)
    _add_sphere(sc, "ball", nodes, BALL_RADIUS, BALL_COLOR)
    _set_pose(sc, nodes["ball"], BALL_POS, [0, 0, 0, 1])

    bodies = [("ball", ball)]; frames = []
    for _ in range(N_FRAMES):
        for __ in range(8):
            pb.stepSimulation(physicsClientId=c)
        for nm, bid in bodies:
            pp, oo = pb.getBasePositionAndOrientation(bid, physicsClientId=c)
            _set_pose(sc, nodes[nm], pp, oo)
        rgba, _ = ren.render(sc, flags=pyrender.RenderFlags.RGBA)
        frames.append(rgba[:,:,:3])
    _save_video(frames, "video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")

if __name__ == "__main__":
    main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_concave_bowl_spin_orbit")
    print("OK")
