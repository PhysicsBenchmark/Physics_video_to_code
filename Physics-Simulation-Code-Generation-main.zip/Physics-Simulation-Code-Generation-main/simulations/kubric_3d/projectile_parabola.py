"""projectile_parabola — ball launched from elevated platform follows parabolic arc."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (8.0, 0.0, 4.0)
CAM_TARGET = (0.0, 0.0, 1.0)
N_FRAMES   = 120  # 4 s @ 30 fps


@dataclass
class Params:
    seed:             int
    launch_angle_deg: float   # elevation angle (degrees above horizontal)
    launch_speed:     float   # initial speed (m/s)
    launch_z:         float   # height of launch point (m)
    ball_radius:      float   # m
    ball_mass:        float   # kg
    restitution:      float
    ball_color:       List[float]
    platform_color:   List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        launch_angle_deg=random.uniform(30.0, 75.0),
        launch_speed=random.uniform(4.0, 12.0),
        launch_z=random.uniform(1.5, 3.0),
        ball_radius=random.uniform(0.06, 0.15),
        ball_mass=random.uniform(0.2, 1.5),
        restitution=random.uniform(0.3, 0.8),
        ball_color=[random.uniform(0.5, 1.0), random.uniform(0.3, 0.8),
                    random.uniform(0.2, 0.7), 1.0],
        platform_color=[0.50, 0.40, 0.30, 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=0.6, restitution=p.restitution)
    ren.add_plane_mesh("floor", 14.0, [0.36, 0.36, 0.38, 1.0])
    ren.set_static_pose("floor", [0, 0, 0])

    # Elevated launch platform (static box)
    plat_hx, plat_hy, plat_hz = 0.4, 0.4, p.launch_z / 2.0
    plat_pos = [-3.0, 0.0, plat_hz]
    phys.add_box([plat_hx, plat_hy, plat_hz], plat_pos, mass=0.0, friction=0.8)
    ren.add_box("platform", [plat_hx, plat_hy, plat_hz], p.platform_color)
    ren.set_static_pose("platform", plat_pos)

    # Launch ball
    angle = math.radians(p.launch_angle_deg)
    vx = p.launch_speed * math.cos(angle)
    vz = p.launch_speed * math.sin(angle)
    ball_start = [-3.0, 0.0, p.launch_z + p.ball_radius]
    bid = phys.add_sphere(p.ball_radius, ball_start,
                          mass=p.ball_mass, friction=0.3,
                          restitution=p.restitution,
                          vel=[vx, 0.0, vz])
    ren.add_sphere("ball", p.ball_radius, p.ball_color)
    dyn = [("ball", bid)]

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    # Theoretical range and time of flight
    t_flight = (vz + math.sqrt(vz**2 + 2 * 9.81 * p.launch_z)) / 9.81
    x_range = vx * t_flight
    cot = build_cot(
        simulation="projectile_parabola",
        category="rigid_body_constrained",
        seed=seed,
        physical_observation=(
            f"Ball (r={p.ball_radius:.3f} m, m={p.ball_mass:.2f} kg) "
            f"launched at {p.launch_angle_deg:.1f}° from z={p.launch_z:.2f} m "
            f"at speed {p.launch_speed:.1f} m/s. "
            f"Theoretical range ≈ {x_range:.2f} m, flight time ≈ {t_flight:.2f} s."),
        law_name="Projectile motion under gravity",
        law_statement=(
            "In the absence of air resistance, horizontal velocity is constant "
            "and vertical velocity changes at -g."),
        law_formula="x(t)=v0*cos(θ)*t,  z(t)=z0+v0*sin(θ)*t-½g*t²",
        assumptions=[
            "No air resistance; only gravity acts during flight.",
            "Ball is a rigid sphere; aerodynamic lift/drag neglected.",
            "Floor is flat and provides Coulomb friction on landing.",
        ],
        state_variables=["position r (m)", "velocity v (m/s)",
                         "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "x(t)=x_0+v_x t",
            "z(t)=z_0+v_z t-\\frac{1}{2}g t^2",
            "v_x=\\text{const},\\quad v_z=v_{z0}-gt",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            f"Initial velocity: vx={vx:.2f} m/s, vz={vz:.2f} m/s.",
            f"Apex at t={vz/9.81:.2f} s, height={p.launch_z + vz**2/(2*9.81):.2f} m.",
            f"Lands at x≈{-3.0 + x_range:.2f} m after t≈{t_flight:.2f} s.",
            f"Restitution e={p.restitution:.2f} → ball may bounce after landing.",
        ],
        expected_behavior=[
            f"Parabolic arc from z={p.launch_z:.2f} m platform.",
            f"Lands approximately {x_range:.1f} m downrange.",
            "Bounces on landing according to restitution coefficient.",
        ],
        parameters={
            "launch_angle_deg": param_entry(p.launch_angle_deg, "deg", "Launch elevation angle"),
            "launch_speed_mps": param_entry(p.launch_speed,    "m/s", "Initial speed"),
            "launch_z_m":       param_entry(p.launch_z,        "m",   "Launch height"),
            "ball_radius_m":    param_entry(p.ball_radius,     "m",   "Ball radius"),
            "ball_mass_kg":     param_entry(p.ball_mass,       "kg",  "Ball mass"),
            "restitution":      param_entry(p.restitution,     "",    "Coefficient of restitution"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    angle = math.radians(p.launch_angle_deg)
    vx = p.launch_speed * math.cos(angle)
    vz = p.launch_speed * math.sin(angle)
    plat_hz = p.launch_z / 2.0
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# projectile_parabola  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[7.0,7.0,0.02],[0.36,0.36,0.38,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    ps=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[0.4,0.4,{plat_hz}],physicsClientId=c)
    pb.createMultiBody(0,ps,-1,[-3.0,0.0,{plat_hz}],[0,0,0,1],physicsClientId=c)
    _add_box(sc,"platform",nodes,[0.4,0.4,{plat_hz}],{p.platform_color})
    _set_pose(sc,nodes["platform"],[-3.0,0.0,{plat_hz}],[0,0,0,1])
    bs=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.ball_radius},physicsClientId=c)
    bid=pb.createMultiBody({p.ball_mass},bs,-1,[-3.0,0.0,{p.launch_z+p.ball_radius}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(bid,-1,lateralFriction=0.3,restitution={p.restitution},physicsClientId=c)
    pb.resetBaseVelocity(bid,[{vx},0.0,{vz}],[0,0,0],physicsClientId=c)
    _add_sphere(sc,"ball",nodes,{p.ball_radius},{p.ball_color})
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
        _set_pose(sc,nodes["ball"],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_projectile_parabola")
    print("OK")
