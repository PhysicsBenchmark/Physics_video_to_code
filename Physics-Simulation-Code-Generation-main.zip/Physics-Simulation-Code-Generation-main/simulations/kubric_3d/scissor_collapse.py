"""scissor_collapse — alternating diagonal rod pairs lean against each other and collapse."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (5, -3, 4)
CAM_TARGET = (0, 0, 1)
N_FRAMES   = 150


@dataclass
class Params:
    seed: int
    n_pairs: int
    rod_half_length: float
    rod_half_thickness: float
    rod_half_height: float
    rod_mass: float
    restitution: float
    friction: float
    lean_angle_deg: float
    colors: List[List[float]]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    n = random.randint(4, 6)
    return Params(
        seed=seed,
        n_pairs=n,
        rod_half_length=random.uniform(0.5, 0.9),
        rod_half_thickness=random.uniform(0.03, 0.06),
        rod_half_height=random.uniform(0.03, 0.06),
        rod_mass=random.uniform(0.3, 0.8),
        restitution=random.uniform(0.2, 0.5),
        friction=random.uniform(0.4, 0.7),
        lean_angle_deg=random.uniform(20.0, 40.0),
        colors=[_rand_hue() for _ in range(n * 2)],
    )


def _rand_hue():
    h = random.random(); s, v = 0.85, 0.90
    hi = int(h*6) % 6; f = h*6 - int(h*6)
    p_ = v*(1-s); q = v*(1-f*s); t = v*(1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return [r, g, b, 1.0]


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.friction)
    ren.add_plane_mesh("floor", 8.0, [0.42, 0.42, 0.45, 1.0])

    # Build alternating diagonal rows of thin boxes leaning against each other
    # Each pair: two rods arranged in X shape at position i
    # Row A leans at +angle, Row B leans at -angle, alternating in Y
    dyn = []
    he = [p.rod_half_length, p.rod_half_thickness, p.rod_half_height]
    angle_rad = math.radians(p.lean_angle_deg)

    spacing = p.rod_half_length * 2 * 0.6
    x_start = -spacing * p.n_pairs / 2.0

    for i in range(p.n_pairs):
        cx = x_start + i * spacing
        # Two rods per pair: one leans +, one leans -
        for j, sign in enumerate([1, -1]):
            rot_angle = sign * angle_rad
            # Quaternion about Y axis
            qy = [0.0, math.sin(rot_angle / 2), 0.0, math.cos(rot_angle / 2)]
            # Height: rods rest on floor; center at rod_half_height + lean offset
            cy = (j - 0.5) * p.rod_half_thickness * 3.0
            cz = p.rod_half_height + p.rod_half_length * abs(math.sin(angle_rad)) * 0.5
            # small initial velocity to trigger collapse
            vx = random.uniform(-0.1, 0.1)
            vy = random.uniform(-0.1, 0.1)
            nm = f"rod{i}_{j}"
            color = p.colors[i * 2 + j]
            bid = phys.add_box(he, [cx, cy, cz], orn=qy,
                                mass=p.rod_mass, friction=p.friction,
                                restitution=p.restitution,
                                vel=(vx, vy, 0.0))
            ren.add_box(nm, he, color)
            ren.set_static_pose(nm, [cx, cy, cz], qy)
            dyn.append((nm, bid))

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="scissor_collapse",
        category="mixed_complex",
        seed=seed,
        physical_observation=(
            f"{p.n_pairs} pairs of thin rods (l={p.rod_half_length*2:.2f}m, "
            f"t={p.rod_half_thickness*2:.3f}m) arranged alternating at ±{p.lean_angle_deg:.1f}°; "
            f"small perturbations trigger cascade collapse."
        ),
        law_name="Newton-Euler rigid-body tipping and cascade dynamics",
        law_statement=(
            "Each rod pair forms an unstable equilibrium; small perturbations cause tipping; "
            "falling rods impact adjacent pairs, propagating collapse along the structure."
        ),
        law_formula="τ_tip = m·g·d_cm; I·α = τ_net",
        assumptions=[
            "Rigid thin box approximation for rods",
            "Coulomb friction at floor contacts",
            "Initial small random velocities trigger instability",
            "No structural joints between rods",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg+\\sum F_c",
            "I\\dot{\\omega}=\\sum\\tau_c-\\omega\\times I\\omega",
            "\\tau_{tip}=mgd_{cm}\\sin\\phi",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B + cross_terms)",
        derivation_steps=[
            f"Each rod pair leans at ±{p.lean_angle_deg:.1f}° from horizontal",
            f"Tipping torque τ = {p.rod_mass:.2f}×9.81×{p.rod_half_length:.2f}×sin({p.lean_angle_deg:.1f}°) = {p.rod_mass*9.81*p.rod_half_length*math.sin(angle_rad):.3f} N·m",
            "Small perturbation initiates first pair's fall",
            "Falling rod impacts adjacent pair; impulse propagates collapse",
            "Cascade proceeds along row",
        ],
        expected_behavior=[
            "Structure initially stable with slight lean",
            "Perturbation causes first pair to begin falling",
            "Cascade: each falling rod knocks over neighbors",
            "All rods collapse to floor in sequence",
        ],
        parameters={
            "n_pairs":           param_entry(p.n_pairs,           "",    "number of rod pairs"),
            "rod_half_length":   param_entry(p.rod_half_length,   "m",   "half-length of each rod"),
            "rod_half_thickness":param_entry(p.rod_half_thickness,"m",   "half-thickness of each rod"),
            "rod_mass":          param_entry(p.rod_mass,          "kg",  "mass of each rod"),
            "lean_angle_deg":    param_entry(p.lean_angle_deg,    "deg", "rod lean angle from horizontal"),
            "restitution":       param_entry(p.restitution,       "",    "coefficient of restitution"),
            "friction":          param_entry(p.friction,          "",    "lateral friction coefficient"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    random.seed(p.seed + 42); np.random.seed(p.seed + 42)
    he = [p.rod_half_length, p.rod_half_thickness, p.rod_half_height]
    angle_rad = math.radians(p.lean_angle_deg)
    spacing = p.rod_half_length * 2 * 0.6
    x_start = -spacing * p.n_pairs / 2.0
    rod_lines = []
    bids_list = []
    for i in range(p.n_pairs):
        cx = x_start + i * spacing
        for j, sign in enumerate([1, -1]):
            rot_angle = sign * angle_rad
            qy = [0.0, round(math.sin(rot_angle / 2), 6), 0.0, round(math.cos(rot_angle / 2), 6)]
            cy = (j - 0.5) * p.rod_half_thickness * 3.0
            cz = p.rod_half_height + p.rod_half_length * abs(math.sin(angle_rad)) * 0.5
            vx = round(random.uniform(-0.1, 0.1), 5)
            vy = round(random.uniform(-0.1, 0.1), 5)
            nm = f"rod{i}_{j}"
            color = p.colors[i * 2 + j]
            rod_lines.append(
                f"    sr=pb.createCollisionShape(pb.GEOM_BOX,halfExtents={he},physicsClientId=c)\n"
                f"    {nm.replace('{','').replace('}','')}=pb.createMultiBody({p.rod_mass},sr,-1,[{cx:.4f},{cy:.4f},{cz:.4f}],{qy},physicsClientId=c)\n"
                f"    pb.changeDynamics(rod{i}_{j},-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)\n"
                f"    pb.resetBaseVelocity(rod{i}_{j},[{vx},{vy},0],[0,0,0],physicsClientId=c)\n"
                f"    _add_box(sc,'rod{i}_{j}',nodes,{he},{color})\n"
                f"    _set_pose(sc,nodes['rod{i}_{j}'],[{cx:.4f},{cy:.4f},{cz:.4f}],{qy})\n"
            )
            bids_list.append(f"('rod{i}_{j}',rod{i}_{j})")
    bids_str = "[" + ",".join(bids_list) + "]"
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# scissor_collapse  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[4.0,4.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
{"".join(rod_lines)}    bids={bids_str}
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete()
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_scissor_collapse")
    print("OK")
