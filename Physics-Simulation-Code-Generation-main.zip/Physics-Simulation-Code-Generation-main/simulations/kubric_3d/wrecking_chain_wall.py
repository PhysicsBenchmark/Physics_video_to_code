"""wrecking_chain_wall — wrecking ball on chain swings as pendulum and demolishes a block wall."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (6, -4, 5)
CAM_TARGET = (0, 0, 2)
N_FRAMES   = 180


@dataclass
class Params:
    seed: int
    n_links: int
    link_radius: float
    link_half_len: float
    ball_radius: float
    ball_mass: float
    release_angle_deg: float
    wall_n_blocks: int
    block_mass: float
    floor_friction: float
    restitution: float
    pivot_height: float
    color_ball: List[float]
    color_block: List[float]
    color_chain: List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        n_links=random.randint(8, 12),
        link_radius=random.uniform(0.04, 0.07),
        link_half_len=random.uniform(0.10, 0.18),
        ball_radius=random.uniform(0.18, 0.30),
        ball_mass=random.uniform(8.0, 18.0),
        release_angle_deg=random.uniform(30.0, 60.0),
        wall_n_blocks=random.randint(8, 12),
        block_mass=random.uniform(0.3, 1.0),
        floor_friction=random.uniform(0.4, 0.7),
        restitution=random.uniform(0.3, 0.6),
        pivot_height=random.uniform(4.0, 5.5),
        color_ball=_rand_hue(),
        color_block=_rand_hue(),
        color_chain=_rand_hue(),
    )


def _rand_hue():
    h = random.random(); s, v = 0.85, 0.90
    hi = int(h*6) % 6; f = h*6 - int(h*6)
    p_ = v*(1-s); q = v*(1-f*s); t = v*(1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return [r, g, b, 1.0]


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 12.0, [0.42, 0.42, 0.45, 1.0])

    # Fixed pivot anchor at top
    pivot_pos = [0.0, 0.0, p.pivot_height]
    anc = phys.add_sphere(0.06, pivot_pos, mass=0.0)
    phys.fix_body(anc, pos=pivot_pos)
    ren.add_sphere("pivot", 0.06, [0.7, 0.7, 0.7, 1.0])
    ren.set_static_pose("pivot", pivot_pos)

    # Chain hangs from pivot — use fewer, fatter, shorter links for stability
    stable_n_links = max(4, p.n_links // 2)
    stable_link_radius = p.link_radius * 1.5   # fatter links
    stable_link_half_len = p.link_half_len * 0.7  # shorter links
    chain_start = [0.0, 0.0, p.pivot_height]
    links = phys.create_chain(stable_n_links, stable_link_radius, stable_link_half_len,
                               chain_start, mass_per_link=0.15,
                               friction=0.3, restitution=p.restitution)
    # Apply higher damping to each chain link to suppress jitter
    import pybullet as _pb_damp
    for lid in links:
        _pb_damp.changeDynamics(lid, -1,
                                linearDamping=0.3, angularDamping=0.5,
                                physicsClientId=phys.client)
    # Connect chain top to pivot
    stable_off = stable_link_half_len + stable_link_radius * 0.25
    phys.create_constraint(anc, -1, links[0], -1,
                            pb_mod.JOINT_POINT2POINT, [0, 0, 0],
                            [0.0, 0.0, 0.0],
                            [0.0, 0.0, stable_off],
                            max_force=3000.0)

    stable_seg = stable_link_half_len * 2 + stable_link_radius * 0.5
    for i, lid in enumerate(links):
        nm = f"lnk{i}"
        lz = p.pivot_height - i * stable_seg
        ren.add_capsule(nm, stable_link_radius, stable_link_half_len * 2, p.color_chain)
        ren.set_static_pose(nm, [0.0, 0.0, lz])

    # Wrecking ball at chain end
    # Displace ball sideways for pendulum release
    theta = math.radians(p.release_angle_deg)
    chain_len = stable_n_links * stable_seg
    ball_x = chain_len * math.sin(theta)
    ball_z = max(p.ball_radius + 0.05, p.pivot_height - chain_len * math.cos(theta))
    ball_pos = [ball_x, 0.0, ball_z]

    ball_id = phys.add_sphere(p.ball_radius, ball_pos,
                               mass=p.ball_mass, friction=0.3,
                               restitution=p.restitution)
    # Connect ball to last link
    phys.create_constraint(links[-1], -1, ball_id, -1,
                            pb_mod.JOINT_POINT2POINT, [0, 0, 0],
                            [0.0, 0.0, -stable_off], [0.0, 0.0, 0.0],
                            max_force=3000.0)
    ren.add_sphere("ball", p.ball_radius, p.color_ball, metallic=0.3, roughness=0.2)
    ren.set_static_pose("ball", ball_pos)

    # Wall of stacked blocks to the right
    wall_x = 2.0
    block_he = [0.12, 0.22, 0.14]
    n_cols = max(1, p.wall_n_blocks // 3)
    rows = (p.wall_n_blocks + n_cols - 1) // n_cols

    dyn = [("ball", ball_id)] + [(f"lnk{i}", lid) for i, lid in enumerate(links)]
    idx = 0
    for row in range(rows):
        for col in range(n_cols):
            if idx >= p.wall_n_blocks:
                break
            bx_w = wall_x
            by_w = (col - n_cols / 2.0 + 0.5) * block_he[1] * 2.2
            bz_w = block_he[2] + row * block_he[2] * 2.1
            nm = f"blk{idx}"
            bid = phys.add_box(block_he, [bx_w, by_w, bz_w],
                                mass=p.block_mass, friction=p.floor_friction,
                                restitution=p.restitution)
            ren.add_box(nm, block_he, p.color_block)
            ren.set_static_pose(nm, [bx_w, by_w, bz_w])
            dyn.append((nm, bid))
            idx += 1

    frames = run_loop(phys, ren, dyn, N_FRAMES, steps_per_frame=16)

    chain_len_approx = stable_n_links * stable_seg
    v_bottom = math.sqrt(max(0.0, 2 * 9.81 * chain_len_approx * (1 - math.cos(theta))))
    cot = build_cot(
        simulation="wrecking_chain_wall",
        category="mixed_complex",
        seed=seed,
        physical_observation=(
            f"Wrecking ball r={p.ball_radius:.2f}m m={p.ball_mass:.1f}kg on "
            f"{p.n_links}-link chain from pivot h={p.pivot_height:.2f}m; "
            f"released at θ={p.release_angle_deg:.1f}°; demolishes {p.wall_n_blocks} blocks."
        ),
        law_name="Flexible pendulum dynamics + collision impulse",
        law_statement=(
            "Chain-ball system acts as multi-link pendulum; gravitational PE converts to KE; "
            "ball strikes wall and transfers momentum via contact impulses."
        ),
        law_formula="v_bottom = sqrt(2gL(1-cosθ)); j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        assumptions=[
            "Rigid capsule links with point-to-point constraints",
            "Heavy ball approximates point mass at chain end",
            "Wall blocks are rigid; Coulomb friction on floor",
            "Chain links have small mass compared to ball",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg+T_{link}+F_c",
            "v_{bottom}\\approx\\sqrt{2gL(1-\\cos\\theta)}",
            "j_n=-(1+e)v_{rel,n}/(1/m_A+1/m_B)",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B + cross_terms)",
        derivation_steps=[
            f"Chain length L≈{chain_len_approx:.2f}m; θ={p.release_angle_deg:.1f}°",
            f"Ball bottom speed ≈{v_bottom:.2f} m/s (energy approximation)",
            "Chain transmits tension; ball traces arc and hits wall",
            f"KE at impact = 0.5×{p.ball_mass:.1f}×{v_bottom:.2f}² ≈{0.5*p.ball_mass*v_bottom**2:.1f}J",
            "Blocks scatter proportional to transferred momentum",
        ],
        expected_behavior=[
            "Ball swings in arc toward wall",
            "Chain straightens during downswing",
            "Ball strikes wall, scattering blocks",
            "Ball swings back; chain becomes slack then taut again",
        ],
        parameters={
            "n_links":           param_entry(p.n_links,           "",    "number of chain links"),
            "link_radius":       param_entry(p.link_radius,       "m",   "capsule link radius"),
            "link_half_len":     param_entry(p.link_half_len,     "m",   "half-length of each link"),
            "ball_radius":       param_entry(p.ball_radius,       "m",   "wrecking ball radius"),
            "ball_mass":         param_entry(p.ball_mass,         "kg",  "wrecking ball mass"),
            "release_angle_deg": param_entry(p.release_angle_deg, "deg", "release angle from vertical"),
            "wall_n_blocks":     param_entry(p.wall_n_blocks,     "",    "number of wall blocks"),
            "block_mass":        param_entry(p.block_mass,        "kg",  "mass per block"),
            "pivot_height":      param_entry(p.pivot_height,      "m",   "pivot height above floor"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    seg = p.link_half_len * 2 + p.link_radius * 0.5
    off = p.link_half_len + p.link_radius * 0.25
    theta = math.radians(p.release_angle_deg)
    chain_len = p.n_links * seg
    ball_x = chain_len * math.sin(theta)
    ball_z = max(p.ball_radius + 0.05, p.pivot_height - chain_len * math.cos(theta))
    block_he = [0.12, 0.22, 0.14]
    n_cols = max(1, p.wall_n_blocks // 3)
    rows = (p.wall_n_blocks + n_cols - 1) // n_cols

    link_lines = []
    for i in range(p.n_links):
        lz = p.pivot_height - i * seg
        link_lines.append(
            f"    sl=pb.createCollisionShape(pb.GEOM_CAPSULE,radius={p.link_radius},height={p.link_half_len*2},physicsClientId=c)\n"
            f"    l{i}=pb.createMultiBody(0.15,sl,-1,[0,0,{lz:.3f}],[0,0,0,1],physicsClientId=c)\n"
            f"    pb.changeDynamics(l{i},-1,lateralFriction=0.3,restitution={p.restitution},linearDamping=0.05,angularDamping=0.1,physicsClientId=c)\n"
            f"    _add_capsule(sc,'lnk{i}',nodes,{p.link_radius},{p.link_half_len*2},{p.color_chain})\n"
            f"    _set_pose(sc,nodes['lnk{i}'],[0,0,{lz:.3f}],[0,0,0,1])\n"
        )
        if i == 0:
            link_lines.append(
                f"    pb.createConstraint(anc,-1,l0,-1,pb.JOINT_POINT2POINT,[0,0,0],[0,0,0],[0,0,{off:.3f}],physicsClientId=c)\n"
            )
        else:
            link_lines.append(
                f"    pb.createConstraint(l{i-1},-1,l{i},-1,pb.JOINT_POINT2POINT,[0,0,0],[0,0,{-off:.3f}],[0,0,{off:.3f}],physicsClientId=c)\n"
            )

    block_lines = []
    idx = 0
    for row in range(rows):
        for col in range(n_cols):
            if idx >= p.wall_n_blocks:
                break
            bx_w = 2.0
            by_w = (col - n_cols / 2.0 + 0.5) * block_he[1] * 2.2
            bz_w = block_he[2] + row * block_he[2] * 2.1
            block_lines.append(
                f"    sb2=pb.createCollisionShape(pb.GEOM_BOX,halfExtents={block_he},physicsClientId=c)\n"
                f"    blk{idx}=pb.createMultiBody({p.block_mass},sb2,-1,[{bx_w},{by_w:.3f},{bz_w:.3f}],[0,0,0,1],physicsClientId=c)\n"
                f"    pb.changeDynamics(blk{idx},-1,lateralFriction={p.floor_friction},restitution={p.restitution},physicsClientId=c)\n"
                f"    _add_box(sc,'blk{idx}',nodes,{block_he},{p.color_block})\n"
                f"    _set_pose(sc,nodes['blk{idx}'],[{bx_w},{by_w:.3f},{bz_w:.3f}],[0,0,0,1])\n"
            )
            idx += 1

    bids_links = "[" + ",".join([f"('lnk{i}',l{i})" for i in range(p.n_links)]) + "]"
    bids_blocks = "[" + ",".join([f"('blk{i}',blk{i})" for i in range(p.wall_n_blocks)]) + "]"
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# wrecking_chain_wall  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[6.0,6.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    sa=pb.createCollisionShape(pb.GEOM_SPHERE,radius=0.06,physicsClientId=c)
    anc=pb.createMultiBody(0,sa,-1,[0,0,{p.pivot_height:.3f}],[0,0,0,1],physicsClientId=c)
    pb.createConstraint(anc,-1,-1,-1,pb.JOINT_FIXED,[0,0,0],[0,0,0],[0,0,{p.pivot_height:.3f}],physicsClientId=c)
    _add_sphere(sc,"pivot",nodes,0.06,[0.7,0.7,0.7,1.0])
    _set_pose(sc,nodes["pivot"],[0,0,{p.pivot_height:.3f}],[0,0,0,1])
{"".join(link_lines)}    sb=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.ball_radius},physicsClientId=c)
    ball=pb.createMultiBody({p.ball_mass},sb,-1,[{ball_x:.3f},0,{ball_z:.3f}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(ball,-1,lateralFriction=0.3,restitution={p.restitution},physicsClientId=c)
    pb.createConstraint(l{p.n_links-1},-1,ball,-1,pb.JOINT_POINT2POINT,[0,0,0],[0,0,{-off:.3f}],[0,0,0],physicsClientId=c)
    _add_sphere(sc,"ball",nodes,{p.ball_radius},{p.color_ball})
    _set_pose(sc,nodes["ball"],[{ball_x:.3f},0,{ball_z:.3f}],[0,0,0,1])
{"".join(block_lines)}    bids=[("ball",ball)]+{bids_links}+{bids_blocks}
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete()
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_wrecking_chain_wall")
    print("OK")
