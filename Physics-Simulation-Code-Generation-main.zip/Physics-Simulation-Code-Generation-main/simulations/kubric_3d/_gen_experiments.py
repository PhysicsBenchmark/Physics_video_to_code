#!/usr/bin/env python3
"""
_gen_experiments.py
Generates all 48 remaining experiment .py files for the kubric_3d dataset.
Run once:  python _gen_experiments.py
"""
import os, textwrap

OUT = os.path.dirname(os.path.abspath(__file__))

# ── shared header injected into every generated file ──────────────────────────
HEADER = '''\
"""{{DOCSTRING}}"""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List, Tuple
import numpy as np

CAM_EYE    = {CAM_EYE}
CAM_TARGET = {CAM_TARGET}
N_FRAMES   = {N_FRAMES}
SPF        = 8          # physics substeps per render frame (240 Hz / 30 fps)


@dataclass
class Params:
{PARAMS_FIELDS}

def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
{RANDOM_BODY}

def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        muted_grey, random_hue_color, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)
    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)
{SCENE_BODY}
    frames = run_loop(phys, ren, _dyn, N_FRAMES, extra_sync_fn=_extra_sync if '_extra_sync' in dir() else None)
    cot = build_cot(
        simulation="{NAME}", category="{CATEGORY}", seed=seed,
        physical_observation=_observation(p),
        law_name="{LAW_NAME}", law_statement="{LAW_STMT}", law_formula="{LAW_FMT}",
        assumptions={ASSUMPTIONS},
        state_variables=["position r (m)","velocity v (m/s)","quaternion q","ω (rad/s)"],
        equations_latex=["\\\\dot{{r}}=v","m\\\\dot{{v}}=mg+F_c","I\\\\dot{{\\\\omega}}=\\\\tau_c"],
        contact_impulse="j = -(1+e)·v_n / (1/m_A+1/m_B+cross)",
        derivation_steps={DERIVATION},
        expected_behavior={EXPECTED},
        parameters={{k: param_entry(getattr(p,k), "", k) for k in {PARAM_KEYS}}})
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# {NAME}  seed={{p.seed}}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}
def main():
{STANDALONE_BODY}
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir=f"/tmp/test_{NAME}")
    print("OK →", f"/tmp/test_{NAME}")
'''

# ═══════════════════════════════════════════════════════════════════════════════
# Each experiment is defined as a dict, then written to disk as a .py file
# ═══════════════════════════════════════════════════════════════════════════════

def write_file(name: str, content: str):
    path = os.path.join(OUT, f"{name}.py")
    with open(path, "w") as fh:
        fh.write(content)
    print(f"  wrote {path}")


def ind(text: str, n: int = 4) -> str:
    """Indent every non-empty line by n spaces."""
    pad = " " * n
    return "\n".join(pad + line if line.strip() else line for line in text.splitlines())


# ─────────────────────────────────────────────────────────────────────────────
# 03 domino_chain
# ─────────────────────────────────────────────────────────────────────────────
write_file("domino_chain", '''\
"""domino_chain — row of standing boxes, first one tipped, cascade falls."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (0.0, -7.0, 3.0)
CAM_TARGET = (0.0,  2.5, 0.5)
N_FRAMES   = 150


@dataclass
class Params:
    seed: int
    n_dominos:  int
    spacing:    float   # centre-to-centre Y spacing (m)
    dom_w:      float   # half-width X
    dom_d:      float   # half-depth Y
    dom_h:      float   # half-height Z
    mass:       float
    friction:   float
    restitution: float
    push_vel:   float   # initial Y velocity of first domino
    color:      List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    h = random.uniform(0.20, 0.35)
    d = random.uniform(0.025, 0.040)
    sp = random.uniform(0.16, 0.26)
    return Params(
        seed=seed,
        n_dominos=random.randint(6, 14),
        spacing=sp, dom_w=random.uniform(0.06, 0.10), dom_d=d, dom_h=h,
        mass=random.uniform(0.1, 0.6),
        friction=random.uniform(0.4, 0.8),
        restitution=random.uniform(0.1, 0.45),
        push_vel=random.uniform(0.5, 1.8),
        color=[random.uniform(0.3,0.9), random.uniform(0.2,0.8),
               random.uniform(0.1,0.7), 1.0])


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)
    phys.add_plane(friction=p.friction)
    ren.add_plane_mesh("floor", 8.0, [0.42, 0.42, 0.45, 1.0])

    dyn = []
    for i in range(p.n_dominos):
        y = i * p.spacing
        he = [p.dom_w, p.dom_d, p.dom_h]
        pos = [0.0, y, p.dom_h]
        bid = phys.add_box(he, pos, mass=p.mass, friction=p.friction,
                           restitution=p.restitution)
        if i == 0:
            import pybullet as bp
            bp.resetBaseVelocity(bid, [0, p.push_vel, 0], [0, 0, 0],
                                 physicsClientId=phys.client)
        name = f"dom_{i}"
        ren.add_box(name, he, p.color)
        dyn.append((name, bid))

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="domino_chain", category="rigid_body_free_dynamics", seed=seed,
        physical_observation=(
            f"{p.n_dominos} dominoes (h={p.dom_h*2:.3f} m, d={p.dom_d*2:.3f} m, "
            f"spacing={p.spacing:.3f} m, mass={p.mass:.3f} kg) tipped with "
            f"v₀={p.push_vel:.2f} m/s."),
        law_name="Rigid-body contact cascade — toppling condition",
        law_statement="A domino topples its neighbour when its falling edge reaches the next standing piece.",
        law_formula="Topple if d_spacing ≤ 2H·sin(θ_tip) where θ_tip = arccos(d/H)",
        assumptions=["Dominoes rigid; no elastic deformation",
                     "Dominos placed upright — any small push beyond θ_tip causes full fall",
                     "Floor friction prevents base sliding"],
        state_variables=["position r (m)","velocity v (m/s)","quaternion q","ω (rad/s)"],
        equations_latex=["\\dot{r}=v","m\\dot{v}=mg+F_c","I\\dot{\\omega}=\\tau_c"],
        contact_impulse="j = -(1+e)·v_n / (1/m_A + 1/m_B + cross)",
        derivation_steps=[
            f"Each domino stands upright: centre-of-mass at z={p.dom_h:.3f} m.",
            f"Critical tipping angle: θ_tip = arctan(dom_d/dom_h) = {math.degrees(math.atan(p.dom_d/p.dom_h)):.1f}°.",
            f"Spacing {p.spacing:.3f} m < 2·{p.dom_h:.3f}·sin(θ_tip) → cascade propagates.",
            "Each falling domino transfers angular impulse to the next."],
        expected_behavior=[
            f"First domino pushed at {p.push_vel:.2f} m/s begins tipping.",
            "Cascade propagates along Y-axis at roughly constant speed.",
            f"Last domino falls at t ≈ {p.n_dominos * p.spacing / 1.5:.1f} s."],
        parameters={
            "n_dominos":    param_entry(p.n_dominos, "", "Number of dominoes"),
            "spacing_m":    param_entry(p.spacing,  "m",  "Centre-to-centre spacing"),
            "height_m":     param_entry(p.dom_h*2,  "m",  "Domino height"),
            "mass_kg":      param_entry(p.mass,     "kg", "Mass per domino"),
            "friction":     param_entry(p.friction, "",   "Domino/floor friction"),
            "push_vel_mps": param_entry(p.push_vel, "m/s","Initial push velocity")})
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# domino_chain  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}
def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[4,4.5,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,2,0],[0,0,0,1])
    he=[{p.dom_w},{p.dom_d},{p.dom_h}]; bids=[]
    for i in range({p.n_dominos}):
        y=i*{p.spacing}; pos=[0,y,{p.dom_h}]
        s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=he,physicsClientId=c)
        bid=pb.createMultiBody({p.mass},s,-1,pos,[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
        if i==0: pb.resetBaseVelocity(bid,[0,{p.push_vel},0],[0,0,0],physicsClientId=c)
        nm=f"d_{{i}}"
        _add_box(sc,nm,nodes,he,{p.color}); bids.append((nm,bid))
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_domino_chain")
    print("OK")
''')


# ─────────────────────────────────────────────────────────────────────────────
# 04 billiard_break_3d
# ─────────────────────────────────────────────────────────────────────────────
write_file("billiard_break_3d", '''\
"""billiard_break_3d — cue ball breaks a rack of billiard balls on a table."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (0.0, -2.5, 2.5)
CAM_TARGET = (0.0,  0.8, 0.5)
N_FRAMES   = 120


@dataclass
class Params:
    seed: int
    ball_r:   float    # 0.028 m standard
    cue_speed: float
    cue_y:    float    # cue start Y
    table_friction: float
    restitution: float
    colors: List[List[float]]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        ball_r=random.uniform(0.025, 0.032),
        cue_speed=random.uniform(3.5, 8.0),
        cue_y=random.uniform(-1.0, -0.7),
        table_friction=random.uniform(0.10, 0.30),
        restitution=random.uniform(0.70, 0.92),
        colors=[[random.random(), random.random(), random.random(), 1.0] for _ in range(11)])


def _rack_positions(r: float):
    """Triangle rack: 4 rows, 1+2+3+4=10 balls."""
    positions = []
    row_offset = r * 2 * math.cos(math.pi / 6)
    for row in range(4):
        for col in range(row + 1):
            x = (col - row / 2.0) * r * 2.05
            y = row * row_offset
            positions.append([x, y, 0.0])
    return positions


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    table_z = 0.40
    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    # table top
    phys.add_box([1.1, 0.7, table_z], [0, 0.4, table_z/2], mass=0,
                 friction=p.table_friction, restitution=0.3)
    ren.add_box("table", [1.1, 0.7, table_z], [0.1, 0.55, 0.15, 1.0])
    ren.set_static_pose("table", [0, 0.4, table_z/2])

    phys.add_plane(friction=0.8)
    ren.add_plane_mesh("floor", 6.0, [0.35, 0.30, 0.25, 1.0])

    dyn = []
    rack = _rack_positions(p.ball_r)
    for i, rp in enumerate(rack):
        pos = [rp[0], rp[1] + 0.5, table_z + p.ball_r]
        bid = phys.add_sphere(p.ball_r, pos, mass=0.17,
                              friction=p.table_friction, restitution=p.restitution)
        nm = f"ball_{i}"
        ren.add_sphere(nm, p.ball_r, p.colors[i])
        dyn.append((nm, bid))

    # cue ball
    cue_bid = phys.add_sphere(p.ball_r,
                              [0.0, p.cue_y, table_z + p.ball_r],
                              mass=0.17, friction=p.table_friction,
                              restitution=p.restitution,
                              vel=[0.0, p.cue_speed, 0.0])
    ren.add_sphere("cue", p.ball_r, [0.97, 0.97, 0.97, 1.0])
    dyn.append(("cue", cue_bid))

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="billiard_break_3d", category="rigid_body_free_dynamics", seed=seed,
        physical_observation=(
            f"Cue ball (r={p.ball_r:.3f} m) strikes a 10-ball rack at {p.cue_speed:.1f} m/s "
            f"on a table with friction={p.table_friction:.2f}."),
        law_name="Conservation of momentum + restitution impulse (billiard collisions)",
        law_statement="In each ball-ball collision, momentum is transferred via normal impulse; energy loss governed by e.",
        law_formula="v_A'= v_A - (1+e)(v_rel·n̂)/(1/m_A+1/m_B)·n̂/m_A",
        assumptions=["Balls are perfect spheres of equal mass (0.17 kg each)",
                     "Table felt modelled as flat friction surface",
                     f"Restitution e={p.restitution:.2f} for all ball-ball contacts"],
        state_variables=["position r (m)","velocity v (m/s)","ω (rad/s)"],
        equations_latex=["\\dot{r}=v","m\\dot{v}=F_c+F_{friction}"],
        contact_impulse="j = -(1+e)·v_n·m/2  (equal mass case)",
        derivation_steps=[
            f"Cue ball launched at v={p.cue_speed:.1f} m/s toward rack apex.",
            "Apex ball receives impulse j, distributes to its two neighbours.",
            "Chain of impulses propagates through rack.",
            f"Table friction (μ={p.table_friction:.2f}) decelerates all balls over time."],
        expected_behavior=[
            "Rack scatters symmetrically from the apex hit.",
            f"Higher cue speed ({p.cue_speed:.1f} m/s) → wider scatter.",
            "Balls slow due to felt friction; some may fall off table edges."],
        parameters={
            "ball_radius_m":   param_entry(p.ball_r, "m", "Ball radius"),
            "cue_speed_mps":   param_entry(p.cue_speed, "m/s", "Cue-ball speed"),
            "table_friction":  param_entry(p.table_friction, "", "Table felt friction"),
            "restitution":     param_entry(p.restitution, "", "Ball-ball restitution")})
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    import math as _m
    rack = []
    row_off = p.ball_r * 2 * _m.cos(_m.pi / 6)
    for row in range(4):
        for col in range(row + 1):
            x = (col - row / 2.0) * p.ball_r * 2.05
            y = row * row_off
            rack.append([round(x, 5), round(y + 0.5, 5), round(0.40 + p.ball_r, 5)])
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# billiard_break_3d  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}
def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    pb.changeDynamics(0,-1,lateralFriction=0.8,physicsClientId=c)
    s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[1.1,0.7,0.20],physicsClientId=c)
    pb.createMultiBody(0,s,-1,[0,0.4,0.20],[0,0,0,1],physicsClientId=c)
    _add_box(sc,"tbl",nodes,[1.1,0.7,0.20],[0.1,0.55,0.15,1.0])
    _set_pose(sc,nodes["tbl"],[0,0.4,0.20],[0,0,0,1])
    bids=[]; rack={rack}; clr={p.colors}
    for i,(rp) in enumerate(rack):
        s=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.ball_r},physicsClientId=c)
        bid=pb.createMultiBody(0.17,s,-1,rp,[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction={p.table_friction},restitution={p.restitution},physicsClientId=c)
        _add_sphere(sc,f"b{{i}}",nodes,{p.ball_r},clr[i]); bids.append((f"b{{i}}",bid))
    s=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.ball_r},physicsClientId=c)
    cb=pb.createMultiBody(0.17,s,-1,[0,{p.cue_y},{0.40+p.ball_r}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(cb,-1,lateralFriction={p.table_friction},restitution={p.restitution},physicsClientId=c)
    pb.resetBaseVelocity(cb,[0,{p.cue_speed},0],[0,0,0],physicsClientId=c)
    _add_sphere(sc,"cue",nodes,{p.ball_r},[0.97,0.97,0.97,1.0]); bids.append(("cue",cb))
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_billiard")
    print("OK")
''')


# ─────────────────────────────────────────────────────────────────────────────
# Helper: generic experiment template factory
# ─────────────────────────────────────────────────────────────────────────────
def make_generic(name, docstring, cam_eye, cam_target, n_frames,
                 params_fields, random_body, scene_body, standalone_body,
                 obs_fn, law_name, law_stmt, law_fmt,
                 assumptions, derivation, expected, param_keys, category):
    """Write a generic experiment file from components."""
    code = f'''\
"""{docstring}"""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List, Tuple
import numpy as np

CAM_EYE    = {cam_eye}
CAM_TARGET = {cam_target}
N_FRAMES   = {n_frames}


@dataclass
class Params:
{params_fields}

def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
{random_body}

def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        muted_grey, random_hue_color, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)
    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)
    _dyn = []
    _extra_sync = None
{scene_body}
    frames = run_loop(phys, ren, _dyn, N_FRAMES, extra_sync_fn=_extra_sync)
    cot = build_cot(
        simulation="{name}", category="{category}", seed=seed,
        physical_observation={obs_fn},
        law_name="{law_name}",
        law_statement="{law_stmt}",
        law_formula=r"{law_fmt}",
        assumptions={assumptions},
        state_variables=["position r (m)","velocity v (m/s)","quaternion q","ω (rad/s)"],
        equations_latex=["\\\\dot{{r}}=v","m\\\\dot{{v}}=mg+F_c","I\\\\dot{{\\\\omega}}=\\\\tau_c"],
        contact_impulse="j = -(1+e)·v_n / (1/m_A+1/m_B+cross)",
        derivation_steps={derivation},
        expected_behavior={expected},
        parameters={{k: param_entry(getattr(p, k), "", k) for k in {param_keys}}})
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# {name}  seed={{p.seed}}
import pybullet as pb
N_FRAMES={n_frames}; CAM_EYE={cam_eye}; CAM_TARGET={cam_target}
def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{{{}}}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
{standalone_body}
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir=f"/tmp/test_{name}")
    print("OK")
'''
    write_file(name, code)


# ═══════════════════════════════════════════════════════════════════════════════
# 05 hourglass_sphere_flow
# ═══════════════════════════════════════════════════════════════════════════════
make_generic(
    name="hourglass_sphere_flow",
    docstring="hourglass_sphere_flow — spheres flow through a narrow neck.",
    cam_eye=(3.5, -3.5, 2.5), cam_target=(0.0, 0.0, 1.5), n_frames=180,
    category="rigid_body_free_dynamics",
    params_fields="""\
    seed: int
    n_balls: int
    ball_r:  float
    mass:    float
    friction: float
    restitution: float
    neck_w:  float    # half-width of neck opening
    colors:  List[List[float]]""",
    random_body="""\
    n = random.randint(15, 28)
    r = random.uniform(0.04, 0.07)
    return Params(seed=seed, n_balls=n, ball_r=r,
                  mass=random.uniform(0.01, 0.08),
                  friction=random.uniform(0.2, 0.5),
                  restitution=random.uniform(0.2, 0.5),
                  neck_w=random.uniform(r*1.3, r*2.2),
                  colors=[[random.random(), random.random(), random.random(), 1.0]
                          for _ in range(n)])""",
    scene_body="""\
    p = random_params(seed)
    phys.add_plane(friction=p.friction)
    ren.add_plane_mesh("floor", 4.0, muted_grey())

    # funnel walls: 4 angled wedge boxes
    nw = p.neck_w
    for i, (he, pos, orn) in enumerate([
        ([0.7, 0.05, 0.6], [-nw-0.35, 0, 1.5], [0,0,0,1]),
        ([0.7, 0.05, 0.6], [ nw+0.35, 0, 1.5], [0,0,0,1]),
        ([0.05, 0.7, 0.6], [0,-nw-0.35, 1.5], [0,0,0,1]),
        ([0.05, 0.7, 0.6], [0, nw+0.35, 1.5], [0,0,0,1])]):
        phys.add_box(he, pos, orn=orn, mass=0)
        ren.add_box(f"fw{i}", he, [0.5, 0.5, 0.55, 1.0])
        ren.set_static_pose(f"fw{i}", pos, orn)

    # drop balls into top chamber
    import itertools
    ball_bids = []
    for i in range(p.n_balls):
        x = (i % 4 - 1.5) * p.ball_r * 2.5
        y = (i // 4 % 4 - 1.5) * p.ball_r * 2.5
        z = 2.0 + (i // 16) * p.ball_r * 2.5
        bid = phys.add_sphere(p.ball_r, [x, y, z], mass=p.mass,
                              friction=p.friction, restitution=p.restitution)
        ren.add_sphere(f"b{i}", p.ball_r, p.colors[i])
        ball_bids.append(bid)
        _dyn.append((f"b{i}", bid))""",
    standalone_body="""\
    # funnel walls
    nw={p.neck_w}
    for he,pos in [([0.7,0.05,0.6],[-nw-0.35,0,1.5]),([0.7,0.05,0.6],[nw+0.35,0,1.5]),
                   ([0.05,0.7,0.6],[0,-nw-0.35,1.5]),([0.05,0.7,0.6],[0,nw+0.35,1.5])]:
        s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=he,physicsClientId=c)
        pb.createMultiBody(0,s,-1,pos,[0,0,0,1],physicsClientId=c)
    bids=[]; clr={p.colors}
    for i in range({p.n_balls}):
        x=(i%4-1.5)*{p.ball_r}*2.5; y=(i//4%4-1.5)*{p.ball_r}*2.5; z=2.0+(i//16)*{p.ball_r}*2.5
        s=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.ball_r},physicsClientId=c)
        bid=pb.createMultiBody({p.mass},s,-1,[x,y,z],[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
        _add_sphere(sc,f"b{{i}}",nodes,{p.ball_r},clr[i]); bids.append((f"b{{i}}",bid))
    _add_box(sc,"fl",nodes,[2,2,0.02],[0.4,0.4,0.43,1.0]); _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    frames=[]
    for _ in range(180):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])""",
    obs_fn='f"{p.n_balls} spheres (r={p.ball_r:.3f} m, m={p.mass:.3f} kg) draining through neck width {p.neck_w*2:.3f} m."',
    law_name="Granular flow through a constriction",
    law_stmt="Small particles (r < neck_w/2) pass; large ones jam at the neck.",
    law_fmt="Flow rate Q ∝ (D_neck - d_ball)^{5/2} (Beverloo law for granular media)",
    assumptions=["Particles are rigid spheres", "Funnel walls are frictionless rigid barriers",
                 "Jamming occurs probabilistically for r close to neck_w/2"],
    derivation=['Balls fall under gravity from top chamber.',
                'Neck geometry allows only balls with r < neck_w through.',
                'Balls land in bottom chamber and pile up.'],
    expected=['Balls flow through neck into lower chamber.',
              'Larger balls (near neck size) may bridge and block flow.',
              'Flow rate decreases as lower chamber fills.'],
    param_keys='["n_balls","ball_r","mass","friction","restitution","neck_w"]')


# ═══════════════════════════════════════════════════════════════════════════════
# 06 avalanche_slope
# ═══════════════════════════════════════════════════════════════════════════════
make_generic(
    name="avalanche_slope",
    docstring="avalanche_slope — objects released from an inclined plane.",
    cam_eye=(6.0, -3.0, 4.5), cam_target=(1.0, 2.5, 0.5), n_frames=150,
    category="rigid_body_free_dynamics",
    params_fields="""\
    seed: int
    angle_deg: float
    n_objects: int
    masses:  List[float]
    radii:   List[float]
    frictions: List[float]
    restitutions: List[float]
    colors: List[List[float]]
    kinds: List[str]    # sphere/box/cylinder""",
    random_body="""\
    n = random.randint(8, 16)
    ang = random.uniform(25.0, 42.0)
    return Params(seed=seed, angle_deg=ang, n_objects=n,
                  masses      =[random.uniform(0.2, 2.5)  for _ in range(n)],
                  radii       =[random.uniform(0.08, 0.22) for _ in range(n)],
                  frictions   =[random.uniform(0.15, 0.60) for _ in range(n)],
                  restitutions=[random.uniform(0.25, 0.75) for _ in range(n)],
                  colors      =[[random.random(),random.random(),random.random(),1.0] for _ in range(n)],
                  kinds       =[random.choice(["sphere","box","cylinder"]) for _ in range(n)])""",
    scene_body="""\
    p = random_params(seed)
    phys.add_plane(friction=0.5)
    ren.add_plane_mesh("floor", 10.0, muted_grey())

    # inclined ramp
    import pybullet as pb2
    ang_r = math.radians(p.angle_deg)
    ramp_len, ramp_w, ramp_th = 4.5, 1.5, 0.1
    cx = ramp_len/2 * math.cos(ang_r)
    cz = ramp_len/2 * math.sin(ang_r)
    orn_q = pb2.getQuaternionFromEuler([0, -ang_r, 0])
    phys.add_box([ramp_len/2, ramp_w/2, ramp_th],
                 [cx, 0.0, cz + ramp_th], orn=orn_q, mass=0, friction=0.4)
    ren.add_box("ramp", [ramp_len/2, ramp_w/2, ramp_th], [0.55, 0.50, 0.45, 1.0])
    ren.set_static_pose("ramp", [cx, 0.0, cz + ramp_th], orn_q)

    # barrier at the top (removed after 1 s = 30 frames)
    bar_pos = [ramp_len * 0.85 * math.cos(ang_r),
               0.0,
               ramp_len * 0.85 * math.sin(ang_r) + ramp_th * 2]
    barrier_id = phys.add_box([0.08, ramp_w/2, 0.25], bar_pos, mass=0)
    ren.add_box("barrier", [0.08, ramp_w/2, 0.25], [0.8, 0.2, 0.2, 1.0])
    ren.set_static_pose("barrier", bar_pos)

    # objects on slope
    for i in range(p.n_objects):
        t = 0.3 + i * 0.25
        ox = t * math.cos(ang_r) + (i%3 - 1) * 0.18
        oz = t * math.sin(ang_r) + ramp_th * 2 + p.radii[i]
        kind = p.kinds[i]
        if kind == "sphere":
            bid = phys.add_sphere(p.radii[i], [ox, (i%3-1)*0.22, oz],
                                  mass=p.masses[i], friction=p.frictions[i],
                                  restitution=p.restitutions[i])
            ren.add_sphere(f"obj{i}", p.radii[i], p.colors[i])
        elif kind == "box":
            he = [p.radii[i]*0.8]*3
            bid = phys.add_box(he, [ox, (i%3-1)*0.22, oz],
                               mass=p.masses[i], friction=p.frictions[i],
                               restitution=p.restitutions[i])
            ren.add_box(f"obj{i}", he, p.colors[i])
        else:
            bid = phys.add_cylinder(p.radii[i]*0.7, p.radii[i]*1.4,
                                    [ox,(i%3-1)*0.22,oz],
                                    mass=p.masses[i], friction=p.frictions[i],
                                    restitution=p.restitutions[i])
            ren.add_cylinder(f"obj{i}", p.radii[i]*0.7, p.radii[i]*1.4, p.colors[i])
        _dyn.append((f"obj{i}", bid))

    # schedule barrier removal at frame 30
    _barrier_id = barrier_id
    _phys_client = phys.client
    _removed = [False]
    def _extra_sync(ph, re, fi):
        if fi == 30 and not _removed[0]:
            import pybullet as _pb
            _pb.removeBody(_barrier_id, physicsClientId=_phys_client)
            _removed[0] = True""",
    standalone_body="""\
    import math
    ang_r=math.radians({p.angle_deg}); ramp_len=4.5
    cx=ramp_len/2*math.cos(ang_r); cz=ramp_len/2*math.sin(ang_r)
    orn_q=pb.getQuaternionFromEuler([0,-ang_r,0])
    s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[ramp_len/2,0.75,0.1],physicsClientId=c)
    pb.createMultiBody(0,s,-1,[cx,0,cz+0.1],orn_q,physicsClientId=c)
    _add_box(sc,"ramp",nodes,[ramp_len/2,0.75,0.1],[0.55,0.50,0.45,1.0])
    _set_pose(sc,nodes["ramp"],[cx,0,cz+0.1],orn_q)
    bar_pos=[ramp_len*0.85*math.cos(ang_r),0,ramp_len*0.85*math.sin(ang_r)+0.2]
    sb=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[0.08,0.75,0.25],physicsClientId=c)
    barrier_id=pb.createMultiBody(0,sb,-1,bar_pos,[0,0,0,1],physicsClientId=c)
    _add_box(sc,"bar",nodes,[0.08,0.75,0.25],[0.8,0.2,0.2,1.0])
    _set_pose(sc,nodes["bar"],bar_pos,[0,0,0,1])
    radii={p.radii}; masses={p.masses}; frics={p.frictions}; rests={p.restitutions}
    colors={p.colors}; kinds={p.kinds}; bids=[]
    for i in range({p.n_objects}):
        t=0.3+i*0.25; ox=t*math.cos(ang_r)+(i%3-1)*0.18; oz=t*math.sin(ang_r)+0.2+radii[i]
        if kinds[i]=="sphere":
            s=pb.createCollisionShape(pb.GEOM_SPHERE,radius=radii[i],physicsClientId=c)
            bid=pb.createMultiBody(masses[i],s,-1,[ox,(i%3-1)*0.22,oz],[0,0,0,1],physicsClientId=c)
            _add_sphere(sc,f"o{{i}}",nodes,radii[i],colors[i])
        else:
            he=[radii[i]*0.8]*3
            s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=he,physicsClientId=c)
            bid=pb.createMultiBody(masses[i],s,-1,[ox,(i%3-1)*0.22,oz],[0,0,0,1],physicsClientId=c)
            _add_box(sc,f"o{{i}}",nodes,he,colors[i])
        pb.changeDynamics(bid,-1,lateralFriction=frics[i],restitution=rests[i],physicsClientId=c)
        bids.append((f"o{{i}}",bid))
    frames=[]; removed=False
    for fi in range(150):
        if fi==30 and not removed: pb.removeBody(barrier_id,physicsClientId=c); removed=True
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])""",
    obs_fn='f"{p.n_objects} objects on {p.angle_deg:.1f}° slope, barrier removed at t=1 s."',
    law_name="Inclined plane dynamics — sliding vs rolling threshold",
    law_stmt="Object slides if friction < tan(θ); rolls otherwise. a_slide = g(sin θ - μ cos θ).",
    law_fmt="a = g(\\sin\\theta - \\mu\\cos\\theta)  [slide];  a = \\frac{{5}}{{7}}g\\sin\\theta  [sphere roll]",
    assumptions=["Ramp is rigid and stationary",
                 "Each object's motion independent until collision",
                 "Rolling without slipping when μ > (2/7)tan θ (sphere)"],
    derivation=[
        'Resolve gravity along ramp: F_par = mg·sin(θ), F_perp = mg·cos(θ).',
        'Friction force: f = μ·N = μ·mg·cos(θ).',
        'Net acceleration: a = g(sin θ - μ cos θ) for sliding.',
        'For rolling sphere: a = 5/7·g·sin θ (moment of inertia I=2mr²/5).'],
    expected=[
        f'Objects with friction < tan({p.angle_deg:.0f}°)={math.tan(math.radians(p.angle_deg)):.2f} slide.',
        'Spheres roll faster than boxes with same friction.',
        'All objects reach the bottom and spread on the floor.'],
    param_keys='["angle_deg","n_objects","masses","frictions","restitutions"]')


# ═══════════════════════════════════════════════════════════════════════════════
# 07 ball_pit_drop
# ═══════════════════════════════════════════════════════════════════════════════
make_generic(
    name="ball_pit_drop",
    docstring="ball_pit_drop — heavy ball dropped into a dense pit of small spheres.",
    cam_eye=(5.5, -5.5, 5.5), cam_target=(0.0, 0.0, 1.0), n_frames=150,
    category="rigid_body_free_dynamics",
    params_fields="""\
    seed: int
    n_pit: int
    pit_r: float
    heavy_r: float
    heavy_mass: float
    heavy_drop_z: float
    pit_friction: float
    pit_restitution: float""",
    random_body="""\
    return Params(seed=seed,
                  n_pit=random.randint(35, 55),
                  pit_r=random.uniform(0.08, 0.14),
                  heavy_r=random.uniform(0.22, 0.38),
                  heavy_mass=random.uniform(6.0, 18.0),
                  heavy_drop_z=random.uniform(3.2, 4.5),
                  pit_friction=random.uniform(0.3, 0.6),
                  pit_restitution=random.uniform(0.3, 0.65))""",
    scene_body="""\
    p = random_params(seed)
    # container walls
    cw = 1.8
    for he, pos in [
        ([cw, 0.05, 1.5], [0,  cw, 1.5]),
        ([cw, 0.05, 1.5], [0, -cw, 1.5]),
        ([0.05, cw, 1.5], [ cw, 0, 1.5]),
        ([0.05, cw, 1.5], [-cw, 0, 1.5])]:
        phys.add_box(he, pos, mass=0)
    phys.add_plane(friction=p.pit_friction)
    ren.add_plane_mesh("floor", 5.0, muted_grey())

    # pre-settle pit balls (physics only, 60 steps)
    pit_bids = []
    for i in range(p.n_pit):
        x = (i % 6 - 2.5) * p.pit_r * 2.2
        y = (i // 6 % 6 - 2.5) * p.pit_r * 2.2
        z = 0.15 + p.pit_r + (i // 36) * p.pit_r * 2.2
        bid = phys.add_sphere(p.pit_r, [x, y, z], mass=0.2,
                              friction=p.pit_friction, restitution=p.pit_restitution)
        pit_bids.append(bid)
    for _ in range(80):
        phys.step()

    # add render meshes for pit balls
    for i, bid in enumerate(pit_bids):
        col = [random.random(), random.random(), random.random(), 1.0]
        ren.add_sphere(f"pit{i}", p.pit_r, col)
        _dyn.append((f"pit{i}", bid))

    # drop heavy ball
    hb = phys.add_sphere(p.heavy_r, [0.0, 0.0, p.heavy_drop_z],
                         mass=p.heavy_mass, restitution=0.3, friction=0.4)
    ren.add_sphere("heavy", p.heavy_r, [0.85, 0.25, 0.15, 1.0])
    _dyn.append(("heavy", hb))""",
    standalone_body="""\
    cw=1.8
    for he,pos in [([cw,0.05,1.5],[0,cw,1.5]),([cw,0.05,1.5],[0,-cw,1.5]),
                   ([0.05,cw,1.5],[cw,0,1.5]),([0.05,cw,1.5],[-cw,0,1.5])]:
        s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=he,physicsClientId=c)
        pb.createMultiBody(0,s,-1,pos,[0,0,0,1],physicsClientId=c)
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    pit_bids=[]
    for i in range({p.n_pit}):
        x=(i%6-2.5)*{p.pit_r}*2.2; y=(i//6%6-2.5)*{p.pit_r}*2.2; z=0.15+{p.pit_r}+(i//36)*{p.pit_r}*2.2
        s=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.pit_r},physicsClientId=c)
        bid=pb.createMultiBody(0.2,s,-1,[x,y,z],[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction={p.pit_friction},restitution={p.pit_restitution},physicsClientId=c)
        pit_bids.append(bid)
    for _ in range(80): pb.stepSimulation(physicsClientId=c)
    bids=[]
    for i,bid in enumerate(pit_bids):
        col=[__import__('random').random() for _ in range(3)]+[1.0]
        _add_sphere(sc,f"p{{i}}",nodes,{p.pit_r},col); bids.append((f"p{{i}}",bid))
    s=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.heavy_r},physicsClientId=c)
    hb=pb.createMultiBody({p.heavy_mass},s,-1,[0,0,{p.heavy_drop_z}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(hb,-1,lateralFriction=0.4,restitution=0.3,physicsClientId=c)
    _add_sphere(sc,"hv",nodes,{p.heavy_r},[0.85,0.25,0.15,1.0]); bids.append(("hv",hb))
    _add_box(sc,"fl",nodes,[2.5,2.5,0.02],[0.4,0.4,0.42,1.0]); _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    frames=[]
    for _ in range(150):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])""",
    obs_fn='f"Heavy ball (r={p.heavy_r:.3f} m, m={p.heavy_mass:.1f} kg) dropped from z={p.heavy_drop_z:.2f} m into {p.n_pit} small balls."',
    law_name="Impact dynamics in granular media",
    law_stmt="Heavy impactor penetrates granular bed; depth scales as d ∝ (m·v²)^(1/3).",
    law_fmt="d_{pen} \\propto \\left(\\frac{{m v^2}}{{\\rho g}}\\right)^{{1/3}}",
    assumptions=["Pit balls treated as independent rigid spheres",
                 "No cohesion between pit balls",
                 "Container walls are rigid and frictionless"],
    derivation=['Heavy ball free-falls: v_impact = sqrt(2g·h).',
                'On impact, momentum transferred to nearby pit balls.',
                'Crater forms; depth and width scale with impact energy.'],
    expected=[f'Impact velocity ≈ {(2*9.81*p.heavy_drop_z)**0.5:.1f} m/s.',
              'Pit balls scatter outward from impact zone.',
              'Heavy ball settles into pit after multiple bounces.'],
    param_keys='["n_pit","pit_r","heavy_r","heavy_mass","heavy_drop_z","pit_friction"]')


# ═══════════════════════════════════════════════════════════════════════════════
# 08 spinning_top_precession
# ═══════════════════════════════════════════════════════════════════════════════
make_generic(
    name="spinning_top_precession",
    docstring="spinning_top_precession — gyroscope precessing under gravity.",
    cam_eye=(2.5, -2.5, 2.0), cam_target=(0.0, 0.0, 0.3), n_frames=150,
    category="rigid_body_free_dynamics",
    params_fields="""\
    seed: int
    radius: float
    height: float
    mass:   float
    spin:   float    # initial angular velocity around body Z (rad/s)
    tilt:   float    # initial tilt from vertical (deg)
    friction: float
    color: List[float]""",
    random_body="""\
    return Params(seed=seed,
                  radius=random.uniform(0.07, 0.14),
                  height=random.uniform(0.22, 0.42),
                  mass=random.uniform(0.05, 0.30),
                  spin=random.uniform(18.0, 45.0),
                  tilt=random.uniform(5.0, 18.0),
                  friction=random.uniform(0.5, 0.9),
                  color=[random.random(), random.random(), random.random(), 1.0])""",
    scene_body="""\
    p = random_params(seed)
    import pybullet as pb2
    phys.add_plane(friction=p.friction)
    ren.add_plane_mesh("floor", 3.0, muted_grey())

    tilt_r = math.radians(p.tilt)
    orn = pb2.getQuaternionFromEuler([tilt_r, 0, 0])
    tip_z = p.radius * 0.2   # top tip rests near z=0
    pos = [0.0, 0.0, tip_z + p.height / 2]

    # cylinder body
    top_id = phys.add_cylinder(p.radius, p.height, pos, orn=orn,
                               mass=p.mass, friction=p.friction, restitution=0.1)
    # initial spin around body axis (approx world Z)
    pb2.resetBaseVelocity(top_id, [0, 0, 0], [0, 0, p.spin],
                          physicsClientId=phys.client)

    ren.add_cylinder("top", p.radius, p.height, p.color, metallic=0.3, roughness=0.2)
    _dyn.append(("top", top_id))""",
    standalone_body="""\
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    tilt_r=math.radians({p.tilt})
    orn=pb.getQuaternionFromEuler([tilt_r,0,0])
    pos=[0,0,{p.radius*0.2+p.height/2}]
    s=pb.createCollisionShape(pb.GEOM_CYLINDER,radius={p.radius},height={p.height},physicsClientId=c)
    tid=pb.createMultiBody({p.mass},s,-1,pos,orn,physicsClientId=c)
    pb.changeDynamics(tid,-1,lateralFriction={p.friction},restitution=0.1,physicsClientId=c)
    pb.resetBaseVelocity(tid,[0,0,0],[0,0,{p.spin}],physicsClientId=c)
    _add_cylinder(sc,"top",nodes,{p.radius},{p.height},{p.color})
    _add_box(sc,"fl",nodes,[1.5,1.5,0.02],muted_grey()); _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    bids=[("top",tid)]; frames=[]
    for _ in range(150):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])""",
    obs_fn='f"Spinning top (r={p.radius:.3f} m, h={p.height:.3f} m, m={p.mass:.3f} kg) at {p.spin:.1f} rad/s, tilted {p.tilt:.1f}°."',
    law_name="Gyroscopic precession — Euler equations",
    law_stmt="A tilted spinning top precesses at Ω_p = M·g·d / (I_spin·ω_spin).",
    law_fmt="\\Omega_p = \\frac{{Mgd}}{{I_z\\omega_z}}",
    assumptions=["Top modelled as solid cylinder: I_z = mr²/2, I_x = m(3r²+h²)/12",
                 "Nutation neglected for high spin rates",
                 "Tip contact approximated by small sphere"],
    derivation=[
        'Torque from gravity: τ = r_cm × (mg ẑ).',
        'Precession angular velocity: Ω_p = τ / (I_z·ω_z).',
        f'Estimated Ω_p ≈ {p.mass*9.81*(p.height/2)*math.sin(math.radians(p.tilt)) / (0.5*p.mass*p.radius**2*p.spin):.3f} rad/s.',
        'As ω_z decreases (friction), Ω_p increases and top eventually falls.'],
    expected=[f'Top precesses around vertical axis at ≈{p.mass*9.81*(p.height/2)*math.sin(math.radians(p.tilt))/(0.5*p.mass*p.radius**2*p.spin):.3f} rad/s.',
              'Precession period visible in video.',
              'Top gradually loses spin energy and tilts further.'],
    param_keys='["radius","height","mass","spin","tilt","friction"]')


# ═══════════════════════════════════════════════════════════════════════════════
# 09 jenga_pull
# ═══════════════════════════════════════════════════════════════════════════════
make_generic(
    name="jenga_pull",
    docstring="jenga_pull — block extracted from a Jenga-style tower.",
    cam_eye=(4.5, -4.5, 2.0), cam_target=(0.0, 0.0, 1.1), n_frames=150,
    category="rigid_body_free_dynamics",
    params_fields="""\
    seed: int
    n_layers: int
    pull_layer: int
    pull_speed: float
    block_mass: float
    friction: float
    restitution: float
    color_a: List[float]
    color_b: List[float]""",
    random_body="""\
    nl = random.randint(14, 22)
    return Params(seed=seed, n_layers=nl,
                  pull_layer=random.randint(4, nl-4),
                  pull_speed=random.uniform(0.8, 2.5),
                  block_mass=random.uniform(0.08, 0.30),
                  friction=random.uniform(0.35, 0.70),
                  restitution=random.uniform(0.05, 0.30),
                  color_a=[random.uniform(0.6,0.9),random.uniform(0.5,0.8),random.uniform(0.3,0.6),1.0],
                  color_b=[random.uniform(0.3,0.6),random.uniform(0.4,0.7),random.uniform(0.6,0.9),1.0])""",
    scene_body="""\
    import pybullet as pb2
    p = random_params(seed)
    phys.add_plane(friction=p.friction)
    ren.add_plane_mesh("floor", 5.0, muted_grey())

    # Jenga block: 0.025 × 0.075 × 0.25 m
    bw, bd, bl = 0.0265, 0.0795, 0.2540
    all_bids = []
    for layer in range(p.n_layers):
        z = bw + layer * bw * 2
        col = p.color_a if layer % 2 == 0 else p.color_b
        if layer % 2 == 0:  # blocks along X
            for j in range(3):
                x = (j - 1) * bd * 1.05
                bid = phys.add_box([bd/2, bl/2, bw], [x, 0, z],
                                   mass=p.block_mass, friction=p.friction,
                                   restitution=p.restitution)
                nm = f"b{layer}_{j}"
                ren.add_box(nm, [bd/2, bl/2, bw], col)
                all_bids.append((nm, bid, layer, j))
        else:               # blocks along Y
            for j in range(3):
                y = (j - 1) * bd * 1.05
                bid = phys.add_box([bl/2, bd/2, bw], [0, y, z],
                                   mass=p.block_mass, friction=p.friction,
                                   restitution=p.restitution)
                nm = f"b{layer}_{j}"
                ren.add_box(nm, [bl/2, bd/2, bw], col)
                all_bids.append((nm, bid, layer, j))

    # settle 30 frames
    for _ in range(30): phys.step()

    # apply pull velocity to middle block of pull_layer
    pull_bid = None
    for nm, bid, layer, j in all_bids:
        if layer == p.pull_layer and j == 1:
            pull_bid = bid
            break
    if pull_bid is not None:
        if p.pull_layer % 2 == 0:
            pb2.resetBaseVelocity(pull_bid, [p.pull_speed, 0, 0], [0,0,0],
                                  physicsClientId=phys.client)
        else:
            pb2.resetBaseVelocity(pull_bid, [0, p.pull_speed, 0], [0,0,0],
                                  physicsClientId=phys.client)

    for nm, bid, layer, j in all_bids:
        _dyn.append((nm, bid))""",
    standalone_body="""\
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    bw,bd,bl=0.0265,0.0795,0.254; all_bids=[]
    for ly in range({p.n_layers}):
        z=bw+ly*bw*2
        col={p.color_a} if ly%2==0 else {p.color_b}
        if ly%2==0:
            for j in range(3):
                x=(j-1)*bd*1.05
                s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[bd/2,bl/2,bw],physicsClientId=c)
                bid=pb.createMultiBody({p.block_mass},s,-1,[x,0,z],[0,0,0,1],physicsClientId=c)
                pb.changeDynamics(bid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
                nm=f"b_{{ly}}_{{j}}"; _add_box(sc,nm,nodes,[bd/2,bl/2,bw],col); all_bids.append((nm,bid,ly,j))
        else:
            for j in range(3):
                y=(j-1)*bd*1.05
                s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[bl/2,bd/2,bw],physicsClientId=c)
                bid=pb.createMultiBody({p.block_mass},s,-1,[0,y,z],[0,0,0,1],physicsClientId=c)
                pb.changeDynamics(bid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
                nm=f"b_{{ly}}_{{j}}"; _add_box(sc,nm,nodes,[bl/2,bd/2,bw],col); all_bids.append((nm,bid,ly,j))
    for _ in range(30): pb.stepSimulation(physicsClientId=c)
    for nm,bid,ly,j in all_bids:
        if ly=={p.pull_layer} and j==1:
            vx={p.pull_speed} if ly%2==0 else 0; vy=0 if ly%2==0 else {p.pull_speed}
            pb.resetBaseVelocity(bid,[vx,vy,0],[0,0,0],physicsClientId=c)
    frames=[]
    for _ in range(150):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid,ly,j in all_bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])""",
    obs_fn='f"Jenga tower ({p.n_layers} layers, μ={p.friction:.2f}); block at layer {p.pull_layer} pulled at {p.pull_speed:.2f} m/s."',
    law_name="Static friction limit and structural instability",
    law_stmt="Block can be extracted without toppling if pull force < static friction of above blocks.",
    law_fmt="F_{pull} < \\mu \\cdot N_{above}  \\Rightarrow  safe extraction",
    assumptions=["Blocks are rigid rectangular prisms",
                 "Friction is Coulomb (static and kinetic)",
                 "Tower treated as discrete stack; no elastic deformation"],
    derivation=['Weight above pull_layer: W_above = n_above × mass × g.',
                'Maximum static friction: F_s = μ × W_above.',
                f'Pull speed {p.pull_speed:.2f} m/s applied; whether tower survives depends on μ and mass above.'],
    expected=[f'Block at layer {p.pull_layer} extracted horizontally.',
              'Tower may or may not topple depending on friction.',
              f'High friction (μ={p.friction:.2f}) means more stable extraction.'],
    param_keys='["n_layers","pull_layer","pull_speed","block_mass","friction","restitution"]')


# ═══════════════════════════════════════════════════════════════════════════════
# 10 funnel_sorting
# ═══════════════════════════════════════════════════════════════════════════════
make_generic(
    name="funnel_sorting",
    docstring="funnel_sorting — spheres of two sizes, small ones pass through funnel.",
    cam_eye=(4.0, -4.0, 3.5), cam_target=(0.0, 0.0, 1.2), n_frames=150,
    category="rigid_body_free_dynamics",
    params_fields="""\
    seed: int
    n_small: int
    n_large: int
    r_small: float
    r_large: float
    neck_r:  float   # funnel exit radius (only r_small < neck_r pass)
    mass_small: float
    mass_large: float
    friction: float
    restitution: float""",
    random_body="""\
    rs = random.uniform(0.045, 0.075)
    rl = random.uniform(0.10, 0.17)
    neck = random.uniform(rs * 1.15, rs * 1.60)   # small passes, large doesn't
    return Params(seed=seed,
                  n_small=random.randint(4, 8),
                  n_large=random.randint(3, 6),
                  r_small=rs, r_large=rl, neck_r=neck,
                  mass_small=random.uniform(0.02, 0.08),
                  mass_large=random.uniform(0.10, 0.40),
                  friction=random.uniform(0.25, 0.55),
                  restitution=random.uniform(0.25, 0.60))""",
    scene_body="""\
    p = random_params(seed)
    phys.add_plane(friction=p.friction)
    ren.add_plane_mesh("floor", 6.0, muted_grey())

    # funnel: 4 angled walls forming inverted pyramid with neck_r opening
    nr = p.neck_r
    for i, (he, pos) in enumerate([
        ([0.80, 0.04, 0.70], [-nr-0.40, 0, 1.80]),
        ([0.80, 0.04, 0.70], [ nr+0.40, 0, 1.80]),
        ([0.04, 0.80, 0.70], [0, -nr-0.40, 1.80]),
        ([0.04, 0.80, 0.70], [0,  nr+0.40, 1.80])]):
        phys.add_box(he, pos, mass=0)
        ren.add_box(f"fw{i}", he, [0.50, 0.50, 0.55, 1.0])
        ren.set_static_pose(f"fw{i}", pos)

    # small balls (green)
    for i in range(p.n_small):
        x = (i % 3 - 1) * p.r_small * 2.5
        y = (i // 3) * p.r_small * 2.5
        bid = phys.add_sphere(p.r_small, [x, y, 2.8 + i * p.r_small * 0.5],
                              mass=p.mass_small, friction=p.friction,
                              restitution=p.restitution)
        ren.add_sphere(f"sm{i}", p.r_small, [0.2, 0.85, 0.3, 1.0])
        _dyn.append((f"sm{i}", bid))

    # large balls (red)
    for i in range(p.n_large):
        x = (i % 2 - 0.5) * p.r_large * 2.5
        bid = phys.add_sphere(p.r_large, [x, -0.3, 3.5 + i * p.r_large * 0.5],
                              mass=p.mass_large, friction=p.friction,
                              restitution=p.restitution)
        ren.add_sphere(f"lg{i}", p.r_large, [0.85, 0.2, 0.2, 1.0])
        _dyn.append((f"lg{i}", bid))""",
    standalone_body="""\
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    nr={p.neck_r}
    for he,pos in [([0.80,0.04,0.70],[-nr-0.40,0,1.80]),([0.80,0.04,0.70],[nr+0.40,0,1.80]),
                   ([0.04,0.80,0.70],[0,-nr-0.40,1.80]),([0.04,0.80,0.70],[0,nr+0.40,1.80])]:
        s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=he,physicsClientId=c)
        pb.createMultiBody(0,s,-1,pos,[0,0,0,1],physicsClientId=c)
    bids=[]
    for i in range({p.n_small}):
        x=(i%3-1)*{p.r_small}*2.5; y=(i//3)*{p.r_small}*2.5; z=2.8+i*{p.r_small}*0.5
        s=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.r_small},physicsClientId=c)
        bid=pb.createMultiBody({p.mass_small},s,-1,[x,y,z],[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
        _add_sphere(sc,f"sm{{i}}",nodes,{p.r_small},[0.2,0.85,0.3,1.0]); bids.append((f"sm{{i}}",bid))
    for i in range({p.n_large}):
        x=(i%2-0.5)*{p.r_large}*2.5; z=3.5+i*{p.r_large}*0.5
        s=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.r_large},physicsClientId=c)
        bid=pb.createMultiBody({p.mass_large},s,-1,[x,-0.3,z],[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
        _add_sphere(sc,f"lg{{i}}",nodes,{p.r_large},[0.85,0.2,0.2,1.0]); bids.append((f"lg{{i}}",bid))
    _add_box(sc,"fl",nodes,[3,3,0.02],[0.4,0.4,0.43,1.0]); _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    frames=[]
    for _ in range(150):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])""",
    obs_fn='f"{p.n_small} small (r={p.r_small:.3f} m) + {p.n_large} large (r={p.r_large:.3f} m) balls; neck r={p.neck_r:.3f} m."',
    law_name="Geometric sorting by constriction (granular segregation)",
    law_stmt="A sphere of radius r passes through a circular opening of radius R iff r < R.",
    law_fmt="\\text{{pass}} \\iff r_{ball} < r_{neck}",
    assumptions=["Balls are rigid spheres",
                 "Funnel walls are rigid and smooth",
                 "No horizontal velocity imparted at entry"],
    derivation=[f'Small balls: r={p.r_small:.3f} m < neck_r={p.neck_r:.3f} m → pass through.',
                f'Large balls: r={p.r_large:.3f} m > neck_r={p.neck_r:.3f} m → blocked.',
                'Sorted automatically by geometry alone.'],
    expected=[f'All {p.n_small} small balls (green) fall through funnel.',
              f'All {p.n_large} large balls (red) rest on funnel walls.',
              'Clear separation visible in video.'],
    param_keys='["n_small","n_large","r_small","r_large","neck_r","mass_small","mass_large"]')


print("\\n✓ Generated experiment files 03–10")
print("  Run generate_dataset_kubric.py to produce the dataset.")
''')

print("Generator script written. Running it now...")
