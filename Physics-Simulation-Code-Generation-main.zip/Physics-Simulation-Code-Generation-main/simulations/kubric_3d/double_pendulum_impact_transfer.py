"""double_pendulum_impact_transfer — proper double pendulum (point-to-point
joints) whose second bob visibly strikes a stationary block."""
from __future__ import annotations
import math, random
from dataclasses import asdict

import numpy as np
import pybullet as pb

from ._advanced_life_scenes import _COMMON_ASSUMPTIONS, _COMMON_DERIV, _COMMON_EQ, _SPEC
from ._real_life_scenes import (
    CAM_DEFAULT,
    N_FRAMES,
    Params,
    TARGET_DEFAULT,
    _base_summary,
    _box,
    _capsule,
    _sphere,
    _visual,
)

EXPERIMENT = "double_pendulum_impact_transfer"

ANCHOR        = (0.0, 0.0, 1.55)
L1            = 0.55
L2            = 0.50
BOB1_R        = 0.13
BOB2_R        = 0.10
BOB1_M        = 2.5
BOB2_M        = 1.0
TARGET_HALF   = (0.10, 0.18, 0.43)
TARGET_POS    = (0.55, 0.0, 0.43)
TARGET_M      = 0.5
ROD_RADIUS    = 0.014
ROD_COLOR     = [0.94, 0.74, 0.18, 1.0]
ANCHOR_COLOR  = [0.45, 0.45, 0.50, 1.0]
BOB1_COLOR    = [0.16, 0.42, 0.86, 1.0]
BOB2_COLOR    = [0.20, 0.72, 0.34, 1.0]
TARGET_COLOR  = [0.85, 0.18, 0.14, 1.0]
FLOOR_SIZE    = 7.0


def _initial_positions():
    bob1 = [ANCHOR[0], ANCHOR[1], ANCHOR[2] - L1]
    bob2 = [ANCHOR[0], ANCHOR[1], ANCHOR[2] - L1 - L2]
    return bob1, bob2


def _initial_bob1_vel(seed: int):
    rng = random.Random(seed + abs(hash(EXPERIMENT)) % 100000)
    speed = rng.uniform(2.7, 3.3)
    sign = 1.0 if rng.random() > 0.5 else -1.0
    return [sign * speed, 0.0, 0.0]


def random_params(seed: int) -> Params:
    bob1_pos, bob2_pos = _initial_positions()
    vel = _initial_bob1_vel(seed)
    target_pos = list(TARGET_POS)
    if vel[0] < 0:
        target_pos[0] = -target_pos[0]
    rod1_mid = [(ANCHOR[0] + bob1_pos[0]) * 0.5,
                (ANCHOR[1] + bob1_pos[1]) * 0.5,
                (ANCHOR[2] + bob1_pos[2]) * 0.5]
    rod2_mid = [(bob1_pos[0] + bob2_pos[0]) * 0.5,
                (bob1_pos[1] + bob2_pos[1]) * 0.5,
                (bob1_pos[2] + bob2_pos[2]) * 0.5]
    objects = [
        _visual(_sphere("anchor", 0.045, list(ANCHOR), 0, ANCHOR_COLOR)),
        _sphere("bob1", BOB1_R, bob1_pos, BOB1_M, BOB1_COLOR,
                vel=vel, friction=0.4, restitution=0.5),
        _sphere("bob2", BOB2_R, bob2_pos, BOB2_M, BOB2_COLOR,
                friction=0.4, restitution=0.6),
        _box("target", list(TARGET_HALF), target_pos, TARGET_M, TARGET_COLOR,
             friction=0.45, restitution=0.4),
        _visual(_capsule("rod1", ROD_RADIUS, L1, rod1_mid, 0, ROD_COLOR)),
        _visual(_capsule("rod2", ROD_RADIUS, L2, rod2_mid, 0, ROD_COLOR)),
    ]
    summary = {
        "anchor_world": list(ANCHOR),
        "rod1_length_m": L1,
        "rod2_length_m": L2,
        "bob1_mass_kg": BOB1_M,
        "bob2_mass_kg": BOB2_M,
        "target_mass_kg": TARGET_M,
        "bob1_initial_vel_mps": vel,
        "joints": "JOINT_POINT2POINT (world-bob1) and (bob1-bob2)",
        "impact_target": "second bob hits target block during swing",
    }
    return Params(seed=seed, experiment=EXPERIMENT, objects=objects,
                  camera_eye=CAM_DEFAULT, camera_target=TARGET_DEFAULT,
                  floor_size=FLOOR_SIZE, summary=summary)


def _cot(params: Params):
    from simulations.kubric_3d._base import build_cot, param_entry
    category, law, formula = _SPEC[EXPERIMENT]
    entries = {k: param_entry(v, "various", k)
               for k, v in _base_summary(params).items()}
    return build_cot(
        EXPERIMENT, category, params.seed,
        f"{EXPERIMENT}: rigid double pendulum joined by point-to-point "
        "constraints; the second bob swings into and impacts a stationary "
        "block of lower mass.",
        law,
        f"{law}; PyBullet point-to-point constraints maintain the rod lengths "
        "and contacts/impulses are resolved numerically.",
        formula, _COMMON_ASSUMPTIONS,
        ["position r (m)", "velocity v (m/s)", "orientation q",
         "angular velocity omega (rad/s)"],
        _COMMON_EQ,
        "j_n=-(1+e)(v_rel dot n)/m_eff; |j_t|<=mu|j_n|",
        _COMMON_DERIV,
        ["First bob swings under gravity from initial sideways velocity.",
         "Rod constraints transmit force to second bob.",
         "Second bob accelerates and strikes the target block.",
         "Block slides with Coulomb friction; bobs continue oscillating."],
        entries)


def make_standalone_code(params: Params) -> str:
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    bob1_pos, bob2_pos = _initial_positions()
    vel = list(params.summary["bob1_initial_vel_mps"])
    target_pos = list(TARGET_POS)
    if vel[0] < 0:
        target_pos[0] = -target_pos[0]
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f'''
# {EXPERIMENT}  seed={params.seed}
N_FRAMES={N_FRAMES}; CAM_EYE={repr(params.camera_eye)}; CAM_TARGET={repr(params.camera_target)}
ANCHOR={list(ANCHOR)}; L1={L1}; L2={L2}
BOB1_R={BOB1_R}; BOB2_R={BOB2_R}; BOB1_M={BOB1_M}; BOB2_M={BOB2_M}
BOB1_POS={bob1_pos}; BOB2_POS={bob2_pos}; BOB1_VEL={vel}
TARGET_POS={target_pos}; TARGET_HALF={list(TARGET_HALF)}; TARGET_M={TARGET_M}
ROD_R={ROD_RADIUS}; ROD_COL={ROD_COLOR}
BOB1_COL={BOB1_COLOR}; BOB2_COL={BOB2_COLOR}
TARGET_COL={TARGET_COLOR}; ANCHOR_COL={ANCHOR_COLOR}
FLOOR={FLOOR_SIZE}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    p.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"floor",nodes,[FLOOR/2,FLOOR/2,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["floor"],[0,0,-0.02],[0,0,0,1])
    s1=p.createCollisionShape(p.GEOM_SPHERE,radius=BOB1_R,physicsClientId=c)
    bob1=p.createMultiBody(BOB1_M,s1,-1,BOB1_POS,[0,0,0,1],physicsClientId=c)
    p.changeDynamics(bob1,-1,lateralFriction=0.4,restitution=0.5,
        linearDamping=0.01,angularDamping=0.05,physicsClientId=c)
    p.resetBaseVelocity(bob1,BOB1_VEL,[0,0,0],physicsClientId=c)
    s2=p.createCollisionShape(p.GEOM_SPHERE,radius=BOB2_R,physicsClientId=c)
    bob2=p.createMultiBody(BOB2_M,s2,-1,BOB2_POS,[0,0,0,1],physicsClientId=c)
    p.changeDynamics(bob2,-1,lateralFriction=0.4,restitution=0.6,
        linearDamping=0.01,angularDamping=0.05,physicsClientId=c)
    sb=p.createCollisionShape(p.GEOM_BOX,halfExtents=TARGET_HALF,physicsClientId=c)
    box=p.createMultiBody(TARGET_M,sb,-1,TARGET_POS,[0,0,0,1],physicsClientId=c)
    p.changeDynamics(box,-1,lateralFriction=0.45,restitution=0.4,physicsClientId=c)
    cid1=p.createConstraint(bob1,-1,-1,-1,p.JOINT_POINT2POINT,[0,0,1],
        [0,0,L1],ANCHOR,physicsClientId=c)
    p.changeConstraint(cid1,maxForce=50000,physicsClientId=c)
    cid2=p.createConstraint(bob2,-1,bob1,-1,p.JOINT_POINT2POINT,[0,0,1],
        [0,0,L2],[0,0,0],physicsClientId=c)
    p.changeConstraint(cid2,maxForce=50000,physicsClientId=c)
    _add_sphere(sc,"anchor",nodes,0.045,ANCHOR_COL); _set_pose(sc,nodes["anchor"],ANCHOR,[0,0,0,1])
    _add_sphere(sc,"bob1",nodes,BOB1_R,BOB1_COL)
    _add_sphere(sc,"bob2",nodes,BOB2_R,BOB2_COL)
    _add_box(sc,"target",nodes,TARGET_HALF,TARGET_COL)
    bodies=[("bob1",bob1),("bob2",bob2),("target",box)]
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): p.stepSimulation(physicsClientId=c)
        for nm,bid in bodies:
            pp,oo=p.getBasePositionAndOrientation(bid,physicsClientId=c); _set_pose(sc,nodes[nm],pp,oo)
        b1p,_=p.getBasePositionAndOrientation(bob1,physicsClientId=c)
        b2p,_=p.getBasePositionAndOrientation(bob2,physicsClientId=c)
        _update_string(sc,nodes,"rod1",ANCHOR,list(b1p),radius=ROD_R,color=ROD_COL)
        _update_string(sc,nodes,"rod2",list(b1p),list(b2p),radius=ROD_R,color=ROD_COL)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); p.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
'''


def generate_sample(seed: int, out_dir: str):
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample,
    )
    params = random_params(seed)
    bob1_pos, bob2_pos = _initial_positions()
    vel = list(params.summary["bob1_initial_vel_mps"])
    target_pos = list(TARGET_POS)
    if vel[0] < 0:
        target_pos[0] = -target_pos[0]

    phys = Physics()
    ren = Renderer(params.camera_eye, params.camera_target)
    phys.add_plane(friction=0.55)
    ren.add_plane_mesh("floor", params.floor_size, [0.42, 0.42, 0.45, 1.0])

    bob1_id = phys.add_sphere(BOB1_R, bob1_pos, mass=BOB1_M,
                              friction=0.4, restitution=0.5,
                              vel=vel, lin_damp=0.01, ang_damp=0.05)
    bob2_id = phys.add_sphere(BOB2_R, bob2_pos, mass=BOB2_M,
                              friction=0.4, restitution=0.6,
                              lin_damp=0.01, ang_damp=0.05)
    box_id = phys.add_box(list(TARGET_HALF), target_pos, mass=TARGET_M,
                          friction=0.45, restitution=0.4)

    ren.add_sphere("anchor", 0.045, ANCHOR_COLOR)
    ren.set_static_pose("anchor", list(ANCHOR), (0, 0, 0, 1))
    ren.add_sphere("bob1", BOB1_R, BOB1_COLOR)
    ren.add_sphere("bob2", BOB2_R, BOB2_COLOR)
    ren.add_box("target", list(TARGET_HALF), TARGET_COLOR)

    phys.create_constraint(
        bob1_id, -1, -1, -1,
        pb.JOINT_POINT2POINT, [0, 0, 1],
        [0, 0, L1], list(ANCHOR),
        max_force=50000.0)
    phys.create_constraint(
        bob2_id, -1, bob1_id, -1,
        pb.JOINT_POINT2POINT, [0, 0, 1],
        [0, 0, L2], [0, 0, 0],
        max_force=50000.0)

    dyn = [("bob1", bob1_id), ("bob2", bob2_id), ("target", box_id)]

    def extra_sync_fn(phys, ren, fi):
        b1, _ = phys.get_pose(bob1_id)
        b2, _ = phys.get_pose(bob2_id)
        ren.update_string("rod1", list(ANCHOR), b1.tolist(),
                          radius=ROD_RADIUS, color=ROD_COLOR)
        ren.update_string("rod2", b1.tolist(), b2.tolist(),
                          radius=ROD_RADIUS, color=ROD_COLOR)

    frames = run_loop(phys, ren, dyn, N_FRAMES, extra_sync_fn=extra_sync_fn)
    data = asdict(params); data.update(_base_summary(params))
    save_sample(out_dir, data, _cot(params), make_standalone_code(params), frames)
    phys.close(); ren.close()


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_double_pendulum_impact_transfer")
    print("OK")
