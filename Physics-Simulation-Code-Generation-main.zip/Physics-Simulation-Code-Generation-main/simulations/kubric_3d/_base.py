"""
_base.py — shared infrastructure for all kubric_3d experiments.

Physics:  PyBullet (DIRECT/headless, 240 Hz, same engine as Kubric)
Renderer: pyrender + trimesh (EGL-accelerated OpenGL, PBR materials)
Output:   480×480 MP4 @ 30 fps, params.json, cot.json, simulation_code.py
"""

from __future__ import annotations
import os, json, math, random
from typing import List, Tuple, Optional, Dict, Any

# Headless OpenGL must be selected before importing pyrender internals.
if "PYOPENGL_PLATFORM" not in os.environ and not os.environ.get("DISPLAY"):
    os.environ["PYOPENGL_PLATFORM"] = "egl"

import numpy as np
import pybullet as p
pb = p
import pybullet_data
import trimesh
import pyrender
import imageio

# ── Global constants ──────────────────────────────────────────────────────────
RESOLUTION  = (480, 480)
FPS         = 30
STEP_RATE   = 240        # physics Hz; 8 substeps per frame
G           = 9.81       # m/s²


def metadata_only() -> bool:
    return os.environ.get("KUBRIC_METADATA_ONLY") == "1"


class _NoopScene:
    def add(self, *args, **kwargs):
        return object()

    def set_pose(self, *args, **kwargs):
        return None

    def remove_node(self, *args, **kwargs):
        return None


class _NoopRenderer:
    def render(self, *args, **kwargs):
        return np.zeros((1, 1, 4), dtype=np.uint8), None

    def delete(self):
        return None

# ══════════════════════════════════════════════════════════════════════════════
# Colour utilities
# ══════════════════════════════════════════════════════════════════════════════

def hsv_to_rgb(h: float, s: float, v: float) -> Tuple[float, float, float]:
    hi = int(h * 6) % 6
    f  = h * 6 - int(h * 6)
    p_ = v * (1 - s);  q = v * (1 - f*s);  t = v * (1-(1-f)*s)
    return [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]

def random_hue_color(s: float = 0.85, v: float = 0.90) -> List[float]:
    r, g, b = hsv_to_rgb(random.random(), s, v)
    return [r, g, b, 1.0]

def muted_grey(lo: float = 0.30, hi: float = 0.55) -> List[float]:
    c = random.uniform(lo, hi)
    return [c, c + random.uniform(-0.03, 0.03), c + random.uniform(-0.03, 0.03), 1.0]

def floor_color() -> List[float]:
    return muted_grey(0.38, 0.52)

# ══════════════════════════════════════════════════════════════════════════════
# Physics wrapper
# ══════════════════════════════════════════════════════════════════════════════

class Physics:
    """
    Thin PyBullet wrapper mirroring Kubric's simulator config.
    10× substeps (240 Hz physics / 24 fps render) for stable contacts.
    """

    def __init__(self, gravity: Tuple = (0, 0, -G)):
        self.client = p.connect(p.DIRECT)
        p.setGravity(*gravity, physicsClientId=self.client)
        p.setAdditionalSearchPath(
            pybullet_data.getDataPath(), physicsClientId=self.client)
        p.setPhysicsEngineParameter(
            fixedTimeStep                   = 1.0 / STEP_RATE,
            restitutionVelocityThreshold    = 0.2,
            useSplitImpulse                 = 1,
            splitImpulsePenetrationThreshold= -0.02,
            contactSlop                     = 0.0,
            physicsClientId                 = self.client,
        )

    # ── primitives ────────────────────────────────────────────────────────────

    def add_plane(self, z: float = 0.0,
                  friction: float = 0.8, restitution: float = 0.5) -> int:
        bid = p.loadURDF("plane.urdf", [0, 0, z],
                         physicsClientId=self.client)
        p.changeDynamics(bid, -1,
                         lateralFriction=friction, restitution=restitution,
                         physicsClientId=self.client)
        return bid

    def add_sphere(self, radius, pos, mass=1.0, friction=0.5, restitution=0.7,
                   vel=(0,0,0), ang_vel=(0,0,0),
                   lin_damp=0.01, ang_damp=0.02) -> int:
        shape = p.createCollisionShape(p.GEOM_SPHERE, radius=radius,
                                       physicsClientId=self.client)
        bid   = p.createMultiBody(mass, shape, -1, pos, [0,0,0,1],
                                   physicsClientId=self.client)
        p.changeDynamics(bid, -1,
                         lateralFriction=friction, restitution=restitution,
                         linearDamping=lin_damp, angularDamping=ang_damp,
                         physicsClientId=self.client)
        if any(v != 0 for v in vel) or any(v != 0 for v in ang_vel):
            p.resetBaseVelocity(bid, vel, ang_vel, physicsClientId=self.client)
        return bid

    def add_box(self, half_ext, pos, orn=(0,0,0,1), mass=1.0,
                friction=0.5, restitution=0.5,
                vel=(0,0,0), ang_vel=(0,0,0),
                lin_damp=0.01, ang_damp=0.02) -> int:
        shape = p.createCollisionShape(p.GEOM_BOX, halfExtents=half_ext,
                                       physicsClientId=self.client)
        bid   = p.createMultiBody(mass, shape, -1, pos, orn,
                                   physicsClientId=self.client)
        p.changeDynamics(bid, -1,
                         lateralFriction=friction, restitution=restitution,
                         linearDamping=lin_damp, angularDamping=ang_damp,
                         physicsClientId=self.client)
        if any(v != 0 for v in vel) or any(v != 0 for v in ang_vel):
            p.resetBaseVelocity(bid, vel, ang_vel, physicsClientId=self.client)
        return bid

    def add_cylinder(self, radius, height, pos, orn=(0,0,0,1), mass=1.0,
                     friction=0.5, restitution=0.5,
                     vel=(0,0,0), ang_vel=(0,0,0)) -> int:
        shape = p.createCollisionShape(p.GEOM_CYLINDER, radius=radius,
                                       height=height,
                                       physicsClientId=self.client)
        bid   = p.createMultiBody(mass, shape, -1, pos, orn,
                                   physicsClientId=self.client)
        p.changeDynamics(bid, -1,
                         lateralFriction=friction, restitution=restitution,
                         physicsClientId=self.client)
        if any(v != 0 for v in vel) or any(v != 0 for v in ang_vel):
            p.resetBaseVelocity(bid, vel, ang_vel, physicsClientId=self.client)
        return bid

    def add_capsule(self, radius, height, pos, orn=(0,0,0,1), mass=1.0,
                    friction=0.5, restitution=0.5,
                    vel=(0,0,0), ang_vel=(0,0,0),
                    lin_damp=0.01, ang_damp=0.02) -> int:
        shape = p.createCollisionShape(p.GEOM_CAPSULE, radius=radius,
                                       height=height,
                                       physicsClientId=self.client)
        bid   = p.createMultiBody(mass, shape, -1, pos, orn,
                                   physicsClientId=self.client)
        p.changeDynamics(bid, -1,
                         lateralFriction=friction, restitution=restitution,
                         linearDamping=lin_damp, angularDamping=ang_damp,
                         physicsClientId=self.client)
        if any(v != 0 for v in vel) or any(v != 0 for v in ang_vel):
            p.resetBaseVelocity(bid, vel, ang_vel, physicsClientId=self.client)
        return bid

    def load_urdf(self, filename: str, pos=(0,0,0), orn=(0,0,0,1),
                  fixed: bool = False, scale: float = 1.0) -> int:
        return p.loadURDF(filename, pos, orn,
                          useFixedBase=fixed,
                          globalScaling=scale,
                          physicsClientId=self.client)

    # ── constraints / chains ──────────────────────────────────────────────────

    def create_constraint(self, body_a, link_a, body_b, link_b,
                          joint_type, joint_axis,
                          parent_pos, child_pos,
                          parent_orn=(0,0,0,1), child_orn=(0,0,0,1),
                          max_force: float = 500.0) -> int:
        cid = p.createConstraint(
            body_a, link_a, body_b, link_b,
            joint_type, joint_axis,
            parent_pos, child_pos,
            parent_orn, child_orn,
            physicsClientId=self.client)
        p.changeConstraint(cid, maxForce=max_force,
                           physicsClientId=self.client)
        return cid

    def create_chain(self, n_links: int, link_radius: float,
                     link_half_len: float, start_pos,
                     mass_per_link: float = 0.1,
                     friction: float = 0.5,
                     restitution: float = 0.4,
                     max_force: float = 200.0) -> List[int]:
        """
        Build a rope/chain from n_links capsules connected by JOINT_POINT2POINT.
        Capsules hang downward from start_pos.
        """
        links: List[int] = []
        pos = list(start_pos)
        segment = link_half_len * 2 + link_radius * 0.5
        for i in range(n_links):
            bid = self.add_capsule(
                link_radius, link_half_len * 2, pos,
                mass=mass_per_link, friction=friction,
                restitution=restitution, lin_damp=0.05, ang_damp=0.1)
            if links:
                off = link_half_len + link_radius * 0.25
                self.create_constraint(
                    links[-1], -1, bid, -1,
                    p.JOINT_POINT2POINT, [0, 0, 1],
                    [0, 0, -off], [0, 0, off],
                    max_force=max_force)
            links.append(bid)
            pos[2] -= segment
        return links

    def fix_body(self, bid, pos=None) -> int:
        """Pin a body to the world frame at its current or given position."""
        if pos is None:
            pos, _ = self.get_pose(bid)
        cid = p.createConstraint(
            bid, -1, -1, -1,
            p.JOINT_FIXED, [0,0,0],
            [0,0,0], list(pos),
            physicsClientId=self.client)
        return cid

    # ── simulation step ───────────────────────────────────────────────────────

    def step(self):
        p.stepSimulation(physicsClientId=self.client)

    def get_pose(self, bid: int) -> Tuple[np.ndarray, np.ndarray]:
        pos, orn = p.getBasePositionAndOrientation(
            bid, physicsClientId=self.client)
        return np.array(pos), np.array(orn)   # orn = xyzw quaternion

    def get_link_pose(self, bid: int, link: int) -> Tuple[np.ndarray, np.ndarray]:
        state = p.getLinkState(bid, link,
                               computeForwardKinematics=1,
                               physicsClientId=self.client)
        return np.array(state[0]), np.array(state[1])

    def num_joints(self, bid: int) -> int:
        return p.getNumJoints(bid, physicsClientId=self.client)

    def close(self):
        p.disconnect(self.client)


# ══════════════════════════════════════════════════════════════════════════════
# Renderer
# ══════════════════════════════════════════════════════════════════════════════

def _look_at(eye, target, up=(0, 0, 1)) -> np.ndarray:
    eye    = np.array(eye,    dtype=float)
    target = np.array(target, dtype=float)
    up     = np.array(up,     dtype=float)
    fwd    = target - eye
    fwd   /= np.linalg.norm(fwd)
    right  = np.cross(fwd, up)
    if np.linalg.norm(right) < 1e-8:
        right = np.array([1., 0., 0.])
    right /= np.linalg.norm(right)
    up2    = np.cross(right, fwd)
    m      = np.eye(4)
    m[:3, 0] = right;  m[:3, 1] = up2;  m[:3, 2] = -fwd;  m[:3, 3] = eye
    return m


def _quat_to_mat(xyzw) -> np.ndarray:
    x, y, z, w = xyzw
    return np.array([
        [1-2*(y*y+z*z), 2*(x*y-z*w),   2*(x*z+y*w)  ],
        [2*(x*y+z*w),   1-2*(x*x+z*z), 2*(y*z-x*w)  ],
        [2*(x*z-y*w),   2*(y*z+x*w),   1-2*(x*x+y*y)],
    ])


class Renderer:
    """
    pyrender OffscreenRenderer with PBR materials + three-point light rig.
    Replaces Kubric's Blender/Cycles backend; fully pip-installable.
    """

    def __init__(self, cam_eye, cam_target,
                 resolution: Tuple[int, int] = RESOLUTION,
                 cam_up: Tuple = (0, 0, 1)):
        W, H = resolution
        self.W, self.H = W, H
        self._metadata_only = metadata_only()
        self._nodes: Dict[str, Any] = {}
        if self._metadata_only:
            self.renderer = _NoopRenderer()
            self.scene = _NoopScene()
            return
        self.renderer = pyrender.OffscreenRenderer(W, H)
        self.scene    = pyrender.Scene(
            ambient_light=[0.10, 0.10, 0.12, 1.0],
            bg_color=[0.06, 0.06, 0.10, 1.0])
        self._setup_lights()
        self._setup_camera(cam_eye, cam_target, cam_up)

    def _setup_lights(self):
        key  = pyrender.DirectionalLight(color=[1.00, 0.95, 0.88], intensity=5.5)
        fill = pyrender.DirectionalLight(color=[0.50, 0.62, 1.00], intensity=2.0)
        rim  = pyrender.DirectionalLight(color=[0.90, 0.90, 0.90], intensity=0.8)
        self.scene.add(key,  pose=_look_at([-3, -4,  6], [0, 0, 0]))
        self.scene.add(fill, pose=_look_at([ 4,  3,  4], [0, 0, 0]))
        self.scene.add(rim,  pose=_look_at([ 0, -5,  1], [0, 0, 0]))

    def _setup_camera(self, eye, target, up):
        cam = pyrender.PerspectiveCamera(
            yfov=math.pi / 4,
            aspectRatio=self.W / self.H,
            znear=0.05, zfar=300.)
        self.scene.add(cam, pose=_look_at(eye, target, up))

    # ── mesh creation helpers ─────────────────────────────────────────────────

    def _material(self, color, metallic=0.05, roughness=0.50):
        return pyrender.MetallicRoughnessMaterial(
            baseColorFactor=color,
            metallicFactor=metallic,
            roughnessFactor=roughness)

    def _add_mesh(self, name: str, tm: trimesh.Trimesh, color,
                  metallic=0.05, roughness=0.50, smooth=True):
        if self._metadata_only:
            self._nodes[name] = object()
            return
        mat  = self._material(color, metallic, roughness)
        pm   = pyrender.Mesh.from_trimesh(tm, material=mat, smooth=smooth)
        node = self.scene.add(pm, pose=np.eye(4))
        self._nodes[name] = node

    def add_plane_mesh(self, name: str, size: float, color):
        tm = trimesh.creation.box(extents=[size, size, 0.04])
        self._add_mesh(name, tm, color, metallic=0.0, roughness=0.95, smooth=False)

    def add_sphere(self, name: str, radius: float, color,
                   metallic=0.10, roughness=0.30):
        tm = trimesh.creation.icosphere(subdivisions=3, radius=radius)
        self._add_mesh(name, tm, color, metallic, roughness, smooth=True)

    def add_box(self, name: str, half_ext, color,
                metallic=0.05, roughness=0.55):
        tm = trimesh.creation.box(extents=[e * 2 for e in half_ext])
        self._add_mesh(name, tm, color, metallic, roughness, smooth=False)

    def add_cylinder(self, name: str, radius: float, height: float, color,
                     metallic=0.05, roughness=0.50):
        tm = trimesh.creation.cylinder(radius=radius, height=height, sections=32)
        self._add_mesh(name, tm, color, metallic, roughness, smooth=True)

    def add_capsule(self, name: str, radius: float, height: float, color,
                    metallic=0.05, roughness=0.50):
        tm = trimesh.creation.capsule(radius=radius, height=height, count=[8, 8])
        self._add_mesh(name, tm, color, metallic, roughness, smooth=True)

    def add_thin_box(self, name: str, half_ext, color):
        """Alias for flat panels / walls / planks."""
        self.add_box(name, half_ext, color, metallic=0.0, roughness=0.8)

    # ── pose update ──────────────────────────────────────────────────────────

    def set_pose(self, name: str, pos, quat_xyzw):
        if self._metadata_only:
            self._nodes.setdefault(name, object())
            return
        R   = _quat_to_mat(quat_xyzw)
        mat = np.eye(4)
        mat[:3, :3] = R
        mat[:3,  3] = np.array(pos)
        self.scene.set_pose(self._nodes[name], pose=mat)

    def set_static_pose(self, name: str, pos, quat_xyzw=(0,0,0,1)):
        self.set_pose(name, pos, quat_xyzw)

    def update_string(self, name: str, p1, p2,
                      radius: float = 0.006, color=None):
        """Create or refresh a thin cylinder 'string/wire' between world points p1 and p2.
        Call each frame from extra_sync_fn to animate pendulum strings, cradle wires, etc."""
        if self._metadata_only:
            self._nodes[name] = object()
            return
        if color is None:
            color = [0.22, 0.16, 0.10, 1.0]
        if name in self._nodes:
            self.scene.remove_node(self._nodes.pop(name))
        p1 = np.array(p1, dtype=float)
        p2 = np.array(p2, dtype=float)
        diff = p2 - p1
        length = float(np.linalg.norm(diff))
        if length < 1e-6:
            return
        mid   = (p1 + p2) * 0.5
        z_ax  = diff / length
        up    = np.array([0., 0., 1.]) if abs(z_ax[2]) < 0.95 else np.array([0., 1., 0.])
        x_ax  = np.cross(up, z_ax);  x_ax /= np.linalg.norm(x_ax)
        y_ax  = np.cross(z_ax, x_ax)
        mat   = np.eye(4)
        mat[:3, 0] = x_ax;  mat[:3, 1] = y_ax
        mat[:3, 2] = z_ax;  mat[:3, 3] = mid
        tm   = trimesh.creation.cylinder(radius=radius, height=length, sections=8)
        node = self.scene.add(
            pyrender.Mesh.from_trimesh(
                tm,
                material=self._material(color, metallic=0.3, roughness=0.7),
                smooth=True),
            pose=mat)
        self._nodes[name] = node

    # ── render ────────────────────────────────────────────────────────────────

    def render_frame(self) -> np.ndarray:
        if self._metadata_only:
            return np.zeros((1, 1, 3), dtype=np.uint8)
        rgba, _ = self.renderer.render(
            self.scene, flags=pyrender.RenderFlags.RGBA)
        return rgba[:, :, :3]

    def close(self):
        self.renderer.delete()


# ══════════════════════════════════════════════════════════════════════════════
# Simulation loop
# ══════════════════════════════════════════════════════════════════════════════

def run_loop(phys: Physics, ren: Renderer,
             dynamic_objects,          # list of (name, body_id)
             n_frames: int,
             steps_per_frame: int = STEP_RATE // FPS,
             extra_sync_fn=None) -> List[np.ndarray]:
    """
    Standard simulation + render loop used by most experiments.

    dynamic_objects: [(render_name, bullet_body_id), ...]
    extra_sync_fn:   optional callable(phys, ren, frame_idx) for special cases
                     (chain links, multi-link bodies, etc.)
    """
    if metadata_only():
        return []
    frames: List[np.ndarray] = []
    for fi in range(n_frames):
        for _ in range(steps_per_frame):
            phys.step()
        for name, bid in dynamic_objects:
            pos, orn = phys.get_pose(bid)
            ren.set_pose(name, pos, orn)
        if extra_sync_fn is not None:
            extra_sync_fn(phys, ren, fi)
        frames.append(ren.render_frame())
    return frames


# ══════════════════════════════════════════════════════════════════════════════
# Dataset I/O
# ══════════════════════════════════════════════════════════════════════════════

def save_sample(out_dir: str,
                params_dict: dict,
                cot_dict:    dict,
                standalone_code: str,
                frames: List[np.ndarray],
                fps: int = FPS):
    os.makedirs(out_dir, exist_ok=True)
    cot_dict = enrich_kubric_cot(cot_dict, params_dict, standalone_code)
    # params
    with open(os.path.join(out_dir, "params.json"), "w") as fh:
        json.dump(params_dict, fh, indent=2)
    # cot
    with open(os.path.join(out_dir, "cot.json"), "w") as fh:
        json.dump(cot_dict, fh, indent=2)
    # standalone script
    with open(os.path.join(out_dir, "simulation_code.py"), "w") as fh:
        fh.write(standalone_code)


def param_entry(value, unit: str, description: str) -> dict:
    return {"value": value, "unit": unit, "description": description}


def _summarize_value(value):
    if isinstance(value, list):
        if len(value) > 8:
            return {"count": len(value), "first_values": value[:3]}
        return value
    return value


def _extract_camera_from_code(code: str) -> dict:
    import ast
    import re

    camera = {}
    for key in ("CAM_EYE", "CAM_TARGET"):
        match = re.search(rf"{key}\s*=\s*([^\n]+)", code)
        if not match:
            continue
        try:
            camera[key.lower()] = ast.literal_eval(match.group(1).strip())
        except Exception:
            camera[key.lower()] = match.group(1).strip()
    return camera


def enrich_kubric_cot(cot: dict, params_dict: dict, standalone_code: str) -> dict:
    """Attach PyBullet/render metadata to every Kubric COT file."""
    object_keys = [
        key for key in (
            "objects", "object_shapes", "shape", "obj_type", "colors", "color",
            "radii", "masses", "positions", "velocities", "frictions",
            "restitutions", "n_objects", "n_balls", "n_links", "n_layers",
        )
        if key in params_dict
    ]
    cot["pybullet_numerical_model"] = {
        "engine": "PyBullet/Bullet rigid-body dynamics",
        "time_integration": {
            "method": "semi-implicit Euler / sequential impulse stepping",
            "physics_hz": STEP_RATE,
            "frame_rate_fps": FPS,
            "substeps_per_frame": STEP_RATE // FPS,
            "timestep_s": round(1.0 / STEP_RATE, 6),
        },
        "contact_and_constraint_resolution": {
            "normal_impulse": "j_n = -(1+e) * (v_rel dot n) / effective_mass",
            "tangent_impulse": "|j_t| <= mu * |j_n| with Coulomb friction clamp",
            "solver": "Bullet sequential impulse / LCP-style contact solver",
            "settings": {
                "useSplitImpulse": True,
                "restitutionVelocityThreshold": 0.2,
                "contactSlop": 0.0,
            },
        },
        "scope_note": (
            "Closed-form equations in physical_law describe the teaching model; "
            "contacts, hinges, collision impulses, and nonpenetration are resolved "
            "numerically by PyBullet in simulation_code.py."
        ),
    }
    cot["visual_scene"] = {
        "renderer": "pyrender OffscreenRenderer with EGL when headless",
        "resolution_px": list(RESOLUTION),
        "camera": _extract_camera_from_code(standalone_code),
        "object_metadata": {key: _summarize_value(params_dict[key]) for key in object_keys},
        "shape_color_note": (
            "Object shapes, colors, initial poses, velocities, friction, and restitution "
            "are stored in params.json when the experiment exposes them."
        ),
    }
    return cot


def build_cot(
    simulation:           str,
    category:             str,
    seed:                 int,
    physical_observation: str,
    law_name:             str,
    law_statement:        str,
    law_formula:          str,
    assumptions:          List[str],
    state_variables:      List[str],
    equations_latex:      List[str],
    contact_impulse:      str,
    derivation_steps:     List[str],
    expected_behavior:    List[str],
    parameters:           dict,
    energy_check:         str = (
        "Energy is conserved only in ideal lossless free-flight/constraint phases. "
        "In PyBullet runs it may change through gravity, constraint work, friction, "
        "inelastic impacts, damping, motors, or scripted kinematic motion depending "
        "on the scene."
    ),
) -> dict:
    return {
        "simulation":            simulation,
        "category":              category,
        "seed":                  seed,
        "physical_observation":  physical_observation,
        "physical_law": {
            "name":      law_name,
            "statement": law_statement,
            "formula":   law_formula,
        },
        "modeling_assumptions": assumptions,
        "ode_system": None,
        "impulse_model": {
            "state_variables":        state_variables,
            "equations_latex":        equations_latex,
            "contact_impulse_formula": contact_impulse,
            "numerical_method": (
                "Semi-implicit Euler at 240 Hz "
                "(8 substeps per 30-fps frame), "
                "PyBullet sequential-impulse contact solver"
            ),
        },
        "derivation_steps": derivation_steps,
        "numerical_method": {
            "solver":               "PyBullet rigid-body sequential-impulse solver",
            "timestep_s":           round(1.0 / STEP_RATE, 6),
            "substeps_per_frame":   STEP_RATE // FPS,
            "justification": (
                f"{STEP_RATE // FPS}× substep ratio ensures stable contact "
                "resolution without tunnelling at realistic object sizes."
            ),
        },
        "code_validation": {
            "physics_engine":       "PyBullet (Bullet Physics 3.x)",
            "energy_check":         energy_check,
            "physical_plausibility": True,
        },
        "expected_behavior": expected_behavior,
        "parameters":        parameters,
    }


# ══════════════════════════════════════════════════════════════════════════════
# Standalone-script boilerplate (injected into every simulation_code.py)
# ══════════════════════════════════════════════════════════════════════════════

STANDALONE_IMPORTS = """\
import os, math, random
if "PYOPENGL_PLATFORM" not in os.environ:
    if not os.environ.get("DISPLAY"):
        os.environ["PYOPENGL_PLATFORM"] = "egl"
import numpy as np
import pybullet as p
pb = p
import pybullet_data
import trimesh
import pyrender
import imageio

G          = 9.81
RESOLUTION = (480, 480)
FPS        = 30
STEP_RATE  = 240
"""

STANDALONE_UTILS = """\

def _hsv_rgb(h, s, v):
    hi = int(h*6)%6; f=h*6-int(h*6); p_=v*(1-s); q=v*(1-f*s); t=v*(1-(1-f)*s)
    return [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]

def random_hue_color(s=0.85, v=0.90):
    r, g, b = _hsv_rgb(random.random(), s, v)
    return [r, g, b, 1.0]

def muted_grey(lo=0.30, hi=0.55):
    c = random.uniform(lo, hi)
    return [c, c + random.uniform(-0.03, 0.03), c + random.uniform(-0.03, 0.03), 1.0]

def floor_color():
    return muted_grey(0.38, 0.52)

def _look_at(eye, target, up=(0,0,1)):
    eye=np.array(eye,float); target=np.array(target,float); up=np.array(up,float)
    fwd=target-eye; fwd/=np.linalg.norm(fwd)
    right=np.cross(fwd,up)
    if np.linalg.norm(right)<1e-8: right=np.array([1.,0.,0.])
    right/=np.linalg.norm(right); up2=np.cross(right,fwd)
    m=np.eye(4); m[:3,0]=right; m[:3,1]=up2; m[:3,2]=-fwd; m[:3,3]=eye
    return m

def _q2r(xyzw):
    x,y,z,w=xyzw
    return np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],
                     [2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],
                     [2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])

def _set_pose(scene, node, pos, quat):
    R=_q2r(quat); m=np.eye(4); m[:3,:3]=R; m[:3,3]=np.array(pos)
    scene.set_pose(node, pose=m)

def _make_renderer(cam_eye, cam_target):
    W,H=RESOLUTION
    ren=pyrender.OffscreenRenderer(W,H)
    sc=pyrender.Scene(ambient_light=[0.10,0.10,0.12,1.0],bg_color=[0.06,0.06,0.10,1.0])
    for color,intensity,eye in [([1.00,0.95,0.88],5.5,[-3,-4,6]),
                                  ([0.50,0.62,1.00],2.0,[4,3,4]),
                                  ([0.90,0.90,0.90],0.8,[0,-5,1])]:
        sc.add(pyrender.DirectionalLight(color=color,intensity=intensity),
               pose=_look_at(eye,[0,0,0]))
    cam=pyrender.PerspectiveCamera(yfov=math.pi/4,aspectRatio=W/H,znear=0.05,zfar=300.)
    sc.add(cam,pose=_look_at(cam_eye,cam_target))
    return ren,sc

def _mat(color,metallic=0.05,roughness=0.5):
    return pyrender.MetallicRoughnessMaterial(baseColorFactor=color,
           metallicFactor=metallic,roughnessFactor=roughness)

def _add_sphere(sc,name,nodes,r,color,metallic=0.1,roughness=0.3):
    tm=trimesh.creation.icosphere(subdivisions=3,radius=r)
    nodes[name]=sc.add(pyrender.Mesh.from_trimesh(tm,material=_mat(color,metallic,roughness),smooth=True),pose=np.eye(4))

def _add_box(sc,name,nodes,he,color,metallic=0.05,roughness=0.55):
    tm=trimesh.creation.box(extents=[e*2 for e in he])
    nodes[name]=sc.add(pyrender.Mesh.from_trimesh(tm,material=_mat(color,metallic,roughness),smooth=False),pose=np.eye(4))

def _add_cylinder(sc,name,nodes,r,h,color,metallic=0.05,roughness=0.5):
    tm=trimesh.creation.cylinder(radius=r,height=h,sections=32)
    nodes[name]=sc.add(pyrender.Mesh.from_trimesh(tm,material=_mat(color,metallic,roughness),smooth=True),pose=np.eye(4))

def _add_capsule(sc,name,nodes,r,h,color):
    tm=trimesh.creation.capsule(radius=r,height=h,count=[8,8])
    nodes[name]=sc.add(pyrender.Mesh.from_trimesh(tm,material=_mat(color),smooth=True),pose=np.eye(4))

def _update_string(sc,nodes,name,p1,p2,radius=0.006,color=None):
    if color is None: color=[0.22,0.16,0.10,1.0]
    if name in nodes: sc.remove_node(nodes.pop(name))
    p1=np.array(p1,float); p2=np.array(p2,float)
    diff=p2-p1; length=float(np.linalg.norm(diff))
    if length<1e-6: return
    mid=(p1+p2)*0.5; z=diff/length
    up=np.array([0.,0.,1.]) if abs(z[2])<0.95 else np.array([0.,1.,0.])
    x=np.cross(up,z); x/=np.linalg.norm(x); y=np.cross(z,x)
    m=np.eye(4); m[:3,0]=x; m[:3,1]=y; m[:3,2]=z; m[:3,3]=mid
    tm=trimesh.creation.cylinder(radius=radius,height=length,sections=8)
    mat=pyrender.MetallicRoughnessMaterial(baseColorFactor=color,metallicFactor=0.3,roughnessFactor=0.7)
    nodes[name]=sc.add(pyrender.Mesh.from_trimesh(tm,material=mat,smooth=True),pose=m)

def _save_video(frames,path,fps=FPS):
    w=imageio.get_writer(path,fps=fps,codec='libx264',quality=5,macro_block_size=None)
    for f in frames: w.append_data(f)
    w.close()

def _init_physics():
    c=p.connect(p.DIRECT)
    p.setGravity(0,0,-G,physicsClientId=c)
    p.setAdditionalSearchPath(pybullet_data.getDataPath(),physicsClientId=c)
    p.setPhysicsEngineParameter(fixedTimeStep=1.0/STEP_RATE,
        restitutionVelocityThreshold=0.2,useSplitImpulse=1,
        splitImpulsePenetrationThreshold=-0.02,contactSlop=0.0,
        physicsClientId=c)
    return c
"""
