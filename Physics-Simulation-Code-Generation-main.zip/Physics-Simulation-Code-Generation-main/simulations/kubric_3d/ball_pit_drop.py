"""ball_pit_drop — heavy ball dropped into dense pit of small spheres."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np
CAM_EYE=(5.5,-5.5,5.5); CAM_TARGET=(0.0,0.0,1.0); N_FRAMES=150
@dataclass
class Params:
    seed: int
    n_pit:int
    pit_r:float
    heavy_r:float
    heavy_mass:float
    drop_z:float
    pit_friction:float
    pit_restitution:float
def random_params(seed):
    random.seed(seed); np.random.seed(seed)
    return Params(seed=seed,n_pit=random.randint(35,55),
        pit_r=random.uniform(0.08,0.14),heavy_r=random.uniform(0.22,0.38),
        heavy_mass=random.uniform(6.0,18.0),drop_z=random.uniform(3.2,4.5),
        pit_friction=random.uniform(0.3,0.6),pit_restitution=random.uniform(0.3,0.65))
def generate_sample(seed, out_dir):
    _dir=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0,_dir)
    from simulations.kubric_3d._base import (Physics,Renderer,run_loop,save_sample,
        build_cot,param_entry,muted_grey,random_hue_color,STANDALONE_IMPORTS,STANDALONE_UTILS)
    import pybullet as pb
    random.seed(seed); np.random.seed(seed)
    p=random_params(seed)
    phys=Physics(); ren=Renderer(CAM_EYE,CAM_TARGET)
    _dyn=[]; _extra_sync=None
    p=random_params(seed)
    phys.add_box([15,15,0.1],[0,0,-0.1],mass=0,friction=p.pit_friction,restitution=0.4)
    ren.add_plane_mesh("fl",30.0,muted_grey())
    pit_bids=[]
    for i in range(p.n_pit):
        x=(i%6-2.5)*p.pit_r*2.2; y=(i//6%6-2.5)*p.pit_r*2.2; z=0.15+p.pit_r+(i//36)*p.pit_r*2.2
        bid=phys.add_sphere(p.pit_r,[x,y,z],mass=0.2,friction=p.pit_friction,restitution=p.pit_restitution)
        pit_bids.append(bid)
    for _ in range(80): phys.step()
    for i,bid in enumerate(pit_bids):
        col=[random.random(),random.random(),random.random(),1.0]
        ren.add_sphere(f"p{i}",p.pit_r,col); _dyn.append((f"p{i}",bid))
    hb=phys.add_sphere(p.heavy_r,[0,0,p.drop_z],mass=p.heavy_mass,restitution=0.3,friction=0.4)
    ren.add_sphere("hv",p.heavy_r,[0.85,0.25,0.15,1.0]); _dyn.append(("hv",hb))
    frames=run_loop(phys,ren,_dyn,N_FRAMES,extra_sync_fn=_extra_sync)
    cot=build_cot("ball_pit_drop","rigid_body",seed,
        f"Heavy r={p.heavy_r:.3f}m m={p.heavy_mass:.1f}kg dropped from z={p.drop_z:.2f}m into {p.n_pit} balls.",
        "Impact dynamics in granular media","Impactor penetrates bed; depth ~ (m*v^2)^(1/3)",r"d_pen \propto (m v^2 / rho g)^{1/3}",
        ["Pit balls are independent rigid spheres","No cohesion","Walls rigid"],
        ["r (m)","v (m/s)","q","w (rad/s)"],
        ["dot_r=v","m*dot_v=mg+Fc","I*dot_w=tc-wxIw"],
        "j=-(1+e)*v_n/(1/mA+1/mB+cross)",
        [f"Impact v~{(2*9.81*p.drop_z)**0.5:.1f} m/s","Momentum transferred to pit balls","Crater forms then refills"],[f"Impact velocity ~{(2*9.81*p.drop_z)**0.5:.1f} m/s","Pit balls scatter radially","Heavy ball settles in pit"],
        {k:param_entry(getattr(p,k),"",k) for k in ["n_pit","pit_r","heavy_r","heavy_mass","drop_z","pit_friction"]})
    save_sample(out_dir,asdict(p),cot,make_standalone_code(p),frames)
    phys.close(); ren.close()
def make_standalone_code(p):
    _dir=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0,_dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS,STANDALONE_UTILS
    body=f"""
# ball_pit_drop  seed={p.seed}
import pybullet as pb
N_FRAMES=150; CAM_EYE=(5.5,-5.5,5.5); CAM_TARGET=(0.0,0.0,1.0)
def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    import random as _rnd; _rnd.seed({p.seed})
    pit_bids=[]
    for i in range({p.n_pit}):
        x=(i%6-2.5)*{p.pit_r}*2.2; y=(i//6%6-2.5)*{p.pit_r}*2.2; z=0.15+{p.pit_r}+(i//36)*{p.pit_r}*2.2
        s=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.pit_r},physicsClientId=c)
        bid=pb.createMultiBody(0.2,s,-1,[x,y,z],[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction={p.pit_friction},restitution={p.pit_restitution},physicsClientId=c)
        pit_bids.append(bid)
    for _ in range(80): pb.stepSimulation(physicsClientId=c)
    bids=[]
    for i,bid in enumerate(pit_bids):
        col=[_rnd.random(),_rnd.random(),_rnd.random(),1.0]
        _add_sphere(sc,f"p{{i}}",nodes,{p.pit_r},col); bids.append((f"p{{i}}",bid))
    s=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.heavy_r},physicsClientId=c)
    hb=pb.createMultiBody({p.heavy_mass},s,-1,[0,0,{p.drop_z}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(hb,-1,lateralFriction=0.4,restitution=0.3,physicsClientId=c)
    _add_sphere(sc,"hv",nodes,{p.heavy_r},[0.85,0.25,0.15,1.0]); bids.append(("hv",hb))
    _add_box(sc,"fl",nodes,[2.5,2.5,0.02],muted_grey()); _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    frames=[]
    for _ in range(150):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""
    return STANDALONE_IMPORTS+STANDALONE_UTILS+body
if __name__=="__main__":
    generate_sample(seed=0,out_dir=f"/tmp/test_ball_pit_drop"); print("OK")
