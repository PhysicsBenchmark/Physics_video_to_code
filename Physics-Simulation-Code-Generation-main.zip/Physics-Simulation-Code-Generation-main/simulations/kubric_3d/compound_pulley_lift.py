"""compound_pulley_lift — movable pulley lifts load with mechanical advantage 2."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (3.5, -5.0, 2.5)
CAM_TARGET = (0.0,  0.0, 1.5)
N_FRAMES   = 150


@dataclass
class Params:
    seed: int
    load_mass: float
    v_load: float       # load rising speed (m/s)
    load_color: List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    h=random.random(); s,v=0.85,0.90; hi=int(h*6)%6; f=h*6-int(h*6)
    p_=v*(1-s); q=v*(1-f*s); t=v*(1-(1-f)*s)
    r,g,b=[(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return Params(
        seed=seed,
        load_mass=random.uniform(2.0, 5.0),
        v_load=random.uniform(0.25, 0.65),
        load_color=[r, g, b, 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Renderer, save_sample, build_cot, param_entry,
        STANDALONE_IMPORTS, STANDALONE_UTILS, FPS)

    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    ren = Renderer(CAM_EYE, CAM_TARGET)

    # Floor
    ren.add_plane_mesh("floor", 8.0, [0.38, 0.38, 0.42, 1.0])
    ren.set_static_pose("floor", [0, 0, -0.02])

    # Ceiling beam (support structure, static)
    ren.add_box("beam", [0.80, 0.12, 0.06], [0.45, 0.38, 0.30, 1.0])
    ren.set_static_pose("beam", [0.15, 0.0, 3.12])

    # Support pole
    ren.add_cylinder("pole", 0.03, 3.0, [0.45, 0.38, 0.30, 1.0])
    ren.set_static_pose("pole", [0.0, 0.0, 1.5])

    # Fixed pulley (top, static)
    H_fixed = 3.0
    ren.add_cylinder("fp", 0.14, 0.09, [0.70, 0.70, 0.20, 1.0])
    ren.set_static_pose("fp", [0.0, 0.0, H_fixed],
                        [math.sin(math.pi/4), 0, 0, math.cos(math.pi/4)])  # tip on side

    # Movable pulley (dynamic, rises)
    ren.add_cylinder("mp", 0.11, 0.08, [0.55, 0.55, 0.60, 1.0])

    # Load (box)
    ren.add_box("load", [0.25, 0.25, 0.20], p.load_color)

    # Effort weight (falling sphere)
    ren.add_sphere("effort", 0.11, [0.20, 0.45, 0.85, 1.0])

    # Kinematics
    z_mp_0   = 1.20   # movable pulley initial height
    z_eff_0  = 2.50   # effort weight initial height
    v_eff    = p.v_load * 2.0   # effort falls 2× faster than load rises

    rope_col = [0.30, 0.22, 0.12, 1.0]
    orn_side = [math.sin(math.pi/4), 0, 0, math.cos(math.pi/4)]

    frames = []
    for fi in range(N_FRAMES):
        t = fi / float(FPS)

        z_mp  = min(z_mp_0  + p.v_load * t, H_fixed - 0.25)
        z_eff = max(z_eff_0 - v_eff * t, 0.20)
        z_load = z_mp - 0.45

        ren.set_pose("mp",     [0.0, 0.0, z_mp],   orn_side)
        ren.set_pose("load",   [0.0, 0.0, z_load],  [0, 0, 0, 1])
        ren.set_pose("effort", [0.45, 0.0, z_eff],  [0, 0, 0, 1])

        # Rope 1: fixed top-left anchor → movable pulley left
        ren.update_string("r1", [-0.08, 0, H_fixed], [-0.08, 0, z_mp],  0.008, rope_col)
        # Rope 2: movable pulley right → fixed top-right anchor
        ren.update_string("r2", [ 0.08, 0, z_mp],   [ 0.08, 0, H_fixed], 0.008, rope_col)
        # Rope 3: top anchor → effort weight (over fixed pulley)
        ren.update_string("r3", [0.30, 0, H_fixed], [0.45, 0, z_eff],   0.008, rope_col)
        # Load hanging rope: load top → movable pulley bottom
        ren.update_string("r4", [0, 0, z_mp-0.04], [0, 0, z_load+0.20], 0.008, rope_col)

        frames.append(ren.render_frame())

    T_effort = p.load_mass * 9.81 / 2.0  # ideal tension in each rope
    cot = build_cot(
        simulation="compound_pulley_lift",
        category="articulated_jointed",
        seed=seed,
        physical_observation=(
            f"Compound pulley (MA=2) lifts load of {p.load_mass:.2f} kg "
            f"at {p.v_load:.2f} m/s while effort weight descends at {v_eff:.2f} m/s."
        ),
        law_name="Compound pulley — mechanical advantage",
        law_statement=(
            "Two rope segments support the movable pulley; "
            "mechanical advantage MA=2. Effort force = Load/2; effort speed = 2×load speed."
        ),
        law_formula="MA=2; F_{effort}=W_{load}/2; v_{effort}=2v_{load}; 2T=W+m_{mp}g",
        assumptions=[
            "Massless inextensible ropes.",
            "Frictionless, massless pulleys (ideal system).",
            "Load rises vertically.",
        ],
        state_variables=["z_load (m)", "z_effort (m)", "v_load (m/s)"],
        equations_latex=[
            "2T = W_{load} + m_{mp}g",
            "T = F_{effort}",
            "v_{effort} = 2 v_{load}",
        ],
        contact_impulse="N/A (kinematic simulation — no collisions)",
        derivation_steps=[
            f"Load weight W = {p.load_mass:.2f} × 9.81 = {p.load_mass*9.81:.2f} N",
            f"Ideal effort force = W/MA = {p.load_mass*9.81/2:.2f} N",
            f"Rope tension T = {T_effort:.2f} N",
            f"Load velocity = {p.v_load:.2f} m/s → effort velocity = {v_eff:.2f} m/s",
        ],
        expected_behavior=[
            f"Load (red/coloured box) rises at {p.v_load:.2f} m/s.",
            f"Effort weight (blue sphere) descends at {v_eff:.2f} m/s.",
            "Movable pulley rises with the load.",
            "Three visible rope segments remain taut throughout.",
        ],
        parameters={
            "load_mass": param_entry(p.load_mass, "kg",  "load mass"),
            "v_load":    param_entry(p.v_load,    "m/s", "load rising speed"),
            "MA":        param_entry(2,            "",    "mechanical advantage"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# compound_pulley_lift  seed={p.seed}
import math
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}
V_LOAD={p.v_load}

def main():
    ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    _add_box(sc,"fl",nodes,[4,4,0.02],[0.38,0.38,0.42,1.0]); _set_pose(sc,nodes["fl"],[0,0,-0.02],[0,0,0,1])
    _add_cylinder(sc,"pole",nodes,0.03,3.0,[0.45,0.38,0.30,1.0]); _set_pose(sc,nodes["pole"],[0,0,1.5],[0,0,0,1])
    q90=[math.sin(math.pi/4),0,0,math.cos(math.pi/4)]
    _add_cylinder(sc,"fp",nodes,0.14,0.09,[0.70,0.70,0.20,1.0]); _set_pose(sc,nodes["fp"],[0,0,3.0],q90)
    _add_cylinder(sc,"mp",nodes,0.11,0.08,[0.55,0.55,0.60,1.0])
    _add_box(sc,"load",nodes,[0.25,0.25,0.20],{p.load_color})
    _add_sphere(sc,"eff",nodes,0.11,[0.20,0.45,0.85,1.0])
    rc=[0.30,0.22,0.12,1.0]; frames=[]
    for fi in range(N_FRAMES):
        t=fi/30.0; zmp=min(1.2+V_LOAD*t,2.75); ze=max(2.5-V_LOAD*2*t,0.2); zl=zmp-0.45
        _set_pose(sc,nodes["mp"],[0,0,zmp],q90); _set_pose(sc,nodes["load"],[0,0,zl],[0,0,0,1])
        _set_pose(sc,nodes["eff"],[0.45,0,ze],[0,0,0,1])
        _update_string(sc,nodes,"r1",[-0.08,0,3.0],[-0.08,0,zmp],0.008,rc)
        _update_string(sc,nodes,"r2",[0.08,0,zmp],[0.08,0,3.0],0.008,rc)
        _update_string(sc,nodes,"r3",[0.30,0,3.0],[0.45,0,ze],0.008,rc)
        _update_string(sc,nodes,"r4",[0,0,zmp-0.04],[0,0,zl+0.20],0.008,rc)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_compound_pulley_lift")
    print("OK")
