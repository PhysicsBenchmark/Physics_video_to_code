"""spring_compress_vs_stretch — twin horizontal mass-spring oscillators show Hooke's law.

Two identical carts each connect to a fixed wall by a Hookean spring (force
F = -k * (x - x_eq) applied to the cart each substep).  The compression cart
starts displaced toward the wall (spring shorter than rest); the stretch
cart starts displaced away from the wall (spring longer than rest).  Both
oscillate around the same equilibrium length, 180 deg out of phase, so at
every instant the viewer sees one spring compressed while the other is
stretched.  The spring visuals are dynamic cylinders that span wall->cart
each frame, with colour modulated from orange (compressed) through yellow
(rest) to green (stretched) — making the deformation immediately readable.
"""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (3.2, -3.0, 2.4)
CAM_TARGET = (0.0,  0.0, 0.30)
N_FRAMES   = 150
FPS        = 30
G          = 9.81


@dataclass
class Params:
    seed: int
    cart_mass: float
    cart_half: List[float]
    wall_half: List[float]
    spring_k: float
    spring_rest_length: float
    spring_radius: float
    cart_lin_damp: float
    initial_compression: float
    initial_stretch: float
    wall_x: float
    cart_y_compress: float
    cart_y_stretch: float
    cart_z: float
    compress_cart_color: List[float]
    stretch_cart_color: List[float]
    wall_color: List[float]
    spring_color_compressed: List[float]
    spring_color_stretched: List[float]
    spring_color_neutral: List[float]


def random_params(seed: int) -> Params:
    rng = random.Random(seed)
    cart_half = [0.10, 0.10, 0.10]
    return Params(
        seed=seed,
        cart_mass=rng.uniform(0.40, 0.70),
        cart_half=cart_half,
        wall_half=[0.04, 0.18, 0.20],
        spring_k=rng.uniform(16.0, 24.0),                 # N/m
        spring_rest_length=rng.uniform(0.55, 0.70),       # centre-to-centre
        spring_radius=0.030,
        cart_lin_damp=0.18,                                # gentle decay
        initial_compression=rng.uniform(0.20, 0.28),
        initial_stretch=rng.uniform(0.20, 0.28),
        wall_x=-0.70,
        cart_y_compress=-0.40,
        cart_y_stretch=+0.40,
        cart_z=cart_half[2],
        compress_cart_color=[0.85, 0.18, 0.14, 1.0],
        stretch_cart_color=[0.16, 0.42, 0.86, 1.0],
        wall_color=[0.45, 0.45, 0.50, 1.0],
        spring_color_compressed=[0.96, 0.45, 0.10, 1.0],   # orange
        spring_color_stretched=[0.20, 0.85, 0.30, 1.0],    # green
        spring_color_neutral=[0.94, 0.74, 0.18, 1.0],      # yellow
    )


def _spring_color(deformation: float, p: Params) -> List[float]:
    """Yellow at rest, blends to orange when compressed (def<0) and green when stretched (def>0)."""
    norm = max(p.initial_compression, p.initial_stretch, 1e-3)
    a = max(min(deformation / norm, 1.0), -1.0)
    if a >= 0.0:
        c1, c2, t = p.spring_color_neutral, p.spring_color_stretched, a
    else:
        c1, c2, t = p.spring_color_neutral, p.spring_color_compressed, -a
    return [c1[i] * (1.0 - t) + c2[i] * t for i in range(4)]


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, save_sample, build_cot, param_entry,
        STEP_RATE, metadata_only)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)
    phys.add_plane(friction=0.04)                          # near-frictionless rails
    ren.add_plane_mesh("floor", 5.0, [0.42, 0.42, 0.45, 1.0])

    cart_x_eq = p.wall_x + p.spring_rest_length

    # Compression demo (red cart, starts displaced toward the wall)
    wall_c_pos = [p.wall_x, p.cart_y_compress, p.wall_half[2]]
    wall_c_id = phys.add_box(p.wall_half, wall_c_pos, mass=0,
                             friction=0.6, restitution=0.0)
    ren.add_box("wall_c", p.wall_half, p.wall_color)
    ren.set_static_pose("wall_c", wall_c_pos)

    cart_c_pos = [cart_x_eq - p.initial_compression, p.cart_y_compress, p.cart_z]
    cart_c_id = phys.add_box(p.cart_half, cart_c_pos, mass=p.cart_mass,
                             friction=0.04, restitution=0.0,
                             lin_damp=p.cart_lin_damp, ang_damp=0.5)
    ren.add_box("cart_c", p.cart_half, p.compress_cart_color)
    ren.set_static_pose("cart_c", cart_c_pos)

    # Stretch demo (blue cart, starts displaced away from the wall)
    wall_s_pos = [p.wall_x, p.cart_y_stretch, p.wall_half[2]]
    wall_s_id = phys.add_box(p.wall_half, wall_s_pos, mass=0,
                             friction=0.6, restitution=0.0)
    ren.add_box("wall_s", p.wall_half, p.wall_color)
    ren.set_static_pose("wall_s", wall_s_pos)

    cart_s_pos = [cart_x_eq + p.initial_stretch, p.cart_y_stretch, p.cart_z]
    cart_s_id = phys.add_box(p.cart_half, cart_s_pos, mass=p.cart_mass,
                             friction=0.04, restitution=0.0,
                             lin_damp=p.cart_lin_damp, ang_damp=0.5)
    ren.add_box("cart_s", p.cart_half, p.stretch_cart_color)
    ren.set_static_pose("cart_s", cart_s_pos)

    bodies = [("cart_c", cart_c_id), ("cart_s", cart_s_id)]
    steps_per_frame = STEP_RATE // FPS

    frames = []
    if metadata_only():
        save_sample(out_dir, asdict(p), _build_cot(p, build_cot, param_entry),
                    make_standalone_code(p), frames)
        phys.close(); ren.close(); return

    wall_front_x = p.wall_x + p.wall_half[0]
    for _fi in range(N_FRAMES):
        for _ in range(steps_per_frame):
            cp, _ = phys.get_pose(cart_c_id)
            sp, _ = phys.get_pose(cart_s_id)
            F_c = -p.spring_k * ((cp[0] - p.wall_x) - p.spring_rest_length)
            F_s = -p.spring_k * ((sp[0] - p.wall_x) - p.spring_rest_length)
            pb_mod.applyExternalForce(cart_c_id, -1, [F_c, 0.0, 0.0], list(cp),
                                      pb_mod.WORLD_FRAME, physicsClientId=phys.client)
            pb_mod.applyExternalForce(cart_s_id, -1, [F_s, 0.0, 0.0], list(sp),
                                      pb_mod.WORLD_FRAME, physicsClientId=phys.client)
            phys.step()
        for nm, bid in bodies:
            pos, orn = phys.get_pose(bid)
            ren.set_pose(nm, pos, orn)
        cp, _ = phys.get_pose(cart_c_id)
        sp, _ = phys.get_pose(cart_s_id)
        deform_c = (cp[0] - p.wall_x) - p.spring_rest_length
        deform_s = (sp[0] - p.wall_x) - p.spring_rest_length
        # Spring runs from wall front-face to cart back-face on each track.
        sc_p1 = [wall_front_x,            p.cart_y_compress, p.cart_z]
        sc_p2 = [cp[0] - p.cart_half[0],  p.cart_y_compress, p.cart_z]
        ss_p1 = [wall_front_x,            p.cart_y_stretch,  p.cart_z]
        ss_p2 = [sp[0] - p.cart_half[0],  p.cart_y_stretch,  p.cart_z]
        ren.update_string("spring_c", sc_p1, sc_p2,
                          radius=p.spring_radius, color=_spring_color(deform_c, p))
        ren.update_string("spring_s", ss_p1, ss_p2,
                          radius=p.spring_radius, color=_spring_color(deform_s, p))
        frames.append(ren.render_frame())

    save_sample(out_dir, asdict(p), _build_cot(p, build_cot, param_entry),
                make_standalone_code(p), frames)
    phys.close(); ren.close()


def _build_cot(p: Params, build_cot, param_entry):
    omega = math.sqrt(p.spring_k / p.cart_mass)
    period = 2.0 * math.pi / omega
    return build_cot(
        simulation="spring_compress_vs_stretch",
        category="hookean_oscillator",
        seed=p.seed,
        physical_observation=(
            f"Two identical carts (m={p.cart_mass:.2f} kg) are each connected to a fixed "
            f"wall by a Hookean spring of stiffness k={p.spring_k:.1f} N/m and rest length "
            f"L0={p.spring_rest_length:.2f} m.  The red cart starts displaced "
            f"{p.initial_compression:.2f} m toward its wall (spring compressed); the blue "
            f"cart starts displaced {p.initial_stretch:.2f} m away from its wall (spring "
            f"stretched).  Both released from rest, they oscillate as simple harmonic "
            f"oscillators with angular frequency omega = sqrt(k/m) = {omega:.2f} rad/s "
            f"(period T = {period:.2f} s)."
        ),
        law_name="Hooke's law and simple harmonic motion",
        law_statement=(
            "Within its elastic range, a spring exerts a restoring force proportional "
            "to its deformation: F = -k (x - x_eq).  Combined with Newton's second law "
            "this gives m x_dotdot + k (x - x_eq) = 0, whose solution is sinusoidal "
            "oscillation around the equilibrium with omega = sqrt(k/m) and amplitude "
            "set by the initial displacement.  Compression (x < x_eq) pushes the cart "
            "outward; stretch (x > x_eq) pulls it back."
        ),
        law_formula="F = -k (x - x_eq);  m x_dotdot + k (x - x_eq) = 0;  omega = sqrt(k/m)",
        assumptions=[
            "Linear (Hookean) spring: force is proportional to deformation, no nonlinearity.",
            "Spring force applied at the cart centre via PyBullet applyExternalForce.",
            "Floor friction set very low (mu=0.04) so the spring force dominates the dynamics.",
            "Light linear damping on each cart so the amplitude decays slowly across the clip.",
            "Walls are static (mass=0); springs are visual cylinders whose length and colour "
            "track the cart-to-wall distance every frame.",
            "PyBullet integrates contacts and forces at 240 Hz.",
        ],
        state_variables=["cart positions x_c, x_s",
                         "cart velocities v_c, v_s",
                         "spring deformations Delta_c, Delta_s"],
        equations_latex=[
            "F = -k\\,(x - x_{\\text{eq}})",
            "m\\,\\ddot x + k\\,(x - x_{\\text{eq}}) = 0",
            "x(t) = x_{\\text{eq}} + A\\cos(\\omega t + \\varphi)",
            "\\omega = \\sqrt{k/m},\\;\\; T = 2\\pi/\\omega",
        ],
        contact_impulse="j_n = -(1+e)(v_rel . n)/m_eff;  |j_t| <= mu |j_n|",
        derivation_steps=[
            f"Equilibrium: cart x_eq = wall_x + L0 = {p.wall_x + p.spring_rest_length:.3f} m.",
            f"Compression cart starts at x_eq - {p.initial_compression:.3f} m "
            f"(spring shortened); spring force +k * compression = "
            f"{p.spring_k * p.initial_compression:.2f} N pushes it outward.",
            f"Stretch cart starts at x_eq + {p.initial_stretch:.3f} m "
            f"(spring elongated); spring force -k * stretch = "
            f"{-p.spring_k * p.initial_stretch:.2f} N pulls it back.",
            f"Each cart obeys SHM about x_eq with angular frequency "
            f"omega = sqrt(k/m) = {omega:.3f} rad/s, period T = {period:.3f} s "
            f"(~{N_FRAMES / FPS / period:.1f} cycles in this clip).",
            "Both carts share the same period but are 180 deg out of phase, so the two "
            "springs alternate compressed/stretched states.",
        ],
        expected_behavior=[
            "Both carts oscillate sinusoidally around the same equilibrium position.",
            "At any instant one spring is compressed (orange) and the other stretched (green), "
            "with their colours becoming yellow as they pass through rest length.",
            "Amplitude decays slowly under mild linear damping.",
            "Walls remain stationary throughout; carts never leave their tracks.",
        ],
        parameters={
            "cart_mass":          param_entry(p.cart_mass,           "kg",   "cart mass"),
            "spring_k":           param_entry(p.spring_k,            "N/m",  "spring stiffness"),
            "spring_rest_length": param_entry(p.spring_rest_length,  "m",    "spring rest length (cart-to-wall)"),
            "initial_compression":param_entry(p.initial_compression, "m",    "initial compression of red spring"),
            "initial_stretch":    param_entry(p.initial_stretch,     "m",    "initial stretch of blue spring"),
            "angular_frequency":  param_entry(omega,                 "rad/s","SHM angular frequency"),
            "period":             param_entry(period,                "s",    "SHM period"),
            "damping":            param_entry(p.cart_lin_damp,       "1/s",  "linear damping coefficient"),
        })


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# spring_compress_vs_stretch  seed={p.seed}
import pybullet as pb
N_FRAMES = {N_FRAMES}; CAM_EYE = {CAM_EYE}; CAM_TARGET = {CAM_TARGET}
CART_HALF = {p.cart_half}; WALL_HALF = {p.wall_half}
CART_MASS = {p.cart_mass}; CART_LD = {p.cart_lin_damp}
SPRING_K = {p.spring_k}; L0 = {p.spring_rest_length}; SR = {p.spring_radius}
INIT_C = {p.initial_compression}; INIT_S = {p.initial_stretch}
WALL_X = {p.wall_x}
Y_C = {p.cart_y_compress}; Y_S = {p.cart_y_stretch}; CART_Z = {p.cart_z}
WALL_COLOR = {p.wall_color}
CART_C_COLOR = {p.compress_cart_color}; CART_S_COLOR = {p.stretch_cart_color}
SPRING_COMPRESS_COLOR = {p.spring_color_compressed}
SPRING_STRETCH_COLOR  = {p.spring_color_stretched}
SPRING_NEUTRAL_COLOR  = {p.spring_color_neutral}

def _spring_color(deform):
    norm = max(INIT_C, INIT_S, 1e-3)
    a = max(min(deform / norm, 1.0), -1.0)
    if a >= 0:
        c1, c2, t = SPRING_NEUTRAL_COLOR, SPRING_STRETCH_COLOR, a
    else:
        c1, c2, t = SPRING_NEUTRAL_COLOR, SPRING_COMPRESS_COLOR, -a
    return [c1[i]*(1-t) + c2[i]*t for i in range(4)]

def main():
    c = _init_physics(); ren, sc = _make_renderer(CAM_EYE, CAM_TARGET); nodes = {{}}
    plane = pb.loadURDF("plane.urdf", [0, 0, 0], physicsClientId=c)
    pb.changeDynamics(plane, -1, lateralFriction=0.04, restitution=0.0, physicsClientId=c)
    _add_box(sc, "floor", nodes, [2.5, 2.5, 0.02], [0.42, 0.42, 0.45, 1.0])
    _set_pose(sc, nodes["floor"], [0, 0, -0.02], [0, 0, 0, 1])

    x_eq = WALL_X + L0
    # walls
    for nm, y in [("wall_c", Y_C), ("wall_s", Y_S)]:
        sh = pb.createCollisionShape(pb.GEOM_BOX, halfExtents=WALL_HALF, physicsClientId=c)
        bid = pb.createMultiBody(0, sh, -1, [WALL_X, y, WALL_HALF[2]], [0,0,0,1],
                                  physicsClientId=c)
        pb.changeDynamics(bid, -1, lateralFriction=0.6, restitution=0.0, physicsClientId=c)
        _add_box(sc, nm, nodes, WALL_HALF, WALL_COLOR)
        _set_pose(sc, nodes[nm], [WALL_X, y, WALL_HALF[2]], [0,0,0,1])

    # carts
    sh = pb.createCollisionShape(pb.GEOM_BOX, halfExtents=CART_HALF, physicsClientId=c)
    cart_c = pb.createMultiBody(CART_MASS, sh, -1, [x_eq - INIT_C, Y_C, CART_Z], [0,0,0,1],
                                 physicsClientId=c)
    cart_s = pb.createMultiBody(CART_MASS, sh, -1, [x_eq + INIT_S, Y_S, CART_Z], [0,0,0,1],
                                 physicsClientId=c)
    for bid in (cart_c, cart_s):
        pb.changeDynamics(bid, -1, lateralFriction=0.04, restitution=0.0,
                           linearDamping=CART_LD, angularDamping=0.5, physicsClientId=c)
    _add_box(sc, "cart_c", nodes, CART_HALF, CART_C_COLOR)
    _set_pose(sc, nodes["cart_c"], [x_eq - INIT_C, Y_C, CART_Z], [0,0,0,1])
    _add_box(sc, "cart_s", nodes, CART_HALF, CART_S_COLOR)
    _set_pose(sc, nodes["cart_s"], [x_eq + INIT_S, Y_S, CART_Z], [0,0,0,1])

    wall_front = WALL_X + WALL_HALF[0]
    bodies = [("cart_c", cart_c), ("cart_s", cart_s)]
    frames = []
    for fi in range(N_FRAMES):
        for __ in range(8):
            cp, _ = pb.getBasePositionAndOrientation(cart_c, physicsClientId=c)
            sp, _ = pb.getBasePositionAndOrientation(cart_s, physicsClientId=c)
            F_c = -SPRING_K * ((cp[0] - WALL_X) - L0)
            F_s = -SPRING_K * ((sp[0] - WALL_X) - L0)
            pb.applyExternalForce(cart_c, -1, [F_c, 0, 0], list(cp),
                                   pb.WORLD_FRAME, physicsClientId=c)
            pb.applyExternalForce(cart_s, -1, [F_s, 0, 0], list(sp),
                                   pb.WORLD_FRAME, physicsClientId=c)
            pb.stepSimulation(physicsClientId=c)
        for nm, bid in bodies:
            pp, oo = pb.getBasePositionAndOrientation(bid, physicsClientId=c)
            _set_pose(sc, nodes[nm], pp, oo)
        cp, _ = pb.getBasePositionAndOrientation(cart_c, physicsClientId=c)
        sp, _ = pb.getBasePositionAndOrientation(cart_s, physicsClientId=c)
        d_c = (cp[0] - WALL_X) - L0
        d_s = (sp[0] - WALL_X) - L0
        _update_string(sc, nodes, "spring_c",
                        [wall_front, Y_C, CART_Z],
                        [cp[0] - CART_HALF[0], Y_C, CART_Z],
                        SR, _spring_color(d_c))
        _update_string(sc, nodes, "spring_s",
                        [wall_front, Y_S, CART_Z],
                        [sp[0] - CART_HALF[0], Y_S, CART_Z],
                        SR, _spring_color(d_s))
        rgba, _ = ren.render(sc, flags=pyrender.RenderFlags.RGBA)
        frames.append(rgba[:,:,:3])
    _save_video(frames, "video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")

if __name__ == "__main__":
    main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_spring_compress_vs_stretch")
    print("OK")
