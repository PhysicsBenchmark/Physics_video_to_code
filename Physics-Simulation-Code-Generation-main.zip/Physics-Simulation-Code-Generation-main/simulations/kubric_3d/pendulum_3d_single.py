"""pendulum_3d_single — single spherical pendulum pivoted at top, released from angle."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (4, -2, 3)
CAM_TARGET = (0, 0, 1)
N_FRAMES   = 150


@dataclass
class Params:
    seed: int
    rod_length: float
    ball_radius: float
    ball_mass: float
    release_angle_deg: float
    floor_friction: float
    pivot_height: float
    color: List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    h = random.random()
    s, v = 0.85, 0.90
    hi = int(h * 6) % 6
    f  = h * 6 - int(h * 6)
    p_ = v * (1 - s); q = v * (1 - f*s); t = v * (1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    color = [r, g, b, 1.0]
    rod_len = random.uniform(1.0, 3.0)
    return Params(
        seed=seed,
        rod_length=rod_len,
        ball_radius=random.uniform(0.04, 0.10),
        ball_mass=random.uniform(0.5, 2.0),
        release_angle_deg=random.uniform(20.0, 70.0),
        floor_friction=random.uniform(0.4, 0.7),
        pivot_height=rod_len + 0.3,
        color=color,
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 8.0, [0.42, 0.42, 0.45, 1.0])

    # Pivot world position
    pivot = [0.0, 0.0, p.pivot_height]

    # Ball released at angle from vertical
    theta = math.radians(p.release_angle_deg)
    bx = p.rod_length * math.sin(theta)
    bz = p.pivot_height - p.rod_length * math.cos(theta)
    ball_pos = [bx, 0.0, bz]

    ball_id = phys.add_sphere(
        radius=p.ball_radius, pos=ball_pos,
        mass=p.ball_mass, friction=0.1, restitution=0.5)

    # Fixed anchor at pivot (mass=0 → already static; no extra JOINT_FIXED needed)
    anchor_id = phys.add_sphere(radius=0.03, pos=pivot, mass=0.0,
                                friction=0.0, restitution=0.0)

    # Connect ball to anchor with JOINT_POINT2POINT
    # child_pos = vector from ball to pivot in ball's local frame
    pivot_in_ball = [pivot[0]-ball_pos[0], pivot[1]-ball_pos[1], pivot[2]-ball_pos[2]]
    phys.create_constraint(
        anchor_id, -1, ball_id, -1,
        pb_mod.JOINT_POINT2POINT, [0, 0, 0],
        [0.0, 0.0, 0.0],
        pivot_in_ball,
        max_force=5000.0)

    ren.add_sphere("ball", p.ball_radius, p.color)
    ren.set_static_pose("ball", ball_pos)

    _pivot = pivot  # capture for closure
    _ball_id = ball_id
    ren.add_sphere("pivot", 0.04, [0.85, 0.85, 0.85, 1.0])
    ren.set_static_pose("pivot", pivot)

    str_radius = 0.012
    str_color = [0.25, 0.18, 0.10, 1.0]

    def extra_sync_fn(phys, ren, fi):
        ball_p, _ = phys.get_pose(_ball_id)
        ren.update_string("string", _pivot, ball_p.tolist(), str_radius, str_color)

    dyn = [("ball", ball_id)]
    frames = run_loop(phys, ren, dyn, N_FRAMES, extra_sync_fn=extra_sync_fn)

    period_approx = 2 * math.pi * math.sqrt(p.rod_length / 9.81)
    cot = build_cot(
        simulation="pendulum_3d_single",
        category="articulated_jointed",
        seed=seed,
        physical_observation=(
            f"Spherical pendulum L={p.rod_length:.2f}m, r={p.ball_radius:.3f}m, "
            f"m={p.ball_mass:.2f}kg released from θ={p.release_angle_deg:.1f}°."
        ),
        law_name="Lagrangian mechanics of spherical pendulum",
        law_statement=(
            "A mass on an inextensible rod pivoted at a fixed point conserves "
            "energy (PE+KE) and traces a curved path under gravity."
        ),
        law_formula="L = (1/2)m·L²·(θ̇² + sin²θ·φ̇²) - mgL(1 - cosθ)",
        assumptions=[
            "Point mass at end of massless inextensible rod",
            "No air drag",
            "JOINT_POINT2POINT constraint enforces constant distance from pivot",
            "Large-angle oscillation (no small-angle approximation)",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg-T\\hat{e}_r",
            "T=m(L\\dot{\\theta}^2+g\\cos\\theta)",
            "T_{\\text{period}}\\approx 2\\pi\\sqrt{L/g}",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            "Constraint: |r - r_pivot|² = L² enforced by JOINT_POINT2POINT",
            "Tension T = m(v²/L + g·cosθ) balances centripetal need",
            f"Small-angle period T ≈ {period_approx:.3f} s",
            f"Initial PE = m·g·L·(1-cosθ) = {p.ball_mass*9.81*p.rod_length*(1-math.cos(theta)):.3f} J",
            "At bottom: v = sqrt(2gL(1-cosθ))",
        ],
        expected_behavior=[
            "Ball swings from initial angle toward equilibrium",
            "Passes through lowest point with maximum speed",
            "Swings up on opposite side to approximately same height",
            "Oscillates with slowly decreasing amplitude due to damping",
        ],
        parameters={
            "rod_length":        param_entry(p.rod_length,        "m",  "pendulum rod length"),
            "ball_radius":       param_entry(p.ball_radius,       "m",  "sphere radius"),
            "ball_mass":         param_entry(p.ball_mass,         "kg", "pendulum bob mass"),
            "release_angle_deg": param_entry(p.release_angle_deg, "°",  "release angle from vertical"),
            "pivot_height":      param_entry(p.pivot_height,      "m",  "pivot point height above ground"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    theta = math.radians(p.release_angle_deg)
    bx = p.rod_length * math.sin(theta)
    bz = p.pivot_height - p.rod_length * math.cos(theta)
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# pendulum_3d_single  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[4.0,4.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    # anchor at pivot
    sa=pb.createCollisionShape(pb.GEOM_SPHERE,radius=0.03,physicsClientId=c)
    anc=pb.createMultiBody(0,sa,-1,[0,0,{p.pivot_height}],[0,0,0,1],physicsClientId=c)
    pb.createConstraint(anc,-1,-1,-1,pb.JOINT_FIXED,[0,0,0],[0,0,0],[0,0,{p.pivot_height}],physicsClientId=c)
    # ball
    sb=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.ball_radius},physicsClientId=c)
    ball=pb.createMultiBody({p.ball_mass},sb,-1,[{bx:.4f},0,{bz:.4f}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(ball,-1,lateralFriction=0.1,restitution=0.5,physicsClientId=c)
    cid=pb.createConstraint(anc,-1,ball,-1,pb.JOINT_POINT2POINT,[0,0,0],
        [0,0,0],[{-bx:.4f},0,{p.pivot_height-bz:.4f}],physicsClientId=c)
    pb.changeConstraint(cid,maxForce=1000,physicsClientId=c)
    _add_sphere(sc,"ball",nodes,{p.ball_radius},{p.color})
    bids=[("ball",ball)]; frames=[]; pivot_pos=[0,0,{p.pivot_height}]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn)
        ball_pos2,_=pb.getBasePositionAndOrientation(ball,physicsClientId=c)
        _update_string(sc,nodes,"string",pivot_pos,list(ball_pos2),0.006,[0.25,0.18,0.10,1.0])
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_pendulum_3d_single")
    print("OK")
