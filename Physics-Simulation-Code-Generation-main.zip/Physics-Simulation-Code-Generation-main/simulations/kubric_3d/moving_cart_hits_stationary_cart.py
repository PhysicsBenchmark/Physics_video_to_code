"""moving_cart_hits_stationary_cart — moving cart strikes a stationary cart, demonstrating 1-D momentum conservation."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (0.5, -4.5, 1.4)
CAM_TARGET = (0.0,  0.0, 0.20)
N_FRAMES   = 150


@dataclass
class Params:
    seed: int
    cart_half_ext: List[float]
    cart_a_x0: float
    cart_a_v0: float       # initial speed of moving cart (positive, in +x)
    cart_a_mass: float
    cart_b_x0: float
    cart_b_mass: float
    floor_friction: float
    restitution: float
    cart_a_color: List[float]
    cart_b_color: List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        cart_half_ext=[0.28, 0.18, 0.14],
        cart_a_x0=-1.7,
        cart_a_v0=random.uniform(1.2, 1.8),
        cart_a_mass=random.uniform(0.55, 0.95),
        cart_b_x0=0.5,
        cart_b_mass=random.uniform(0.55, 0.95),
        floor_friction=random.uniform(0.04, 0.08),
        restitution=random.uniform(0.70, 0.92),
        cart_a_color=[0.90, 0.20, 0.18, 1.0],   # red — visibly the "moving" one
        cart_b_color=[0.18, 0.42, 0.88, 1.0],   # blue — visibly the "stationary" one
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        STANDALONE_IMPORTS, STANDALONE_UTILS, FPS)

    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 8.0, [0.42, 0.42, 0.45, 1.0])
    ren.set_static_pose("floor", [0, 0, -0.02])

    cart_z = p.cart_half_ext[2]   # bottom flush on floor

    # Yellow stripe on floor visually marking cart B's initial position
    ren.add_box("marker_b", [0.04, 0.18, 0.005], [0.95, 0.85, 0.10, 1.0])
    ren.set_static_pose("marker_b", [p.cart_b_x0, 0.0, 0.005])

    cart_a_id = phys.add_box(p.cart_half_ext, [p.cart_a_x0, 0.0, cart_z],
                             mass=p.cart_a_mass,
                             friction=p.floor_friction, restitution=p.restitution,
                             vel=[p.cart_a_v0, 0, 0],
                             lin_damp=0.0, ang_damp=0.05)
    ren.add_box("cart_A", p.cart_half_ext, p.cart_a_color)

    cart_b_id = phys.add_box(p.cart_half_ext, [p.cart_b_x0, 0.0, cart_z],
                             mass=p.cart_b_mass,
                             friction=p.floor_friction, restitution=p.restitution,
                             lin_damp=0.0, ang_damp=0.05)
    ren.add_box("cart_B", p.cart_half_ext, p.cart_b_color)

    dyn = [("cart_A", cart_a_id), ("cart_B", cart_b_id)]
    frames = run_loop(phys, ren, dyn, N_FRAMES)

    e  = p.restitution
    m1 = p.cart_a_mass; m2 = p.cart_b_mass
    u1 = p.cart_a_v0;   u2 = 0.0
    v1 = ((m1 - e*m2)*u1 + (1+e)*m2*u2) / (m1 + m2)
    v2 = ((1+e)*m1*u1 + (m2 - e*m1)*u2) / (m1 + m2)
    KE_i = 0.5*m1*u1*u1 + 0.5*m2*u2*u2
    KE_f = 0.5*m1*v1*v1 + 0.5*m2*v2*v2
    p_i  = m1*u1 + m2*u2
    p_f  = m1*v1 + m2*v2
    gap  = (p.cart_b_x0 - p.cart_a_x0) - 2*p.cart_half_ext[0]
    t_collide = gap / max(u1, 1e-3)
    cot = build_cot(
        simulation="moving_cart_hits_stationary_cart",
        category="rigid_body_collision",
        seed=seed,
        physical_observation=(
            f"Cart A (m={m1:.2f}kg, RED) approaches stationary cart B (m={m2:.2f}kg, BLUE) "
            f"at u₁={u1:.2f}m/s. After 1-D collision with restitution e={e:.2f}: "
            f"v_A={v1:.2f}m/s, v_B={v2:.2f}m/s. Yellow stripe marks cart B's initial position."
        ),
        law_name="1-D collision: momentum conservation + Newton's restitution",
        law_statement=(
            "Conservation of linear momentum: m₁u₁ + m₂u₂ = m₁v₁ + m₂v₂. "
            "Newton's restitution: v₂ − v₁ = −e(u₂ − u₁). "
            "Together these uniquely determine post-collision velocities."
        ),
        law_formula="v_1=\\frac{(m_1-em_2)u_1+(1+e)m_2 u_2}{m_1+m_2};\\;\\; v_2=\\frac{(1+e)m_1 u_1+(m_2-em_1)u_2}{m_1+m_2}",
        assumptions=[
            "u₂ = 0 (cart B initially at rest).",
            "1-D collision along x-axis.",
            "Newton restitution captures elasticity (e=1 fully elastic, e=0 plastic).",
            "Floor friction decelerates each cart between/after the collision.",
        ],
        state_variables=["x_A (m)", "v_A (m/s)", "x_B (m)", "v_B (m/s)"],
        equations_latex=[
            "m_1 u_1 + m_2 u_2 = m_1 v_1 + m_2 v_2",
            "v_2 - v_1 = -e(u_2 - u_1)",
            "M\\dot{v}=-\\mu Mg\\,\\mathrm{sign}(v)",
        ],
        contact_impulse="j = (1+e)·m_1·m_2·(u_1-u_2) / (m_1+m_2)",
        derivation_steps=[
            f"Initial: m_A={m1:.2f}kg @ u_A={u1:.2f}m/s; m_B={m2:.2f}kg @ u_B=0; e={e:.2f}",
            f"Initial gap: {gap:.2f} m → expected collision time ≈ {t_collide:.2f} s",
            f"Predicted v_A = (m_A − e·m_B)·u_A / (m_A+m_B) = {v1:.3f} m/s",
            f"Predicted v_B = (1+e)·m_A·u_A / (m_A+m_B) = {v2:.3f} m/s",
            f"Momentum check: p_i={p_i:.3f}, p_f={p_f:.3f} (conserved)",
            f"KE: pre={KE_i:.3f}J → post={KE_f:.3f}J ({KE_f/KE_i*100:.1f}% retained)",
        ],
        expected_behavior=[
            f"Cart A (red) slides at {u1:.2f} m/s toward cart B (blue), which sits on the yellow marker.",
            f"Collision at t≈{t_collide:.2f}s: cart A {'nearly stops' if abs(v1) < 0.25 else f'recoils to {v1:.2f}m/s'}, "
            f"cart B accelerates from 0 to ≈{v2:.2f} m/s.",
            f"Cart B continues moving rightward; cart A {'remains nearly still' if abs(v1) < 0.25 else 'drifts'}.",
            f"Floor friction (μ={p.floor_friction:.2f}) gradually slows each cart over the rest of the clip.",
        ],
        parameters={
            "m_A":             param_entry(m1, "kg",  "moving cart mass"),
            "u_A":             param_entry(u1, "m/s", "initial speed of cart A"),
            "m_B":             param_entry(m2, "kg",  "stationary cart mass"),
            "u_B":             param_entry(0.0, "m/s", "initial speed of cart B"),
            "restitution":     param_entry(e,  "",   "Newton restitution coefficient"),
            "floor_friction":  param_entry(p.floor_friction, "", "cart-floor friction coefficient"),
            "v_A_predicted":   param_entry(v1, "m/s", "post-collision speed of A"),
            "v_B_predicted":   param_entry(v2, "m/s", "post-collision speed of B"),
            "KE_ratio":        param_entry(KE_f/KE_i, "", "post/pre kinetic-energy ratio"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# moving_cart_hits_stationary_cart  seed={p.seed}
import math, pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}
HE={p.cart_half_ext}; A_X0={p.cart_a_x0}; A_V0={p.cart_a_v0}; A_M={p.cart_a_mass}
B_X0={p.cart_b_x0}; B_M={p.cart_b_mass}; FR={p.floor_friction}; RES={p.restitution}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    plane_bid=pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    pb.changeDynamics(plane_bid,-1,lateralFriction=FR,physicsClientId=c)
    _add_box(sc,"fl",nodes,[4,4,0.02],[0.42,0.42,0.45,1.0]); _set_pose(sc,nodes["fl"],[0,0,-0.02],[0,0,0,1])
    _add_box(sc,"mark",nodes,[0.04,0.18,0.005],[0.95,0.85,0.10,1.0]); _set_pose(sc,nodes["mark"],[B_X0,0,0.005],[0,0,0,1])
    cz=HE[2]
    s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=HE,physicsClientId=c)
    a=pb.createMultiBody(A_M,s,-1,[A_X0,0,cz],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(a,-1,lateralFriction=FR,restitution=RES,linearDamping=0.0,angularDamping=0.05,physicsClientId=c)
    pb.resetBaseVelocity(a,[A_V0,0,0],[0,0,0],physicsClientId=c)
    _add_box(sc,"a",nodes,HE,{p.cart_a_color})
    s2=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=HE,physicsClientId=c)
    b=pb.createMultiBody(B_M,s2,-1,[B_X0,0,cz],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(b,-1,lateralFriction=FR,restitution=RES,linearDamping=0.0,angularDamping=0.05,physicsClientId=c)
    _add_box(sc,"b",nodes,HE,{p.cart_b_color})
    bids=[("a",a),("b",b)]; frames=[]
    for fi in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c); _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_moving_cart_hits_stationary_cart")
    print("OK")
