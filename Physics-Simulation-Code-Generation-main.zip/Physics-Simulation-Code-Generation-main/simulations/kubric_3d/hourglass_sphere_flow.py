"""hourglass_sphere_flow — spheres drain through a narrow neck."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np
CAM_EYE=(3.5,-3.5,2.5); CAM_TARGET=(0.0,0.0,1.5); N_FRAMES=180
@dataclass
class Params:
    seed: int; n_balls: int; ball_r: float; mass: float
    friction: float; restitution: float; neck_w: float
    colors: List[List[float]]
def random_params(seed):
    random.seed(seed); np.random.seed(seed)
    r=random.uniform(0.04,0.07)
    return Params(seed=seed,n_balls=random.randint(15,28),ball_r=r,
                  mass=random.uniform(0.01,0.08),friction=random.uniform(0.2,0.5),
                  restitution=random.uniform(0.2,0.5),neck_w=random.uniform(r*1.3,r*2.2),
                  colors=[[random.random(),random.random(),random.random(),1.0]
                          for _ in range(30)])
def generate_sample(seed, out_dir):
    _dir=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0,_dir)
    from simulations.kubric_3d._base import (Physics,Renderer,run_loop,save_sample,
        build_cot,param_entry,muted_grey,STANDALONE_IMPORTS,STANDALONE_UTILS)
    import pybullet as pb
    random.seed(seed); np.random.seed(seed)
    p=random_params(seed)
    phys=Physics(); ren=Renderer(CAM_EYE,CAM_TARGET)
    phys.add_plane(friction=p.friction); ren.add_plane_mesh("fl",4.0,muted_grey())
    nr = p.neck_w / 2  # half-width of neck
    outer_half = 0.5   # half-width of outer wall
    wall_height = 1.5  # height of each wall panel
    wall_center_z = 2.0  # center height of walls

    # 4 walls forming a box with central neck opening
    for wname, he, pos in [
        ("wL", [outer_half, 0.85, wall_height/2], [-(nr + outer_half), 0, wall_center_z]),
        ("wR", [outer_half, 0.85, wall_height/2], [ (nr + outer_half), 0, wall_center_z]),
        ("wF", [nr + outer_half*2 + 0.02, 0.85, wall_height/2], [0, -(0.9), wall_center_z]),
        ("wB", [nr + outer_half*2 + 0.02, 0.85, wall_height/2], [0,  (0.9), wall_center_z])]:
        phys.add_box(he, pos, mass=0, friction=0.3, restitution=0.4)
        ren.add_box(wname, he, [0.5, 0.5, 0.55, 0.7])
        ren.set_static_pose(wname, pos)
    dyn=[]
    for i in range(p.n_balls):
        x=(i%4-1.5)*p.ball_r*2.5; y=(i//4%4-1.5)*p.ball_r*2.5; z=2.0+(i//16)*p.ball_r*2.5
        bid=phys.add_sphere(p.ball_r,[x,y,z],mass=p.mass,friction=p.friction,restitution=p.restitution)
        ren.add_sphere(f"b{i}",p.ball_r,p.colors[i]); dyn.append((f"b{i}",bid))
    frames=run_loop(phys,ren,dyn,N_FRAMES)
    cot=build_cot("hourglass_sphere_flow","rigid_body_free_dynamics",seed,
        f"{p.n_balls} balls r={p.ball_r:.3f}m through neck {p.neck_w*2:.3f}m",
        "Granular flow through constriction","Balls r<neck_w pass; larger jam",
        "Q prop (D_neck - d_ball)^{5/2}",
        ["Rigid spheres","Funnel walls frictionless","Jamming if r near neck_w/2"],
        ["r (m)","v (m/s)","q","w (rad/s)"],
        ["dot_r=v","m*dot_v=mg+Fc","I*dot_w=tc"],
        "j=-(1+e)*v_n/(1/mA+1/mB)",
        ["Balls fall under gravity","Neck allows only r<neck_w balls",
         "Larger balls rest on funnel walls"],
        [f"All {p.n_balls} balls attempt to flow through",
         f"Balls with r={p.ball_r:.3f}m < neck_w={p.neck_w:.3f}m pass through",
         "Others rest on funnel geometry"],
        {k:param_entry(getattr(p,k),"",k) for k in ["n_balls","ball_r","mass","friction","neck_w"]})
    save_sample(out_dir,asdict(p),cot,make_standalone_code(p),frames)
    phys.close(); ren.close()
def make_standalone_code(p):
    _dir=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0,_dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS,STANDALONE_UTILS
    body=f"""
# hourglass_sphere_flow  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}
def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    nw={p.neck_w}
    for he,pos in [([0.70,0.04,0.60],[-nw-0.40,0,1.80]),([0.70,0.04,0.60],[nw+0.40,0,1.80]),
                   ([0.04,0.70,0.60],[0,-nw-0.40,1.80]),([0.04,0.70,0.60],[0,nw+0.40,1.80])]:
        s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=he,physicsClientId=c)
        pb.createMultiBody(0,s,-1,pos,[0,0,0,1],physicsClientId=c)
    bids=[]; clr={p.colors[:p.n_balls]}
    for i in range({p.n_balls}):
        x=(i%4-1.5)*{p.ball_r}*2.5; y=(i//4%4-1.5)*{p.ball_r}*2.5; z=2.0+(i//16)*{p.ball_r}*2.5
        s=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.ball_r},physicsClientId=c)
        bid=pb.createMultiBody({p.mass},s,-1,[x,y,z],[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
        _add_sphere(sc,f"b{{i}}",nodes,{p.ball_r},clr[i%len(clr)]); bids.append((f"b{{i}}",bid))
    _add_box(sc,"fl",nodes,[2.5,2.5,0.02],[0.4,0.4,0.43,1.0]); _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    frames=[]
    for _ in range({N_FRAMES}):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""
    return STANDALONE_IMPORTS+STANDALONE_UTILS+body
if __name__=="__main__":
    generate_sample(seed=0,out_dir="/tmp/test_hourglass"); print("OK")
