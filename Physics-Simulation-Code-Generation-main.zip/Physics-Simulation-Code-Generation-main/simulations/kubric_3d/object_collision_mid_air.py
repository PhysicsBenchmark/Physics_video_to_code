"""object_collision_mid_air — two objects launched toward each other collide mid-air."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (0, -6, 4)
CAM_TARGET = (0, 0, 1.5)
N_FRAMES   = 120


@dataclass
class Params:
    seed: int
    mass_a: float
    mass_b: float
    radius_a: float
    radius_b: float
    speed_a: float
    speed_b: float
    height: float
    obj_b_type: str   # "sphere" or "box"
    restitution: float
    floor_friction: float
    color_a: List[float]
    color_b: List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        mass_a=random.uniform(0.5, 3.0),
        mass_b=random.uniform(0.5, 3.0),
        radius_a=random.uniform(0.10, 0.22),
        radius_b=random.uniform(0.10, 0.22),
        speed_a=random.uniform(2.0, 6.0),
        speed_b=random.uniform(2.0, 6.0),
        height=random.uniform(1.0, 3.0),
        obj_b_type=random.choice(["sphere", "box"]),
        restitution=random.uniform(0.3, 0.8),
        floor_friction=random.uniform(0.4, 0.7),
        color_a=_rand_hue(),
        color_b=_rand_hue(),
    )


def _rand_hue():
    h = random.random(); s, v = 0.85, 0.90
    hi = int(h*6) % 6; f = h*6 - int(h*6)
    p_ = v*(1-s); q = v*(1-f*s); t = v*(1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return [r, g, b, 1.0]


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 10.0, [0.42, 0.42, 0.45, 1.0])

    # Object A: sphere launched from x=-4 in +X direction
    pos_a = [-4.0, 0.0, p.height]
    id_a = phys.add_sphere(p.radius_a, pos_a,
                            mass=p.mass_a, friction=p.floor_friction,
                            restitution=p.restitution,
                            vel=(p.speed_a, 0.0, 0.0))
    ren.add_sphere("obj_a", p.radius_a, p.color_a, metallic=0.1, roughness=0.3)
    ren.set_static_pose("obj_a", pos_a)

    # Object B: sphere or box launched from x=+4 in -X direction
    pos_b = [4.0, 0.0, p.height]
    he_b = [p.radius_b, p.radius_b, p.radius_b]
    if p.obj_b_type == "sphere":
        id_b = phys.add_sphere(p.radius_b, pos_b,
                                mass=p.mass_b, friction=p.floor_friction,
                                restitution=p.restitution,
                                vel=(-p.speed_b, 0.0, 0.0))
        ren.add_sphere("obj_b", p.radius_b, p.color_b, metallic=0.1, roughness=0.3)
    else:
        id_b = phys.add_box(he_b, pos_b, mass=p.mass_b, friction=p.floor_friction,
                             restitution=p.restitution,
                             vel=(-p.speed_b, 0.0, 0.0))
        ren.add_box("obj_b", he_b, p.color_b)
    ren.set_static_pose("obj_b", pos_b)

    dyn = [("obj_a", id_a), ("obj_b", id_b)]
    frames = run_loop(phys, ren, dyn, N_FRAMES)

    # Conservation of momentum
    p_total_x = p.mass_a * p.speed_a - p.mass_b * p.speed_b
    vcm = p_total_x / (p.mass_a + p.mass_b)
    cot = build_cot(
        simulation="object_collision_mid_air",
        category="mixed_complex",
        seed=seed,
        physical_observation=(
            f"Sphere A (r={p.radius_a:.2f}m, m={p.mass_a:.2f}kg) launched at v={p.speed_a:.1f}m/s +X "
            f"from x=-4; {p.obj_b_type} B (r={p.radius_b:.2f}m, m={p.mass_b:.2f}kg) launched at "
            f"v={p.speed_b:.1f}m/s -X from x=+4; both at height={p.height:.2f}m; collide at center."
        ),
        law_name="Conservation of momentum + Newton contact impulse",
        law_statement=(
            "Total linear momentum conserved during collision; "
            "impulse exchanges momentum between objects; "
            "energy may be lost based on restitution coefficient."
        ),
        law_formula="m_A v_A + m_B v_B = const; j = -(1+e)·v_rel / (1/m_A + 1/m_B)",
        assumptions=[
            "Rigid spheres/box; point contact approximation",
            "Normal impulse only (no friction during collision)",
            "Gravity acts throughout trajectory",
            "No air resistance",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "m_A v_{A,x} + m_B v_{B,x} = p_x = const",
            "v_{A,x}'=v_{A,x}+j/m_A",
            "v_{B,x}'=v_{B,x}-j/m_B",
            "j=-(1+e)(v_{A,x}-v_{B,x})/(1/m_A+1/m_B)",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            f"Relative velocity at collision: v_rel = {p.speed_a:.1f} + {p.speed_b:.1f} = {p.speed_a+p.speed_b:.1f} m/s",
            f"Total momentum p_x = {p.mass_a:.2f}×{p.speed_a:.1f} - {p.mass_b:.2f}×{p.speed_b:.1f} = {p_total_x:.2f} kg·m/s",
            f"CM velocity v_cm = {vcm:.3f} m/s",
            f"Impulse magnitude j = -(1+{p.restitution:.2f})×{p.speed_a+p.speed_b:.1f}/(1/{p.mass_a:.2f}+1/{p.mass_b:.2f}) = {-(1+p.restitution)*(p.speed_a+p.speed_b)/(1/p.mass_a+1/p.mass_b):.3f} N·s",
            "Objects scatter; heavier object continues in original direction",
        ],
        expected_behavior=[
            "Both objects approach each other from opposite sides",
            "Collision near x=0 (center) at height above floor",
            "Objects scatter based on mass ratio and restitution",
            "Objects land on floor and slide/roll to rest",
        ],
        parameters={
            "mass_a":       param_entry(p.mass_a,       "kg",  "mass of object A (sphere)"),
            "mass_b":       param_entry(p.mass_b,       "kg",  "mass of object B"),
            "radius_a":     param_entry(p.radius_a,     "m",   "radius of object A"),
            "radius_b":     param_entry(p.radius_b,     "m",   "radius/half-extent of object B"),
            "speed_a":      param_entry(p.speed_a,      "m/s", "launch speed of A"),
            "speed_b":      param_entry(p.speed_b,      "m/s", "launch speed of B"),
            "height":       param_entry(p.height,       "m",   "launch height above floor"),
            "obj_b_type":   param_entry(p.obj_b_type,   "",    "type of object B: sphere or box"),
            "restitution":  param_entry(p.restitution,  "",    "coefficient of restitution"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    he_b = [p.radius_b, p.radius_b, p.radius_b]
    if p.obj_b_type == "sphere":
        obj_b_phys = (
            f"    sb2=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.radius_b},physicsClientId=c)\n"
            f"    obj_b=pb.createMultiBody({p.mass_b},sb2,-1,[4,0,{p.height:.3f}],[0,0,0,1],physicsClientId=c)\n"
            f"    pb.changeDynamics(obj_b,-1,lateralFriction={p.floor_friction},restitution={p.restitution},physicsClientId=c)\n"
            f"    pb.resetBaseVelocity(obj_b,[{-p.speed_b},0,0],[0,0,0],physicsClientId=c)\n"
            f"    _add_sphere(sc,'obj_b',nodes,{p.radius_b},{p.color_b})\n"
            f"    _set_pose(sc,nodes['obj_b'],[4,0,{p.height:.3f}],[0,0,0,1])\n"
        )
    else:
        obj_b_phys = (
            f"    sb2=pb.createCollisionShape(pb.GEOM_BOX,halfExtents={he_b},physicsClientId=c)\n"
            f"    obj_b=pb.createMultiBody({p.mass_b},sb2,-1,[4,0,{p.height:.3f}],[0,0,0,1],physicsClientId=c)\n"
            f"    pb.changeDynamics(obj_b,-1,lateralFriction={p.floor_friction},restitution={p.restitution},physicsClientId=c)\n"
            f"    pb.resetBaseVelocity(obj_b,[{-p.speed_b},0,0],[0,0,0],physicsClientId=c)\n"
            f"    _add_box(sc,'obj_b',nodes,{he_b},{p.color_b})\n"
            f"    _set_pose(sc,nodes['obj_b'],[4,0,{p.height:.3f}],[0,0,0,1])\n"
        )
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# object_collision_mid_air  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[5.0,5.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    sa=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.radius_a},physicsClientId=c)
    obj_a=pb.createMultiBody({p.mass_a},sa,-1,[-4,0,{p.height:.3f}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(obj_a,-1,lateralFriction={p.floor_friction},restitution={p.restitution},physicsClientId=c)
    pb.resetBaseVelocity(obj_a,[{p.speed_a},0,0],[0,0,0],physicsClientId=c)
    _add_sphere(sc,"obj_a",nodes,{p.radius_a},{p.color_a})
    _set_pose(sc,nodes["obj_a"],[-4,0,{p.height:.3f}],[0,0,0,1])
{obj_b_phys}    bids=[("obj_a",obj_a),("obj_b",obj_b)]
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete()
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_object_collision_mid_air")
    print("OK")
