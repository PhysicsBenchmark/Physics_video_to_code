"""ragdoll_free_fall — jointed capsule ragdoll dropped from height, lands and sprawls."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (5, -3, 5)
CAM_TARGET = (0, 0, 1.5)
N_FRAMES   = 150


@dataclass
class Params:
    seed: int
    torso_mass: float
    limb_mass: float
    drop_height: float
    torso_radius: float
    torso_height: float
    limb_radius: float
    limb_height: float
    restitution: float
    friction: float
    color_torso: List[float]
    color_limbs: List[float]


def _rand_color():
    h = random.random()
    s, v = 0.85, 0.90
    hi = int(h * 6) % 6
    f  = h * 6 - int(h * 6)
    p_ = v * (1 - s); q = v * (1 - f*s); t = v * (1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return [r, g, b, 1.0]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        torso_mass=random.uniform(5.0, 15.0),
        limb_mass=random.uniform(0.5, 2.0),
        drop_height=random.uniform(3.0, 5.0),
        torso_radius=random.uniform(0.12, 0.18),
        torso_height=random.uniform(0.40, 0.60),
        limb_radius=random.uniform(0.05, 0.09),
        limb_height=random.uniform(0.25, 0.40),
        restitution=random.uniform(0.1, 0.4),
        friction=random.uniform(0.3, 0.7),
        color_torso=_rand_color(),
        color_limbs=_rand_color(),
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.friction)
    ren.add_plane_mesh("floor", 10.0, [0.42, 0.42, 0.45, 1.0])

    dyn = []
    # Torso at drop height — give small lateral angular velocity so it tips sideways on landing
    torso_pos = [0.0, 0.0, p.drop_height]
    torso_id = phys.add_capsule(
        radius=p.torso_radius, height=p.torso_height,
        pos=torso_pos, mass=p.torso_mass,
        friction=p.friction, restitution=p.restitution,
        ang_vel=(0.0, 0.5, 0.0))   # slow rotation around Y → tips sideways after landing
    ren.add_capsule("torso", p.torso_radius, p.torso_height, p.color_torso)
    ren.set_static_pose("torso", torso_pos)
    dyn.append(("torso", torso_id))

    # Limb layout: 2 arms (upper body sides) + 2 legs (lower body)
    # Arm offsets from torso center
    torso_top = p.torso_height / 2.0
    torso_bot = -p.torso_height / 2.0
    arm_offset_z = torso_top * 0.5  # mid-upper torso
    leg_offset_z = torso_bot * 0.5  # mid-lower torso

    limb_configs = [
        # name, offset from torso center, orientation (euler xyz)
        ("arm_l", [-p.torso_radius - p.limb_height * 0.5, 0.0, arm_offset_z], [0, math.pi/2, 0]),
        ("arm_r", [ p.torso_radius + p.limb_height * 0.5, 0.0, arm_offset_z], [0, math.pi/2, 0]),
        ("leg_l", [-p.torso_radius * 0.5, 0.0, torso_bot - p.limb_height * 0.6], [0, 0, 0]),
        ("leg_r", [ p.torso_radius * 0.5, 0.0, torso_bot - p.limb_height * 0.6], [0, 0, 0]),
    ]

    for name, offset, euler in limb_configs:
        lpos = [torso_pos[0] + offset[0],
                torso_pos[1] + offset[1],
                torso_pos[2] + offset[2]]
        orn = pb_mod.getQuaternionFromEuler(euler)
        lid = phys.add_capsule(
            radius=p.limb_radius, height=p.limb_height,
            pos=lpos, orn=orn,
            mass=p.limb_mass,
            friction=p.friction, restitution=p.restitution)

        # Connect limb to torso with JOINT_POINT2POINT at contact point
        # Attachment point in torso frame: the offset direction
        attach_torso = [offset[0] * 0.5, offset[1] * 0.5, offset[2]]
        attach_limb  = [0.0, 0.0, p.limb_height * 0.5 + p.limb_radius * 0.3]

        phys.create_constraint(
            torso_id, -1, lid, -1,
            pb_mod.JOINT_POINT2POINT, [0, 0, 0],
            attach_torso, attach_limb,
            max_force=300.0)

        ren.add_capsule(name, p.limb_radius, p.limb_height, p.color_limbs)
        ren.set_static_pose(name, lpos, orn)
        dyn.append((name, lid))

    # Head (small sphere on top of torso)
    head_pos = [torso_pos[0], torso_pos[1],
                torso_pos[2] + p.torso_height / 2.0 + p.torso_radius * 0.9]
    head_r = p.torso_radius * 0.55
    head_id = phys.add_sphere(
        radius=head_r, pos=head_pos, mass=p.limb_mass * 0.5,
        friction=p.friction, restitution=p.restitution)
    phys.create_constraint(
        torso_id, -1, head_id, -1,
        pb_mod.JOINT_POINT2POINT, [0, 0, 0],
        [0.0, 0.0, p.torso_height / 2.0],
        [0.0, 0.0, -head_r],
        max_force=300.0)
    ren.add_sphere("head", head_r, p.color_torso)
    ren.set_static_pose("head", head_pos)
    dyn.append(("head", head_id))

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    t_fall = math.sqrt(2 * p.drop_height / 9.81)
    v_impact = 9.81 * t_fall
    cot = build_cot(
        simulation="ragdoll_free_fall",
        category="articulated_jointed",
        seed=seed,
        physical_observation=(
            f"Ragdoll: torso m={p.torso_mass:.1f}kg r={p.torso_radius:.2f}m h={p.torso_height:.2f}m, "
            f"4 limbs + head, dropped from {p.drop_height:.1f}m. "
            f"Impact velocity ~{v_impact:.2f} m/s."
        ),
        law_name="Multi-body constrained dynamics with impact",
        law_statement=(
            "A jointed rigid body system falls under gravity; on impact, "
            "contact impulses propagate through JOINT_POINT2POINT constraints, "
            "causing limbs to sprawl."
        ),
        law_formula="v_impact = sqrt(2·g·h); j = -(1+e)·v_n / Σ(1/m_i)",
        assumptions=[
            "Capsule primitives for all body segments",
            "JOINT_POINT2POINT constraints allow free rotation",
            "Inelastic contact with floor",
            "No muscle forces; purely passive joints",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg+F_c+T_{\\text{joint}}",
            "v_{\\text{impact}} = \\sqrt{2gh}",
            "j = -(1+e)v_n / \\sum_i 1/m_i",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            f"Free fall: t = sqrt(2h/g) = {t_fall:.3f} s",
            f"Impact velocity: v = sqrt(2gh) = {v_impact:.3f} m/s",
            "Torso impact impulse: j = -(1+e)·m_torso·v_n",
            "Constraint forces transmit impulse to limbs",
            "Limbs rotate around attachment points due to angular impulse",
        ],
        expected_behavior=[
            "Ragdoll falls freely from height",
            "Torso impacts floor first",
            "Limbs swing and sprawl outward",
            "System settles on floor in crumpled pose",
        ],
        parameters={
            "torso_mass":   param_entry(p.torso_mass,   "kg", "torso mass"),
            "limb_mass":    param_entry(p.limb_mass,    "kg", "mass per limb"),
            "drop_height":  param_entry(p.drop_height,  "m",  "initial drop height"),
            "torso_radius": param_entry(p.torso_radius, "m",  "torso capsule radius"),
            "torso_height": param_entry(p.torso_height, "m",  "torso capsule height"),
            "limb_radius":  param_entry(p.limb_radius,  "m",  "limb capsule radius"),
            "limb_height":  param_entry(p.limb_height,  "m",  "limb capsule height"),
            "restitution":  param_entry(p.restitution,  "",   "coefficient of restitution"),
            "friction":     param_entry(p.friction,     "",   "friction coefficient"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    import pybullet as _pb
    torso_pos = [0.0, 0.0, p.drop_height]
    torso_top = p.torso_height / 2.0
    torso_bot = -p.torso_height / 2.0
    arm_offset_z = torso_top * 0.5
    leg_offset_z = torso_bot * 0.5
    head_r = p.torso_radius * 0.55
    head_pos = [torso_pos[0], torso_pos[1],
                torso_pos[2] + p.torso_height / 2.0 + p.torso_radius * 0.9]

    limb_configs = [
        ("arm_l", [-p.torso_radius - p.limb_height * 0.5, 0.0, arm_offset_z], [0, math.pi/2, 0]),
        ("arm_r", [ p.torso_radius + p.limb_height * 0.5, 0.0, arm_offset_z], [0, math.pi/2, 0]),
        ("leg_l", [-p.torso_radius * 0.5, 0.0, torso_bot - p.limb_height * 0.6], [0, 0, 0]),
        ("leg_r", [ p.torso_radius * 0.5, 0.0, torso_bot - p.limb_height * 0.6], [0, 0, 0]),
    ]

    limb_lines = []
    for lname, offset, euler in limb_configs:
        lpos = [torso_pos[0] + offset[0],
                torso_pos[1] + offset[1],
                torso_pos[2] + offset[2]]
        orn = list(_pb.getQuaternionFromEuler(euler))
        attach_torso = [offset[0] * 0.5, offset[1] * 0.5, offset[2]]
        attach_limb  = [0.0, 0.0, p.limb_height * 0.5 + p.limb_radius * 0.3]
        limb_lines.append(
            f"    sl=pb.createCollisionShape(pb.GEOM_CAPSULE,radius={p.limb_radius},height={p.limb_height},physicsClientId=c)\n"
            f"    lid=pb.createMultiBody({p.limb_mass},sl,-1,{lpos},{orn},physicsClientId=c)\n"
            f"    pb.changeDynamics(lid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)\n"
            f"    cid=pb.createConstraint(torso,-1,lid,-1,pb.JOINT_POINT2POINT,[0,0,0],{attach_torso},{attach_limb},physicsClientId=c)\n"
            f"    pb.changeConstraint(cid,maxForce=300,physicsClientId=c)\n"
            f"    _add_capsule(sc,'{lname}',nodes,{p.limb_radius},{p.limb_height},{p.color_limbs})\n"
            f"    _set_pose(sc,nodes['{lname}'],{lpos},{orn})\n"
            f"    bids.append(('{lname}',lid))\n"
        )
    limb_code = "".join(limb_lines)

    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# ragdoll_free_fall  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[5.0,5.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    # torso
    st=pb.createCollisionShape(pb.GEOM_CAPSULE,radius={p.torso_radius},height={p.torso_height},physicsClientId=c)
    torso=pb.createMultiBody({p.torso_mass},st,-1,{torso_pos},[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(torso,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
    _add_capsule(sc,"torso",nodes,{p.torso_radius},{p.torso_height},{p.color_torso})
    bids=[("torso",torso)]
{limb_code}
    # head
    sh=pb.createCollisionShape(pb.GEOM_SPHERE,radius={head_r:.4f},physicsClientId=c)
    head=pb.createMultiBody({p.limb_mass*0.5},sh,-1,{head_pos},[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(head,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
    cid=pb.createConstraint(torso,-1,head,-1,pb.JOINT_POINT2POINT,[0,0,0],[0,0,{p.torso_height/2.0:.4f}],[0,0,{-head_r:.4f}],physicsClientId=c)
    pb.changeConstraint(cid,maxForce=300,physicsClientId=c)
    _add_sphere(sc,"head",nodes,{head_r:.4f},{p.color_torso})
    bids.append(("head",head))
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_ragdoll_free_fall")
    print("OK")
