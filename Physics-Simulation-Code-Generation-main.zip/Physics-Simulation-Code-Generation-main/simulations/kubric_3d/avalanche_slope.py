"""avalanche_slope — objects released from inclined plane when barrier removed."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np
CAM_EYE=(8.0,-5.0,4.0); CAM_TARGET=(1.0,1.0,0.5); N_FRAMES=150
@dataclass
class Params:
    seed: int
    angle_deg:float
    n_objects:int
    masses:List[float]
    radii:List[float]
    frictions:List[float]
    restitutions:List[float]
    colors:List[List[float]]
def random_params(seed):
    random.seed(seed); np.random.seed(seed)
    n=random.randint(8,15); a=random.uniform(25.0,42.0)
    return Params(seed=seed,angle_deg=a,n_objects=n,
        masses=[random.uniform(0.2,2.5) for _ in range(n)],
        radii=[random.uniform(0.08,0.22) for _ in range(n)],
        frictions=[random.uniform(0.15,0.60) for _ in range(n)],
        restitutions=[random.uniform(0.25,0.75) for _ in range(n)],
        colors=[[random.random(),random.random(),random.random(),1.0] for _ in range(n)])
def generate_sample(seed, out_dir):
    _dir=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0,_dir)
    from simulations.kubric_3d._base import (Physics,Renderer,run_loop,save_sample,
        build_cot,param_entry,muted_grey,random_hue_color,STANDALONE_IMPORTS,STANDALONE_UTILS)
    import pybullet as pb
    random.seed(seed); np.random.seed(seed)
    p=random_params(seed)
    phys=Physics(); ren=Renderer(CAM_EYE,CAM_TARGET)
    _dyn=[]; _extra_sync=None
    p=random_params(seed)
    phys.add_box([15,15,0.1],[0,0,-0.1],mass=0,friction=0.5,restitution=0.4)
    ren.add_plane_mesh("fl",30.0,muted_grey())
    ang_r=math.radians(p.angle_deg); ramp_len=4.5
    cx=ramp_len/2*math.cos(ang_r); cz=ramp_len/2*math.sin(ang_r)
    orn_q=pb.getQuaternionFromEuler([0,-ang_r,0])
    phys.add_box([ramp_len/2,0.85,0.10],[cx,0,cz+0.10],orn=orn_q,mass=0,friction=0.4)
    ren.add_box("ramp",[ramp_len/2,0.85,0.10],[0.55,0.50,0.45,1.0])
    ren.set_static_pose("ramp",[cx,0,cz+0.10],orn_q)
    bar_pos=[ramp_len*0.85*math.cos(ang_r),0,ramp_len*0.85*math.sin(ang_r)+0.20]
    barrier_id=phys.add_box([0.08,0.85,0.28],bar_pos,mass=0)
    ren.add_box("bar",[0.08,0.85,0.28],[0.8,0.2,0.2,1.0]); ren.set_static_pose("bar",bar_pos)
    _pc=phys.client; _rem=[False]
    for i in range(p.n_objects):
        t=0.3+i*0.25; ox=t*math.cos(ang_r)+(i%3-1)*0.18
        oz=t*math.sin(ang_r)+0.20+p.radii[i]
        bid=phys.add_sphere(p.radii[i],[ox,(i%3-1)*0.22,oz],mass=p.masses[i],
                            friction=p.frictions[i],restitution=p.restitutions[i])
        ren.add_sphere(f"o{i}",p.radii[i],p.colors[i]); _dyn.append((f"o{i}",bid))
    def _extra_sync(ph,re,fi):
        if fi==30 and not _rem[0]:
            pb.removeBody(barrier_id,physicsClientId=_pc); _rem[0]=True
    frames=run_loop(phys,ren,_dyn,N_FRAMES,extra_sync_fn=_extra_sync)
    cot=build_cot("avalanche_slope","rigid_body",seed,
        f"{p.n_objects} objects on {p.angle_deg:.1f}° slope; barrier removed at t=1 s.",
        "Inclined-plane dynamics","Slides if mu<tan(theta); rolls otherwise",r"a=g(sin theta - mu cos theta)",
        ["Rigid objects","Ramp rigid and fixed","Rolling w/o slipping when mu>(2/7)tan(theta)"],
        ["r (m)","v (m/s)","q","w (rad/s)"],
        ["dot_r=v","m*dot_v=mg+Fc","I*dot_w=tc-wxIw"],
        "j=-(1+e)*v_n/(1/mA+1/mB+cross)",
        ["Gravity along ramp: F=mg sin(theta)","Friction: f=mu mg cos(theta)","Net a=g(sin-mu*cos)"],["Objects slide/roll down after barrier removed","Heavier objects same acceleration (galileo)","High friction objects may not slide if mu>tan(theta)"],
        {k:param_entry(getattr(p,k),"",k) for k in ["angle_deg","n_objects","masses","frictions","restitutions"]})
    save_sample(out_dir,asdict(p),cot,make_standalone_code(p),frames)
    phys.close(); ren.close()
def make_standalone_code(p):
    _dir=os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0,_dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS,STANDALONE_UTILS
    body=f"""
# avalanche_slope  seed={p.seed}
import pybullet as pb
N_FRAMES=150; CAM_EYE=(8.0,-5.0,4.0); CAM_TARGET=(1.0,1.0,0.5)
def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    import math
    ang_r=math.radians({p.angle_deg}); ramp_len=4.5
    cx=ramp_len/2*math.cos(ang_r); cz=ramp_len/2*math.sin(ang_r)
    orn_q=pb.getQuaternionFromEuler([0,-ang_r,0])
    s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[ramp_len/2,0.85,0.10],physicsClientId=c)
    pb.createMultiBody(0,s,-1,[cx,0,cz+0.10],orn_q,physicsClientId=c)
    _add_box(sc,"ramp",nodes,[ramp_len/2,0.85,0.10],[0.55,0.50,0.45,1.0])
    _set_pose(sc,nodes["ramp"],[cx,0,cz+0.10],orn_q)
    sb=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[0.08,0.85,0.28],physicsClientId=c)
    bar_id=pb.createMultiBody(0,sb,-1,[{p.angle_deg}*0.0+ramp_len*0.85*math.cos(ang_r),0,ramp_len*0.85*math.sin(ang_r)+0.20],[0,0,0,1],physicsClientId=c)
    radii={p.radii}; masses={p.masses}; frics={p.frictions}; rests={p.restitutions}; colors={p.colors}
    bids=[]
    for i in range({p.n_objects}):
        t=0.3+i*0.25; ox=t*math.cos(ang_r)+(i%3-1)*0.18; oz=t*math.sin(ang_r)+0.20+radii[i]
        s=pb.createCollisionShape(pb.GEOM_SPHERE,radius=radii[i],physicsClientId=c)
        bid=pb.createMultiBody(masses[i],s,-1,[ox,(i%3-1)*0.22,oz],[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction=frics[i],restitution=rests[i],physicsClientId=c)
        _add_sphere(sc,f"o{{i}}",nodes,radii[i],colors[i]); bids.append((f"o{{i}}",bid))
    _add_box(sc,"fl",nodes,[5,5,0.02],muted_grey()); _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    frames=[]; removed=False
    for fi in range(150):
        if fi==30 and not removed: pb.removeBody(bar_id,physicsClientId=c); removed=True
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""
    return STANDALONE_IMPORTS+STANDALONE_UTILS+body
if __name__=="__main__":
    generate_sample(seed=0,out_dir=f"/tmp/test_avalanche_slope"); print("OK")
