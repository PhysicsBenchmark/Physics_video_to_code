"""gyroscope_on_stand — spinning rotor on a stand precesses under gravity."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (3.0, -4.0, 2.0)
CAM_TARGET = (0.0,  0.0, 1.2)
N_FRAMES   = 120


@dataclass
class Params:
    seed: int
    omega_spin: float
    rotor_mass: float
    rotor_R: float
    L_axle: float
    beta_deg: float
    rotor_color: List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    h = random.random(); s, v = 0.85, 0.90; hi = int(h*6) % 6; f = h*6 - int(h*6)
    p_ = v*(1-s); q = v*(1-f*s); t = v*(1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return Params(seed=seed, omega_spin=random.uniform(22.0, 40.0),
                  rotor_mass=random.uniform(0.4, 0.9), rotor_R=random.uniform(0.22, 0.32),
                  L_axle=random.uniform(0.40, 0.60), beta_deg=random.uniform(12.0, 28.0),
                  rotor_color=[r, g, b, 1.0])


def _quat_mul(p, q):
    px, py, pz, pw = p; qx, qy, qz, qw = q
    return [pw*qx+px*qw+py*qz-pz*qy, pw*qy-px*qz+py*qw+pz*qx,
            pw*qz+px*qy-py*qx+pz*qw, pw*qw-px*qx-py*qy-pz*qz]


def _axle_orient(phi, beta):
    sin_half = math.sqrt((1 - math.sin(beta)) / 2)
    cos_half = math.sqrt((1 + math.sin(beta)) / 2)
    return [-math.sin(phi)*sin_half, math.cos(phi)*sin_half, 0.0, cos_half]


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Renderer, save_sample, build_cot, param_entry,
        STANDALONE_IMPORTS, STANDALONE_UTILS, FPS)

    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    ren = Renderer(CAM_EYE, CAM_TARGET)

    g = 9.81
    beta = math.radians(p.beta_deg)
    I_rotor = 0.5 * p.rotor_mass * p.rotor_R**2
    tau = p.rotor_mass * g * p.L_axle * math.cos(beta)
    L_ang = I_rotor * p.omega_spin
    Omega_p = tau / L_ang
    h_pivot = 1.25

    ren.add_plane_mesh("floor", 8.0, [0.38, 0.38, 0.42, 1.0])
    ren.set_static_pose("floor", [0, 0, -0.02])
    ren.add_cylinder("pole", 0.04, h_pivot, [0.50, 0.42, 0.32, 1.0])
    ren.set_static_pose("pole", [0.0, 0.0, h_pivot/2])
    ren.add_box("base", [0.18, 0.18, 0.03], [0.60, 0.50, 0.45, 1.0])
    ren.set_static_pose("base", [0.0, 0.0, 0.03])
    ren.add_sphere("pivot_m", 0.05, [0.80, 0.80, 0.80, 1.0])
    ren.set_static_pose("pivot_m", [0.0, 0.0, h_pivot])
    ren.add_cylinder("rotor", p.rotor_R, 0.06, p.rotor_color)
    ren.add_sphere("axle_tip", 0.04, [0.70, 0.70, 0.70, 1.0])

    pivot = [0.0, 0.0, h_pivot]

    frames = []
    for fi in range(N_FRAMES):
        t = fi / float(FPS)
        phi = Omega_p * t
        theta_s = p.omega_spin * t
        ax_dir = [math.cos(beta)*math.cos(phi), math.cos(beta)*math.sin(phi), math.sin(beta)]
        rc = [pivot[0]+p.L_axle*ax_dir[0], pivot[1]+p.L_axle*ax_dir[1], pivot[2]+p.L_axle*ax_dir[2]]
        q_orient = _axle_orient(phi, beta)
        s2 = math.sin(theta_s/2)
        q_spin = [ax_dir[0]*s2, ax_dir[1]*s2, ax_dir[2]*s2, math.cos(theta_s/2)]
        q_rotor = _quat_mul(q_spin, q_orient)
        ren.set_pose("axle_tip", rc, [0, 0, 0, 1])
        ren.set_pose("rotor", rc, q_rotor)
        ren.update_string("axle", pivot, rc, 0.025, [0.55, 0.55, 0.60, 1.0])
        frames.append(ren.render_frame())

    cot = build_cot(
        simulation="gyroscope_on_stand",
        category="rigid_body_constrained",
        seed=seed,
        physical_observation=(
            f"Gyroscope rotor (m={p.rotor_mass:.2f}kg, R={p.rotor_R:.2f}m) "
            f"spins at ω={p.omega_spin:.1f}rad/s, lean β={p.beta_deg:.1f}°. "
            f"Precesses at Ω_p={Omega_p:.2f}rad/s."
        ),
        law_name="Gyroscopic precession — angular momentum",
        law_statement="Ω_p = τ/L = Mgd/(Iω_spin). Gravity torque changes L direction steadily.",
        law_formula="\\Omega_p=\\frac{MgL\\cos\\beta}{I\\omega_{spin}};\\quad I=\\tfrac{1}{2}mR^2",
        assumptions=[
            "Steady precession (no nutation).",
            "Rotor modelled as thin disc: I=½mR².",
            "Pivot is frictionless point support.",
        ],
        state_variables=["φ_precess (rad)", "θ_spin (rad)", "axle direction (unit vec)"],
        equations_latex=[
            "I=\\tfrac{1}{2}mR^2",
            "\\tau=MgL\\cos\\beta",
            "\\Omega_p=\\tau/(I\\omega)",
        ],
        contact_impulse="N/A (kinematic precession)",
        derivation_steps=[
            f"I = ½×{p.rotor_mass:.2f}×{p.rotor_R:.2f}² = {I_rotor:.4f} kg·m²",
            f"τ = {p.rotor_mass:.2f}×9.81×{p.L_axle:.2f}×cos({p.beta_deg:.1f}°) = {tau:.3f} N·m",
            f"L = {I_rotor:.4f}×{p.omega_spin:.1f} = {L_ang:.3f} kg·m²/s",
            f"Ω_p = {tau:.3f}/{L_ang:.3f} = {Omega_p:.3f} rad/s",
        ],
        expected_behavior=[
            f"Rotor spins fast at {p.omega_spin:.1f} rad/s.",
            f"Axle sweeps around vertical at {Omega_p:.2f} rad/s.",
            f"Full precession period: {2*math.pi/Omega_p:.1f}s.",
            "Gyroscope resists gravity — angular momentum maintained.",
        ],
        parameters={
            "omega_spin": param_entry(p.omega_spin, "rad/s", "rotor spin rate"),
            "rotor_mass": param_entry(p.rotor_mass, "kg",   "rotor mass"),
            "rotor_R":    param_entry(p.rotor_R,    "m",    "rotor radius"),
            "L_axle":     param_entry(p.L_axle,     "m",    "axle length"),
            "beta_deg":   param_entry(p.beta_deg,   "deg",  "lean angle above horizontal"),
            "Omega_p":    param_entry(Omega_p,       "rad/s","precession rate"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    beta = math.radians(p.beta_deg)
    I_rotor = 0.5*p.rotor_mass*p.rotor_R**2
    tau = p.rotor_mass*9.81*p.L_axle*math.cos(beta)
    Omega_p = tau/(I_rotor*p.omega_spin)
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# gyroscope_on_stand  seed={p.seed}
import math
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}
BETA={beta}; OMG={p.omega_spin}; OP={Omega_p}; LA={p.L_axle}
def _qmul(p,q):
    px,py,pz,pw=p;qx,qy,qz,qw=q
    return[pw*qx+px*qw+py*qz-pz*qy,pw*qy-px*qz+py*qw+pz*qx,pw*qz+px*qy-py*qx+pz*qw,pw*qw-px*qx-py*qy-pz*qz]
def main():
    ren,sc=_make_renderer(CAM_EYE,CAM_TARGET);nodes={{}}
    _add_box(sc,"fl",nodes,[5,5,0.02],[0.38,0.38,0.42,1.0]);_set_pose(sc,nodes["fl"],[0,0,-0.02],[0,0,0,1])
    _add_cylinder(sc,"pole",nodes,0.04,1.25,[0.50,0.42,0.32,1.0]);_set_pose(sc,nodes["pole"],[0,0,0.625],[0,0,0,1])
    _add_sphere(sc,"piv",nodes,0.05,[0.80,0.80,0.80,1.0]);_set_pose(sc,nodes["piv"],[0,0,1.25],[0,0,0,1])
    _add_cylinder(sc,"rot",nodes,{p.rotor_R},0.06,{p.rotor_color});_add_sphere(sc,"tip",nodes,0.04,[0.7,0.7,0.7,1.0])
    piv=[0,0,1.25];frames=[]
    for fi in range(N_FRAMES):
        t=fi/30.0;phi=OP*t;ts=OMG*t
        ad=[math.cos(BETA)*math.cos(phi),math.cos(BETA)*math.sin(phi),math.sin(BETA)]
        rc=[piv[0]+LA*ad[0],piv[1]+LA*ad[1],piv[2]+LA*ad[2]]
        sh=(1-math.sin(BETA))/2;ch=(1+math.sin(BETA))/2
        qo=[-math.sin(phi)*math.sqrt(sh),math.cos(phi)*math.sqrt(sh),0,math.sqrt(ch)]
        s2=math.sin(ts/2);qs=[ad[0]*s2,ad[1]*s2,ad[2]*s2,math.cos(ts/2)];qr=_qmul(qs,qo)
        _set_pose(sc,nodes["rot"],rc,qr);_set_pose(sc,nodes["tip"],rc,[0,0,0,1])
        _update_string(sc,nodes,"axle",piv,rc,0.025,[0.55,0.55,0.60,1.0])
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA);frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4");ren.delete();print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_gyroscope_on_stand")
    print("OK")
