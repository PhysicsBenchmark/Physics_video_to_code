"""seesaw_imbalance — plank balanced on fulcrum tips under unequal masses."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (5, -3, 3)
CAM_TARGET = (0, 0, 0.5)
N_FRAMES   = 150


@dataclass
class Params:
    seed: int
    plank_length_half: float
    plank_mass: float
    m1: float
    m2: float
    r1: float
    r2: float
    friction: float
    restitution: float
    color_plank: List[float]
    color_m1: List[float]
    color_m2: List[float]


def _rand_color():
    h = random.random()
    s, v = 0.85, 0.90
    hi = int(h * 6) % 6
    f  = h * 6 - int(h * 6)
    p_ = v * (1 - s); q = v * (1 - f*s); t = v * (1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return [r, g, b, 1.0]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    m1 = random.uniform(0.3, 2.0)
    m2 = random.uniform(0.3, 2.0)
    if abs(m1 - m2) < 0.3:
        m2 += random.uniform(0.3, 1.0)
    return Params(
        seed=seed,
        plank_length_half=random.uniform(1.2, 2.5),
        plank_mass=random.uniform(0.5, 1.5),
        m1=m1,
        m2=m2,
        r1=random.uniform(0.07, 0.13),
        r2=random.uniform(0.07, 0.13),
        friction=random.uniform(0.4, 0.8),
        restitution=random.uniform(0.1, 0.4),
        color_plank=_rand_color(),
        color_m1=_rand_color(),
        color_m2=_rand_color(),
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.friction)
    ren.add_plane_mesh("floor", 10.0, [0.42, 0.42, 0.45, 1.0])

    # Fulcrum: static cylinder at center
    fulcrum_r = 0.05
    fulcrum_h = 0.20
    fulcrum_pos = [0.0, 0.0, fulcrum_h / 2.0]
    fulcrum_id = phys.add_cylinder(
        radius=fulcrum_r, height=fulcrum_h,
        pos=fulcrum_pos, mass=0.0, friction=p.friction, restitution=p.restitution)
    phys.fix_body(fulcrum_id, pos=fulcrum_pos)
    ren.add_cylinder("fulcrum", fulcrum_r, fulcrum_h, [0.55, 0.55, 0.6, 1.0])
    ren.set_static_pose("fulcrum", fulcrum_pos)

    # Plank: long thin box resting on top of fulcrum
    plank_he = [p.plank_length_half, 0.08, 0.04]
    plank_z = fulcrum_h + plank_he[2]  # top of fulcrum + plank half-height
    plank_pos = [0.0, 0.0, plank_z]
    plank_id = phys.add_box(
        plank_he, plank_pos, mass=p.plank_mass,
        friction=p.friction, restitution=p.restitution)
    ren.add_box("plank", plank_he, p.color_plank)
    ren.set_static_pose("plank", plank_pos)

    # Mass 1 on left end (negative x)
    m1_pos = [-p.plank_length_half * 0.85, 0.0, plank_z + plank_he[2] + p.r1]
    m1_id = phys.add_sphere(
        radius=p.r1, pos=m1_pos, mass=p.m1,
        friction=p.friction, restitution=p.restitution)
    ren.add_sphere("mass1", p.r1, p.color_m1)
    ren.set_static_pose("mass1", m1_pos)

    # Mass 2 on right end (positive x)
    m2_pos = [ p.plank_length_half * 0.85, 0.0, plank_z + plank_he[2] + p.r2]
    m2_id = phys.add_sphere(
        radius=p.r2, pos=m2_pos, mass=p.m2,
        friction=p.friction, restitution=p.restitution)
    ren.add_sphere("mass2", p.r2, p.color_m2)
    ren.set_static_pose("mass2", m2_pos)

    dyn = [
        ("plank", plank_id),
        ("mass1", m1_id),
        ("mass2", m2_id),
    ]
    frames = run_loop(phys, ren, dyn, N_FRAMES)

    heavier = "m2" if p.m2 > p.m1 else "m1"
    torque1 = p.m1 * 9.81 * p.plank_length_half * 0.85
    torque2 = p.m2 * 9.81 * p.plank_length_half * 0.85
    cot = build_cot(
        simulation="seesaw_imbalance",
        category="articulated_jointed",
        seed=seed,
        physical_observation=(
            f"Seesaw: plank L={p.plank_length_half*2:.2f}m, m_plank={p.plank_mass:.2f}kg. "
            f"m1={p.m1:.2f}kg on left, m2={p.m2:.2f}kg on right. "
            f"Net torque tips toward {heavier}."
        ),
        law_name="Torque balance and rotational dynamics",
        law_statement=(
            "The net torque about the fulcrum τ_net = (m2-m1)·g·d determines "
            "the angular acceleration; imbalanced seesaw rotates toward heavier side."
        ),
        law_formula="τ_net = (m2 - m1)·g·d; α = τ_net / I_plank",
        assumptions=[
            "Plank is uniform thin rod: I = (1/12)·M·L²",
            "Masses treated as point masses at ends",
            "Fulcrum is frictionless in rotation (low friction cylinder)",
            "Plank rests on fulcrum—no rigid attachment; rotation permitted",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\tau_1 = m_1 g d_1",
            "\\tau_2 = m_2 g d_2",
            "\\tau_{\\text{net}} = \\tau_2 - \\tau_1",
            "\\alpha = \\tau_{\\text{net}} / I",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            f"Torque from m1 about fulcrum: τ1 = {torque1:.3f} N·m (CCW)",
            f"Torque from m2 about fulcrum: τ2 = {torque2:.3f} N·m (CW)",
            f"Net torque: Δτ = {abs(torque2-torque1):.3f} N·m toward {heavier}",
            f"Plank I ≈ {p.plank_mass*(2*p.plank_length_half)**2/12:.4f} kg·m²",
            "Contact with fulcrum transmits normal force; plank rotates freely",
        ],
        expected_behavior=[
            f"Heavier side ({heavier}) sinks under gravity",
            "Lighter side rises until plank rests on ground or angle saturates",
            "Masses slide along plank under friction",
            "System reaches static equilibrium with plank angled",
        ],
        parameters={
            "plank_length_half": param_entry(p.plank_length_half, "m",  "half-length of plank"),
            "plank_mass":        param_entry(p.plank_mass,        "kg", "plank mass"),
            "m1":                param_entry(p.m1,                "kg", "left mass"),
            "m2":                param_entry(p.m2,                "kg", "right mass"),
            "r1":                param_entry(p.r1,                "m",  "radius of left sphere"),
            "r2":                param_entry(p.r2,                "m",  "radius of right sphere"),
            "friction":          param_entry(p.friction,          "",   "friction coefficient"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    fulcrum_h = 0.20
    plank_he = [p.plank_length_half, 0.08, 0.04]
    plank_z = fulcrum_h + plank_he[2]
    m1_pos = [-p.plank_length_half * 0.85, 0.0, plank_z + plank_he[2] + p.r1]
    m2_pos = [ p.plank_length_half * 0.85, 0.0, plank_z + plank_he[2] + p.r2]
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# seesaw_imbalance  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[5.0,5.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    # fulcrum (static)
    sf=pb.createCollisionShape(pb.GEOM_CYLINDER,radius=0.05,height=0.20,physicsClientId=c)
    fid=pb.createMultiBody(0,sf,-1,[0,0,0.10],[0,0,0,1],physicsClientId=c)
    pb.createConstraint(fid,-1,-1,-1,pb.JOINT_FIXED,[0,0,0],[0,0,0],[0,0,0.10],physicsClientId=c)
    _add_cylinder(sc,"fulcrum",nodes,0.05,0.20,[0.55,0.55,0.6,1.0])
    _set_pose(sc,nodes["fulcrum"],[0,0,0.10],[0,0,0,1])
    # plank
    sp=pb.createCollisionShape(pb.GEOM_BOX,halfExtents={list(plank_he)},physicsClientId=c)
    plank=pb.createMultiBody({p.plank_mass},sp,-1,[0,0,{plank_z:.4f}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(plank,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
    _add_box(sc,"plank",nodes,{list(plank_he)},{p.color_plank})
    # mass1
    sm1=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.r1},physicsClientId=c)
    bid1=pb.createMultiBody({p.m1},sm1,-1,{list(m1_pos)},[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(bid1,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
    _add_sphere(sc,"mass1",nodes,{p.r1},{p.color_m1})
    # mass2
    sm2=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.r2},physicsClientId=c)
    bid2=pb.createMultiBody({p.m2},sm2,-1,{list(m2_pos)},[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(bid2,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
    _add_sphere(sc,"mass2",nodes,{p.r2},{p.color_m2})
    bids=[("plank",plank),("mass1",bid1),("mass2",bid2)]; frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_seesaw_imbalance")
    print("OK")
