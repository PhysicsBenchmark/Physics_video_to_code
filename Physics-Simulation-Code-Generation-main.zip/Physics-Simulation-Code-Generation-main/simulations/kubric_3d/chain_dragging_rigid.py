"""chain_dragging_rigid — heavy box dragged forward with a chain trailing behind."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (0, -6, 4)
CAM_TARGET = (0, 2, 0.5)
N_FRAMES   = 120


@dataclass
class Params:
    seed: int
    n_links: int
    link_radius: float
    link_half_len: float
    mass_per_link: float
    box_half: List[float]
    box_mass: float
    drag_vel: float
    floor_friction: float
    restitution: float
    color_box: List[float]
    color_chain: List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        n_links=random.randint(6, 10),
        link_radius=random.uniform(0.04, 0.07),
        link_half_len=random.uniform(0.08, 0.14),
        mass_per_link=random.uniform(0.05, 0.2),
        box_half=[random.uniform(0.2, 0.35), random.uniform(0.2, 0.35), random.uniform(0.12, 0.2)],
        box_mass=random.uniform(2.0, 6.0),
        drag_vel=random.uniform(2.0, 5.0),
        floor_friction=random.uniform(0.4, 0.7),
        restitution=random.uniform(0.2, 0.5),
        color_box=_rand_hue(),
        color_chain=_rand_hue(),
    )


def _rand_hue():
    h = random.random(); s, v = 0.85, 0.90
    hi = int(h*6) % 6; f = h*6 - int(h*6)
    p_ = v*(1-s); q = v*(1-f*s); t = v*(1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return [r, g, b, 1.0]


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 12.0, [0.42, 0.42, 0.45, 1.0])

    bh = p.box_half
    box_z = bh[2]
    box_id = phys.add_box(bh, [0.0, 0.0, box_z],
                          mass=p.box_mass, friction=p.floor_friction,
                          restitution=p.restitution,
                          vel=(0.0, p.drag_vel, 0.0))
    ren.add_box("box", bh, p.color_box)
    ren.set_static_pose("box", [0.0, 0.0, box_z])

    # Chain lies flat on floor behind the box, along -Y direction
    # Each link at floor level (z = link_radius), spaced along -Y
    seg = p.link_half_len * 2 + p.link_radius * 0.5
    links = []
    for i in range(p.n_links):
        link_y = -(bh[1] + p.link_radius + i * seg)
        link_z = p.link_radius + 0.005  # lying on floor
        bid = phys.add_capsule(
            p.link_radius, p.link_half_len * 2,
            [0.0, link_y, link_z],
            mass=p.mass_per_link, friction=p.floor_friction, restitution=p.restitution,
            lin_damp=0.1, ang_damp=0.1)
        if links:
            off = p.link_half_len + p.link_radius * 0.25
            phys.create_constraint(
                links[-1], -1, bid, -1,
                pb_mod.JOINT_POINT2POINT, [0, 0, 1],
                [0, 0, -off], [0, 0, off], max_force=300.0)
        links.append(bid)

    # Connect first link to box back face
    phys.create_constraint(
        box_id, -1, links[0], -1,
        pb_mod.JOINT_POINT2POINT, [0, 0, 0],
        [0.0, -bh[1], 0.0],
        [0.0, p.link_half_len + p.link_radius * 0.25, 0.0],
        max_force=500.0)

    for i in range(p.n_links):
        nm = f"lnk{i}"
        link_y = -(bh[1] + p.link_radius + i * seg)
        link_z = p.link_radius + 0.005
        ren.add_capsule(nm, p.link_radius, p.link_half_len * 2, p.color_chain)
        ren.set_static_pose(nm, [0.0, link_y, link_z])

    # Pre-settle chain on floor (40 physics steps before rendering starts)
    for _ in range(40):
        phys.step()

    dyn = [("box", box_id)] + [(f"lnk{i}", lid) for i, lid in enumerate(links)]
    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="chain_dragging_rigid",
        category="rope_chain",
        seed=seed,
        physical_observation=(
            f"Box m={p.box_mass:.1f}kg (half-extents {[round(x,2) for x in p.box_half]}) "
            f"launched at v={p.drag_vel:.1f} m/s in +Y; {p.n_links}-link chain trails behind "
            f"and straightens as the box moves forward."
        ),
        law_name="Newton-Euler rigid-body dynamics + point-to-point constraint impulse",
        law_statement=(
            "Each chain link is a rigid capsule; point-to-point constraints transmit tension "
            "impulses; friction decelerates the box and drags the chain."
        ),
        law_formula="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        assumptions=[
            "Rigid capsule links connected by ideal point-to-point constraints",
            "Coulomb friction floor contact",
            "Chain links may rest on the ground and be lifted by tension",
            "No air resistance",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg+F_c+T",
            "I\\dot{\\omega}=\\tau_c-\\omega\\times I\\omega",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B + cross_terms)",
        derivation_steps=[
            f"Box initial KE = 0.5 * {p.box_mass:.1f} * {p.drag_vel:.1f}^2 = {0.5*p.box_mass*p.drag_vel**2:.1f} J",
            "Friction decelerates box; tension propagates down chain links",
            "Links lifted from ground and aligned with velocity direction",
            "Chain straightens as tension wave reaches last link",
        ],
        expected_behavior=[
            "Box slides forward rapidly",
            "Chain links peel off the floor sequentially",
            "Chain straightens and trails behind moving box",
            "System decelerates due to friction",
        ],
        parameters={
            "n_links":       param_entry(p.n_links,       "",    "number of chain links"),
            "link_radius":   param_entry(p.link_radius,   "m",   "capsule radius of each link"),
            "link_half_len": param_entry(p.link_half_len, "m",   "half-length of each link capsule"),
            "mass_per_link": param_entry(p.mass_per_link, "kg",  "mass per chain link"),
            "box_mass":      param_entry(p.box_mass,      "kg",  "mass of dragged box"),
            "drag_vel":      param_entry(p.drag_vel,      "m/s", "initial velocity of box"),
            "floor_friction":param_entry(p.floor_friction,"",    "floor lateral friction coefficient"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    bh = p.box_half
    box_z = bh[2]
    chain_start = [0.0, -bh[1] - p.link_radius, box_z]
    seg = p.link_half_len * 2 + p.link_radius * 0.5
    off = p.link_half_len + p.link_radius * 0.25
    link_setup = []
    for i in range(p.n_links):
        lz = chain_start[2] - i * seg
        link_setup.append(
            f"    sl=pb.createCollisionShape(pb.GEOM_CAPSULE,radius={p.link_radius},height={p.link_half_len*2},physicsClientId=c)\n"
            f"    l{i}=pb.createMultiBody({p.mass_per_link},sl,-1,[{chain_start[0]},{chain_start[1]:.3f},{lz:.3f}],[0,0,0,1],physicsClientId=c)\n"
            f"    pb.changeDynamics(l{i},-1,lateralFriction={p.floor_friction},restitution={p.restitution},linearDamping=0.05,angularDamping=0.1,physicsClientId=c)\n"
            f"    _add_capsule(sc,'lnk{i}',nodes,{p.link_radius},{p.link_half_len*2},{p.color_chain})\n"
            f"    _set_pose(sc,nodes['lnk{i}'],[{chain_start[0]},{chain_start[1]:.3f},{lz:.3f}],[0,0,0,1])\n"
        )
        if i == 0:
            link_setup.append(
                f"    pb.createConstraint(box_id,-1,l0,- 1,pb.JOINT_POINT2POINT,[0,0,0],[0,{-bh[1]:.3f},0],[0,0,{off:.3f}],physicsClientId=c)\n"
            )
        else:
            link_setup.append(
                f"    pb.createConstraint(l{i-1},-1,l{i},-1,pb.JOINT_POINT2POINT,[0,0,0],[0,0,{-off:.3f}],[0,0,{off:.3f}],physicsClientId=c)\n"
            )
    link_code = "".join(link_setup)
    bids_list = "    bids=[('box',box_id)]+" + str([f"('lnk{i}',l{i})" for i in range(p.n_links)]).replace("'", "") + "\n"
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# chain_dragging_rigid  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[6.0,6.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    sb=pb.createCollisionShape(pb.GEOM_BOX,halfExtents={bh},physicsClientId=c)
    box_id=pb.createMultiBody({p.box_mass},sb,-1,[0,0,{box_z:.3f}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(box_id,-1,lateralFriction={p.floor_friction},restitution={p.restitution},physicsClientId=c)
    pb.resetBaseVelocity(box_id,[0,{p.drag_vel},0],[0,0,0],physicsClientId=c)
    _add_box(sc,"box",nodes,{bh},{p.color_box})
    _set_pose(sc,nodes["box"],[0,0,{box_z:.3f}],[0,0,0,1])
{link_code}    bids=[("box",box_id)]+[("lnk{{}}" .format(i), eval(f"l{{i}}")) for i in range({p.n_links})]
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete()
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_chain_dragging_rigid")
    print("OK")
