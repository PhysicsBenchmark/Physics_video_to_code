"""ramp_to_spring_projectile — ball rolls down a ramp into a spring-loaded plunger.

Energy chain (the physical law sequence this scene teaches):

  m g h   (gravitational PE at top of ramp)
   ->  1/2 m v^2 + 1/2 I omega^2   (rolling KE at the foot of the ramp,
                                    with v = sqrt(10 g h / 7) for a solid sphere)
   ->  ball-plunger collision   (linear momentum + restitution impulse)
   ->  1/2 k x^2   (spring PE stored as the plunger compresses)
   ->  back to KE in the rebound (Hooke's law, F = -k x)

The ramp is a tilted box whose lower edge actually rests on the floor (no
floating slabs).  The "spring" is a real Hookean force F = -k (x - x_eq)
applied to a movable plunger on every substep, with a thick cylinder
rendered between the wall and the plunger that stretches/compresses with
its position and changes colour orange ↔ yellow ↔ green to indicate
compression / rest / stretch.
"""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np


CAM_EYE    = (3.5, -3.8, 2.2)
CAM_TARGET = (0.0,  0.0, 0.25)
N_FRAMES   = 150
FPS        = 30
G          = 9.81


@dataclass
class Params:
    seed: int
    ramp_half: List[float]
    ramp_pos: List[float]
    ramp_angle: float
    ramp_friction: float
    ball_radius: float
    ball_mass: float
    ball_pos: List[float]
    ball_friction: float
    ball_rolling_friction: float
    floor_friction: float
    spring_k: float
    spring_rest_length: float
    spring_radius: float
    plunger_half: List[float]
    plunger_pos: List[float]
    plunger_mass: float
    plunger_friction: float
    wall_half: List[float]
    wall_pos: List[float]
    ramp_color: List[float]
    ball_color: List[float]
    plunger_color: List[float]
    wall_color: List[float]
    spring_color_compressed: List[float]
    spring_color_neutral: List[float]
    spring_color_stretched: List[float]
    floor_color: List[float]


def random_params(seed: int) -> Params:
    rng = random.Random(seed)
    angle    = rng.uniform(0.42, 0.52)         # ~24-30 deg incline
    L        = 1.4
    t_thick  = 0.06
    cos_a    = math.cos(angle)
    sin_a    = math.sin(angle)

    # Ramp centre-z chosen so the +x bottom corner of the tilted slab sits on
    # the floor (z = 0).  PyBullet's getQuaternionFromEuler([0, +angle, 0])
    # rotates +x toward -z, so +x is the LOW end and -x is the HIGH end.
    ramp_centre_z = (L / 2.0) * sin_a + (t_thick / 2.0) * cos_a
    ramp_x        = -0.55
    ramp_pos      = [ramp_x, 0.0, ramp_centre_z]
    ramp_half     = [L / 2.0, 0.25, t_thick / 2.0]

    # Ball seat: just inside the high-end (-x) corner of the top face.
    corner_x  = ramp_x - (L / 2.0) * cos_a + (t_thick / 2.0) * sin_a
    corner_z  = 2.0 * ramp_centre_z          # = L sin a + t cos a
    ball_radius = 0.08
    inset       = 0.10                        # along surface toward +x
    ball_x = corner_x + ball_radius * sin_a + inset * cos_a
    ball_z = corner_z + ball_radius * cos_a + inset * (-sin_a)
    ball_pos = [ball_x, 0.0, ball_z]

    # Plunger height tuned to match the ball-centre impact height (~ball_radius)
    # so the contact applies essentially no torque and the plunger never tips.
    plunger_half  = [0.05, 0.18, 0.08]
    plunger_x_eq  = 0.85
    plunger_pos   = [plunger_x_eq, 0.0, plunger_half[2]]

    spring_rest_length = 0.50
    wall_half = [0.04, 0.30, 0.20]
    wall_x    = plunger_x_eq + plunger_half[0] + spring_rest_length + wall_half[0]
    wall_pos  = [wall_x, 0.0, wall_half[2]]

    return Params(
        seed=seed,
        ramp_half=ramp_half,
        ramp_pos=ramp_pos,
        ramp_angle=angle,
        ramp_friction=0.55,                   # high enough for rolling without slipping
        ball_radius=ball_radius,
        ball_mass=rng.uniform(0.25, 0.35),
        ball_pos=ball_pos,
        ball_friction=0.55,
        ball_rolling_friction=0.004,          # slight rolling resistance on flat floor
        floor_friction=0.30,
        spring_k=rng.uniform(38.0, 55.0),     # N/m
        spring_rest_length=spring_rest_length,
        spring_radius=0.030,
        plunger_half=plunger_half,
        plunger_pos=plunger_pos,
        plunger_mass=rng.uniform(0.65, 0.85), # heavier than ball -> ball rebounds
        plunger_friction=0.05,                # slides freely on the floor
        wall_half=wall_half,
        wall_pos=wall_pos,
        ramp_color=[0.45, 0.45, 0.50, 1.0],
        ball_color=[0.85, 0.18, 0.14, 1.0],
        plunger_color=[0.16, 0.42, 0.86, 1.0],
        wall_color=[0.30, 0.32, 0.36, 1.0],
        spring_color_compressed=[0.96, 0.45, 0.10, 1.0],   # orange (compressed)
        spring_color_neutral=[0.94, 0.74, 0.18, 1.0],      # yellow (rest)
        spring_color_stretched=[0.20, 0.85, 0.30, 1.0],    # green  (stretched)
        floor_color=[0.42, 0.42, 0.45, 1.0],
    )


def _spring_color(deformation: float, p: Params) -> List[float]:
    """Plunger displaced toward wall (def > 0) -> compressed (orange);
    plunger pulled away from wall (def < 0) -> stretched (green)."""
    norm = 0.25
    a = max(min(deformation / norm, 1.0), -1.0)
    if a >= 0:
        c1, c2, t = p.spring_color_neutral, p.spring_color_compressed, a
    else:
        c1, c2, t = p.spring_color_neutral, p.spring_color_stretched, -a
    return [c1[i] * (1.0 - t) + c2[i] * t for i in range(4)]


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, save_sample, build_cot, param_entry,
        STEP_RATE, metadata_only)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)
    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 5.0, p.floor_color)

    # --- Ramp (static tilted box, lower edge on the floor) ----------------
    ramp_orn = pb_mod.getQuaternionFromEuler([0.0, p.ramp_angle, 0.0])
    ramp_id = phys.add_box(p.ramp_half, p.ramp_pos, orn=ramp_orn, mass=0,
                           friction=p.ramp_friction, restitution=0.0)
    ren.add_box("ramp", p.ramp_half, p.ramp_color)
    ren.set_static_pose("ramp", p.ramp_pos, ramp_orn)

    # --- Ball -------------------------------------------------------------
    ball_id = phys.add_sphere(p.ball_radius, p.ball_pos, mass=p.ball_mass,
                              friction=p.ball_friction, restitution=0.70,
                              lin_damp=0.0, ang_damp=0.0)
    pb_mod.changeDynamics(ball_id, -1,
                          rollingFriction=p.ball_rolling_friction,
                          physicsClientId=phys.client)
    ren.add_sphere("ball", p.ball_radius, p.ball_color)
    ren.set_static_pose("ball", p.ball_pos)

    # --- Plunger (movable, connected to wall by a spring force) ----------
    plunger_id = phys.add_box(p.plunger_half, p.plunger_pos, mass=p.plunger_mass,
                              friction=p.plunger_friction, restitution=0.70,
                              lin_damp=0.05, ang_damp=4.0)
    ren.add_box("plunger", p.plunger_half, p.plunger_color)
    ren.set_static_pose("plunger", p.plunger_pos)

    # --- Wall (static) ----------------------------------------------------
    wall_id = phys.add_box(p.wall_half, p.wall_pos, mass=0,
                           friction=0.5, restitution=0.0)
    ren.add_box("wall", p.wall_half, p.wall_color)
    ren.set_static_pose("wall", p.wall_pos)

    bodies          = [("ball", ball_id), ("plunger", plunger_id)]
    steps_per_frame = STEP_RATE // FPS
    plunger_x_eq    = p.plunger_pos[0]
    wall_front_x    = p.wall_pos[0] - p.wall_half[0]
    spring_z        = p.plunger_half[2]

    frames = []
    if metadata_only():
        save_sample(out_dir, asdict(p), _build_cot(p, build_cot, param_entry),
                    make_standalone_code(p), frames)
        phys.close(); ren.close(); return

    for _fi in range(N_FRAMES):
        for _ in range(steps_per_frame):
            pp, _ = phys.get_pose(plunger_id)
            F_spring = -p.spring_k * (pp[0] - plunger_x_eq)
            pb_mod.applyExternalForce(plunger_id, -1, [F_spring, 0.0, 0.0],
                                      list(pp), pb_mod.WORLD_FRAME,
                                      physicsClientId=phys.client)
            phys.step()
        for nm, bid in bodies:
            pos, orn = phys.get_pose(bid)
            ren.set_pose(nm, pos, orn)
        plunger_pos_now, _ = phys.get_pose(plunger_id)
        deformation     = plunger_pos_now[0] - plunger_x_eq
        plunger_back_x  = plunger_pos_now[0] + p.plunger_half[0]
        ren.update_string(
            "spring",
            [wall_front_x,    0.0, spring_z],
            [plunger_back_x,  0.0, spring_z],
            radius=p.spring_radius,
            color=_spring_color(deformation, p))
        frames.append(ren.render_frame())

    save_sample(out_dir, asdict(p), _build_cot(p, build_cot, param_entry),
                make_standalone_code(p), frames)
    phys.close(); ren.close()


def _build_cot(p: Params, build_cot, param_entry):
    sin_a = math.sin(p.ramp_angle); cos_a = math.cos(p.ramp_angle)
    h_top  = p.ball_pos[2] - p.ball_radius      # initial height of ball-floor contact
    # Ideal rolling-without-slipping speed at the foot of the ramp:
    v_pred = math.sqrt(10.0 * G * h_top / 7.0)
    # Estimate ball-plunger collision (1D, restitution e ~ 0.1 baseline):
    e = 0.10
    m_b = p.ball_mass; m_p = p.plunger_mass
    v_p_after = (1.0 + e) * m_b * v_pred / (m_b + m_p)
    # Plunger oscillation parameters
    omega_p = math.sqrt(p.spring_k / m_p)
    period  = 2.0 * math.pi / omega_p
    amp     = v_p_after / omega_p
    return build_cot(
        simulation="ramp_to_spring_projectile",
        category="energy_chain",
        seed=p.seed,
        physical_observation=(
            f"A ball (m={p.ball_mass:.2f} kg, r={p.ball_radius:.2f} m) is released from "
            f"height h={h_top:.2f} m at the top of an inclined plane "
            f"(theta={math.degrees(p.ramp_angle):.1f} deg, mu={p.ramp_friction}).  "
            f"It rolls without slipping to the foot, leaves the ramp at "
            f"v_pred = sqrt(10 g h / 7) = {v_pred:.2f} m/s, traverses the floor and "
            f"strikes a movable plunger (m={p.plunger_mass:.2f} kg) attached to a wall "
            f"by a Hookean spring of stiffness k={p.spring_k:.1f} N/m and rest length "
            f"L0={p.spring_rest_length:.2f} m.  Predicted plunger launch speed "
            f"{v_p_after:.2f} m/s and oscillation period T = 2 pi sqrt(m_p/k) = "
            f"{period:.2f} s with amplitude {amp:.2f} m."
        ),
        law_name="Conservation of energy across rolling, collision and Hooke's law",
        law_statement=(
            "On a smooth incline, gravitational PE is converted into translational and "
            "rotational kinetic energy: m g h = 1/2 m v^2 + 1/2 I omega^2, with the "
            "rolling constraint v = r omega.  For a solid sphere I = 2/5 m r^2, giving "
            "v = sqrt(10 g h / 7).  At the plunger the ball transfers momentum through "
            "a normal-impulse collision; the plunger then enters simple harmonic motion "
            "under F = -k (x - x_eq), storing 1/2 k x^2 of elastic PE before it returns "
            "the energy to the system as the rebound."
        ),
        law_formula=(
            "m g h = 1/2 m v^2 + 1/2 I omega^2;  J_n = -(1+e)(v_rel . n)/m_eff;  "
            "F_spring = -k (x - x_eq);  T = 2 pi sqrt(m_p / k)"
        ),
        assumptions=[
            "Solid uniform sphere with rolling friction sufficient to roll without slipping.",
            "Ramp is rigid and statically anchored; lower edge in contact with the floor.",
            "Spring is modelled as an explicit Hookean force on the plunger (no spring URDF).",
            "Plunger floor friction is low so it slides freely under the spring force.",
            "Rigid-body collision with restitution (e ~ 0.10) at the ball-plunger contact.",
            "PyBullet integrates contacts and forces at 240 Hz.",
        ],
        state_variables=["ball position r_b", "ball linear velocity v_b",
                         "ball angular velocity omega_b",
                         "plunger position x_p", "plunger velocity v_p"],
        equations_latex=[
            "m g h = \\tfrac12 m v^2 + \\tfrac12 I \\omega^2,\\;\\; v = r\\omega",
            "v_{\\text{foot}} = \\sqrt{\\tfrac{10}{7}\\, g\\, h}\\;\\;\\text{(solid sphere)}",
            "F_{\\text{spring}} = -k\\,(x_p - x_{\\text{eq}})",
            "\\tfrac12 k\\,x_{\\max}^2 = \\tfrac12 m_p v_{p,0}^2 \\;\\Rightarrow\\; x_{\\max} = v_{p,0}/\\omega",
            "T = 2\\pi\\sqrt{m_p / k}",
        ],
        contact_impulse="j_n = -(1+e)(v_rel . n)/m_eff;  |j_t| <= mu |j_n|",
        derivation_steps=[
            f"Initial height of ball centre above ramp foot: h = {h_top:.3f} m.",
            f"Solid-sphere rolling speed at the foot: v = sqrt(10 g h / 7) = "
            f"{v_pred:.2f} m/s (slightly reduced in practice by floor rolling friction).",
            f"1D ball-plunger collision (e = {e}): v_p_after = (1+e) m_b v / "
            f"(m_b + m_p) = {v_p_after:.2f} m/s.",
            f"Plunger SHM: omega_p = sqrt(k/m_p) = {omega_p:.2f} rad/s, "
            f"period T = {period:.2f} s, predicted amplitude x_max = {amp:.2f} m.",
            f"Total clip duration {N_FRAMES / FPS:.1f} s spans roughly "
            f"{(N_FRAMES / FPS) / period:.1f} plunger periods, so several oscillations "
            f"(and likely multiple ball-plunger contacts) are visible.",
        ],
        expected_behavior=[
            "Ball rolls smoothly down the ramp under gravity (no penetration, no flying).",
            "Ball traverses the floor at near-constant speed and strikes the plunger.",
            "Plunger is launched toward the wall, compressing the spring (cylinder shortens "
            "and its colour shifts to orange).",
            "Spring rebounds, pushing the plunger back toward the ball; at maximum extension "
            "the cylinder lengthens and turns green.",
            "Ball and plunger keep interacting (often several times) as the spring's energy "
            "decays through restitution and friction over the 5-second clip.",
        ],
        parameters={
            "ramp_angle":        param_entry(p.ramp_angle,        "rad", "ramp tilt angle"),
            "ramp_angle_deg":    param_entry(math.degrees(p.ramp_angle), "deg", "ramp tilt"),
            "ball_mass":         param_entry(p.ball_mass,         "kg",  "ball mass"),
            "ball_radius":       param_entry(p.ball_radius,       "m",   "ball radius"),
            "plunger_mass":      param_entry(p.plunger_mass,      "kg",  "plunger mass"),
            "spring_k":          param_entry(p.spring_k,          "N/m", "spring stiffness"),
            "spring_rest_length":param_entry(p.spring_rest_length,"m",   "spring rest length"),
            "h_drop":            param_entry(h_top,               "m",   "drop height of ball centre"),
            "v_pred_foot":       param_entry(v_pred,              "m/s", "predicted rolling speed at foot"),
            "v_plunger_after":   param_entry(v_p_after,           "m/s", "1D-impulse plunger launch speed"),
            "plunger_period":    param_entry(period,              "s",   "plunger SHM period"),
        })


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# ramp_to_spring_projectile  seed={p.seed}
import pybullet as pb
N_FRAMES = {N_FRAMES}; CAM_EYE = {CAM_EYE}; CAM_TARGET = {CAM_TARGET}
RAMP_HALF = {p.ramp_half}; RAMP_POS = {p.ramp_pos}; RAMP_ANGLE = {p.ramp_angle}
RAMP_FR = {p.ramp_friction}
BALL_RADIUS = {p.ball_radius}; BALL_MASS = {p.ball_mass}; BALL_POS = {p.ball_pos}
BALL_FR = {p.ball_friction}; BALL_ROLL_FR = {p.ball_rolling_friction}
FLOOR_FR = {p.floor_friction}
SPRING_K = {p.spring_k}; SPRING_REST = {p.spring_rest_length}; SR = {p.spring_radius}
PLUNGER_HALF = {p.plunger_half}; PLUNGER_POS = {p.plunger_pos}; PLUNGER_MASS = {p.plunger_mass}
PLUNGER_FR = {p.plunger_friction}
WALL_HALF = {p.wall_half}; WALL_POS = {p.wall_pos}
RAMP_COLOR = {p.ramp_color}; BALL_COLOR = {p.ball_color}
PLUNGER_COLOR = {p.plunger_color}; WALL_COLOR = {p.wall_color}
SPRING_COMPRESS_COLOR = {p.spring_color_compressed}
SPRING_NEUTRAL_COLOR  = {p.spring_color_neutral}
SPRING_STRETCH_COLOR  = {p.spring_color_stretched}
FLOOR_COLOR = {p.floor_color}

def _spring_color(deform):
    norm = 0.25
    a = max(min(deform / norm, 1.0), -1.0)
    if a >= 0:
        c1, c2, t = SPRING_NEUTRAL_COLOR, SPRING_COMPRESS_COLOR, a
    else:
        c1, c2, t = SPRING_NEUTRAL_COLOR, SPRING_STRETCH_COLOR, -a
    return [c1[i]*(1-t) + c2[i]*t for i in range(4)]

def main():
    c = _init_physics(); ren, sc = _make_renderer(CAM_EYE, CAM_TARGET); nodes = {{}}
    plane = pb.loadURDF("plane.urdf", [0, 0, 0], physicsClientId=c)
    pb.changeDynamics(plane, -1, lateralFriction=FLOOR_FR, restitution=0.0, physicsClientId=c)
    _add_box(sc, "floor", nodes, [2.5, 2.5, 0.02], FLOOR_COLOR)
    _set_pose(sc, nodes["floor"], [0, 0, -0.02], [0, 0, 0, 1])

    ramp_orn = pb.getQuaternionFromEuler([0.0, RAMP_ANGLE, 0.0])
    rsh = pb.createCollisionShape(pb.GEOM_BOX, halfExtents=RAMP_HALF, physicsClientId=c)
    ramp = pb.createMultiBody(0, rsh, -1, RAMP_POS, ramp_orn, physicsClientId=c)
    pb.changeDynamics(ramp, -1, lateralFriction=RAMP_FR, restitution=0.0, physicsClientId=c)
    _add_box(sc, "ramp", nodes, RAMP_HALF, RAMP_COLOR)
    _set_pose(sc, nodes["ramp"], RAMP_POS, ramp_orn)

    bsh = pb.createCollisionShape(pb.GEOM_SPHERE, radius=BALL_RADIUS, physicsClientId=c)
    ball = pb.createMultiBody(BALL_MASS, bsh, -1, BALL_POS, [0,0,0,1], physicsClientId=c)
    pb.changeDynamics(ball, -1, lateralFriction=BALL_FR, restitution=0.70,
                       linearDamping=0.0, angularDamping=0.0,
                       rollingFriction=BALL_ROLL_FR, physicsClientId=c)
    _add_sphere(sc, "ball", nodes, BALL_RADIUS, BALL_COLOR)
    _set_pose(sc, nodes["ball"], BALL_POS, [0, 0, 0, 1])

    psh = pb.createCollisionShape(pb.GEOM_BOX, halfExtents=PLUNGER_HALF, physicsClientId=c)
    plunger = pb.createMultiBody(PLUNGER_MASS, psh, -1, PLUNGER_POS, [0,0,0,1],
                                  physicsClientId=c)
    pb.changeDynamics(plunger, -1, lateralFriction=PLUNGER_FR, restitution=0.70,
                       linearDamping=0.05, angularDamping=4.0, physicsClientId=c)
    _add_box(sc, "plunger", nodes, PLUNGER_HALF, PLUNGER_COLOR)
    _set_pose(sc, nodes["plunger"], PLUNGER_POS, [0, 0, 0, 1])

    wsh = pb.createCollisionShape(pb.GEOM_BOX, halfExtents=WALL_HALF, physicsClientId=c)
    wall = pb.createMultiBody(0, wsh, -1, WALL_POS, [0,0,0,1], physicsClientId=c)
    pb.changeDynamics(wall, -1, lateralFriction=0.5, restitution=0.0, physicsClientId=c)
    _add_box(sc, "wall", nodes, WALL_HALF, WALL_COLOR)
    _set_pose(sc, nodes["wall"], WALL_POS, [0, 0, 0, 1])

    bodies = [("ball", ball), ("plunger", plunger)]
    plunger_x_eq = PLUNGER_POS[0]
    wall_front_x = WALL_POS[0] - WALL_HALF[0]
    spring_z = PLUNGER_HALF[2]

    spf = STEP_RATE // 30
    frames = []
    for fi in range(N_FRAMES):
        for __ in range(spf):
            pp, _ = pb.getBasePositionAndOrientation(plunger, physicsClientId=c)
            F_spring = -SPRING_K * (pp[0] - plunger_x_eq)
            pb.applyExternalForce(plunger, -1, [F_spring, 0, 0], list(pp),
                                   pb.WORLD_FRAME, physicsClientId=c)
            pb.stepSimulation(physicsClientId=c)
        for nm, bid in bodies:
            pp, oo = pb.getBasePositionAndOrientation(bid, physicsClientId=c)
            _set_pose(sc, nodes[nm], pp, oo)
        pp, _ = pb.getBasePositionAndOrientation(plunger, physicsClientId=c)
        deform = pp[0] - plunger_x_eq
        plunger_back_x = pp[0] + PLUNGER_HALF[0]
        _update_string(sc, nodes, "spring",
                        [wall_front_x, 0, spring_z],
                        [plunger_back_x, 0, spring_z],
                        SR, _spring_color(deform))
        rgba, _ = ren.render(sc, flags=pyrender.RenderFlags.RGBA)
        frames.append(rgba[:,:,:3])
    _save_video(frames, "video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")

if __name__ == "__main__":
    main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_ramp_to_spring_projectile")
    print("OK")
