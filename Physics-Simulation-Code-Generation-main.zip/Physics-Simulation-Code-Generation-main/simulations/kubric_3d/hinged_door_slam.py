"""hinged_door_slam — door hinged on one edge, given angular push, and slams into a latch post."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (4.6, -4.2, 3.1)
CAM_TARGET = (0, 0, 1)
N_FRAMES   = 120
DOOR_CLEARANCE = 0.06


@dataclass
class Params:
    seed: int
    door_mass: float
    door_half_width: float
    door_half_height: float
    door_half_thick: float
    initial_angular_vel: float
    friction: float
    restitution: float
    color_door: List[float]
    color_frame: List[float]


def _rand_color():
    h = random.random()
    s, v = 0.85, 0.90
    hi = int(h * 6) % 6
    f  = h * 6 - int(h * 6)
    p_ = v * (1 - s); q = v * (1 - f*s); t = v * (1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return [r, g, b, 1.0]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        door_mass=random.uniform(5.0, 20.0),
        door_half_width=random.uniform(0.4, 0.7),
        door_half_height=random.uniform(0.9, 1.2),
        door_half_thick=0.04,
        initial_angular_vel=random.uniform(5.0, 8.0),
        friction=random.uniform(0.3, 0.6),
        restitution=random.uniform(0.1, 0.4),
        color_door=_rand_color(),
        color_frame=[0.55, 0.45, 0.35, 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.friction)
    ren.add_plane_mesh("floor", 8.0, [0.42, 0.42, 0.45, 1.0])
    ren.set_static_pose("floor", [0, 0, -0.02])

    door_he = [p.door_half_width, p.door_half_thick, p.door_half_height]

    # Static frame post is offset behind the hinge so it does not intersect
    # the door panel and accidentally lock the hinge.
    frame_he = [0.04, 0.06, p.door_half_height + 0.1]
    frame_pos = [-0.12, 0.0, frame_he[2]]
    phys.add_box(frame_he, frame_pos, mass=0.0,
                 friction=p.friction, restitution=p.restitution)
    ren.add_box("frame", frame_he, p.color_frame)
    ren.set_static_pose("frame", frame_pos)

    # Door starts fully open: rotated 90° about Z so it lies along +Y axis
    # Hinge at x=0, y=0; door extends in +Y when open → center at [0, hw, hh]
    door_orn = list(pb_mod.getQuaternionFromEuler([0.0, 0.0, math.pi / 2]))
    hinge_center_z = p.door_half_height + DOOR_CLEARANCE
    door_center = [0.0, p.door_half_width, hinge_center_z]

    door_id = phys.add_box(
        door_he, door_center, orn=door_orn,
        mass=p.door_mass,
        friction=p.friction, restitution=p.restitution)
    pb_mod.changeDynamics(door_id, -1,
                          linearDamping=0.0, angularDamping=0.0,
                          physicsClientId=phys.client)

    # A pair of world-pinned points on the hinge edge defines a true vertical
    # hinge line.  The previous static anchor body overlapped the frame and
    # let contacts cancel the intended angular velocity.
    pin_z_low  = DOOR_CLEARANCE + p.door_half_height * 0.15
    pin_z_high = DOOR_CLEARANCE + p.door_half_height * 1.85
    for pin_z_world in [pin_z_low, pin_z_high]:
        dz = pin_z_world - hinge_center_z
        door_local_pivot = [-p.door_half_width, 0.0, dz]
        cid = pb_mod.createConstraint(
            door_id, -1, -1, -1,
            pb_mod.JOINT_POINT2POINT, [0, 0, 1],
            door_local_pivot, [0.0, 0.0, pin_z_world],
            physicsClientId=phys.client)
        pb_mod.changeConstraint(cid, maxForce=50000.0, physicsClientId=phys.client)

    # A narrow latch-side post gives the swing somewhere physical to slam
    # without drawing a second static door panel.
    latch_he = [0.035, 0.08, p.door_half_height + DOOR_CLEARANCE / 2]
    latch_pos = [2.0 * p.door_half_width + latch_he[0],
                 -0.02, latch_he[2]]
    phys.add_box(latch_he, latch_pos, mass=0.0,
                 friction=p.friction, restitution=p.restitution)
    ren.add_box("latch_post", latch_he, [0.42, 0.42, 0.44, 1.0])
    ren.set_static_pose("latch_post", latch_pos)

    # Give door initial angular velocity to swing shut (negative Z = closing)
    pb_mod.resetBaseVelocity(
        door_id, [0, 0, 0], [0, 0, -p.initial_angular_vel],
        physicsClientId=phys.client)

    ren.add_box("door", door_he, p.color_door)
    ren.set_static_pose("door", door_center, door_orn)

    dyn = [("door", door_id)]
    frames = run_loop(phys, ren, dyn, N_FRAMES)

    I_door = p.door_mass * (4 * p.door_half_width**2) / 3.0  # rod about end
    cot = build_cot(
        simulation="hinged_door_slam",
        category="articulated_jointed",
        seed=seed,
        physical_observation=(
            f"Door: m={p.door_mass:.1f}kg, w={p.door_half_width*2:.2f}m, "
            f"h={p.door_half_height*2:.2f}m. "
            f"Initial angular velocity={p.initial_angular_vel:.2f} rad/s (closing). "
            f"Hinged at left edge with floor clearance; swings about the vertical hinge line and hits a latch post."
        ),
        law_name="Rotational dynamics of hinged rigid body",
        law_statement=(
            "A door hinged at one edge has one rotational degree of freedom; "
            "external torques and latch-post contact impulses change angular momentum."
        ),
        law_formula="τ = I·α; I_hinge = (1/3)·m·L²; L_z = I_hinge·ω_z",
        assumptions=[
            "Door is uniform rectangular plate; I about hinge = mL²/3",
            "Two separated hinge pins constrain translation and leave rotation about z",
            "Gravity gives negligible torque about the vertical hinge axis",
            "A narrow latch post receives the closing impact",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "I_{\\text{hinge}} = \\frac{1}{3}mL^2",
            "L_z = I_{\\text{hinge}}\\omega_z",
            "\\Delta L_z = \\int \\tau_z\\,dt",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            f"I_hinge = mL²/3 = {I_door:.4f} kg·m²",
            "Initial angular momentum carries the panel from open toward closed",
            "The two hinge pins keep the hinge edge fixed while the panel yaws",
            "At the latch post: contact impulse removes angular momentum and may cause rebound",
        ],
        expected_behavior=[
            "Door starts open at 90° with inward angular velocity",
            "Panel visibly rotates about the vertical hinge edge",
            "Door slams into the narrow latch-side post",
            "May bounce slightly after impact depending on restitution",
        ],
        parameters={
            "door_mass":          param_entry(p.door_mass,          "kg",    "door mass"),
            "door_half_width":    param_entry(p.door_half_width,    "m",     "door half-width"),
            "door_half_height":   param_entry(p.door_half_height,   "m",     "door half-height"),
            "initial_angular_vel":param_entry(p.initial_angular_vel,"rad/s", "initial closing angular velocity"),
            "friction":           param_entry(p.friction,           "",      "friction coefficient"),
            "restitution":        param_entry(p.restitution,        "",      "coefficient of restitution"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    import pybullet as _pb
    door_he = [p.door_half_width, p.door_half_thick, p.door_half_height]
    door_orn = list(_pb.getQuaternionFromEuler([0.0, 0.0, math.pi / 2]))
    frame_he = [0.04, 0.06, p.door_half_height + 0.1]
    frame_pos = [-0.12, 0.0, frame_he[2]]
    hinge_center_z = p.door_half_height + DOOR_CLEARANCE
    latch_he = [0.035, 0.08, p.door_half_height + DOOR_CLEARANCE / 2]
    latch_pos = [2.0 * p.door_half_width + latch_he[0], -0.02, latch_he[2]]
    pin_z_low  = DOOR_CLEARANCE + p.door_half_height * 0.15
    pin_z_high = DOOR_CLEARANCE + p.door_half_height * 1.85
    dz_low  = pin_z_low  - hinge_center_z
    dz_high = pin_z_high - hinge_center_z
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# hinged_door_slam  seed={p.seed}
import pybullet as pb
import math
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[4.0,4.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,-0.02],[0,0,0,1])
    sf=pb.createCollisionShape(pb.GEOM_BOX,halfExtents={list(frame_he)},physicsClientId=c)
    pb.createMultiBody(0,sf,-1,{frame_pos},[0,0,0,1],physicsClientId=c)
    _add_box(sc,"frame",nodes,{list(frame_he)},{p.color_frame})
    _set_pose(sc,nodes["frame"],{frame_pos},[0,0,0,1])
    door_orn={door_orn}
    door_center=[0.0,{p.door_half_width:.4f},{hinge_center_z:.4f}]
    sd=pb.createCollisionShape(pb.GEOM_BOX,halfExtents={list(door_he)},physicsClientId=c)
    door=pb.createMultiBody({p.door_mass},sd,-1,door_center,door_orn,physicsClientId=c)
    pb.changeDynamics(door,-1,lateralFriction={p.friction},restitution={p.restitution},linearDamping=0.0,angularDamping=0.0,physicsClientId=c)
    for pin_z,dz in [({pin_z_low:.4f},{dz_low:.4f}),({pin_z_high:.4f},{dz_high:.4f})]:
        cid=pb.createConstraint(door,-1,-1,-1,pb.JOINT_POINT2POINT,[0,0,1],[{-p.door_half_width:.4f},0,dz],[0,0,pin_z],physicsClientId=c)
        pb.changeConstraint(cid,maxForce=50000.0,physicsClientId=c)
    ss=pb.createCollisionShape(pb.GEOM_BOX,halfExtents={list(latch_he)},physicsClientId=c)
    pb.createMultiBody(0,ss,-1,{list(latch_pos)},[0,0,0,1],physicsClientId=c)
    _add_box(sc,"latch_post",nodes,{list(latch_he)},[0.42,0.42,0.44,1.0])
    _set_pose(sc,nodes["latch_post"],{list(latch_pos)},[0,0,0,1])
    pb.resetBaseVelocity(door,[0,0,0],[0,0,{-p.initial_angular_vel}],physicsClientId=c)
    _add_box(sc,"door",nodes,{list(door_he)},{p.color_door})
    _set_pose(sc,nodes["door"],door_center,door_orn)
    bids=[("door",door)]; frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn2=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn2)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_hinged_door_slam")
    print("OK")
