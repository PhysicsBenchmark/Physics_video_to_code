"""newton_cradle_3d — simplified Newton's cradle: line of balls, first few given initial velocity."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (3.0, -4.0, 3.0)
CAM_TARGET = (0.0,  0.0, 0.5)
N_FRAMES   = 150  # 5 s @ 30 fps


@dataclass
class Params:
    seed:          int
    n_balls:       int
    ball_radius:   float   # m
    ball_mass:     float   # kg
    restitution:   float   # should be 0.9–0.99 for cradle effect
    initial_speed: float   # speed of the first n_initial balls (m/s)
    n_initial:     int     # how many balls get initial velocity
    ball_color:    List[float]
    struck_color:  List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    n = random.randint(4, 6)
    return Params(
        seed=seed,
        n_balls=n,
        ball_radius=random.uniform(0.06, 0.12),
        ball_mass=random.uniform(0.15, 0.50),
        restitution=random.uniform(0.90, 0.99),
        initial_speed=random.uniform(0.7, 1.6),
        n_initial=random.randint(1, min(2, n - 2)),
        ball_color=[0.75, 0.75, 0.78, 1.0],
        struck_color=[0.90, 0.65, 0.15, 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=0.1, restitution=p.restitution)
    ren.add_plane_mesh("floor", 8.0, [0.30, 0.30, 0.32, 1.0])
    ren.set_static_pose("floor", [0, 0, -0.02])

    # Balls hang from fixed-length rods/strings.  The previous implementation
    # only drew strings after the fact while the balls were free to translate,
    # which let the right-side balls visibly stretch away from their pivots.
    gap = p.ball_radius * 2.01  # slight gap prevents initial overlap
    total_width = (p.n_balls - 1) * gap
    x_start = -total_width / 2.0

    rest_z = max(0.42, p.ball_radius * 3.2)
    string_len = 0.86
    top_rail_z = rest_z + string_len
    pull_angle = math.radians(32.0)
    str_radius = 0.006
    str_color  = [0.25, 0.18, 0.10, 1.0]

    dyn = []
    ball_ids = []
    pivots = []
    rod_shape = pb_mod.createCollisionShape(
        pb_mod.GEOM_CAPSULE, radius=0.004, height=string_len,
        physicsClientId=phys.client)

    rail_he = [total_width / 2 + 0.35, 0.035, 0.025]
    ren.add_box("top_rail", rail_he, [0.45, 0.36, 0.26, 1.0])
    ren.set_static_pose("top_rail", [0.0, 0.0, top_rail_z])

    for i in range(p.n_balls):
        rest_x = x_start + i * gap
        theta = pull_angle if i < p.n_initial else 0.0
        x = rest_x - string_len * math.sin(theta)
        z = top_rail_z - string_len * math.cos(theta)
        pivot = [rest_x, 0.0, top_rail_z]
        color = p.struck_color if i < p.n_initial else p.ball_color

        vel = [0.0, 0.0, 0.0]
        if i < p.n_initial:
            vel = [
                p.initial_speed * math.cos(theta),
                0.0,
                -p.initial_speed * math.sin(theta),
            ]
        bid = phys.add_sphere(p.ball_radius, [x, 0.0, z],
                              mass=p.ball_mass, friction=0.02,
                              restitution=p.restitution,
                              vel=vel, lin_damp=0.002, ang_damp=0.002)

        rod_pos = [(pivot[0] + x) * 0.5, 0.0, (pivot[2] + z) * 0.5]
        rod_orn = [0.0, math.sin(theta / 2), 0.0, math.cos(theta / 2)]
        rod_id = pb_mod.createMultiBody(
            0.02, rod_shape, -1, rod_pos, rod_orn,
            physicsClientId=phys.client)
        pb_mod.setCollisionFilterGroupMask(rod_id, -1, 0, 0,
                                           physicsClientId=phys.client)
        pb_mod.changeDynamics(rod_id, -1,
                              linearDamping=0.01, angularDamping=0.01,
                              physicsClientId=phys.client)
        top_cid = pb_mod.createConstraint(
            rod_id, -1, -1, -1,
            pb_mod.JOINT_POINT2POINT, [0, 0, 0],
            [0, 0, string_len / 2], pivot,
            physicsClientId=phys.client)
        pb_mod.changeConstraint(top_cid, maxForce=50000.0,
                                physicsClientId=phys.client)
        bottom_cid = pb_mod.createConstraint(
            rod_id, -1, bid, -1,
            pb_mod.JOINT_POINT2POINT, [0, 0, 0],
            [0, 0, -string_len / 2], [0, 0, 0],
            physicsClientId=phys.client)
        pb_mod.changeConstraint(bottom_cid, maxForce=50000.0,
                                physicsClientId=phys.client)

        name = f"ball_{i}"
        ren.add_sphere(name, p.ball_radius, color)
        dyn.append((name, bid))
        ball_ids.append(bid)
        pivots.append(pivot)

    _ball_ids = ball_ids
    _pivots = [np.array(v, dtype=float) for v in pivots]
    _str_len = string_len

    def extra_sync_fn(phys, ren, fi):
        for i, bid in enumerate(_ball_ids):
            ball_p, ball_orn = phys.get_pose(bid)
            pivot = _pivots[i]
            diff = ball_p - pivot
            dist = float(np.linalg.norm(diff))
            if dist > 1e-8:
                direction = diff / dist
                corrected = pivot + direction * _str_len
                if abs(dist - _str_len) > _str_len * 0.01:
                    vel, ang = pb_mod.getBaseVelocity(
                        bid, physicsClientId=phys.client)
                    vel_np = np.array(vel, dtype=float)
                    tangent_vel = vel_np - np.dot(vel_np, direction) * direction
                    pb_mod.resetBasePositionAndOrientation(
                        bid, corrected.tolist(), ball_orn,
                        physicsClientId=phys.client)
                    pb_mod.resetBaseVelocity(
                        bid, tangent_vel.tolist(), ang,
                        physicsClientId=phys.client)
                    ball_p = corrected
            ren.set_pose(f"ball_{i}", ball_p, ball_orn)
            ren.update_string(f"str_{i}", pivot.tolist(), ball_p.tolist(),
                              str_radius, str_color)

    frames = run_loop(phys, ren, dyn, N_FRAMES, extra_sync_fn=extra_sync_fn)

    cot = build_cot(
        simulation="newton_cradle_3d",
        category="rigid_body_constrained",
        seed=seed,
        physical_observation=(
            f"Newton's cradle with {p.n_balls} balls "
            f"(r={p.ball_radius:.3f} m, m={p.ball_mass:.3f} kg each, "
            f"e={p.restitution:.2f}). "
            f"First {p.n_initial} ball(s) launched at {p.initial_speed:.2f} m/s."),
        law_name="Conservation of momentum and kinetic energy (elastic collision)",
        law_statement=(
            "For equal-mass nearly-elastic balls, an impulse chain transfers "
            "velocity exactly to the far end: n balls in → n balls out."),
        law_formula="m*v_in = m*v_out [momentum]; e≈1 → KE conserved",
        assumptions=[
            "Balls are equal mass and nearly perfectly elastic.",
            "Collisions treated as simultaneous pairwise contacts.",
            "No air resistance.",
            "Each ball is constrained to a fixed-length pendulum rod/string.",
        ],
        state_variables=["position r (m)", "velocity v (m/s)",
                         "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\sum m v_i = \\text{const}",
            "\\sum \\frac{1}{2}m v_i^2 \\approx \\text{const}\\;(e\\to 1)",
            "|r_i-r_{pivot,i}| = L",
            "v_1'=0,\\;v_2'=v_1\\quad(\\text{equal mass, 1D elastic})",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            f"Ball(s) 0..{p.n_initial-1} travel at {p.initial_speed:.2f} m/s.",
            "Impact chain: each contact passes impulse to next ball.",
            f"With e={p.restitution:.2f}, energy loss per collision: {(1-p.restitution**2)*100:.1f}%.",
            f"Expected: {p.n_initial} ball(s) ejected from far end, rest remain stationary.",
        ],
        expected_behavior=[
            f"First {p.n_initial} ball(s) strike the group and stop (approximately).",
            f"Last {p.n_initial} ball(s) fly off with nearly the same speed.",
            "System oscillates back and forth, slowly losing energy.",
        ],
        parameters={
            "n_balls":          param_entry(p.n_balls,       "",    "Total number of balls"),
            "ball_radius_m":    param_entry(p.ball_radius,   "m",   "Ball radius"),
            "ball_mass_kg":     param_entry(p.ball_mass,     "kg",  "Mass per ball"),
            "restitution":      param_entry(p.restitution,   "",    "Coefficient of restitution"),
            "initial_speed_mps": param_entry(p.initial_speed,"m/s", "Initial speed of first balls"),
            "n_initial":        param_entry(p.n_initial,     "",    "Number of balls given initial velocity"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    gap = p.ball_radius * 2.01
    total_width = (p.n_balls - 1) * gap
    x_start = -total_width / 2.0
    rest_z = max(0.42, p.ball_radius * 3.2)
    string_len = 0.86
    top_rail_z = rest_z + string_len
    pull_angle = math.radians(32.0)
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# newton_cradle_3d  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[4.0,4.0,0.02],[0.30,0.30,0.32,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    gap={gap}; x_start={x_start}; bids=[]; ball_id_list=[]; pivots=[]
    bc={p.ball_color}; sc_col={p.struck_color}; top_z={top_rail_z}; str_len={string_len}; pull_angle={pull_angle}
    _add_box(sc,"top_rail",nodes,[{total_width/2+0.35:.4f},0.035,0.025],[0.45,0.36,0.26,1.0])
    _set_pose(sc,nodes["top_rail"],[0,0,top_z],[0,0,0,1])
    rod_shape=pb.createCollisionShape(pb.GEOM_CAPSULE,radius=0.004,height=str_len,physicsClientId=c)
    for i in range({p.n_balls}):
        rx=x_start+i*gap; theta=pull_angle if i<{p.n_initial} else 0.0
        x=rx-str_len*math.sin(theta); z=top_z-str_len*math.cos(theta)
        pivot=[rx,0.0,top_z]
        color=sc_col if i<{p.n_initial} else bc
        s=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.ball_radius},physicsClientId=c)
        bid=pb.createMultiBody({p.ball_mass},s,-1,[x,0.0,z],[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction=0.02,restitution={p.restitution},linearDamping=0.002,angularDamping=0.002,physicsClientId=c)
        if i<{p.n_initial}:
            pb.resetBaseVelocity(bid,[{p.initial_speed}*math.cos(theta),0.0,{-p.initial_speed}*math.sin(theta)],[0,0,0],physicsClientId=c)
        rod_pos=[(pivot[0]+x)*0.5,0.0,(pivot[2]+z)*0.5]
        rod_orn=[0.0,math.sin(theta/2),0.0,math.cos(theta/2)]
        rod=pb.createMultiBody(0.02,rod_shape,-1,rod_pos,rod_orn,physicsClientId=c)
        pb.setCollisionFilterGroupMask(rod,-1,0,0,physicsClientId=c)
        pb.changeDynamics(rod,-1,linearDamping=0.01,angularDamping=0.01,physicsClientId=c)
        tcid=pb.createConstraint(rod,-1,-1,-1,pb.JOINT_POINT2POINT,[0,0,0],[0,0,str_len/2],pivot,physicsClientId=c)
        pb.changeConstraint(tcid,maxForce=50000,physicsClientId=c)
        bcid=pb.createConstraint(rod,-1,bid,-1,pb.JOINT_POINT2POINT,[0,0,0],[0,0,-str_len/2],[0,0,0],physicsClientId=c)
        pb.changeConstraint(bcid,maxForce=50000,physicsClientId=c)
        nm=f"ball_{{i}}"; _add_sphere(sc,nm,nodes,{p.ball_radius},color); bids.append((nm,bid)); ball_id_list.append(bid)
        pivots.append(pivot)
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        for i,bid in enumerate(ball_id_list):
            bp,bo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            pivot=np.array(pivots[i],float); bp_np=np.array(bp,float); diff=bp_np-pivot
            dist=float(np.linalg.norm(diff))
            if dist>1e-8:
                direction=diff/dist; corrected=pivot+direction*str_len
                if abs(dist-str_len)>str_len*0.01:
                    vel,ang=pb.getBaseVelocity(bid,physicsClientId=c)
                    vel_np=np.array(vel,float); tangent_vel=vel_np-np.dot(vel_np,direction)*direction
                    pb.resetBasePositionAndOrientation(bid,corrected.tolist(),bo,physicsClientId=c)
                    pb.resetBaseVelocity(bid,tangent_vel.tolist(),ang,physicsClientId=c)
                    bp_np=corrected
            _set_pose(sc,nodes[f"ball_{{i}}"],bp_np,bo)
            _update_string(sc,nodes,f"str_{{i}}",pivots[i],bp_np.tolist(),0.006,[0.25,0.18,0.10,1.0])
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_newton_cradle_3d")
    print("OK")
