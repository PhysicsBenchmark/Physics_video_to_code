"""coin_spin_topple — spinning coin on a surface slows and topples under gyroscopic instability."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (4, -2, 3)
CAM_TARGET = (0, 0, 0.2)
N_FRAMES   = 180


@dataclass
class Params:
    seed: int
    coin_radius: float
    coin_height: float
    coin_mass: float
    initial_spin: float
    initial_tilt_deg: float
    floor_friction: float
    restitution: float
    color_coin: List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        coin_radius=random.uniform(0.05, 0.12),
        coin_height=random.uniform(0.005, 0.012),
        coin_mass=random.uniform(0.005, 0.015),
        initial_spin=random.uniform(20.0, 60.0),
        initial_tilt_deg=random.uniform(5.0, 15.0),
        floor_friction=random.uniform(0.3, 0.6),
        restitution=random.uniform(0.2, 0.5),
        color_coin=_rand_hue(),
    )


def _rand_hue():
    h = random.random(); s, v = 0.85, 0.90
    hi = int(h*6) % 6; f = h*6 - int(h*6)
    p_ = v*(1-s); q = v*(1-f*s); t = v*(1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return [r, g, b, 1.0]


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 6.0, [0.42, 0.42, 0.45, 1.0])
    ren.set_static_pose("floor", [0, 0, -0.02])

    # Coin stands on its rim: rotate 90° about X so the flat face is vertical.
    # Small tilt perturbation along Y so the coin wobbles/precesses.
    tilt_rad = math.radians(p.initial_tilt_deg)
    qorn = list(pb_mod.getQuaternionFromEuler([math.pi/2 + tilt_rad, 0.0, 0.0]))

    # Coin center height: rim touches floor at z=0; center must be at z = coin_radius.
    # Add a small gap (0.002 m) so the coin sits just above the floor, not embedded in it.
    coin_z = p.coin_radius + 0.002

    # Spin about world vertical axis [0, 0, 1] — coin spins on its rim
    ang_vel = (0.0, 0.0, p.initial_spin)

    coin_id = phys.add_cylinder(p.coin_radius, p.coin_height,
                                  [0.0, 0.0, coin_z], orn=qorn,
                                  mass=p.coin_mass, friction=p.floor_friction,
                                  restitution=p.restitution,
                                  ang_vel=ang_vel)
    ren.add_cylinder("coin", p.coin_radius, p.coin_height, p.color_coin,
                     metallic=0.7, roughness=0.2)
    ren.set_static_pose("coin", [0.0, 0.0, coin_z], qorn)

    dyn = [("coin", coin_id)]
    frames = run_loop(phys, ren, dyn, N_FRAMES)

    I_z = 0.5 * p.coin_mass * p.coin_radius ** 2
    I_x = p.coin_mass * (3 * p.coin_radius**2 + p.coin_height**2) / 12.0
    cot = build_cot(
        simulation="coin_spin_topple",
        category="mixed_complex",
        seed=seed,
        physical_observation=(
            f"Flat coin (r={p.coin_radius:.3f}m, h={p.coin_height:.4f}m, m={p.coin_mass:.4f}kg) "
            f"spun at ω={p.initial_spin:.1f} rad/s on flat surface with initial tilt "
            f"{p.initial_tilt_deg:.1f}°; gyroscopic precession slows and coin topples."
        ),
        law_name="Euler gyroscope equations + rigid-body contact",
        law_statement=(
            "Spinning coin exhibits gyroscopic precession; friction dissipates spin energy; "
            "as spin decreases below critical value, precession diverges and coin falls."
        ),
        law_formula="Ω_p = m·g·r·cos(θ) / (I_z·ω_spin); I_z=(1/2)mr²",
        assumptions=[
            "Rigid flat cylinder (coin)",
            "Coulomb friction at contact point with floor",
            "Gyroscopic approximation valid for large ω_spin",
            "Small angle tilt; contact at single point on rim",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "I_z\\dot{\\omega}_z=\\tau_z",
            "I_x\\dot{\\omega}_x=(I_y-I_z)\\omega_y\\omega_z+\\tau_x",
            "\\Omega_p=\\frac{mgr\\cos\\theta}{I_z\\omega_{spin}}",
            "I_z=\\frac{1}{2}mr^2",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B + r×n·I^{-1}·r×n)",
        derivation_steps=[
            f"Spin moment of inertia I_z = 0.5×{p.coin_mass:.5f}×{p.coin_radius:.3f}² = {I_z:.6f} kg·m²",
            f"Transverse MOI I_x ≈ {I_x:.6f} kg·m²",
            f"Precession rate Ω_p = m·g·r/(I_z·ω) = {p.coin_mass*9.81*p.coin_radius/(I_z*p.initial_spin):.3f} rad/s",
            "Friction torque reduces ω_spin over time",
            "When ω_spin too low, gyroscopic restoring torque < gravity torque → fall",
        ],
        expected_behavior=[
            "Coin spins stably with characteristic wobble/precession",
            "Spin rate decreases due to rolling friction",
            "Precession rate increases (Ω_p ∝ 1/ω_spin)",
            "Coin eventually falls flat on the floor",
        ],
        parameters={
            "coin_radius":      param_entry(p.coin_radius,      "m",     "coin radius"),
            "coin_height":      param_entry(p.coin_height,      "m",     "coin thickness"),
            "coin_mass":        param_entry(p.coin_mass,        "kg",    "coin mass"),
            "initial_spin":     param_entry(p.initial_spin,     "rad/s", "initial spin angular velocity"),
            "initial_tilt_deg": param_entry(p.initial_tilt_deg, "deg",   "initial tilt from upright"),
            "floor_friction":   param_entry(p.floor_friction,   "",      "floor friction coefficient"),
            "restitution":      param_entry(p.restitution,      "",      "coefficient of restitution"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    import pybullet as _pb
    tilt_rad = math.radians(p.initial_tilt_deg)
    qorn = list(_pb.getQuaternionFromEuler([math.pi/2 + tilt_rad, 0.0, 0.0]))
    coin_z = p.coin_radius + 0.002
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# coin_spin_topple  seed={p.seed}
import pybullet as pb
import math
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[3.0,3.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    tilt_rad={tilt_rad}
    qorn=pb.getQuaternionFromEuler([math.pi/2 + tilt_rad, 0, 0])
    coin_z={coin_z:.4f}
    sc_=pb.createCollisionShape(pb.GEOM_CYLINDER,radius={p.coin_radius},height={p.coin_height},physicsClientId=c)
    coin=pb.createMultiBody({p.coin_mass},sc_,-1,[0,0,coin_z],qorn,physicsClientId=c)
    pb.changeDynamics(coin,-1,lateralFriction={p.floor_friction},restitution={p.restitution},physicsClientId=c)
    pb.resetBaseVelocity(coin,[0,0,0],[0,0,{p.initial_spin}],physicsClientId=c)
    _add_cylinder(sc,"coin",nodes,{p.coin_radius},{p.coin_height},{p.color_coin})
    _set_pose(sc,nodes["coin"],[0,0,coin_z],list(qorn))
    bids=[("coin",coin)]
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete()
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_coin_spin_topple")
    print("OK")
