"""fan_push_stationary_block — a fan's air stream pushes a block into a wall.

A static fan (pole + disc + spinning blades for visual context) sits on one
side of the floor.  Instead of approximating the airflow with discrete pellet
projectiles, a constant horizontal wind force F_wind is applied to the block
each substep — this is exactly the steady-state momentum-flux loading from a
column of moving air.  The block must first overcome static floor friction;
once moving, it accelerates under (F_wind - mu m g), traverses the floor, and
strikes a fixed wall on the far side.  After impact it bounces back and the
wind decelerates it, sometimes producing a second strike.
"""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (4.5, -5.0, 3.3)
CAM_TARGET = (0.0,  0.0, 0.4)
N_FRAMES   = 150
FPS        = 30
G          = 9.81


@dataclass
class Params:
    seed: int
    fan_base_xy: List[float]
    fan_pole_height: float
    fan_disc_radius: float
    fan_disc_thickness: float
    fan_blade_omega: float
    block_pos: List[float]
    block_half: List[float]
    block_mass: float
    block_friction: float
    block_restitution: float
    wall_pos: List[float]
    wall_half: List[float]
    wind_force: float
    fan_pole_color: List[float]
    fan_disc_color: List[float]
    fan_blade_color: List[float]
    block_color: List[float]
    wall_color: List[float]


def random_params(seed: int) -> Params:
    rng = random.Random(seed)
    block_mass     = rng.uniform(0.20, 0.40)
    wind_force     = rng.uniform(1.6, 2.4)              # newtons
    block_friction = 0.30
    fan_blade_omega = rng.uniform(15.0, 28.0)           # rad/s, visual only
    return Params(
        seed=seed,
        fan_base_xy=[-1.45, 0.0],
        fan_pole_height=0.55,
        fan_disc_radius=0.22,
        fan_disc_thickness=0.05,
        fan_blade_omega=fan_blade_omega,
        block_pos=[-0.55, 0.0, 0.16],
        block_half=[0.16, 0.16, 0.16],
        block_mass=block_mass,
        block_friction=block_friction,
        block_restitution=0.20,
        wall_pos=[1.05, 0.0, 0.30],
        wall_half=[0.06, 0.40, 0.30],
        wind_force=wind_force,
        fan_pole_color=[0.30, 0.32, 0.36, 1.0],
        fan_disc_color=[0.25, 0.27, 0.30, 1.0],
        fan_blade_color=[0.92, 0.92, 0.95, 1.0],
        block_color=[0.85, 0.18, 0.14, 1.0],
        wall_color=[0.50, 0.50, 0.55, 1.0],
    )


def _euler_quat(rx, ry, rz):
    import pybullet as pb
    return pb.getQuaternionFromEuler([rx, ry, rz])


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, save_sample, build_cot, param_entry,
        STEP_RATE, metadata_only)
    import pybullet as pb_mod
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)
    phys.add_plane(friction=0.55)
    ren.add_plane_mesh("floor", 5.0, [0.42, 0.42, 0.45, 1.0])

    block_id = phys.add_box(p.block_half, p.block_pos, mass=p.block_mass,
                            friction=p.block_friction, restitution=p.block_restitution,
                            lin_damp=0.05, ang_damp=0.3)
    ren.add_box("block", p.block_half, p.block_color)
    ren.set_static_pose("block", p.block_pos)

    wall_id = phys.add_box(p.wall_half, p.wall_pos, mass=0,
                           friction=0.6, restitution=0.4)
    ren.add_box("wall", p.wall_half, p.wall_color)
    ren.set_static_pose("wall", p.wall_pos)

    # ---- fan visual (no collision; the airflow effect is the wind force) ----
    pole_pos = [p.fan_base_xy[0], p.fan_base_xy[1], p.fan_pole_height / 2.0]
    ren.add_cylinder("fan_pole", 0.025, p.fan_pole_height, p.fan_pole_color)
    ren.set_static_pose("fan_pole", pole_pos)

    disc_pos = [p.fan_base_xy[0] + 0.04, 0.0, p.fan_pole_height + 0.05]
    disc_orn = _euler_quat(0.0, math.pi / 2.0, 0.0)         # axis along x
    ren.add_cylinder("fan_disc", p.fan_disc_radius, p.fan_disc_thickness, p.fan_disc_color)
    ren.set_static_pose("fan_disc", disc_pos, disc_orn)

    blade_half = [0.010, p.fan_disc_radius * 0.92, 0.022]
    blade_pos  = [disc_pos[0] + p.fan_disc_thickness / 2.0 + 0.02, 0.0, disc_pos[2]]
    ren.add_box("blade_a", blade_half, p.fan_blade_color)
    ren.add_box("blade_b", blade_half, p.fan_blade_color)

    bodies = [("block", block_id)]
    steps_per_frame = STEP_RATE // FPS

    frames = []
    if metadata_only():
        save_sample(out_dir, asdict(p), _build_cot(p, build_cot, param_entry),
                    make_standalone_code(p), frames)
        phys.close(); ren.close(); return

    for fi in range(N_FRAMES):
        for _ in range(steps_per_frame):
            bpos, _ = phys.get_pose(block_id)
            pb_mod.applyExternalForce(block_id, -1, [p.wind_force, 0.0, 0.0],
                                      list(bpos), pb_mod.WORLD_FRAME,
                                      physicsClientId=phys.client)
            phys.step()
        for nm, bid in bodies:
            pos, orn = phys.get_pose(bid)
            ren.set_pose(nm, pos, orn)
        # Spin the two blades around the fan's x-axis (visual only).
        theta = p.fan_blade_omega * (fi / FPS)
        ren.set_pose("blade_a", blade_pos, _euler_quat(theta,                math.pi / 2, 0))
        ren.set_pose("blade_b", blade_pos, _euler_quat(theta + math.pi / 2,  math.pi / 2, 0))
        frames.append(ren.render_frame())

    save_sample(out_dir, asdict(p), _build_cot(p, build_cot, param_entry),
                make_standalone_code(p), frames)
    phys.close(); ren.close()


def _build_cot(p: Params, build_cot, param_entry):
    block_front_x = p.block_pos[0] + p.block_half[0]
    wall_front_x  = p.wall_pos[0]  - p.wall_half[0]
    travel        = wall_front_x - block_front_x
    friction_force = p.block_friction * p.block_mass * G
    net_force      = max(p.wind_force - friction_force, 0.0)
    accel          = net_force / p.block_mass
    t_impact       = math.sqrt(2.0 * travel / accel) if accel > 1e-6 else float("inf")
    v_impact       = accel * t_impact
    return build_cot(
        simulation="fan_push_stationary_block",
        category="aerodynamic_forcing",
        seed=p.seed,
        physical_observation=(
            f"A fan blows a steady horizontal wind force F_wind={p.wind_force:.2f} N onto a "
            f"block (m={p.block_mass:.2f} kg, mu={p.block_friction}).  Static friction "
            f"({friction_force:.2f} N) is overcome by the wind, the block accelerates at "
            f"{accel:.2f} m/s^2, traverses {travel:.2f} m and strikes the wall at "
            f"~{v_impact:.2f} m/s after {t_impact:.2f} s; it then rebounds with restitution "
            f"e={p.block_restitution}."
        ),
        law_name="Newton's second law with constant aerodynamic forcing and Coulomb friction",
        law_statement=(
            "The wind exerts a horizontal force F_wind on the block; gravity and the floor "
            "normal balance vertically.  When |F_wind| > mu_s m g the block slides; while "
            "moving, the kinetic friction force mu m g opposes motion, giving "
            "a = (F_wind - mu m g)/m.  At the wall, momentum is reversed by a normal "
            "contact impulse with restitution e."
        ),
        law_formula="m a = F_wind - mu m g sign(v);  J_n = -(1+e) m v_rel . n",
        assumptions=[
            "Wind is modelled as a constant horizontal body force on the block "
            "(steady momentum flux from the fan).",
            "The fan visual (pole, disc, blades) is decorative and has no collision; "
            "its blades rotate kinematically for visual context only.",
            "Coulomb friction applies at the block-floor contact.",
            "Wall is a static body (mass=0); rebound governed by restitution e.",
            "Rigid bodies; PyBullet integrates contacts at 240 Hz.",
        ],
        state_variables=["block position", "block velocity",
                         "block orientation", "block angular velocity"],
        equations_latex=[
            "m \\ddot x = F_{\\text{wind}} - \\mu m g\\,\\mathrm{sgn}(\\dot x)",
            "v_{\\text{impact}} = \\sqrt{2\\,a\\,\\Delta x}",
            "v^{+} = -e\\,v^{-}\\quad\\text{(at wall)}",
        ],
        contact_impulse="j_n = -(1+e)(v_rel . n) / m_eff;  |j_t| <= mu |j_n|",
        derivation_steps=[
            f"Static friction limit: mu m g = {friction_force:.3f} N; wind {p.wind_force:.2f} N "
            f"-> block slides ({'yes' if p.wind_force > friction_force else 'no'}).",
            f"Steady acceleration: a = (F_wind - mu m g)/m = {accel:.2f} m/s^2.",
            f"Travel distance from block-front to wall-front: {travel:.3f} m.",
            f"Estimated impact speed: v = sqrt(2 a Δx) = {v_impact:.2f} m/s "
            f"at t ≈ {t_impact:.2f} s.",
            f"Post-bounce speed: -e v ≈ {-p.block_restitution * v_impact:.2f} m/s; "
            f"wind continues to act so the block decelerates and may strike again.",
        ],
        expected_behavior=[
            "Fan blades visibly spin (kinematic) while the wind force pushes the block.",
            "Block slides smoothly along the floor without flying or tumbling.",
            "Block strikes the wall, rebounds with reduced speed, and may oscillate "
            "until friction + wind balance.",
        ],
        parameters={
            "block_mass":        param_entry(p.block_mass,        "kg",  "block mass"),
            "block_friction":    param_entry(p.block_friction,    "",    "Coulomb friction with floor"),
            "block_restitution": param_entry(p.block_restitution, "",    "block-wall restitution"),
            "wind_force":        param_entry(p.wind_force,        "N",   "constant horizontal wind force"),
            "predicted_accel":   param_entry(accel,               "m/s^2","steady-state acceleration"),
            "predicted_v_impact":param_entry(v_impact,             "m/s", "estimated wall-impact speed"),
            "predicted_t_impact":param_entry(t_impact,             "s",   "estimated time to wall"),
            "fan_blade_omega":   param_entry(p.fan_blade_omega,   "rad/s","visual blade spin rate"),
        })


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# fan_push_stationary_block  seed={p.seed}
import pybullet as pb
N_FRAMES = {N_FRAMES}; CAM_EYE = {CAM_EYE}; CAM_TARGET = {CAM_TARGET}
WIND_FORCE = {p.wind_force}
BLOCK_HALF = {p.block_half}; BLOCK_POS = {p.block_pos}; BLOCK_MASS = {p.block_mass}
BLOCK_FR = {p.block_friction}; BLOCK_RE = {p.block_restitution}
WALL_HALF = {p.wall_half}; WALL_POS = {p.wall_pos}
FAN_BASE_XY = {p.fan_base_xy}; FAN_POLE_H = {p.fan_pole_height}
FAN_DISC_R = {p.fan_disc_radius}; FAN_DISC_T = {p.fan_disc_thickness}
FAN_OMEGA = {p.fan_blade_omega}
FAN_POLE_COLOR = {p.fan_pole_color}; FAN_DISC_COLOR = {p.fan_disc_color}
BLADE_COLOR = {p.fan_blade_color}; BLOCK_COLOR = {p.block_color}; WALL_COLOR = {p.wall_color}

def main():
    c = _init_physics(); ren, sc = _make_renderer(CAM_EYE, CAM_TARGET); nodes = {{}}
    pb.loadURDF("plane.urdf", [0, 0, 0], physicsClientId=c)
    _add_box(sc, "floor", nodes, [2.5, 2.5, 0.02], [0.42, 0.42, 0.45, 1.0])
    _set_pose(sc, nodes["floor"], [0, 0, -0.02], [0, 0, 0, 1])

    bsh = pb.createCollisionShape(pb.GEOM_BOX, halfExtents=BLOCK_HALF, physicsClientId=c)
    block = pb.createMultiBody(BLOCK_MASS, bsh, -1, BLOCK_POS, [0,0,0,1], physicsClientId=c)
    pb.changeDynamics(block, -1, lateralFriction=BLOCK_FR, restitution=BLOCK_RE,
                       linearDamping=0.05, angularDamping=0.3, physicsClientId=c)
    _add_box(sc, "block", nodes, BLOCK_HALF, BLOCK_COLOR)
    _set_pose(sc, nodes["block"], BLOCK_POS, [0,0,0,1])

    wsh = pb.createCollisionShape(pb.GEOM_BOX, halfExtents=WALL_HALF, physicsClientId=c)
    wall = pb.createMultiBody(0, wsh, -1, WALL_POS, [0,0,0,1], physicsClientId=c)
    pb.changeDynamics(wall, -1, lateralFriction=0.6, restitution=0.4, physicsClientId=c)
    _add_box(sc, "wall", nodes, WALL_HALF, WALL_COLOR)
    _set_pose(sc, nodes["wall"], WALL_POS, [0,0,0,1])

    pole_pos = [FAN_BASE_XY[0], FAN_BASE_XY[1], FAN_POLE_H / 2.0]
    _add_cylinder(sc, "fan_pole", nodes, 0.025, FAN_POLE_H, FAN_POLE_COLOR)
    _set_pose(sc, nodes["fan_pole"], pole_pos, [0, 0, 0, 1])

    disc_pos = [FAN_BASE_XY[0] + 0.04, 0.0, FAN_POLE_H + 0.05]
    disc_orn = pb.getQuaternionFromEuler([0.0, math.pi / 2.0, 0.0])
    _add_cylinder(sc, "fan_disc", nodes, FAN_DISC_R, FAN_DISC_T, FAN_DISC_COLOR)
    _set_pose(sc, nodes["fan_disc"], disc_pos, disc_orn)

    blade_half = [0.010, FAN_DISC_R * 0.92, 0.022]
    blade_pos  = [disc_pos[0] + FAN_DISC_T / 2.0 + 0.02, 0.0, disc_pos[2]]
    _add_box(sc, "blade_a", nodes, blade_half, BLADE_COLOR)
    _add_box(sc, "blade_b", nodes, blade_half, BLADE_COLOR)

    frames = []
    for fi in range(N_FRAMES):
        for __ in range(8):
            bp, _ = pb.getBasePositionAndOrientation(block, physicsClientId=c)
            pb.applyExternalForce(block, -1, [WIND_FORCE, 0.0, 0.0], list(bp),
                                   pb.WORLD_FRAME, physicsClientId=c)
            pb.stepSimulation(physicsClientId=c)
        bp, bo = pb.getBasePositionAndOrientation(block, physicsClientId=c)
        _set_pose(sc, nodes["block"], bp, bo)
        theta = FAN_OMEGA * (fi / 30.0)
        _set_pose(sc, nodes["blade_a"], blade_pos,
                   pb.getQuaternionFromEuler([theta,                math.pi/2, 0]))
        _set_pose(sc, nodes["blade_b"], blade_pos,
                   pb.getQuaternionFromEuler([theta + math.pi/2,    math.pi/2, 0]))
        rgba, _ = ren.render(sc, flags=pyrender.RenderFlags.RGBA)
        frames.append(rgba[:,:,:3])
    _save_video(frames, "video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")

if __name__ == "__main__":
    main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_fan_push_stationary_block")
    print("OK")
