"""elastic_coupled_cart_collision — projectile elastically strikes one of two
carts coupled by a real Hookean spring; the spring oscillates and transfers
momentum/energy throughout the video."""
from __future__ import annotations
import math, random
from dataclasses import asdict

import numpy as np
import pybullet as pb

from ._advanced_life_scenes import _COMMON_ASSUMPTIONS, _COMMON_DERIV, _COMMON_EQ, _SPEC
from ._real_life_scenes import (
    CAM_DEFAULT,
    N_FRAMES,
    Params,
    TARGET_DEFAULT,
    _base_summary,
    _box,
    _capsule,
    _sphere,
    _visual,
)

EXPERIMENT = "elastic_coupled_cart_collision"

CART_HX, CART_HY, CART_HZ = 0.10, 0.12, 0.07
CART_LEFT_X  = -0.30
CART_RIGHT_X = +0.30
CART_Z       = CART_HZ                    # sits on floor
SPRING_REST  = CART_RIGHT_X - CART_LEFT_X  # = 0.60 (center-to-center)
SPRING_K     = 30.0                        # N/m → relative-mode period ≈ 1.0 s
CART_M       = 1.5

PROJ_R       = 0.10
PROJ_M       = 0.5
PROJ_X0      = -1.40
PROJ_Z       = PROJ_R                       # rolling on floor
PROJ_SPEED   = 2.5                         # m/s, sign chosen by seed
FLOOR_MU     = 0.012                        # near-frictionless rail so oscillation persists

CART_LEFT_COLOR  = [0.16, 0.42, 0.86, 1.0]
CART_RIGHT_COLOR = [0.20, 0.72, 0.34, 1.0]
PROJ_COLOR       = [0.85, 0.18, 0.14, 1.0]
SPRING_COLOR     = [0.94, 0.74, 0.18, 1.0]
SPRING_AMP       = 0.045
SPRING_WIRE_R    = 0.012
N_ZIGS           = 6                       # spring zigzag turns
SPRING_SEG_NAMES = [f"spring_{i:02d}" for i in range(2 * N_ZIGS)]


def _initial_proj_velocity(seed: int):
    rng = random.Random(seed + abs(hash(EXPERIMENT)) % 100000)
    sign = 1.0 if rng.random() > 0.5 else -1.0
    return sign * rng.uniform(0.85, 1.15) * PROJ_SPEED


def _layout_for_velocity(vel_x: float):
    """Mirror the layout when the projectile comes from the right side."""
    if vel_x >= 0:
        return PROJ_X0, CART_LEFT_X, CART_RIGHT_X
    return -PROJ_X0, -CART_LEFT_X, -CART_RIGHT_X


def random_params(seed: int) -> Params:
    vel_x = _initial_proj_velocity(seed)
    proj_x, cart_l_x, cart_r_x = _layout_for_velocity(vel_x)
    proj_pos      = [proj_x, 0.0, PROJ_Z]
    cart_left_pos = [cart_l_x, 0.0, CART_Z]
    cart_right_pos= [cart_r_x, 0.0, CART_Z]
    spring_mid    = [(cart_l_x + cart_r_x) * 0.5, 0.0, CART_Z]
    objects = [
        _box("cart_left",  [CART_HX, CART_HY, CART_HZ], cart_left_pos,  CART_M, CART_LEFT_COLOR,
             friction=FLOOR_MU, restitution=0.95),
        _box("cart_right", [CART_HX, CART_HY, CART_HZ], cart_right_pos, CART_M, CART_RIGHT_COLOR,
             friction=FLOOR_MU, restitution=0.95),
        _sphere("projectile", PROJ_R, proj_pos, PROJ_M, PROJ_COLOR,
                vel=[vel_x, 0, 0], friction=FLOOR_MU, restitution=0.95),
        _visual(_capsule("spring", SPRING_WIRE_R, abs(SPRING_REST),
                         spring_mid, 0, SPRING_COLOR, orn=[0, math.pi/2, 0])),
    ]
    summary = {
        "spring_rest_length_m":     SPRING_REST,
        "spring_constant_N_per_m":  SPRING_K,
        "cart_mass_kg":             CART_M,
        "projectile_mass_kg":       PROJ_M,
        "projectile_initial_velocity_mps": vel_x,
        "spring_relative_period_s": 2 * math.pi * math.sqrt(CART_M / (2 * SPRING_K)),
        "phenomena_demonstrated": [
            "Elastic collision (sphere↔cart) — momentum & kinetic energy nearly conserved",
            "Hooke's law spring force F = -k(ℓ - L_eq) applied each physics substep",
            "Coupled two-mass oscillation with relative-mode period 2π√(m/2k)",
            "Center-of-mass drift at constant velocity (1st law / momentum conservation)",
        ],
    }
    return Params(seed=seed, experiment=EXPERIMENT, objects=objects,
                  camera_eye=CAM_DEFAULT, camera_target=TARGET_DEFAULT,
                  floor_size=7.0, summary=summary)


def _cot(params: Params):
    from simulations.kubric_3d._base import build_cot, param_entry
    category, law, formula = _SPEC[EXPERIMENT]
    entries = {k: param_entry(v, "various", k)
               for k, v in _base_summary(params).items()}
    return build_cot(
        EXPERIMENT, category, params.seed,
        f"{EXPERIMENT}: a sphere collides nearly elastically with the near cart "
        "of a pair coupled by a real Hookean spring; the spring then drives "
        "coupled oscillation that transfers energy to the far cart for the "
        "remainder of the clip.",
        law,
        f"{law}; spring force F = -k(ℓ - L_eq) is integrated by PyBullet via "
        "per-substep external-force application to both carts (Newton's third law).",
        formula, _COMMON_ASSUMPTIONS,
        ["position r (m)", "velocity v (m/s)", "spring stretch ℓ-L_eq (m)",
         "spring force F (N)"],
        _COMMON_EQ + ["F_{spring}=-k(\\ell - L_{eq})",
                      "T_{rel} = 2\\pi\\sqrt{m/(2k)}"],
        "j_n=-(1+e)(v_rel·n)/m_eff; |j_t|<=mu|j_n|",
        _COMMON_DERIV + [
            "Each substep: read cart positions, compute current spring length ℓ.",
            "Apply F = k(ℓ - L_eq) along the cart-to-cart axis to each cart.",
            "PyBullet integrates the carts and the projectile-cart collision impulse.",
        ],
        ["Projectile rebounds off cart_left at lower speed (elastic restitution).",
         "Spring compresses, slowing cart_left and accelerating cart_right.",
         "Carts oscillate about the (drifting) centre of mass with period T_rel.",
         "Cart-system momentum equals the projectile's momentum change.",
        ],
        entries)


def make_standalone_code(params: Params) -> str:
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    vel_x = params.summary["projectile_initial_velocity_mps"]
    proj_x, cart_l_x, cart_r_x = _layout_for_velocity(vel_x)
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f'''
# {EXPERIMENT}  seed={params.seed}
N_FRAMES={N_FRAMES}; CAM_EYE={repr(params.camera_eye)}; CAM_TARGET={repr(params.camera_target)}
CART_HX,CART_HY,CART_HZ={CART_HX},{CART_HY},{CART_HZ}; CART_M={CART_M}; CART_Z={CART_Z}
CART_L_POS=[{cart_l_x},0,{CART_Z}]; CART_R_POS=[{cart_r_x},0,{CART_Z}]
CART_L_COL={CART_LEFT_COLOR}; CART_R_COL={CART_RIGHT_COLOR}
PROJ_R={PROJ_R}; PROJ_M={PROJ_M}; PROJ_POS=[{proj_x},0,{PROJ_Z}]; PROJ_VEL=[{vel_x},0,0]; PROJ_COL={PROJ_COLOR}
SPRING_K={SPRING_K}; SPRING_REST={SPRING_REST}; SPRING_AMP={SPRING_AMP}; SPRING_R={SPRING_WIRE_R}
SPRING_COL={SPRING_COLOR}; N_ZIGS={N_ZIGS}; FLOOR=7.0
FLOOR_MU={FLOOR_MU}

def _draw_spring(sc, nodes, p1, p2):
    p1=np.array(p1,float); p2=np.array(p2,float); diff=p2-p1
    L=float(np.linalg.norm(diff))
    if L<1e-6: return
    z_ax=diff/L; ref=np.array([0.,0.,1.]) if abs(z_ax[2])<0.95 else np.array([1.,0.,0.])
    perp=ref-np.dot(ref,z_ax)*z_ax; perp=perp/np.linalg.norm(perp)
    n_pts=2*N_ZIGS+1; pts=[]
    for i in range(n_pts):
        t=i/(n_pts-1); axial=p1+z_ax*(t*L)
        if i==0 or i==n_pts-1: off=np.zeros(3)
        elif i%2==1: off=+perp*SPRING_AMP
        else: off=-perp*SPRING_AMP
        pts.append(axial+off)
    for i in range(len(pts)-1):
        _update_string(sc,nodes,f"spring_{{i:02d}}",pts[i].tolist(),pts[i+1].tolist(),
                       radius=SPRING_R,color=SPRING_COL)

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pl_id=p.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    p.changeDynamics(pl_id,-1,lateralFriction=FLOOR_MU,restitution=0.4,physicsClientId=c)
    _add_box(sc,"floor",nodes,[FLOOR/2,FLOOR/2,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["floor"],[0,0,-0.02],[0,0,0,1])
    sl=p.createCollisionShape(p.GEOM_BOX,halfExtents=[CART_HX,CART_HY,CART_HZ],physicsClientId=c)
    cart_l=p.createMultiBody(CART_M,sl,-1,CART_L_POS,[0,0,0,1],physicsClientId=c)
    p.changeDynamics(cart_l,-1,lateralFriction=FLOOR_MU,restitution=0.95,
        linearDamping=0.0,angularDamping=0.05,physicsClientId=c)
    sr=p.createCollisionShape(p.GEOM_BOX,halfExtents=[CART_HX,CART_HY,CART_HZ],physicsClientId=c)
    cart_r=p.createMultiBody(CART_M,sr,-1,CART_R_POS,[0,0,0,1],physicsClientId=c)
    p.changeDynamics(cart_r,-1,lateralFriction=FLOOR_MU,restitution=0.95,
        linearDamping=0.0,angularDamping=0.05,physicsClientId=c)
    sp=p.createCollisionShape(p.GEOM_SPHERE,radius=PROJ_R,physicsClientId=c)
    proj=p.createMultiBody(PROJ_M,sp,-1,PROJ_POS,[0,0,0,1],physicsClientId=c)
    p.changeDynamics(proj,-1,lateralFriction=FLOOR_MU,restitution=0.95,
        linearDamping=0.0,angularDamping=0.05,physicsClientId=c)
    p.resetBaseVelocity(proj,PROJ_VEL,[0,0,0],physicsClientId=c)
    _add_box(sc,"cart_left",nodes,[CART_HX,CART_HY,CART_HZ],CART_L_COL)
    _add_box(sc,"cart_right",nodes,[CART_HX,CART_HY,CART_HZ],CART_R_COL)
    _add_sphere(sc,"projectile",nodes,PROJ_R,PROJ_COL)
    bodies=[("cart_left",cart_l),("cart_right",cart_r),("projectile",proj)]
    frames=[]
    for fi in range(N_FRAMES):
        for _ in range(8):
            pl,_=p.getBasePositionAndOrientation(cart_l,physicsClientId=c)
            pr,_=p.getBasePositionAndOrientation(cart_r,physicsClientId=c)
            pl=np.array(pl,float); pr=np.array(pr,float)
            d=pr-pl; dist=float(np.linalg.norm(d))
            if dist>1e-6:
                dirn=d/dist; F=SPRING_K*(dist-SPRING_REST)
                p.applyExternalForce(cart_l,-1,(F*dirn).tolist(),pl.tolist(),
                                     p.WORLD_FRAME,physicsClientId=c)
                p.applyExternalForce(cart_r,-1,(-F*dirn).tolist(),pr.tolist(),
                                     p.WORLD_FRAME,physicsClientId=c)
            p.stepSimulation(physicsClientId=c)
            for cid in (cart_l,cart_r):
                v,_=p.getBaseVelocity(cid,physicsClientId=c)
                p.resetBaseVelocity(cid,[v[0],0,0],[0,0,0],physicsClientId=c)
        for nm,bid in bodies:
            pp,oo=p.getBasePositionAndOrientation(bid,physicsClientId=c); _set_pose(sc,nodes[nm],pp,oo)
        pl,_=p.getBasePositionAndOrientation(cart_l,physicsClientId=c)
        pr,_=p.getBasePositionAndOrientation(cart_r,physicsClientId=c)
        a=(pl[0]+np.sign(pr[0]-pl[0])*CART_HX, pl[1], pl[2])
        b=(pr[0]-np.sign(pr[0]-pl[0])*CART_HX, pr[1], pr[2])
        _draw_spring(sc,nodes,a,b)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); p.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
'''


def _draw_spring(ren, p1, p2):
    p1 = np.array(p1, dtype=float); p2 = np.array(p2, dtype=float)
    diff = p2 - p1
    L = float(np.linalg.norm(diff))
    if L < 1e-6:
        return
    z_ax = diff / L
    ref = np.array([0., 0., 1.]) if abs(z_ax[2]) < 0.95 else np.array([1., 0., 0.])
    perp = ref - np.dot(ref, z_ax) * z_ax
    perp = perp / np.linalg.norm(perp)
    n_pts = 2 * N_ZIGS + 1
    pts = []
    for i in range(n_pts):
        t = i / (n_pts - 1)
        axial = p1 + z_ax * (t * L)
        if i == 0 or i == n_pts - 1:
            off = np.zeros(3)
        elif i % 2 == 1:
            off = +perp * SPRING_AMP
        else:
            off = -perp * SPRING_AMP
        pts.append(axial + off)
    for i in range(len(pts) - 1):
        ren.update_string(SPRING_SEG_NAMES[i], pts[i].tolist(), pts[i + 1].tolist(),
                          radius=SPRING_WIRE_R, color=SPRING_COLOR)


def generate_sample(seed: int, out_dir: str):
    from simulations.kubric_3d._base import (
        Physics, Renderer, save_sample, STEP_RATE, FPS, metadata_only,
    )
    params = random_params(seed)
    vel_x = params.summary["projectile_initial_velocity_mps"]
    proj_x, cart_l_x, cart_r_x = _layout_for_velocity(vel_x)

    phys = Physics()
    ren = Renderer(params.camera_eye, params.camera_target)
    phys.add_plane(friction=FLOOR_MU)
    ren.add_plane_mesh("floor", params.floor_size, [0.42, 0.42, 0.45, 1.0])

    cart_l_id = phys.add_box([CART_HX, CART_HY, CART_HZ], [cart_l_x, 0, CART_Z],
                             mass=CART_M, friction=FLOOR_MU, restitution=0.95,
                             lin_damp=0.0, ang_damp=0.05)
    cart_r_id = phys.add_box([CART_HX, CART_HY, CART_HZ], [cart_r_x, 0, CART_Z],
                             mass=CART_M, friction=FLOOR_MU, restitution=0.95,
                             lin_damp=0.0, ang_damp=0.05)
    proj_id = phys.add_sphere(PROJ_R, [proj_x, 0, PROJ_Z], mass=PROJ_M,
                              friction=FLOOR_MU, restitution=0.95,
                              vel=[vel_x, 0, 0], lin_damp=0.0, ang_damp=0.05)

    ren.add_box("cart_left",  [CART_HX, CART_HY, CART_HZ], CART_LEFT_COLOR)
    ren.add_box("cart_right", [CART_HX, CART_HY, CART_HZ], CART_RIGHT_COLOR)
    ren.add_sphere("projectile", PROJ_R, PROJ_COLOR)

    bodies = [("cart_left", cart_l_id), ("cart_right", cart_r_id),
              ("projectile", proj_id)]

    if metadata_only():
        save_sample(out_dir, asdict(params), _cot(params),
                    make_standalone_code(params), [])
        phys.close(); ren.close()
        return

    substeps = STEP_RATE // FPS
    frames = []
    for fi in range(N_FRAMES):
        for _ in range(substeps):
            pl, _ = phys.get_pose(cart_l_id)
            pr, _ = phys.get_pose(cart_r_id)
            d = pr - pl
            dist = float(np.linalg.norm(d))
            if dist > 1e-6:
                direction = d / dist
                F = SPRING_K * (dist - SPRING_REST)
                pb.applyExternalForce(cart_l_id, -1, (F * direction).tolist(),
                                      pl.tolist(), pb.WORLD_FRAME,
                                      physicsClientId=phys.client)
                pb.applyExternalForce(cart_r_id, -1, (-F * direction).tolist(),
                                      pr.tolist(), pb.WORLD_FRAME,
                                      physicsClientId=phys.client)
            phys.step()
            for cid in (cart_l_id, cart_r_id):
                v, _ = pb.getBaseVelocity(cid, physicsClientId=phys.client)
                pb.resetBaseVelocity(cid, [v[0], 0.0, 0.0], [0.0, 0.0, 0.0],
                                     physicsClientId=phys.client)
        for name, bid in bodies:
            pos, orn = phys.get_pose(bid)
            ren.set_pose(name, pos, orn)
        pl, _ = phys.get_pose(cart_l_id)
        pr, _ = phys.get_pose(cart_r_id)
        sgn = 1.0 if pr[0] > pl[0] else -1.0
        a = [float(pl[0] + sgn * CART_HX), float(pl[1]), float(pl[2])]
        b = [float(pr[0] - sgn * CART_HX), float(pr[1]), float(pr[2])]
        _draw_spring(ren, a, b)
        frames.append(ren.render_frame())

    save_sample(out_dir, asdict(params), _cot(params),
                make_standalone_code(params), frames)
    phys.close(); ren.close()


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_elastic_coupled_cart_collision")
    print("OK")
