"""granular_hourglass_3d — small spheres drain through a conical funnel neck into a lower chamber."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (3.0, -4.5, 1.8)
CAM_TARGET = (0.0,  0.0, 1.0)
N_FRAMES   = 150


@dataclass
class Params:
    seed: int
    n_grains: int
    grain_r: float
    neck_r: float
    friction: float
    restitution: float


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    grain_r = random.uniform(0.048, 0.072)
    neck_r  = grain_r * random.uniform(1.15, 1.50)
    return Params(seed=seed,
                  n_grains=random.randint(14, 22),
                  grain_r=grain_r,
                  neck_r=neck_r,
                  friction=random.uniform(0.25, 0.55),
                  restitution=random.uniform(0.20, 0.50))


def _build_hourglass_walls(phys, ren, neck_r, wall_color, friction, restitution):
    """8 tilted boxes form a conical funnel above the neck, 4 vertical walls form the chamber below."""
    import pybullet as pb

    n_panels   = 8
    top_r      = neck_r + 0.50     # funnel mouth radius
    z_top      = 1.80              # top of funnel panels
    z_neck     = 0.85              # bottom of funnel (neck height)
    z_center   = (z_top + z_neck) / 2.0
    panel_h    = (z_top - z_neck) / 2.0   # half-height of each panel
    panel_w    = 0.28              # half-width along ring
    panel_t    = 0.025             # half-thickness
    ring_r     = (top_r + neck_r) / 2.0
    tilt       = math.atan2(top_r - neck_r, z_top - z_neck)  # inward tilt from vertical

    for i in range(n_panels):
        angle = 2 * math.pi * i / n_panels
        px = ring_r * math.cos(angle)
        py = ring_r * math.sin(angle)
        orn = pb.getQuaternionFromEuler([0, tilt, angle])
        he  = [panel_t, panel_w, panel_h]
        phys.add_box(he, [px, py, z_center], orn=orn, mass=0, friction=friction, restitution=restitution)
        wname = f"fw{i}"
        ren.add_box(wname, he, wall_color)
        ren.set_static_pose(wname, [px, py, z_center], orn)

    # Lower chamber: 4 vertical walls forming a square tube from floor to z_neck
    cham_h  = z_neck / 2.0
    cham_cx = neck_r * 0.85   # slightly inside neck radius
    for j, (dx, dy) in enumerate([(1,0),(-1,0),(0,1),(0,-1)]):
        if dx != 0:
            he2 = [panel_t, cham_cx, cham_h]
        else:
            he2 = [cham_cx, panel_t, cham_h]
        px2 = dx * cham_cx; py2 = dy * cham_cx; pz2 = cham_h
        phys.add_box(he2, [px2, py2, pz2], mass=0, friction=friction, restitution=restitution)
        wname2 = f"cw{j}"
        ren.add_box(wname2, he2, wall_color)
        ren.set_static_pose(wname2, [px2, py2, pz2])


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        STANDALONE_IMPORTS, STANDALONE_UTILS, FPS)

    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.friction)
    ren.add_plane_mesh("floor", 8.0, [0.38, 0.38, 0.42, 1.0])
    ren.set_static_pose("floor", [0, 0, -0.02])

    wall_color = [0.55, 0.55, 0.60, 1.0]
    _build_hourglass_walls(phys, ren, p.neck_r, wall_color, p.friction, p.restitution)

    # Drop grains from above funnel mouth, spread within top_r*0.5
    top_r = p.neck_r + 0.50
    spread = top_r * 0.40
    dyn = []
    grain_cols = [[0.25, 0.65, 0.90, 1.0], [0.90, 0.40, 0.20, 1.0],
                  [0.30, 0.85, 0.40, 1.0], [0.90, 0.85, 0.15, 1.0]]
    for i in range(p.n_grains):
        angle = 2 * math.pi * i / p.n_grains
        x = spread * math.cos(angle) * random.uniform(0.3, 1.0)
        y = spread * math.sin(angle) * random.uniform(0.3, 1.0)
        z = 2.0 + i * p.grain_r * 1.8
        bid = phys.add_sphere(p.grain_r, [x, y, z],
                              mass=0.03, friction=p.friction, restitution=p.restitution)
        col = grain_cols[i % len(grain_cols)]
        ren.add_sphere(f"gr{i}", p.grain_r, col)
        dyn.append((f"gr{i}", bid))

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="granular_hourglass_3d",
        category="granular",
        seed=seed,
        physical_observation=(
            f"{p.n_grains} grains (r={p.grain_r:.3f}m) flow through "
            f"conical funnel with neck r={p.neck_r:.3f}m."
        ),
        law_name="Granular flow through constriction (Beverloo law)",
        law_statement="Flow rate Q ∝ (D_neck - k·d_grain)^(5/2). Jamming if neck too narrow.",
        law_formula="Q\\propto(D-kd)^{5/2}",
        assumptions=[
            "Rigid spheres with Coulomb friction.",
            "Funnel walls are rigid static bodies.",
            "Grains dropped from rest above funnel mouth.",
        ],
        state_variables=["r (m)", "v (m/s)", "ω (rad/s)", "q"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg+F_{contact}",
            "I\\dot{\\omega}=\\tau_{contact}",
        ],
        contact_impulse="j = -(1+e)v_n / effective_mass",
        derivation_steps=[
            f"Grain r={p.grain_r:.3f}m, neck r={p.neck_r:.3f}m",
            f"Pass condition: grain_r < neck_r → {'flow expected' if p.grain_r < p.neck_r else 'jamming likely'}",
            f"Funnel angle: {math.degrees(math.atan2(0.50, 1.80-0.85)):.1f}° from vertical",
        ],
        expected_behavior=[
            f"Grains fall into funnel from z~2m.",
            f"Small grains (r={p.grain_r:.3f}m) pass through neck (r={p.neck_r:.3f}m).",
            "Grains collect in lower chamber.",
            "Flow rate decreases as grain pile builds up.",
        ],
        parameters={
            "n_grains":   param_entry(p.n_grains,   "",    "number of grains"),
            "grain_r":    param_entry(p.grain_r,    "m",   "grain radius"),
            "neck_r":     param_entry(p.neck_r,     "m",   "funnel neck radius"),
            "friction":   param_entry(p.friction,   "",    "friction coefficient"),
            "restitution":param_entry(p.restitution,"",    "restitution coefficient"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# granular_hourglass_3d  seed={p.seed}
import math, pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}
NECK_R={p.neck_r}; GR={p.grain_r}; FR={p.friction}; RE={p.restitution}; NG={p.n_grains}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[4,4,0.02],[0.38,0.38,0.42,1.0]); _set_pose(sc,nodes["fl"],[0,0,-0.02],[0,0,0,1])
    top_r=NECK_R+0.50; n_panels=8; z_top=1.80; z_neck=0.85; z_c=(z_top+z_neck)/2; ring_r=(top_r+NECK_R)/2
    tilt=math.atan2(top_r-NECK_R,z_top-z_neck); ph=( z_top-z_neck)/2; pw=0.28; pt=0.025
    wc=[0.55,0.55,0.60,1.0]
    for i in range(n_panels):
        angle=2*math.pi*i/n_panels; px=ring_r*math.cos(angle); py=ring_r*math.sin(angle)
        orn=pb.getQuaternionFromEuler([0,tilt,angle]); he=[pt,pw,ph]
        s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=he,physicsClientId=c)
        pb.createMultiBody(0,s,-1,[px,py,z_c],orn,physicsClientId=c)
        _add_box(sc,f"fw{{i}}",nodes,he,wc); _set_pose(sc,nodes[f"fw{{i}}"],[px,py,z_c],orn)
    ch=z_neck/2; cx=NECK_R*0.85
    for j,(dx,dy) in enumerate([(1,0),(-1,0),(0,1),(0,-1)]):
        he2=[pt,cx,ch] if dx!=0 else [cx,pt,ch]; px2=dx*cx; py2=dy*cx; pz2=ch
        s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=he2,physicsClientId=c)
        pb.createMultiBody(0,s,-1,[px2,py2,pz2],[0,0,0,1],physicsClientId=c)
        _add_box(sc,f"cw{{j}}",nodes,he2,wc); _set_pose(sc,nodes[f"cw{{j}}"],[px2,py2,pz2],[0,0,0,1])
    sp=top_r*0.40; bids=[]; cols=[[0.25,0.65,0.90,1.0],[0.90,0.40,0.20,1.0],[0.30,0.85,0.40,1.0],[0.90,0.85,0.15,1.0]]
    for i in range(NG):
        ang=2*math.pi*i/NG; x=sp*math.cos(ang)*0.7; y=sp*math.sin(ang)*0.7; z=2.0+i*GR*1.8
        s=pb.createCollisionShape(pb.GEOM_SPHERE,radius=GR,physicsClientId=c)
        bid=pb.createMultiBody(0.03,s,-1,[x,y,z],[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction=FR,restitution=RE,physicsClientId=c)
        col=cols[i%len(cols)]; _add_sphere(sc,f"gr{{i}}",nodes,GR,col); bids.append((f"gr{{i}}",bid))
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c); _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_granular_hourglass_3d")
    print("OK")
