"""basketball_free_throw — basketball launched toward a cylinder-ring hoop."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (5, -5, 4)
CAM_TARGET = (0, 0, 2)
N_FRAMES   = 120


@dataclass
class Params:
    seed: int
    hoop_radius: float
    hoop_height: float
    ball_radius: float
    ball_mass: float
    launch_angle_deg: float
    launch_speed: float
    launch_x: float
    restitution: float
    floor_friction: float
    color_ball: List[float]
    color_hoop: List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        hoop_radius=random.uniform(0.22, 0.32),
        hoop_height=random.uniform(2.5, 3.5),
        ball_radius=random.uniform(0.11, 0.15),
        ball_mass=random.uniform(0.5, 0.8),
        launch_angle_deg=random.uniform(40.0, 65.0),
        launch_speed=random.uniform(5.0, 9.0),
        launch_x=random.uniform(-2.5, -1.5),
        restitution=random.uniform(0.4, 0.7),
        floor_friction=random.uniform(0.4, 0.7),
        color_ball=_rand_hue(),
        color_hoop=_rand_hue(),
    )


def _rand_hue():
    h = random.random(); s, v = 0.85, 0.90
    hi = int(h*6) % 6; f = h*6 - int(h*6)
    p_ = v*(1-s); q = v*(1-f*s); t = v*(1-(1-f)*s)
    r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
    return [r, g, b, 1.0]


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.floor_friction)
    ren.add_plane_mesh("floor", 10.0, [0.42, 0.42, 0.45, 1.0])

    # Hoop: 8 small static cylinders arranged in a circle
    n_posts = 8
    post_r = 0.025
    post_h = 0.06
    hoop_cx, hoop_cy = 0.0, 0.0
    for i in range(n_posts):
        angle = 2 * math.pi * i / n_posts
        px = hoop_cx + p.hoop_radius * math.cos(angle)
        py = hoop_cy + p.hoop_radius * math.sin(angle)
        pz = p.hoop_height
        nm = f"hp{i}"
        phys.add_cylinder(post_r, post_h, [px, py, pz], mass=0.0,
                           friction=0.3, restitution=p.restitution)
        ren.add_cylinder(nm, post_r, post_h, p.color_hoop)
        ren.set_static_pose(nm, [px, py, pz])

    # Ball launch: projectile from (launch_x, 0, ball_radius) toward hoop
    angle_rad = math.radians(p.launch_angle_deg)
    dx = hoop_cx - p.launch_x
    vx = p.launch_speed * math.cos(angle_rad)
    vz = p.launch_speed * math.sin(angle_rad)
    ball_z = p.ball_radius + 0.05
    ball_pos = [p.launch_x, 0.0, ball_z]

    ball_id = phys.add_sphere(p.ball_radius, ball_pos,
                               mass=p.ball_mass, friction=0.5,
                               restitution=p.restitution,
                               vel=(vx, 0.0, vz))
    ren.add_sphere("ball", p.ball_radius, p.color_ball, metallic=0.1, roughness=0.3)
    ren.set_static_pose("ball", ball_pos)

    dyn = [("ball", ball_id)]
    frames = run_loop(phys, ren, dyn, N_FRAMES)

    cot = build_cot(
        simulation="basketball_free_throw",
        category="mixed_complex",
        seed=seed,
        physical_observation=(
            f"Basketball r={p.ball_radius:.2f}m m={p.ball_mass:.2f}kg launched from x={p.launch_x:.2f}m "
            f"at {p.launch_angle_deg:.1f}° speed={p.launch_speed:.1f}m/s toward hoop at height={p.hoop_height:.2f}m."
        ),
        law_name="Projectile motion + Newton contact impulse",
        law_statement=(
            "Ball follows parabolic trajectory under gravity; "
            "on contact with hoop posts, impulse forces scatter the ball."
        ),
        law_formula="x(t)=x_0+v_x t; z(t)=z_0+v_z t - 0.5 g t^2",
        assumptions=[
            "Rigid ball and hoop posts",
            "Coulomb friction at contacts",
            "No air resistance on projectile",
            "Ball launched in XZ plane with Y=0",
        ],
        state_variables=["position r (m)", "velocity v (m/s)", "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "x(t)=x_0+v_x t",
            "z(t)=z_0+v_z t - \\frac{1}{2}g t^2",
            "v_z(t)=v_{z0}-gt",
            "j_n = -(1+e)\\frac{v_{rel,n}}{1/m_A+1/m_B}",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            f"Launch angle θ={p.launch_angle_deg:.1f}°, speed={p.launch_speed:.1f} m/s",
            f"v_x={p.launch_speed*math.cos(angle_rad):.2f} m/s, v_z={p.launch_speed*math.sin(angle_rad):.2f} m/s",
            f"Time to reach hoop x≈{dx:.2f}m: t≈{dx/(p.launch_speed*math.cos(angle_rad)):.2f}s",
            f"Peak height: z_peak={ball_z + (p.launch_speed*math.sin(angle_rad))**2/(2*9.81):.2f}m",
            "Ball contacts hoop post if trajectory intersects ring radius",
        ],
        expected_behavior=[
            "Ball follows parabolic arc toward hoop",
            "Ball may pass through hoop or bounce off rim posts",
            "Ball bounces on floor after interaction with hoop",
        ],
        parameters={
            "hoop_radius":      param_entry(p.hoop_radius,      "m",   "radius of the hoop ring"),
            "hoop_height":      param_entry(p.hoop_height,      "m",   "height of hoop above floor"),
            "ball_radius":      param_entry(p.ball_radius,      "m",   "basketball radius"),
            "ball_mass":        param_entry(p.ball_mass,        "kg",  "basketball mass"),
            "launch_angle_deg": param_entry(p.launch_angle_deg, "deg", "launch angle above horizontal"),
            "launch_speed":     param_entry(p.launch_speed,     "m/s", "launch speed"),
            "launch_x":         param_entry(p.launch_x,        "m",   "launch x position"),
            "restitution":      param_entry(p.restitution,      "",    "coefficient of restitution"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    n_posts = 8
    post_r = 0.025; post_h = 0.06
    angle_rad = math.radians(p.launch_angle_deg)
    vx = p.launch_speed * math.cos(angle_rad)
    vz = p.launch_speed * math.sin(angle_rad)
    ball_z = p.ball_radius + 0.05
    hoop_lines = []
    for i in range(n_posts):
        angle = 2 * math.pi * i / n_posts
        px = p.hoop_radius * math.cos(angle)
        py = p.hoop_radius * math.sin(angle)
        hoop_lines.append(
            f"    sh=pb.createCollisionShape(pb.GEOM_CYLINDER,radius={post_r},height={post_h},physicsClientId=c)\n"
            f"    pb.createMultiBody(0,sh,-1,[{px:.4f},{py:.4f},{p.hoop_height:.3f}],[0,0,0,1],physicsClientId=c)\n"
            f"    _add_cylinder(sc,'hp{i}',nodes,{post_r},{post_h},{p.color_hoop})\n"
            f"    _set_pose(sc,nodes['hp{i}'],[{px:.4f},{py:.4f},{p.hoop_height:.3f}],[0,0,0,1])\n"
        )
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# basketball_free_throw  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[5.0,5.0,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
{"".join(hoop_lines)}    sb=pb.createCollisionShape(pb.GEOM_SPHERE,radius={p.ball_radius},physicsClientId=c)
    ball=pb.createMultiBody({p.ball_mass},sb,-1,[{p.launch_x:.3f},0,{ball_z:.3f}],[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(ball,-1,lateralFriction=0.5,restitution={p.restitution},physicsClientId=c)
    pb.resetBaseVelocity(ball,[{vx:.4f},0,{vz:.4f}],[0,0,0],physicsClientId=c)
    _add_sphere(sc,"ball",nodes,{p.ball_radius},{p.color_ball})
    _set_pose(sc,nodes["ball"],[{p.launch_x:.3f},0,{ball_z:.3f}],[0,0,0,1])
    bids=[("ball",ball)]
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pos,orn=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pos,orn)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete()
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_basketball_free_throw")
    print("OK")
