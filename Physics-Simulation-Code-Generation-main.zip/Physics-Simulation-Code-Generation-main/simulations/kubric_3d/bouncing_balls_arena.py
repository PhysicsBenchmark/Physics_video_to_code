"""bouncing_balls_arena — N spheres with varying restitution in a walled arena."""
from __future__ import annotations
import os, sys, math, random, json
from dataclasses import dataclass, asdict, field
from typing import List
import numpy as np

CAM_EYE    = (0.0,  0.0, 9.0)   # top-down avoids looking through side walls
CAM_TARGET = (0.0,  0.0, 0.0)
N_FRAMES   = 150   # 5 s @ 30 fps


@dataclass
class Params:
    seed:        int
    n_balls:     int
    radii:       List[float]
    masses:      List[float]
    restitutions: List[float]
    frictions:   List[float]
    colors:      List[List[float]]
    positions:   List[List[float]]
    velocities:  List[List[float]]
    floor_friction: float
    wall_restitution: float
    arena_half: float


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    n  = random.randint(5, 10)
    ah = random.uniform(1.5, 2.5)          # smaller arena — visible from top cam
    radii  = [random.uniform(0.10, 0.25) for _ in range(n)]
    masses = [random.uniform(0.2, 3.0)   for _ in range(n)]
    rests  = [random.uniform(0.4, 0.95)  for _ in range(n)]
    frics  = [random.uniform(0.1, 0.5)   for _ in range(n)]
    pos    = [[random.uniform(-ah+r+0.05, ah-r-0.05),
               random.uniform(-ah+r+0.05, ah-r-0.05),
               random.uniform(0.3, 2.5)] for r in radii]
    vels   = [[random.uniform(-3.5, 3.5),
               random.uniform(-3.5, 3.5), 0.0] for _ in range(n)]
    colors = [[random.random(), random.random(), random.random(), 1.0] for _ in range(n)]
    return Params(seed=seed, n_balls=n, radii=radii, masses=masses,
                  restitutions=rests, frictions=frics, colors=colors,
                  positions=pos, velocities=vels,
                  floor_friction=random.uniform(0.3, 0.7),
                  wall_restitution=random.uniform(0.6, 0.90),
                  arena_half=ah)


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    params = random_params(seed)
    p = params

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    # floor
    phys.add_plane(z=0.0, friction=p.floor_friction)
    ren.add_plane_mesh("floor", p.arena_half*2+0.5, [0.45,0.45,0.48,1.0])

    # walls
    ah, wh = p.arena_half, 2.5
    wall_col = [0.30, 0.32, 0.35, 0.9]
    for wname, he, wpos in [
        ("wN",(ah,0.05,wh),(0, ah,wh)),("wS",(ah,0.05,wh),(0,-ah,wh)),
        ("wE",(0.05,ah,wh),(ah, 0,wh)),("wW",(0.05,ah,wh),(-ah,0,wh))]:
        phys.add_box(he, wpos, mass=0, friction=0.4, restitution=p.wall_restitution)
        ren.add_box(wname, he, wall_col)
        ren.set_static_pose(wname, wpos)

    # balls
    dyn = []
    for i in range(p.n_balls):
        bid = phys.add_sphere(p.radii[i], p.positions[i], mass=p.masses[i],
                              friction=p.frictions[i], restitution=p.restitutions[i],
                              vel=p.velocities[i])
        ren.add_sphere(f"b{i}", p.radii[i], p.colors[i])
        dyn.append((f"b{i}", bid))

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    params_d = asdict(params)
    cot = build_cot(
        simulation="bouncing_balls_arena", category="rigid_body_free_dynamics",
        seed=seed,
        physical_observation=(
            f"{p.n_balls} spheres (radii {[round(r,3) for r in p.radii]} m, "
            f"masses {[round(m,2) for m in p.masses]} kg) in a "
            f"{p.arena_half*2:.1f}×{p.arena_half*2:.1f} m walled arena. "
            f"Restitutions {[round(e,2) for e in p.restitutions]}."),
        law_name="Newton-Euler rigid-body dynamics + Coulomb contact + restitution impulse",
        law_statement="Each sphere obeys F=ma; wall/floor contacts resolved via impulse j_n=-(1+e)v_n/w.",
        law_formula="j_n = -(1+e)·v_n⁻ / (1/m_A + 1/m_B);  a = F_net/m",
        assumptions=["Point-mass approximation for rotation during free flight",
                     "Coulomb friction: |j_t| ≤ μ|j_n|",
                     "Coefficient of restitution e is constant per object pair"],
        state_variables=["position r∈ℝ³ (m)","velocity v∈ℝ³ (m/s)",
                         "quaternion q (orientation)","angular velocity ω∈ℝ³ (rad/s)"],
        equations_latex=["\\dot{r}=v","m\\dot{v}=mg\\hat{z}+F_{contact}",
                         "\\dot{q}=\\tfrac{1}{2}q\\otimes\\omega",
                         "I\\dot{\\omega}=\\tau_{contact}-\\omega\\times I\\omega"],
        contact_impulse="j_n = -(1+e)·(v_{rel}·n̂) / (1/m_A + 1/m_B + cross terms)",
        derivation_steps=[
            "Free flight: integrate ṙ=v, v̇=g under gravity.",
            f"On contact with wall/floor: decompose v_rel into normal v_n and tangential v_t.",
            "Normal impulse: j_n = -(1+e)·v_n / (sum of inverse masses + inertia terms).",
            "Tangential impulse clamped by Coulomb: |j_t| ≤ μ·|j_n|.",
            "Update velocities: v ← v + j/m."],
        expected_behavior=[
            f"High-restitution balls (e≈{max(p.restitutions):.2f}) bounce many times.",
            f"Low-restitution balls (e≈{min(p.restitutions):.2f}) come to rest quickly.",
            "All balls confined within walls; lateral spread from initial velocities."],
        parameters={k: param_entry(asdict(params)[k], "various", k) for k in
                    ["n_balls","radii","masses","restitutions","frictions","floor_friction"]})
    save_sample(out_dir, params_d, cot, make_standalone_code(params), frames)
    phys.close(); ren.close()


def make_standalone_code(params: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    p = params
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# ── bouncing_balls_arena  seed={p.seed} ──────────────────────────────────────
N_FRAMES   = {N_FRAMES}
CAM_EYE    = {CAM_EYE}
CAM_TARGET = {CAM_TARGET}

def main():
    c = _init_physics()
    import pybullet as p
    import pybullet_data
    ren, sc = _make_renderer(CAM_EYE, CAM_TARGET)
    nodes = {{}}

    ah = {p.arena_half}
    # floor
    p.loadURDF("plane.urdf", [0,0,0], physicsClientId=c)
    _add_box(sc,"floor",nodes,[ah+0.5,ah+0.5,0.02],[0.45,0.45,0.48,1.0])
    _set_pose(sc,nodes["floor"],[0,0,0],[0,0,0,1])

    # walls
    wh=2.5
    for wn,he,wp in [("wN",({p.arena_half},0.05,wh),(0,{p.arena_half},wh)),
                     ("wS",({p.arena_half},0.05,wh),(0,-{p.arena_half},wh)),
                     ("wE",(0.05,{p.arena_half},wh),({p.arena_half},0,wh)),
                     ("wW",(0.05,{p.arena_half},wh),(-{p.arena_half},0,wh))]:
        s=p.createCollisionShape(p.GEOM_BOX,halfExtents=list(he),physicsClientId=c)
        p.createMultiBody(0,s,-1,list(wp),[0,0,0,1],physicsClientId=c)
        _add_box(sc,wn,nodes,he,[0.30,0.32,0.35,0.9])
        _set_pose(sc,nodes[wn],wp,[0,0,0,1])

    # balls
    bids=[]
    radii  ={p.radii}
    masses ={p.masses}
    rests  ={p.restitutions}
    frics  ={p.frictions}
    colors ={p.colors}
    pos    ={p.positions}
    vels   ={p.velocities}
    for i in range({p.n_balls}):
        s=p.createCollisionShape(p.GEOM_SPHERE,radius=radii[i],physicsClientId=c)
        bid=p.createMultiBody(masses[i],s,-1,pos[i],[0,0,0,1],physicsClientId=c)
        p.changeDynamics(bid,-1,lateralFriction=frics[i],restitution=rests[i],physicsClientId=c)
        p.resetBaseVelocity(bid,vels[i],[0,0,0],physicsClientId=c)
        _add_sphere(sc,f"b{{i}}",nodes,radii[i],colors[i])
        bids.append(bid)

    frames=[]
    import pybullet as pb
    for _ in range(N_FRAMES):
        for __ in range(8):
            pb.stepSimulation(physicsClientId=c)
        for i,bid in enumerate(bids):
            pos2,orn=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[f"b{{i}}"],pos2,orn)
        rgba,_=ren.render(sc,flags=__import__('pyrender').RenderFlags.RGBA)
        frames.append(rgba[:,:,:3])

    _save_video(frames,"video.mp4")
    pb.disconnect(c)
    ren.delete()
    print("Saved video.mp4")

if __name__=="__main__":
    main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_bouncing_balls")
    print("OK →", "/tmp/test_bouncing_balls")
