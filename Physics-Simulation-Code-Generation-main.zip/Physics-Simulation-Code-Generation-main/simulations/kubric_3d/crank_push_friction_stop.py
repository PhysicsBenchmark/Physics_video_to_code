"""crank_push_friction_stop — rotating crank arm strikes a block; floor friction halts it.

The crank arm is pinned to a static anchor at the pivot via a JOINT_REVOLUTE constraint
around the vertical axis. The arm has an initial angular velocity around Z. As it sweeps
through ~180°, its tip strikes a block resting on the floor. Tangential momentum is
transferred to the block, which then decelerates to a stop under Coulomb friction with
the floor. Joint angular damping bleeds the arm's residual rotation."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (2.0, -3.6, 2.2)
CAM_TARGET = (-1.0, -0.4, 0.15)
N_FRAMES   = 150


@dataclass
class Params:
    seed: int
    arm_length: float
    arm_mass: float
    omega0: float           # initial angular velocity around +Z (rad/s, CCW from above)
    block_mass: float
    block_friction: float
    angular_damping: float
    arm_color: List[float]
    block_color: List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    def _hue():
        h = random.random(); s, v = 0.85, 0.90; hi = int(h*6) % 6; f = h*6 - int(h*6)
        p_ = v*(1-s); q = v*(1-f*s); t = v*(1-(1-f)*s)
        r, g, b = [(v,t,p_),(q,v,p_),(p_,v,t),(p_,q,v),(t,p_,v),(v,p_,q)][hi]
        return [r, g, b, 1.0]
    return Params(
        seed=seed,
        arm_length=0.85,
        arm_mass=random.uniform(1.6, 2.4),
        omega0=random.uniform(4.0, 5.5),
        block_mass=random.uniform(0.40, 0.65),
        block_friction=random.uniform(0.25, 0.38),
        angular_damping=0.30,
        arm_color=[0.94, 0.74, 0.18, 1.0],
        block_color=_hue(),
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        STANDALONE_IMPORTS, STANDALONE_UTILS, FPS)
    import pybullet as pb_mod

    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.block_friction)
    ren.add_plane_mesh("floor", 8.0, [0.42, 0.42, 0.45, 1.0])
    ren.set_static_pose("floor", [0, 0, -0.02])

    pivot  = [-1.0, 0.0, 0.10]
    L_half = p.arm_length / 2.0

    # Visible axle pole (decorative): represents the rotation axis the arm pivots around
    ren.add_cylinder("pole", 0.04, 0.40, [0.45, 0.40, 0.32, 1.0])
    ren.set_static_pose("pole", [pivot[0], pivot[1], 0.20])

    # Visible pivot marker (decorative)
    ren.add_sphere("pivot_m", 0.045, [0.85, 0.85, 0.85, 1.0])
    ren.set_static_pose("pivot_m", pivot)

    # Crank as a 2-link multi-body: static base (anchor) + arm link via JOINT_REVOLUTE.
    # The link URDF frame coincides with the joint, so we put it AT the base origin
    # (=pivot) and offset the box collision shape by L_half along +x. The inertial
    # frame is also at L_half so the CoM is at the bar's geometric centre. As the
    # joint rotates, the bar sweeps around the pivot at its near end.
    arm_he = [L_half, 0.05, 0.04]
    anchor_shape = pb_mod.createCollisionShape(pb_mod.GEOM_SPHERE, radius=0.025,
                                               physicsClientId=phys.client)
    arm_shape    = pb_mod.createCollisionShape(
        pb_mod.GEOM_BOX, halfExtents=arm_he,
        collisionFramePosition=[L_half, 0, 0],
        physicsClientId=phys.client)
    crank_mb = pb_mod.createMultiBody(
        baseMass=0.0,
        baseCollisionShapeIndex=anchor_shape,
        basePosition=pivot,
        baseOrientation=[0, 0, 0, 1],
        linkMasses=[p.arm_mass],
        linkCollisionShapeIndices=[arm_shape],
        linkVisualShapeIndices=[-1],
        linkPositions=[[0, 0, 0]],                  # joint at base origin = pivot
        linkOrientations=[[0, 0, 0, 1]],
        linkInertialFramePositions=[[L_half, 0, 0]],  # CoM at bar centre
        linkInertialFrameOrientations=[[0, 0, 0, 1]],
        linkParentIndices=[0],
        linkJointTypes=[pb_mod.JOINT_REVOLUTE],
        linkJointAxis=[[0, 0, 1]],
        physicsClientId=phys.client,
    )
    pb_mod.changeDynamics(crank_mb, 0, lateralFriction=0.4, restitution=0.20,
                          linearDamping=0.0, angularDamping=0.0,
                          jointDamping=p.angular_damping,
                          physicsClientId=phys.client)
    pb_mod.resetJointState(crank_mb, jointIndex=0,
                           targetValue=0.0, targetVelocity=p.omega0,
                           physicsClientId=phys.client)
    pb_mod.setJointMotorControl2(crank_mb, 0, controlMode=pb_mod.VELOCITY_CONTROL,
                                 force=0.0, physicsClientId=phys.client)
    ren.add_box("arm", arm_he, p.arm_color)

    # Block resting on floor, in the arm's swing path. Arm sweeps CCW from θ=0 (+x)
    # toward θ=π (-x); the block is placed slightly into the −y region beyond the arm's
    # tip at θ=π so the arm strikes it at θ ≈ 190°, delivering tangential +x⨯mostly−y momentum.
    blk_he   = [0.16, 0.16, 0.10]
    blk_pos  = [pivot[0] - p.arm_length + 0.05, -0.32, blk_he[2]]
    block_id = phys.add_box(blk_he, blk_pos, mass=p.block_mass,
                            friction=p.block_friction, restitution=0.20,
                            lin_damp=0.05, ang_damp=0.10)
    ren.add_box("block", blk_he, p.block_color)

    # Sync the arm link (it's part of the multi-body, not a standalone body)
    _crank = crank_mb
    def extra_sync_fn(phys, ren, fi):
        ls = pb_mod.getLinkState(_crank, 0, physicsClientId=phys.client)
        ren.set_pose("arm", list(ls[0]), list(ls[1]))

    dyn = [("block", block_id)]
    frames = run_loop(phys, ren, dyn, N_FRAMES, extra_sync_fn=extra_sync_fn)

    g = 9.81
    v_tip   = p.omega0 * p.arm_length
    m_eff   = p.arm_mass / 3.0   # uniform bar pivoted at one end: I/L² = m/3
    e       = 0.20
    v_block = (1+e) * m_eff * v_tip / (m_eff + p.block_mass)
    slide_d = v_block**2 / (2 * p.block_friction * g)
    slide_t = v_block / (p.block_friction * g)
    cot = build_cot(
        simulation="crank_push_friction_stop",
        category="rigid_body_constrained",
        seed=seed,
        physical_observation=(
            f"Crank arm (L={p.arm_length:.2f}m, m={p.arm_mass:.2f}kg, ω₀={p.omega0:.1f}rad/s) "
            f"swings about a vertical axle and strikes a block (m={p.block_mass:.2f}kg). "
            f"Block slides ≈{slide_d:.2f}m before friction (μ={p.block_friction:.2f}) halts it."
        ),
        law_name="Rotational impact + Coulomb friction deceleration",
        law_statement=(
            "Crank carries angular momentum L=Iω. Tangential collision transfers momentum to block. "
            "Block KE dissipates as friction work: F·d=μMg·d."
        ),
        law_formula="v_{tip}=L\\omega;\\quad v_{blk}'=\\frac{(1+e)(m/3)v_{tip}}{m/3+M};\\quad d=v^2/(2\\mu g)",
        assumptions=[
            "Massless rigid axle (JOINT_REVOLUTE around vertical axis).",
            "Uniform bar: moment of inertia I=⅓mL² about pivoted end.",
            "Coulomb friction at floor; restitution e captures collision energy loss.",
            "Joint angular damping models bearing friction.",
        ],
        state_variables=["θ_arm (rad)", "ω_arm (rad/s)", "x_block (m)", "v_block (m/s)"],
        equations_latex=[
            "I\\dot\\omega=\\tau_{contact}-c_d\\omega",
            "v_{tip}=L\\omega",
            "M\\dot{v}=-\\mu M g\\,\\mathrm{sign}(v)",
        ],
        contact_impulse="j = (1+e)·m_eff·M·v_tip / (m_eff + M)",
        derivation_steps=[
            f"Arm tip speed: v_tip = ωL = {v_tip:.2f} m/s",
            f"Effective tip mass: m_eff = m/3 = {m_eff:.3f} kg",
            f"Block post-impact speed: v' = (1+e)·m_eff·v_tip/(m_eff+M) = {v_block:.2f} m/s",
            f"Block slide distance: d = v'²/(2μg) = {slide_d:.2f} m",
            f"Block slide duration: t = v'/(μg) = {slide_t:.2f} s",
        ],
        expected_behavior=[
            f"Arm rotates CCW at {p.omega0:.1f} rad/s about pivot at (−1.0, 0).",
            "After ≈half rotation, arm's tip strikes the block tangentially.",
            f"Block flies in roughly −y direction at ≈{v_block:.2f} m/s.",
            f"Block decelerates and stops after ≈{slide_d:.2f} m of slide.",
            "Arm continues rotating with reduced ω; gradually slows by joint damping.",
        ],
        parameters={
            "arm_length":       param_entry(p.arm_length,       "m",     "crank arm length"),
            "arm_mass":         param_entry(p.arm_mass,         "kg",    "crank arm mass"),
            "omega0":           param_entry(p.omega0,           "rad/s", "initial angular velocity"),
            "block_mass":       param_entry(p.block_mass,       "kg",    "block mass"),
            "block_friction":   param_entry(p.block_friction,   "",      "block-floor friction"),
            "angular_damping":  param_entry(p.angular_damping,  "1/s",   "joint angular damping"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    L_half = p.arm_length / 2.0
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# crank_push_friction_stop  seed={p.seed}
import math, pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}
ARM_L={p.arm_length}; AM={p.arm_mass}; OMG={p.omega0}; AD={p.angular_damping}
BM={p.block_mass}; BFR={p.block_friction}; LH={L_half}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    plane_bid=pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    pb.changeDynamics(plane_bid,-1,lateralFriction=BFR,physicsClientId=c)
    _add_box(sc,"fl",nodes,[4,4,0.02],[0.42,0.42,0.45,1.0]); _set_pose(sc,nodes["fl"],[0,0,-0.02],[0,0,0,1])
    PIV=[-1.0,0,0.10]
    _add_cylinder(sc,"pole",nodes,0.04,0.40,[0.45,0.40,0.32,1.0]); _set_pose(sc,nodes["pole"],[PIV[0],PIV[1],0.20],[0,0,0,1])
    _add_sphere(sc,"piv",nodes,0.045,[0.85,0.85,0.85,1.0]); _set_pose(sc,nodes["piv"],PIV,[0,0,0,1])
    arm_he=[LH,0.05,0.04]
    anchor_shape=pb.createCollisionShape(pb.GEOM_SPHERE,radius=0.025,physicsClientId=c)
    arm_shape=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=arm_he,collisionFramePosition=[LH,0,0],physicsClientId=c)
    crank=pb.createMultiBody(baseMass=0.0,baseCollisionShapeIndex=anchor_shape,
        basePosition=PIV,baseOrientation=[0,0,0,1],
        linkMasses=[AM],linkCollisionShapeIndices=[arm_shape],linkVisualShapeIndices=[-1],
        linkPositions=[[0,0,0]],linkOrientations=[[0,0,0,1]],
        linkInertialFramePositions=[[LH,0,0]],linkInertialFrameOrientations=[[0,0,0,1]],
        linkParentIndices=[0],linkJointTypes=[pb.JOINT_REVOLUTE],linkJointAxis=[[0,0,1]],
        physicsClientId=c)
    pb.changeDynamics(crank,0,lateralFriction=0.4,restitution=0.2,linearDamping=0.0,angularDamping=0.0,jointDamping=AD,physicsClientId=c)
    pb.resetJointState(crank,jointIndex=0,targetValue=0.0,targetVelocity=OMG,physicsClientId=c)
    pb.setJointMotorControl2(crank,0,controlMode=pb.VELOCITY_CONTROL,force=0.0,physicsClientId=c)
    _add_box(sc,"arm",nodes,arm_he,{p.arm_color})
    blk_he=[0.16,0.16,0.10]; blk_pos=[PIV[0]-ARM_L+0.05,-0.32,blk_he[2]]
    sb2=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=blk_he,physicsClientId=c)
    blk=pb.createMultiBody(BM,sb2,-1,blk_pos,[0,0,0,1],physicsClientId=c)
    pb.changeDynamics(blk,-1,lateralFriction=BFR,restitution=0.2,linearDamping=0.05,angularDamping=0.10,physicsClientId=c)
    _add_box(sc,"blk",nodes,blk_he,{p.block_color}); _set_pose(sc,nodes["blk"],blk_pos,[0,0,0,1])
    frames=[]
    for fi in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        ls=pb.getLinkState(crank,0,physicsClientId=c); _set_pose(sc,nodes["arm"],list(ls[0]),list(ls[1]))
        bp,bo=pb.getBasePositionAndOrientation(blk,physicsClientId=c); _set_pose(sc,nodes["blk"],bp,bo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_crank_push_friction_stop")
    print("OK")
