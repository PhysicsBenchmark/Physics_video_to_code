"""domino_chain — cascade of upright dominoes knocked over in sequence."""
from __future__ import annotations
import os, sys, math, random
from dataclasses import dataclass, asdict
from typing import List
import numpy as np

CAM_EYE    = (6.0, 0.0, 3.0)
CAM_TARGET = (0.0, 0.0, 0.8)
N_FRAMES   = 150  # 5 s @ 30 fps


@dataclass
class Params:
    seed:         int
    n_dominoes:   int
    spacing:      float   # centre-to-centre spacing along Y (m)
    push_vel:     float   # initial velocity of first domino in +Y (m/s)
    domino_mass:  float   # kg per domino
    restitution:  float
    friction:     float
    domino_color: List[float]
    floor_color:  List[float]


def random_params(seed: int) -> Params:
    random.seed(seed); np.random.seed(seed)
    return Params(
        seed=seed,
        n_dominoes=random.randint(6, 14),
        # Spacing: 0.7x domino height (2*hz=0.60m) so each falling domino hits next
        spacing=random.uniform(0.32, 0.45),
        push_vel=random.uniform(1.5, 3.0),
        domino_mass=random.uniform(0.05, 0.25),
        restitution=random.uniform(0.2, 0.5),
        friction=random.uniform(0.4, 0.8),
        domino_color=[random.uniform(0.5, 1.0), random.uniform(0.3, 0.8),
                      random.uniform(0.2, 0.7), 1.0],
        floor_color=[0.40, 0.38, 0.35, 1.0],
    )


def generate_sample(seed: int, out_dir: str):
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import (
        Physics, Renderer, run_loop, save_sample, build_cot, param_entry,
        random_hue_color, muted_grey, STANDALONE_IMPORTS, STANDALONE_UTILS)
    random.seed(seed); np.random.seed(seed)
    p = random_params(seed)

    phys = Physics()
    ren  = Renderer(CAM_EYE, CAM_TARGET)

    phys.add_plane(friction=p.friction)
    ren.add_plane_mesh("floor", 10.0, p.floor_color)
    ren.set_static_pose("floor", [0, 0, -0.02])

    import pybullet as pb

    # Domino half-extents: thin in Y (fall direction), wide in X, tall in Z
    # Dominoes line up along Y; each falls forward in +Y
    hx, hy, hz = 0.15, 0.04, 0.30   # wide in X, thin in Y, tall in Z
    dyn = []
    for i in range(p.n_dominoes):
        y_pos = i * p.spacing
        bid = phys.add_box([hx, hy, hz],
                           [0.0, y_pos, hz],   # stand upright: center z = hz
                           mass=p.domino_mass,
                           friction=p.friction,
                           restitution=p.restitution)
        # Give the first domino a strong push: angular vel around -X tips it forward in +Y
        if i == 0:
            ang_tip = p.push_vel / hz
            pb.resetBaseVelocity(bid, [0.0, p.push_vel * 0.5, 0.0],
                                 [-ang_tip, 0.0, 0.0],
                                 physicsClientId=phys.client)
        name = f"dom_{i}"
        ren.add_box(name, [hx, hy, hz], p.domino_color)
        dyn.append((name, bid))

    frames = run_loop(phys, ren, dyn, N_FRAMES)

    total_y = (p.n_dominoes - 1) * p.spacing
    cot = build_cot(
        simulation="domino_chain",
        category="rigid_body_free_dynamics",
        seed=seed,
        physical_observation=(
            f"A line of {p.n_dominoes} upright dominoes "
            f"(0.10×0.40×0.60 m, mass {p.domino_mass:.3f} kg each) "
            f"spaced {p.spacing:.2f} m apart. "
            f"First domino pushed at {p.push_vel:.2f} m/s in +Y."),
        law_name="Newton-Euler rigid-body dynamics + contact cascade",
        law_statement=(
            "Each falling domino transfers angular momentum via contact impulse "
            "to the next, triggering a chain reaction."),
        law_formula="j_n = -(1+e)*v_rel_n / (1/m_A + 1/m_B + cross_terms)",
        assumptions=[
            "Dominoes are rigid; no elastic deformation.",
            "Floor is flat and provides Coulomb friction.",
            "Spacing chosen so each falling domino can reach the next.",
        ],
        state_variables=["position r (m)", "velocity v (m/s)",
                         "quaternion q", "angular velocity ω (rad/s)"],
        equations_latex=[
            "\\dot{r}=v",
            "m\\dot{v}=mg+F_c",
            "I\\dot{\\omega}=\\tau_c-\\omega\\times I\\omega",
        ],
        contact_impulse="j_n = -(1+e)·v_n / (1/m_A + 1/m_B)",
        derivation_steps=[
            f"Domino 0 given initial velocity {p.push_vel:.2f} m/s in +Y.",
            "Domino tilts under gravity; contact point moves forward.",
            "Impact impulse tips domino i+1, initiating cascade.",
            f"Cascade propagates across {p.n_dominoes} dominoes over ~{total_y:.2f} m.",
        ],
        expected_behavior=[
            "First domino topples and hits second.",
            "Chain reaction propagates down the line.",
            f"All {p.n_dominoes} dominoes fall sequentially.",
        ],
        parameters={
            "n_dominoes":   param_entry(p.n_dominoes, "",    "Number of dominoes"),
            "spacing_m":    param_entry(p.spacing,    "m",   "Centre-to-centre spacing"),
            "push_vel_mps": param_entry(p.push_vel,   "m/s", "Initial push velocity"),
            "domino_mass_kg": param_entry(p.domino_mass, "kg", "Mass per domino"),
            "restitution":  param_entry(p.restitution, "",   "Coefficient of restitution"),
            "friction":     param_entry(p.friction,    "",   "Lateral friction coefficient"),
        })
    save_sample(out_dir, asdict(p), cot, make_standalone_code(p), frames)
    phys.close(); ren.close()


def make_standalone_code(p: Params) -> str:
    _dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, _dir)
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f"""
# domino_chain  seed={p.seed}
import pybullet as pb
N_FRAMES={N_FRAMES}; CAM_EYE={CAM_EYE}; CAM_TARGET={CAM_TARGET}

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    pb.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"fl",nodes,[5.0,5.0,0.02],[0.40,0.38,0.35,1.0])
    _set_pose(sc,nodes["fl"],[0,0,0],[0,0,0,1])
    hx,hy,hz=0.15,0.04,0.30; dc={p.domino_color}
    bids=[]
    for i in range({p.n_dominoes}):
        y_pos=i*{p.spacing}
        s=pb.createCollisionShape(pb.GEOM_BOX,halfExtents=[hx,hy,hz],physicsClientId=c)
        bid=pb.createMultiBody({p.domino_mass},s,-1,[0,y_pos,hz],[0,0,0,1],physicsClientId=c)
        pb.changeDynamics(bid,-1,lateralFriction={p.friction},restitution={p.restitution},physicsClientId=c)
        if i==0:
            ang_tip={p.push_vel}/hz
            pb.resetBaseVelocity(bid,[0,{p.push_vel*0.5},0],[-ang_tip,0,0],physicsClientId=c)
        nm=f"dom_{{i}}"
        _add_box(sc,nm,nodes,[hx,hy,hz],dc); bids.append((nm,bid))
    frames=[]
    for _ in range(N_FRAMES):
        for __ in range(8): pb.stepSimulation(physicsClientId=c)
        for nm,bid in bids:
            pp,oo=pb.getBasePositionAndOrientation(bid,physicsClientId=c)
            _set_pose(sc,nodes[nm],pp,oo)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); pb.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
"""


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_domino_chain")
    print("OK")
