"""stick_support_catapult_release — counterweight-driven trebuchet whose
support stick topples at t=0, releasing the lever to launch the projectile."""
from __future__ import annotations
import math, random
from dataclasses import asdict

import numpy as np
import pybullet as pb

from ._advanced_life_scenes import _COMMON_ASSUMPTIONS, _COMMON_DERIV, _COMMON_EQ, _SPEC
from ._real_life_scenes import (
    CAM_DEFAULT,
    N_FRAMES,
    Params,
    TARGET_DEFAULT,
    _base_summary,
    _box,
    _cylinder,
    _sphere,
    _visual,
)

EXPERIMENT = "stick_support_catapult_release"

# Geometry
PIVOT          = (0.0, 0.0, 1.10)
LEVER_HALF     = (0.55, 0.06, 0.025)
LEVER_PIVOT_OFFSET = (0.20, 0.0, 0.0)         # pivot in lever local frame
LEVER_M        = 0.6

CW_HALF        = (0.09, 0.09, 0.09)            # counterweight box (cube) half-extents
CW_M           = 3.5
CW_CHAIN_LEN   = 0.20                          # gap between short-arm tip and counterweight top
CW_HOOK_LOCAL  = (LEVER_HALF[0], 0.0, 0.0)     # chain attachment on lever (short-arm tip)
CHAIN_RADIUS   = 0.012
CHAIN_COLOR    = [0.30, 0.28, 0.26, 1.0]

PROJ_R         = 0.06
PROJ_M         = 0.25
PROJ_LOCAL     = (-0.50, 0.0, LEVER_HALF[2] + PROJ_R + 0.001)  # on top of lever, -x end

STICK_R        = 0.04
STICK_M        = 0.20

POLE_R         = 0.05
POLE_Y_OFFSET  = -0.18                         # pole sits behind the lever's swing plane
POLE_TOP_Z     = PIVOT[2]
ARM_R          = 0.05                          # horizontal arm linking pole top to pivot pin
ARM_LEN        = abs(POLE_Y_OFFSET)            # spans from y=POLE_Y_OFFSET to y=0 (pivot)
ARM_CENTER     = (PIVOT[0], POLE_Y_OFFSET / 2, PIVOT[2])
ARM_ORN        = (math.pi / 2, 0.0, 0.0)       # default cylinder axis Z → align with Y

COCK_ANGLE_DEG = 38.0                          # cocked: short-arm/counterweight up

WOOD     = [0.55, 0.34, 0.16, 1.0]
GREY     = [0.45, 0.45, 0.50, 1.0]
DARK     = [0.30, 0.30, 0.34, 1.0]
PROJ_COL = [0.94, 0.74, 0.18, 1.0]
RED      = [0.85, 0.18, 0.14, 1.0]


def _r_y(theta):
    c, s = math.cos(theta), math.sin(theta)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])


def _cock_quat():
    return pb.getQuaternionFromEuler([0, math.radians(-COCK_ANGLE_DEG), 0])


def _initial_lever_center():
    R = _r_y(math.radians(-COCK_ANGLE_DEG))
    return (np.array(PIVOT) - R @ np.array(LEVER_PIVOT_OFFSET)).tolist()


def _world_offset(local_offset):
    R = _r_y(math.radians(-COCK_ANGLE_DEG))
    return (np.array(_initial_lever_center()) + R @ np.array(local_offset)).tolist()


def _short_arm_tip_world():
    return _world_offset(CW_HOOK_LOCAL)


def _initial_cw_center():
    """Counterweight hangs straight down from the short-arm tip (chain taut)."""
    tip = _short_arm_tip_world()
    return [tip[0], tip[1], tip[2] - CW_CHAIN_LEN - CW_HALF[2]]


# Stick stands beside the counterweight (not under it) so it doesn't trap the
# release; it's given a kick at t=0 and topples on its own.
STICK_OFFSET_Y = 0.18


def _stick_height():
    cw = _initial_cw_center()
    return max(cw[2] - 0.05, 0.30)


def _stick_center():
    cw = _initial_cw_center()
    return [cw[0], cw[1] + STICK_OFFSET_Y, _stick_height() / 2]


def random_params(seed: int) -> Params:
    rng = random.Random(seed + abs(hash(EXPERIMENT)) % 100000)
    th = math.radians(-COCK_ANGLE_DEG)
    lever_pos = _initial_lever_center()
    cw_pos = _initial_cw_center()
    proj_pos = _world_offset(PROJ_LOCAL)
    stick_pos = _stick_center()
    stick_h = _stick_height()
    chain_anchor = _short_arm_tip_world()
    chain_mid = [chain_anchor[0], chain_anchor[1],
                 (chain_anchor[2] + cw_pos[2] + CW_HALF[2]) / 2]
    objects = [
        # Visible pivot pole + horizontal arm + pin (visual only — pivot is enforced by constraint).
        _visual(_cylinder("pivot_pole", POLE_R, POLE_TOP_Z,
                          [PIVOT[0], POLE_Y_OFFSET, POLE_TOP_Z / 2], 0, DARK)),
        _visual(_cylinder("pivot_arm", ARM_R, ARM_LEN,
                          list(ARM_CENTER), 0, DARK, orn=list(ARM_ORN))),
        _visual(_sphere("pivot_pin", 0.045, list(PIVOT), 0, RED)),
        # Visual chain (rendered live each frame; this entry just records its initial pose)
        _visual(_cylinder("chain", CHAIN_RADIUS, CW_CHAIN_LEN,
                          chain_mid, 0, CHAIN_COLOR)),
        # Lever (the catapult arm)
        _box("lever", list(LEVER_HALF), lever_pos, LEVER_M, WOOD,
             orn=[0, th, 0], friction=0.85, restitution=0.10),
        # Counterweight (heavy block hanging from the short arm by a chain — falls under gravity)
        _box("counterweight", list(CW_HALF), cw_pos, CW_M, GREY,
             friction=0.5, restitution=0.05),
        # Projectile (sits on long arm; friction holds it during the swing)
        _sphere("projectile", PROJ_R, proj_pos, PROJ_M, PROJ_COL,
                friction=0.9, restitution=0.45),
        # Support stick (kicked over at t=0 by initial angular velocity).
        _cylinder("support_stick", STICK_R, stick_h, stick_pos, STICK_M, RED,
                  friction=0.35, restitution=0.05,
                  ang_vel=[6.0, 0.0, 0.0]),
    ]
    short_arm = LEVER_HALF[0] - LEVER_PIVOT_OFFSET[0]
    long_arm  = LEVER_HALF[0] + LEVER_PIVOT_OFFSET[0]
    summary = {
        "pivot_world": list(PIVOT),
        "cock_angle_deg": COCK_ANGLE_DEG,
        "short_arm_length_m": short_arm,
        "long_arm_length_m":  long_arm,
        "lever_arm_ratio":    long_arm / short_arm,
        "lever_mass_kg":      LEVER_M,
        "counterweight_mass_kg": CW_M,
        "projectile_mass_kg": PROJ_M,
        "support_stick_initial_angular_velocity": [6.0, 0.0, 0.0],
        "phenomena_demonstrated": [
            "Static equilibrium: stick contact balances counterweight torque about pivot",
            "Release: stick topples (initial ω about x), lever loses upward support",
            "Torque about hinge: τ = r × m_cw g drives angular acceleration",
            "Mechanical advantage: tip speed = (long_arm/short_arm) × counterweight speed",
            "Energy conversion: counterweight ΔPE → rotational KE → projectile KE",
            "Projectile motion: parabolic free flight after launch",
        ],
    }
    return Params(seed=seed, experiment=EXPERIMENT, objects=objects,
                  camera_eye=CAM_DEFAULT, camera_target=TARGET_DEFAULT,
                  floor_size=10.0, summary=summary)


def _cot(params: Params):
    from simulations.kubric_3d._base import build_cot, param_entry
    category, law, formula = _SPEC[EXPERIMENT]
    entries = {k: param_entry(v, "various", k)
               for k, v in _base_summary(params).items()}
    return build_cot(
        EXPERIMENT, category, params.seed,
        f"{EXPERIMENT}: a counterweight-loaded lever is held cocked by a "
        "vertical support stick. At t=0 the stick is kicked and topples; the "
        "counterweight falls, the lever rotates about its hinge, and the "
        "projectile is launched in a parabolic arc.",
        law,
        f"{law}; PyBullet enforces the hinge with a point-to-point constraint "
        "(off-axis angular velocity zeroed each substep) and resolves stick↔"
        "lever and projectile↔lever contacts with friction-clamped impulses.",
        formula, _COMMON_ASSUMPTIONS,
        ["lever angle θ (rad)", "angular velocity ω (rad/s)",
         "torque τ about pivot (N·m)", "projectile r,v,q,ω"],
        _COMMON_EQ + ["I\\dot{\\omega}=\\tau_{cw}-\\tau_{proj}-\\tau_{lever}",
                      "v_{tip} = \\omega \\cdot \\ell_{long}",
                      "z(t)=z_0+v_z t-\\tfrac12 g t^2"],
        "j_n=-(1+e)(v_rel·n)/m_eff; |j_t|<=mu|j_n|",
        _COMMON_DERIV + [
            "Cocked equilibrium: stick contact force balances counterweight gravity torque about pivot.",
            "After stick topples (initial ω_x), contact is lost and the only torque is gravity.",
            "Counterweight falls a distance s_short·sin(θ); long-arm tip rises s_long·sin(θ).",
            "Projectile launches when surface tilt and centripetal acceleration overcome friction grip.",
        ],
        ["Stick rotates about its base in the y-z plane and falls clear of the lever within ~0.2 s.",
         "Counterweight (short arm) drops; long arm with projectile sweeps up.",
         "Projectile lifts off the lever at high tangential speed and follows a parabolic arc.",
         "Lever continues past horizontal, oscillates about its new equilibrium under gravity.",
        ],
        entries)


def make_standalone_code(params: Params) -> str:
    from simulations.kubric_3d._base import STANDALONE_IMPORTS, STANDALONE_UTILS
    th = math.radians(-COCK_ANGLE_DEG)
    cock_quat = list(pb.getQuaternionFromEuler([0, th, 0]))
    lever_pos = _initial_lever_center()
    cw_pos = _initial_cw_center()
    proj_pos = _world_offset(PROJ_LOCAL)
    stick_pos = _stick_center()
    stick_h = _stick_height()
    return STANDALONE_IMPORTS + STANDALONE_UTILS + f'''
# {EXPERIMENT}  seed={params.seed}
N_FRAMES={N_FRAMES}; CAM_EYE={repr(params.camera_eye)}; CAM_TARGET={repr(params.camera_target)}
PIVOT={list(PIVOT)}
LEVER_HALF={list(LEVER_HALF)}; LEVER_M={LEVER_M}
LEVER_POS={lever_pos}; COCK_QUAT={cock_quat}
LEVER_PIVOT_OFFSET={list(LEVER_PIVOT_OFFSET)}
CW_HALF={list(CW_HALF)}; CW_M={CW_M}; CW_HOOK_LOCAL={list(CW_HOOK_LOCAL)}; CW_POS={cw_pos}
CW_CHAIN_LEN={CW_CHAIN_LEN}; CHAIN_RADIUS={CHAIN_RADIUS}; CHAIN_COLOR={CHAIN_COLOR}
PROJ_R={PROJ_R}; PROJ_M={PROJ_M}; PROJ_POS={proj_pos}
STICK_R={STICK_R}; STICK_M={STICK_M}; STICK_H={stick_h}; STICK_POS={stick_pos}
POLE_R={POLE_R}; POLE_TOP_Z={POLE_TOP_Z}; POLE_Y_OFFSET={POLE_Y_OFFSET}
ARM_R={ARM_R}; ARM_LEN={ARM_LEN}; ARM_CENTER={list(ARM_CENTER)}; ARM_ORN={list(ARM_ORN)}
WOOD={WOOD}; GREY={GREY}; DARK={DARK}; PROJ_COL={PROJ_COL}; RED={RED}
FLOOR=10.0

def main():
    c=_init_physics(); ren,sc=_make_renderer(CAM_EYE,CAM_TARGET); nodes={{}}
    p.loadURDF("plane.urdf",[0,0,0],physicsClientId=c)
    _add_box(sc,"floor",nodes,[FLOOR/2,FLOOR/2,0.02],[0.42,0.42,0.45,1.0])
    _set_pose(sc,nodes["floor"],[0,0,-0.02],[0,0,0,1])
    _add_cylinder(sc,"pivot_pole",nodes,POLE_R,POLE_TOP_Z,DARK)
    _set_pose(sc,nodes["pivot_pole"],[PIVOT[0],POLE_Y_OFFSET,POLE_TOP_Z/2],[0,0,0,1])
    _add_cylinder(sc,"pivot_arm",nodes,ARM_R,ARM_LEN,DARK)
    _set_pose(sc,nodes["pivot_arm"],ARM_CENTER,p.getQuaternionFromEuler(ARM_ORN))
    _add_sphere(sc,"pivot_pin",nodes,0.045,RED); _set_pose(sc,nodes["pivot_pin"],PIVOT,[0,0,0,1])
    sl=p.createCollisionShape(p.GEOM_BOX,halfExtents=LEVER_HALF,physicsClientId=c)
    lever=p.createMultiBody(LEVER_M,sl,-1,LEVER_POS,COCK_QUAT,physicsClientId=c)
    p.changeDynamics(lever,-1,lateralFriction=0.85,restitution=0.10,
        linearDamping=0.0,angularDamping=0.05,physicsClientId=c)
    sc_=p.createCollisionShape(p.GEOM_BOX,halfExtents=CW_HALF,physicsClientId=c)
    cw=p.createMultiBody(CW_M,sc_,-1,CW_POS,[0,0,0,1],physicsClientId=c)
    p.changeDynamics(cw,-1,lateralFriction=0.5,restitution=0.05,
        linearDamping=0.0,angularDamping=0.05,physicsClientId=c)
    sp=p.createCollisionShape(p.GEOM_SPHERE,radius=PROJ_R,physicsClientId=c)
    proj=p.createMultiBody(PROJ_M,sp,-1,PROJ_POS,[0,0,0,1],physicsClientId=c)
    p.changeDynamics(proj,-1,lateralFriction=0.9,restitution=0.45,
        linearDamping=0.0,angularDamping=0.05,physicsClientId=c)
    ss=p.createCollisionShape(p.GEOM_CYLINDER,radius=STICK_R,height=STICK_H,physicsClientId=c)
    stick=p.createMultiBody(STICK_M,ss,-1,STICK_POS,[0,0,0,1],physicsClientId=c)
    p.changeDynamics(stick,-1,lateralFriction=0.35,restitution=0.05,
        linearDamping=0.0,angularDamping=0.05,physicsClientId=c)
    p.resetBaseVelocity(stick,[0,0,0],[6.0,0,0],physicsClientId=c)
    cid_p=p.createConstraint(lever,-1,-1,-1,p.JOINT_POINT2POINT,[0,0,1],
        LEVER_PIVOT_OFFSET, PIVOT, physicsClientId=c)
    p.changeConstraint(cid_p,maxForce=80000,physicsClientId=c)
    cid_cw=p.createConstraint(cw,-1,lever,-1,p.JOINT_POINT2POINT,[0,0,1],
        [0,0,CW_HALF[2]+CW_CHAIN_LEN], CW_HOOK_LOCAL, physicsClientId=c)
    p.changeConstraint(cid_cw,maxForce=80000,physicsClientId=c)
    _add_box(sc,"lever",nodes,LEVER_HALF,WOOD)
    _add_box(sc,"counterweight",nodes,CW_HALF,GREY)
    _add_sphere(sc,"projectile",nodes,PROJ_R,PROJ_COL)
    _add_cylinder(sc,"support_stick",nodes,STICK_R,STICK_H,RED)
    bodies=[("lever",lever),("counterweight",cw),("projectile",proj),("support_stick",stick)]
    frames=[]
    for fi in range(N_FRAMES):
        for _ in range(8):
            p.stepSimulation(physicsClientId=c)
            v,om=p.getBaseVelocity(lever,physicsClientId=c)
            p.resetBaseVelocity(lever,v,[0.0,om[1],0.0],physicsClientId=c)
        for nm,bid in bodies:
            pp,oo=p.getBasePositionAndOrientation(bid,physicsClientId=c); _set_pose(sc,nodes[nm],pp,oo)
        lp,lq=p.getBasePositionAndOrientation(lever,physicsClientId=c)
        cwp,cwq=p.getBasePositionAndOrientation(cw,physicsClientId=c)
        Rl=np.array(p.getMatrixFromQuaternion(lq)).reshape(3,3)
        Rc=np.array(p.getMatrixFromQuaternion(cwq)).reshape(3,3)
        chain_top=(np.array(lp)+Rl@np.array(CW_HOOK_LOCAL)).tolist()
        chain_bot=(np.array(cwp)+Rc@np.array([0,0,CW_HALF[2]])).tolist()
        _update_string(sc,nodes,"chain",chain_top,chain_bot,radius=CHAIN_RADIUS,color=CHAIN_COLOR)
        rgba,_=ren.render(sc,flags=pyrender.RenderFlags.RGBA); frames.append(rgba[:,:,:3])
    _save_video(frames,"video.mp4"); p.disconnect(c); ren.delete(); print("Saved video.mp4")
if __name__=="__main__": main()
'''


def generate_sample(seed: int, out_dir: str):
    from simulations.kubric_3d._base import (
        Physics, Renderer, save_sample, STEP_RATE, FPS, metadata_only,
    )
    params = random_params(seed)

    phys = Physics()
    ren = Renderer(params.camera_eye, params.camera_target)
    phys.add_plane(friction=0.6)
    ren.add_plane_mesh("floor", params.floor_size, [0.42, 0.42, 0.45, 1.0])

    ren.add_cylinder("pivot_pole", POLE_R, POLE_TOP_Z, DARK)
    ren.set_static_pose("pivot_pole",
                        [PIVOT[0], POLE_Y_OFFSET, POLE_TOP_Z / 2], (0, 0, 0, 1))
    ren.add_cylinder("pivot_arm", ARM_R, ARM_LEN, DARK)
    ren.set_static_pose("pivot_arm", list(ARM_CENTER),
                        pb.getQuaternionFromEuler(list(ARM_ORN)))
    ren.add_sphere("pivot_pin", 0.045, RED)
    ren.set_static_pose("pivot_pin", list(PIVOT), (0, 0, 0, 1))

    cock_quat = _cock_quat()
    lever_pos = _initial_lever_center()
    cw_pos = _initial_cw_center()
    proj_pos = _world_offset(PROJ_LOCAL)
    stick_pos = _stick_center()
    stick_h = _stick_height()

    lever_id = phys.add_box(list(LEVER_HALF), lever_pos, mass=LEVER_M,
                            orn=cock_quat, friction=0.85, restitution=0.10,
                            lin_damp=0.0, ang_damp=0.05)
    cw_id = phys.add_box(list(CW_HALF), cw_pos, mass=CW_M,
                         friction=0.5, restitution=0.05,
                         lin_damp=0.0, ang_damp=0.05)
    proj_id = phys.add_sphere(PROJ_R, proj_pos, mass=PROJ_M,
                              friction=0.9, restitution=0.45,
                              lin_damp=0.0, ang_damp=0.05)
    stick_id = phys.add_cylinder(STICK_R, stick_h, stick_pos, mass=STICK_M,
                                 friction=0.35, restitution=0.05,
                                 ang_vel=[6.0, 0.0, 0.0])

    ren.add_box("lever", list(LEVER_HALF), WOOD)
    ren.add_box("counterweight", list(CW_HALF), GREY)
    ren.add_sphere("projectile", PROJ_R, PROJ_COL)
    ren.add_cylinder("support_stick", STICK_R, stick_h, RED)

    # Pivot: lever ↔ world (point-to-point; off-axis ω zeroed manually).
    phys.create_constraint(
        lever_id, -1, -1, -1,
        pb.JOINT_POINT2POINT, [0, 0, 1],
        list(LEVER_PIVOT_OFFSET), list(PIVOT),
        max_force=80000.0)
    # Counterweight ↔ lever via chain (point-to-point — counterweight hangs and swings freely).
    phys.create_constraint(
        cw_id, -1, lever_id, -1,
        pb.JOINT_POINT2POINT, [0, 0, 1],
        [0.0, 0.0, CW_HALF[2] + CW_CHAIN_LEN],   # anchor in counterweight frame (chain top)
        list(CW_HOOK_LOCAL),                     # anchor in lever frame (short-arm tip)
        max_force=80000.0)

    bodies = [("lever", lever_id), ("counterweight", cw_id),
              ("projectile", proj_id), ("support_stick", stick_id)]

    if metadata_only():
        save_sample(out_dir, asdict(params), _cot(params),
                    make_standalone_code(params), [])
        phys.close(); ren.close()
        return

    substeps = STEP_RATE // FPS
    frames = []
    for fi in range(N_FRAMES):
        for _ in range(substeps):
            phys.step()
            v, om = pb.getBaseVelocity(lever_id, physicsClientId=phys.client)
            pb.resetBaseVelocity(lever_id, v, [0.0, om[1], 0.0],
                                 physicsClientId=phys.client)
        for name, bid in bodies:
            pos, orn = phys.get_pose(bid)
            ren.set_pose(name, pos, orn)
        # Live chain between short-arm tip and counterweight top
        lp, lq = phys.get_pose(lever_id)
        cwp, cwq = phys.get_pose(cw_id)
        Rl = np.array(pb.getMatrixFromQuaternion(lq.tolist())).reshape(3, 3)
        Rc = np.array(pb.getMatrixFromQuaternion(cwq.tolist())).reshape(3, 3)
        chain_top = (np.array(lp) + Rl @ np.array(CW_HOOK_LOCAL)).tolist()
        chain_bot = (np.array(cwp) + Rc @ np.array([0, 0, CW_HALF[2]])).tolist()
        ren.update_string("chain", chain_top, chain_bot,
                          radius=CHAIN_RADIUS, color=CHAIN_COLOR)
        frames.append(ren.render_frame())

    save_sample(out_dir, asdict(params), _cot(params),
                make_standalone_code(params), frames)
    phys.close(); ren.close()


if __name__ == "__main__":
    generate_sample(seed=0, out_dir="/tmp/test_stick_support_catapult_release")
    print("OK")
