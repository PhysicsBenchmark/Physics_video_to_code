"""
Springs Two Slabs Compound
============================
A vertical 2-DOF compound spring-mass system. Top: N_top parallel springs from
ceiling to upper slab (mass m_1). Middle: N_mid parallel springs from upper to
lower slab (mass m_2). Effective stiffnesses K_top = N_top * k_top and
K_mid = N_mid * k_mid.

Equations of motion (y up, slab CoMs y_1, y_2):
  m_1 y1_ddot = K_top (y_ceil - y_1 - L_top) - K_mid (y_1 - y_2 - L_mid) - gamma_1 v_1 - m_1 g
  m_2 y2_ddot = K_mid (y_1 - y_2 - L_mid) - gamma_2 v_2 - m_2 g
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict


@dataclass
class SpringsTwoSlabsCompoundParams:
    g: float = 9.8
    m_1: float = 1.0
    m_2: float = 0.5
    K_top: float = 120.0
    K_mid: float = 50.0
    L_top: float = 0.40
    L_mid: float = 0.30
    gamma_1: float = 0.20
    gamma_2: float = 0.15
    y_ceil: float = 1.40
    slab_w_1: float = 0.80
    slab_h_1: float = 0.06
    slab_w_2: float = 0.50
    slab_h_2: float = 0.06
    y1_0: float = 1.00
    y2_0: float = 0.70
    v1_0: float = 0.0
    v2_0: float = 0.0


def simulate(
    params: SpringsTwoSlabsCompoundParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    g = params.g
    m_1 = params.m_1
    m_2 = params.m_2
    K_top = params.K_top
    K_mid = params.K_mid
    L_top = params.L_top
    L_mid = params.L_mid
    gamma_1 = params.gamma_1
    gamma_2 = params.gamma_2
    y_ceil = params.y_ceil

    def ode(t, y):
        y1, y2, v1, v2 = y
        F_top = K_top * (y_ceil - y1 - L_top)
        F_mid = K_mid * (y1 - y2 - L_mid)
        a1 = (F_top - F_mid - gamma_1 * v1 - m_1 * g) / m_1
        a2 = (F_mid - gamma_2 * v2 - m_2 * g) / m_2
        return [v1, v2, a1, a2]

    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(ode, (0, duration),
                    [params.y1_0, params.y2_0, params.v1_0, params.v2_0],
                    t_eval=t_eval, method="RK45", rtol=1e-9, atol=1e-11)
    return sol.t, sol.y


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: SpringsTwoSlabsCompoundParams,
    output_path: str,
    fps: int = 30,
) -> None:
    y_ceil = params.y_ceil
    slab_w_1 = params.slab_w_1
    slab_h_1 = params.slab_h_1
    slab_w_2 = params.slab_w_2
    slab_h_2 = params.slab_h_2
    y1a, y2a = y[0], y[1]
    n_frames = len(t)

    # Determine the number of springs from K and a typical k
    # We just visually use 3 top + 2 mid as a fixed visual structure
    N_top = 3
    N_mid = 2

    xpad = 0.20
    half_w = max(slab_w_1, slab_w_2) / 2.0
    xlim_lo, xlim_hi = -half_w - xpad, half_w + xpad
    ylim_lo, ylim_hi = -0.10, y_ceil + 0.10

    fig, ax = plt.subplots(figsize=(6, 6), facecolor="#1a1a2e")
    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
    ax.set_facecolor("#16213e")
    ax.set_xlim(xlim_lo, xlim_hi)
    ax.set_ylim(ylim_lo, ylim_hi)
    ax.set_aspect("equal")
    ax.axis("off")

    ax.plot([xlim_lo, xlim_hi], [y_ceil, y_ceil], color="#adb5bd", lw=2.5, zorder=2)
    ceil_thickness = 0.06
    ax.add_patch(patches.Rectangle((xlim_lo, y_ceil), xlim_hi - xlim_lo, ceil_thickness,
                                   facecolor="#4a4e69", edgecolor="#adb5bd",
                                   lw=1, hatch="////", zorder=2))

    def even_x(n, width, centre=0.0):
        if n == 1:
            return np.array([centre])
        inset = min(0.06, width * 0.12)
        return np.linspace(centre - width / 2.0 + inset,
                           centre + width / 2.0 - inset, n)

    top_xs = even_x(N_top, slab_w_1, 0.0)
    mid_xs = even_x(N_mid, slab_w_2, 0.0)

    def vertical_spring_path(x, y_top, y_bot, n=8, r=0.04):
        ts = np.linspace(0, 1, n * 20 + 2)
        margin = 0.08
        env = np.where((ts < margin) | (ts > 1 - margin), 0,
                       np.sin(n * 2 * np.pi * (ts - margin) / (1 - 2 * margin)))
        ys = y_top + ts * (y_bot - y_top)
        xs = x + r * env
        return xs, ys

    top_lines = [ax.plot([], [], "-", color="#a8dadc", lw=2.0, zorder=3)[0]
                 for _ in range(N_top)]
    mid_lines = [ax.plot([], [], "-", color="#a8dadc", lw=2.0, zorder=3)[0]
                 for _ in range(N_mid)]

    slab1 = patches.Rectangle((-slab_w_1 / 2, params.y1_0 - slab_h_1 / 2),
                              slab_w_1, slab_h_1,
                              facecolor="#8ecae6", edgecolor="white", lw=1.5, zorder=4)
    slab2 = patches.Rectangle((-slab_w_2 / 2, params.y2_0 - slab_h_2 / 2),
                              slab_w_2, slab_h_2,
                              facecolor="#ffd166", edgecolor="white", lw=1.5, zorder=4)
    ax.add_patch(slab1)
    ax.add_patch(slab2)

    def update(f):
        y1 = y1a[f]
        y2 = y2a[f]
        slab1.set_y(y1 - slab_h_1 / 2)
        slab2.set_y(y2 - slab_h_2 / 2)
        upper_top = y1 + slab_h_1 / 2
        upper_bot = y1 - slab_h_1 / 2
        lower_top = y2 + slab_h_2 / 2
        for i, ln in enumerate(top_lines):
            xs, ys = vertical_spring_path(top_xs[i], y_ceil, upper_top)
            ln.set_data(xs, ys)
        for i, ln in enumerate(mid_lines):
            xs, ys = vertical_spring_path(mid_xs[i], upper_bot, lower_top)
            ln.set_data(xs, ys)
        return top_lines + mid_lines + [slab1, slab2]

    ani = animation.FuncAnimation(fig, update, frames=n_frames,
                                  interval=1000 / fps, blit=False)
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: SpringsTwoSlabsCompoundParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Springs Two Slabs Compound — auto-generated."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

g = {p["g"]}
m_1 = {p["m_1"]}
m_2 = {p["m_2"]}
K_top = {p["K_top"]}
K_mid = {p["K_mid"]}
L_top = {p["L_top"]}
L_mid = {p["L_mid"]}
gamma_1 = {p["gamma_1"]}
gamma_2 = {p["gamma_2"]}
y_ceil = {p["y_ceil"]}
slab_w_1 = {p["slab_w_1"]}
slab_h_1 = {p["slab_h_1"]}
slab_w_2 = {p["slab_w_2"]}
slab_h_2 = {p["slab_h_2"]}
y1_0 = {p["y1_0"]}
y2_0 = {p["y2_0"]}
v1_0 = {p["v1_0"]}
v2_0 = {p["v2_0"]}
duration = {duration}
fps = 30
N_top, N_mid = 3, 2

def ode(t, y):
    y1, y2, v1, v2 = y
    F_top = K_top * (y_ceil - y1 - L_top)
    F_mid = K_mid * (y1 - y2 - L_mid)
    a1 = (F_top - F_mid - gamma_1*v1 - m_1*g)/m_1
    a2 = (F_mid - gamma_2*v2 - m_2*g)/m_2
    return [v1, v2, a1, a2]

t_eval = np.linspace(0, duration, int(duration*fps)+1)
sol = solve_ivp(ode, (0, duration), [y1_0, y2_0, v1_0, v2_0],
                t_eval=t_eval, method="RK45", rtol=1e-9, atol=1e-11)
y1a, y2a = sol.y[0], sol.y[1]

xpad = 0.20
half_w = max(slab_w_1, slab_w_2)/2.0
xlim_lo, xlim_hi = -half_w-xpad, half_w+xpad
ylim_lo, ylim_hi = -0.10, y_ceil+0.10

fig, ax = plt.subplots(figsize=(6,6), facecolor="#1a1a2e")
fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
ax.set_facecolor("#16213e")
ax.set_xlim(xlim_lo, xlim_hi); ax.set_ylim(ylim_lo, ylim_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.plot([xlim_lo, xlim_hi], [y_ceil, y_ceil], color="#adb5bd", lw=2.5, zorder=2)
ax.add_patch(patches.Rectangle((xlim_lo, y_ceil), xlim_hi-xlim_lo, 0.06,
    facecolor="#4a4e69", edgecolor="#adb5bd", lw=1, hatch="////", zorder=2))

def even_x(n, width, centre=0.0):
    if n == 1: return np.array([centre])
    inset = min(0.06, width*0.12)
    return np.linspace(centre - width/2.0 + inset, centre + width/2.0 - inset, n)

top_xs = even_x(N_top, slab_w_1, 0.0)
mid_xs = even_x(N_mid, slab_w_2, 0.0)

def vertical_spring_path(x, y_top, y_bot, n=8, r=0.04):
    ts = np.linspace(0, 1, n*20+2)
    margin = 0.08
    env = np.where((ts<margin)|(ts>1-margin), 0,
                   np.sin(n*2*np.pi*(ts-margin)/(1-2*margin)))
    ys = y_top + ts*(y_bot-y_top)
    xs = x + r*env
    return xs, ys

top_lines = [ax.plot([], [], "-", color="#a8dadc", lw=2.0, zorder=3)[0] for _ in range(N_top)]
mid_lines = [ax.plot([], [], "-", color="#a8dadc", lw=2.0, zorder=3)[0] for _ in range(N_mid)]
slab1 = patches.Rectangle((-slab_w_1/2, y1_0-slab_h_1/2), slab_w_1, slab_h_1,
    facecolor="#8ecae6", edgecolor="white", lw=1.5, zorder=4)
slab2 = patches.Rectangle((-slab_w_2/2, y2_0-slab_h_2/2), slab_w_2, slab_h_2,
    facecolor="#ffd166", edgecolor="white", lw=1.5, zorder=4)
ax.add_patch(slab1); ax.add_patch(slab2)

def update(f):
    y1, y2 = y1a[f], y2a[f]
    slab1.set_y(y1 - slab_h_1/2); slab2.set_y(y2 - slab_h_2/2)
    upper_top = y1 + slab_h_1/2
    upper_bot = y1 - slab_h_1/2
    lower_top = y2 + slab_h_2/2
    for i, ln in enumerate(top_lines):
        xs, ys = vertical_spring_path(top_xs[i], y_ceil, upper_top)
        ln.set_data(xs, ys)
    for i, ln in enumerate(mid_lines):
        xs, ys = vertical_spring_path(mid_xs[i], upper_bot, lower_top)
        ln.set_data(xs, ys)
    return top_lines + mid_lines + [slab1, slab2]

ani = animation.FuncAnimation(fig, update, frames=len(sol.t), interval=1000/fps, blit=False)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Springs Two Slabs Compound")
    parser.add_argument("--g", type=float, default=9.8)
    parser.add_argument("--m_1", type=float, default=1.0)
    parser.add_argument("--m_2", type=float, default=0.5)
    parser.add_argument("--K_top", type=float, default=120.0)
    parser.add_argument("--K_mid", type=float, default=50.0)
    parser.add_argument("--L_top", type=float, default=0.40)
    parser.add_argument("--L_mid", type=float, default=0.30)
    parser.add_argument("--gamma_1", type=float, default=0.20)
    parser.add_argument("--gamma_2", type=float, default=0.15)
    parser.add_argument("--y_ceil", type=float, default=1.40)
    parser.add_argument("--slab_w_1", type=float, default=0.80)
    parser.add_argument("--slab_h_1", type=float, default=0.06)
    parser.add_argument("--slab_w_2", type=float, default=0.50)
    parser.add_argument("--slab_h_2", type=float, default=0.06)
    parser.add_argument("--y1_0", type=float, default=1.00)
    parser.add_argument("--y2_0", type=float, default=0.70)
    parser.add_argument("--v1_0", type=float, default=0.0)
    parser.add_argument("--v2_0", type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="springs_two_slabs_compound.mp4")
    args = parser.parse_args()
    p = SpringsTwoSlabsCompoundParams(
        g=args.g, m_1=args.m_1, m_2=args.m_2, K_top=args.K_top, K_mid=args.K_mid,
        L_top=args.L_top, L_mid=args.L_mid,
        gamma_1=args.gamma_1, gamma_2=args.gamma_2, y_ceil=args.y_ceil,
        slab_w_1=args.slab_w_1, slab_h_1=args.slab_h_1,
        slab_w_2=args.slab_w_2, slab_h_2=args.slab_h_2,
        y1_0=args.y1_0, y2_0=args.y2_0, v1_0=args.v1_0, v2_0=args.v2_0,
    )
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
