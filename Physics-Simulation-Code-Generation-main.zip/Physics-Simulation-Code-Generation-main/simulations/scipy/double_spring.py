"""
Double Spring (Three-Spring Two-Block) Simulation
==================================================
Faithfully translated from myphysicslab/src/sims/springs/DoubleSpringSim.ts

Physical Layout:
    [wall1] ~spring1~ [block1] ~spring2~ [block2] ~spring3~ [wall2]

Physical Law: Newton's Second Law for each block
    m₁ ẍ₁ = F_spring1_on_block1 + F_spring2_on_block1 - b ẋ₁
    m₂ ẍ₂ = F_spring2_on_block2 + F_spring3_on_block2 - b ẋ₂

Spring stretch conventions (left_pos is left attachment, right_pos is right attachment):
    stretch  = (right_pos - left_pos) - rest_length

Force on right body of spring (positive stretch = stretched = pulls right body LEFT):
    F_right = -k · stretch

Force on left body of spring (same spring, Newton's 3rd law):
    F_left = +k · stretch

Full ODE (for blocks in normal order, matching TypeScript S1=S2=S3=+1 case):
    ẋ₁ = v₁
    ẋ₂ = v₂
    v̇₁ = [ -k₁(x₁ - wall₁ - R) + k₂(x₂ - x₁ - R) - b·v₁ ] / m₁
    v̇₂ = [ -k₂(x₂ - x₁ - R) + k₃(wall₂ - x₂ - R) - b·v₂ ] / m₂

where R = rest_length, x₁, x₂ are absolute block positions.
Equilibrium: x₁_eq = wall₁ + R,  x₂_eq = wall₁ + 2R,  wall₂ = wall₁ + 3R

State vector: [x1, x2, v1, v2]
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict, field
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis, spring_path


@dataclass
class DoubleSpringParams:
    k: float = 6.0      # stiffness of all three springs (N/m)  [TS default]
    m1: float = 1.0     # mass of block 1 (kg)
    m2: float = 1.0     # mass of block 2 (kg)
    b: float = 0.0      # damping coefficient (kg/s) [TS default = 0]
    R: float = 2.0      # rest length of each spring (m)
    # Wall positions: wall1 at 0, wall2 at 3R = 6.0
    # Initial conditions (displacements from equilibrium)
    du1: float = 0.0    # block 1 displacement from x1_eq (m)
    dv1: float = 0.0    # block 1 initial velocity (m/s)
    du2: float = 0.5    # block 2 displacement from x2_eq (m)  [TS default v2=-2.3, closer to impulse]
    dv2: float = -2.3   # block 2 initial velocity (m/s) [TS default]


def equilibrium(p: DoubleSpringParams):
    """Equilibrium positions of both blocks."""
    wall1 = 0.0
    x1_eq = wall1 + p.R
    x2_eq = wall1 + 2 * p.R
    wall2 = wall1 + 3 * p.R
    return wall1, x1_eq, x2_eq, wall2


def ode(t: float, y: list, p: DoubleSpringParams):
    """
    Exact translation of DoubleSpringSim.ts evaluate() (normal S1=S2=S3=+1 case).
        change[V1] = (-k1*stretch1 + k2*stretch2 - b*v1) / m1
        change[V2] = (-k2*stretch2 + k3*stretch3 - b*v2) / m2
    """
    x1, x2, v1, v2 = y
    wall1, _, _, wall2 = equilibrium(p)
    R = p.R

    stretch1 = (x1 - wall1) - R          # spring 1: wall1 → block1
    stretch2 = (x2 - x1) - R             # spring 2: block1 → block2
    stretch3 = (wall2 - x2) - R          # spring 3: block2 → wall2  (NB: wall2-x2)

    dv1 = (-p.k * stretch1 + p.k * stretch2 - p.b * v1) / p.m1
    dv2 = (-p.k * stretch2 + p.k * stretch3 - p.b * v2) / p.m2

    return [v1, v2, dv1, dv2]


def simulate(
    params: DoubleSpringParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Integrate using RK45. Returns (t, y) with y.shape = (4, N)."""
    _, x1_eq, x2_eq, _ = equilibrium(params)
    x1_0 = x1_eq + params.du1
    x2_0 = x2_eq + params.du2

    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode,
        (0, duration),
        [x1_0, x2_0, params.dv1, params.dv2],
        t_eval=t_eval,
        args=(params,),
        method="RK45",
        rtol=1e-9,
        atol=1e-11,
    )
    return sol.t, sol.y


def energy(t: np.ndarray, y: np.ndarray, p: DoubleSpringParams):
    x1, x2, v1, v2 = y
    wall1, _, _, wall2 = equilibrium(p)
    s1 = (x1 - wall1) - p.R
    s2 = (x2 - x1) - p.R
    s3 = (wall2 - x2) - p.R
    KE = 0.5 * p.m1 * v1**2 + 0.5 * p.m2 * v2**2
    PE = 0.5 * p.k * (s1**2 + s2**2 + s3**2)
    return KE, PE, KE + PE


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: DoubleSpringParams,
    output_path: str,
    fps: int = 30,
) -> None:
    """Render: [wall1] ~~~~ [block1] ~~~~ [block2] ~~~~ [wall2]"""
    x1_arr, x2_arr = y[0], y[1]
    wall1, x1_eq, x2_eq, wall2 = equilibrium(params)

    pad = 0.4
    xlim = (wall1 - pad, wall2 + pad)
    block_h = 0.35

    fig, ax = plt.subplots(figsize=(9, 3))
    setup_dark_axis(fig, ax, xlim, (-1.0, 1.0))

    # Static: track and walls
    track_y = 0.0
    ax.axhline(track_y - block_h / 2, color="#4a4e69", lw=1.5, zorder=1)

    for wx in [wall1, wall2]:
        sign = -1 if wx == wall1 else 1
        ax.add_patch(
            patches.Rectangle(
                (wx + sign * 0.02 - (0.15 if sign > 0 else 0),
                 track_y - 0.6), 0.15, 1.2,
                facecolor="#4a4e69", edgecolor="#adb5bd", lw=1, hatch="////",
            )
        )

    # Equilibrium markers
    for xeq in [x1_eq, x2_eq]:
        ax.axvline(xeq, color="#4a4e69", lw=0.8, ls="--", alpha=0.4, zorder=1)

    # Animated springs and blocks
    (sp1,) = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
    (sp2,) = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
    (sp3,) = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
    bw = 0.3
    b1 = patches.FancyBboxPatch(
        (x1_eq - bw / 2, track_y - block_h / 2), bw, block_h,
        boxstyle="round,pad=0.02", lw=1.5, edgecolor="white", facecolor="#e63946",
    )
    b2 = patches.FancyBboxPatch(
        (x2_eq - bw / 2, track_y - block_h / 2), bw, block_h,
        boxstyle="round,pad=0.02", lw=1.5, edgecolor="white", facecolor="#f4d35e",
    )
    ax.add_patch(b1)
    ax.add_patch(b2)

    def init():
        sp1.set_data([], [])
        sp2.set_data([], [])
        sp3.set_data([], [])
        return sp1, sp2, sp3

    def update(frame):
        bx1, bx2 = x1_arr[frame], x2_arr[frame]
        b1.set_x(bx1 - bw / 2)
        b2.set_x(bx2 - bw / 2)

        sx, sy = spring_path(wall1, track_y, bx1 - bw / 2, track_y, n_coils=6, coil_radius=0.18)
        sp1.set_data(sx, sy)
        sx, sy = spring_path(bx1 + bw / 2, track_y, bx2 - bw / 2, track_y, n_coils=6, coil_radius=0.18)
        sp2.set_data(sx, sy)
        sx, sy = spring_path(bx2 + bw / 2, track_y, wall2, track_y, n_coils=6, coil_radius=0.18)
        sp3.set_data(sx, sy)
        return sp1, sp2, sp3

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), init_func=init, interval=1000 / fps, blit=False
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: DoubleSpringParams, duration: float = 12.0) -> str:
    p = asdict(params)
    _, x1_eq, x2_eq, wall2 = equilibrium(params)
    return f'''"""
Double Spring System — auto-generated simulation script.
Physics (Newton's 2nd Law for each block):
  v̇₁ = [-k(x₁-wall₁-R) + k(x₂-x₁-R) - b·v₁] / m₁
  v̇₂ = [-k(x₂-x₁-R) + k(wall₂-x₂-R) - b·v₂] / m₂
Layout: [wall1=0] ~k~ [block1] ~k~ [block2] ~k~ [wall2={wall2:.2f}]
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

k, m1, m2, b = {p["k"]}, {p["m1"]}, {p["m2"]}, {p["b"]}
R             = {p["R"]}    # rest length of each spring (m)
wall1, wall2  = 0.0, {wall2:.4f}
x1_0  = {x1_eq:.4f} + {p["du1"]}   # block 1 initial position (m)
x2_0  = {x2_eq:.4f} + {p["du2"]}   # block 2 initial position (m)
v1_0, v2_0 = {p["dv1"]:.4f}, {p["dv2"]:.4f}
duration = {duration}

def ode(t, y):
    x1, x2, v1, v2 = y
    s1 = (x1-wall1)-R; s2 = (x2-x1)-R; s3 = (wall2-x2)-R
    dv1 = (-k*s1 + k*s2 - b*v1)/m1
    dv2 = (-k*s2 + k*s3 - b*v2)/m2
    return [v1, v2, dv1, dv2]

fps=30; t_eval=np.linspace(0,duration,int(duration*fps)+1)
sol=solve_ivp(ode,(0,duration),[x1_0,x2_0,v1_0,v2_0],t_eval=t_eval,method="RK45",rtol=1e-9,atol=1e-11)
x1a,x2a=sol.y[0],sol.y[1]

bw,bh,ty=0.3,0.35,0.0
fig,ax=plt.subplots(figsize=(9,3),facecolor="#1a1a2e")
ax.set_facecolor("#16213e"); ax.set_xlim(wall1-0.4,wall2+0.4); ax.set_ylim(-1,1)
ax.set_aspect("equal"); ax.axis("off")
ax.axhline(ty-bh/2,color="#4a4e69",lw=1.5,zorder=1)
for wx,sgn in [(wall1,1),(wall2,-1)]:
    ax.add_patch(patches.Rectangle((wx+(sgn*0.02-(0.15 if sgn<0 else 0)),ty-0.6),0.15,1.2,
        facecolor="#4a4e69",edgecolor="#adb5bd",lw=1,hatch="////"))

def sp_path(x1,x2,n=6,r=0.18):
    t=np.linspace(0,1,n*20+2)
    env=np.where((t<0.08)|(t>0.92),0,np.sin(n*2*np.pi*(t-0.08)/(1-2*0.08)))
    return x1+t*(x2-x1), ty+r*env

s1l,=ax.plot([],[],"-",color="#a8dadc",lw=2.5,zorder=3)
s2l,=ax.plot([],[],"-",color="#a8dadc",lw=2.5,zorder=3)
s3l,=ax.plot([],[],"-",color="#a8dadc",lw=2.5,zorder=3)
b1p=patches.FancyBboxPatch((x1_0-bw/2,ty-bh/2),bw,bh,boxstyle="round,pad=0.02",
    lw=1.5,edgecolor="white",facecolor="#e63946"); ax.add_patch(b1p)
b2p=patches.FancyBboxPatch((x2_0-bw/2,ty-bh/2),bw,bh,boxstyle="round,pad=0.02",
    lw=1.5,edgecolor="white",facecolor="#f4d35e"); ax.add_patch(b2p)

def update(f):
    b1,b2=x1a[f],x2a[f]
    b1p.set_x(b1-bw/2); b2p.set_x(b2-bw/2)
    s1l.set_data(*sp_path(wall1,b1-bw/2)); s2l.set_data(*sp_path(b1+bw/2,b2-bw/2))
    s3l.set_data(*sp_path(b2+bw/2,wall2)); return s1l,s2l,s3l

ani=animation.FuncAnimation(fig,update,frames=len(sol.t),interval=1000/fps,blit=False)
ani.save("double_spring.mp4",writer=animation.FFMpegWriter(fps=fps,bitrate=1800),dpi=120)
plt.close(); print("Saved double_spring.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Double Spring System")
    parser.add_argument("--k",   type=float, default=6.0)
    parser.add_argument("--m1",  type=float, default=1.0)
    parser.add_argument("--m2",  type=float, default=1.0)
    parser.add_argument("--b",   type=float, default=0.0)
    parser.add_argument("--R",   type=float, default=2.0)
    parser.add_argument("--du1", type=float, default=0.0)
    parser.add_argument("--dv1", type=float, default=0.0)
    parser.add_argument("--du2", type=float, default=0.5)
    parser.add_argument("--dv2", type=float, default=-2.3)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output",   type=str,   default="double_spring.mp4")
    args = parser.parse_args()
    p = DoubleSpringParams(
        k=args.k, m1=args.m1, m2=args.m2, b=args.b, R=args.R,
        du1=args.du1, dv1=args.dv1, du2=args.du2, dv2=args.dv2,
    )
    print(f"Simulating double spring: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
