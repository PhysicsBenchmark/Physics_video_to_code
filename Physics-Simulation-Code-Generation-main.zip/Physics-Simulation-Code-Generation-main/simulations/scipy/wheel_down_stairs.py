"""
Wheel Down Stairs - rolling wheel tips over edges, free-flies, bounces on steps.
Uses solve_ivp for pivot phases and free-flight; Routh impulse map at each contact.
Encapsulates all the heavy computation in the standalone script.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class WheelDownStairsParams:
    g: float = 9.8
    m_w: float = 1.5
    R_w: float = 0.18
    v_x_0: float = -1.20
    e_g: float = 0.40
    mu_g: float = 0.30
    mu_r: float = 0.05
    N_steps: int = 4
    w_step: float = 0.30
    h_step: float = 0.18
    x_stairs_top: float = -0.50
    X_0: float = 1.40
    x_floor_left: float = -5.00
    x_floor_right: float = 2.20


def simulate(params: WheelDownStairsParams, duration: float = 12.0, fps: int = 30):
    """Run the full pivot/flight/bounce simulation; returns (t, y) where
    y has rows (x, y, theta)."""
    # We essentially duplicate the standalone routine here to compute trajectory.
    code_locals = {}
    exec(_TRAJECTORY_CODE, {"np": np, "params": params, "duration": duration, "fps": fps,
                            "solve_ivp": _solve_ivp_lazy()}, code_locals)
    return code_locals["t_grid"], np.vstack([code_locals["xs"], code_locals["ys"], code_locals["ths"]])


def _solve_ivp_lazy():
    from scipy.integrate import solve_ivp
    return solve_ivp


_TRAJECTORY_CODE = '''
g=params.g; m_w=params.m_w; R_w=params.R_w
v_x_0=params.v_x_0; omega_0=-v_x_0/R_w
e_g=params.e_g; mu_g=params.mu_g; mu_r=params.mu_r
N_steps=int(params.N_steps); w_step=params.w_step; h_step=params.h_step
h_top=N_steps*h_step
x_stairs_top=params.x_stairs_top
X_0=params.X_0
x_floor_left=params.x_floor_left
x_floor_right=params.x_floor_right
I_com=0.5*m_w*R_w*R_w
I_edge=I_com+m_w*R_w*R_w

edges=[(x_stairs_top-k*w_step, h_top-k*h_step) for k in range(N_steps)]
horizontal_surfaces=[]
horizontal_surfaces.append(dict(y=h_top, x_left=x_stairs_top, x_right=x_floor_right, tag="upper_floor"))
for k in range(1,N_steps):
    horizontal_surfaces.append(dict(y=h_top-k*h_step,
                                    x_left=x_stairs_top-k*w_step,
                                    x_right=x_stairs_top-(k-1)*w_step,
                                    tag=f"step_{k}_top"))
horizontal_surfaces.append(dict(y=0.0,
                                x_left=x_floor_left,
                                x_right=x_stairs_top-(N_steps-1)*w_step,
                                tag="lower_floor"))

t_phase1_end=(X_0-x_stairs_top)/abs(v_x_0)
th_at_phase1_end=omega_0*t_phase1_end

def pivot_ode(t,s):
    phi,phi_dot=s
    return [phi_dot, (2.0*g/(3.0*R_w))*np.sin(phi)]

n_frames=int(duration*fps)+1
t_grid=np.linspace(0.0,duration,n_frames)
xs=np.full(n_frames,np.nan); ys=np.full(n_frames,np.nan); ths=np.full(n_frames,np.nan)
vxs=np.full(n_frames,np.nan); vys=np.full(n_frames,np.nan); oms=np.full(n_frames,np.nan)

def set_grid(ti,xc,yc,th,vx,vy,om):
    j=int(round(ti*fps))
    if 0<=j<n_frames and abs(t_grid[j]-ti)<0.5/fps+1e-9:
        if np.isnan(xs[j]):
            xs[j]=xc; ys[j]=yc; ths[j]=th
            vxs[j]=vx; vys[j]=vy; oms[j]=om

# Phase 1: rolling on upper floor.
for j,t in enumerate(t_grid):
    if t>t_phase1_end+1e-9: break
    xs[j]=X_0+v_x_0*t; ys[j]=h_top+R_w; ths[j]=omega_0*t
    vxs[j]=v_x_0; vys[j]=0.0; oms[j]=omega_0

def detach_event():
    def ev(t,s):
        phi,phi_dot=s
        return phi_dot*phi_dot - g*np.cos(phi)/R_w
    ev.terminal=True; ev.direction=+1.0
    return ev
def safety_event(phi_max):
    def ev(t,s): return s[0]-phi_max
    ev.terminal=True; ev.direction=+1.0
    return ev

xe0,ye0=edges[0]
phi_dot_0=-v_x_0/R_w
sub_grid=t_grid[(t_grid>=t_phase1_end-1e-12)&(t_grid<=t_phase1_end+5.0)]
if sub_grid.size==0 or sub_grid[0]>t_phase1_end+1e-12:
    sub_grid=np.concatenate(([t_phase1_end],sub_grid))
else:
    sub_grid=sub_grid.copy(); sub_grid[0]=t_phase1_end
sol=solve_ivp(pivot_ode,(t_phase1_end,t_phase1_end+5.0),[0.0,phi_dot_0],
              t_eval=sub_grid,events=[detach_event(),safety_event(np.pi/2-1e-3)],
              method="RK45",rtol=1e-9,atol=1e-11,max_step=0.005)
if sol.t_events[0].size>0:
    t_detach=float(sol.t_events[0][0]); phi_d,phi_dot_d=sol.y_events[0][0]
elif sol.t_events[1].size>0:
    t_detach=float(sol.t_events[1][0]); phi_d,phi_dot_d=sol.y_events[1][0]
else:
    t_detach=sol.t[-1]; phi_d,phi_dot_d=sol.y[0,-1],sol.y[1,-1]
for i,ti in enumerate(sol.t):
    if ti>t_detach+1e-9: break
    phi=sol.y[0,i]; phi_dot=sol.y[1,i]
    xc=xe0-R_w*np.sin(phi); yc=ye0+R_w*np.cos(phi)
    vx=-R_w*phi_dot*np.cos(phi); vy=-R_w*phi_dot*np.sin(phi)
    set_grid(ti,xc,yc,th_at_phase1_end+phi,vx,vy,phi_dot)
xc_d=xe0-R_w*np.sin(phi_d); yc_d=ye0+R_w*np.cos(phi_d)
vx_d=-R_w*phi_dot_d*np.cos(phi_d); vy_d=-R_w*phi_dot_d*np.sin(phi_d)
om_d=phi_dot_d
th_at_detach=th_at_phase1_end+phi_d

# Free-flight phase with surface events.
def free_ode(t,s):
    x,y,th,vx,vy,om=s
    return [vx,vy,om,0.0,-g,0.0]

def horiz_top_event(surface):
    y_surf=surface["y"]; xL=surface["x_left"]; xR=surface["x_right"]
    def ev(t,s):
        x,y,th,vx,vy,om=s
        f=(y-R_w)-y_surf
        if (x<xL-1e-9) or (x>xR+1e-9) or (y<y_surf):
            return f+10.0
        return f
    ev.terminal=True; ev.direction=-1.0
    return ev
def corner_event(corner):
    xc_,yc_=corner
    def ev(t,s):
        x,y,th,vx,vy,om=s
        dx=x-xc_; dy=y-yc_
        return dx*dx+dy*dy-R_w*R_w
    ev.terminal=True; ev.direction=-1.0
    return ev

def routh_impulse(state,n_hat,contact_point):
    x,y,th,vx,vy,om=state
    nx,ny=n_hat
    tx,ty=-ny,nx
    rx=contact_point[0]-x; ry=contact_point[1]-y
    vcx=vx-om*ry; vcy=vy+om*rx
    vc_n=vcx*nx+vcy*ny; vc_t=vcx*tx+vcy*ty
    if vc_n>=0.0:
        return list(state)
    rxn=rx*ny-ry*nx; rxt=rx*ty-ry*tx
    inv_mn=1.0/m_w + rxn*rxn/I_com
    inv_mt=1.0/m_w + rxt*rxt/I_com
    Jn=-(1.0+e_g)*vc_n/inv_mn
    Jt_stk=-vc_t/inv_mt
    cone=mu_g*abs(Jn)
    Jt = Jt_stk if abs(Jt_stk)<=cone else np.sign(Jt_stk)*cone
    Jx=Jn*nx+Jt*tx; Jy=Jn*ny+Jt*ty
    vx_p=vx+Jx/m_w; vy_p=vy+Jy/m_w
    om_p=om + (rx*Jy-ry*Jx)/I_com
    return [x,y,th,vx_p,vy_p,om_p]

events_list=[]; events_info=[]
for surface in horizontal_surfaces:
    events_list.append(horiz_top_event(surface))
    events_info.append(("horiz",surface))
for ec in edges:
    events_list.append(corner_event(ec))
    events_info.append(("corner",ec))

EPS_GUARD=1e-3
state=[xc_d,yc_d,th_at_detach,vx_d,vy_d,om_d]
t_now=t_detach
settle_state=None
b_count=0
max_bounces=200
while t_now<duration-1e-9 and b_count<max_bounces:
    sub_grid=t_grid[(t_grid>=t_now-1e-12)&(t_grid<=duration+1e-12)]
    if sub_grid.size==0 or sub_grid[0]>t_now+1e-12:
        sub_grid=np.concatenate(([t_now],sub_grid))
    else:
        sub_grid=sub_grid.copy(); sub_grid[0]=t_now
    sol=solve_ivp(free_ode,(t_now,duration),state,t_eval=sub_grid,
                  events=events_list,method="RK45",rtol=1e-9,atol=1e-11,max_step=0.005)
    t_event_first=duration+1.0; ev_idx=-1
    for k,te_arr in enumerate(sol.t_events):
        if te_arr.size>0 and te_arr[0]<t_event_first:
            t_event_first=te_arr[0]; ev_idx=k
    for i,ti in enumerate(sol.t):
        if ti>t_event_first+1e-12: break
        if ti<t_now-1e-12: continue
        x_,y_,th_,vx_,vy_,om_=sol.y[:,i]
        set_grid(ti,x_,y_,th_,vx_,vy_,om_)
    if ev_idx<0:
        x_,y_,th_,vx_,vy_,om_=sol.y[:,-1]
        state=[x_,y_,th_,vx_,vy_,om_]; t_now=sol.t[-1]; break
    t_event=float(sol.t_events[ev_idx][0])
    state_event=sol.y_events[ev_idx][0].tolist()
    kind,payload=events_info[ev_idx]
    if kind=="horiz":
        n_hat=(0.0,1.0); cp=(state_event[0],payload["y"])
    else:
        cx_,cy_=payload
        dx=state_event[0]-cx_; dy=state_event[1]-cy_
        d=np.hypot(dx,dy)
        if d<1e-12: d=R_w
        n_hat=(dx/d,dy/d); cp=(cx_,cy_)
    new_state=routh_impulse(state_event,n_hat,cp)
    is_lower=(kind=="horiz" and payload.get("tag")=="lower_floor")
    if is_lower:
        v_rebound=new_state[4]; v_min=g/fps
        if v_rebound<v_min:
            settle_state=(t_event,new_state[0],0.0+R_w,new_state[3],new_state[5],new_state[2])
            t_now=t_event; state=list(new_state); break
    new_state[0]+=EPS_GUARD*n_hat[0]
    new_state[1]+=EPS_GUARD*n_hat[1]
    state=list(new_state); t_now=t_event; b_count+=1

if settle_state is not None:
    t_settle,xc_s,yc_s,vx_s,om_s,th_s=settle_state
    s_0=vx_s+om_s*R_w
    if abs(s_0)>1e-9:
        sgn=np.sign(s_0)
        a_vx_slip=-mu_g*g*sgn; a_om_slip=-2.0*mu_g*g/R_w*sgn
        t_slip=abs(s_0)/(3.0*mu_g*g)
    else:
        a_vx_slip=0.0; a_om_slip=0.0; t_slip=0.0
    vx_after=vx_s+a_vx_slip*t_slip
    om_after=om_s+a_om_slip*t_slip
    xc_after=xc_s+vx_s*t_slip+0.5*a_vx_slip*t_slip**2
    th_after=th_s+om_s*t_slip+0.5*a_om_slip*t_slip**2
    t_after=t_settle+t_slip
    a_vx_4=-mu_r*g*np.sign(vx_after) if abs(vx_after)>1e-9 else 0.0
    a_om_4=-a_vx_4/R_w
    t_stop_dur=abs(vx_after/a_vx_4) if abs(a_vx_4)>1e-12 else duration
    t_stop=t_after+t_stop_dur
    x_stop=xc_after+vx_after*t_stop_dur+0.5*a_vx_4*t_stop_dur**2
    th_stop=th_after+om_after*t_stop_dur+0.5*a_om_4*t_stop_dur**2
    for j,t in enumerate(t_grid):
        if t<t_settle-1e-9: continue
        if not np.isnan(xs[j]): continue
        if t<=t_after:
            dt=t-t_settle
            xs[j]=xc_s+vx_s*dt+0.5*a_vx_slip*dt*dt
            ys[j]=R_w
            ths[j]=th_s+om_s*dt+0.5*a_om_slip*dt*dt
            vxs[j]=vx_s+a_vx_slip*dt; vys[j]=0.0; oms[j]=om_s+a_om_slip*dt
        elif t<=t_stop:
            dt=t-t_after
            xs[j]=xc_after+vx_after*dt+0.5*a_vx_4*dt*dt
            ys[j]=R_w
            ths[j]=th_after+om_after*dt+0.5*a_om_4*dt*dt
            vxs[j]=vx_after+a_vx_4*dt; vys[j]=0.0; oms[j]=om_after+a_om_4*dt
        else:
            xs[j]=x_stop; ys[j]=R_w; ths[j]=th_stop
            vxs[j]=0.0; vys[j]=0.0; oms[j]=0.0

last=None
for j in range(n_frames):
    if np.isnan(xs[j]):
        if last is None:
            xs[j]=X_0; ys[j]=h_top+R_w
            ths[j]=0.0; vxs[j]=v_x_0; vys[j]=0.0; oms[j]=omega_0
        else:
            xs[j]=last[0]; ys[j]=last[1]; ths[j]=last[2]
            vxs[j]=last[3]; vys[j]=last[4]; oms[j]=last[5]
    last=(xs[j],ys[j],ths[j],vxs[j],vys[j],oms[j])
'''


def render_video(t, y, params: WheelDownStairsParams, output_path: str, fps: int = 30):
    p = params
    xs, ys, ths = y[0], y[1], y[2]
    h_top = int(p.N_steps) * p.h_step
    fig_w, fig_h = 9.0, 5.0
    fig_aspect = fig_w / fig_h
    x_lo_d = p.x_floor_left - 0.30
    x_hi_d = p.x_floor_right + 0.30
    y_lo_d = -0.30
    y_hi_d = h_top + 2 * p.R_w + 0.30
    dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_d / dy_d < fig_aspect:
        extra = (fig_aspect * dy_d - dx_d) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx_d / fig_aspect - dy_d) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    from matplotlib.patches import Polygon, Circle
    from matplotlib.collections import LineCollection

    # Build staircase polygon
    pts = []
    y_below = -0.40
    pts.append((p.x_floor_left, y_below))
    pts.append((p.x_floor_left, 0.0))
    pts.append((p.x_stairs_top - (int(p.N_steps) - 1) * p.w_step, 0.0))
    for k in reversed(range(int(p.N_steps))):
        pts.append((p.x_stairs_top - k * p.w_step, h_top - k * p.h_step))
        x_right = p.x_floor_right if k == 0 else p.x_stairs_top - (k - 1) * p.w_step
        pts.append((x_right, h_top - k * p.h_step))
    pts.append((p.x_floor_right, y_below))

    ax.add_patch(Polygon(pts, closed=True, facecolor="#4a4e69", edgecolor="none", zorder=0))
    sp = pts[1:-1]
    ax.plot([q[0] for q in sp], [q[1] for q in sp], color="#adb5bd", lw=2.0, zorder=1)

    wheel = Circle((xs[0], ys[0]), p.R_w,
                   facecolor="#80c0ff", edgecolor="#ffffff", lw=1.6, zorder=5)
    ax.add_patch(wheel)
    spokes_lc = LineCollection([], colors="#1a1a2e", linewidths=2.6, zorder=5.5)
    ax.add_collection(spokes_lc)
    hi_spoke, = ax.plot([], [], color="#e63946", lw=3.0, zorder=5.6)
    axle_dot = Circle((xs[0], ys[0]), 0.018, facecolor="#1a1a2e",
                      edgecolor="#ffffff", lw=0.8, zorder=6)
    ax.add_patch(axle_dot)

    N_SPOKES = 6

    def spoke_segments(cx, cy, phi, n=N_SPOKES, inner_frac=0.10, outer_frac=0.96):
        angles = phi + 2.0 * np.pi * np.arange(n) / n
        r0 = inner_frac * p.R_w; r1 = outer_frac * p.R_w
        segs = np.empty((n, 2, 2))
        segs[:, 0, 0] = cx + r0 * np.cos(angles); segs[:, 0, 1] = cy + r0 * np.sin(angles)
        segs[:, 1, 0] = cx + r1 * np.cos(angles); segs[:, 1, 1] = cy + r1 * np.sin(angles)
        return segs

    def update(f):
        cx, cy, th = xs[f], ys[f], ths[f]
        wheel.set_center((cx, cy))
        axle_dot.center = (cx, cy)
        spokes_lc.set_segments(spoke_segments(cx, cy, th))
        hi_spoke.set_data([cx + 0.10 * p.R_w * np.cos(th), cx + 0.96 * p.R_w * np.cos(th)],
                          [cy + 0.10 * p.R_w * np.sin(th), cy + 0.96 * p.R_w * np.sin(th)])
        return wheel, axle_dot, spokes_lc, hi_spoke

    ani = animation.FuncAnimation(fig, update, frames=len(t), interval=1000.0 / fps, blit=False)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: WheelDownStairsParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Wheel down stairs - auto-generated."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Circle, Polygon
from matplotlib.collections import LineCollection

g={p["g"]}; m_w={p["m_w"]}; R_w={p["R_w"]}; I_com=0.5*m_w*R_w*R_w
v_x_0={p["v_x_0"]}; omega_0=-v_x_0/R_w
e_g={p["e_g"]}; mu_g={p["mu_g"]}; mu_r={p["mu_r"]}
N_steps={int(p["N_steps"])}; w_step={p["w_step"]}; h_step={p["h_step"]}
h_top=N_steps*h_step
x_stairs_top={p["x_stairs_top"]}; X_0={p["X_0"]}
x_floor_left={p["x_floor_left"]}; x_floor_right={p["x_floor_right"]}
duration={duration}; fps=30
I_edge=I_com+m_w*R_w*R_w

edges=[(x_stairs_top-k*w_step,h_top-k*h_step) for k in range(N_steps)]
horizontal_surfaces=[]
horizontal_surfaces.append(dict(y=h_top,x_left=x_stairs_top,x_right=x_floor_right,tag="upper_floor"))
for k in range(1,N_steps):
    horizontal_surfaces.append(dict(y=h_top-k*h_step,
                                    x_left=x_stairs_top-k*w_step,
                                    x_right=x_stairs_top-(k-1)*w_step,
                                    tag=f"step_{{k}}_top"))
horizontal_surfaces.append(dict(y=0.0,
                                x_left=x_floor_left,
                                x_right=x_stairs_top-(N_steps-1)*w_step,
                                tag="lower_floor"))

def build_surface_polygon():
    pts=[]; y_below=-0.40
    pts.append((x_floor_left,y_below))
    pts.append((x_floor_left,0.0))
    pts.append((x_stairs_top-(N_steps-1)*w_step,0.0))
    for k in reversed(range(N_steps)):
        pts.append((x_stairs_top-k*w_step,h_top-k*h_step))
        x_right_of_step=x_floor_right if k==0 else x_stairs_top-(k-1)*w_step
        pts.append((x_right_of_step,h_top-k*h_step))
    pts.append((x_floor_right,y_below))
    return pts

t_phase1_end=(X_0-x_stairs_top)/abs(v_x_0)
th_at_phase1_end=omega_0*t_phase1_end

def pivot_ode(t,s):
    phi,phi_dot=s
    return [phi_dot, (2.0*g/(3.0*R_w))*np.sin(phi)]

n_frames=int(duration*fps)+1
t_grid=np.linspace(0.0,duration,n_frames)
xs=np.full(n_frames,np.nan); ys=np.full(n_frames,np.nan); ths=np.full(n_frames,np.nan)
vxs=np.full(n_frames,np.nan); vys=np.full(n_frames,np.nan); oms=np.full(n_frames,np.nan)
def set_grid(ti,xc,yc,th,vx,vy,om):
    j=int(round(ti*fps))
    if 0<=j<n_frames and abs(t_grid[j]-ti)<0.5/fps+1e-9:
        if np.isnan(xs[j]):
            xs[j]=xc; ys[j]=yc; ths[j]=th
            vxs[j]=vx; vys[j]=vy; oms[j]=om

for j,t in enumerate(t_grid):
    if t>t_phase1_end+1e-9: break
    xs[j]=X_0+v_x_0*t; ys[j]=h_top+R_w; ths[j]=omega_0*t
    vxs[j]=v_x_0; vys[j]=0.0; oms[j]=omega_0

def detach_ev():
    def ev(t,s):
        phi,phi_dot=s
        return phi_dot*phi_dot - g*np.cos(phi)/R_w
    ev.terminal=True; ev.direction=+1.0; return ev
def safety_ev(phi_max):
    def ev(t,s): return s[0]-phi_max
    ev.terminal=True; ev.direction=+1.0; return ev

xe0,ye0=edges[0]
phi_dot_0=-v_x_0/R_w
sub_grid=t_grid[(t_grid>=t_phase1_end-1e-12)&(t_grid<=t_phase1_end+5.0)]
if sub_grid.size==0 or sub_grid[0]>t_phase1_end+1e-12:
    sub_grid=np.concatenate(([t_phase1_end],sub_grid))
else:
    sub_grid=sub_grid.copy(); sub_grid[0]=t_phase1_end
sol=solve_ivp(pivot_ode,(t_phase1_end,t_phase1_end+5.0),[0.0,phi_dot_0],
              t_eval=sub_grid,events=[detach_ev(),safety_ev(np.pi/2-1e-3)],
              method="RK45",rtol=1e-9,atol=1e-11,max_step=0.005)
if sol.t_events[0].size>0:
    t_detach=float(sol.t_events[0][0]); phi_d,phi_dot_d=sol.y_events[0][0]
elif sol.t_events[1].size>0:
    t_detach=float(sol.t_events[1][0]); phi_d,phi_dot_d=sol.y_events[1][0]
else:
    t_detach=sol.t[-1]; phi_d,phi_dot_d=sol.y[0,-1],sol.y[1,-1]
for i,ti in enumerate(sol.t):
    if ti>t_detach+1e-9: break
    phi=sol.y[0,i]; phi_dot=sol.y[1,i]
    xc=xe0-R_w*np.sin(phi); yc=ye0+R_w*np.cos(phi)
    vx=-R_w*phi_dot*np.cos(phi); vy=-R_w*phi_dot*np.sin(phi)
    set_grid(ti,xc,yc,th_at_phase1_end+phi,vx,vy,phi_dot)
xc_d=xe0-R_w*np.sin(phi_d); yc_d=ye0+R_w*np.cos(phi_d)
vx_d=-R_w*phi_dot_d*np.cos(phi_d); vy_d=-R_w*phi_dot_d*np.sin(phi_d)
om_d=phi_dot_d
th_at_detach=th_at_phase1_end+phi_d

def free_ode(t,s):
    x,y,th,vx,vy,om=s
    return [vx,vy,om,0.0,-g,0.0]

def horiz_top_event(surface):
    y_surf=surface["y"]; xL=surface["x_left"]; xR=surface["x_right"]
    def ev(t,s):
        x,y,th,vx,vy,om=s
        f=(y-R_w)-y_surf
        if (x<xL-1e-9) or (x>xR+1e-9) or (y<y_surf):
            return f+10.0
        return f
    ev.terminal=True; ev.direction=-1.0; return ev
def corner_ev(corner):
    xc_,yc_=corner
    def ev(t,s):
        x,y,th,vx,vy,om=s
        dx=x-xc_; dy=y-yc_
        return dx*dx+dy*dy-R_w*R_w
    ev.terminal=True; ev.direction=-1.0; return ev

def routh_impulse(state,n_hat,cp):
    x,y,th,vx,vy,om=state
    nx,ny=n_hat
    tx,ty=-ny,nx
    rx=cp[0]-x; ry=cp[1]-y
    vcx=vx-om*ry; vcy=vy+om*rx
    vc_n=vcx*nx+vcy*ny; vc_t=vcx*tx+vcy*ty
    if vc_n>=0.0: return list(state)
    rxn=rx*ny-ry*nx; rxt=rx*ty-ry*tx
    inv_mn=1.0/m_w + rxn*rxn/I_com
    inv_mt=1.0/m_w + rxt*rxt/I_com
    Jn=-(1.0+e_g)*vc_n/inv_mn
    Jt_stk=-vc_t/inv_mt
    cone=mu_g*abs(Jn)
    Jt = Jt_stk if abs(Jt_stk)<=cone else np.sign(Jt_stk)*cone
    Jx=Jn*nx+Jt*tx; Jy=Jn*ny+Jt*ty
    return [x,y,th,vx+Jx/m_w,vy+Jy/m_w,om+(rx*Jy-ry*Jx)/I_com]

events_list=[]; events_info=[]
for s_ in horizontal_surfaces:
    events_list.append(horiz_top_event(s_)); events_info.append(("horiz",s_))
for ec in edges:
    events_list.append(corner_ev(ec)); events_info.append(("corner",ec))

EPS_GUARD=1e-3
state=[xc_d,yc_d,th_at_detach,vx_d,vy_d,om_d]
t_now=t_detach
settle_state=None
for b in range(200):
    if t_now>=duration-1e-9: break
    sub_grid=t_grid[(t_grid>=t_now-1e-12)&(t_grid<=duration+1e-12)]
    if sub_grid.size==0 or sub_grid[0]>t_now+1e-12:
        sub_grid=np.concatenate(([t_now],sub_grid))
    else:
        sub_grid=sub_grid.copy(); sub_grid[0]=t_now
    sol=solve_ivp(free_ode,(t_now,duration),state,t_eval=sub_grid,
                  events=events_list,method="RK45",rtol=1e-9,atol=1e-11,max_step=0.005)
    t_first=duration+1.0; ev_idx=-1
    for k,te_arr in enumerate(sol.t_events):
        if te_arr.size>0 and te_arr[0]<t_first:
            t_first=te_arr[0]; ev_idx=k
    for i,ti in enumerate(sol.t):
        if ti>t_first+1e-12: break
        if ti<t_now-1e-12: continue
        x_,y_,th_,vx_,vy_,om_=sol.y[:,i]
        set_grid(ti,x_,y_,th_,vx_,vy_,om_)
    if ev_idx<0:
        x_,y_,th_,vx_,vy_,om_=sol.y[:,-1]
        state=[x_,y_,th_,vx_,vy_,om_]; t_now=sol.t[-1]; break
    t_event=float(sol.t_events[ev_idx][0])
    state_event=sol.y_events[ev_idx][0].tolist()
    kind,payload=events_info[ev_idx]
    if kind=="horiz":
        n_hat=(0.0,1.0); cp=(state_event[0],payload["y"])
    else:
        cx_,cy_=payload
        dx=state_event[0]-cx_; dy=state_event[1]-cy_
        d=np.hypot(dx,dy)
        if d<1e-12: d=R_w
        n_hat=(dx/d,dy/d); cp=(cx_,cy_)
    new_state=routh_impulse(state_event,n_hat,cp)
    is_lower=(kind=="horiz" and payload.get("tag")=="lower_floor")
    if is_lower:
        v_rebound=new_state[4]; v_min=g/fps
        if v_rebound<v_min:
            settle_state=(t_event,new_state[0],0.0+R_w,new_state[3],new_state[5],new_state[2])
            t_now=t_event; state=list(new_state); break
    new_state[0]+=EPS_GUARD*n_hat[0]
    new_state[1]+=EPS_GUARD*n_hat[1]
    state=list(new_state); t_now=t_event

if settle_state is not None:
    t_settle,xc_s,yc_s,vx_s,om_s,th_s=settle_state
    s_0=vx_s+om_s*R_w
    if abs(s_0)>1e-9:
        sgn=np.sign(s_0)
        a_vx_slip=-mu_g*g*sgn; a_om_slip=-2.0*mu_g*g/R_w*sgn
        t_slip=abs(s_0)/(3.0*mu_g*g)
    else:
        a_vx_slip=0.0; a_om_slip=0.0; t_slip=0.0
    vx_after=vx_s+a_vx_slip*t_slip
    om_after=om_s+a_om_slip*t_slip
    xc_after=xc_s+vx_s*t_slip+0.5*a_vx_slip*t_slip**2
    th_after=th_s+om_s*t_slip+0.5*a_om_slip*t_slip**2
    t_after=t_settle+t_slip
    a_vx_4=-mu_r*g*np.sign(vx_after) if abs(vx_after)>1e-9 else 0.0
    a_om_4=-a_vx_4/R_w
    t_stop_dur=abs(vx_after/a_vx_4) if abs(a_vx_4)>1e-12 else duration
    t_stop=t_after+t_stop_dur
    x_stop=xc_after+vx_after*t_stop_dur+0.5*a_vx_4*t_stop_dur**2
    th_stop=th_after+om_after*t_stop_dur+0.5*a_om_4*t_stop_dur**2
    for j,t in enumerate(t_grid):
        if t<t_settle-1e-9: continue
        if not np.isnan(xs[j]): continue
        if t<=t_after:
            dt=t-t_settle
            xs[j]=xc_s+vx_s*dt+0.5*a_vx_slip*dt*dt; ys[j]=R_w
            ths[j]=th_s+om_s*dt+0.5*a_om_slip*dt*dt
        elif t<=t_stop:
            dt=t-t_after
            xs[j]=xc_after+vx_after*dt+0.5*a_vx_4*dt*dt; ys[j]=R_w
            ths[j]=th_after+om_after*dt+0.5*a_om_4*dt*dt
        else:
            xs[j]=x_stop; ys[j]=R_w; ths[j]=th_stop

last=None
for j in range(n_frames):
    if np.isnan(xs[j]):
        if last is None:
            xs[j]=X_0; ys[j]=h_top+R_w; ths[j]=0.0
        else:
            xs[j]=last[0]; ys[j]=last[1]; ths[j]=last[2]
    last=(xs[j],ys[j],ths[j])

fig_w,fig_h=9.0,5.0; fa=fig_w/fig_h
x_lo_d=x_floor_left-0.30; x_hi_d=x_floor_right+0.30
y_lo_d=-0.30; y_hi_d=h_top+2*R_w+0.30
dx_d,dy_d=x_hi_d-x_lo_d,y_hi_d-y_lo_d
if dx_d/dy_d<fa:
    e=(fa*dy_d-dx_d)/2.0; x_lo,x_hi=x_lo_d-e,x_hi_d+e; y_lo,y_hi=y_lo_d,y_hi_d
else:
    e=(dx_d/fa-dy_d)/2.0; x_lo,x_hi=x_lo_d,x_hi_d; y_lo,y_hi=y_lo_d-e,y_hi_d+e

fig=plt.figure(figsize=(fig_w,fig_h),facecolor="#1a1a2e")
ax=fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi); ax.set_aspect("equal"); ax.axis("off")
poly_pts=build_surface_polygon()
ax.add_patch(Polygon(poly_pts,closed=True,facecolor="#4a4e69",edgecolor="none",zorder=0))
sp=poly_pts[1:-1]
ax.plot([q[0] for q in sp],[q[1] for q in sp],color="#adb5bd",lw=2.0,zorder=1)
N_SPOKES=6
wheel_patch=Circle((xs[0],ys[0]),R_w,facecolor="#80c0ff",edgecolor="#ffffff",lw=1.6,zorder=5)
ax.add_patch(wheel_patch)
spokes_lc=LineCollection([],colors="#1a1a2e",linewidths=2.6,zorder=5.5)
ax.add_collection(spokes_lc)
hi_spoke,=ax.plot([],[],color="#e63946",lw=3.0,zorder=5.6)
axle_dot=Circle((xs[0],ys[0]),0.018,facecolor="#1a1a2e",edgecolor="#ffffff",lw=0.8,zorder=6)
ax.add_patch(axle_dot)

def spoke_segments(cx,cy,phi,n=N_SPOKES,inner_frac=0.10,outer_frac=0.96):
    angles=phi+2.0*np.pi*np.arange(n)/n
    r0=inner_frac*R_w; r1=outer_frac*R_w
    segs=np.empty((n,2,2))
    segs[:,0,0]=cx+r0*np.cos(angles); segs[:,0,1]=cy+r0*np.sin(angles)
    segs[:,1,0]=cx+r1*np.cos(angles); segs[:,1,1]=cy+r1*np.sin(angles)
    return segs

def update(f):
    cx,cy,th=xs[f],ys[f],ths[f]
    wheel_patch.set_center((cx,cy))
    axle_dot.center=(cx,cy)
    spokes_lc.set_segments(spoke_segments(cx,cy,th))
    hi_spoke.set_data([cx+0.10*R_w*np.cos(th),cx+0.96*R_w*np.cos(th)],
                      [cy+0.10*R_w*np.sin(th),cy+0.96*R_w*np.sin(th)])
    return wheel_patch,axle_dot,spokes_lc,hi_spoke

ani=animation.FuncAnimation(fig,update,frames=n_frames,interval=1000.0/fps,blit=False)
ani.save("video.mp4",writer=animation.FFMpegWriter(fps=fps,bitrate=1800),dpi=120)
plt.close(); print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    for fld, dflt in asdict(WheelDownStairsParams()).items():
        if isinstance(dflt, int):
            parser.add_argument(f"--{fld}", type=int, default=dflt)
        else:
            parser.add_argument(f"--{fld}", type=float, default=dflt)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="video.mp4")
    args = parser.parse_args()
    p = WheelDownStairsParams(**{k: getattr(args, k) for k in asdict(WheelDownStairsParams()).keys()})
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
