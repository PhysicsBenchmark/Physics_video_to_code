"""
Disk Spin-off
=============
Top-down view: a disk spins up linearly from rest, with N_cubes co-rotating on
its surface. Each cube transitions ON_DISK_STUCK -> ON_DISK_SLIPPING when
required centripetal+tangential acceleration exceeds mu_s_disk*g, then to
ON_FLOOR once it crosses the disk edge, where Coulomb floor friction
decelerates it to rest.
"""

from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.transforms as mtransforms
from matplotlib.patches import Rectangle, Circle
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class DiskSpinoffParams:
    R_disk: float = 1.0
    N_cubes: int = 8
    cube_size: float = 0.08
    omega_max: float = 6.0
    t_ramp: float = 1.0
    mu_s_disk: float = 0.4
    mu_k_disk: float = 0.3
    mu_k_floor: float = 0.5
    g: float = 9.81
    seed: int = 7


def _run(p: DiskSpinoffParams, duration: float, fps: int):
    R_disk = p.R_disk
    N_cubes = int(p.N_cubes)
    cube_size = p.cube_size
    omega_max = p.omega_max
    t_ramp = p.t_ramp
    mu_s_disk = p.mu_s_disk
    mu_k_disk = p.mu_k_disk
    mu_k_floor = p.mu_k_floor
    g = p.g

    rng = np.random.default_rng(int(p.seed))
    r_init = R_disk * np.sqrt(rng.uniform(0.05, 0.85, N_cubes))
    phi_init = rng.uniform(0.0, 2 * np.pi, N_cubes)
    x = r_init * np.cos(phi_init)
    y = r_init * np.sin(phi_init)
    vx = np.zeros(N_cubes); vy = np.zeros(N_cubes)
    theta_cube = phi_init.copy()

    ON_STUCK, ON_SLIP, ON_FLOOR = 0, 1, 2
    status = np.full(N_cubes, ON_STUCK, dtype=int)

    def omega_disk(t):
        if t < t_ramp:
            return omega_max * (t / t_ramp)
        return omega_max

    dt = 1e-3
    n_steps = int(round(duration / dt)) + 1
    frame_stride = int(round(1.0 / (fps * dt)))
    n_frames = int(duration * fps) + 1

    X_hist = np.zeros((n_frames, N_cubes))
    Y_hist = np.zeros((n_frames, N_cubes))
    TH_hist = np.zeros((n_frames, N_cubes))
    DISK_HIST = np.zeros(n_frames)
    disk_angle = 0.0
    eps = 1e-6
    frame_idx = 0
    for step in range(n_steps):
        t = step * dt
        om = omega_disk(t)
        disk_angle += om * dt
        for i in range(N_cubes):
            r2 = x[i] ** 2 + y[i] ** 2
            on_disk = r2 < R_disk ** 2
            if status[i] != ON_FLOOR and not on_disk:
                status[i] = ON_FLOOR

            if status[i] == ON_STUCK:
                r_cur = np.sqrt(r2)
                a_c = (om ** 2) * r_cur
                alpha = omega_max / t_ramp if t < t_ramp else 0.0
                a_t = alpha * r_cur
                a_req = np.sqrt(a_c ** 2 + a_t ** 2)
                if a_req <= mu_s_disk * g:
                    c, s = np.cos(om * dt), np.sin(om * dt)
                    xn = c * x[i] - s * y[i]
                    yn = s * x[i] + c * y[i]
                    x[i] = xn; y[i] = yn
                    vx[i] = -om * y[i]; vy[i] = om * x[i]
                    theta_cube[i] += om * dt
                else:
                    status[i] = ON_SLIP

            if status[i] == ON_SLIP:
                vdx = -om * y[i]; vdy = om * x[i]
                vrx = vx[i] - vdx; vry = vy[i] - vdy
                vr_mag = np.sqrt(vrx * vrx + vry * vry)
                if vr_mag < eps:
                    ax_ = 0.0; ay_ = 0.0
                else:
                    ax_ = -mu_k_disk * g * vrx / vr_mag
                    ay_ = -mu_k_disk * g * vry / vr_mag
                vx[i] += ax_ * dt
                vy[i] += ay_ * dt
                x[i] += vx[i] * dt
                y[i] += vy[i] * dt
                theta_cube[i] += om * dt * 0.5
                if x[i] ** 2 + y[i] ** 2 >= R_disk ** 2:
                    status[i] = ON_FLOOR

            elif status[i] == ON_FLOOR:
                v_mag = np.sqrt(vx[i] * vx[i] + vy[i] * vy[i])
                if v_mag < eps:
                    vx[i] = 0.0; vy[i] = 0.0
                else:
                    ax_ = -mu_k_floor * g * vx[i] / v_mag
                    ay_ = -mu_k_floor * g * vy[i] / v_mag
                    vx_new = vx[i] + ax_ * dt
                    vy_new = vy[i] + ay_ * dt
                    if vx_new * vx[i] + vy_new * vy[i] < 0:
                        vx[i] = 0.0; vy[i] = 0.0
                    else:
                        vx[i] = vx_new; vy[i] = vy_new
                        x[i] += vx[i] * dt
                        y[i] += vy[i] * dt
        if step % frame_stride == 0 and frame_idx < n_frames:
            X_hist[frame_idx] = x
            Y_hist[frame_idx] = y
            TH_hist[frame_idx] = theta_cube
            DISK_HIST[frame_idx] = disk_angle
            frame_idx += 1
    while frame_idx < n_frames:
        X_hist[frame_idx] = x; Y_hist[frame_idx] = y
        TH_hist[frame_idx] = theta_cube; DISK_HIST[frame_idx] = disk_angle
        frame_idx += 1

    t_eval = np.linspace(0.0, duration, n_frames)
    return t_eval, X_hist, Y_hist, TH_hist, DISK_HIST


def simulate(
    params: DiskSpinoffParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    t_eval, X, Y, TH, DH = _run(params, duration, fps)
    # state stacking: rows are interleaved per-cube (X, Y, TH transposed) plus disk angle
    N = X.shape[1]
    out = np.vstack([X.T, Y.T, TH.T, DH[None, :]])
    return t_eval, out


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: DiskSpinoffParams,
    output_path: str,
    fps: int = 30,
) -> None:
    p = params
    N = int(p.N_cubes)
    X_hist = y[0:N].T
    Y_hist = y[N:2 * N].T
    TH_hist = y[2 * N:3 * N].T
    DISK_HIST = y[3 * N]

    W, H = 6.0, 6.0
    fig = plt.figure(figsize=(W, H), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e"); ax.axis("off"); ax.set_aspect("equal")

    extent = 1.6
    aspect = W / H
    dx = 2 * extent; dy = 2 * extent
    if dx / dy < aspect:
        extra = (aspect * dy - dx) / 2
        ax.set_xlim(-extent - extra, extent + extra); ax.set_ylim(-extent, extent)
    else:
        extra = (dx / aspect - dy) / 2
        ax.set_xlim(-extent, extent); ax.set_ylim(-extent - extra, extent + extra)

    xlim = ax.get_xlim(); ylim = ax.get_ylim()
    ax.add_patch(Rectangle((xlim[0], ylim[0]), xlim[1] - xlim[0], ylim[1] - ylim[0],
                           facecolor="#4a4e69", zorder=0))
    disk_patch = Circle((0, 0), p.R_disk, facecolor="#3a4357",
                        edgecolor="#a8dadc", lw=1.2, zorder=1)
    ax.add_patch(disk_patch)
    spoke_line, = ax.plot([], [], "-", color="#a8dadc", lw=2.0, zorder=2)
    spoke_dot, = ax.plot([], [], "o", color="#a8dadc", ms=5, zorder=2)

    cube_patches = []
    for _i in range(N):
        rect = Rectangle((-p.cube_size / 2, -p.cube_size / 2),
                         p.cube_size, p.cube_size,
                         facecolor="#e63946", edgecolor="#1a1a2e", lw=0.8, zorder=3)
        ax.add_patch(rect); cube_patches.append(rect)

    def update(frame):
        th_d = DISK_HIST[frame]
        sx, sy = p.R_disk * np.cos(th_d), p.R_disk * np.sin(th_d)
        spoke_line.set_data([0, sx], [0, sy])
        rd = 0.6 * p.R_disk
        spoke_dot.set_data([rd * np.cos(th_d + 1.7)], [rd * np.sin(th_d + 1.7)])
        for i, rect in enumerate(cube_patches):
            cx = X_hist[frame, i]; cy = Y_hist[frame, i]; th = TH_hist[frame, i]
            tr = (mtransforms.Affine2D().rotate(th).translate(cx, cy)) + ax.transData
            rect.set_transform(tr)
        return [spoke_line, spoke_dot] + cube_patches

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000 / fps, blit=True)
    writer = animation.FFMpegWriter(fps=fps, bitrate=2400)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: DiskSpinoffParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""
Disk Spin-off — auto-generated.
"""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.transforms as mtransforms
from matplotlib.patches import Rectangle, Circle

R_disk     = {p["R_disk"]}
N_cubes    = {int(p["N_cubes"])}
cube_size  = {p["cube_size"]}
omega_max  = {p["omega_max"]}
t_ramp     = {p["t_ramp"]}
mu_s_disk  = {p["mu_s_disk"]}
mu_k_disk  = {p["mu_k_disk"]}
mu_k_floor = {p["mu_k_floor"]}
g          = {p["g"]}
duration   = {duration}
fps        = 30
seed       = {int(p["seed"])}

rng = np.random.default_rng(seed)
r_init = R_disk * np.sqrt(rng.uniform(0.05, 0.85, N_cubes))
phi_init = rng.uniform(0.0, 2 * np.pi, N_cubes)
x = r_init * np.cos(phi_init); y = r_init * np.sin(phi_init)
vx = np.zeros(N_cubes); vy = np.zeros(N_cubes)
theta_cube = phi_init.copy()
ON_STUCK, ON_SLIP, ON_FLOOR = 0, 1, 2
status = np.full(N_cubes, ON_STUCK, dtype=int)

def omega_disk(t):
    if t < t_ramp: return omega_max * (t / t_ramp)
    return omega_max

dt = 1e-3
n_steps = int(round(duration / dt)) + 1
frame_stride = int(round(1.0 / (fps * dt)))
n_frames = int(duration * fps) + 1
X_hist = np.zeros((n_frames, N_cubes))
Y_hist = np.zeros((n_frames, N_cubes))
TH_hist = np.zeros((n_frames, N_cubes))
DISK_HIST = np.zeros(n_frames)
disk_angle = 0.0; eps = 1e-6; frame_idx = 0

for step in range(n_steps):
    t = step * dt
    om = omega_disk(t)
    disk_angle += om * dt
    for i in range(N_cubes):
        r2 = x[i]**2 + y[i]**2
        on_disk = r2 < R_disk**2
        if status[i] != ON_FLOOR and not on_disk:
            status[i] = ON_FLOOR
        if status[i] == ON_STUCK:
            r_cur = np.sqrt(r2)
            a_c = (om**2) * r_cur
            alpha = omega_max/t_ramp if t < t_ramp else 0.0
            a_t = alpha * r_cur
            a_req = np.sqrt(a_c**2 + a_t**2)
            if a_req <= mu_s_disk * g:
                c, s = np.cos(om*dt), np.sin(om*dt)
                xn = c*x[i] - s*y[i]; yn = s*x[i] + c*y[i]
                x[i] = xn; y[i] = yn
                vx[i] = -om * y[i]; vy[i] = om * x[i]
                theta_cube[i] += om * dt
            else:
                status[i] = ON_SLIP
        if status[i] == ON_SLIP:
            vdx = -om * y[i]; vdy = om * x[i]
            vrx = vx[i] - vdx; vry = vy[i] - vdy
            vr_mag = np.sqrt(vrx**2 + vry**2)
            if vr_mag < eps: ax_ = 0.0; ay_ = 0.0
            else:
                ax_ = -mu_k_disk * g * vrx / vr_mag
                ay_ = -mu_k_disk * g * vry / vr_mag
            vx[i] += ax_*dt; vy[i] += ay_*dt
            x[i] += vx[i]*dt; y[i] += vy[i]*dt
            theta_cube[i] += om * dt * 0.5
            if x[i]**2 + y[i]**2 >= R_disk**2:
                status[i] = ON_FLOOR
        elif status[i] == ON_FLOOR:
            v_mag = np.sqrt(vx[i]**2 + vy[i]**2)
            if v_mag < eps: vx[i] = 0.0; vy[i] = 0.0
            else:
                ax_ = -mu_k_floor * g * vx[i] / v_mag
                ay_ = -mu_k_floor * g * vy[i] / v_mag
                vx_new = vx[i] + ax_*dt; vy_new = vy[i] + ay_*dt
                if vx_new * vx[i] + vy_new * vy[i] < 0:
                    vx[i] = 0.0; vy[i] = 0.0
                else:
                    vx[i] = vx_new; vy[i] = vy_new
                    x[i] += vx[i]*dt; y[i] += vy[i]*dt
    if step % frame_stride == 0 and frame_idx < n_frames:
        X_hist[frame_idx] = x; Y_hist[frame_idx] = y
        TH_hist[frame_idx] = theta_cube; DISK_HIST[frame_idx] = disk_angle
        frame_idx += 1

while frame_idx < n_frames:
    X_hist[frame_idx] = x; Y_hist[frame_idx] = y
    TH_hist[frame_idx] = theta_cube; DISK_HIST[frame_idx] = disk_angle
    frame_idx += 1

W, H = 6.0, 6.0
fig = plt.figure(figsize=(W, H), facecolor="#1a1a2e")
ax = fig.add_axes([0, 0, 1, 1]); ax.set_facecolor("#16213e")
ax.axis("off"); ax.set_aspect("equal")
extent = 1.6; aspect = W / H
dx = 2*extent; dy = 2*extent
if dx/dy < aspect:
    extra = (aspect*dy - dx)/2
    ax.set_xlim(-extent - extra, extent + extra); ax.set_ylim(-extent, extent)
else:
    extra = (dx/aspect - dy)/2
    ax.set_xlim(-extent, extent); ax.set_ylim(-extent - extra, extent + extra)

xlim = ax.get_xlim(); ylim = ax.get_ylim()
ax.add_patch(Rectangle((xlim[0], ylim[0]), xlim[1]-xlim[0], ylim[1]-ylim[0], facecolor="#4a4e69", zorder=0))
disk_patch = Circle((0,0), R_disk, facecolor="#3a4357", edgecolor="#a8dadc", lw=1.2, zorder=1)
ax.add_patch(disk_patch)
spoke_line, = ax.plot([], [], "-", color="#a8dadc", lw=2.0, zorder=2)
spoke_dot,  = ax.plot([], [], "o", color="#a8dadc", ms=5, zorder=2)

cube_patches = []
for i in range(N_cubes):
    rect = Rectangle((-cube_size/2, -cube_size/2), cube_size, cube_size,
                     facecolor="#e63946", edgecolor="#1a1a2e", lw=0.8, zorder=3)
    ax.add_patch(rect); cube_patches.append(rect)

def update(frame):
    th_d = DISK_HIST[frame]
    sx, sy = R_disk * np.cos(th_d), R_disk * np.sin(th_d)
    spoke_line.set_data([0, sx], [0, sy])
    rd = 0.6 * R_disk
    spoke_dot.set_data([rd * np.cos(th_d + 1.7)], [rd * np.sin(th_d + 1.7)])
    for i, rect in enumerate(cube_patches):
        cx = X_hist[frame, i]; cy = Y_hist[frame, i]; th = TH_hist[frame, i]
        tr = (mtransforms.Affine2D().rotate(th).translate(cx, cy)) + ax.transData
        rect.set_transform(tr)
    return [spoke_line, spoke_dot] + cube_patches

ani = animation.FuncAnimation(fig, update, frames=n_frames, interval=1000/fps, blit=True)
ani.save("disk_spinoff.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=2400), dpi=120)
plt.close(); print("Saved disk_spinoff.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Disk Spin-off")
    parser.add_argument("--R_disk", type=float, default=1.0)
    parser.add_argument("--N_cubes", type=int, default=8)
    parser.add_argument("--cube_size", type=float, default=0.08)
    parser.add_argument("--omega_max", type=float, default=6.0)
    parser.add_argument("--t_ramp", type=float, default=1.0)
    parser.add_argument("--mu_s_disk", type=float, default=0.4)
    parser.add_argument("--mu_k_disk", type=float, default=0.3)
    parser.add_argument("--mu_k_floor", type=float, default=0.5)
    parser.add_argument("--g", type=float, default=9.81)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="disk_spinoff.mp4")
    args = parser.parse_args()
    p = DiskSpinoffParams(
        R_disk=args.R_disk, N_cubes=args.N_cubes, cube_size=args.cube_size,
        omega_max=args.omega_max, t_ramp=args.t_ramp,
        mu_s_disk=args.mu_s_disk, mu_k_disk=args.mu_k_disk,
        mu_k_floor=args.mu_k_floor, g=args.g, seed=args.seed,
    )
    print(f"Simulating disk_spinoff: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
