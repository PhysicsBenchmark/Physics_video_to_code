"""
Ballistic Pendulum Simulation
=============================
Classic 19th-century device for inferring projectile speed from a swing
height: a projectile of mass m strikes and embeds itself into a block
of mass M hanging from a rigid massless rod of length L. Conservation of
linear momentum across the (perfectly inelastic) collision and conservation
of mechanical energy during the subsequent swing relate the maximum swing
angle to the bullet's initial speed.

Physical Laws
-------------
1. Linear momentum conservation across the collision (instantaneous, external
   forces are negligible during the contact):
        m · v_b = (m + M) · v_after
   ⇒  v_after = m · v_b / (m + M)

2. Energy conservation during the post-impact swing (no work done by the
   tension in the rod; damping included as a torque):
        ½ (m+M) v_after² = (m+M) g h_max          (when b = 0)
        h_max = L (1 − cos θ_max)
   ⇒  v_b = ((m+M) / m) · √(2 g L (1 − cos θ_max))

3. Equation of motion of the loaded pendulum (combined mass m+M as a point
   mass at distance L from the pivot, with optional viscous angular damping b):
        I · θ̈ = -(m+M) g L sin θ − b θ̇          where I = (m+M) L²
   ⇒  θ̈ = -(g/L) sin θ − (b / ((m+M) L²)) · θ̇

State (post-impact): [θ, ω] with ω = θ̇.
Initial conditions at the impact instant t = t_impact: θ = 0, ω = v_after / L.

Pre-impact, the bullet flies horizontally at constant velocity v_b at the
height of the block; gravity on the bullet is neglected for the brief
flight (typical for ballistic-pendulum analyses).
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis


@dataclass
class BallisticPendulumParams:
    m: float = 0.20        # bullet / projectile mass (kg)
    M: float = 0.80        # hanging-block mass (kg)
    v_b: float = 8.0       # bullet initial speed, +x direction (m/s)
    L: float = 1.10        # pendulum rod length (m)
    g: float = 9.8         # gravitational acceleration (m/s²)
    b: float = 0.05        # angular damping coefficient (kg·m²/s)
    x_b0: float = -2.5     # bullet initial x position (m); pivot is at x=0


def ode(t: float, y: list, p: BallisticPendulumParams):
    """Pendulum ODE for the combined (m+M) mass after the bullet embeds."""
    theta, omega = y
    m_total = p.m + p.M
    Iover = m_total * p.L * p.L
    dtheta = omega
    domega = -(p.g / p.L) * np.sin(theta) - (p.b / Iover) * omega
    return [dtheta, domega]


def simulate(
    params: BallisticPendulumParams,
    duration: float = 6.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Run the two-phase ballistic-pendulum simulation and return one
    contiguous (t, y) table sampled at frame rate. The state row order is

        y[0] = bullet_x       (x position of the bullet, m)
        y[1] = bullet_y       (y position of the bullet, m; pivot is origin)
        y[2] = theta          (rod angle from vertical, rad)
        y[3] = omega          (angular velocity, rad/s)
        y[4] = embedded       (1.0 once the bullet has embedded, else 0.0)

    Pre-impact: bullet flies at constant velocity at the block height
    (y = -L); block stationary at θ = 0. Impact is treated as instantaneous
    when bullet x reaches x = 0 (pivot's x). Post-impact: integrate the
    loaded pendulum ODE from impact time to `duration`.
    """
    n_frames = int(duration * fps) + 1
    t_eval = np.linspace(0, duration, n_frames)

    t_impact = max(0.0, -params.x_b0 / params.v_b)        # bullet reaches x=0
    v_after = params.m * params.v_b / (params.m + params.M)
    omega_after = v_after / params.L

    bullet_x = np.empty(n_frames)
    bullet_y = np.full(n_frames, -params.L)
    theta = np.zeros(n_frames)
    omega = np.zeros(n_frames)
    embedded = np.zeros(n_frames)

    pre_mask = t_eval < t_impact
    post_mask = ~pre_mask

    # Phase 1: bullet flies in
    bullet_x[pre_mask] = params.x_b0 + params.v_b * t_eval[pre_mask]

    # Phase 2: integrate loaded pendulum from t_impact onward
    if np.any(post_mask):
        post_t_local = t_eval[post_mask] - t_impact
        # solve_ivp requires a non-empty span. If the very first post-frame is
        # exactly zero we still want the initial state to be reproduced.
        if post_t_local[-1] <= 0:
            theta[post_mask] = 0.0
            omega[post_mask] = omega_after
        else:
            t_span = (0.0, post_t_local[-1])
            sol = solve_ivp(
                ode,
                t_span,
                [0.0, omega_after],
                t_eval=post_t_local,
                args=(params,),
                method="RK45",
                rtol=1e-9,
                atol=1e-11,
            )
            theta[post_mask] = sol.y[0]
            omega[post_mask] = sol.y[1]

        # After embedding, bullet rides with the block
        bullet_x[post_mask] = params.L * np.sin(theta[post_mask])
        bullet_y[post_mask] = -params.L * np.cos(theta[post_mask])
        embedded[post_mask] = 1.0

    y = np.vstack([bullet_x, bullet_y, theta, omega, embedded])
    return t_eval, y


def collision_summary(params: BallisticPendulumParams):
    v_after = params.m * params.v_b / (params.m + params.M)
    h_predicted = v_after ** 2 / (2 * params.g)            # b = 0 limit
    cos_arg = 1 - h_predicted / params.L
    if cos_arg <= -1:
        theta_max_predicted = np.pi
    else:
        theta_max_predicted = float(np.arccos(np.clip(cos_arg, -1.0, 1.0)))
    KE_before = 0.5 * params.m * params.v_b ** 2
    KE_after = 0.5 * (params.m + params.M) * v_after ** 2
    return {
        "v_after": v_after,
        "h_max_undamped": h_predicted,
        "theta_max_undamped_rad": theta_max_predicted,
        "KE_before": KE_before,
        "KE_after_impact": KE_after,
        "energy_lost_in_impact": KE_before - KE_after,
        "fraction_KE_lost": (KE_before - KE_after) / KE_before if KE_before > 0 else 0.0,
    }


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: BallisticPendulumParams,
    output_path: str,
    fps: int = 30,
    trail_len: int = 60,
) -> None:
    bullet_x, bullet_y = y[0], y[1]
    theta = y[2]
    embedded = y[4]

    # Block dimensions (purely visual; physics treats it as a point mass)
    bw = max(0.16, 0.10 * params.L)
    bh = max(0.16, 0.10 * params.L)
    bullet_r = 0.045

    # Frame: pivot at origin, block hangs at y = -L, bullet enters from the left
    pad = 0.4
    xlim = (params.x_b0 - 0.3, params.L + pad)
    ylim = (-params.L - max(bh, 0.4), 0.6)

    fig, ax = plt.subplots(figsize=(7, 5))
    setup_dark_axis(fig, ax, xlim, ylim)

    # Static elements
    ax.plot([0], [0], "o", color="white", ms=7, zorder=6)            # pivot
    # Reference dashed line marking the rest position of the block
    ax.axvline(0, color="#4a4e69", lw=0.8, ls="--", alpha=0.5, zorder=1)
    ax.axhline(-params.L, color="#4a4e69", lw=0.6, ls=":", alpha=0.4, zorder=1)
    # Path the bullet flies along
    ax.plot([params.x_b0, 0], [-params.L, -params.L],
            color="#4a4e69", lw=0.8, ls=":", alpha=0.5, zorder=1)

    # Animated elements
    (rod,)   = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
    block_p = patches.FancyBboxPatch(
        (-bw / 2, -params.L - bh / 2), bw, bh,
        boxstyle="round,pad=0.02",
        linewidth=1.5, edgecolor="white", facecolor="#457b9d",
    )
    ax.add_patch(block_p)
    (bullet_p,) = ax.plot([], [], "o", color="#e63946", ms=10, zorder=5)
    (trail,)    = ax.plot([], [], "-", color="#e63946", alpha=0.35, lw=1.0, zorder=2)

    trail_x: list = []
    trail_y: list = []

    def init():
        rod.set_data([], [])
        bullet_p.set_data([], [])
        trail.set_data([], [])
        return rod, bullet_p, trail, block_p, 
    def update(frame):
        th = theta[frame]
        block_cx = params.L * np.sin(th)
        block_cy = -params.L * np.cos(th)

        rod.set_data([0, block_cx], [0, block_cy])
        block_p.set_x(block_cx - bw / 2)
        block_p.set_y(block_cy - bh / 2)
        # Block patch does not rotate (would require an Affine2D), but the
        # rod and block centre faithfully track the angular state.

        bullet_p.set_data([bullet_x[frame]], [bullet_y[frame]])

        # Trail only after embedding (so it traces the swing arc, not flight)
        if embedded[frame] > 0.5:
            trail_x.append(block_cx)
            trail_y.append(block_cy)
            if len(trail_x) > trail_len:
                trail_x.pop(0)
                trail_y.pop(0)
            trail.set_data(trail_x, trail_y)

        return rod, bullet_p, trail, block_p
    ani = animation.FuncAnimation(
        fig, update, frames=len(t), init_func=init, interval=1000 / fps, blit=False
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(
    params: BallisticPendulumParams,
    duration: float = 6.0,
) -> str:
    p = asdict(params)
    v_after_val = p["m"] * p["v_b"] / (p["m"] + p["M"])
    return f'''"""
Ballistic Pendulum — auto-generated simulation script.

Physics:
  1. Inelastic collision (instantaneous):  m·v_b = (m+M)·v_after
  2. Loaded pendulum after impact:
        θ̈ = -(g/L)·sin(θ) - (b/((m+M)·L²))·θ̇
  3. From the swing's max angle θ_max one recovers v_b via
        v_b = ((m+M)/m)·sqrt(2·g·L·(1 - cos θ_max))   (b → 0 limit)

Parameters: m={p["m"]} kg, M={p["M"]} kg, v_b={p["v_b"]} m/s, L={p["L"]} m,
            g={p["g"]} m/s², b={p["b"]} kg·m²/s, x_b0={p["x_b0"]} m
            v_after = m·v_b/(m+M) = {v_after_val:.4f} m/s
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

# ── Physical parameters ─────────────────────────────────────────────────────
m, M    = {p["m"]}, {p["M"]}              # bullet, block masses (kg)
v_b     = {p["v_b"]}                       # bullet initial velocity (m/s)
L       = {p["L"]}                         # rod length (m)
g       = {p["g"]}                         # gravitational acceleration (m/s²)
b       = {p["b"]}                         # angular damping (kg·m²/s)
x_b0    = {p["x_b0"]}                      # bullet starting x (m), pivot at 0
duration = {duration}
fps      = 30

# ── Pre-impact: ballistic flight at constant v_b ────────────────────────────
t_impact = max(0.0, -x_b0 / v_b)
v_after  = m * v_b / (m + M)
omega_after = v_after / L            # rod angular velocity at impact

# ── Post-impact: loaded pendulum ODE ────────────────────────────────────────
def ode(t, y):
    theta, omega = y
    Iover = (m + M) * L * L
    dtheta = omega
    domega = -(g / L) * np.sin(theta) - (b / Iover) * omega
    return [dtheta, domega]

# ── Sample on common time grid ──────────────────────────────────────────────
n_frames = int(duration * fps) + 1
t_eval   = np.linspace(0, duration, n_frames)
pre_mask  = t_eval < t_impact
post_mask = ~pre_mask

bullet_x = np.empty(n_frames)
bullet_y = np.full(n_frames, -L)
theta    = np.zeros(n_frames)
embedded = np.zeros(n_frames)

bullet_x[pre_mask]  = x_b0 + v_b * t_eval[pre_mask]
bullet_x[post_mask] = 0.0     # placeholder, overwritten below

if np.any(post_mask):
    post_t_local = t_eval[post_mask] - t_impact
    if post_t_local[-1] > 0:
        sol = solve_ivp(ode, (0.0, post_t_local[-1]),
                        [0.0, omega_after], t_eval=post_t_local,
                        method="RK45", rtol=1e-9, atol=1e-11)
        theta[post_mask] = sol.y[0]
    bullet_x[post_mask] = L * np.sin(theta[post_mask])
    bullet_y[post_mask] = -L * np.cos(theta[post_mask])
    embedded[post_mask] = 1.0

# ── Animation ───────────────────────────────────────────────────────────────
bw = max(0.16, 0.10 * L); bh = max(0.16, 0.10 * L)
pad = 0.4
xlim = (x_b0 - 0.3, L + pad)
ylim = (-L - max(bh, 0.4), 0.6)

fig, ax = plt.subplots(figsize=(7, 5), facecolor="#1a1a2e")
ax.set_facecolor("#16213e"); ax.set_xlim(xlim); ax.set_ylim(ylim)
ax.set_aspect("equal"); ax.axis("off")
ax.plot([0], [0], "o", color="white", ms=7, zorder=6)
ax.axvline(0, color="#4a4e69", lw=0.8, ls="--", alpha=0.5, zorder=1)
ax.axhline(-L, color="#4a4e69", lw=0.6, ls=":", alpha=0.4, zorder=1)
ax.plot([x_b0, 0], [-L, -L], color="#4a4e69", lw=0.8, ls=":", alpha=0.5, zorder=1)

rod,      = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
block_p   = patches.FancyBboxPatch((-bw/2, -L-bh/2), bw, bh,
            boxstyle="round,pad=0.02", linewidth=1.5,
            edgecolor="white", facecolor="#457b9d")
ax.add_patch(block_p)
bullet_p, = ax.plot([], [], "o", color="#e63946", ms=10, zorder=5)
trail,    = ax.plot([], [], "-", color="#e63946", alpha=0.35, lw=1.0, zorder=2)
tx, ty = [], []

def update(f):
    th = theta[f]
    bx = L * np.sin(th); by = -L * np.cos(th)
    rod.set_data([0, bx], [0, by])
    block_p.set_x(bx - bw/2); block_p.set_y(by - bh/2)
    bullet_p.set_data([bullet_x[f]], [bullet_y[f]])
    if embedded[f] > 0.5:
        tx.append(bx); ty.append(by)
        if len(tx) > 60: tx.pop(0); ty.pop(0)
        trail.set_data(tx, ty)
    return rod, block_p, bullet_p, trail
ani = animation.FuncAnimation(fig, update, frames=len(t_eval),
                              interval=1000/fps, blit=False)
ani.save("ballistic_pendulum.mp4",
         writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close(); print("Saved ballistic_pendulum.mp4")
'''


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Ballistic Pendulum Simulation")
    parser.add_argument("--m",       type=float, default=0.2)
    parser.add_argument("--M",       type=float, default=0.8)
    parser.add_argument("--v_b",     type=float, default=8.0)
    parser.add_argument("--L",       type=float, default=1.1)
    parser.add_argument("--g",       type=float, default=9.8)
    parser.add_argument("--b",       type=float, default=0.05)
    parser.add_argument("--x_b0",    type=float, default=-2.5)
    parser.add_argument("--duration", type=float, default=6.0)
    parser.add_argument("--output",   type=str, default="ballistic_pendulum.mp4")
    args = parser.parse_args()

    p = BallisticPendulumParams(
        m=args.m, M=args.M, v_b=args.v_b, L=args.L,
        g=args.g, b=args.b, x_b0=args.x_b0,
    )
    print(f"Simulating ballistic pendulum: {asdict(p)}")
    print(f"  collision summary: {collision_summary(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
