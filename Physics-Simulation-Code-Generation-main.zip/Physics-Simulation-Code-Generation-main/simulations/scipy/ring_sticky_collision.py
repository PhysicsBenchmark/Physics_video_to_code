"""
Ring Sticky Collision — closed-form rigid-body dynamics.

A spinning ring (mass M, radius R) sits at the origin. A point mass m on a
horizontal trajectory y=b strikes the leftmost point of the ring at time t_c
and STICKS perfectly inelastically. After impact, conservation of linear and
angular momentum + parallel-axis theorem give closed-form V_com and Omega_after.
Phase 2 is uniform translation + uniform rotation (force/torque-free).

State (sampled): ring centre (x,y), ring orientation phi, point-mass (x,y).
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Circle
from dataclasses import dataclass, asdict
import sys
import os


@dataclass
class RingStickyCollisionParams:
    M: float = 2.0           # ring mass (kg)
    R: float = 1.0           # ring radius (m)
    m: float = 0.5           # point mass (kg)
    Omega_0: float = 1.5     # initial ring spin (rad/s, CCW positive)
    v: float = 3.0           # point velocity (+x m/s)
    b: float = 0.4           # impact parameter (vertical offset, m); |b|<R
    x_start_point: float = -6.0  # initial x of point mass


def simulate(
    params: RingStickyCollisionParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Returns (t_eval, y) with y.shape = (5, N): [ring_cx, ring_cy, phi_ring, pt_x, pt_y]."""
    M, R, m = params.M, params.R, params.m
    Omega_0, v, b = params.Omega_0, params.v, params.b
    x_start = params.x_start_point

    assert abs(b) < R, "|b| must be < R"

    x_hit = -np.sqrt(R * R - b * b)
    y_hit = b
    r_hit = np.array([x_hit, y_hit])
    t_c = (x_hit - x_start) / v

    M_tot = M + m
    V_com = np.array([m * v / M_tot, 0.0])
    R_com_c = m * r_hit / M_tot
    I_total = M * R * R * (M + 2.0 * m) / M_tot

    L_before = M * R * R * Omega_0 - b * m * v
    RxV_z = R_com_c[0] * V_com[1] - R_com_c[1] * V_com[0]
    L_trans = M_tot * RxV_z
    Omega_after = (L_before - L_trans) / I_total

    t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
    n = t_eval.size
    ring_cx = np.zeros(n)
    ring_cy = np.zeros(n)
    phi_ring = np.zeros(n)
    pt_x = np.zeros(n)
    pt_y = np.zeros(n)

    for i, t in enumerate(t_eval):
        if t < t_c:
            ring_cx[i] = 0.0
            ring_cy[i] = 0.0
            phi_ring[i] = Omega_0 * t
            pt_x[i] = x_start + v * t
            pt_y[i] = b
        else:
            dt = t - t_c
            R_com_t = R_com_c + V_com * dt
            ring_off0 = -R_com_c
            pt_off0 = r_hit - R_com_c
            phi_body = Omega_0 * t_c + Omega_after * dt
            dphi = Omega_after * dt
            c, s = np.cos(dphi), np.sin(dphi)
            Rmat = np.array([[c, -s], [s, c]])
            ring_off = Rmat @ ring_off0
            pt_off = Rmat @ pt_off0
            ring_cx[i] = R_com_t[0] + ring_off[0]
            ring_cy[i] = R_com_t[1] + ring_off[1]
            pt_x[i] = R_com_t[0] + pt_off[0]
            pt_y[i] = R_com_t[1] + pt_off[1]
            phi_ring[i] = phi_body

    y = np.vstack([ring_cx, ring_cy, phi_ring, pt_x, pt_y])
    return t_eval, y


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: RingStickyCollisionParams,
    output_path: str,
    fps: int = 30,
) -> None:
    ring_cx, ring_cy, phi_ring, pt_x, pt_y = y[0], y[1], y[2], y[3], y[4]
    R = params.R
    tick_x = ring_cx + R * np.cos(phi_ring)
    tick_y = ring_cy + R * np.sin(phi_ring)

    fig_w, fig_h = 8.0, 5.0
    fig_aspect = fig_w / fig_h
    all_x = np.concatenate([pt_x, ring_cx + R, ring_cx - R, tick_x])
    all_y = np.concatenate([pt_y, ring_cy + R, ring_cy - R, tick_y])
    pad = 0.5
    x_lo_d, x_hi_d = all_x.min() - pad, all_x.max() + pad
    y_lo_d, y_hi_d = all_y.min() - pad, all_y.max() + pad
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#0b0b1f")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#0b0b1f")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    rng = np.random.default_rng(11)
    star_x = rng.uniform(x_lo, x_hi, size=220)
    star_y = rng.uniform(y_lo, y_hi, size=220)
    star_s = rng.uniform(0.5, 3.0, size=220) ** 2
    star_a = rng.uniform(0.25, 0.80, size=220)
    ax.scatter(star_x, star_y, s=star_s, c="white", alpha=star_a, zorder=0,
               edgecolors='none')

    ring_patch = Circle((0.0, 0.0), R, fill=False, edgecolor="#80c0ff",
                        lw=2.5, zorder=3)
    ax.add_patch(ring_patch)
    tick_ln, = ax.plot([], [], "-", color="#80c0ff", lw=2.0, zorder=4)
    pt_radius = 0.06
    pt_patch = Circle((pt_x[0], pt_y[0]), pt_radius, facecolor="#ef476f",
                      edgecolor="white", lw=1.2, zorder=5)
    ax.add_patch(pt_patch)

    def update(f):
        ring_patch.set_center((ring_cx[f], ring_cy[f]))
        tick_ln.set_data([ring_cx[f], tick_x[f]], [ring_cy[f], tick_y[f]])
        pt_patch.set_center((pt_x[f], pt_y[f]))
        return ring_patch, tick_ln, pt_patch

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0 / fps, blit=True)
    ani.save(output_path,
             writer=animation.FFMpegWriter(fps=fps, bitrate=2400), dpi=120)
    plt.close(fig)


def make_standalone_script(
    params: RingStickyCollisionParams,
    duration: float = 12.0,
) -> str:
    p = asdict(params)
    return f'''"""Ring sticky collision — auto-generated."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Circle

M             = {p["M"]}
R             = {p["R"]}
m             = {p["m"]}
Omega_0       = {p["Omega_0"]}
v             = {p["v"]}
b             = {p["b"]}
x_start_point = {p["x_start_point"]}
duration      = {duration}
fps           = 30

assert abs(b) < R

x_hit = -np.sqrt(R*R - b*b); y_hit = b
r_hit = np.array([x_hit, y_hit])
t_c = (x_hit - x_start_point) / v
M_tot = M + m
V_com = np.array([m*v/M_tot, 0.0])
R_com_c = m * r_hit / M_tot
I_total = M*R*R*(M + 2.0*m)/M_tot
L_before = M*R*R*Omega_0 - b*m*v
RxV_z = R_com_c[0]*V_com[1] - R_com_c[1]*V_com[0]
L_trans = M_tot*RxV_z
Omega_after = (L_before - L_trans) / I_total

t_eval = np.linspace(0.0, duration, int(duration*fps)+1)
n = t_eval.size
ring_cx = np.zeros(n); ring_cy = np.zeros(n); phi_ring = np.zeros(n)
pt_x = np.zeros(n); pt_y = np.zeros(n)
for i, t in enumerate(t_eval):
    if t < t_c:
        ring_cx[i] = 0.0; ring_cy[i] = 0.0
        phi_ring[i] = Omega_0*t
        pt_x[i] = x_start_point + v*t; pt_y[i] = b
    else:
        dt = t - t_c
        R_com_t = R_com_c + V_com*dt
        ring_off0 = -R_com_c; pt_off0 = r_hit - R_com_c
        phi_body = Omega_0*t_c + Omega_after*dt
        dphi = Omega_after*dt
        c, s = np.cos(dphi), np.sin(dphi)
        Rmat = np.array([[c,-s],[s,c]])
        ring_off = Rmat @ ring_off0; pt_off = Rmat @ pt_off0
        ring_cx[i] = R_com_t[0] + ring_off[0]
        ring_cy[i] = R_com_t[1] + ring_off[1]
        pt_x[i] = R_com_t[0] + pt_off[0]
        pt_y[i] = R_com_t[1] + pt_off[1]
        phi_ring[i] = phi_body

tick_x = ring_cx + R*np.cos(phi_ring)
tick_y = ring_cy + R*np.sin(phi_ring)

fig_w, fig_h = 8.0, 5.0
fa = fig_w/fig_h
all_x = np.concatenate([pt_x, ring_cx+R, ring_cx-R, tick_x])
all_y = np.concatenate([pt_y, ring_cy+R, ring_cy-R, tick_y])
pad = 0.5
xlo, xhi = all_x.min()-pad, all_x.max()+pad
ylo, yhi = all_y.min()-pad, all_y.max()+pad
dx, dy = xhi-xlo, yhi-ylo
if dx/dy < fa:
    e=(fa*dy-dx)/2; xlo-=e; xhi+=e
else:
    e=(dx/fa-dy)/2; ylo-=e; yhi+=e

fig = plt.figure(figsize=(fig_w,fig_h), facecolor="#0b0b1f")
ax = fig.add_axes([0,0,1,1])
ax.set_facecolor("#0b0b1f")
ax.set_xlim(xlo,xhi); ax.set_ylim(ylo,yhi)
ax.set_aspect("equal"); ax.axis("off")

rng = np.random.default_rng(11)
sx = rng.uniform(xlo,xhi,220); sy = rng.uniform(ylo,yhi,220)
ss = rng.uniform(0.5,3.0,220)**2; sa = rng.uniform(0.25,0.80,220)
ax.scatter(sx,sy,s=ss,c="white",alpha=sa,zorder=0,edgecolors='none')

ring_patch = Circle((0.0,0.0), R, fill=False, edgecolor="#80c0ff", lw=2.5, zorder=3)
ax.add_patch(ring_patch)
tick_ln, = ax.plot([],[],"-",color="#80c0ff", lw=2.0, zorder=4)
pt_patch = Circle((pt_x[0],pt_y[0]), 0.06, facecolor="#ef476f",
                  edgecolor="white", lw=1.2, zorder=5)
ax.add_patch(pt_patch)

def update(f):
    ring_patch.set_center((ring_cx[f], ring_cy[f]))
    tick_ln.set_data([ring_cx[f], tick_x[f]], [ring_cy[f], tick_y[f]])
    pt_patch.set_center((pt_x[f], pt_y[f]))
    return ring_patch, tick_ln, pt_patch

ani = animation.FuncAnimation(fig, update, frames=len(t_eval), interval=1000/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=2400), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Ring Sticky Collision")
    parser.add_argument("--M", type=float, default=2.0)
    parser.add_argument("--R", type=float, default=1.0)
    parser.add_argument("--m", type=float, default=0.5)
    parser.add_argument("--Omega_0", type=float, default=1.5)
    parser.add_argument("--v", type=float, default=3.0)
    parser.add_argument("--b", type=float, default=0.4)
    parser.add_argument("--x_start_point", type=float, default=-6.0)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="ring_sticky_collision.mp4")
    args = parser.parse_args()

    p = RingStickyCollisionParams(
        M=args.M, R=args.R, m=args.m, Omega_0=args.Omega_0,
        v=args.v, b=args.b, x_start_point=args.x_start_point,
    )
    print(f"Simulating ring sticky collision: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
