"""
Single Spring-Mass-Damper Simulation
=====================================
Faithfully translated from myphysicslab/src/sims/springs/SingleSpringSim.ts

Physical Law: Newton's Second Law (Hooke's Law + viscous damping)
    F_net = m·a

Forces on the block:
    F_spring = -k · stretch   where stretch = x - x_eq  (displacement from equilibrium)
    F_damping = -b · v

Equation of motion:
    m ẍ = -k (x - x_eq) - b ẋ

Using displacement from equilibrium u = x - x_eq:
    m ü = -k u - b u̇
    ü = -(k/m) u - (b/m) u̇

Characteristic equation: λ² + (b/m)λ + k/m = 0
    ω₀ = √(k/m)                   (natural frequency)
    ζ  = b / (2 m ω₀)              (damping ratio)
    Underdamped:  ζ < 1  →  oscillatory decay
    Critically damped: ζ = 1
    Overdamped: ζ > 1  →  exponential return

State vector: [u, v]  where u = x - x_eq,  v = u̇
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis, spring_path


@dataclass
class SingleSpringParams:
    k: float = 3.0     # spring stiffness (N/m)   [TS default]
    m: float = 0.5     # block mass (kg)           [TS default]
    b: float = 0.1     # damping coefficient (kg/s) [TS default]
    u0: float = 1.5    # initial displacement from equilibrium (m)
    v0: float = 0.0    # initial velocity (m/s)


def ode(t: float, y: list, p: SingleSpringParams):
    """
    Exact translation of SingleSpringSim.ts evaluate():
        change[X] = vars[V]
        change[V] = (-k * stretch - b * v) / m
    where stretch = u  (displacement from equilibrium).
    """
    u, v = y
    du = v
    dv = (-p.k * u - p.b * v) / p.m
    return [du, dv]


def simulate(
    params: SingleSpringParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Integrate using RK45. Returns (t, y) with y.shape = (2, N)."""
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode,
        (0, duration),
        [params.u0, params.v0],
        t_eval=t_eval,
        args=(params,),
        method="RK45",
        rtol=1e-9,
        atol=1e-11,
    )
    return sol.t, sol.y


def natural_frequency(p: SingleSpringParams) -> float:
    return np.sqrt(p.k / p.m)


def damping_ratio(p: SingleSpringParams) -> float:
    omega0 = natural_frequency(p)
    return p.b / (2 * p.m * omega0)


def energy(t: np.ndarray, y: np.ndarray, p: SingleSpringParams):
    u, v = y
    KE = 0.5 * p.m * v ** 2
    PE = 0.5 * p.k * u ** 2
    return KE, PE, KE + PE


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: SingleSpringParams,
    output_path: str,
    fps: int = 30,
) -> None:
    """
    Render horizontal spring-mass system:
      [wall] ~~~spring~~~ [block]    on a track
    """
    u = y[0]

    # Layout: wall on far left, equilibrium at x=0, block at x=u
    wall_x = -3.5       # left edge of spring attachment
    block_w = 0.4
    block_h = 0.4
    track_y = 0.0

    x_max = wall_x + 2 * np.abs(params.u0) + 2.5
    xlim = (wall_x - 0.3, x_max)
    ylim = (-1.0, 1.0)

    fig, ax = plt.subplots(figsize=(8, 4))
    setup_dark_axis(fig, ax, xlim, ylim)

    # Static: track line and wall
    ax.axhline(track_y - block_h / 2, color="#4a4e69", lw=1.5, zorder=1)
    wall_patch = patches.Rectangle(
        (wall_x - 0.2, -0.6), 0.2, 1.2,
        facecolor="#4a4e69", edgecolor="#adb5bd", lw=1, hatch="////",
    )
    ax.add_patch(wall_patch)
    # Equilibrium marker
    ax.axvline(0, color="#4a4e69", lw=0.8, ls="--", alpha=0.5, zorder=1)

    # Animated elements
    (spring_line,) = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
    block_patch = patches.FancyBboxPatch(
        (-block_w / 2, track_y - block_h / 2),
        block_w, block_h,
        boxstyle="round,pad=0.02",
        linewidth=1.5, edgecolor="white", facecolor="#e63946",
    )
    ax.add_patch(block_patch)

    def init():
        spring_line.set_data([], [])
        return (spring_line,)

    def update(frame):
        bx = u[frame]
        block_patch.set_x(bx - block_w / 2)
        sx, sy = spring_path(
            wall_x, track_y, bx - block_w / 2, track_y,
            n_coils=8, coil_radius=0.15,
        )
        spring_line.set_data(sx, sy)
        return (spring_line,)

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), init_func=init, interval=1000 / fps, blit=False
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: SingleSpringParams, duration: float = 12.0) -> str:
    p = asdict(params)
    omega0 = np.sqrt(p["k"] / p["m"])
    zeta = p["b"] / (2 * p["m"] * omega0)
    regime = "underdamped" if zeta < 1 else ("critically damped" if zeta == 1 else "overdamped")
    return f'''"""
Spring-Mass-Damper — auto-generated simulation script.
Physics (Newton's Second Law):
    ü = -(k/m)·u - (b/m)·u̇
Parameters: k={p["k"]} N/m, m={p["m"]} kg, b={p["b"]} kg/s
  ω₀ = {omega0:.4f} rad/s,  ζ = {zeta:.4f}  ({regime})
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

k, m, b = {p["k"]}, {p["m"]}, {p["b"]}   # stiffness (N/m), mass (kg), damping (kg/s)
u0, v0  = {p["u0"]:.6f}, {p["v0"]:.6f}    # initial displacement (m), velocity (m/s)
duration = {duration}

def ode(t, y):
    u, v = y
    return [v, (-k*u - b*v)/m]

fps = 30
t_eval = np.linspace(0, duration, int(duration*fps)+1)
sol = solve_ivp(ode,(0,duration),[u0,v0],t_eval=t_eval,method="RK45",rtol=1e-9,atol=1e-11)
u_arr = sol.y[0]

wall_x, block_w, block_h, track_y = -3.5, 0.4, 0.4, 0.0
x_max = wall_x + 2*abs(u0) + 2.5
fig, ax = plt.subplots(figsize=(8,4),facecolor="#1a1a2e")
ax.set_facecolor("#16213e"); ax.set_xlim(wall_x-0.3,x_max); ax.set_ylim(-1.0,1.0)
ax.set_aspect("equal"); ax.axis("off")
ax.axhline(track_y-block_h/2,color="#4a4e69",lw=1.5,zorder=1)
ax.add_patch(patches.Rectangle((wall_x-0.2,-0.6),0.2,1.2,
    facecolor="#4a4e69",edgecolor="#adb5bd",lw=1,hatch="////"))
ax.axvline(0,color="#4a4e69",lw=0.8,ls="--",alpha=0.5,zorder=1)
sp, = ax.plot([],[],"-",color="#a8dadc",lw=2.5,zorder=3)
bp  = patches.FancyBboxPatch((-block_w/2,track_y-block_h/2),block_w,block_h,
    boxstyle="round,pad=0.02",lw=1.5,edgecolor="white",facecolor="#e63946")
ax.add_patch(bp)

def spring_path_fn(x1,x2,n=8,r=0.15):
    t=np.linspace(0,1,n*20+2)
    env=np.where((t<0.08)|(t>0.92),0,np.sin(n*2*np.pi*(t-0.08)/(1-2*0.08)))
    return x1+t*(x2-x1), track_y+r*env

def update(f):
    bx=u_arr[f]; bp.set_x(bx-block_w/2)
    sx,sy=spring_path_fn(wall_x,bx-block_w/2); sp.set_data(sx,sy)
    return (sp,)

ani=animation.FuncAnimation(fig,update,frames=len(sol.t),interval=1000/fps,blit=False)
ani.save("single_spring.mp4",writer=animation.FFMpegWriter(fps=fps,bitrate=1800),dpi=120)
plt.close(); print("Saved single_spring.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Single Spring-Mass-Damper")
    parser.add_argument("--k",  type=float, default=3.0)
    parser.add_argument("--m",  type=float, default=0.5)
    parser.add_argument("--b",  type=float, default=0.1)
    parser.add_argument("--u0", type=float, default=1.5)
    parser.add_argument("--v0", type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output",   type=str,   default="single_spring.mp4")
    args = parser.parse_args()
    p = SingleSpringParams(k=args.k, m=args.m, b=args.b, u0=args.u0, v0=args.v0)
    print(f"Simulating single spring: {asdict(p)}")
    omega0 = natural_frequency(p)
    zeta   = damping_ratio(p)
    print(f"  ω₀ = {omega0:.3f} rad/s,  ζ = {zeta:.3f}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
