"""
Two conveyor belt drop - 8-phase closed-form analytic chain.
Cube falls onto belt 1, slips and rides, falls onto belt 2 (opposite direction),
slips and rides, falls to floor, slides to rest.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle, Circle, Polygon
from matplotlib.collections import LineCollection
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class TwoConveyorDropParams:
    g: float = 9.81
    v_belt1: float = 1.20
    v_belt2: float = -0.80
    mu_belt1: float = 0.30
    mu_belt2: float = 0.30
    mu_floor: float = 0.30
    x_b1_left: float = 0.30
    x_b1_right: float = 1.50
    y_b1_top: float = 1.50
    x_b2_left: float = 1.65
    x_b2_right: float = 2.85
    y_b2_top: float = 0.80
    r_pulley: float = 0.06
    cube_size: float = 0.18
    x_drop: float = 0.55
    y_drop_top: float = 2.05


def _build(p: TwoConveyorDropParams):
    g = p.g
    fall_dist_1 = (p.y_drop_top - p.cube_size) - p.y_b1_top
    fall_dist_1 = max(fall_dist_1, 0.05)
    t1_dur = np.sqrt(2.0 * fall_dist_1 / g)
    a_belt1 = p.mu_belt1 * g
    t2_dur = p.v_belt1 / a_belt1 if a_belt1 > 0 else 0
    dx2 = 0.5 * a_belt1 * t2_dur ** 2
    x_phase3_start = p.x_drop + dx2
    t3_dur = max(0.0, (p.x_b1_right - x_phase3_start) / p.v_belt1) if p.v_belt1 > 0 else 0
    fall_dist_4 = max(p.y_b1_top - p.y_b2_top, 0.05)
    t4_dur = np.sqrt(2.0 * fall_dist_4 / g)
    dx4 = p.v_belt1 * t4_dur
    v_relative = p.v_belt1 - p.v_belt2
    a_belt2 = -p.mu_belt2 * g
    t5_dur = v_relative / (p.mu_belt2 * g) if p.mu_belt2 > 0 else 0
    dx5 = p.v_belt1 * t5_dur + 0.5 * a_belt2 * t5_dur ** 2
    x_phase6_start = p.x_b1_right + dx4 + dx5
    t6_dur = max(0.0, (x_phase6_start - p.x_b2_left) / abs(p.v_belt2)) if abs(p.v_belt2) > 0 else 0
    fall_dist_7 = max(p.y_b2_top, 0.05)
    t7_dur = np.sqrt(2.0 * fall_dist_7 / g)
    dx7 = p.v_belt2 * t7_dur
    a_floor = p.mu_floor * g
    t8_dur = abs(p.v_belt2) / a_floor if a_floor > 0 else 0
    dx8 = -p.v_belt2 ** 2 / (2.0 * a_floor) if a_floor > 0 else 0
    info = dict(
        t1_dur=t1_dur, a_belt1=a_belt1, t2_dur=t2_dur, dx2=dx2,
        x_phase3_start=x_phase3_start, t3_dur=t3_dur, t4_dur=t4_dur, dx4=dx4,
        a_belt2=a_belt2, t5_dur=t5_dur, dx5=dx5,
        x_phase6_start=x_phase6_start, t6_dur=t6_dur, t7_dur=t7_dur, dx7=dx7,
        a_floor=a_floor, t8_dur=t8_dur, dx8=dx8,
    )
    info["t1_end"] = info["t1_dur"]
    info["t2_end"] = info["t1_end"] + info["t2_dur"]
    info["t3_end"] = info["t2_end"] + info["t3_dur"]
    info["t4_end"] = info["t3_end"] + info["t4_dur"]
    info["t5_end"] = info["t4_end"] + info["t5_dur"]
    info["t6_end"] = info["t5_end"] + info["t6_dur"]
    info["t7_end"] = info["t6_end"] + info["t7_dur"]
    info["t8_end"] = info["t7_end"] + info["t8_dur"]
    return info


def _cube_com(t, p, info):
    g = p.g
    if t <= info["t1_end"]:
        return (p.x_drop, (p.y_drop_top - p.cube_size / 2) - 0.5 * g * t * t)
    if t <= info["t2_end"]:
        dt = t - info["t1_end"]
        return (p.x_drop + 0.5 * info["a_belt1"] * dt * dt, p.y_b1_top + p.cube_size / 2)
    if t <= info["t3_end"]:
        dt = t - info["t2_end"]
        return (info["x_phase3_start"] + p.v_belt1 * dt, p.y_b1_top + p.cube_size / 2)
    if t <= info["t4_end"]:
        dt = t - info["t3_end"]
        return (p.x_b1_right + p.v_belt1 * dt, (p.y_b1_top + p.cube_size / 2) - 0.5 * g * dt * dt)
    if t <= info["t5_end"]:
        dt = t - info["t4_end"]
        return (p.x_b1_right + info["dx4"] + p.v_belt1 * dt + 0.5 * info["a_belt2"] * dt * dt,
                p.y_b2_top + p.cube_size / 2)
    if t <= info["t6_end"]:
        dt = t - info["t5_end"]
        return (info["x_phase6_start"] + p.v_belt2 * dt, p.y_b2_top + p.cube_size / 2)
    if t <= info["t7_end"]:
        dt = t - info["t6_end"]
        return (p.x_b2_left + p.v_belt2 * dt, (p.y_b2_top + p.cube_size / 2) - 0.5 * g * dt * dt)
    if t <= info["t8_end"]:
        dt = t - info["t7_end"]
        vx0 = p.v_belt2
        return (p.x_b2_left + info["dx7"] + vx0 * dt + 0.5 * info["a_floor"] * dt * dt, p.cube_size / 2)
    return (p.x_b2_left + info["dx7"] + info["dx8"], p.cube_size / 2)


def simulate(params: TwoConveyorDropParams, duration: float = 5.0, fps: int = 30):
    info = _build(params)
    duration = max(duration, info["t8_end"] + 0.3)
    n = int(duration * fps) + 1
    t_eval = np.linspace(0.0, duration, n)
    y = np.zeros((2, n))
    for i, t in enumerate(t_eval):
        x, yc = _cube_com(t, params, info)
        y[0, i] = x; y[1, i] = yc
    return t_eval, y


def render_video(t, y, params: TwoConveyorDropParams, output_path: str, fps: int = 30):
    p = params
    fig_w, fig_h = 12.0, 7.0
    fig_aspect = fig_w / fig_h
    x_lo_d = -0.10
    x_hi_d = p.x_b2_right + 0.30
    y_lo_d = -0.25
    y_hi_d = p.y_drop_top + 0.20
    dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_d / dy_d < fig_aspect:
        extra = (fig_aspect * dy_d - dx_d) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx_d / fig_aspect - dy_d) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    ax.add_patch(Polygon([(x_lo, y_lo), (x_hi, y_lo), (x_hi, 0.0), (x_lo, 0.0)],
                         facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.plot([x_lo, x_hi], [0.0, 0.0], color="#adb5bd", lw=2.0, zorder=1)

    def draw_belt(x_left, x_right, y_top):
        yp = y_top - p.r_pulley
        ax.plot([x_left, x_right], [y_top, y_top], color="#4a4e69", lw=10, solid_capstyle="butt", zorder=2)
        ax.plot([x_left, x_right], [y_top - 2 * p.r_pulley, y_top - 2 * p.r_pulley],
                color="#4a4e69", lw=10, solid_capstyle="butt", zorder=2)
        ax.add_patch(Circle((x_left, yp), p.r_pulley, facecolor="#3a4357", edgecolor="#adb5bd", lw=1.2, zorder=3))
        ax.add_patch(Circle((x_right, yp), p.r_pulley, facecolor="#3a4357", edgecolor="#adb5bd", lw=1.2, zorder=3))

    draw_belt(p.x_b1_left, p.x_b1_right, p.y_b1_top)
    draw_belt(p.x_b2_left, p.x_b2_right, p.y_b2_top)

    hash_lc1 = LineCollection([], colors="#adb5bd", linewidths=2.0, zorder=4)
    hash_lc2 = LineCollection([], colors="#adb5bd", linewidths=2.0, zorder=4)
    ax.add_collection(hash_lc1); ax.add_collection(hash_lc2)
    cube_patch = Rectangle((0, 0), p.cube_size, p.cube_size,
                           facecolor="#e63946", edgecolor="#adb5bd", lw=1.2, zorder=5)
    ax.add_patch(cube_patch)

    hash_spacing = 0.10; hash_w = 0.022

    def hash_segments(x_left, x_right, y_top, v, t_):
        s0_top = (v * t_) % hash_spacing
        n_marks = int(np.ceil((x_right - x_left) / hash_spacing)) + 2
        segs = []
        for k in range(n_marks):
            x_m = x_left + s0_top + k * hash_spacing
            if x_left <= x_m <= x_right:
                segs.append([(x_m, y_top - hash_w), (x_m, y_top + hash_w)])
        s0_bot = (-v * t_) % hash_spacing
        y_b = y_top - 2 * p.r_pulley
        for k in range(n_marks):
            x_m = x_left + s0_bot + k * hash_spacing
            if x_left <= x_m <= x_right:
                segs.append([(x_m, y_b - hash_w), (x_m, y_b + hash_w)])
        return segs

    def update(f):
        cx, cy = y[0, f], y[1, f]
        cube_patch.set_xy((cx - p.cube_size / 2, cy - p.cube_size / 2))
        t_ = t[f]
        hash_lc1.set_segments(hash_segments(p.x_b1_left, p.x_b1_right, p.y_b1_top, p.v_belt1, t_))
        hash_lc2.set_segments(hash_segments(p.x_b2_left, p.x_b2_right, p.y_b2_top, p.v_belt2, t_))
        return cube_patch, hash_lc1, hash_lc2

    ani = animation.FuncAnimation(fig, update, frames=len(t), interval=1000.0 / fps, blit=False)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: TwoConveyorDropParams, duration: float = 5.0) -> str:
    p = asdict(params)
    return f'''"""Two conveyor drop - auto-generated."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle, Circle, Polygon
from matplotlib.collections import LineCollection

g={p["g"]}; v_belt1={p["v_belt1"]}; v_belt2={p["v_belt2"]}
mu_belt1={p["mu_belt1"]}; mu_belt2={p["mu_belt2"]}; mu_floor={p["mu_floor"]}
x_b1_left={p["x_b1_left"]}; x_b1_right={p["x_b1_right"]}; y_b1_top={p["y_b1_top"]}
x_b2_left={p["x_b2_left"]}; x_b2_right={p["x_b2_right"]}; y_b2_top={p["y_b2_top"]}
r_pulley={p["r_pulley"]}; cube_size={p["cube_size"]}
x_drop={p["x_drop"]}; y_drop_top={p["y_drop_top"]}
fps=30

fall_dist_1=max((y_drop_top-cube_size)-y_b1_top,0.05)
t1_dur=np.sqrt(2.0*fall_dist_1/g)
a_belt1=mu_belt1*g
t2_dur=v_belt1/a_belt1 if a_belt1>0 else 0
dx2=0.5*a_belt1*t2_dur**2
x_phase3_start=x_drop+dx2
t3_dur=max(0.0,(x_b1_right-x_phase3_start)/v_belt1) if v_belt1>0 else 0
fall_dist_4=max(y_b1_top-y_b2_top,0.05)
t4_dur=np.sqrt(2.0*fall_dist_4/g); dx4=v_belt1*t4_dur
v_relative=v_belt1-v_belt2
a_belt2=-mu_belt2*g
t5_dur=v_relative/(mu_belt2*g) if mu_belt2>0 else 0
dx5=v_belt1*t5_dur+0.5*a_belt2*t5_dur**2
x_phase6_start=x_b1_right+dx4+dx5
t6_dur=max(0.0,(x_phase6_start-x_b2_left)/abs(v_belt2)) if abs(v_belt2)>0 else 0
fall_dist_7=max(y_b2_top,0.05)
t7_dur=np.sqrt(2.0*fall_dist_7/g); dx7=v_belt2*t7_dur
a_floor=mu_floor*g
t8_dur=abs(v_belt2)/a_floor if a_floor>0 else 0
dx8=-v_belt2**2/(2.0*a_floor) if a_floor>0 else 0
t1_end=t1_dur; t2_end=t1_end+t2_dur; t3_end=t2_end+t3_dur
t4_end=t3_end+t4_dur; t5_end=t4_end+t5_dur; t6_end=t5_end+t6_dur
t7_end=t6_end+t7_dur; t8_end=t7_end+t8_dur
duration=max({duration},t8_end+0.3)

def cube_com(t):
    if t<=t1_end:
        return (x_drop,(y_drop_top-cube_size/2)-0.5*g*t*t)
    if t<=t2_end:
        dt=t-t1_end; return (x_drop+0.5*a_belt1*dt*dt,y_b1_top+cube_size/2)
    if t<=t3_end:
        dt=t-t2_end; return (x_phase3_start+v_belt1*dt,y_b1_top+cube_size/2)
    if t<=t4_end:
        dt=t-t3_end; return (x_b1_right+v_belt1*dt,(y_b1_top+cube_size/2)-0.5*g*dt*dt)
    if t<=t5_end:
        dt=t-t4_end; return (x_b1_right+dx4+v_belt1*dt+0.5*a_belt2*dt*dt,y_b2_top+cube_size/2)
    if t<=t6_end:
        dt=t-t5_end; return (x_phase6_start+v_belt2*dt,y_b2_top+cube_size/2)
    if t<=t7_end:
        dt=t-t6_end; return (x_b2_left+v_belt2*dt,(y_b2_top+cube_size/2)-0.5*g*dt*dt)
    if t<=t8_end:
        dt=t-t7_end; return (x_b2_left+dx7+v_belt2*dt+0.5*a_floor*dt*dt,cube_size/2)
    return (x_b2_left+dx7+dx8,cube_size/2)

fig_w,fig_h=12.0,7.0; fa=fig_w/fig_h
x_lo_d=-0.10; x_hi_d=x_b2_right+0.30; y_lo_d=-0.25; y_hi_d=y_drop_top+0.20
dx_d,dy_d=x_hi_d-x_lo_d,y_hi_d-y_lo_d
if dx_d/dy_d<fa:
    e=(fa*dy_d-dx_d)/2.0; x_lo,x_hi=x_lo_d-e,x_hi_d+e; y_lo,y_hi=y_lo_d,y_hi_d
else:
    e=(dx_d/fa-dy_d)/2.0; x_lo,x_hi=x_lo_d,x_hi_d; y_lo,y_hi=y_lo_d-e,y_hi_d+e

fig=plt.figure(figsize=(fig_w,fig_h),facecolor="#1a1a2e")
ax=fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi); ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(Polygon([(x_lo,y_lo),(x_hi,y_lo),(x_hi,0.0),(x_lo,0.0)],
                     facecolor="#4a4e69",edgecolor="none",zorder=0))
ax.plot([x_lo,x_hi],[0.0,0.0],color="#adb5bd",lw=2.0,zorder=1)

def draw_belt(xl,xr,yt):
    yp=yt-r_pulley
    ax.plot([xl,xr],[yt,yt],color="#4a4e69",lw=10,solid_capstyle="butt",zorder=2)
    ax.plot([xl,xr],[yt-2*r_pulley,yt-2*r_pulley],color="#4a4e69",lw=10,solid_capstyle="butt",zorder=2)
    ax.add_patch(Circle((xl,yp),r_pulley,facecolor="#3a4357",edgecolor="#adb5bd",lw=1.2,zorder=3))
    ax.add_patch(Circle((xr,yp),r_pulley,facecolor="#3a4357",edgecolor="#adb5bd",lw=1.2,zorder=3))

draw_belt(x_b1_left,x_b1_right,y_b1_top)
draw_belt(x_b2_left,x_b2_right,y_b2_top)

hash_lc1=LineCollection([],colors="#adb5bd",linewidths=2.0,zorder=4)
hash_lc2=LineCollection([],colors="#adb5bd",linewidths=2.0,zorder=4)
ax.add_collection(hash_lc1); ax.add_collection(hash_lc2)
cube_patch=Rectangle((0,0),cube_size,cube_size,facecolor="#e63946",edgecolor="#adb5bd",lw=1.2,zorder=5)
ax.add_patch(cube_patch)
hash_spacing=0.10; hash_w=0.022

def hash_segments(xl,xr,yt,v,t_):
    s0=(v*t_)%hash_spacing
    n=int(np.ceil((xr-xl)/hash_spacing))+2
    segs=[]
    for k in range(n):
        xm=xl+s0+k*hash_spacing
        if xl<=xm<=xr:
            segs.append([(xm,yt-hash_w),(xm,yt+hash_w)])
    s0b=(-v*t_)%hash_spacing
    yb=yt-2*r_pulley
    for k in range(n):
        xm=xl+s0b+k*hash_spacing
        if xl<=xm<=xr:
            segs.append([(xm,yb-hash_w),(xm,yb+hash_w)])
    return segs

def update(f):
    t_=f/fps
    cx,cy=cube_com(t_)
    cube_patch.set_xy((cx-cube_size/2,cy-cube_size/2))
    hash_lc1.set_segments(hash_segments(x_b1_left,x_b1_right,y_b1_top,v_belt1,t_))
    hash_lc2.set_segments(hash_segments(x_b2_left,x_b2_right,y_b2_top,v_belt2,t_))
    return cube_patch,hash_lc1,hash_lc2

n_frames=int(duration*fps)+1
ani=animation.FuncAnimation(fig,update,frames=n_frames,interval=1000.0/fps,blit=False)
ani.save("video.mp4",writer=animation.FFMpegWriter(fps=fps,bitrate=1800),dpi=120)
plt.close(); print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    for fld, dflt in asdict(TwoConveyorDropParams()).items():
        parser.add_argument(f"--{fld}", type=float, default=dflt)
    parser.add_argument("--duration", type=float, default=5.0)
    parser.add_argument("--output", type=str, default="video.mp4")
    args = parser.parse_args()
    p = TwoConveyorDropParams(**{k: getattr(args, k) for k in asdict(TwoConveyorDropParams()).keys()})
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
