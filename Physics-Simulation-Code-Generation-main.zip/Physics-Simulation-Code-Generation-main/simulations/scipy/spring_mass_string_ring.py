"""
Spring-Mass Driven String + Ring (Free End)
============================================
A vertical Hookean spring hangs from the ceiling; a cubical mass attached at
the spring's free end performs SHM about its gravitational equilibrium.  Its
motion drives the left end of a horizontal string that runs to a frictionless
ring on a vertical rod (free, Neumann BC).
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Circle, Rectangle, Arc
from dataclasses import dataclass, asdict


@dataclass
class SpringMassStringRingParams:
    g: float = 9.81
    m_mass: float = 0.30
    k_spring: float = 30.0
    L: float = 4.0
    mu: float = 0.10
    T_str: float = 4.0
    gamma_w: float = 1.0
    tau_ramp: float = 0.40
    H_mass: float = 0.20
    W_mass: float = 0.20
    L_spring_rest: float = 0.50


def simulate(
    params: SpringMassStringRingParams,
    duration: float = 8.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Hybrid: analytic SHM for the spring-mass + leapfrog FDM for the wave eqn.
    Returns (t_eval, U) where U.shape = (N+1, n_frames) and the first row is the driver.
    """
    g = params.g
    m_mass = params.m_mass
    k_spring = params.k_spring
    L = params.L
    mu = params.mu
    T_str = params.T_str
    gamma_w = params.gamma_w
    tau_ramp = params.tau_ramp

    DeltaL_eq = m_mass * g / k_spring
    omega_spring = np.sqrt(k_spring / m_mass)
    c = np.sqrt(T_str / mu)

    N = 200
    dx = L / N
    n_per_frame = 16
    dt = 1.0 / (fps * n_per_frame)
    factor = (c * dt / dx) ** 2
    if factor >= 1.0:
        # Increase n_per_frame
        n_per_frame = int(np.ceil(c / (fps * dx))) + 4
        dt = 1.0 / (fps * n_per_frame)
        factor = (c * dt / dx) ** 2
    damp_n = 1.0 / (1.0 + gamma_w * dt)
    damp_p = 1.0 - gamma_w * dt

    u_curr = np.zeros(N + 1)
    u_prev = u_curr.copy()
    n_frames = int(duration * fps) + 1
    U_frames = np.zeros((N + 1, n_frames))
    U_frames[:, 0] = u_curr

    def y_mass_at(t):
        return DeltaL_eq * np.cos(omega_spring * t)

    def ramp(t):
        return 1.0 - np.exp(-t / tau_ramp)

    for frame in range(1, n_frames):
        for sub in range(n_per_frame):
            t_curr = (frame - 1) / fps + (sub + 1) * dt
            u_next = np.empty_like(u_curr)
            lap_int = u_curr[2:] - 2 * u_curr[1:-1] + u_curr[:-2]
            u_next[1:-1] = damp_n * (2 * u_curr[1:-1] - damp_p * u_prev[1:-1]
                                     + factor * lap_int)
            lap_right = 2 * (u_curr[-2] - u_curr[-1])
            u_next[-1] = damp_n * (2 * u_curr[-1] - damp_p * u_prev[-1]
                                   + factor * lap_right)
            u_next[0] = ramp(t_curr) * y_mass_at(t_curr)
            u_prev, u_curr = u_curr, u_next
        U_frames[:, frame] = u_curr

    t_eval = np.linspace(0, duration, n_frames)
    return t_eval, U_frames


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: SpringMassStringRingParams,
    output_path: str,
    fps: int = 30,
) -> None:
    g = params.g
    m_mass = params.m_mass
    k_spring = params.k_spring
    L = params.L
    H_mass = params.H_mass
    W_mass = params.W_mass
    L_spring_rest = params.L_spring_rest

    DeltaL_eq = m_mass * g / k_spring
    omega_spring = np.sqrt(k_spring / m_mass)

    N = y.shape[0] - 1
    dx = L / N
    x_grid = np.linspace(0.0, L, N + 1)
    n_frames = y.shape[1]

    y_string_eq = 0.0
    y_mass_eq = y_string_eq
    y_ceiling = L_spring_rest + DeltaL_eq + H_mass / 2 + y_mass_eq
    x_mass_c = -W_mass / 2

    def y_mass_at(t):
        return y_mass_eq + DeltaL_eq * np.cos(omega_spring * t)

    fig_w, fig_h = 12.0, 4.5
    fig_aspect = fig_w / fig_h
    x_lo_d = x_mass_c - W_mass / 2 - 0.20
    x_hi_d = L + 0.40
    y_lo_d = -4.5 * DeltaL_eq - 0.10
    y_hi_d = y_ceiling + 0.10
    dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_d / dy_d < fig_aspect:
        extra = (fig_aspect * dy_d - dx_d) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx_d / fig_aspect - dy_d) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi)
    ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal")
    ax.axis("off")
    ax.axhline(y_string_eq, color="#3a4357", lw=1, ls="--", zorder=0)
    ax.add_patch(Rectangle((x_lo, y_ceiling), x_hi - x_lo, y_hi - y_ceiling,
                           facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.plot([x_lo, x_hi], [y_ceiling, y_ceiling], color="#adb5bd", lw=2.0, zorder=1)

    spring_line, = ax.plot([], [], color="#a8dadc", lw=2.0, zorder=3)

    mass_patch = Rectangle((x_mass_c - W_mass / 2, y_mass_at(0.0) - H_mass / 2),
                           W_mass, H_mass,
                           facecolor="#e63946", edgecolor="#adb5bd", lw=1.0, zorder=4)
    ax.add_patch(mass_patch)

    r_x, r_y = 0.22, 0.11
    back_arc = Arc((L, 0), 2 * r_x, 2 * r_y, theta1=0, theta2=180,
                   edgecolor="#e63946", lw=10, zorder=2)
    ax.add_patch(back_arc)
    ax.plot([L, L], [y_lo, y_hi], color="#adb5bd", lw=14,
            solid_capstyle="butt", zorder=3)
    front_arc = Arc((L, 0), 2 * r_x, 2 * r_y, theta1=180, theta2=360,
                    edgecolor="#e63946", lw=10, zorder=5)
    ax.add_patch(front_arc)

    n_cut = int(round(r_x / dx))
    n_inside = (N + 1) - n_cut
    str_x_plot = x_grid[:n_inside]
    str_line, = ax.plot([], [], color="#a8dadc", lw=2.4, zorder=4)

    def coil_xy(p_top, p_bot, n_coils=10, w=0.04, n_pts=80):
        x1, y1 = p_top
        x2, y2 = p_bot
        dx_v, dy_v = x2 - x1, y2 - y1
        Lc = np.hypot(dx_v, dy_v)
        if Lc < 1e-9:
            return np.array([x1, x2]), np.array([y1, y2])
        ux, uy = dx_v / Lc, dy_v / Lc
        nx, ny = -uy, ux
        s = np.linspace(0.0, 1.0, n_pts)
        lead = 0.06
        arc = s * Lc
        middle = (arc >= lead) & (arc <= Lc - lead)
        amp = np.where(middle,
                       w * np.sin(2 * np.pi * n_coils * (arc - lead) / max(Lc - 2 * lead, 1e-6)),
                       0.0)
        xs = x1 + ux * arc + nx * amp
        ys = y1 + uy * arc + ny * amp
        return xs, ys

    def update(f):
        t_now = f / fps
        y_m = y_mass_at(t_now)
        mass_patch.set_xy((x_mass_c - W_mass / 2, y_m - H_mass / 2))
        xs_s, ys_s = coil_xy((x_mass_c, y_ceiling), (x_mass_c, y_m + H_mass / 2))
        spring_line.set_data(xs_s, ys_s)

        u = y[:, f]
        yy = u[-1]
        str_y = u[:n_inside].copy()
        str_y[-1] = yy
        str_line.set_data(str_x_plot, str_y)
        back_arc.set_center((L, yy))
        front_arc.set_center((L, yy))
        return mass_patch, spring_line, str_line, back_arc, front_arc

    ani = animation.FuncAnimation(fig, update, frames=n_frames,
                                  interval=1000.0 / fps, blit=False)
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: SpringMassStringRingParams, duration: float = 8.0) -> str:
    p = asdict(params)
    return f'''"""Spring-Mass Driven String + Ring — auto-generated."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Circle, Rectangle, Arc

g = {p["g"]}
m_mass = {p["m_mass"]}
k_spring = {p["k_spring"]}
L = {p["L"]}
mu = {p["mu"]}
T_str = {p["T_str"]}
gamma_w = {p["gamma_w"]}
tau_ramp = {p["tau_ramp"]}
H_mass = {p["H_mass"]}
W_mass = {p["W_mass"]}
L_spring_rest = {p["L_spring_rest"]}
duration = {duration}
fps = 30

DeltaL_eq = m_mass * g / k_spring
omega_spring = np.sqrt(k_spring / m_mass)
c = np.sqrt(T_str / mu)

y_string_eq = 0.0
y_mass_eq = y_string_eq
y_ceiling = L_spring_rest + DeltaL_eq + H_mass / 2 + y_mass_eq
x_mass_c = -W_mass / 2

def y_mass_at(t):
    return y_mass_eq + DeltaL_eq * np.cos(omega_spring * t)

def ramp(t):
    return 1.0 - np.exp(-t / tau_ramp)

N = 200
dx = L / N
x_grid = np.linspace(0.0, L, N + 1)
n_per_frame = 16
dt = 1.0 / (fps * n_per_frame)
factor = (c * dt / dx) ** 2
if factor >= 1.0:
    n_per_frame = int(np.ceil(c / (fps * dx))) + 4
    dt = 1.0 / (fps * n_per_frame)
    factor = (c * dt / dx) ** 2
damp_n = 1.0 / (1.0 + gamma_w * dt)
damp_p = 1.0 - gamma_w * dt

u_curr = np.zeros(N + 1)
u_prev = u_curr.copy()
n_frames = int(duration * fps) + 1
U_frames = np.zeros((n_frames, N + 1))
U_frames[0] = u_curr.copy()

for frame in range(1, n_frames):
    for sub in range(n_per_frame):
        t_curr = (frame - 1) / fps + (sub + 1) * dt
        u_next = np.empty_like(u_curr)
        lap_int = u_curr[2:] - 2 * u_curr[1:-1] + u_curr[:-2]
        u_next[1:-1] = damp_n * (2 * u_curr[1:-1] - damp_p * u_prev[1:-1] + factor * lap_int)
        lap_right = 2 * (u_curr[-2] - u_curr[-1])
        u_next[-1] = damp_n * (2 * u_curr[-1] - damp_p * u_prev[-1] + factor * lap_right)
        u_next[0] = ramp(t_curr) * (y_mass_at(t_curr) - y_string_eq)
        u_prev, u_curr = u_curr, u_next
    U_frames[frame] = u_curr.copy()

def coil_xy(p_top, p_bot, n_coils=10, w=0.04, n_pts=80):
    x1, y1 = p_top; x2, y2 = p_bot
    dx_v, dy_v = x2 - x1, y2 - y1
    Lc = np.hypot(dx_v, dy_v)
    if Lc < 1e-9:
        return np.array([x1, x2]), np.array([y1, y2])
    ux, uy = dx_v / Lc, dy_v / Lc
    nx, ny = -uy, ux
    s = np.linspace(0.0, 1.0, n_pts)
    lead = 0.06
    arc = s * Lc
    middle = (arc >= lead) & (arc <= Lc - lead)
    amp = np.where(middle, w * np.sin(2*np.pi*n_coils*(arc-lead)/max(Lc-2*lead,1e-6)), 0.0)
    xs = x1 + ux*arc + nx*amp
    ys = y1 + uy*arc + ny*amp
    return xs, ys

fig_w, fig_h = 12.0, 4.5
fig_aspect = fig_w / fig_h
x_lo_d = x_mass_c - W_mass/2 - 0.20
x_hi_d = L + 0.40
y_lo_d = -4.5*DeltaL_eq - 0.10
y_hi_d = y_ceiling + 0.10
dx_d, dy_d = x_hi_d-x_lo_d, y_hi_d-y_lo_d
if dx_d/dy_d < fig_aspect:
    extra = (fig_aspect*dy_d - dx_d)/2.0
    x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
    y_lo, y_hi = y_lo_d, y_hi_d
else:
    extra = (dx_d/fig_aspect - dy_d)/2.0
    x_lo, x_hi = x_lo_d, x_hi_d
    y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.axhline(y_string_eq, color="#3a4357", lw=1, ls="--", zorder=0)
ax.add_patch(Rectangle((x_lo, y_ceiling), x_hi - x_lo, y_hi - y_ceiling, facecolor="#4a4e69", edgecolor="none", zorder=0))
ax.plot([x_lo, x_hi], [y_ceiling, y_ceiling], color="#adb5bd", lw=2.0, zorder=1)
spring_line, = ax.plot([], [], color="#a8dadc", lw=2.0, zorder=3)
mass_patch = Rectangle((x_mass_c - W_mass/2, y_mass_at(0.0)-H_mass/2), W_mass, H_mass, facecolor="#e63946", edgecolor="#adb5bd", lw=1.0, zorder=4)
ax.add_patch(mass_patch)
r_x, r_y = 0.22, 0.11
back_arc = Arc((L, 0), 2*r_x, 2*r_y, theta1=0, theta2=180, edgecolor="#e63946", lw=10, zorder=2)
ax.add_patch(back_arc)
ax.plot([L, L], [y_lo, y_hi], color="#adb5bd", lw=14, solid_capstyle="butt", zorder=3)
front_arc = Arc((L, 0), 2*r_x, 2*r_y, theta1=180, theta2=360, edgecolor="#e63946", lw=10, zorder=5)
ax.add_patch(front_arc)
n_cut = int(round(r_x/dx))
n_inside = (N+1) - n_cut
str_x_plot = x_grid[:n_inside]
str_line, = ax.plot([], [], color="#a8dadc", lw=2.4, zorder=4)

def update(f):
    t = f / fps
    y_m = y_mass_at(t)
    mass_patch.set_xy((x_mass_c - W_mass/2, y_m - H_mass/2))
    xs_s, ys_s = coil_xy((x_mass_c, y_ceiling), (x_mass_c, y_m + H_mass/2))
    spring_line.set_data(xs_s, ys_s)
    u = U_frames[f]
    yy = u[-1]
    str_y = u[:n_inside].copy()
    str_y[-1] = yy
    str_line.set_data(str_x_plot, str_y)
    back_arc.set_center((L, yy))
    front_arc.set_center((L, yy))
    return mass_patch, spring_line, str_line, back_arc, front_arc

ani = animation.FuncAnimation(fig, update, frames=n_frames, interval=1000.0/fps, blit=False)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Spring-Mass-String-Ring")
    parser.add_argument("--g", type=float, default=9.81)
    parser.add_argument("--m_mass", type=float, default=0.30)
    parser.add_argument("--k_spring", type=float, default=30.0)
    parser.add_argument("--L", type=float, default=4.0)
    parser.add_argument("--mu", type=float, default=0.10)
    parser.add_argument("--T_str", type=float, default=4.0)
    parser.add_argument("--gamma_w", type=float, default=1.0)
    parser.add_argument("--tau_ramp", type=float, default=0.40)
    parser.add_argument("--H_mass", type=float, default=0.20)
    parser.add_argument("--W_mass", type=float, default=0.20)
    parser.add_argument("--L_spring_rest", type=float, default=0.50)
    parser.add_argument("--duration", type=float, default=8.0)
    parser.add_argument("--output", type=str, default="spring_mass_string_ring.mp4")
    args = parser.parse_args()
    p = SpringMassStringRingParams(
        g=args.g, m_mass=args.m_mass, k_spring=args.k_spring, L=args.L, mu=args.mu,
        T_str=args.T_str, gamma_w=args.gamma_w, tau_ramp=args.tau_ramp,
        H_mass=args.H_mass, W_mass=args.W_mass, L_spring_rest=args.L_spring_rest,
    )
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
