"""
Wedge-Block - movable wedge on friction floor, sliding block on slope.
Phase 1: Lagrangian-derived 2x2 linear system for accelerations.
Tip phase: kinematic linear angle interpolation.
Phase 2: independent floor friction decel for both bodies.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class WedgeBlockParams:
    alpha_deg: float = 30.0
    L_wedge: float = 2.0
    M_wedge: float = 5.0
    m_block: float = 1.0
    W_block: float = 0.50
    H_block: float = 0.30
    mu_block_slope: float = 0.15
    mu_w: float = 0.02
    mu_floor: float = 0.10
    g: float = 9.81
    dt_tip: float = 0.35


def _state_at_time(t, p, info):
    if t <= info["t_trans"]:
        X_w = info["X_w_0"] + 0.5 * info["a_X_p1"] * t * t
    elif t < info["t_w_stop"]:
        dtw = t - info["t_trans"]
        X_w = info["X_w_trans"] + info["dX_trans"] * dtw + 0.5 * info["a_X_p2"] * dtw * dtw
    else:
        tw = info["t_w_stop"] - info["t_trans"]
        X_w = info["X_w_trans"] + info["dX_trans"] * tw + 0.5 * info["a_X_p2"] * tw * tw

    if t <= info["t_trans"]:
        s = 0.5 * info["a_s_p1"] * t * t
        block = _block_corners_phase1(s, X_w, p, info)
    elif t <= info["t_tip_end"]:
        theta_b = np.deg2rad(p.alpha_deg) * (1.0 - (t - info["t_trans"]) / p.dt_tip)
        B_x = info["B_x_at_trans"] + info["vx_block_trans"] * (t - info["t_trans"])
        block = _block_corners_tip(B_x, theta_b, p)
    else:
        dt_p2 = t - info["t_tip_end"]
        if t < info["t_blk_stop"]:
            CoM_x = info["CoM_x_p2_start"] + info["vx_block_trans"] * dt_p2 + 0.5 * info["a_blk_p2"] * dt_p2 * dt_p2
        else:
            tb = info["t_blk_stop"] - info["t_tip_end"]
            CoM_x = info["CoM_x_p2_start"] + info["vx_block_trans"] * tb + 0.5 * info["a_blk_p2"] * tb * tb
        block = _block_corners_phase2(CoM_x, p)
    return X_w, block


def _block_corners_phase1(s, X_w, p, info):
    apex_x, apex_y = X_w, info["H_wedge"]
    ca, sa = info["ca"], info["sa"]
    corners_slope = [(s, 0.0), (s + p.W_block, 0.0),
                     (s + p.W_block, p.H_block), (s, p.H_block)]
    out = []
    for u, v in corners_slope:
        x = apex_x + u * ca + v * sa
        y = apex_y - u * sa + v * ca
        out.append((x, y))
    return out


def _block_corners_tip(B_x, theta_b, p):
    cb, sb = np.cos(theta_b), np.sin(theta_b)
    A = (B_x - p.W_block * cb, p.W_block * sb)
    B = (B_x, 0.0)
    C = (B_x + p.H_block * sb, p.H_block * cb)
    D = (A[0] + p.H_block * sb, A[1] + p.H_block * cb)
    return [A, B, C, D]


def _block_corners_phase2(CoM_x, p):
    return [(CoM_x - p.W_block / 2, 0.0), (CoM_x + p.W_block / 2, 0.0),
            (CoM_x + p.W_block / 2, p.H_block), (CoM_x - p.W_block / 2, p.H_block)]


def _build(p: WedgeBlockParams):
    alpha = np.deg2rad(p.alpha_deg)
    H_wedge = p.L_wedge * np.tan(alpha)
    ca, sa = np.cos(alpha), np.sin(alpha)
    g = p.g
    N_slope = p.m_block * g * ca
    N_floor = (p.M_wedge + p.m_block) * g
    A_mat = np.array([[(p.M_wedge + p.m_block), p.m_block * ca],
                      [p.m_block * ca, p.m_block]])
    b_vec = np.array([+p.mu_w * N_floor - p.mu_block_slope * N_slope * ca,
                      p.m_block * g * sa - p.mu_block_slope * N_slope])
    a_X_p1, a_s_p1 = np.linalg.solve(A_mat, b_vec)
    L_slope = np.hypot(p.L_wedge, H_wedge)
    s_trans = max(L_slope - p.W_block, 0.05)
    if a_s_p1 <= 0:
        a_s_p1 = 0.5  # fallback
    t_trans = np.sqrt(2.0 * s_trans / a_s_p1)
    X_w_0 = 0.0
    X_w_trans = X_w_0 + 0.5 * a_X_p1 * t_trans * t_trans
    ds_trans = a_s_p1 * t_trans
    dX_trans = a_X_p1 * t_trans
    vx_block_trans = dX_trans + ds_trans * ca
    B_x_at_trans = X_w_trans + p.L_wedge
    t_tip_end = t_trans + p.dt_tip
    B_x_at_tip_end = B_x_at_trans + vx_block_trans * p.dt_tip
    CoM_x_p2_start = B_x_at_tip_end - p.W_block / 2.0
    a_X_p2 = -np.sign(dX_trans) * p.mu_w * g if dX_trans != 0 else 0.0
    a_blk_p2 = -np.sign(vx_block_trans) * p.mu_floor * g if vx_block_trans != 0 else 0.0
    t_w_stop = t_trans + abs(dX_trans) / abs(a_X_p2) if a_X_p2 != 0 else 1e9
    t_blk_stop = t_tip_end + abs(vx_block_trans) / abs(a_blk_p2) if a_blk_p2 != 0 else 1e9
    return dict(
        alpha=alpha, H_wedge=H_wedge, ca=ca, sa=sa,
        a_X_p1=a_X_p1, a_s_p1=a_s_p1, t_trans=t_trans,
        X_w_0=X_w_0, X_w_trans=X_w_trans, dX_trans=dX_trans,
        vx_block_trans=vx_block_trans, B_x_at_trans=B_x_at_trans,
        t_tip_end=t_tip_end, B_x_at_tip_end=B_x_at_tip_end,
        CoM_x_p2_start=CoM_x_p2_start, a_X_p2=a_X_p2, a_blk_p2=a_blk_p2,
        t_w_stop=t_w_stop, t_blk_stop=t_blk_stop,
    )


def simulate(params: WedgeBlockParams, duration: float = 12.0, fps: int = 30):
    info = _build(params)
    n = int(duration * fps) + 1
    t_eval = np.linspace(0.0, duration, n)
    y = np.zeros((9, n))  # X_w + 4 corners (8 vals)
    for i, t in enumerate(t_eval):
        X_w, blk = _state_at_time(t, params, info)
        y[0, i] = X_w
        for k, (cx, cy) in enumerate(blk):
            y[1 + 2 * k, i] = cx
            y[2 + 2 * k, i] = cy
    return t_eval, y


def render_video(t, y, params: WedgeBlockParams, output_path: str, fps: int = 30):
    p = params
    alpha = np.deg2rad(p.alpha_deg)
    H_wedge = p.L_wedge * np.tan(alpha)
    all_xs = []
    for i in range(y.shape[1]):
        all_xs.append(y[0, i]); all_xs.append(y[0, i] + p.L_wedge)
        for k in range(4):
            all_xs.append(y[1 + 2 * k, i])
    all_xs = np.array(all_xs)
    x_lo_d = all_xs.min() - 0.40; x_hi_d = all_xs.max() + 0.40
    y_lo_d = -0.40; y_hi_d = max(H_wedge, p.H_block) + 0.30
    fig_w, fig_h = 13.0, 3.2
    fig_aspect = fig_w / fig_h
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")
    ax.add_patch(Polygon([(x_lo, y_lo), (x_hi, y_lo), (x_hi, 0.0), (x_lo, 0.0)],
                         facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.plot([x_lo, x_hi], [0.0, 0.0], color="#adb5bd", lw=2.0, zorder=1)
    wedge_patch = Polygon([(0, 0), (p.L_wedge, 0), (0, H_wedge)],
                          facecolor="#a8dadc", edgecolor="#adb5bd", lw=1.5, zorder=3)
    ax.add_patch(wedge_patch)
    block_patch = Polygon([(0, 0)] * 4, facecolor="#e63946",
                          edgecolor="#adb5bd", lw=1.0, zorder=4)
    ax.add_patch(block_patch)

    def update(f):
        X_w = y[0, f]
        wedge_patch.set_xy([(X_w, 0.0), (X_w + p.L_wedge, 0.0), (X_w, H_wedge)])
        blk = [(y[1 + 2 * k, f], y[2 + 2 * k, f]) for k in range(4)]
        block_patch.set_xy(blk)
        return wedge_patch, block_patch

    ani = animation.FuncAnimation(fig, update, frames=len(t), interval=1000.0 / fps, blit=False)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: WedgeBlockParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Wedge block - auto-generated."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon

alpha=np.deg2rad({p["alpha_deg"]})
L_wedge={p["L_wedge"]}; H_wedge=L_wedge*np.tan(alpha)
M_wedge={p["M_wedge"]}; m_block={p["m_block"]}
W_block={p["W_block"]}; H_block={p["H_block"]}
mu_block_slope={p["mu_block_slope"]}; mu_w={p["mu_w"]}; mu_floor={p["mu_floor"]}
g={p["g"]}; dt_tip={p["dt_tip"]}
duration={duration}; fps=30
ca,sa=np.cos(alpha),np.sin(alpha)

N_slope=m_block*g*ca; N_floor=(M_wedge+m_block)*g
A_mat=np.array([[(M_wedge+m_block), m_block*ca],
                [m_block*ca, m_block]])
b_vec=np.array([+mu_w*N_floor - mu_block_slope*N_slope*ca,
                m_block*g*sa - mu_block_slope*N_slope])
a_X_p1,a_s_p1=np.linalg.solve(A_mat,b_vec)
L_slope=np.hypot(L_wedge,H_wedge)
s_trans=max(L_slope-W_block,0.05)
if a_s_p1<=0: a_s_p1=0.5
t_trans=np.sqrt(2.0*s_trans/a_s_p1)
X_w_0=0.0
X_w_trans=X_w_0+0.5*a_X_p1*t_trans*t_trans
ds_trans=a_s_p1*t_trans; dX_trans=a_X_p1*t_trans
vx_block_trans=dX_trans+ds_trans*ca
B_x_at_trans=X_w_trans+L_wedge
t_tip_end=t_trans+dt_tip
B_x_at_tip_end=B_x_at_trans+vx_block_trans*dt_tip
CoM_x_p2_start=B_x_at_tip_end-W_block/2.0
a_X_p2 = -np.sign(dX_trans)*mu_w*g if dX_trans!=0 else 0.0
a_blk_p2 = -np.sign(vx_block_trans)*mu_floor*g if vx_block_trans!=0 else 0.0
t_w_stop = t_trans + abs(dX_trans)/abs(a_X_p2) if a_X_p2!=0 else duration+1
t_blk_stop = t_tip_end + abs(vx_block_trans)/abs(a_blk_p2) if a_blk_p2!=0 else duration+1

def block_corners_phase1(s,X_w):
    apex_x,apex_y=X_w,H_wedge
    cs=[(s,0.0),(s+W_block,0.0),(s+W_block,H_block),(s,H_block)]
    out=[]
    for u,v in cs:
        x=apex_x+u*ca+v*sa; y=apex_y-u*sa+v*ca
        out.append((x,y))
    return out
def block_corners_tip(B_x,theta_b):
    cb,sb=np.cos(theta_b),np.sin(theta_b)
    A=(B_x-W_block*cb,W_block*sb); B=(B_x,0.0)
    C=(B_x+H_block*sb,H_block*cb); D=(A[0]+H_block*sb,A[1]+H_block*cb)
    return [A,B,C,D]
def block_corners_phase2(CoM_x):
    return [(CoM_x-W_block/2,0.0),(CoM_x+W_block/2,0.0),
            (CoM_x+W_block/2,H_block),(CoM_x-W_block/2,H_block)]

def state_at_time(t):
    if t<=t_trans: X_w=X_w_0+0.5*a_X_p1*t*t
    elif t<t_w_stop:
        dtw=t-t_trans; X_w=X_w_trans+dX_trans*dtw+0.5*a_X_p2*dtw*dtw
    else:
        tw=t_w_stop-t_trans; X_w=X_w_trans+dX_trans*tw+0.5*a_X_p2*tw*tw
    if t<=t_trans:
        s=0.5*a_s_p1*t*t; block=block_corners_phase1(s,X_w)
    elif t<=t_tip_end:
        theta_b=alpha*(1.0-(t-t_trans)/dt_tip)
        B_x=B_x_at_trans+vx_block_trans*(t-t_trans)
        block=block_corners_tip(B_x,theta_b)
    else:
        dt_p2=t-t_tip_end
        if t<t_blk_stop:
            CoM_x=CoM_x_p2_start+vx_block_trans*dt_p2+0.5*a_blk_p2*dt_p2*dt_p2
        else:
            tb=t_blk_stop-t_tip_end
            CoM_x=CoM_x_p2_start+vx_block_trans*tb+0.5*a_blk_p2*tb*tb
        block=block_corners_phase2(CoM_x)
    return X_w,block

ts_grid=np.linspace(0.0,duration,int(duration*fps)+1)
states=[state_at_time(t) for t in ts_grid]
all_xs=[]
for X_w,blk in states:
    all_xs.append(X_w); all_xs.append(X_w+L_wedge)
    for c in blk: all_xs.append(c[0])
all_xs=np.array(all_xs)
x_lo_d=all_xs.min()-0.40; x_hi_d=all_xs.max()+0.40
y_lo_d=-0.40; y_hi_d=max(H_wedge,H_block)+0.30
fig_w,fig_h=13.0,3.2; fa=fig_w/fig_h
dx,dy=x_hi_d-x_lo_d,y_hi_d-y_lo_d
if dx/dy<fa:
    e=(fa*dy-dx)/2.0; x_lo,x_hi=x_lo_d-e,x_hi_d+e; y_lo,y_hi=y_lo_d,y_hi_d
else:
    e=(dx/fa-dy)/2.0; x_lo,x_hi=x_lo_d,x_hi_d; y_lo,y_hi=y_lo_d-e,y_hi_d+e

fig=plt.figure(figsize=(fig_w,fig_h),facecolor="#1a1a2e")
ax=fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi); ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(Polygon([(x_lo,y_lo),(x_hi,y_lo),(x_hi,0.0),(x_lo,0.0)],
                    facecolor="#4a4e69",edgecolor="none",zorder=0))
ax.plot([x_lo,x_hi],[0.0,0.0],color="#adb5bd",lw=2.0,zorder=1)
wedge_patch=Polygon([(0,0),(L_wedge,0),(0,H_wedge)],facecolor="#a8dadc",edgecolor="#adb5bd",lw=1.5,zorder=3)
ax.add_patch(wedge_patch)
block_patch=Polygon([(0,0)]*4,facecolor="#e63946",edgecolor="#adb5bd",lw=1.0,zorder=4)
ax.add_patch(block_patch)

def update(f):
    t=f/fps
    X_w,blk=state_at_time(t)
    wedge_patch.set_xy([(X_w,0.0),(X_w+L_wedge,0.0),(X_w,H_wedge)])
    block_patch.set_xy(blk)
    return wedge_patch,block_patch

n_frames=len(ts_grid)
ani=animation.FuncAnimation(fig,update,frames=n_frames,interval=1000.0/fps,blit=False)
ani.save("video.mp4",writer=animation.FFMpegWriter(fps=fps,bitrate=1800),dpi=120)
plt.close(); print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    for fld, dflt in asdict(WedgeBlockParams()).items():
        parser.add_argument(f"--{fld}", type=float, default=dflt)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="video.mp4")
    args = parser.parse_args()
    p = WedgeBlockParams(**{k: getattr(args, k) for k in asdict(WedgeBlockParams()).keys()})
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
