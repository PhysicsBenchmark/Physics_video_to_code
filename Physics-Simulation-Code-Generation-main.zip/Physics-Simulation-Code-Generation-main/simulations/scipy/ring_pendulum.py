"""
Ring Pendulum — physical pendulum: a thin uniform hoop hinged on its perimeter.

Dynamics (rigid-body about the hinge):
    I_pivot = 2 M r²
    θ̈ = -(g / 2r) sin θ - (b / I_pivot) θ̇
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis


@dataclass
class RingPendulumParams:
    r: float = 0.6
    M: float = 1.0
    g: float = 9.8
    b: float = 0.04
    theta0: float = 0.5
    omega0: float = 0.0


def ode(t: float, y, p: RingPendulumParams):
    th, om = y
    I_pivot = 2.0 * p.M * p.r * p.r
    return [om, -(p.g / (2.0 * p.r)) * np.sin(th) - (p.b / I_pivot) * om]


def simulate(params: RingPendulumParams, duration: float = 12.0, fps: int = 30):
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(ode, (0, duration), [params.theta0, params.omega0],
                    t_eval=t_eval, args=(params,), method="RK45",
                    rtol=1e-9, atol=1e-11)
    return sol.t, sol.y


def render_video(t, y, params: RingPendulumParams, output_path: str, fps: int = 30):
    theta = y[0]
    r = params.r
    x_h = r + 0.40
    y_h = 0.0
    cx = x_h + r * np.sin(theta)
    cy = y_h - r * np.cos(theta)

    margin = 0.25 * r
    x_lo_d = -0.55 * r
    x_hi_d = (cx.max() + r) + margin
    y_lo_d = (cy.min() - r) - margin
    y_hi_d = y_h + 0.6 * r
    fig_w, fig_h = 6, 6
    fig_aspect = fig_w / fig_h
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h))
    ax = fig.add_axes([0, 0, 1, 1])
    setup_dark_axis(fig, ax, (x_lo, x_hi), (y_lo, y_hi))

    wall = patches.Rectangle((x_lo, y_lo), -x_lo, y_hi - y_lo,
                             facecolor="#4a4e69", edgecolor="none", zorder=0)
    ax.add_patch(wall)
    ax.plot([0, 0], [y_lo, y_hi], color="#adb5bd", lw=2.5, zorder=1)
    bracket = patches.Rectangle((0.0, y_h - 0.05 * r), x_h, 0.10 * r,
                                facecolor="#adb5bd", edgecolor="none", zorder=2)
    ax.add_patch(bracket)
    ring = patches.Wedge((cx[0], cy[0]), r, 0, 360, width=0.05,
                         facecolor="#a8dadc", edgecolor="#adb5bd", lw=1.0, zorder=3)
    ax.add_patch(ring)
    hinge_o = patches.Circle((x_h, y_h), 0.07, facecolor="#e63946",
                             edgecolor="#adb5bd", lw=1.0, zorder=6)
    hinge_i = patches.Circle((x_h, y_h), 0.022, facecolor="#1a1a2e",
                             edgecolor="none", zorder=7)
    ax.add_patch(hinge_o); ax.add_patch(hinge_i)

    def update(f):
        ring.set_center((cx[f], cy[f]))
        return (ring,)

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000 / fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: RingPendulumParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Ring Pendulum standalone script."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

r = {p["r"]}
M = {p["M"]}
g = {p["g"]}
b = {p["b"]}
theta0 = {p["theta0"]}
omega0 = {p["omega0"]}
duration = {duration}
fps = 30

I_pivot = 2.0 * M * r * r
def ode(t, y):
    th, om = y
    return [om, -(g/(2.0*r))*np.sin(th) - (b/I_pivot)*om]

t_eval = np.linspace(0, duration, int(duration*fps)+1)
sol = solve_ivp(ode, (0,duration), [theta0, omega0], t_eval=t_eval,
                method="RK45", rtol=1e-9, atol=1e-11)
t, theta = sol.t, sol.y[0]

x_h = r + 0.40
y_h = 0.0
cx = x_h + r*np.sin(theta)
cy = y_h - r*np.cos(theta)

margin = 0.25*r
x_lo_d = -0.55*r
x_hi_d = (cx.max()+r) + margin
y_lo_d = (cy.min()-r) - margin
y_hi_d = y_h + 0.6*r
fig_w, fig_h = 6, 6
fig_aspect = fig_w/fig_h
dx, dy = x_hi_d-x_lo_d, y_hi_d-y_lo_d
if dx/dy < fig_aspect:
    extra = (fig_aspect*dy-dx)/2.0
    x_lo, x_hi = x_lo_d-extra, x_hi_d+extra
    y_lo, y_hi = y_lo_d, y_hi_d
else:
    extra = (dx/fig_aspect-dy)/2.0
    x_lo, x_hi = x_lo_d, x_hi_d
    y_lo, y_hi = y_lo_d-extra, y_hi_d+extra

fig = plt.figure(figsize=(fig_w,fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1])
ax.set_facecolor("#16213e")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi)
ax.set_aspect("equal"); ax.axis("off")

ax.add_patch(patches.Rectangle((x_lo,y_lo), -x_lo, y_hi-y_lo,
                               facecolor="#4a4e69", edgecolor="none", zorder=0))
ax.plot([0,0],[y_lo,y_hi], color="#adb5bd", lw=2.5, zorder=1)
ax.add_patch(patches.Rectangle((0.0, y_h-0.05*r), x_h, 0.10*r,
                               facecolor="#adb5bd", edgecolor="none", zorder=2))
ring = patches.Wedge((cx[0],cy[0]), r, 0, 360, width=0.05,
                     facecolor="#a8dadc", edgecolor="#adb5bd", lw=1.0, zorder=3)
ax.add_patch(ring)
ax.add_patch(patches.Circle((x_h,y_h), 0.07, facecolor="#e63946",
                            edgecolor="#adb5bd", lw=1.0, zorder=6))
ax.add_patch(patches.Circle((x_h,y_h), 0.022, facecolor="#1a1a2e",
                            edgecolor="none", zorder=7))

def update(f):
    ring.set_center((cx[f],cy[f]))
    return (ring,)

ani = animation.FuncAnimation(fig, update, frames=len(t),
                              interval=1000/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--r", type=float, default=0.6)
    parser.add_argument("--M", type=float, default=1.0)
    parser.add_argument("--g", type=float, default=9.8)
    parser.add_argument("--b", type=float, default=0.04)
    parser.add_argument("--theta0", type=float, default=0.5)
    parser.add_argument("--omega0", type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="ring_pendulum.mp4")
    args = parser.parse_args()
    p = RingPendulumParams(r=args.r, M=args.M, g=args.g, b=args.b,
                           theta0=args.theta0, omega0=args.omega0)
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
