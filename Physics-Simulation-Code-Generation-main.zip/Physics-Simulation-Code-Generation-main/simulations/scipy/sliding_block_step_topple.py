"""
Sliding Block Hits a Step and Topples.

Phases:
1. Slide on lower level: m a = -mu_floor m g until block right face reaches step.
2. Step impact (impulsive): angular momentum conservation about the step's top
   corner; omega_after = M v_at_step (s/2 - h_step) / I_pivot.
3. Pivot phase: I_p theta_ddot = M g d cos(phi_0 - theta).
4. Either topple to upper level (rotational KE -> sliding KE with restitution
   e_land, then mu_upper deceleration) or swing back and slide left under
   floor friction.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon
from scipy.integrate import solve_ivp
from dataclasses import dataclass, asdict


@dataclass
class SlidingBlockStepToppleParams:
    g: float = 9.8
    M: float = 1.0
    s: float = 0.30
    v_0: float = 3.2
    mu_floor: float = 0.10
    h_step: float = 0.05
    x_step: float = 1.0
    e_land: float = 0.30
    mu_upper: float = 0.30
    X_b_0: float = -0.50


def simulate(
    params: SlidingBlockStepToppleParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Returns (t, y) where y.shape = (3, N): [cm_x, cm_y, theta_cw]."""
    g, M, s = params.g, params.M, params.s
    v_0 = params.v_0
    mu_floor = params.mu_floor
    h_step = params.h_step
    x_step = params.x_step
    e_land = params.e_land
    mu_upper = params.mu_upper
    X_b_0 = params.X_b_0

    I_cm = (1.0 / 6.0) * M * s ** 2
    half_s = s / 2.0
    d2 = half_s ** 2 + (half_s - h_step) ** 2
    d_pivot = np.sqrt(d2)
    I_pivot = I_cm + M * d2
    phi_0 = np.arctan2(half_s - h_step, -half_s)

    slide_dist = (x_step - half_s) - X_b_0
    a_floor = mu_floor * g
    v_at_step_sq = v_0 ** 2 - 2.0 * a_floor * slide_dist
    if v_at_step_sq <= 0:
        # block stops before reaching step; degenerate but render still
        v_at_step_sq = 1e-6
    v_at_step = np.sqrt(v_at_step_sq)
    t1_end = (v_0 - v_at_step) / a_floor if a_floor > 1e-12 else slide_dist / v_0

    omega_after = M * v_at_step * (half_s - h_step) / I_pivot

    def pivot_ode(t, y):
        th, om = y
        return [om, M * g * d_pivot * np.cos(phi_0 - th) / I_pivot]

    def ev_topple_done(t, y):
        return y[0] - np.pi / 2.0
    ev_topple_done.terminal = True
    ev_topple_done.direction = +1

    def ev_swingback(t, y):
        return y[0]
    ev_swingback.terminal = True
    ev_swingback.direction = -1

    sol_pivot = solve_ivp(pivot_ode, (0.0, 5.0), [0.0, omega_after],
                          events=[ev_topple_done, ev_swingback],
                          dense_output=True, rtol=1e-9, atol=1e-11,
                          max_step=0.005)
    t_pivot_end = float(sol_pivot.t[-1])
    omega_end = float(sol_pivot.y[1, -1])
    toppled = len(sol_pivot.t_events[0]) > 0
    t2_end = t1_end + t_pivot_end

    if toppled:
        KE_rot_at_landing = 0.5 * I_pivot * omega_end ** 2
        v_slide_upper = e_land * np.sqrt(2.0 * KE_rot_at_landing / M)
        a_upper = mu_upper * g
        if a_upper > 0.0:
            t3_end_dur = v_slide_upper / a_upper
            ds_upper = v_slide_upper ** 2 / (2.0 * a_upper)
        else:
            t3_end_dur = duration
            ds_upper = v_slide_upper * duration
        CM_x_after_topple = x_step + (half_s - h_step)
        final_CM_x_upper = CM_x_after_topple + ds_upper
        t3_end = t2_end + t3_end_dur
        v_CM_x_back = 0.0
        final_CM_x_lower = 0.0
    else:
        omega_z = abs(omega_end)
        v_CM_x_back = -omega_z * (half_s - h_step)
        a_floor_decel = mu_floor * g
        t3_end_dur = abs(v_CM_x_back) / a_floor_decel if a_floor_decel > 0 else duration
        ds_back = v_CM_x_back ** 2 / (2.0 * a_floor_decel) * np.sign(v_CM_x_back)
        final_CM_x_lower = (x_step - half_s) + ds_back
        t3_end = t2_end + t3_end_dur
        v_slide_upper = 0.0
        final_CM_x_upper = 0.0

    def state_at_time(t):
        if t <= t1_end:
            cm_x = X_b_0 + v_0 * t - 0.5 * a_floor * t * t
            return cm_x, half_s, 0.0
        if t <= t2_end:
            dt = t - t1_end
            if dt <= sol_pivot.t[-1]:
                theta = float(sol_pivot.sol(dt)[0])
            else:
                theta = float(sol_pivot.y[0, -1])
            r0 = np.array([-half_s, half_s - h_step])
            c, sn = np.cos(theta), np.sin(theta)
            R = np.array([[c, sn], [-sn, c]])
            r = R @ r0
            return x_step + r[0], h_step + r[1], theta
        dt = t - t2_end
        if toppled:
            if dt < (t3_end - t2_end):
                cm_x = (x_step + (half_s - h_step)) + v_slide_upper * dt - 0.5 * (mu_upper * g) * dt * dt
            else:
                cm_x = final_CM_x_upper
            return cm_x, h_step + half_s, np.pi / 2.0
        else:
            if dt < (t3_end - t2_end):
                v = v_CM_x_back
                a = -np.sign(v) * mu_floor * g
                cm_x = (x_step - half_s) + v * dt + 0.5 * a * dt * dt
            else:
                cm_x = final_CM_x_lower
            return cm_x, half_s, 0.0

    t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
    cm_x = np.zeros(t_eval.size)
    cm_y = np.zeros(t_eval.size)
    th = np.zeros(t_eval.size)
    for i, ti in enumerate(t_eval):
        cm_x[i], cm_y[i], th[i] = state_at_time(ti)
    return t_eval, np.vstack([cm_x, cm_y, th])


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: SlidingBlockStepToppleParams,
    output_path: str,
    fps: int = 30,
) -> None:
    s = params.s; X_b_0 = params.X_b_0
    x_step = params.x_step; h_step = params.h_step
    half_s = s / 2.0
    cm_x, cm_y, th = y[0], y[1], y[2]

    local_corners = np.array([[-half_s, -half_s],
                              [+half_s, -half_s],
                              [+half_s, +half_s],
                              [-half_s, +half_s]])

    def cube_corners(cx, cy, theta_cw):
        c, sn = np.cos(theta_cw), np.sin(theta_cw)
        R = np.array([[c, sn], [-sn, c]])
        return (R @ local_corners.T).T + np.array([cx, cy])

    x_lo_d = X_b_0 - 0.50
    x_hi_d = x_step + 1.50
    y_lo_d = -0.10
    y_hi_d = s + 0.30

    fig_w, fig_h = 9.0, 5.0
    fig_aspect = fig_w / fig_h
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    floor_fill = Polygon([(x_lo, y_lo),
                          (x_lo, 0.0),
                          (x_step, 0.0),
                          (x_step, h_step),
                          (x_hi, h_step),
                          (x_hi, y_lo)],
                         facecolor="#4a4e69", edgecolor="none", zorder=0)
    ax.add_patch(floor_fill)
    ax.plot([x_lo, x_step], [0.0, 0.0],
            color="#adb5bd", lw=2.0, zorder=1)
    ax.plot([x_step, x_step], [0.0, h_step],
            color="#adb5bd", lw=2.0, zorder=1)
    ax.plot([x_step, x_hi], [h_step, h_step],
            color="#adb5bd", lw=2.0, zorder=1)

    block_patch = Polygon(cube_corners(X_b_0, half_s, 0.0),
                          facecolor="#8ecae6", edgecolor="white", lw=1.5, zorder=4)
    ax.add_patch(block_patch)

    def update(f):
        block_patch.set_xy(cube_corners(cm_x[f], cm_y[f], th[f]))
        return (block_patch,)

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0 / fps, blit=False)
    ani.save(output_path,
             writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(
    params: SlidingBlockStepToppleParams,
    duration: float = 12.0,
) -> str:
    p = asdict(params)
    return f'''"""Sliding block step topple — auto-generated."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon
from scipy.integrate import solve_ivp

g        = {p["g"]}
M        = {p["M"]}
s        = {p["s"]}
v_0      = {p["v_0"]}
mu_floor = {p["mu_floor"]}
h_step   = {p["h_step"]}
x_step   = {p["x_step"]}
e_land   = {p["e_land"]}
mu_upper = {p["mu_upper"]}
X_b_0    = {p["X_b_0"]}
duration = {duration}
fps      = 30

I_cm = (1.0/6.0)*M*s**2
half_s = s/2.0
d2 = half_s**2 + (half_s - h_step)**2
d_pivot = np.sqrt(d2)
I_pivot = I_cm + M*d2
phi_0 = np.arctan2(half_s - h_step, -half_s)
slide_dist = (x_step - half_s) - X_b_0
a_floor = mu_floor*g
v_at_step_sq = v_0**2 - 2.0*a_floor*slide_dist
if v_at_step_sq <= 0: v_at_step_sq = 1e-6
v_at_step = np.sqrt(v_at_step_sq)
t1_end = (v_0 - v_at_step)/a_floor if a_floor > 1e-12 else slide_dist/v_0
omega_after = M*v_at_step*(half_s - h_step)/I_pivot

def pivot_ode(t, y):
    th, om = y
    return [om, M*g*d_pivot*np.cos(phi_0 - th)/I_pivot]
def ev_top(t, y): return y[0] - np.pi/2.0
ev_top.terminal=True; ev_top.direction=+1
def ev_back(t, y): return y[0]
ev_back.terminal=True; ev_back.direction=-1

sol = solve_ivp(pivot_ode, (0.0, 5.0), [0.0, omega_after],
                events=[ev_top, ev_back], dense_output=True,
                rtol=1e-9, atol=1e-11, max_step=0.005)
t_pivot_end = float(sol.t[-1])
omega_end = float(sol.y[1,-1])
toppled = len(sol.t_events[0]) > 0
t2_end = t1_end + t_pivot_end
if toppled:
    KE_rot = 0.5*I_pivot*omega_end**2
    v_slide_upper = e_land*np.sqrt(2.0*KE_rot/M)
    a_up = mu_upper*g
    t3_end_dur = v_slide_upper/a_up if a_up>0 else duration
    ds_up = v_slide_upper**2/(2.0*a_up) if a_up>0 else 0.0
    final_up = x_step + (half_s - h_step) + ds_up
    t3_end = t2_end + t3_end_dur
    v_back_x = 0.0; final_lo = 0.0
else:
    om_z = abs(omega_end)
    v_back_x = -om_z*(half_s - h_step)
    a_dec = mu_floor*g
    t3_end_dur = abs(v_back_x)/a_dec if a_dec>0 else duration
    ds_back = v_back_x**2/(2.0*a_dec)*np.sign(v_back_x)
    final_lo = (x_step - half_s) + ds_back
    t3_end = t2_end + t3_end_dur
    v_slide_upper = 0.0; final_up = 0.0

def state_at_t(t):
    if t <= t1_end:
        cx = X_b_0 + v_0*t - 0.5*a_floor*t*t
        return cx, half_s, 0.0
    if t <= t2_end:
        dt = t - t1_end
        if dt <= sol.t[-1]:
            theta = float(sol.sol(dt)[0])
        else:
            theta = float(sol.y[0,-1])
        r0 = np.array([-half_s, half_s - h_step])
        c, sn = np.cos(theta), np.sin(theta)
        Rm = np.array([[c, sn], [-sn, c]])
        r = Rm @ r0
        return x_step + r[0], h_step + r[1], theta
    dt = t - t2_end
    if toppled:
        if dt < (t3_end - t2_end):
            cx = (x_step + (half_s - h_step)) + v_slide_upper*dt - 0.5*(mu_upper*g)*dt*dt
        else:
            cx = final_up
        return cx, h_step + half_s, np.pi/2.0
    else:
        if dt < (t3_end - t2_end):
            a = -np.sign(v_back_x)*mu_floor*g
            cx = (x_step - half_s) + v_back_x*dt + 0.5*a*dt*dt
        else:
            cx = final_lo
        return cx, half_s, 0.0

t_eval = np.linspace(0.0, duration, int(duration*fps)+1)
cm_x = np.zeros(t_eval.size); cm_y = np.zeros(t_eval.size); th = np.zeros(t_eval.size)
for i, ti in enumerate(t_eval):
    cm_x[i], cm_y[i], th[i] = state_at_t(ti)

local = np.array([[-half_s,-half_s],[+half_s,-half_s],
                   [+half_s,+half_s],[-half_s,+half_s]])
def corners(cx, cy, tcw):
    c, sn = np.cos(tcw), np.sin(tcw)
    Rm = np.array([[c, sn], [-sn, c]])
    return (Rm @ local.T).T + np.array([cx, cy])

x_lo_d = X_b_0 - 0.50; x_hi_d = x_step + 1.50
y_lo_d = -0.10; y_hi_d = s + 0.30
fig_w, fig_h = 9.0, 5.0; fa = fig_w/fig_h
dx, dy = x_hi_d-x_lo_d, y_hi_d-y_lo_d
if dx/dy < fa:
    e = (fa*dy-dx)/2; xlo, xhi, ylo, yhi = x_lo_d-e, x_hi_d+e, y_lo_d, y_hi_d
else:
    e = (dx/fa-dy)/2; xlo, xhi, ylo, yhi = x_lo_d, x_hi_d, y_lo_d-e, y_hi_d+e

fig = plt.figure(figsize=(fig_w,fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1])
ax.set_facecolor("#16213e")
ax.set_xlim(xlo, xhi); ax.set_ylim(ylo, yhi)
ax.set_aspect("equal"); ax.axis("off")

ff = Polygon([(xlo,ylo),(xlo,0.0),(x_step,0.0),(x_step,h_step),(xhi,h_step),(xhi,ylo)],
             facecolor="#4a4e69", edgecolor="none", zorder=0)
ax.add_patch(ff)
ax.plot([xlo,x_step],[0,0], color="#adb5bd", lw=2.0, zorder=1)
ax.plot([x_step,x_step],[0,h_step], color="#adb5bd", lw=2.0, zorder=1)
ax.plot([x_step,xhi],[h_step,h_step], color="#adb5bd", lw=2.0, zorder=1)
bp = Polygon(corners(X_b_0, half_s, 0.0),
             facecolor="#8ecae6", edgecolor="white", lw=1.5, zorder=4)
ax.add_patch(bp)

def update(f):
    bp.set_xy(corners(cm_x[f], cm_y[f], th[f]))
    return (bp,)

ani = animation.FuncAnimation(fig, update, frames=len(t_eval), interval=1000/fps, blit=False)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Sliding Block Step Topple")
    parser.add_argument("--g", type=float, default=9.8)
    parser.add_argument("--M", type=float, default=1.0)
    parser.add_argument("--s", type=float, default=0.30)
    parser.add_argument("--v_0", type=float, default=3.2)
    parser.add_argument("--mu_floor", type=float, default=0.10)
    parser.add_argument("--h_step", type=float, default=0.05)
    parser.add_argument("--x_step", type=float, default=1.0)
    parser.add_argument("--e_land", type=float, default=0.30)
    parser.add_argument("--mu_upper", type=float, default=0.30)
    parser.add_argument("--X_b_0", type=float, default=-0.50)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="sliding_block_step_topple.mp4")
    args = parser.parse_args()

    p = SlidingBlockStepToppleParams(
        g=args.g, M=args.M, s=args.s, v_0=args.v_0,
        mu_floor=args.mu_floor, h_step=args.h_step, x_step=args.x_step,
        e_land=args.e_land, mu_upper=args.mu_upper, X_b_0=args.X_b_0,
    )
    print(f"Simulating sliding block step topple: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
