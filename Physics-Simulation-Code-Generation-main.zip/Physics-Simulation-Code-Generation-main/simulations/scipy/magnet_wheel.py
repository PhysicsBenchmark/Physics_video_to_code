"""
Magnet Wheel Simulation
=======================
Faithfully translated from myphysicslab/src/sims/misc/MagnetWheelSim.ts
and myphysicslab/src/sims/misc/MagnetWheel.ts

Physical Law: Newton's Second Law for Rotational Motion
    tau_net = I * alpha

Derivation:
    I = 0.5 * m * R^2              (moment of inertia, solid disk approximation)
    Fixed magnet at (fx, fy) in world coords.
    For each wheel magnet i at body coords (R*cos(phi_i), R*sin(phi_i)):
        World pos: r_i = (R*cos(theta + phi_i), R*sin(theta + phi_i))
        Direction to fixed magnet: d_vec = (fx - r_ix, fy - r_iy)
        Force: F_vec = normalize(d_vec) * strength / |d_vec|^2
            (positive strength = attraction toward fixed magnet)
        Cross-product torque: tau_i = r_ix * F_iy - r_iy * F_ix
    Total:
        tau = sum(tau_i) - damping * omega / m
        alpha = tau / m   (since I / m = R^2/2, and TS divides by m not I)

Note: MagnetWheelSim.ts evaluate() uses:
    change[ANGLEP] = -damping * omega / m   (damping term)
    change[ANGLEP] += force.getTorque() / m  (magnetic torque)
  So the effective ODE divides by mass m, not moment of inertia I.
  This matches the TS source exactly.

State vector: [theta, omega]  where omega = d(theta)/dt
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.animation as animation
from dataclasses import dataclass, asdict
import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from .draw_utils import setup_dark_axis


@dataclass
class MagnetWheelParams:
    N: int = 8                 # number of magnets on the wheel rim
    R_wheel: float = 1.0      # wheel radius (m)
    m_wheel: float = 1.0      # wheel mass (kg)
    strength: float = 2.0     # magnet strength (attraction: positive)
    damping: float = 0.7      # angular damping coefficient (matches TS default of 0.7)
    theta0: float = 0.1       # initial rotation angle (rad)
    omega0: float = 0.5       # initial angular velocity (rad/s)

    def __post_init__(self):
        # Coerce a possibly-float-sampled N to int (config samples uniformly in a
        # float range; floor() to integer here so range(p.N) works downstream).
        self.N = int(self.N)


def _fixed_magnet_pos(p: MagnetWheelParams) -> tuple[float, float]:
    """Fixed magnet is at (0, R_wheel + 0.2*(R_wheel)), just above the rim.
    MagnetWheel.ts default: fixedMagnet_ = new Vector(0, 0.9) for R=1 wheel,
    which is just inside the rim. We use R+0.2 gap to avoid singularity.
    """
    return (0.0, p.R_wheel + 0.2)


def ode(t: float, y: list, p: MagnetWheelParams):
    """
    ODE for the magnet wheel.
    Exact translation of MagnetWheelSim.ts evaluate() + MagnetWheel.ts calculateForces().

    change[ANGLE]  = omega
    change[ANGLEP] = -damping * omega / m
                   + sum_i( torque_i ) / m

    where torque_i = r_ix * F_iy - r_iy * F_ix  (cross product in 2D)
    and   F_i = normalize(fm - r_i) * strength / |fm - r_i|^2

    Note: TS divides by mass m (not moment of inertia I).
    """
    theta, omega = y
    fx, fy = _fixed_magnet_pos(p)

    # damping term: -damping * omega / m  (from TS: -this.damping_*vars[ANGLEP]/m)
    domega = -p.damping * omega / p.m_wheel

    # magnetic torque from each wheel magnet
    for i in range(p.N):
        phi_i = 2.0 * np.pi * i / p.N
        # world position of magnet i (wheel center at origin)
        rx = p.R_wheel * np.cos(theta + phi_i)
        ry = p.R_wheel * np.sin(theta + phi_i)

        # vector from magnet to fixed magnet
        dvx = fx - rx
        dvy = fy - ry
        dist_sq = dvx * dvx + dvy * dvy
        dist = np.sqrt(dist_sq)

        if dist < 1e-10:
            continue

        # force = normalize(d_vec) * strength / dist^2
        # (strength > 0 means attractive, toward fixed magnet)
        f_mag = p.strength / dist_sq
        Fx = (dvx / dist) * f_mag
        Fy = (dvy / dist) * f_mag

        # torque = r x F  (2D cross product: rx*Fy - ry*Fx)
        tau_i = rx * Fy - ry * Fx
        domega += tau_i / p.m_wheel

    dtheta = omega
    return [dtheta, domega]


def simulate(
    params: MagnetWheelParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Integrate the ODE using RK45.
    Returns (t, y) where y.shape = (2, N): [theta, omega] at each time step.
    """
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode,
        (0, duration),
        [params.theta0, params.omega0],
        t_eval=t_eval,
        args=(params,),
        method="RK45",
        rtol=1e-8,
        atol=1e-10,
        dense_output=False,
    )
    return sol.t, sol.y


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: MagnetWheelParams,
    output_path: str,
    fps: int = 30,
) -> None:
    """Render an MP4 video of the magnet wheel animation."""
    theta = y[0]
    fx, fy = _fixed_magnet_pos(params)
    R = params.R_wheel

    pad = R * 0.6
    lim = R + pad
    xlim = (-lim, lim)
    ylim = (-lim, lim + R * 0.4)

    fig, ax = plt.subplots(figsize=(5, 5))
    setup_dark_axis(fig, ax, xlim, ylim)

    # Static: fixed magnet (red star)
    ax.plot([fx], [fy], "*", color="#e63946", ms=16, zorder=6, label="Fixed magnet")
    # Static: wheel center
    ax.plot([0], [0], "o", color="white", ms=5, zorder=6)

    # Animated: wheel rim (circle patch — we redraw as a circle artist)
    wheel_circle = plt.Circle((0, 0), R, color="#a8dadc", fill=False, lw=2.0, zorder=3)
    ax.add_patch(wheel_circle)

    # Animated: spoke (shows rotation angle)
    (spoke,) = ax.plot([], [], "-", color="#457b9d", lw=1.5, zorder=4)

    # Animated: wheel magnets (colored dots)
    magnet_colors = ["#f4a261", "#e9c46a", "#2a9d8f", "#264653",
                     "#e76f51", "#d62828", "#f77f00", "#fcbf49"]
    magnet_dots = []
    for i in range(params.N):
        color = magnet_colors[i % len(magnet_colors)]
        (dot,) = ax.plot([], [], "o", color=color, ms=10, zorder=5)
        magnet_dots.append(dot)

    # Time text

    def init():
        spoke.set_data([], [])
        for dot in magnet_dots:
            dot.set_data([], [])
        return [spoke] + magnet_dots

    def update(frame):
        th = theta[frame]
        # Update spoke (from center to rim at current angle)
        sx = R * np.cos(th)
        sy = R * np.sin(th)
        spoke.set_data([0, sx], [0, sy])
        # Update each wheel magnet position
        for i, dot in enumerate(magnet_dots):
            phi_i = 2.0 * np.pi * i / params.N
            mx = R * np.cos(th + phi_i)
            my = R * np.sin(th + phi_i)
            dot.set_data([mx], [my])
        return [spoke] + magnet_dots

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), init_func=init, interval=1000 / fps, blit=True
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: MagnetWheelParams, duration: float = 12.0) -> str:
    """Return a self-contained Python script string with parameter values embedded."""
    p = asdict(params)
    fx, fy = _fixed_magnet_pos(params)
    return f'''"""
Magnet Wheel — auto-generated simulation script.
Physics:
    theta_dot = omega
    omega_dot = -damping*omega/m + sum_i(torque_i)/m
    torque_i = rx*Fy - ry*Fx  (2D cross product)
    F_i = normalize(fm - r_i) * strength / |fm - r_i|^2
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation

# ── Physical parameters ─────────────────────────────────────────────────────
N        = {p["N"]}          # number of magnets
R_wheel  = {p["R_wheel"]}    # wheel radius (m)
m_wheel  = {p["m_wheel"]}    # wheel mass (kg)
strength = {p["strength"]}   # magnet strength
damping  = {p["damping"]}    # damping coefficient
theta0   = {p["theta0"]:.6f} # initial angle (rad)
omega0   = {p["omega0"]:.6f} # initial angular velocity (rad/s)
duration = {duration}

# Fixed magnet position
fx, fy = {fx}, {fy}

# ── ODE system ───────────────────────────────────────────────────────────────
def ode(t, y):
    theta, omega = y
    domega = -damping * omega / m_wheel
    for i in range(N):
        phi_i = 2.0 * np.pi * i / N
        rx = R_wheel * np.cos(theta + phi_i)
        ry = R_wheel * np.sin(theta + phi_i)
        dvx = fx - rx
        dvy = fy - ry
        dist_sq = dvx**2 + dvy**2
        dist = np.sqrt(dist_sq)
        if dist < 1e-10:
            continue
        f_mag = strength / dist_sq
        Fx = (dvx / dist) * f_mag
        Fy = (dvy / dist) * f_mag
        tau_i = rx * Fy - ry * Fx
        domega += tau_i / m_wheel
    return [omega, domega]

# ── Integrate ────────────────────────────────────────────────────────────────
fps = 30
t_eval = np.linspace(0, duration, int(duration * fps) + 1)
sol = solve_ivp(ode, (0, duration), [theta0, omega0],
                t_eval=t_eval, method="RK45", rtol=1e-8, atol=1e-10)
t, theta = sol.t, sol.y[0]

# ── Animate ──────────────────────────────────────────────────────────────────
R = R_wheel
pad = R * 0.6
lim = R + pad
fig, ax = plt.subplots(figsize=(5, 5), facecolor="#1a1a2e")
ax.set_facecolor("#16213e")
ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim + R*0.4)
ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(plt.Circle((0, 0), R, color="#a8dadc", fill=False, lw=2.0))
ax.plot([0], [0], "o", color="white", ms=5, zorder=6)
ax.plot([fx], [fy], "*", color="#e63946", ms=16, zorder=6)

spoke,   = ax.plot([], [], "-", color="#457b9d", lw=1.5)
mag_dots = [ax.plot([], [], "o", ms=10, color=["#f4a261","#e9c46a","#2a9d8f","#264653",
             "#e76f51","#d62828","#f77f00","#fcbf49"][i % 8])[0] for i in range(N)]

def update(frame):
    th = theta[frame]
    spoke.set_data([0, R*np.cos(th)], [0, R*np.sin(th)])
    for i, dot in enumerate(mag_dots):
        phi = 2*np.pi*i/N
        dot.set_data([R*np.cos(th+phi)], [R*np.sin(th+phi)])
    return [spoke] + mag_dots

ani = animation.FuncAnimation(fig, update, frames=len(t), interval=1000/fps, blit=True)
writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
ani.save("magnet_wheel.mp4", writer=writer, dpi=120)
plt.close()
print("Saved magnet_wheel.mp4")
'''


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Magnet Wheel Simulation")
    parser.add_argument("--N", type=int, default=8)
    parser.add_argument("--R_wheel", type=float, default=1.0)
    parser.add_argument("--m_wheel", type=float, default=1.0)
    parser.add_argument("--strength", type=float, default=2.0)
    parser.add_argument("--damping", type=float, default=0.7)
    parser.add_argument("--theta0", type=float, default=0.1)
    parser.add_argument("--omega0", type=float, default=0.5)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="magnet_wheel.mp4")
    args = parser.parse_args()

    p = MagnetWheelParams(
        N=args.N,
        R_wheel=args.R_wheel,
        m_wheel=args.m_wheel,
        strength=args.strength,
        damping=args.damping,
        theta0=args.theta0,
        omega0=args.omega0,
    )
    print(f"Simulating magnet wheel: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")


if __name__ == "__main__":
    main()
