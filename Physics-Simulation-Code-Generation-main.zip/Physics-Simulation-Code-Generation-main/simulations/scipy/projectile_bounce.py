"""
Projectile Bounce — point-mass ball under gravity with impulsive restitution
(Newton normal e + Coulomb tangent mu) at the floor, switching to a
closed-form coast-and-stop phase once the bouncing settles.
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis


@dataclass
class ProjectileBounceParams:
    g: float = 9.8
    m: float = 0.5
    r_ball: float = 0.10
    v0: float = 12.0
    theta0_deg: float = 60.0
    e: float = 0.65
    mu: float = 0.18
    x0: float = 0.0
    y0: float = 0.10


def _integrate(p: ProjectileBounceParams, duration: float, fps: int):
    g, m, r, v0 = p.g, p.m, p.r_ball, p.v0
    e, mu = p.e, p.mu
    x0, y0 = p.x0, max(p.y0, r)
    th = np.deg2rad(p.theta0_deg)
    vx0 = v0 * np.cos(th); vy0 = v0 * np.sin(th)

    def ode(t, s):
        return [s[2], s[3], 0.0, -g]

    def bounce(t, s):
        return s[1] - r
    bounce.terminal = True
    bounce.direction = -1.0

    def apply(state):
        x, y, vx, vy = state
        Jn = m * (1.0 + e) * abs(vy)
        Jt_cap = mu * Jn
        Jt_stick = -m * vx
        Jt = Jt_stick if abs(Jt_stick) <= Jt_cap else -np.sign(vx) * Jt_cap
        return [x, r, vx + Jt / m, -e * vy]

    t_grid = np.linspace(0.0, duration, int(duration * fps) + 1)
    xs = np.zeros_like(t_grid); ys = np.zeros_like(t_grid)
    vxs = np.zeros_like(t_grid); vys = np.zeros_like(t_grid)
    xs[0], ys[0], vxs[0], vys[0] = x0, y0, vx0, vy0

    state = np.array([x0, y0, vx0, vy0], dtype=float)
    t_now = 0.0; last_idx = 1
    settled = False; t_settle = None; x_settle = None; vx_settle = None
    settle_vy = 0.5

    for _ in range(200):
        if t_now >= duration - 1e-9:
            break
        sol = solve_ivp(ode, (t_now, duration), state, events=bounce,
                        dense_output=True, method="RK45",
                        rtol=1e-9, atol=1e-11, max_step=0.05)
        seg_end = sol.t[-1]
        while last_idx < len(t_grid) and t_grid[last_idx] <= seg_end + 1e-12:
            st = sol.sol(t_grid[last_idx])
            xs[last_idx] = st[0]; ys[last_idx] = st[1]
            vxs[last_idx] = st[2]; vys[last_idx] = st[3]
            last_idx += 1
        if sol.t_events[0].size == 0:
            state = sol.y[:, -1].copy(); t_now = seg_end
            break
        te = sol.t_events[0][0]
        new_state = apply(sol.y_events[0][0])
        t_now = te; state = np.array(new_state, dtype=float)
        if state[3] < settle_vy:
            settled = True; t_settle = te; x_settle = state[0]; vx_settle = state[2]
            break

    if settled:
        if abs(vx_settle) < 1e-9:
            for k in range(last_idx, len(t_grid)):
                xs[k] = x_settle; ys[k] = r; vxs[k] = 0.0; vys[k] = 0.0
        else:
            sgn = np.sign(vx_settle); a = -sgn * mu * g
            t_stop = t_settle + abs(vx_settle) / (mu * g)
            x_stop = x_settle + vx_settle * (t_stop - t_settle) + 0.5 * a * (t_stop - t_settle) ** 2
            for k in range(last_idx, len(t_grid)):
                tk = t_grid[k]
                if tk <= t_stop:
                    dt = tk - t_settle
                    xs[k] = x_settle + vx_settle * dt + 0.5 * a * dt * dt
                    vxs[k] = vx_settle + a * dt
                else:
                    xs[k] = x_stop; vxs[k] = 0.0
                ys[k] = r; vys[k] = 0.0
    else:
        for k in range(last_idx, len(t_grid)):
            dt = t_grid[k] - t_now
            xs[k] = state[0] + state[2] * dt
            ys[k] = max(r, state[1] + state[3] * dt - 0.5 * g * dt * dt)
            vxs[k] = state[2]; vys[k] = state[3] - g * dt

    return t_grid, np.vstack([xs, ys, vxs, vys])


def simulate(params: ProjectileBounceParams, duration: float = 12.0, fps: int = 30):
    return _integrate(params, duration, fps)


def render_video(t, y, params: ProjectileBounceParams, output_path: str, fps: int = 30):
    xs, ys = y[0], y[1]
    r = params.r_ball
    fig_w, fig_h = 8.0, 5.0
    fig_aspect = fig_w / fig_h
    x_lo_d = xs.min() - 0.3; x_hi_d = xs.max() + 0.3
    y_lo_d = -0.3; y_hi_d = ys.max() + 0.3
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h))
    ax = fig.add_axes([0, 0, 1, 1])
    setup_dark_axis(fig, ax, (x_lo, x_hi), (y_lo, y_hi))
    ax.axhspan(y_lo, 0.0, color="#4a4e69", alpha=0.55, zorder=0)
    ax.axhline(0, color="#adb5bd", lw=2, zorder=1)
    trail, = ax.plot([], [], color="#e63946", lw=1.4, alpha=0.40, zorder=2)
    ball = patches.Circle((xs[0], ys[0]), r, facecolor="#e63946",
                          edgecolor="white", lw=1.2, zorder=4)
    ax.add_patch(ball)

    def update(f):
        ball.set_center((xs[f], ys[f]))
        lo = max(0, f - 75)
        trail.set_data(xs[lo:f + 1], ys[lo:f + 1])
        return ball, trail

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000 / fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: ProjectileBounceParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Projectile bounce standalone script."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

g = {p["g"]}
m = {p["m"]}
r_ball = {p["r_ball"]}
v0 = {p["v0"]}
theta0_deg = {p["theta0_deg"]}
e = {p["e"]}
mu = {p["mu"]}
x0 = {p["x0"]}
y0 = max({p["y0"]}, r_ball)
duration = {duration}
fps = 30

theta0 = np.deg2rad(theta0_deg)
vx0 = v0*np.cos(theta0); vy0 = v0*np.sin(theta0)

def ode(t, s): return [s[2], s[3], 0.0, -g]
def bounce(t, s): return s[1] - r_ball
bounce.terminal = True; bounce.direction = -1.0

def apply(state):
    x, y, vx, vy = state
    Jn = m*(1.0+e)*abs(vy)
    Jt_cap = mu*Jn
    Jt_stick = -m*vx
    Jt = Jt_stick if abs(Jt_stick) <= Jt_cap else -np.sign(vx)*Jt_cap
    return [x, r_ball, vx + Jt/m, -e*vy]

t_grid = np.linspace(0.0, duration, int(duration*fps)+1)
xs = np.zeros_like(t_grid); ys = np.zeros_like(t_grid)
vxs = np.zeros_like(t_grid); vys = np.zeros_like(t_grid)
xs[0], ys[0], vxs[0], vys[0] = x0, y0, vx0, vy0

state = np.array([x0, y0, vx0, vy0], dtype=float)
t_now = 0.0; last_idx = 1
settled = False; t_settle = None; x_settle = None; vx_settle = None
settle_vy = 0.5

for _ in range(200):
    if t_now >= duration - 1e-9: break
    sol = solve_ivp(ode, (t_now, duration), state, events=bounce,
                    dense_output=True, method="RK45",
                    rtol=1e-9, atol=1e-11, max_step=0.05)
    seg_end = sol.t[-1]
    while last_idx < len(t_grid) and t_grid[last_idx] <= seg_end + 1e-12:
        st = sol.sol(t_grid[last_idx])
        xs[last_idx]=st[0]; ys[last_idx]=st[1]
        vxs[last_idx]=st[2]; vys[last_idx]=st[3]
        last_idx += 1
    if sol.t_events[0].size == 0:
        state = sol.y[:,-1].copy(); t_now = seg_end; break
    te = sol.t_events[0][0]
    new_state = apply(sol.y_events[0][0])
    t_now = te; state = np.array(new_state, dtype=float)
    if state[3] < settle_vy:
        settled = True; t_settle=te; x_settle=state[0]; vx_settle=state[2]; break

if settled:
    if abs(vx_settle) < 1e-9:
        for k in range(last_idx, len(t_grid)):
            xs[k]=x_settle; ys[k]=r_ball; vxs[k]=0.0; vys[k]=0.0
    else:
        sgn = np.sign(vx_settle); a = -sgn*mu*g
        t_stop = t_settle + abs(vx_settle)/(mu*g)
        x_stop = x_settle + vx_settle*(t_stop-t_settle) + 0.5*a*(t_stop-t_settle)**2
        for k in range(last_idx, len(t_grid)):
            tk = t_grid[k]
            if tk <= t_stop:
                dt = tk - t_settle
                xs[k] = x_settle + vx_settle*dt + 0.5*a*dt*dt
                vxs[k] = vx_settle + a*dt
            else:
                xs[k] = x_stop; vxs[k] = 0.0
            ys[k] = r_ball; vys[k] = 0.0
else:
    for k in range(last_idx, len(t_grid)):
        dt = t_grid[k] - t_now
        xs[k] = state[0] + state[2]*dt
        ys[k] = max(r_ball, state[1] + state[3]*dt - 0.5*g*dt*dt)
        vxs[k] = state[2]; vys[k] = state[3] - g*dt

fig_w, fig_h = 8.0, 5.0
fig_aspect = fig_w/fig_h
x_lo_d = xs.min()-0.3; x_hi_d = xs.max()+0.3
y_lo_d = -0.3; y_hi_d = ys.max()+0.3
dx, dy = x_hi_d-x_lo_d, y_hi_d-y_lo_d
if dx/dy < fig_aspect:
    extra = (fig_aspect*dy-dx)/2.0
    x_lo, x_hi = x_lo_d-extra, x_hi_d+extra
    y_lo, y_hi = y_lo_d, y_hi_d
else:
    extra = (dx/fig_aspect-dy)/2.0
    x_lo, x_hi = x_lo_d, x_hi_d
    y_lo, y_hi = y_lo_d-extra, y_hi_d+extra

fig = plt.figure(figsize=(fig_w,fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.axhspan(y_lo, 0.0, color="#4a4e69", alpha=0.55, zorder=0)
ax.axhline(0, color="#adb5bd", lw=2, zorder=1)
trail, = ax.plot([],[], color="#e63946", lw=1.4, alpha=0.40, zorder=2)
ball = patches.Circle((xs[0],ys[0]), r_ball, facecolor="#e63946",
                      edgecolor="white", lw=1.2, zorder=4)
ax.add_patch(ball)
def update(f):
    ball.set_center((xs[f],ys[f]))
    lo = max(0,f-75)
    trail.set_data(xs[lo:f+1], ys[lo:f+1])
    return ball, trail
ani = animation.FuncAnimation(fig, update, frames=len(t_grid),
                              interval=1000/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--g", type=float, default=9.8)
    parser.add_argument("--m", type=float, default=0.5)
    parser.add_argument("--r_ball", type=float, default=0.10)
    parser.add_argument("--v0", type=float, default=12.0)
    parser.add_argument("--theta0_deg", type=float, default=60.0)
    parser.add_argument("--e", type=float, default=0.65)
    parser.add_argument("--mu", type=float, default=0.18)
    parser.add_argument("--x0", type=float, default=0.0)
    parser.add_argument("--y0", type=float, default=0.10)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="projectile_bounce.mp4")
    args = parser.parse_args()
    p = ProjectileBounceParams(g=args.g, m=args.m, r_ball=args.r_ball, v0=args.v0,
                               theta0_deg=args.theta0_deg, e=args.e, mu=args.mu,
                               x0=args.x0, y0=args.y0)
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
