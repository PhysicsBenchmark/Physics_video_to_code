"""
Colliding Blocks Against a Wall
================================
A small block (m1, side s1) sits at rest on a frictionless surface to the right
of a fixed vertical wall.  A heavier block (m2, side s2) approaches from the
right and hits it; the small block bounces between the wall and the larger
block until they separate.

Free motion: x_i' = v_i, v_i' = 0.

Wall impact (x1 - s1/2 = 0, v1 < 0):  v1 -> -e_w * v1.

Block-block impact:
    v1 <- ((m1 - e_b m2) v1 + (1 + e_b) m2 v2) / (m1 + m2)
    v2 <- ((m2 - e_b m1) v2 + (1 + e_b) m1 v1_pre) / (m1 + m2)
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class CollidingBlocksParams:
    m1: float = 1.0
    s1: float = 0.30
    m2: float = 16.0
    s2: float = 0.70
    e_w: float = 1.0
    e_b: float = 1.0
    x1_0: float = 1.20
    v1_0: float = 0.00
    x2_0: float = 4.30
    v2_0: float = -1.50


def simulate(
    params: CollidingBlocksParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    m1, m2 = params.m1, params.m2
    s1, s2 = params.s1, params.s2
    e_w, e_b = params.e_w, params.e_b

    def free(t, y):
        return [y[1], 0.0, y[3], 0.0]

    def ev_wall(t, y):
        return y[0] - s1 / 2.0
    ev_wall.terminal = True; ev_wall.direction = -1

    def ev_block(t, y):
        return (y[2] - s2 / 2.0) - (y[0] + s1 / 2.0)
    ev_block.terminal = True; ev_block.direction = -1

    t_eval_g = np.linspace(0, duration, int(duration * fps) + 1)
    S = np.zeros((4, len(t_eval_g)))
    state = np.array([params.x1_0, params.v1_0, params.x2_0, params.v2_0], dtype=float)
    S[:, 0] = state
    last_idx = 1
    t_cur = 0.0
    n_collisions = 0

    for _seg in range(2000):
        if t_cur >= duration - 1e-9:
            break
        sol = solve_ivp(free, (t_cur, duration), state,
                        events=[ev_wall, ev_block], dense_output=True,
                        max_step=0.05, rtol=1e-9, atol=1e-11)
        seg_end = sol.t[-1]
        while last_idx < len(t_eval_g) and t_eval_g[last_idx] <= seg_end + 1e-12:
            S[:, last_idx] = sol.sol(t_eval_g[last_idx])
            last_idx += 1
        state = sol.y[:, -1].copy()
        t_cur = seg_end
        if sol.status != 1:
            break
        t_w, t_b = sol.t_events[0], sol.t_events[1]
        is_wall = len(t_w) > 0 and (len(t_b) == 0 or t_w[-1] >= t_b[-1])
        if is_wall:
            state[1] = -e_w * state[1]
        else:
            v1, v2 = state[1], state[3]
            state[1] = ((m1 - e_b * m2) * v1 + (1 + e_b) * m2 * v2) / (m1 + m2)
            state[3] = ((m2 - e_b * m1) * v2 + (1 + e_b) * m1 * v1) / (m1 + m2)
        n_collisions += 1

    if last_idx < len(t_eval_g):
        S[:, last_idx:] = state[:, None]

    return t_eval_g, S


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: CollidingBlocksParams,
    output_path: str,
    fps: int = 30,
) -> None:
    s1, s2 = params.s1, params.s2
    x1_arr, x2_arr = y[0], y[2]
    x2_0 = params.x2_0

    fig_w, fig_h = 10, 4
    fig_aspect = fig_w / fig_h
    x_lo_d = -0.55
    x_hi_d = (x2_0 + s2 / 2) + 0.50
    y_lo_d = -0.30
    y_hi_d = max(s1, s2) + 0.50
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    wall = patches.Rectangle((x_lo, y_lo), -x_lo, y_hi - y_lo,
                             facecolor="#4a4e69", edgecolor="none", zorder=0)
    floor = patches.Rectangle((0, y_lo), x_hi, -y_lo,
                              facecolor="#4a4e69", edgecolor="none",
                              alpha=0.55, zorder=0)
    ax.add_patch(wall); ax.add_patch(floor)
    ax.plot([0, x_hi], [0, 0], color="#adb5bd", lw=2.5, zorder=1)
    ax.plot([0, 0], [y_lo, y_hi], color="#adb5bd", lw=2.5, zorder=1)

    b1 = patches.Rectangle((x1_arr[0] - s1 / 2, 0), s1, s1,
                           facecolor="#e63946", edgecolor="white", lw=1.5, zorder=3)
    b2 = patches.Rectangle((x2_arr[0] - s2 / 2, 0), s2, s2,
                           facecolor="#f4d35e", edgecolor="white", lw=1.5, zorder=3)
    ax.add_patch(b1); ax.add_patch(b2)

    def update(f):
        b1.set_x(x1_arr[f] - s1 / 2)
        b2.set_x(x2_arr[f] - s2 / 2)
        return b1, b2

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000 / fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: CollidingBlocksParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""
Colliding Blocks Against a Wall — auto-generated.
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

m1, s1 = {p["m1"]}, {p["s1"]}
m2, s2 = {p["m2"]}, {p["s2"]}
e_w    = {p["e_w"]}
e_b    = {p["e_b"]}
x1_0, v1_0 = {p["x1_0"]}, {p["v1_0"]}
x2_0, v2_0 = {p["x2_0"]}, {p["v2_0"]}
duration   = {duration}
fps = 30

def free(t, y): return [y[1], 0.0, y[3], 0.0]
def ev_wall(t, y): return y[0] - s1 / 2.0
ev_wall.terminal = True;  ev_wall.direction = -1
def ev_block(t, y): return (y[2] - s2 / 2.0) - (y[0] + s1 / 2.0)
ev_block.terminal = True; ev_block.direction = -1

t_eval_g = np.linspace(0, duration, int(duration * fps) + 1)
S = np.zeros((4, len(t_eval_g)))
state = np.array([x1_0, v1_0, x2_0, v2_0], dtype=float)
S[:, 0] = state
last_idx = 1
t_cur = 0.0
n_collisions = 0

for _seg in range(2000):
    if t_cur >= duration - 1e-9: break
    sol = solve_ivp(free, (t_cur, duration), state,
                    events=[ev_wall, ev_block], dense_output=True,
                    max_step=0.05, rtol=1e-9, atol=1e-11)
    seg_end = sol.t[-1]
    while last_idx < len(t_eval_g) and t_eval_g[last_idx] <= seg_end + 1e-12:
        S[:, last_idx] = sol.sol(t_eval_g[last_idx]); last_idx += 1
    state = sol.y[:, -1].copy(); t_cur = seg_end
    if sol.status != 1: break
    t_w, t_b = sol.t_events[0], sol.t_events[1]
    is_wall = len(t_w) > 0 and (len(t_b) == 0 or t_w[-1] >= t_b[-1])
    if is_wall:
        state[1] = -e_w * state[1]
    else:
        v1, v2 = state[1], state[3]
        state[1] = ((m1 - e_b*m2)*v1 + (1+e_b)*m2*v2) / (m1 + m2)
        state[3] = ((m2 - e_b*m1)*v2 + (1+e_b)*m1*v1) / (m1 + m2)
    n_collisions += 1

if last_idx < len(t_eval_g):
    S[:, last_idx:] = state[:, None]

x1_arr, x2_arr = S[0], S[2]

fig_w, fig_h = 10, 4
fig_aspect = fig_w / fig_h
x_lo_d, x_hi_d = -0.55, (x2_0 + s2/2) + 0.50
y_lo_d, y_hi_d = -0.30, max(s1, s2) + 0.50
dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
if dx / dy < fig_aspect:
    extra = (fig_aspect * dy - dx) / 2.0
    x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
else:
    extra = (dx / fig_aspect - dy) / 2.0
    x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0, 0, 1, 1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(patches.Rectangle((x_lo, y_lo), -x_lo, y_hi - y_lo, facecolor="#4a4e69", edgecolor="none", zorder=0))
ax.add_patch(patches.Rectangle((0, y_lo), x_hi, -y_lo, facecolor="#4a4e69", edgecolor="none", alpha=0.55, zorder=0))
ax.plot([0, x_hi], [0, 0], color="#adb5bd", lw=2.5, zorder=1)
ax.plot([0, 0], [y_lo, y_hi], color="#adb5bd", lw=2.5, zorder=1)

b1 = patches.Rectangle((x1_0 - s1/2, 0), s1, s1, facecolor="#e63946", edgecolor="white", lw=1.5, zorder=3)
b2 = patches.Rectangle((x2_0 - s2/2, 0), s2, s2, facecolor="#f4d35e", edgecolor="white", lw=1.5, zorder=3)
ax.add_patch(b1); ax.add_patch(b2)

def update(f):
    b1.set_x(x1_arr[f] - s1/2); b2.set_x(x2_arr[f] - s2/2)
    return b1, b2

ani = animation.FuncAnimation(fig, update, frames=len(t_eval_g), interval=1000/fps, blit=True)
ani.save("colliding_blocks.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close(); print("Saved colliding_blocks.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Colliding Blocks")
    parser.add_argument("--m1", type=float, default=1.0)
    parser.add_argument("--s1", type=float, default=0.30)
    parser.add_argument("--m2", type=float, default=16.0)
    parser.add_argument("--s2", type=float, default=0.70)
    parser.add_argument("--e_w", type=float, default=1.0)
    parser.add_argument("--e_b", type=float, default=1.0)
    parser.add_argument("--x1_0", type=float, default=1.20)
    parser.add_argument("--v1_0", type=float, default=0.00)
    parser.add_argument("--x2_0", type=float, default=4.30)
    parser.add_argument("--v2_0", type=float, default=-1.50)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="colliding_blocks.mp4")
    args = parser.parse_args()

    p = CollidingBlocksParams(
        m1=args.m1, s1=args.s1, m2=args.m2, s2=args.s2,
        e_w=args.e_w, e_b=args.e_b,
        x1_0=args.x1_0, v1_0=args.v1_0, x2_0=args.x2_0, v2_0=args.v2_0,
    )
    print(f"Simulating colliding blocks: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
