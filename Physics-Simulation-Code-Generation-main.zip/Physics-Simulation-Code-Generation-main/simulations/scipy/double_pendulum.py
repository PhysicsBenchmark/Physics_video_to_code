"""
Double Pendulum Simulation
==========================
Faithfully translated from myphysicslab/src/sims/pendulum/DoublePendulumSim.ts

Physical Law: Lagrangian Mechanics (Euler-Lagrange equations)
    d/dt(∂L/∂q̇ᵢ) - ∂L/∂qᵢ = 0,   qᵢ ∈ {θ₁, θ₂}

Lagrangian L = T - V:
    T = ½(m₁+m₂)L₁²θ̇₁² + ½m₂L₂²θ̇₂² + m₂L₁L₂θ̇₁θ̇₂cos(θ₁-θ₂)
    V = -(m₁+m₂)gL₁cos(θ₁) - m₂gL₂cos(θ₂)

Equations of motion (verbatim from DoublePendulumSim.ts evaluate()):

    θ̈₁ = [-g(2m₁+m₂)sin(θ₁) - gm₂sin(θ₁-2θ₂) - 2m₂θ̇₂²L₂sin(θ₁-θ₂) - m₂θ̇₁²L₁sin(2(θ₁-θ₂))]
           / [L₁(2m₁+m₂ - m₂cos(2(θ₁-θ₂)))]

    θ̈₂ = [2sin(θ₁-θ₂)((m₁+m₂)θ̇₁²L₁ + g(m₁+m₂)cos(θ₁) + m₂θ̇₂²L₂cos(θ₁-θ₂))]
           / [L₂(2m₁+m₂ - m₂cos(2(θ₁-θ₂)))]

State vector: [θ₁, ω₁, θ₂, ω₂]
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis


@dataclass
class DoublePendulumParams:
    L1: float = 1.0         # length of rod 1 (m)
    L2: float = 1.0         # length of rod 2 (m)
    m1: float = 2.0         # mass of bob 1 (kg)  [TS default]
    m2: float = 2.0         # mass of bob 2 (kg)  [TS default]
    g: float  = 9.8         # gravitational acceleration (m/s²)
    theta1_0: float = np.pi / 8   # initial angle of rod 1 (rad)  [TS default]
    omega1_0: float = 0.0
    theta2_0: float = 0.0
    omega2_0: float = 0.0


def ode(t: float, y: list, p: DoublePendulumParams):
    """
    Exact translation of DoublePendulumSim.ts evaluate() method.
    No damping (original TypeScript sim is conservative).
    """
    th1, dth1, th2, dth2 = y
    m1, m2, L1, L2, g = p.m1, p.m2, p.L1, p.L2, p.g

    diff = th1 - th2
    denom = 2 * m1 + m2 - m2 * np.cos(2 * diff)

    # θ̈₁  (change[TH1P] in TypeScript)
    num1 = -g * (2 * m1 + m2) * np.sin(th1)
    num1 -= g * m2 * np.sin(th1 - 2 * th2)
    num1 -= 2 * m2 * dth2 * dth2 * L2 * np.sin(diff)
    num1 -= m2 * dth1 * dth1 * L1 * np.sin(2 * diff)
    ddth1 = num1 / (L1 * denom)

    # θ̈₂  (change[TH2P] in TypeScript)
    num2 = (m1 + m2) * dth1 * dth1 * L1
    num2 += g * (m1 + m2) * np.cos(th1)
    num2 += m2 * dth2 * dth2 * L2 * np.cos(diff)
    num2 *= 2 * np.sin(diff)
    ddth2 = num2 / (L2 * denom)

    return [dth1, ddth1, dth2, ddth2]


def simulate(
    params: DoublePendulumParams,
    duration: float = 15.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Integrate using RK45. Returns (t, y) with y.shape = (4, N)."""
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode,
        (0, duration),
        [params.theta1_0, params.omega1_0, params.theta2_0, params.omega2_0],
        t_eval=t_eval,
        args=(params,),
        method="RK45",
        rtol=1e-9,
        atol=1e-11,
    )
    return sol.t, sol.y


def energy(t: np.ndarray, y: np.ndarray, p: DoublePendulumParams):
    """Total mechanical energy (should be conserved, serves as accuracy check)."""
    th1, dth1, th2, dth2 = y
    x1 = p.L1 * np.sin(th1)
    y1_pos = -p.L1 * np.cos(th1)
    x2 = x1 + p.L2 * np.sin(th2)
    y2_pos = y1_pos - p.L2 * np.cos(th2)

    v1sq = (p.L1 * dth1) ** 2
    v2sq = (p.L1 * dth1) ** 2 + (p.L2 * dth2) ** 2 + 2 * p.L1 * p.L2 * dth1 * dth2 * np.cos(th1 - th2)

    KE = 0.5 * p.m1 * v1sq + 0.5 * p.m2 * v2sq
    PE = -(p.m1 + p.m2) * p.g * p.L1 * np.cos(th1) - p.m2 * p.g * p.L2 * np.cos(th2)
    return KE, PE, KE + PE


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: DoublePendulumParams,
    output_path: str,
    fps: int = 30,
    trail_len: int = 150,
) -> None:
    """Render animated double pendulum with chaos trail on bob 2."""
    th1, _, th2, _ = y
    total_L = params.L1 + params.L2

    x1 = params.L1 * np.sin(th1)
    y1 = -params.L1 * np.cos(th1)
    x2 = x1 + params.L2 * np.sin(th2)
    y2 = y1 - params.L2 * np.cos(th2)

    pad = total_L * 0.25
    lim = total_L + pad
    xlim = (-lim, lim)
    ylim = (-lim, lim * 0.2)

    fig, ax = plt.subplots(figsize=(6, 6))
    setup_dark_axis(fig, ax, xlim, ylim)

    ax.plot([0], [0], "o", color="white", ms=7, zorder=5)

    (trail,) = ax.plot([], [], "-", color="#e63946", alpha=0.4, lw=1.0, zorder=2)
    (rod1,)  = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
    (rod2,)  = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
    (bob1,)  = ax.plot([], [], "o", color="#f4d35e", ms=12, zorder=4)
    (bob2,)  = ax.plot([], [], "o", color="#e63946", ms=12, zorder=4)

    tx: list = []
    ty: list = []

    def init():
        for obj in [trail, rod1, rod2, bob1, bob2]:
            obj.set_data([], [])
        return trail, rod1, rod2, bob1, bob2

    def update(frame):
        rod1.set_data([0, x1[frame]], [0, y1[frame]])
        rod2.set_data([x1[frame], x2[frame]], [y1[frame], y2[frame]])
        bob1.set_data([x1[frame]], [y1[frame]])
        bob2.set_data([x2[frame]], [y2[frame]])
        tx.append(x2[frame])
        ty.append(y2[frame])
        if len(tx) > trail_len:
            tx.pop(0)
            ty.pop(0)
        trail.set_data(tx, ty)
        return trail, rod1, rod2, bob1, bob2

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), init_func=init, interval=1000 / fps, blit=True
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: DoublePendulumParams, duration: float = 15.0) -> str:
    p = asdict(params)
    return f'''"""
Double Pendulum — auto-generated simulation script.
Physics (Lagrangian mechanics):
  θ̈₁ = [-g(2m₁+m₂)sin(θ₁) - gm₂sin(θ₁-2θ₂) - 2m₂θ̇₂²L₂sin(θ₁-θ₂) - m₂θ̇₁²L₁sin(2(θ₁-θ₂))]
        / [L₁(2m₁+m₂ - m₂cos(2(θ₁-θ₂)))]
  θ̈₂ = [2sin(θ₁-θ₂)((m₁+m₂)θ̇₁²L₁ + g(m₁+m₂)cos(θ₁) + m₂θ̇₂²L₂cos(θ₁-θ₂))]
        / [L₂(2m₁+m₂ - m₂cos(2(θ₁-θ₂)))]
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation

L1, L2       = {p["L1"]}, {p["L2"]}        # rod lengths (m)
m1, m2       = {p["m1"]}, {p["m2"]}        # masses (kg)
g            = {p["g"]}                    # gravity (m/s²)
theta1_0     = {p["theta1_0"]:.6f}         # initial angle 1 (rad)
omega1_0     = {p["omega1_0"]:.6f}
theta2_0     = {p["theta2_0"]:.6f}         # initial angle 2 (rad)
omega2_0     = {p["omega2_0"]:.6f}
duration     = {duration}

def ode(t, y):
    th1, dth1, th2, dth2 = y
    diff  = th1 - th2
    denom = 2*m1 + m2 - m2*np.cos(2*diff)
    num1  = -g*(2*m1+m2)*np.sin(th1) - g*m2*np.sin(th1-2*th2)
    num1 -= 2*m2*dth2**2*L2*np.sin(diff) + m2*dth1**2*L1*np.sin(2*diff)
    ddth1 = num1 / (L1 * denom)
    num2  = 2*np.sin(diff)*((m1+m2)*dth1**2*L1 + g*(m1+m2)*np.cos(th1) + m2*dth2**2*L2*np.cos(diff))
    ddth2 = num2 / (L2 * denom)
    return [dth1, ddth1, dth2, ddth2]

fps    = 30
t_eval = np.linspace(0, duration, int(duration*fps)+1)
sol    = solve_ivp(ode, (0, duration), [theta1_0, omega1_0, theta2_0, omega2_0],
                   t_eval=t_eval, method="RK45", rtol=1e-9, atol=1e-11)
th1, th2 = sol.y[0], sol.y[2]
x1 = L1*np.sin(th1);       y1 = -L1*np.cos(th1)
x2 = x1+L2*np.sin(th2);    y2 = y1-L2*np.cos(th2)

lim = (L1+L2)*1.25
fig, ax = plt.subplots(figsize=(6,6), facecolor="#1a1a2e")
ax.set_facecolor("#16213e"); ax.set_xlim(-lim,lim); ax.set_ylim(-lim,lim*0.2)
ax.set_aspect("equal"); ax.axis("off")
ax.plot([0],[0],"o",color="white",ms=7,zorder=5)
trail,  = ax.plot([],[],"-",color="#e63946",alpha=0.4,lw=1.0,zorder=2)
rod1,   = ax.plot([],[],"-",color="#a8dadc",lw=2.5,zorder=3)
rod2,   = ax.plot([],[],"-",color="#a8dadc",lw=2.5,zorder=3)
bob1,   = ax.plot([],[],  "o",color="#f4d35e",ms=12,zorder=4)
bob2,   = ax.plot([],[],  "o",color="#e63946",ms=12,zorder=4)
tx,ty   = [],[]

def update(f):
    rod1.set_data([0,x1[f]],[0,y1[f]])
    rod2.set_data([x1[f],x2[f]],[y1[f],y2[f]])
    bob1.set_data([x1[f]],[y1[f]]); bob2.set_data([x2[f]],[y2[f]])
    tx.append(x2[f]); ty.append(y2[f])
    if len(tx)>150: tx.pop(0); ty.pop(0)
    trail.set_data(tx,ty)
    return trail,rod1,rod2,bob1,bob2

ani = animation.FuncAnimation(fig, update, frames=len(sol.t), interval=1000/fps, blit=True)
ani.save("double_pendulum.mp4", writer=animation.FFMpegWriter(fps=fps,bitrate=1800), dpi=120)
plt.close(); print("Saved double_pendulum.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Double Pendulum Simulation")
    parser.add_argument("--L1", type=float, default=1.0)
    parser.add_argument("--L2", type=float, default=1.0)
    parser.add_argument("--m1", type=float, default=2.0)
    parser.add_argument("--m2", type=float, default=2.0)
    parser.add_argument("--g",  type=float, default=9.8)
    parser.add_argument("--theta1_0", type=float, default=np.pi/8)
    parser.add_argument("--theta2_0", type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=15.0)
    parser.add_argument("--output",   type=str,   default="double_pendulum.mp4")
    args = parser.parse_args()

    p = DoublePendulumParams(
        L1=args.L1, L2=args.L2, m1=args.m1, m2=args.m2, g=args.g,
        theta1_0=args.theta1_0, theta2_0=args.theta2_0,
    )
    print(f"Simulating double pendulum: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
