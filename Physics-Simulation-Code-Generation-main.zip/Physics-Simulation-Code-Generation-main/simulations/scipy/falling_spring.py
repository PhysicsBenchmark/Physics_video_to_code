"""
Falling Spring — two cubical point masses connected by a Hookean spring,
falling under gravity onto a floor with continuous penalty contact (e_rest)
and tangential Coulomb friction.
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class FallingSpringParams:
    m1: float = 0.5
    m2: float = 0.5
    L0: float = 0.9
    k: float = 180.0
    c: float = 0.5
    theta0_deg: float = 35.0
    yCOM0: float = 1.6
    e_rest: float = 0.45
    mu_fric: float = 0.3
    cube_size: float = 0.12
    g: float = 9.81


def _integrate(p: FallingSpringParams, duration: float, fps: int):
    m1, m2, L0, k, c = p.m1, p.m2, p.L0, p.k, p.c
    theta0 = np.deg2rad(p.theta0_deg)
    yCOM0 = p.yCOM0
    e_rest, mu_fric = p.e_rest, p.mu_fric
    cube_size, g = p.cube_size, p.g

    half = L0 / 2.0
    state0 = np.array([
        -half * np.sin(theta0), yCOM0 - half * np.cos(theta0),
        +half * np.sin(theta0), yCOM0 + half * np.cos(theta0),
        0.0, 0.0, 0.0, 0.0
    ])
    zeta_eq = -np.log(max(e_rest, 1e-3))
    zeta = zeta_eq / np.sqrt(np.pi**2 + zeta_eq**2)
    k_floor = 5.0e4
    m_min = min(m1, m2)
    c_floor = 2.0 * zeta * np.sqrt(k_floor * m_min)
    V_EPS = 0.05

    def ode(t, s):
        x1_, y1_, x2_, y2_, vx1, vy1, vx2, vy2 = s
        dx, dy = x2_ - x1_, y2_ - y1_
        L = np.hypot(dx, dy)
        if L < 1e-12:
            ux, uy = 0.0, 0.0
        else:
            ux, uy = dx / L, dy / L
        Fs_mag = k * (L - L0)
        Fs1x, Fs1y = Fs_mag * ux, Fs_mag * uy
        Fs2x, Fs2y = -Fs1x, -Fs1y
        vrel = (vx2 - vx1) * ux + (vy2 - vy1) * uy
        Fd1x, Fd1y = c * vrel * ux, c * vrel * uy
        Fd2x, Fd2y = -Fd1x, -Fd1y
        floor_y = cube_size / 2.0
        Fc1x = Fc1y = Fc2x = Fc2y = 0.0
        pen1 = floor_y - y1_
        if pen1 > 0:
            Fn1 = k_floor * pen1 + c_floor * (-vy1)
            if Fn1 > 0:
                Fc1y = Fn1; Fc1x = -mu_fric * Fn1 * np.tanh(vx1 / V_EPS)
        pen2 = floor_y - y2_
        if pen2 > 0:
            Fn2 = k_floor * pen2 + c_floor * (-vy2)
            if Fn2 > 0:
                Fc2y = Fn2; Fc2x = -mu_fric * Fn2 * np.tanh(vx2 / V_EPS)
        ax1 = (Fs1x + Fd1x + Fc1x) / m1
        ay1 = (Fs1y + Fd1y + Fc1y) / m1 - g
        ax2 = (Fs2x + Fd2x + Fc2x) / m2
        ay2 = (Fs2y + Fd2y + Fc2y) / m2 - g
        return [vx1, vy1, vx2, vy2, ax1, ay1, ax2, ay2]

    t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
    sol = solve_ivp(ode, (0.0, duration), state0, t_eval=t_eval,
                    method="LSODA", rtol=1e-7, atol=1e-9, max_step=1e-3)
    return sol.t, sol.y


def simulate(params: FallingSpringParams, duration: float = 12.0, fps: int = 30):
    return _integrate(params, duration, fps)


def render_video(t, y, params: FallingSpringParams, output_path: str, fps: int = 30):
    cube_size = params.cube_size
    x1, y1, x2, y2 = y[0], y[1], y[2], y[3]
    fig_w, fig_h = 6, 6
    fig_aspect = fig_w / fig_h
    margin_x = 0.30; margin_y = 0.20
    x_lo_d = min(x1.min(), x2.min()) - cube_size / 2 - margin_x
    x_hi_d = max(x1.max(), x2.max()) + cube_size / 2 + margin_x
    y_lo_d = -0.30
    y_hi_d = max(y1.max(), y2.max()) + cube_size / 2 + margin_y
    dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_d / dy_d < fig_aspect:
        extra = (fig_aspect * dy_d - dx_d) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx_d / fig_aspect - dy_d) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")
    ax.add_patch(patches.Rectangle((x_lo, y_lo), x_hi - x_lo, -y_lo,
                                    facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.plot([x_lo, x_hi], [0, 0], color="#adb5bd", lw=2.0, zorder=1)
    cube1 = patches.Rectangle((x1[0] - cube_size / 2, y1[0] - cube_size / 2),
                              cube_size, cube_size, facecolor="#e63946",
                              edgecolor="#adb5bd", lw=1.0, zorder=4)
    cube2 = patches.Rectangle((x2[0] - cube_size / 2, y2[0] - cube_size / 2),
                              cube_size, cube_size, facecolor="#e63946",
                              edgecolor="#adb5bd", lw=1.0, zorder=4)
    ax.add_patch(cube1); ax.add_patch(cube2)
    N_COILS = 10; COIL_W = 0.06; N_PTS = 4 * N_COILS + 2

    def coil_xy(p1, p2):
        x1_, y1_ = p1; x2_, y2_ = p2
        dx, dy = x2_ - x1_, y2_ - y1_
        L = np.hypot(dx, dy)
        if L < 1e-9:
            return np.array([x1_, x2_]), np.array([y1_, y2_])
        ux, uy = dx / L, dy / L
        nx, ny = -uy, ux
        lead = cube_size / 2.0
        s = np.linspace(0.0, 1.0, N_PTS)
        seg_len = max(L - 2 * lead, 1e-6)
        arc = np.where(s < lead / L, s * L,
                       np.where(s > 1.0 - lead / L, s * L,
                                lead + ((s * L - lead) / seg_len) * seg_len))
        middle = (arc >= lead) & (arc <= L - lead)
        phase = np.zeros_like(arc)
        phase[middle] = (arc[middle] - lead) / seg_len
        amp = np.where(middle, COIL_W * np.sin(2 * np.pi * N_COILS * phase), 0.0)
        return x1_ + ux * arc + nx * amp, y1_ + uy * arc + ny * amp

    xs0, ys0 = coil_xy((x1[0], y1[0]), (x2[0], y2[0]))
    spring_line, = ax.plot(xs0, ys0, color="#a8dadc", lw=2.5, zorder=3)

    def update(f):
        cube1.set_xy((x1[f] - cube_size / 2, y1[f] - cube_size / 2))
        cube2.set_xy((x2[f] - cube_size / 2, y2[f] - cube_size / 2))
        xs, ys = coil_xy((x1[f], y1[f]), (x2[f], y2[f]))
        spring_line.set_data(xs, ys)
        return cube1, cube2, spring_line

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000 / fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: FallingSpringParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Falling spring (cube-spring-cube) standalone script."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

m1 = {p["m1"]}
m2 = {p["m2"]}
L0 = {p["L0"]}
k = {p["k"]}
c = {p["c"]}
theta0 = np.deg2rad({p["theta0_deg"]})
yCOM0 = {p["yCOM0"]}
e_rest = {p["e_rest"]}
mu_fric = {p["mu_fric"]}
cube_size = {p["cube_size"]}
g = {p["g"]}
duration = {duration}
fps = 30

half = L0/2.0
x1_0 = -half*np.sin(theta0); y1_0 = yCOM0 - half*np.cos(theta0)
x2_0 = +half*np.sin(theta0); y2_0 = yCOM0 + half*np.cos(theta0)
state0 = np.array([x1_0, y1_0, x2_0, y2_0, 0.0, 0.0, 0.0, 0.0])

zeta_eq = -np.log(max(e_rest, 1e-3))
zeta = zeta_eq / np.sqrt(np.pi**2 + zeta_eq**2)
k_floor = 5.0e4
m_min = min(m1, m2)
c_floor = 2.0*zeta*np.sqrt(k_floor*m_min)
V_EPS = 0.05

def ode(t, s):
    x1_,y1_,x2_,y2_,vx1,vy1,vx2,vy2 = s
    dx,dy = x2_-x1_, y2_-y1_
    L = np.hypot(dx,dy)
    if L<1e-12: ux,uy = 0.0,0.0
    else: ux,uy = dx/L, dy/L
    Fs_mag = k*(L-L0)
    Fs1x,Fs1y = Fs_mag*ux, Fs_mag*uy
    Fs2x,Fs2y = -Fs1x,-Fs1y
    vrel = (vx2-vx1)*ux + (vy2-vy1)*uy
    Fd1x,Fd1y = c*vrel*ux, c*vrel*uy
    Fd2x,Fd2y = -Fd1x,-Fd1y
    floor_y = cube_size/2.0
    Fc1x=Fc1y=Fc2x=Fc2y=0.0
    pen1 = floor_y - y1_
    if pen1>0:
        Fn1 = k_floor*pen1 + c_floor*(-vy1)
        if Fn1>0:
            Fc1y = Fn1; Fc1x = -mu_fric*Fn1*np.tanh(vx1/V_EPS)
    pen2 = floor_y - y2_
    if pen2>0:
        Fn2 = k_floor*pen2 + c_floor*(-vy2)
        if Fn2>0:
            Fc2y = Fn2; Fc2x = -mu_fric*Fn2*np.tanh(vx2/V_EPS)
    ax1 = (Fs1x+Fd1x+Fc1x)/m1
    ay1 = (Fs1y+Fd1y+Fc1y)/m1 - g
    ax2 = (Fs2x+Fd2x+Fc2x)/m2
    ay2 = (Fs2y+Fd2y+Fc2y)/m2 - g
    return [vx1,vy1,vx2,vy2,ax1,ay1,ax2,ay2]

t_eval = np.linspace(0.0, duration, int(duration*fps)+1)
sol = solve_ivp(ode, (0.0, duration), state0, t_eval=t_eval,
                method="LSODA", rtol=1e-7, atol=1e-9, max_step=1e-3)
x1=sol.y[0]; y1=sol.y[1]; x2=sol.y[2]; y2=sol.y[3]

fig_w, fig_h = 6, 6
fig_aspect = fig_w/fig_h
margin_x=0.30; margin_y=0.20
x_lo_d = min(x1.min(),x2.min()) - cube_size/2 - margin_x
x_hi_d = max(x1.max(),x2.max()) + cube_size/2 + margin_x
y_lo_d = -0.30
y_hi_d = max(y1.max(),y2.max()) + cube_size/2 + margin_y
dx_d, dy_d = x_hi_d-x_lo_d, y_hi_d-y_lo_d
if dx_d/dy_d < fig_aspect:
    extra = (fig_aspect*dy_d - dx_d)/2.0
    x_lo, x_hi = x_lo_d-extra, x_hi_d+extra
    y_lo, y_hi = y_lo_d, y_hi_d
else:
    extra = (dx_d/fig_aspect - dy_d)/2.0
    x_lo, x_hi = x_lo_d, x_hi_d
    y_lo, y_hi = y_lo_d-extra, y_hi_d+extra

fig = plt.figure(figsize=(fig_w,fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(patches.Rectangle((x_lo,y_lo), x_hi-x_lo, -y_lo,
                               facecolor="#4a4e69", edgecolor="none", zorder=0))
ax.plot([x_lo,x_hi],[0,0], color="#adb5bd", lw=2.0, zorder=1)
cube1 = patches.Rectangle((x1[0]-cube_size/2, y1[0]-cube_size/2),
                          cube_size, cube_size, facecolor="#e63946",
                          edgecolor="#adb5bd", lw=1.0, zorder=4)
cube2 = patches.Rectangle((x2[0]-cube_size/2, y2[0]-cube_size/2),
                          cube_size, cube_size, facecolor="#e63946",
                          edgecolor="#adb5bd", lw=1.0, zorder=4)
ax.add_patch(cube1); ax.add_patch(cube2)
N_COILS=10; COIL_W=0.06; N_PTS=4*N_COILS+2

def coil_xy(p1,p2):
    x1_,y1_ = p1; x2_,y2_ = p2
    dx,dy = x2_-x1_, y2_-y1_
    L = np.hypot(dx,dy)
    if L<1e-9: return np.array([x1_,x2_]), np.array([y1_,y2_])
    ux,uy = dx/L, dy/L
    nx,ny = -uy, ux
    lead = cube_size/2.0
    s = np.linspace(0.0,1.0,N_PTS)
    seg_len = max(L - 2*lead, 1e-6)
    arc = np.where(s<lead/L, s*L,
                   np.where(s>1.0-lead/L, s*L,
                            lead + ((s*L-lead)/seg_len)*seg_len))
    middle = (arc>=lead) & (arc<=L-lead)
    phase = np.zeros_like(arc)
    phase[middle] = (arc[middle]-lead)/seg_len
    amp = np.where(middle, COIL_W*np.sin(2*np.pi*N_COILS*phase), 0.0)
    return x1_+ux*arc+nx*amp, y1_+uy*arc+ny*amp

xs0,ys0 = coil_xy((x1[0],y1[0]),(x2[0],y2[0]))
spring_line, = ax.plot(xs0,ys0, color="#a8dadc", lw=2.5, zorder=3)

def update(f):
    cube1.set_xy((x1[f]-cube_size/2, y1[f]-cube_size/2))
    cube2.set_xy((x2[f]-cube_size/2, y2[f]-cube_size/2))
    xs,ys = coil_xy((x1[f],y1[f]),(x2[f],y2[f]))
    spring_line.set_data(xs,ys)
    return cube1, cube2, spring_line

ani = animation.FuncAnimation(fig, update, frames=len(t_eval),
                              interval=1000/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--m1", type=float, default=0.5)
    parser.add_argument("--m2", type=float, default=0.5)
    parser.add_argument("--L0", type=float, default=0.9)
    parser.add_argument("--k", type=float, default=180.0)
    parser.add_argument("--c", type=float, default=0.5)
    parser.add_argument("--theta0_deg", type=float, default=35.0)
    parser.add_argument("--yCOM0", type=float, default=1.6)
    parser.add_argument("--e_rest", type=float, default=0.45)
    parser.add_argument("--mu_fric", type=float, default=0.3)
    parser.add_argument("--cube_size", type=float, default=0.12)
    parser.add_argument("--g", type=float, default=9.81)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="falling_spring.mp4")
    args = parser.parse_args()
    p = FallingSpringParams(**{k: getattr(args, k) for k in
        ["m1","m2","L0","k","c","theta0_deg","yCOM0","e_rest","mu_fric","cube_size","g"]})
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
