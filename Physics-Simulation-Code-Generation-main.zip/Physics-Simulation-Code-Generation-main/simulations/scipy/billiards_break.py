"""
Billiards Break — top-down view, cue ball strikes a 10-ball triangular rack.
Velocity Verlet, Coulomb cloth friction, ball-ball / ball-cushion collisions.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class BilliardsBreakParams:
    g: float = 9.8
    m: float = 0.16
    r: float = 0.057
    e_ball: float = 0.94
    e_wall: float = 0.92
    mu: float = 0.012
    x_min: float = -1.27
    x_max: float = 1.27
    y_min: float = -0.635
    y_max: float = 0.635
    x_apex: float = 0.50
    y_apex: float = 0.0
    x_cue0: float = -0.95
    y_cue0: float = 0.04
    vx_cue0: float = 8.0
    vy_cue0: float = 0.10
    duration: float = 12.0
    dt: float = 0.001


def _run_sim(p):
    N = 11
    g = p.g; m = p.m; r = p.r
    e_ball = p.e_ball; e_wall = p.e_wall; mu = p.mu
    pos = np.zeros((N, 2)); vel = np.zeros((N, 2))
    pos[0] = (p.x_cue0, p.y_cue0); vel[0] = (p.vx_cue0, p.vy_cue0)
    dx_row = r * np.sqrt(3.0); nudge = 1e-6
    idx = 1
    for k in range(4):
        n_in_row = k + 1
        x_row = p.x_apex + k * dx_row + k * nudge
        for j in range(n_in_row):
            y_pos = (j - (n_in_row - 1) / 2.0) * (2.0 * r + nudge)
            pos[idx] = (x_row, y_pos); idx += 1

    v_eps = 1e-3
    dt = p.dt
    n_steps = int(round(p.duration / dt))
    fps = 30
    sample_every = max(1, int(round((1.0 / fps) / dt)))
    n_frames = int(round(p.duration * fps)) + 1
    P_hist = np.zeros((n_frames, N, 2))
    P_hist[0] = pos

    def all_accels(V):
        A = np.zeros_like(V)
        speeds = np.hypot(V[:, 0], V[:, 1])
        moving = speeds > v_eps
        A[moving] = -mu * g * V[moving] / speeds[moving, None]
        return A

    def resolve_walls(P, V):
        for i in range(N):
            if P[i, 0] < p.x_min + r:
                P[i, 0] = p.x_min + r
                if V[i, 0] < 0.0: V[i, 0] = -e_wall * V[i, 0]
            elif P[i, 0] > p.x_max - r:
                P[i, 0] = p.x_max - r
                if V[i, 0] > 0.0: V[i, 0] = -e_wall * V[i, 0]
            if P[i, 1] < p.y_min + r:
                P[i, 1] = p.y_min + r
                if V[i, 1] < 0.0: V[i, 1] = -e_wall * V[i, 1]
            elif P[i, 1] > p.y_max - r:
                P[i, 1] = p.y_max - r
                if V[i, 1] > 0.0: V[i, 1] = -e_wall * V[i, 1]

    def resolve_ball_ball(P, V, max_passes=6):
        two_r = 2.0 * r
        for _ in range(max_passes):
            moved = False
            for i in range(N):
                for j in range(i+1, N):
                    dx = P[j, 0] - P[i, 0]; dy = P[j, 1] - P[i, 1]
                    d2 = dx*dx + dy*dy
                    if d2 >= two_r * two_r: continue
                    d = np.sqrt(d2) if d2 > 0.0 else 1e-12
                    nx, ny = dx / d, dy / d
                    vrx = V[j, 0] - V[i, 0]; vry = V[j, 1] - V[i, 1]
                    vrn = vrx * nx + vry * ny
                    if vrn < 0.0:
                        Jn = -(1.0 + e_ball) * m * vrn / 2.0
                        V[i, 0] -= (Jn / m) * nx; V[i, 1] -= (Jn / m) * ny
                        V[j, 0] += (Jn / m) * nx; V[j, 1] += (Jn / m) * ny
                    overlap = two_r - d
                    if overlap > 0.0:
                        sx = 0.5 * overlap * nx; sy = 0.5 * overlap * ny
                        P[i, 0] -= sx; P[i, 1] -= sy
                        P[j, 0] += sx; P[j, 1] += sy
                        moved = True
            if not moved: break

    A = all_accels(vel)
    frame_idx = 1
    for step in range(1, n_steps + 1):
        vel += 0.5 * A * dt
        pos += vel * dt
        A = all_accels(vel)
        vel += 0.5 * A * dt
        resolve_walls(pos, vel)
        resolve_ball_ball(pos, vel, max_passes=6)
        speeds = np.hypot(vel[:, 0], vel[:, 1])
        vel[speeds < v_eps] = 0.0
        A = all_accels(vel)
        if step % sample_every == 0 and frame_idx < n_frames:
            P_hist[frame_idx] = pos
            frame_idx += 1
    while frame_idx < n_frames:
        P_hist[frame_idx] = pos
        frame_idx += 1
    return P_hist, n_frames


def simulate(params: BilliardsBreakParams, duration: float = 12.0, fps: int = 30):
    if duration is not None: params.duration = duration
    P_hist, n_frames = _run_sim(params)
    t = np.linspace(0.0, params.duration, n_frames)
    N = 11
    y = np.zeros((2 * N, n_frames))
    for i in range(N):
        y[2*i] = P_hist[:, i, 0]
        y[2*i+1] = P_hist[:, i, 1]
    return t, y


def render_video(t, y, params: BilliardsBreakParams, output_path: str, fps: int = 30):
    p = params
    N = 11
    n_frames = y.shape[1]
    P_hist = np.zeros((n_frames, N, 2))
    for i in range(N):
        P_hist[:, i, 0] = y[2*i]; P_hist[:, i, 1] = y[2*i+1]

    margin = 0.10
    x_lo, x_hi = p.x_min - margin, p.x_max + margin
    y_lo, y_hi = p.y_min - margin, p.y_max + margin
    fig = plt.figure(figsize=(8.0, 4.0), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#0f5132")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal")
    ax.set_xticks([]); ax.set_yticks([])
    for sp in ax.spines.values(): sp.set_visible(False)

    cush_color = "#7c552d"; cush_thick = 0.05
    ax.add_patch(patches.Rectangle((p.x_min - cush_thick, p.y_min - cush_thick),
                                    (p.x_max - p.x_min) + 2 * cush_thick, cush_thick,
                                    facecolor=cush_color, edgecolor="none", zorder=1))
    ax.add_patch(patches.Rectangle((p.x_min - cush_thick, p.y_max),
                                    (p.x_max - p.x_min) + 2 * cush_thick, cush_thick,
                                    facecolor=cush_color, edgecolor="none", zorder=1))
    ax.add_patch(patches.Rectangle((p.x_min - cush_thick, p.y_min),
                                    cush_thick, (p.y_max - p.y_min),
                                    facecolor=cush_color, edgecolor="none", zorder=1))
    ax.add_patch(patches.Rectangle((p.x_max, p.y_min),
                                    cush_thick, (p.y_max - p.y_min),
                                    facecolor=cush_color, edgecolor="none", zorder=1))

    rack_colors = ["#f4d35e", "#1d3557", "#e63946", "#6a0572", "#f08a4b",
                   "#2a9d8f", "#9d2c2c", "#222222", "#ffd166", "#118ab2"]
    cue = patches.Circle(P_hist[0, 0], p.r, facecolor="white",
                         edgecolor="#dddddd", lw=0.8, zorder=4)
    ax.add_patch(cue)
    ball_patches = [cue]
    for k in range(10):
        bp = patches.Circle(P_hist[0, k+1], p.r, facecolor=rack_colors[k],
                            edgecolor="white", lw=0.8, zorder=4)
        ax.add_patch(bp); ball_patches.append(bp)

    def update(f):
        for i, bp in enumerate(ball_patches):
            bp.center = (float(P_hist[f, i, 0]), float(P_hist[f, i, 1]))
        return ball_patches

    ani = animation.FuncAnimation(fig, update, frames=n_frames,
                                  interval=1000.0/fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=2400), dpi=120)
    plt.close(fig)


def make_standalone_script(params: BilliardsBreakParams, duration: float = 12.0) -> str:
    p = asdict(params)
    p["duration"] = duration
    return f'''"""Billiards break - standalone script."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

g = {p["g"]}; m = {p["m"]}; r = {p["r"]}
e_ball = {p["e_ball"]}; e_wall = {p["e_wall"]}; mu = {p["mu"]}
x_min = {p["x_min"]}; x_max = {p["x_max"]}; y_min = {p["y_min"]}; y_max = {p["y_max"]}
x_apex = {p["x_apex"]}; y_apex = {p["y_apex"]}
x_cue0 = {p["x_cue0"]}; y_cue0 = {p["y_cue0"]}; vx_cue0 = {p["vx_cue0"]}; vy_cue0 = {p["vy_cue0"]}
duration = {p["duration"]}; dt = {p["dt"]}; fps = {p["fps"] if "fps" in p else 30}
v_eps = 1e-3
N = 11
pos = np.zeros((N, 2)); vel = np.zeros((N, 2))
pos[0] = (x_cue0, y_cue0); vel[0] = (vx_cue0, vy_cue0)
dx_row = r * np.sqrt(3.0); nudge = 1e-6
idx = 1
for k in range(4):
    n_in_row = k + 1
    x_row = x_apex + k * dx_row + k * nudge
    for j in range(n_in_row):
        y_pos = (j - (n_in_row - 1) / 2.0) * (2.0 * r + nudge)
        pos[idx] = (x_row, y_pos); idx += 1

n_steps = int(round(duration / dt))
sample_every = max(1, int(round((1.0 / fps) / dt)))
n_frames = int(round(duration * fps)) + 1
P_hist = np.zeros((n_frames, N, 2)); P_hist[0] = pos


def all_accels(V):
    A = np.zeros_like(V)
    speeds = np.hypot(V[:, 0], V[:, 1])
    moving = speeds > v_eps
    A[moving] = -mu * g * V[moving] / speeds[moving, None]
    return A


def resolve_walls(P, V):
    for i in range(N):
        if P[i, 0] < x_min + r:
            P[i, 0] = x_min + r
            if V[i, 0] < 0.0: V[i, 0] = -e_wall * V[i, 0]
        elif P[i, 0] > x_max - r:
            P[i, 0] = x_max - r
            if V[i, 0] > 0.0: V[i, 0] = -e_wall * V[i, 0]
        if P[i, 1] < y_min + r:
            P[i, 1] = y_min + r
            if V[i, 1] < 0.0: V[i, 1] = -e_wall * V[i, 1]
        elif P[i, 1] > y_max - r:
            P[i, 1] = y_max - r
            if V[i, 1] > 0.0: V[i, 1] = -e_wall * V[i, 1]


def resolve_ball_ball(P, V, max_passes=6):
    two_r = 2.0 * r
    for _ in range(max_passes):
        moved = False
        for i in range(N):
            for j in range(i+1, N):
                dx = P[j, 0] - P[i, 0]; dy = P[j, 1] - P[i, 1]
                d2 = dx*dx + dy*dy
                if d2 >= two_r * two_r: continue
                d = np.sqrt(d2) if d2 > 0.0 else 1e-12
                nx, ny = dx / d, dy / d
                vrx = V[j, 0] - V[i, 0]; vry = V[j, 1] - V[i, 1]
                vrn = vrx * nx + vry * ny
                if vrn < 0.0:
                    Jn = -(1.0 + e_ball) * m * vrn / 2.0
                    V[i, 0] -= (Jn / m) * nx; V[i, 1] -= (Jn / m) * ny
                    V[j, 0] += (Jn / m) * nx; V[j, 1] += (Jn / m) * ny
                overlap = two_r - d
                if overlap > 0.0:
                    sx = 0.5 * overlap * nx; sy = 0.5 * overlap * ny
                    P[i, 0] -= sx; P[i, 1] -= sy
                    P[j, 0] += sx; P[j, 1] += sy
                    moved = True
        if not moved: break


A = all_accels(vel)
frame_idx = 1
for step in range(1, n_steps + 1):
    vel += 0.5 * A * dt
    pos += vel * dt
    A = all_accels(vel)
    vel += 0.5 * A * dt
    resolve_walls(pos, vel)
    resolve_ball_ball(pos, vel, max_passes=6)
    speeds = np.hypot(vel[:, 0], vel[:, 1])
    vel[speeds < v_eps] = 0.0
    A = all_accels(vel)
    if step % sample_every == 0 and frame_idx < n_frames:
        P_hist[frame_idx] = pos; frame_idx += 1
while frame_idx < n_frames:
    P_hist[frame_idx] = pos; frame_idx += 1

margin = 0.10
x_lo, x_hi = x_min - margin, x_max + margin
y_lo, y_hi = y_min - margin, y_max + margin
fig = plt.figure(figsize=(8.0, 4.0), facecolor="#1a1a2e")
ax = fig.add_axes([0, 0, 1, 1])
ax.set_facecolor("#0f5132")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal")
ax.set_xticks([]); ax.set_yticks([])
for sp in ax.spines.values(): sp.set_visible(False)

cush_color = "#7c552d"; cush_thick = 0.05
ax.add_patch(patches.Rectangle((x_min - cush_thick, y_min - cush_thick),
                                (x_max - x_min) + 2 * cush_thick, cush_thick,
                                facecolor=cush_color, edgecolor="none", zorder=1))
ax.add_patch(patches.Rectangle((x_min - cush_thick, y_max),
                                (x_max - x_min) + 2 * cush_thick, cush_thick,
                                facecolor=cush_color, edgecolor="none", zorder=1))
ax.add_patch(patches.Rectangle((x_min - cush_thick, y_min),
                                cush_thick, (y_max - y_min),
                                facecolor=cush_color, edgecolor="none", zorder=1))
ax.add_patch(patches.Rectangle((x_max, y_min),
                                cush_thick, (y_max - y_min),
                                facecolor=cush_color, edgecolor="none", zorder=1))

rack_colors = ["#f4d35e", "#1d3557", "#e63946", "#6a0572", "#f08a4b",
               "#2a9d8f", "#9d2c2c", "#222222", "#ffd166", "#118ab2"]
cue = patches.Circle(P_hist[0, 0], r, facecolor="white",
                     edgecolor="#dddddd", lw=0.8, zorder=4)
ax.add_patch(cue)
ball_patches = [cue]
for k in range(10):
    bp = patches.Circle(P_hist[0, k+1], r, facecolor=rack_colors[k],
                        edgecolor="white", lw=0.8, zorder=4)
    ax.add_patch(bp); ball_patches.append(bp)

def update(f):
    for i, bp in enumerate(ball_patches):
        bp.center = (float(P_hist[f, i, 0]), float(P_hist[f, i, 1]))
    return ball_patches

ani = animation.FuncAnimation(fig, update, frames=n_frames,
                              interval=1000.0/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=2400), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    p = BilliardsBreakParams()
    t, y = simulate(p, duration=p.duration)
    render_video(t, y, p, "video.mp4")
