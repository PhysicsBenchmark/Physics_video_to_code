"""
Cart with Two Pendulums (Huygens-coupled metronomes)
====================================================
Two pendulums of length L_i and bob mass m_i hang on a cart (mass M) that
slides frictionlessly on horizontal rails. Lagrangian mechanics gives a 3x3
linear system in (X_dd, theta1_dd, theta2_dd):

  [ M_tot           m1 L1 cos t1   m2 L2 cos t2 ] [ X_dd  ]   [ m1 L1 s1 w1^2 + m2 L2 s2 w2^2 ]
  [ m1 L1 cos t1    m1 L1^2        0            ] [ t1_dd ] = [ -m1 g L1 s1 - b1 w1            ]
  [ m2 L2 cos t2    0              m2 L2^2      ] [ t2_dd ]   [ -m2 g L2 s2 - b2 w2            ]

Horizontal momentum is conserved (frictionless rails).
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class CartTwoMetronomesParams:
    g: float = 9.8
    M: float = 3.0
    m_1: float = 0.45
    m_2: float = 0.85
    L_1: float = 0.40
    L_2: float = 0.60
    b_1: float = 0.0040
    b_2: float = 0.0070
    dx_1: float = -0.30
    dx_2: float = 0.30
    h_pivot: float = 0.95
    X0: float = 0.0
    theta1_0: float = 0.45
    theta2_0: float = -0.55
    Xdot0: float = 0.0
    w1_0: float = 0.0
    w2_0: float = 0.0


def simulate(
    params: CartTwoMetronomesParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    g, M = params.g, params.M
    m1, m2 = params.m_1, params.m_2
    L1, L2 = params.L_1, params.L_2
    b1, b2 = params.b_1, params.b_2
    M_tot = M + m1 + m2

    def ode(t, y):
        X, t1, t2, Xd, w1, w2 = y
        c1, s1 = np.cos(t1), np.sin(t1)
        c2, s2 = np.cos(t2), np.sin(t2)
        A = np.array([
            [M_tot,        m1 * L1 * c1,  m2 * L2 * c2],
            [m1 * L1 * c1, m1 * L1 * L1,  0.0],
            [m2 * L2 * c2, 0.0,           m2 * L2 * L2],
        ])
        b_vec = np.array([
            m1 * L1 * s1 * w1 * w1 + m2 * L2 * s2 * w2 * w2,
            -m1 * g * L1 * s1 - b1 * w1,
            -m2 * g * L2 * s2 - b2 * w2,
        ])
        Xdd, t1dd, t2dd = np.linalg.solve(A, b_vec)
        return [Xd, w1, w2, Xdd, t1dd, t2dd]

    t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
    y0 = [params.X0, params.theta1_0, params.theta2_0,
          params.Xdot0, params.w1_0, params.w2_0]
    sol = solve_ivp(ode, (0.0, duration), y0, t_eval=t_eval,
                    method="RK45", rtol=1e-9, atol=1e-11)
    return sol.t, sol.y


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: CartTwoMetronomesParams,
    output_path: str,
    fps: int = 30,
) -> None:
    X_arr, t1_arr, t2_arr = y[0], y[1], y[2]
    L1, L2 = params.L_1, params.L_2
    dx1, dx2 = params.dx_1, params.dx_2
    h_pivot = params.h_pivot
    m1, m2 = params.m_1, params.m_2

    cart_w, cart_h = 0.9, 0.20
    track_y = 0.0
    cart_bottom = 0.02
    beam_y = cart_bottom + cart_h

    x1_max_swing = float(np.max(np.abs(L1 * np.sin(t1_arr))))
    x2_max_swing = float(np.max(np.abs(L2 * np.sin(t2_arr))))
    x_extent = max(np.max(np.abs(X_arr)) + cart_w / 2.0,
                   np.max(np.abs(X_arr + dx1)) + x1_max_swing,
                   np.max(np.abs(X_arr + dx2)) + x2_max_swing) + 0.30
    xlim = (-x_extent, x_extent)
    ylim = (-0.25, h_pivot + 0.25)

    fig, ax = plt.subplots(figsize=(9, 5), facecolor="#1a1a2e")
    ax.set_facecolor("#16213e")
    ax.set_xlim(*xlim); ax.set_ylim(*ylim)
    ax.set_aspect("equal"); ax.axis("off")
    ax.axhline(track_y, color="#4a4e69", lw=1.5, zorder=1)
    tick_xs = np.arange(np.ceil(xlim[0]), np.floor(xlim[1]) + 1e-9, 0.25)
    for tx in tick_xs:
        ax.plot([tx, tx], [track_y - 0.04, track_y], color="#4a4e69", lw=1.0, zorder=1)

    cart_patch = patches.FancyBboxPatch(
        (-cart_w / 2.0, cart_bottom), cart_w, cart_h,
        boxstyle="round,pad=0.01", linewidth=1.5,
        edgecolor="white", facecolor="#8ecae6", zorder=3,
    )
    ax.add_patch(cart_patch)
    beam_line, = ax.plot([], [], "-", color="#cdd5e0", lw=1.5, zorder=3)
    pivot1_dot, = ax.plot([], [], "o", color="white", ms=5, zorder=6)
    pivot2_dot, = ax.plot([], [], "o", color="white", ms=5, zorder=6)
    rod1, = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=4)
    rod2, = ax.plot([], [], "-", color="#ffd166", lw=2.5, zorder=4)
    ms_ref = 14.0
    bob1_ms = ms_ref * (m1 / max(m1, m2)) ** (1.0 / 3.0)
    bob2_ms = ms_ref * (m2 / max(m1, m2)) ** (1.0 / 3.0)
    bob1, = ax.plot([], [], "o", color="#e63946", ms=bob1_ms, zorder=5)
    bob2, = ax.plot([], [], "o", color="#ef476f", ms=bob2_ms, zorder=5)

    def update(f):
        cx = X_arr[f]
        cart_patch.set_x(cx - cart_w / 2.0)
        p1x = cx + dx1; p2x = cx + dx2; py = h_pivot
        beam_line.set_data([p1x, p1x, p2x, p2x],
                           [beam_y, py, py, beam_y])
        pivot1_dot.set_data([p1x], [py])
        pivot2_dot.set_data([p2x], [py])
        b1x = p1x + L1 * np.sin(t1_arr[f]); b1y = py - L1 * np.cos(t1_arr[f])
        b2x = p2x + L2 * np.sin(t2_arr[f]); b2y = py - L2 * np.cos(t2_arr[f])
        rod1.set_data([p1x, b1x], [py, b1y])
        rod2.set_data([p2x, b2x], [py, b2y])
        bob1.set_data([b1x], [b1y]); bob2.set_data([b2x], [b2y])
        return cart_patch, beam_line, pivot1_dot, pivot2_dot, rod1, rod2, bob1, bob2

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0 / fps, blit=False)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: CartTwoMetronomesParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""
Cart with Two Pendulums (Huygens-coupled metronomes) — auto-generated.
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

g       = {p["g"]}
M       = {p["M"]}
m1      = {p["m_1"]}
m2      = {p["m_2"]}
L1      = {p["L_1"]}
L2      = {p["L_2"]}
b1      = {p["b_1"]}
b2      = {p["b_2"]}
dx1     = {p["dx_1"]}
dx2     = {p["dx_2"]}
h_pivot = {p["h_pivot"]}
X0      = {p["X0"]}
theta1_0= {p["theta1_0"]}
theta2_0= {p["theta2_0"]}
Xdot0   = {p["Xdot0"]}
w1_0    = {p["w1_0"]}
w2_0    = {p["w2_0"]}
duration= {duration}
M_tot   = M + m1 + m2

def ode(t, y):
    X, t1, t2, Xd, w1, w2 = y
    c1, s1 = np.cos(t1), np.sin(t1)
    c2, s2 = np.cos(t2), np.sin(t2)
    A = np.array([
        [M_tot,            m1 * L1 * c1,    m2 * L2 * c2  ],
        [m1 * L1 * c1,     m1 * L1 * L1,    0.0           ],
        [m2 * L2 * c2,     0.0,             m2 * L2 * L2  ],
    ])
    b_vec = np.array([
        m1 * L1 * s1 * w1 * w1 + m2 * L2 * s2 * w2 * w2,
        -m1 * g * L1 * s1 - b1 * w1,
        -m2 * g * L2 * s2 - b2 * w2,
    ])
    Xdd, t1dd, t2dd = np.linalg.solve(A, b_vec)
    return [Xd, w1, w2, Xdd, t1dd, t2dd]

fps = 30
t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
y0 = [X0, theta1_0, theta2_0, Xdot0, w1_0, w2_0]
sol = solve_ivp(ode, (0.0, duration), y0, t_eval=t_eval,
                method="RK45", rtol=1e-9, atol=1e-11)
X_arr  = sol.y[0]; t1_arr = sol.y[1]; t2_arr = sol.y[2]

cart_w, cart_h = 0.9, 0.20
cart_bottom = 0.02
beam_y = cart_bottom + cart_h
x1_max_swing = np.max(np.abs(L1 * np.sin(t1_arr)))
x2_max_swing = np.max(np.abs(L2 * np.sin(t2_arr)))
x_extent = max(np.max(np.abs(X_arr)) + cart_w / 2.0,
               np.max(np.abs(X_arr + dx1)) + x1_max_swing,
               np.max(np.abs(X_arr + dx2)) + x2_max_swing) + 0.30
xlim = (-x_extent, x_extent); ylim = (-0.25, h_pivot + 0.25)

fig, ax = plt.subplots(figsize=(9, 5), facecolor="#1a1a2e")
ax.set_facecolor("#16213e")
ax.set_xlim(*xlim); ax.set_ylim(*ylim)
ax.set_aspect("equal"); ax.axis("off")
ax.axhline(0.0, color="#4a4e69", lw=1.5, zorder=1)
for tx in np.arange(np.ceil(xlim[0]), np.floor(xlim[1]) + 1e-9, 0.25):
    ax.plot([tx, tx], [-0.04, 0.0], color="#4a4e69", lw=1.0, zorder=1)
cart_patch = patches.FancyBboxPatch(
    (-cart_w / 2.0, cart_bottom), cart_w, cart_h,
    boxstyle="round,pad=0.01", linewidth=1.5,
    edgecolor="white", facecolor="#8ecae6", zorder=3,
)
ax.add_patch(cart_patch)
beam_line, = ax.plot([], [], "-", color="#cdd5e0", lw=1.5, zorder=3)
pivot1_dot, = ax.plot([], [], "o", color="white", ms=5, zorder=6)
pivot2_dot, = ax.plot([], [], "o", color="white", ms=5, zorder=6)
rod1, = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=4)
rod2, = ax.plot([], [], "-", color="#ffd166", lw=2.5, zorder=4)
ms_ref = 14.0
bob1_ms = ms_ref * (m1 / max(m1, m2)) ** (1.0 / 3.0)
bob2_ms = ms_ref * (m2 / max(m1, m2)) ** (1.0 / 3.0)
bob1, = ax.plot([], [], "o", color="#e63946", ms=bob1_ms, zorder=5)
bob2, = ax.plot([], [], "o", color="#ef476f", ms=bob2_ms, zorder=5)

def update(f):
    cx = X_arr[f]
    cart_patch.set_x(cx - cart_w / 2.0)
    p1x = cx + dx1; p2x = cx + dx2; py = h_pivot
    beam_line.set_data([p1x, p1x, p2x, p2x], [beam_y, py, py, beam_y])
    pivot1_dot.set_data([p1x], [py]); pivot2_dot.set_data([p2x], [py])
    b1x = p1x + L1 * np.sin(t1_arr[f]); b1y = py - L1 * np.cos(t1_arr[f])
    b2x = p2x + L2 * np.sin(t2_arr[f]); b2y = py - L2 * np.cos(t2_arr[f])
    rod1.set_data([p1x, b1x], [py, b1y])
    rod2.set_data([p2x, b2x], [py, b2y])
    bob1.set_data([b1x], [b1y]); bob2.set_data([b2x], [b2y])
    return cart_patch, beam_line, pivot1_dot, pivot2_dot, rod1, rod2, bob1, bob2

ani = animation.FuncAnimation(fig, update, frames=len(sol.t), interval=1000.0/fps, blit=False)
ani.save("cart_two_metronomes.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close(); print("Saved cart_two_metronomes.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Cart with Two Metronomes")
    parser.add_argument("--g", type=float, default=9.8)
    parser.add_argument("--M", type=float, default=3.0)
    parser.add_argument("--m_1", type=float, default=0.45)
    parser.add_argument("--m_2", type=float, default=0.85)
    parser.add_argument("--L_1", type=float, default=0.40)
    parser.add_argument("--L_2", type=float, default=0.60)
    parser.add_argument("--b_1", type=float, default=0.0040)
    parser.add_argument("--b_2", type=float, default=0.0070)
    parser.add_argument("--dx_1", type=float, default=-0.30)
    parser.add_argument("--dx_2", type=float, default=0.30)
    parser.add_argument("--h_pivot", type=float, default=0.95)
    parser.add_argument("--X0", type=float, default=0.0)
    parser.add_argument("--theta1_0", type=float, default=0.45)
    parser.add_argument("--theta2_0", type=float, default=-0.55)
    parser.add_argument("--Xdot0", type=float, default=0.0)
    parser.add_argument("--w1_0", type=float, default=0.0)
    parser.add_argument("--w2_0", type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="cart_two_metronomes.mp4")
    args = parser.parse_args()

    p = CartTwoMetronomesParams(
        g=args.g, M=args.M, m_1=args.m_1, m_2=args.m_2,
        L_1=args.L_1, L_2=args.L_2, b_1=args.b_1, b_2=args.b_2,
        dx_1=args.dx_1, dx_2=args.dx_2, h_pivot=args.h_pivot,
        X0=args.X0, theta1_0=args.theta1_0, theta2_0=args.theta2_0,
        Xdot0=args.Xdot0, w1_0=args.w1_0, w2_0=args.w2_0,
    )
    print(f"Simulating cart_two_metronomes: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
