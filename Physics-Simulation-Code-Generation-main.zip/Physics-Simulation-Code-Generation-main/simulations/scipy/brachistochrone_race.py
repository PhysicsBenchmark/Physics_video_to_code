"""
Brachistochrone Race Simulation
================================
Two beads slide frictionlessly under gravity from A=(0,H) on a vertical wall to
B=(D,0) on a horizontal floor:
  (1) along the straight chord A→B   (constant along-ramp acceleration g·H/L)
  (2) along the brachistochrone cycloid (cusp at A) — the time-minimising path

  Cycloid:  x(θ)=R(θ-sin θ),  y(θ)=H-R(1-cos θ),  θ∈[0,θ_e]
  Endpoint:  (θ_e-sin θ_e)/(1-cos θ_e) = D/H,   R = H/(1-cos θ_e)
  Time:      θ(t)=√(g/R)·t,   T_brach = √(R/g)·θ_e
"""

from __future__ import annotations
import numpy as np
from scipy.optimize import brentq
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class BrachistochroneRaceParams:
    H: float = 2.0
    D: float = 3.5
    g: float = 9.8
    ball_radius: float = 0.10


def _solve_cycloid(H: float, D: float):
    def f_theta(th):
        return (th - np.sin(th)) / (1.0 - np.cos(th)) - D / H

    theta_e = brentq(f_theta, 1e-6, 2.0 * np.pi - 1e-6, xtol=1e-12)
    R = H / (1.0 - np.cos(theta_e))
    return theta_e, R


def simulate(
    params: BrachistochroneRaceParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    H, D, g = params.H, params.D, params.g
    theta_e, R = _solve_cycloid(H, D)
    T_brach = np.sqrt(R / g) * theta_e
    L_chord = np.sqrt(D * D + H * H)
    a_str = g * H / L_chord

    t_eval = np.linspace(0, duration, int(duration * fps) + 1)

    omega_cyc = np.sqrt(g / R)
    theta_t = np.minimum(omega_cyc * t_eval, theta_e)
    x_cyc = R * (theta_t - np.sin(theta_t))
    y_cyc = H - R * (1.0 - np.cos(theta_t))

    s_t = np.minimum(0.5 * a_str * t_eval * t_eval, L_chord)
    x_str = (D / L_chord) * s_t
    y_str = H - (H / L_chord) * s_t

    y = np.vstack([x_cyc, y_cyc, x_str, y_str])
    return t_eval, y


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: BrachistochroneRaceParams,
    output_path: str,
    fps: int = 30,
) -> None:
    H, D = params.H, params.D
    x_cyc, y_cyc, x_str, y_str = y[0], y[1], y[2], y[3]
    theta_e, R = _solve_cycloid(H, D)
    th_track = np.linspace(0.0, theta_e, 240)
    x_track = R * (th_track - np.sin(th_track))
    y_track = H - R * (1.0 - np.cos(th_track))

    fig_w, fig_h = 10, 6
    fig_aspect = fig_w / fig_h
    xpad, ypad = 0.55, 0.45
    x_lo_d = -xpad
    x_hi_d = D + xpad
    y_lo_d = -ypad
    y_hi_d = H + ypad
    dx_v, dy_v = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_v / dy_v < fig_aspect:
        extra = (fig_aspect * dy_v - dx_v) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
    else:
        extra = (dx_v / fig_aspect - dy_v) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi)
    ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal")
    ax.axis("off")

    wall = patches.Rectangle((x_lo, y_lo), -x_lo, y_hi - y_lo,
                             facecolor="#4a4e69", edgecolor="none", zorder=0)
    floor = patches.Rectangle((0.0, y_lo), x_hi, -y_lo,
                              facecolor="#4a4e69", edgecolor="none",
                              alpha=0.55, zorder=0)
    ax.add_patch(wall)
    ax.add_patch(floor)
    ax.plot([0.0, x_hi], [0.0, 0.0], color="#adb5bd", lw=2.5, zorder=1)
    ax.plot([0.0, 0.0], [y_lo, y_hi], color="#adb5bd", lw=2.5, zorder=1)
    ax.plot([0.0, D], [H, 0.0], "-", color="#a8dadc", lw=2.5,
            solid_capstyle="round", zorder=2)
    ax.plot(x_track, y_track, "-", color="#f4d35e", lw=2.5,
            solid_capstyle="round", zorder=2)
    ax.plot([0.0], [H], "o", color="#adb5bd", ms=6, zorder=3)
    ax.plot([D], [0.0], "o", color="#adb5bd", ms=6, zorder=3)

    trail_str, = ax.plot([], [], "-", color="#e63946", alpha=0.45, lw=1.6, zorder=3)
    trail_cyc, = ax.plot([], [], "-", color="#f4d35e", alpha=0.45, lw=1.6, zorder=3)
    tx_s, ty_s, tx_c, ty_c = [], [], [], []

    ball_r = params.ball_radius
    ball_str = plt.Circle((x_str[0], y_str[0]), ball_r, facecolor="#e63946",
                          edgecolor="white", lw=1.4, zorder=5)
    ball_cyc = plt.Circle((x_cyc[0], y_cyc[0]), ball_r, facecolor="#f4d35e",
                          edgecolor="white", lw=1.4, zorder=5)
    ax.add_patch(ball_str)
    ax.add_patch(ball_cyc)

    def update(f):
        ball_str.set_center((x_str[f], y_str[f]))
        ball_cyc.set_center((x_cyc[f], y_cyc[f]))
        tx_s.append(x_str[f]); ty_s.append(y_str[f])
        tx_c.append(x_cyc[f]); ty_c.append(y_cyc[f])
        if len(tx_s) > 60:
            tx_s.pop(0); ty_s.pop(0)
        if len(tx_c) > 60:
            tx_c.pop(0); ty_c.pop(0)
        trail_str.set_data(tx_s, ty_s)
        trail_cyc.set_data(tx_c, ty_c)
        return ball_str, ball_cyc, trail_str, trail_cyc

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000 / fps, blit=True)
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: BrachistochroneRaceParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""
Brachistochrone Race — auto-generated simulation script.
"""
import numpy as np
from scipy.optimize import brentq
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

H = {p["H"]}
D = {p["D"]}
g = {p["g"]}
ball_radius = {p["ball_radius"]}
duration = {duration}
fps = 30

def f_theta(th):
    return (th - np.sin(th)) / (1.0 - np.cos(th)) - D / H

theta_e = brentq(f_theta, 1e-6, 2.0 * np.pi - 1e-6, xtol=1e-12)
R = H / (1.0 - np.cos(theta_e))
T_brach = np.sqrt(R / g) * theta_e
L_chord = np.sqrt(D * D + H * H)
T_straight = np.sqrt(2.0 * L_chord * L_chord / (g * H))

t_eval = np.linspace(0, duration, int(duration * fps) + 1)
omega_cyc = np.sqrt(g / R)
theta_t = np.minimum(omega_cyc * t_eval, theta_e)
x_cyc = R * (theta_t - np.sin(theta_t))
y_cyc = H - R * (1.0 - np.cos(theta_t))

a_straight = g * H / L_chord
s_t = np.minimum(0.5 * a_straight * t_eval * t_eval, L_chord)
x_str = (D / L_chord) * s_t
y_str = H - (H / L_chord) * s_t

th_track = np.linspace(0.0, theta_e, 240)
x_track = R * (th_track - np.sin(th_track))
y_track = H - R * (1.0 - np.cos(th_track))

fig_w, fig_h = 10, 6
fig_aspect = fig_w / fig_h
xpad, ypad = 0.55, 0.45
x_lo_d, x_hi_d, y_lo_d, y_hi_d = -xpad, D + xpad, -ypad, H + ypad
dx_v, dy_v = x_hi_d - x_lo_d, y_hi_d - y_lo_d
if dx_v / dy_v < fig_aspect:
    extra = (fig_aspect * dy_v - dx_v) / 2.0
    x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
else:
    extra = (dx_v / fig_aspect - dy_v) / 2.0
    x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0, 0, 1, 1])
ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")
wall = patches.Rectangle((x_lo, y_lo), -x_lo, y_hi - y_lo, facecolor="#4a4e69", edgecolor="none", zorder=0)
floor = patches.Rectangle((0.0, y_lo), x_hi, -y_lo, facecolor="#4a4e69", edgecolor="none", alpha=0.55, zorder=0)
ax.add_patch(wall); ax.add_patch(floor)
ax.plot([0.0, x_hi], [0.0, 0.0], color="#adb5bd", lw=2.5, zorder=1)
ax.plot([0.0, 0.0], [y_lo, y_hi], color="#adb5bd", lw=2.5, zorder=1)
ax.plot([0.0, D], [H, 0.0], "-", color="#a8dadc", lw=2.5, zorder=2)
ax.plot(x_track, y_track, "-", color="#f4d35e", lw=2.5, zorder=2)
ax.plot([0.0], [H], "o", color="#adb5bd", ms=6, zorder=3)
ax.plot([D], [0.0], "o", color="#adb5bd", ms=6, zorder=3)

trail_str, = ax.plot([], [], "-", color="#e63946", alpha=0.45, lw=1.6, zorder=3)
trail_cyc, = ax.plot([], [], "-", color="#f4d35e", alpha=0.45, lw=1.6, zorder=3)
tx_s, ty_s, tx_c, ty_c = [], [], [], []
ball_str = plt.Circle((x_str[0], y_str[0]), ball_radius, facecolor="#e63946", edgecolor="white", lw=1.4, zorder=5)
ball_cyc = plt.Circle((x_cyc[0], y_cyc[0]), ball_radius, facecolor="#f4d35e", edgecolor="white", lw=1.4, zorder=5)
ax.add_patch(ball_str); ax.add_patch(ball_cyc)

def update(f):
    ball_str.set_center((x_str[f], y_str[f]))
    ball_cyc.set_center((x_cyc[f], y_cyc[f]))
    tx_s.append(x_str[f]); ty_s.append(y_str[f])
    tx_c.append(x_cyc[f]); ty_c.append(y_cyc[f])
    if len(tx_s) > 60: tx_s.pop(0); ty_s.pop(0)
    if len(tx_c) > 60: tx_c.pop(0); ty_c.pop(0)
    trail_str.set_data(tx_s, ty_s)
    trail_cyc.set_data(tx_c, ty_c)
    return ball_str, ball_cyc, trail_str, trail_cyc

ani = animation.FuncAnimation(fig, update, frames=len(t_eval), interval=1000/fps, blit=True)
ani.save("brachistochrone_race.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved brachistochrone_race.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Brachistochrone Race")
    parser.add_argument("--H", type=float, default=2.0)
    parser.add_argument("--D", type=float, default=3.5)
    parser.add_argument("--g", type=float, default=9.8)
    parser.add_argument("--ball_radius", type=float, default=0.10)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="brachistochrone_race.mp4")
    args = parser.parse_args()

    p = BrachistochroneRaceParams(H=args.H, D=args.D, g=args.g,
                                  ball_radius=args.ball_radius)
    print(f"Simulating brachistochrone race: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
