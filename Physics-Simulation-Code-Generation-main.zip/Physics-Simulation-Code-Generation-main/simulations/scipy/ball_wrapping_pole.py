"""
Ball Wrapping Pole — top-down view of a tethered ball wrapping around a pole.
Closed-form: phi(t) = (L_0 - sqrt(L_0^2 - 2 R_pole v_0 t)) / R_pole.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Circle
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class BallWrappingPoleParams:
    R_pole: float = 0.10
    L_0: float = 1.50
    v_0: float = 2.00
    m: float = 0.30
    duration: float = 8.0


def simulate(params: BallWrappingPoleParams, duration: float = 8.0, fps: int = 30):
    p = params
    t_wrap = p.L_0 ** 2 / (2.0 * p.R_pole * p.v_0)
    n = int(duration * fps) + 1
    t = np.linspace(0.0, duration, n)
    t_clip = np.minimum(t, t_wrap)
    phi = (p.L_0 - np.sqrt(np.maximum(p.L_0 ** 2 - 2.0 * p.R_pole * p.v_0 * t_clip, 0.0))) / p.R_pole
    L = np.maximum(p.L_0 - p.R_pole * phi, 0.0)
    bx = p.R_pole * np.cos(phi) - L * np.sin(phi)
    by = p.R_pole * np.sin(phi) + L * np.cos(phi)
    return t, np.stack([phi, L, bx, by])


def render_video(t, y, params: BallWrappingPoleParams, output_path: str, fps: int = 30):
    p = params
    phi_arr, L_arr, bx_arr, by_arr = y[0], y[1], y[2], y[3]
    phi_max = p.L_0 / p.R_pole

    W, H = 6.0, 5.0
    fig = plt.figure(figsize=(W, H), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_aspect("equal"); ax.axis("off")
    extent = p.R_pole + p.L_0 + 0.30
    aspect = W / H
    dx = 2.0 * extent; dy = 2.0 * extent
    if dx / dy < aspect:
        extra = (aspect * dy - dx) / 2.0
        ax.set_xlim(-extent - extra, extent + extra)
        ax.set_ylim(-extent, extent)
    else:
        extra = (dx / aspect - dy) / 2.0
        ax.set_xlim(-extent, extent)
        ax.set_ylim(-extent - extra, extent + extra)

    xlim = ax.get_xlim(); ylim = ax.get_ylim()
    rng = np.random.default_rng(11)
    sx = rng.uniform(xlim[0], xlim[1], size=140)
    sy = rng.uniform(ylim[0], ylim[1], size=140)
    ss = rng.uniform(0.6, 3.0, size=140) ** 2
    sa = rng.uniform(0.25, 0.75, size=140)
    ax.scatter(sx, sy, s=ss, c="white", alpha=sa, zorder=0, edgecolors='none')

    pole_patch = Circle((0.0, 0.0), p.R_pole, facecolor="#7c552d",
                        edgecolor="white", lw=1.2, zorder=2)
    ax.add_patch(pole_patch)
    n_ticks = 12
    for k in range(n_ticks):
        a = 2.0 * np.pi * k / n_ticks
        r_in = 0.55 * p.R_pole; r_out = 0.95 * p.R_pole
        ax.plot([r_in * np.cos(a), r_out * np.cos(a)],
                [r_in * np.sin(a), r_out * np.sin(a)],
                color="#3a2615", lw=0.8, zorder=3)

    ax.plot([p.R_pole], [0.0], 'o', color="#f1c453", markersize=4.0,
            markeredgecolor="white", markeredgewidth=0.6, zorder=4)
    wrap_line, = ax.plot([], [], '-', color="#e0e0e0", lw=1.5, zorder=5)
    free_line, = ax.plot([], [], '-', color="#e0e0e0", lw=1.5, zorder=5)
    trail_len = 120
    trail_line, = ax.plot([], [], '-', color="#e63946", lw=1.4, alpha=0.55, zorder=6)
    ball_marker, = ax.plot([], [], 'o', color="#e63946", markersize=8.5,
                           markeredgecolor="white", markeredgewidth=1.0, zorder=7)
    ARC_PTS = 60

    def update(f):
        phi = float(phi_arr[f])
        bx = float(bx_arr[f]); by = float(by_arr[f])
        if phi > 1e-9:
            a_arr = np.linspace(0.0, phi, max(2, int(ARC_PTS * phi / phi_max) + 2))
            wrap_line.set_data(p.R_pole * np.cos(a_arr), p.R_pole * np.sin(a_arr))
        else:
            wrap_line.set_data([p.R_pole], [0.0])
        wpx = p.R_pole * np.cos(phi); wpy = p.R_pole * np.sin(phi)
        free_line.set_data([wpx, bx], [wpy, by])
        ball_marker.set_data([bx], [by])
        lo = max(0, f - trail_len + 1)
        trail_line.set_data(bx_arr[lo:f+1], by_arr[lo:f+1])
        return wrap_line, free_line, trail_line, ball_marker

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0/fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=2400), dpi=120)
    plt.close(fig)


def make_standalone_script(params: BallWrappingPoleParams, duration: float = 8.0) -> str:
    p = asdict(params)
    return f'''"""Ball wrapping pole - standalone script."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Circle

R_pole = {p["R_pole"]}
L_0 = {p["L_0"]}
v_0 = {p["v_0"]}
m = {p["m"]}
duration = {duration}
fps = 30
t_wrap = L_0 ** 2 / (2.0 * R_pole * v_0)
phi_max = L_0 / R_pole

n_frames = int(duration * fps) + 1
t_arr = np.linspace(0.0, duration, n_frames)
t_clip = np.minimum(t_arr, t_wrap)
phi_arr = (L_0 - np.sqrt(np.maximum(L_0 ** 2 - 2.0 * R_pole * v_0 * t_clip, 0.0))) / R_pole
L_arr = np.maximum(L_0 - R_pole * phi_arr, 0.0)
bx_arr = R_pole * np.cos(phi_arr) - L_arr * np.sin(phi_arr)
by_arr = R_pole * np.sin(phi_arr) + L_arr * np.cos(phi_arr)

W, H = 6.0, 5.0
fig = plt.figure(figsize=(W, H), facecolor="#1a1a2e")
ax = fig.add_axes([0, 0, 1, 1])
ax.set_facecolor("#16213e"); ax.set_aspect("equal"); ax.axis("off")
extent = R_pole + L_0 + 0.30
aspect = W / H
dx = 2.0 * extent; dy = 2.0 * extent
if dx / dy < aspect:
    extra = (aspect * dy - dx) / 2.0
    ax.set_xlim(-extent - extra, extent + extra); ax.set_ylim(-extent, extent)
else:
    extra = (dx / aspect - dy) / 2.0
    ax.set_xlim(-extent, extent); ax.set_ylim(-extent - extra, extent + extra)

xlim = ax.get_xlim(); ylim = ax.get_ylim()
rng = np.random.default_rng(11)
sx = rng.uniform(xlim[0], xlim[1], size=140)
sy = rng.uniform(ylim[0], ylim[1], size=140)
ss = rng.uniform(0.6, 3.0, size=140) ** 2
sa = rng.uniform(0.25, 0.75, size=140)
ax.scatter(sx, sy, s=ss, c="white", alpha=sa, zorder=0, edgecolors='none')

pole_patch = Circle((0.0, 0.0), R_pole, facecolor="#7c552d",
                    edgecolor="white", lw=1.2, zorder=2)
ax.add_patch(pole_patch)
for k in range(12):
    a = 2.0 * np.pi * k / 12
    r_in = 0.55 * R_pole; r_out = 0.95 * R_pole
    ax.plot([r_in * np.cos(a), r_out * np.cos(a)],
            [r_in * np.sin(a), r_out * np.sin(a)],
            color="#3a2615", lw=0.8, zorder=3)

ax.plot([R_pole], [0.0], 'o', color="#f1c453", markersize=4.0,
        markeredgecolor="white", markeredgewidth=0.6, zorder=4)
wrap_line, = ax.plot([], [], '-', color="#e0e0e0", lw=1.5, zorder=5)
free_line, = ax.plot([], [], '-', color="#e0e0e0", lw=1.5, zorder=5)
trail_line, = ax.plot([], [], '-', color="#e63946", lw=1.4, alpha=0.55, zorder=6)
ball_marker, = ax.plot([], [], 'o', color="#e63946", markersize=8.5,
                       markeredgecolor="white", markeredgewidth=1.0, zorder=7)
ARC_PTS = 60
trail_len = 120

def update(f):
    phi = float(phi_arr[f])
    bx = float(bx_arr[f]); by = float(by_arr[f])
    if phi > 1e-9:
        a_arr = np.linspace(0.0, phi, max(2, int(ARC_PTS * phi / phi_max) + 2))
        wrap_line.set_data(R_pole * np.cos(a_arr), R_pole * np.sin(a_arr))
    else:
        wrap_line.set_data([R_pole], [0.0])
    wpx = R_pole * np.cos(phi); wpy = R_pole * np.sin(phi)
    free_line.set_data([wpx, bx], [wpy, by])
    ball_marker.set_data([bx], [by])
    lo = max(0, f - trail_len + 1)
    trail_line.set_data(bx_arr[lo:f+1], by_arr[lo:f+1])
    return wrap_line, free_line, trail_line, ball_marker

ani = animation.FuncAnimation(fig, update, frames=n_frames,
                              interval=1000.0/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=2400), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    p = BallWrappingPoleParams()
    t, y = simulate(p, duration=p.duration)
    render_video(t, y, p, "video.mp4")
