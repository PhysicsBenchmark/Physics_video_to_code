"""
Block-Belt-Spring Stick-Slip Oscillator — closed-form phased simulation.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle
from matplotlib.collections import LineCollection
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class BlockBeltSpringStickslipParams:
    g: float = 9.8
    m: float = 1.0
    s: float = 0.20
    k: float = 10.0
    L_s: float = 0.50
    mu_s: float = 0.40
    mu_k: float = 0.30
    v_belt: float = 0.20
    x_eq: float = 0.0
    duration: float = 12.0


def _segments(p):
    omega = np.sqrt(p.k / p.m)
    x_break = p.x_eq - p.mu_s * p.m * p.g / p.k
    x_new = p.x_eq - p.mu_k * p.m * p.g / p.k
    EPS = 1e-12
    segments = []
    t_cur = 0.0; x_cur = p.x_eq; phase = "stick"
    for _ in range(1000):
        if t_cur >= p.duration - EPS: break
        if phase == "stick":
            dx_to_break = x_cur - x_break
            t_end = t_cur + (dx_to_break / p.v_belt if dx_to_break > EPS else 0.0)
            t_end_clipped = min(t_end, p.duration)
            segments.append({"kind": "stick", "t0": t_cur, "t1": t_end_clipped, "x0": x_cur})
            if t_end >= p.duration - EPS: break
            t_cur = t_end; x_cur = x_break; phase = "slip"
            continue
        A = x_break - x_new
        B = -p.v_belt / omega
        half = np.arctan2(-A, B)
        if half <= 0: half += np.pi
        t_slip_dur = 2.0 * half / omega
        u_end = A * np.cos(omega * t_slip_dur) + B * np.sin(omega * t_slip_dur)
        x_slip_end = x_new + u_end
        t_end = t_cur + t_slip_dur
        t_end_clipped = min(t_end, p.duration)
        segments.append({"kind": "slip", "t0": t_cur, "t1": t_end_clipped,
                         "x0": x_break, "A": A, "B": B})
        if t_end >= p.duration - EPS: break
        t_cur = t_end; x_cur = x_slip_end; phase = "stick"
    return segments, omega, x_new


def simulate(params: BlockBeltSpringStickslipParams, duration: float = 12.0, fps: int = 30):
    if duration is not None: params.duration = duration
    segs, omega, x_new = _segments(params)
    n = int(params.duration * fps) + 1
    t = np.linspace(0.0, params.duration, n)
    x_arr = np.zeros(n)
    for i, ti in enumerate(t):
        for seg in segs:
            if seg["t0"] - 1e-12 <= ti <= seg["t1"] + 1e-12:
                tau = ti - seg["t0"]
                if seg["kind"] == "stick":
                    x_arr[i] = seg["x0"] - params.v_belt * tau
                else:
                    u = seg["A"] * np.cos(omega * tau) + seg["B"] * np.sin(omega * tau)
                    x_arr[i] = x_new + u
                break
    return t, np.stack([x_arr])


def render_video(t, y, params: BlockBeltSpringStickslipParams,
                 output_path: str, fps: int = 30):
    p = params
    x_arr = y[0]
    x_wall = p.x_eq + p.s / 2 + p.L_s
    belt_thickness = 0.10
    y_belt_top = 0.0
    y_block_bottom = y_belt_top
    y_block_top = y_block_bottom + p.s
    x_min_block = float(min(x_arr.min(), p.x_eq - p.mu_s * p.m * p.g / p.k))
    x_belt_left = x_min_block - 0.40 - p.s/2
    x_belt_right = x_wall

    fig_w, fig_h = 10.0, 5.0
    fig_aspect = fig_w / fig_h
    x_lo_d = x_belt_left - 0.05; x_hi_d = x_wall + 0.20
    y_lo_d = -belt_thickness - 0.20; y_hi_d = y_block_top + 0.60
    dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_d / dy_d < fig_aspect:
        extra = (fig_aspect * dy_d - dx_d) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx_d / fig_aspect - dy_d) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    ax.add_patch(Rectangle((x_belt_left, y_belt_top - belt_thickness),
                           x_belt_right - x_belt_left, belt_thickness,
                           facecolor="#4a4e69", edgecolor="none", zorder=1))
    ax.plot([x_belt_left, x_belt_right], [y_belt_top, y_belt_top],
            color="#adb5bd", lw=2.0, zorder=2)
    ax.plot([x_belt_left, x_belt_right],
            [y_belt_top - belt_thickness, y_belt_top - belt_thickness],
            color="#adb5bd", lw=1.5, zorder=2)
    wall_w = 0.10
    ax.add_patch(Rectangle((x_wall, y_lo), wall_w, y_hi - y_lo,
                           facecolor="#adb5bd", edgecolor="none", zorder=1))

    hash_lc = LineCollection([], colors="#adb5bd", linewidths=2.0, zorder=3)
    ax.add_collection(hash_lc)
    block_patch = Rectangle((p.x_eq - p.s/2, y_block_bottom), p.s, p.s,
                            facecolor="#8ecae6", edgecolor="white", lw=1.5, zorder=5)
    ax.add_patch(block_patch)
    spring_line, = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=4)
    n_zigzag = 12; zigzag_amp = 0.06

    def spring_path(x_left, x_right, y_centre):
        if x_right - x_left < 1e-3:
            return np.array([x_left, x_right]), np.array([y_centre, y_centre])
        n_pts = n_zigzag * 2 + 3
        t_param = np.linspace(0.0, 1.0, n_pts)
        xs = x_left + t_param * (x_right - x_left)
        lead = 0.06
        env = np.where((t_param < lead) | (t_param > 1 - lead), 0.0,
                       np.sin(n_zigzag * 2.0 * np.pi *
                              (t_param - lead) / (1.0 - 2.0 * lead)))
        ys = y_centre + zigzag_amp * env
        return xs, ys

    hash_spacing = 0.30; hash_w = 0.025

    def update(f):
        ti = t[f]
        cx = x_arr[f]
        block_patch.set_xy((cx - p.s/2, y_block_bottom))
        sx, sy = spring_path(cx + p.s/2, x_wall, y_block_bottom + p.s/2)
        spring_line.set_data(sx, sy)
        s0 = (-p.v_belt * ti) % hash_spacing
        n_marks = int(np.ceil((x_belt_right - x_belt_left) / hash_spacing)) + 2
        segs = []
        for i in range(n_marks):
            x_m = x_belt_left + s0 + i * hash_spacing - hash_spacing
            if x_belt_left <= x_m <= x_belt_right:
                segs.append([(x_m, y_belt_top - hash_w), (x_m, y_belt_top + hash_w)])
        hash_lc.set_segments(segs)
        return block_patch, spring_line, hash_lc

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0/fps, blit=False)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: BlockBeltSpringStickslipParams,
                           duration: float = 12.0) -> str:
    p = asdict(params)
    p["duration"] = duration
    return f'''"""Block-belt-spring stick-slip - standalone script."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle
from matplotlib.collections import LineCollection

g = {p["g"]}; m = {p["m"]}; s = {p["s"]}; k = {p["k"]}
L_s = {p["L_s"]}; mu_s = {p["mu_s"]}; mu_k = {p["mu_k"]}
v_belt = {p["v_belt"]}; x_eq = {p["x_eq"]}
duration = {p["duration"]}; fps = 30

omega = np.sqrt(k / m)
x_break = x_eq - mu_s * m * g / k
x_new = x_eq - mu_k * m * g / k
x_wall = x_eq + s / 2 + L_s

EPS = 1e-12
segments = []
t_cur = 0.0; x_cur = x_eq; phase = "stick"
for _ in range(1000):
    if t_cur >= duration - EPS: break
    if phase == "stick":
        dx_to_break = x_cur - x_break
        t_end = t_cur + (dx_to_break / v_belt if dx_to_break > EPS else 0.0)
        t_end_clipped = min(t_end, duration)
        segments.append({{"kind": "stick", "t0": t_cur, "t1": t_end_clipped, "x0": x_cur}})
        if t_end >= duration - EPS: break
        t_cur = t_end; x_cur = x_break; phase = "slip"
        continue
    A = x_break - x_new
    B = -v_belt / omega
    half = np.arctan2(-A, B)
    if half <= 0: half += np.pi
    t_slip_dur = 2.0 * half / omega
    u_end = A * np.cos(omega * t_slip_dur) + B * np.sin(omega * t_slip_dur)
    x_slip_end = x_new + u_end
    t_end = t_cur + t_slip_dur
    t_end_clipped = min(t_end, duration)
    segments.append({{"kind": "slip", "t0": t_cur, "t1": t_end_clipped,
                     "x0": x_break, "A": A, "B": B}})
    if t_end >= duration - EPS: break
    t_cur = t_end; x_cur = x_slip_end; phase = "stick"


def block_x_at(t):
    for seg in segments:
        if seg["t0"] - EPS <= t <= seg["t1"] + EPS:
            tau = t - seg["t0"]
            if seg["kind"] == "stick":
                return seg["x0"] - v_belt * tau
            u = seg["A"] * np.cos(omega * tau) + seg["B"] * np.sin(omega * tau)
            return x_new + u
    seg = segments[-1]
    tau = seg["t1"] - seg["t0"]
    if seg["kind"] == "stick":
        return seg["x0"] - v_belt * tau
    u = seg["A"] * np.cos(omega * tau) + seg["B"] * np.sin(omega * tau)
    return x_new + u


t_grid = np.linspace(0.0, duration, int(duration * fps) + 1)
x_arr = np.array([block_x_at(t) for t in t_grid])
x_min_block = float(min(x_arr.min(), x_break))
belt_thickness = 0.10
y_belt_top = 0.0
y_block_bottom = y_belt_top
y_block_top = y_block_bottom + s
x_belt_left = x_min_block - 0.40 - s/2
x_belt_right = x_wall

fig_w, fig_h = 10.0, 5.0
fig_aspect = fig_w / fig_h
x_lo_d = x_belt_left - 0.05; x_hi_d = x_wall + 0.20
y_lo_d = -belt_thickness - 0.20; y_hi_d = y_block_top + 0.60
dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
if dx_d / dy_d < fig_aspect:
    extra = (fig_aspect * dy_d - dx_d) / 2.0
    x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
    y_lo, y_hi = y_lo_d, y_hi_d
else:
    extra = (dx_d / fig_aspect - dy_d) / 2.0
    x_lo, x_hi = x_lo_d, x_hi_d
    y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0, 0, 1, 1])
ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")

ax.add_patch(Rectangle((x_belt_left, y_belt_top - belt_thickness),
                       x_belt_right - x_belt_left, belt_thickness,
                       facecolor="#4a4e69", edgecolor="none", zorder=1))
ax.plot([x_belt_left, x_belt_right], [y_belt_top, y_belt_top],
        color="#adb5bd", lw=2.0, zorder=2)
ax.plot([x_belt_left, x_belt_right],
        [y_belt_top - belt_thickness, y_belt_top - belt_thickness],
        color="#adb5bd", lw=1.5, zorder=2)
wall_w = 0.10
ax.add_patch(Rectangle((x_wall, y_lo), wall_w, y_hi - y_lo,
                       facecolor="#adb5bd", edgecolor="none", zorder=1))

hash_spacing = 0.30; hash_w = 0.025
hash_lc = LineCollection([], colors="#adb5bd", linewidths=2.0, zorder=3)
ax.add_collection(hash_lc)
block_patch = Rectangle((x_eq - s/2, y_block_bottom), s, s,
                        facecolor="#8ecae6", edgecolor="white", lw=1.5, zorder=5)
ax.add_patch(block_patch)
spring_line, = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=4)
n_zigzag = 12; zigzag_amp = 0.06


def spring_path(x_left, x_right, y_centre):
    if x_right - x_left < 1e-3:
        return np.array([x_left, x_right]), np.array([y_centre, y_centre])
    n_pts = n_zigzag * 2 + 3
    t_param = np.linspace(0.0, 1.0, n_pts)
    xs = x_left + t_param * (x_right - x_left)
    lead = 0.06
    env = np.where((t_param < lead) | (t_param > 1 - lead), 0.0,
                   np.sin(n_zigzag * 2.0 * np.pi *
                          (t_param - lead) / (1.0 - 2.0 * lead)))
    ys = y_centre + zigzag_amp * env
    return xs, ys


def update(f):
    ti = f / fps
    cx = block_x_at(ti)
    block_patch.set_xy((cx - s/2, y_block_bottom))
    sx, sy = spring_path(cx + s/2, x_wall, y_block_bottom + s/2)
    spring_line.set_data(sx, sy)
    s0 = (-v_belt * ti) % hash_spacing
    n_marks = int(np.ceil((x_belt_right - x_belt_left) / hash_spacing)) + 2
    segs = []
    for i in range(n_marks):
        x_m = x_belt_left + s0 + i * hash_spacing - hash_spacing
        if x_belt_left <= x_m <= x_belt_right:
            segs.append([(x_m, y_belt_top - hash_w), (x_m, y_belt_top + hash_w)])
    hash_lc.set_segments(segs)
    return block_patch, spring_line, hash_lc


n_frames = int(duration * fps) + 1
ani = animation.FuncAnimation(fig, update, frames=n_frames,
                              interval=1000.0/fps, blit=False)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    p = BlockBeltSpringStickslipParams()
    t, y = simulate(p, duration=p.duration)
    render_video(t, y, p, "video.mp4")
