"""
Accelerating Cart with Sliding Mass(es) Inside
==============================================
A wheeled cart of mass M_cart slides on a horizontal frictionless track under a
prescribed sinusoidal external force F_ext(t) = F_amp · sin(ω_drive · t).

Inside the cart, N variable-shape objects (spheres, cuboids, spring-coupled
pairs) sit on the cart's interior floor.  Each interior body i has its own
Coulomb friction coefficient μ_i with the cart floor.  As the cart accelerates
back and forth, each body lags by the inertia–friction balance:
  • it sticks while  |a_cart| ≤ μ_i g
  • it slips otherwise (relative motion arises and kinetic friction acts).

Bodies bounce off the cart's interior walls and may collide pairwise.

Physical laws (one-dimensional, lab frame):
  • For each interior body i:
        m_i ẍ_i = − μ_i m_i g · tanh(α (v_i − v_cart))      (regularised Coulomb friction)
                  + Σ_j F_spring_{ij}                       (spring forces if part of a pair)
                  + Σ_w F_wall_{iw}                         (interior-wall penalty contacts)
                  + Σ_j F_body_{ij}                         (inter-body penalty contacts)
  • For the cart:
        M_cart ẍ_cart = F_ext(t)
                        + Σ_i [+ μ_i m_i g · tanh(α (v_i − v_cart))]    (Newton's 3rd)
                        − Σ_i [F_wall_{iw on body i}]                    (Newton's 3rd)
  • Total system CoM (Newton's 2nd law for the system):
        (M_cart + Σ m_i) ẍ_CoM = F_ext(t)
    All internal forces cancel by Newton's 3rd law, so internal friction
    only redistributes velocities between cart and bodies — it cannot move
    the system CoM.  When F_ext = 0 the CoM moves at constant velocity
    (linear-momentum conservation).

Numerical scheme:
  • Smooth tanh-regularised Coulomb friction (avoids the sign-discontinuity at
    v_rel = 0 that would break stiff ODE solvers).
  • Penalty-spring + critical-style damping for hard contacts at interior
    walls and between bodies.
  • LSODA integrator (auto-switches stiff/non-stiff to handle the contact-stiff
    intervals efficiently).

State vector: [x_cart, v_cart, x_b0, v_b0, x_b1, v_b1, ..., x_bN, v_bN]
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, field
from typing import List, Dict, Any
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis, spring_path


@dataclass
class AcceleratingCartSlidingMassParams:
    """
    Top-level controls (sample_params fills these):
      setup_seed   — int seed driving the randomized object layout
      M_cart       — cart mass (kg)
      F_amp        — amplitude of the sinusoidal external force on the cart (N)
      omega_drive  — angular frequency of the external force (rad/s)
      g            — gravitational acceleration (m/s²)
      alpha_tanh   — sharpness of the tanh-regularised friction (s/m)
      k_contact    — penalty stiffness for hard contacts (N/m)

    Structural fields auto-populated by __post_init__ from setup_seed:
      n_bodies, body_kinds, body_masses, body_mu, body_half_sizes,
      body_x0, body_v0, body_colors, spring_pairs, L_interior,
      cart_x0, cart_v0
    """
    setup_seed: float = 0.0
    M_cart: float = 5.0
    F_amp: float = 35.0
    omega_drive: float = 1.5
    g: float = 9.8
    alpha_tanh: float = 80.0
    k_contact: float = 4000.0

    # Auto-populated:
    n_bodies: int = 0
    body_kinds:      List[str]            = field(default_factory=list)
    body_masses:     List[float]          = field(default_factory=list)
    body_mu:         List[float]          = field(default_factory=list)
    body_half_sizes: List[float]          = field(default_factory=list)
    body_x0:         List[float]          = field(default_factory=list)
    body_v0:         List[float]          = field(default_factory=list)
    body_colors:     List[str]            = field(default_factory=list)
    spring_pairs:    List[Dict[str, Any]] = field(default_factory=list)
    L_interior: float = 2.6
    cart_x0: float = 0.0
    cart_v0: float = 0.0

    def __post_init__(self):
        if not self.body_kinds:
            self._build_layout()

    def _build_layout(self):
        rng = np.random.default_rng(int(self.setup_seed))
        n_objects = int(rng.integers(1, 5))   # 1–4 high-level objects

        body_kinds:      List[str]            = []
        body_masses:     List[float]          = []
        body_mu:         List[float]          = []
        body_half_sizes: List[float]          = []
        body_x0_rel:     List[float]          = []  # offset from interior left wall
        body_colors:     List[str]            = []
        spring_pairs:    List[Dict[str, Any]] = []

        palette = ["#e63946", "#457b9d", "#2a9d8f", "#f4a261",
                   "#06d6a0", "#118ab2", "#9d4edd", "#ef476f"]
        color_idx = 0
        next_x = 0.10                     # initial offset from the interior left wall
        margin = 0.14                     # min spacing between adjacent bodies

        for _ in range(n_objects):
            kind = rng.choice(["sphere", "cuboid", "spring_pair"],
                              p=[0.40, 0.40, 0.20])

            if kind in ("sphere", "cuboid"):
                m    = float(rng.uniform(0.40, 1.60))
                half = float(rng.uniform(0.10, 0.18))
                mu   = float(rng.uniform(0.05, 0.55))
                body_kinds.append(kind)
                body_masses.append(m)
                body_mu.append(mu)
                body_half_sizes.append(half)
                body_colors.append(palette[color_idx % len(palette)])
                color_idx += 1
                x_pos = next_x + half
                body_x0_rel.append(x_pos)
                next_x = x_pos + half + margin
            else:                          # spring_pair: two coupled blocks
                m_l    = float(rng.uniform(0.35, 1.00))
                m_r    = float(rng.uniform(0.35, 1.00))
                half_l = float(rng.uniform(0.07, 0.12))
                half_r = float(rng.uniform(0.07, 0.12))
                mu_l   = float(rng.uniform(0.05, 0.40))
                mu_r   = float(rng.uniform(0.05, 0.40))
                k      = float(rng.uniform(20.0, 80.0))
                L_nat  = float(rng.uniform(0.25, 0.45))
                color_pair = palette[color_idx % len(palette)]
                color_idx += 1

                l_idx = len(body_kinds)
                body_kinds.append("spring_left")
                body_masses.append(m_l)
                body_mu.append(mu_l)
                body_half_sizes.append(half_l)
                body_colors.append(color_pair)
                x_l = next_x + half_l
                body_x0_rel.append(x_l)

                r_idx = len(body_kinds)
                body_kinds.append("spring_right")
                body_masses.append(m_r)
                body_mu.append(mu_r)
                body_half_sizes.append(half_r)
                body_colors.append(color_pair)
                x_r = x_l + half_l + L_nat + half_r
                body_x0_rel.append(x_r)
                next_x = x_r + half_r + margin

                spring_pairs.append({
                    "left_body_idx":  l_idx,
                    "right_body_idx": r_idx,
                    "k":              k,
                    "L_natural":      L_nat,
                })

        # Cart interior length: at least the layout span + ~0.6 m sliding room.
        L_int = max(next_x + 0.30, 2.5)

        # Re-centre body positions so the layout midpoint sits at the cart
        # centre (cart starts at the lab-frame origin).
        layout_centre = (0.10 + (next_x - margin)) / 2.0
        body_x0_lab = [x - layout_centre for x in body_x0_rel]
        body_v0     = [0.0] * len(body_kinds)

        self.n_bodies        = len(body_kinds)
        self.body_kinds      = body_kinds
        self.body_masses     = body_masses
        self.body_mu         = body_mu
        self.body_half_sizes = body_half_sizes
        self.body_x0         = body_x0_lab
        self.body_v0         = body_v0
        self.body_colors     = body_colors
        self.spring_pairs    = spring_pairs
        self.L_interior      = L_int
        self.cart_x0         = 0.0
        self.cart_v0         = 0.0


# ─────────────────────────────────────────────────────────────────────────────
# ODE
# ─────────────────────────────────────────────────────────────────────────────
def _ode(t: float, y: List[float], p: AcceleratingCartSlidingMassParams):
    n      = p.n_bodies
    g      = p.g
    M      = p.M_cart
    L_int  = p.L_interior
    alpha  = p.alpha_tanh
    k_c    = p.k_contact
    zeta_c = 0.6                         # damping ratio for hard contacts

    x_cart, v_cart = y[0], y[1]
    x_b = np.array([y[2 + 2 * i]     for i in range(n)])
    v_b = np.array([y[3 + 2 * i]     for i in range(n)])

    F_b = np.zeros(n)                    # net force on body i
    F_c = 0.0                            # net interaction force on cart (ex F_ext)

    # External driving force on the cart.
    # Cosine (rather than sine) keeps the time-integrated impulse symmetric
    # around zero so the cart's CoM oscillates instead of drifting.
    F_ext = p.F_amp * np.cos(p.omega_drive * t)

    # ── Coulomb friction with the cart floor (regularised tanh) ────────────
    for i in range(n):
        v_rel  = v_b[i] - v_cart
        F_fric = -p.body_mu[i] * p.body_masses[i] * g * np.tanh(alpha * v_rel)
        F_b[i] += F_fric
        F_c    += -F_fric                 # Newton's 3rd law

    # ── Hooke spring forces between paired bodies ──────────────────────────
    for sp in p.spring_pairs:
        l, r = sp["left_body_idx"], sp["right_body_idx"]
        sep      = x_b[r] - x_b[l]
        rest_sep = sp["L_natural"] + p.body_half_sizes[l] + p.body_half_sizes[r]
        stretch  = sep - rest_sep
        F_s      = sp["k"] * stretch
        F_b[l]  += F_s
        F_b[r]  -= F_s

    # ── Interior wall contacts (penalty + damping) ─────────────────────────
    xL_wall = x_cart - L_int / 2.0
    xR_wall = x_cart + L_int / 2.0
    for i in range(n):
        body_left  = x_b[i] - p.body_half_sizes[i]
        body_right = x_b[i] + p.body_half_sizes[i]
        if body_left < xL_wall:
            overlap = xL_wall - body_left
            v_rel   = v_b[i] - v_cart
            m_eff   = p.body_masses[i] * M / (p.body_masses[i] + M)
            c_d     = 2.0 * zeta_c * np.sqrt(m_eff * k_c)
            F       = k_c * overlap - c_d * v_rel
            F_b[i] += F
            F_c    += -F
        if body_right > xR_wall:
            overlap = body_right - xR_wall
            v_rel   = v_b[i] - v_cart
            m_eff   = p.body_masses[i] * M / (p.body_masses[i] + M)
            c_d     = 2.0 * zeta_c * np.sqrt(m_eff * k_c)
            F       = -k_c * overlap - c_d * v_rel
            F_b[i] += F
            F_c    += -F

    # ── Body-body penalty contacts (skip bodies internal to a spring pair) ─
    spring_pair_set = set()
    for sp in p.spring_pairs:
        spring_pair_set.add(tuple(sorted([sp["left_body_idx"],
                                          sp["right_body_idx"]])))
    for i in range(n):
        for j in range(i + 1, n):
            if (i, j) in spring_pair_set:
                continue
            l, r = (i, j) if x_b[i] < x_b[j] else (j, i)
            sign_r = +1 if r == j else -1
            face_l_right = x_b[l] + p.body_half_sizes[l]
            face_r_left  = x_b[r] - p.body_half_sizes[r]
            if face_r_left < face_l_right:
                overlap = face_l_right - face_r_left
                v_rel   = v_b[r] - v_b[l]
                m_eff   = p.body_masses[l] * p.body_masses[r] / \
                          (p.body_masses[l] + p.body_masses[r])
                c_d     = 2.0 * zeta_c * np.sqrt(m_eff * k_c)
                F       = k_c * overlap - c_d * v_rel
                F_b[r] += sign_r * F
                F_b[l] -= sign_r * F

    # Pack derivatives
    dy = [v_cart, (F_ext + F_c) / M]
    for i in range(n):
        dy.append(v_b[i])
        dy.append(F_b[i] / p.body_masses[i])
    return dy


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────
def simulate(params: AcceleratingCartSlidingMassParams,
             duration: float = 12.0,
             fps: int = 30):
    n  = params.n_bodies
    y0 = [params.cart_x0, params.cart_v0]
    for i in range(n):
        y0.append(params.body_x0[i])
        y0.append(params.body_v0[i])
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        _ode, (0, duration), y0,
        t_eval=t_eval, args=(params,),
        method="LSODA", rtol=1e-7, atol=1e-9, max_step=0.01,
    )
    return sol.t, sol.y


def render_video(t: np.ndarray,
                 y: np.ndarray,
                 params: AcceleratingCartSlidingMassParams,
                 output_path: str,
                 fps: int = 30) -> None:
    n     = params.n_bodies
    L_int = params.L_interior

    # ── Visual layout constants ──────────────────────────────────────────────
    floor_y               = 0.0
    wheel_r               = 0.075
    wheel_y               = floor_y + wheel_r
    cart_floor_thickness  = 0.05
    cart_floor_top_y      = wheel_y + 0.04
    cart_floor_bot_y      = cart_floor_top_y - cart_floor_thickness
    wall_thickness        = 0.06
    wall_height           = 0.55
    wall_top_y            = cart_floor_top_y + wall_height
    label_y               = wall_top_y + 0.50

    x_cart_arr = y[0]
    pad        = L_int / 2.0 + 0.6
    x_min      = float(np.min(x_cart_arr)) - pad
    x_max      = float(np.max(x_cart_arr)) + pad

    fig, ax = plt.subplots(figsize=(11, 4.6))
    setup_dark_axis(
        fig, ax,
        xlim=(x_min, x_max),
        ylim=(floor_y - 0.20, label_y + 0.30),
    )

    # Static lab floor (track)
    ax.axhline(floor_y, color="#3a3a4f", lw=2.2, zorder=1)

    # Cart parts (animated)
    floor_rect = patches.Rectangle(
        (params.cart_x0 - L_int / 2 - wall_thickness, cart_floor_bot_y),
        L_int + 2 * wall_thickness, cart_floor_thickness,
        facecolor="#4a4e69", edgecolor="white", lw=1.2, zorder=2,
    )
    left_wall_rect = patches.Rectangle(
        (params.cart_x0 - L_int / 2 - wall_thickness, cart_floor_top_y),
        wall_thickness, wall_height,
        facecolor="#4a4e69", edgecolor="white", lw=1.2, zorder=2,
    )
    right_wall_rect = patches.Rectangle(
        (params.cart_x0 + L_int / 2, cart_floor_top_y),
        wall_thickness, wall_height,
        facecolor="#4a4e69", edgecolor="white", lw=1.2, zorder=2,
    )
    ax.add_patch(floor_rect)
    ax.add_patch(left_wall_rect)
    ax.add_patch(right_wall_rect)

    wheel1 = plt.Circle((params.cart_x0 - L_int / 3, wheel_y), wheel_r,
                        color="#a8dadc", zorder=3)
    wheel2 = plt.Circle((params.cart_x0 + L_int / 3, wheel_y), wheel_r,
                        color="#a8dadc", zorder=3)
    ax.add_patch(wheel1)
    ax.add_patch(wheel2)

    # Bodies (animated patches)
    body_patches = []
    for i in range(n):
        kind = params.body_kinds[i]
        c    = params.body_colors[i]
        x0   = params.body_x0[i] + params.cart_x0
        h    = params.body_half_sizes[i]
        y_c  = cart_floor_top_y + h
        if kind == "sphere":
            patch = patches.Circle((x0, y_c), h,
                                   facecolor=c, edgecolor="white",
                                   lw=1.5, zorder=4)
        else:                                 # cuboid / spring_left / spring_right
            patch = patches.FancyBboxPatch(
                (x0 - h, y_c - h), 2 * h, 2 * h,
                boxstyle="round,pad=0.01",
                lw=1.2, edgecolor="white", facecolor=c, zorder=4,
            )
        ax.add_patch(patch)
        body_patches.append(patch)

    # Spring lines
    spring_lines = [
        (sp, ax.plot([], [], "-", color="#ffd166", lw=2.0, zorder=4)[0])
        for sp in params.spring_pairs
    ]

    # CoM marker (vertical dashed line + label) for the full system
    com_line, = ax.plot([], [], "--", color="#ffd166", lw=1.6, zorder=5)

    # Force readout text (top-right) and time text (top-left)

    M_total = params.M_cart + sum(params.body_masses)

    def update(frame: int):
        x_cart = y[0, frame]
        # Cart body
        floor_rect.set_x(x_cart - L_int / 2 - wall_thickness)
        left_wall_rect.set_x(x_cart - L_int / 2 - wall_thickness)
        right_wall_rect.set_x(x_cart + L_int / 2)
        wheel1.center = (x_cart - L_int / 3, wheel_y)
        wheel2.center = (x_cart + L_int / 3, wheel_y)
        # Bodies
        for i in range(n):
            xi   = y[2 + 2 * i, frame]
            kind = params.body_kinds[i]
            h    = params.body_half_sizes[i]
            y_c  = cart_floor_top_y + h
            if kind == "sphere":
                body_patches[i].center = (xi, y_c)
            else:
                body_patches[i].set_x(xi - h)
                body_patches[i].set_y(y_c - h)
        # Springs
        for sp, line in spring_lines:
            l, r = sp["left_body_idx"], sp["right_body_idx"]
            xl   = y[2 + 2 * l, frame] + params.body_half_sizes[l]
            xr   = y[2 + 2 * r, frame] - params.body_half_sizes[r]
            yl   = cart_floor_top_y + params.body_half_sizes[l]
            yr   = cart_floor_top_y + params.body_half_sizes[r]
            if xr - xl > 0.02:
                sx, sy = spring_path(
                    xl, yl, xr, yr,
                    n_coils=max(3, int(sp["L_natural"] * 14)),
                    coil_radius=0.05,
                )
                line.set_data(sx, sy)
            else:
                line.set_data([], [])
        # Centre of mass
        body_x = np.array([y[2 + 2 * i, frame] for i in range(n)])
        x_com  = (params.M_cart * x_cart +
                  np.sum(np.array(params.body_masses) * body_x)) / M_total
        com_line.set_data([x_com, x_com], [floor_y, label_y - 0.15])
        # Texts
        F_now = params.F_amp * np.cos(params.omega_drive * t[frame])
        arrow = "→" if F_now > 0.5 else ("←" if F_now < -0.5 else "·")
        return ([floor_rect, left_wall_rect, right_wall_rect, wheel1, wheel2,
                 com_line]
                + body_patches + [ln for _, ln in spring_lines])

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), interval=1000 / fps, blit=False,
    )
    ani.save(output_path,
             writer=animation.FFMpegWriter(fps=fps, bitrate=1800),
             dpi=120)
    plt.close(fig)


# ─────────────────────────────────────────────────────────────────────────────
# Standalone-script generator
# ─────────────────────────────────────────────────────────────────────────────
def make_standalone_script(params: AcceleratingCartSlidingMassParams,
                           duration: float = 12.0) -> str:
    body_kinds      = list(params.body_kinds)
    body_masses     = list(params.body_masses)
    body_mu         = list(params.body_mu)
    body_half_sizes = list(params.body_half_sizes)
    body_x0         = list(params.body_x0)
    body_v0         = list(params.body_v0)
    body_colors     = list(params.body_colors)
    spring_pairs    = list(params.spring_pairs)

    return f'''"""
Accelerating Cart with Sliding Mass(es) Inside — auto-generated standalone script.

Physics:
  • Cart driven by sinusoidal external force  F_ext(t) = F_amp · sin(ω_drive · t).
  • Each interior body i obeys
        m_i ẍ_i = -μ_i m_i g · tanh(α (v_i - v_cart))
                  + Σ_j k_pair (x_R - x_L - L_nat) for paired bodies (Hooke's law)
                  + interior-wall and inter-body penalty contacts.
  • Cart obeys Newton's 2nd law: M_cart ẍ_cart = F_ext - Σ friction reactions
                                               - Σ wall reactions.
  • Total system CoM:  (M_cart + Σ m_i) ẍ_CoM = F_ext(t).
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

# ── Parameters (filled in from the dataclass at generation time) ────────────
M_cart       = {params.M_cart}
F_amp        = {params.F_amp}
omega_drive  = {params.omega_drive}
g            = {params.g}
alpha_tanh   = {params.alpha_tanh}
k_contact    = {params.k_contact}
L_interior   = {params.L_interior}
cart_x0      = {params.cart_x0}
cart_v0      = {params.cart_v0}
body_kinds      = {body_kinds!r}
body_masses     = {body_masses!r}
body_mu         = {body_mu!r}
body_half_sizes = {body_half_sizes!r}
body_x0         = {body_x0!r}
body_v0         = {body_v0!r}
body_colors     = {body_colors!r}
spring_pairs    = {spring_pairs!r}
duration        = {duration}
fps             = 30
n_bodies        = len(body_kinds)
zeta_c          = 0.6

spring_pair_set = set()
for sp in spring_pairs:
    spring_pair_set.add(tuple(sorted([sp["left_body_idx"], sp["right_body_idx"]])))


def ode(t, y):
    n = n_bodies
    x_cart, v_cart = y[0], y[1]
    x_b = np.array([y[2 + 2 * i] for i in range(n)])
    v_b = np.array([y[3 + 2 * i] for i in range(n)])
    F_b = np.zeros(n)
    F_c = 0.0
    F_ext = F_amp * np.cos(omega_drive * t)

    for i in range(n):
        v_rel = v_b[i] - v_cart
        F_fric = -body_mu[i] * body_masses[i] * g * np.tanh(alpha_tanh * v_rel)
        F_b[i] += F_fric
        F_c    += -F_fric

    for sp in spring_pairs:
        l, r = sp["left_body_idx"], sp["right_body_idx"]
        sep      = x_b[r] - x_b[l]
        rest_sep = sp["L_natural"] + body_half_sizes[l] + body_half_sizes[r]
        stretch  = sep - rest_sep
        F_s      = sp["k"] * stretch
        F_b[l]  += F_s
        F_b[r]  -= F_s

    xL_wall = x_cart - L_interior / 2.0
    xR_wall = x_cart + L_interior / 2.0
    for i in range(n):
        bl = x_b[i] - body_half_sizes[i]
        br = x_b[i] + body_half_sizes[i]
        if bl < xL_wall:
            overlap = xL_wall - bl
            v_rel   = v_b[i] - v_cart
            m_eff   = body_masses[i] * M_cart / (body_masses[i] + M_cart)
            c_d     = 2.0 * zeta_c * np.sqrt(m_eff * k_contact)
            F       = k_contact * overlap - c_d * v_rel
            F_b[i] += F
            F_c    += -F
        if br > xR_wall:
            overlap = br - xR_wall
            v_rel   = v_b[i] - v_cart
            m_eff   = body_masses[i] * M_cart / (body_masses[i] + M_cart)
            c_d     = 2.0 * zeta_c * np.sqrt(m_eff * k_contact)
            F       = -k_contact * overlap - c_d * v_rel
            F_b[i] += F
            F_c    += -F

    for i in range(n):
        for j in range(i + 1, n):
            if (i, j) in spring_pair_set:
                continue
            l, r = (i, j) if x_b[i] < x_b[j] else (j, i)
            sign_r = +1 if r == j else -1
            flr = x_b[l] + body_half_sizes[l]
            frl = x_b[r] - body_half_sizes[r]
            if frl < flr:
                overlap = flr - frl
                v_rel   = v_b[r] - v_b[l]
                m_eff   = body_masses[l] * body_masses[r] / (body_masses[l] + body_masses[r])
                c_d     = 2.0 * zeta_c * np.sqrt(m_eff * k_contact)
                F       = k_contact * overlap - c_d * v_rel
                F_b[r] += sign_r * F
                F_b[l] -= sign_r * F

    dy = [v_cart, (F_ext + F_c) / M_cart]
    for i in range(n):
        dy.append(v_b[i])
        dy.append(F_b[i] / body_masses[i])
    return dy


# ── Integrate ────────────────────────────────────────────────────────────────
y0 = [cart_x0, cart_v0]
for i in range(n_bodies):
    y0.append(body_x0[i]); y0.append(body_v0[i])
t_eval = np.linspace(0, duration, int(duration * fps) + 1)
sol = solve_ivp(ode, (0, duration), y0, t_eval=t_eval,
                method="LSODA", rtol=1e-7, atol=1e-9, max_step=0.01)
y = sol.y; t = sol.t


# ── Spring-coil visualization helper ─────────────────────────────────────────
def spring_path_fn(x1, y1, x2, y2, n=8, r=0.05):
    dx, dy_ = x2 - x1, y2 - y1
    L = np.hypot(dx, dy_)
    if L < 1e-10:
        return np.array([x1, x2]), np.array([y1, y2])
    ux, uy = dx / L, dy_ / L
    nx_, ny_ = -uy, ux
    pts = n * 20 + 2
    tt  = np.linspace(0, 1, pts)
    margin = 0.08
    env = np.where((tt < margin) | (tt > 1 - margin), 0,
                   np.sin(n * 2 * np.pi * (tt - margin) / (1 - 2 * margin)))
    return x1 + tt * dx + r * env * nx_, y1 + tt * dy_ + r * env * ny_


# ── Visual layout ────────────────────────────────────────────────────────────
floor_y               = 0.0
wheel_r               = 0.075
wheel_y               = floor_y + wheel_r
cart_floor_thickness  = 0.05
cart_floor_top_y      = wheel_y + 0.04
cart_floor_bot_y      = cart_floor_top_y - cart_floor_thickness
wall_thickness        = 0.06
wall_height           = 0.55
wall_top_y            = cart_floor_top_y + wall_height
label_y               = wall_top_y + 0.50

x_min = float(np.min(y[0])) - L_interior / 2.0 - 0.6
x_max = float(np.max(y[0])) + L_interior / 2.0 + 0.6

fig, ax = plt.subplots(figsize=(11, 4.6), facecolor="#1a1a2e")
ax.set_facecolor("#16213e")
ax.set_xlim(x_min, x_max); ax.set_ylim(floor_y - 0.20, label_y + 0.30)
ax.set_aspect("equal"); ax.axis("off")
ax.axhline(floor_y, color="#3a3a4f", lw=2.2, zorder=1)

floor_rect = patches.Rectangle(
    (cart_x0 - L_interior / 2 - wall_thickness, cart_floor_bot_y),
    L_interior + 2 * wall_thickness, cart_floor_thickness,
    facecolor="#4a4e69", edgecolor="white", lw=1.2, zorder=2,
)
left_wall_rect = patches.Rectangle(
    (cart_x0 - L_interior / 2 - wall_thickness, cart_floor_top_y),
    wall_thickness, wall_height,
    facecolor="#4a4e69", edgecolor="white", lw=1.2, zorder=2,
)
right_wall_rect = patches.Rectangle(
    (cart_x0 + L_interior / 2, cart_floor_top_y),
    wall_thickness, wall_height,
    facecolor="#4a4e69", edgecolor="white", lw=1.2, zorder=2,
)
ax.add_patch(floor_rect); ax.add_patch(left_wall_rect); ax.add_patch(right_wall_rect)

wheel1 = plt.Circle((cart_x0 - L_interior / 3, wheel_y), wheel_r, color="#a8dadc", zorder=3)
wheel2 = plt.Circle((cart_x0 + L_interior / 3, wheel_y), wheel_r, color="#a8dadc", zorder=3)
ax.add_patch(wheel1); ax.add_patch(wheel2)

body_patches = []
for i, kind in enumerate(body_kinds):
    c   = body_colors[i]
    h   = body_half_sizes[i]
    y_c = cart_floor_top_y + h
    x0  = body_x0[i] + cart_x0
    if kind == "sphere":
        p_ = patches.Circle((x0, y_c), h, facecolor=c,
                            edgecolor="white", lw=1.5, zorder=4)
    else:
        p_ = patches.FancyBboxPatch(
            (x0 - h, y_c - h), 2 * h, 2 * h,
            boxstyle="round,pad=0.01", lw=1.2,
            edgecolor="white", facecolor=c, zorder=4,
        )
    ax.add_patch(p_); body_patches.append(p_)

spring_lines = [(sp, ax.plot([], [], "-", color="#ffd166",
                              lw=2.0, zorder=4)[0]) for sp in spring_pairs]

com_line, = ax.plot([], [], "--", color="#ffd166", lw=1.6, zorder=5)

M_total = M_cart + sum(body_masses)


def update(frame):
    x_cart = y[0, frame]
    floor_rect.set_x(x_cart - L_interior / 2 - wall_thickness)
    left_wall_rect.set_x(x_cart - L_interior / 2 - wall_thickness)
    right_wall_rect.set_x(x_cart + L_interior / 2)
    wheel1.center = (x_cart - L_interior / 3, wheel_y)
    wheel2.center = (x_cart + L_interior / 3, wheel_y)
    for i in range(n_bodies):
        xi = y[2 + 2 * i, frame]
        h  = body_half_sizes[i]
        y_c = cart_floor_top_y + h
        if body_kinds[i] == "sphere":
            body_patches[i].center = (xi, y_c)
        else:
            body_patches[i].set_x(xi - h)
            body_patches[i].set_y(y_c - h)
    for sp, line in spring_lines:
        l, r = sp["left_body_idx"], sp["right_body_idx"]
        xl = y[2 + 2 * l, frame] + body_half_sizes[l]
        xr = y[2 + 2 * r, frame] - body_half_sizes[r]
        yl = cart_floor_top_y + body_half_sizes[l]
        yr = cart_floor_top_y + body_half_sizes[r]
        if xr - xl > 0.02:
            sx, sy_ = spring_path_fn(xl, yl, xr, yr,
                                      n=max(3, int(sp["L_natural"] * 14)),
                                      r=0.05)
            line.set_data(sx, sy_)
        else:
            line.set_data([], [])
    body_x = np.array([y[2 + 2 * i, frame] for i in range(n_bodies)])
    x_com  = (M_cart * x_cart + np.sum(np.array(body_masses) * body_x)) / M_total
    com_line.set_data([x_com, x_com], [floor_y, label_y - 0.15])
    F_now = F_amp * np.cos(omega_drive * t[frame])
    arrow = "->" if F_now > 0.5 else ("<-" if F_now < -0.5 else ".")
    return ([floor_rect, left_wall_rect, right_wall_rect, wheel1, wheel2,
             com_line]
            + body_patches + [ln for _, ln in spring_lines])


ani = animation.FuncAnimation(fig, update, frames=len(t),
                              interval=1000 / fps, blit=False)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Accelerating Cart with Sliding Mass(es) Inside")
    parser.add_argument("--seed",         type=float, default=42)
    parser.add_argument("--M_cart",       type=float, default=5.0)
    parser.add_argument("--F_amp",        type=float, default=35.0)
    parser.add_argument("--omega_drive",  type=float, default=1.5)
    parser.add_argument("--duration",     type=float, default=12.0)
    parser.add_argument("--output",       type=str,   default="accelerating_cart_sliding_mass.mp4")
    args = parser.parse_args()

    p = AcceleratingCartSlidingMassParams(
        setup_seed=args.seed, M_cart=args.M_cart,
        F_amp=args.F_amp, omega_drive=args.omega_drive,
    )
    print(f"Built layout: n_bodies={p.n_bodies}")
    print(f"  kinds      : {p.body_kinds}")
    print(f"  masses     : {[round(m,2) for m in p.body_masses]}")
    print(f"  mu         : {[round(m,3) for m in p.body_mu]}")
    print(f"  half_sizes : {[round(h,3) for h in p.body_half_sizes]}")
    print(f"  spring_pair: {p.spring_pairs}")

    t, y = simulate(p, duration=args.duration)
    print(f"Simulation done. Frames: {y.shape[1]}")
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
