"""
Lagrange Roller Simulation
===========================
Faithfully translated from myphysicslab/src/sims/roller/LagrangeRollerSim.ts

Physical Law: Euler-Lagrange equations applied to the HumpPath curve.

Track (HumpPath from myphysicslab/src/sims/roller/HumpPath.ts):
    y = 3 + x^2 * (-7 + x^2) / 6
      = 3 - (7/6)*x^2 + (1/6)*x^4

This is a 'W'-shaped path with a central hump.

Derivation (from LagrangeRollerSim.ts, verified against RollerCoaster_Lagrangian.pdf):
    dy/dx  = -(7/3)*x + (2/3)*x^3
    d^2y/dx^2 = -(7/3) + 2*x^2

    Euler-Lagrange gives (from the TS source exactly):

        x' = v

              -(x * (-7 + 2*x^2) * (3*g + (-7 + 6*x^2) * v^2))
        v' = ─────────────────────────────────────────────────────
                       (9 + 49*x^2 - 28*x^4 + 4*x^6)

    Note: the TS implementation (gravity_ = 2 by default in the TS code) uses
    a different default gravity.  We expose g as a parameter and use 9.8 as
    the Python default so that the physics is clearly grounded.  The TS formula
    above is exact and is used verbatim in the evaluate() method.

    Optional linear damping (not present in the TS Lagrangian formulation) can
    be added as a perturbation:
        v' += -(b/m) * sqrt(1 + (dy/dx)^2) * v / (1 + (dy/dx)^2)
            = -(b/m) * v / sqrt(1 + (dy/dx)^2)

State vector: [x, v]  where v = dx/dt
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from dataclasses import dataclass, asdict
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from .draw_utils import setup_dark_axis


@dataclass
class LagrangeRollerParams:
    g: float  = 9.8    # gravitational acceleration (m/s^2)
    m: float  = 1.0    # ball mass (kg)
    b: float  = 0.0    # damping coefficient (0 = exact Lagrangian, no damping)
    x0: float = 0.5    # initial x position (m)
    v0: float = 0.5    # initial x velocity (m/s)


def _hump(x: np.ndarray):
    """
    HumpPath: y = 3 - (7/6)*x^2 + (1/6)*x^4
    Returns (y, dy/dx).
    Taken directly from HumpPath.ts:  y_func(t) = 3 + t*t*(-7 + t*t)/6
    """
    x2 = x * x
    y   = 3.0 + x2 * (-7.0 + x2) / 6.0
    dydx = x * (-7.0 + 2.0 * x2) / 3.0     # = -(7/3)*x + (2/3)*x^3
    return y, dydx


def ode(t: float, state: list, p: LagrangeRollerParams):
    """
    ODE from LagrangeRollerSim.ts evaluate() — exact translation.

    dx/dt = v

            -(x * (-7 + 2*x^2) * (3*g + (-7 + 6*x^2) * v^2))
    dv/dt = ─────────────────────────────────────────────────
                    (9 + 49*x^2 - 28*x^4 + 4*x^6)

    Plus optional damping term: -(b/m) * v / sqrt(1 + (dydx)^2)
    """
    x, v = state
    x2 = x * x

    # Exact formula from LagrangeRollerSim.ts
    numerator   = -(x * (-7.0 + 2.0 * x2) * (3.0 * p.g + (-7.0 + 6.0 * x2) * v * v))
    denominator = 9.0 + 49.0 * x2 - 28.0 * x2 * x2 + 4.0 * x2 * x2 * x2
    dv = numerator / denominator

    # Optional damping (perturbation on top of the Lagrangian)
    if p.b != 0.0:
        dydx  = x * (-7.0 + 2.0 * x2) / 3.0
        dv   -= (p.b / p.m) * v / np.sqrt(1.0 + dydx * dydx)

    return [v, dv]


def simulate(
    params: LagrangeRollerParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Integrate the ODE using RK45.
    Returns (t, y) where y.shape = (2, N): [x, v] at each time step.
    """
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode,
        (0, duration),
        [params.x0, params.v0],
        t_eval=t_eval,
        args=(params,),
        method="RK45",
        rtol=1e-8,
        atol=1e-10,
        dense_output=False,
    )
    return sol.t, sol.y


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: LagrangeRollerParams,
    output_path: str,
    fps: int = 30,
    trail_len: int = 60,
) -> None:
    """Render an MP4 video of the ball rolling along the hump track."""
    x_ball = y[0]
    y_ball, _ = _hump(x_ball)

    # Static track: x in [-3, 3] (domain of HumpPath in TS source)
    x_range = np.linspace(-3.0, 3.0, 600)
    y_track, _ = _hump(x_range)

    pad_x = 0.3
    pad_y = 0.5
    xlim = (x_range.min() - pad_x, x_range.max() + pad_x)
    ylim = (y_track.min() - pad_y, y_track.max() + pad_y)

    fig, ax = plt.subplots(figsize=(8, 5))
    setup_dark_axis(fig, ax, xlim, ylim)

    # Static track
    ax.plot(x_range, y_track, "-", color="#a8dadc", lw=2.0, zorder=2, alpha=0.7)

    # Animated elements
    (ball,)  = ax.plot([], [], "o", color="#e63946", ms=12, zorder=5)
    (trail,) = ax.plot([], [], "-", color="#e63946", alpha=0.4, lw=1.5, zorder=4)

    trail_x: list = []
    trail_y: list = []

    def init():
        ball.set_data([], [])
        trail.set_data([], [])
        return ball, trail

    def update(frame):
        bx = x_ball[frame]
        by = y_ball[frame]
        ball.set_data([bx], [by])
        trail_x.append(bx)
        trail_y.append(by)
        if len(trail_x) > trail_len:
            trail_x.pop(0)
            trail_y.pop(0)
        trail.set_data(trail_x, trail_y)
        return ball, trail

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), init_func=init, interval=1000 / fps, blit=True
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: LagrangeRollerParams, duration: float = 12.0) -> str:
    """Return a self-contained Python script string with parameter values embedded."""
    p = asdict(params)
    return f'''"""
Lagrange Roller (Hump Path) — auto-generated simulation script.
Track:    y = 3 - (7/6)*x^2 + (1/6)*x^4   (HumpPath from myphysicslab)
Physics:  v\' = -(x*(-7+2x^2)*(3g+(-7+6x^2)*v^2)) / (9+49x^2-28x^4+4x^6)
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation

# ── Physical parameters ─────────────────────────────────────────────────────
g  = {p["g"]}    # gravitational acceleration (m/s^2)
m  = {p["m"]}    # ball mass (kg)
b  = {p["b"]}    # damping coefficient (0 = pure Lagrangian)
x0 = {p["x0"]}   # initial x position (m)
v0 = {p["v0"]}   # initial x velocity (m/s)
duration = {duration}

# ── Track helper ─────────────────────────────────────────────────────────────
def hump(x):
    x2   = x * x
    y    = 3.0 + x2 * (-7.0 + x2) / 6.0
    dydx = x * (-7.0 + 2.0 * x2) / 3.0
    return y, dydx

# ── ODE system (exact translation of LagrangeRollerSim.ts evaluate()) ────────
def ode(t, state):
    x, v = state
    x2   = x * x
    num  = -(x * (-7.0 + 2.0*x2) * (3.0*g + (-7.0 + 6.0*x2)*v*v))
    den  = 9.0 + 49.0*x2 - 28.0*x2*x2 + 4.0*x2*x2*x2
    dv   = num / den
    if b != 0.0:
        _, dydx = hump(np.array([x]))
        dv -= (b / m) * v / np.sqrt(1.0 + dydx[0]**2)
    return [v, dv]

# ── Integrate ────────────────────────────────────────────────────────────────
fps    = 30
t_eval = np.linspace(0, duration, int(duration * fps) + 1)
sol    = solve_ivp(ode, (0, duration), [x0, v0],
                   t_eval=t_eval, method="RK45", rtol=1e-8, atol=1e-10)
t, x_ball = sol.t, sol.y[0]
y_ball, _ = hump(x_ball)

# ── Static track ─────────────────────────────────────────────────────────────
x_range = np.linspace(-3, 3, 600)
y_track, _ = hump(x_range)

# ── Animate ──────────────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(8, 5), facecolor="#1a1a2e")
ax.set_facecolor("#16213e")
ax.set_xlim(-3.3, 3.3)
ax.set_ylim(y_track.min() - 0.5, y_track.max() + 0.5)
ax.set_aspect("equal"); ax.axis("off")
ax.plot(x_range, y_track, "-", color="#a8dadc", lw=2.0, alpha=0.7)

ball,  = ax.plot([], [], "o", color="#e63946", ms=12, zorder=5)
trail, = ax.plot([], [], "-", color="#e63946", alpha=0.4, lw=1.5)
tx, ty = [], []

def update(frame):
    ball.set_data([x_ball[frame]], [y_ball[frame]])
    tx.append(x_ball[frame]); ty.append(y_ball[frame])
    if len(tx) > 60: tx.pop(0); ty.pop(0)
    trail.set_data(tx, ty)
    return ball, trail

ani = animation.FuncAnimation(fig, update, frames=len(t), interval=1000/fps, blit=True)
writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
ani.save("lagrange_roller.mp4", writer=writer, dpi=120)
plt.close()
print("Saved lagrange_roller.mp4")
'''


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Lagrange Roller — Hump Path Simulation")
    parser.add_argument("--g",        type=float, default=9.8)
    parser.add_argument("--m",        type=float, default=1.0)
    parser.add_argument("--b",        type=float, default=0.0)
    parser.add_argument("--x0",       type=float, default=0.5)
    parser.add_argument("--v0",       type=float, default=0.5)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output",   type=str,   default="lagrange_roller.mp4")
    args = parser.parse_args()

    p = LagrangeRollerParams(
        g=args.g, m=args.m, b=args.b, x0=args.x0, v0=args.v0,
    )
    print(f"Simulating Lagrange roller (hump path): {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
