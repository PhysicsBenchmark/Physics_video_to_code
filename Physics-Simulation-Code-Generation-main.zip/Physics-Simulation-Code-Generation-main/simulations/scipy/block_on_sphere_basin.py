"""
Block on Sphere in a Basin — block dropped onto sphere; sphere rolls/slides on floor in a U-basin.
Hybrid integrator: solve_ivp + impulsive rigid-body collision resolution.
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from matplotlib.transforms import Affine2D
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class BlockOnSphereBasinParams:
    g: float = 9.8
    m_s: float = 0.4
    r_s: float = 0.15
    M_b: float = 1.0
    s: float = 0.30
    I_b: float = 0.015
    e_bs: float = 0.45
    mu_bs: float = 0.30
    e_floor_block: float = 0.30
    mu_floor_block: float = 0.30
    e_wall: float = 0.65
    mu_wall: float = 0.10
    mu_floor_sphere: float = 0.20
    x_left_wall: float = -1.20
    x_right_wall: float = 1.20
    h_drop: float = 1.20
    theta_0: float = 0.18
    X_b_0: float = 0.05
    duration: float = 12.0


def _run_sim(p):
    g = p.g
    m_s = p.m_s; r_s = p.r_s; M_b = p.M_b; s = p.s; I_b = p.I_b
    e_bs = p.e_bs; mu_bs = p.mu_bs
    e_floor_block = p.e_floor_block; mu_floor_block = p.mu_floor_block
    e_wall = p.e_wall; mu_wall = p.mu_wall
    mu_floor_sphere = p.mu_floor_sphere
    x_left_wall = p.x_left_wall; x_right_wall = p.x_right_wall
    h_drop = p.h_drop; theta_0 = p.theta_0; X_b_0 = p.X_b_0
    duration = p.duration
    I_s = (2.0/5.0) * m_s * r_s * r_s
    fps = 30
    n_frames = int(duration * fps) + 1
    t_grid = np.linspace(0.0, duration, n_frames)

    IDX = dict(Xb=0, Yb=1, thb=2, Vxb=3, Vyb=4, omb=5,
               Xs=6, Ys=7, ths=8, Vxs=9, Vys=10, oms=11)

    def initial_state():
        y0 = np.zeros(12)
        y0[IDX['Xb']] = X_b_0; y0[IDX['Yb']] = h_drop; y0[IDX['thb']] = theta_0
        y0[IDX['Xs']] = 0.0; y0[IDX['Ys']] = r_s
        return y0

    def block_corners(Xb, Yb, th):
        half = s / 2.0
        body = np.array([[half, half], [-half, half], [-half, -half], [half, -half]])
        c, sn = np.cos(th), np.sin(th)
        R = np.array([[c, -sn], [sn, c]])
        return body @ R.T + np.array([Xb, Yb])

    def block_sphere_gap(Xb, Yb, th, Xs, Ys):
        c, sn = np.cos(th), np.sin(th)
        dx = Xs - Xb; dy = Ys - Yb
        bx = c * dx + sn * dy; by = -sn * dx + c * dy
        half = s / 2.0
        qx = max(abs(bx) - half, 0.0); qy = max(abs(by) - half, 0.0)
        outside = np.hypot(qx, qy)
        inside = min(max(abs(bx) - half, abs(by) - half), 0.0)
        return outside + inside - r_s

    def block_sphere_contact(Xb, Yb, th, Xs, Ys):
        c, sn = np.cos(th), np.sin(th)
        dx = Xs - Xb; dy = Ys - Yb
        bx = c * dx + sn * dy; by = -sn * dx + c * dy
        half = s / 2.0
        cx = max(-half, min(half, bx)); cy_ = max(-half, min(half, by))
        cp_world = np.array([Xb + c * cx - sn * cy_, Yb + sn * cx + c * cy_])
        n_sphere_to_block = cp_world - np.array([Xs, Ys])
        nrm = np.linalg.norm(n_sphere_to_block)
        n_hat = (n_sphere_to_block / nrm) if nrm >= 1e-12 else np.array([0.0, 1.0])
        r_b = cp_world - np.array([Xb, Yb])
        return cp_world, n_hat, r_b

    _settled = [False]
    _bs_cooldown_until = [-1e9]

    def free_flight(t, y):
        dy = np.zeros(12)
        if not _settled[0]:
            dy[IDX['Xb']] = y[IDX['Vxb']]; dy[IDX['Yb']] = y[IDX['Vyb']]
            dy[IDX['thb']] = y[IDX['omb']]; dy[IDX['Vxb']] = 0.0
            dy[IDX['Vyb']] = -g; dy[IDX['omb']] = 0.0
        Vxs = y[IDX['Vxs']]; oms = y[IDX['oms']]
        v_slip = Vxs - r_s * oms
        if abs(v_slip) > 1e-6:
            sgn = np.sign(v_slip)
            a_x = -sgn * mu_floor_sphere * g
            a_om = +sgn * mu_floor_sphere * g * (m_s * r_s) / I_s
        else:
            a_x = 0.0; a_om = 0.0
        dy[IDX['Xs']] = Vxs; dy[IDX['Ys']] = 0.0; dy[IDX['ths']] = oms
        dy[IDX['Vxs']] = a_x; dy[IDX['Vys']] = 0.0; dy[IDX['oms']] = a_om
        return dy

    def make_events():
        def ev_bs(t, y):
            if _settled[0] or t < _bs_cooldown_until[0]: return 1.0
            return block_sphere_gap(y[IDX['Xb']], y[IDX['Yb']], y[IDX['thb']],
                                    y[IDX['Xs']], y[IDX['Ys']])
        ev_bs.terminal = True; ev_bs.direction = -1.0

        def ev_bf(t, y):
            if _settled[0]: return 1.0
            pts = block_corners(y[IDX['Xb']], y[IDX['Yb']], y[IDX['thb']])
            return float(pts[:, 1].min())
        ev_bf.terminal = True; ev_bf.direction = -1.0

        def ev_sl(t, y):
            return (y[IDX['Xs']] - r_s) - x_left_wall
        ev_sl.terminal = True; ev_sl.direction = -1.0

        def ev_sr(t, y):
            return x_right_wall - (y[IDX['Xs']] + r_s)
        ev_sr.terminal = True; ev_sr.direction = -1.0

        def ev_bl(t, y):
            if _settled[0]: return 1.0
            pts = block_corners(y[IDX['Xb']], y[IDX['Yb']], y[IDX['thb']])
            return float(pts[:, 0].min()) - x_left_wall
        ev_bl.terminal = True; ev_bl.direction = -1.0

        def ev_br(t, y):
            if _settled[0]: return 1.0
            pts = block_corners(y[IDX['Xb']], y[IDX['Yb']], y[IDX['thb']])
            return x_right_wall - float(pts[:, 0].max())
        ev_br.terminal = True; ev_br.direction = -1.0

        def ev_sbs(t, y):
            if not _settled[0]: return 1.0
            return block_sphere_gap(y[IDX['Xb']], y[IDX['Yb']], y[IDX['thb']],
                                    y[IDX['Xs']], y[IDX['Ys']])
        ev_sbs.terminal = True; ev_sbs.direction = -1.0
        return [ev_bs, ev_bf, ev_sl, ev_sr, ev_bl, ev_br, ev_sbs]

    EV_NAMES = ['block_sphere', 'block_floor',
                'sphere_left', 'sphere_right',
                'block_left', 'block_right', 'sphere_block_settled']

    def resolve_block_sphere(state):
        y = state.copy()
        Xb, Yb, thb = y[IDX['Xb']], y[IDX['Yb']], y[IDX['thb']]
        Xs, Ys = y[IDX['Xs']], y[IDX['Ys']]
        Vxb, Vyb, omb = y[IDX['Vxb']], y[IDX['Vyb']], y[IDX['omb']]
        Vxs, Vys, oms = y[IDX['Vxs']], y[IDX['Vys']], y[IDX['oms']]
        cp, n_hat, r_b = block_sphere_contact(Xb, Yb, thb, Xs, Ys)
        pre_gap = block_sphere_gap(Xb, Yb, thb, Xs, Ys)
        if pre_gap < 0.0:
            push = -pre_gap
            Xb += push * n_hat[0]; Yb += push * n_hat[1]
            y[IDX['Xb']] = Xb; y[IDX['Yb']] = Yb
            cp, n_hat, r_b = block_sphere_contact(Xb, Yb, thb, Xs, Ys)
        r_sv = cp - np.array([Xs, Ys])
        t_hat = np.array([-n_hat[1], n_hat[0]])
        v_b_cp = np.array([Vxb - omb * r_b[1], Vyb + omb * r_b[0]])
        v_s_cp = np.array([Vxs - oms * r_sv[1], Vys + oms * r_sv[0]])
        v_rel = v_b_cp - v_s_cp
        v_rel_n = float(v_rel @ n_hat)
        if v_rel_n >= 0.0: return y
        rb_x_n = r_b[0] * n_hat[1] - r_b[1] * n_hat[0]
        rs_x_n = r_sv[0] * n_hat[1] - r_sv[1] * n_hat[0]
        rb_x_t = r_b[0] * t_hat[1] - r_b[1] * t_hat[0]
        rs_x_t = r_sv[0] * t_hat[1] - r_sv[1] * t_hat[0]
        inv_m_n = (1.0/M_b + 1.0/m_s + rb_x_n*rb_x_n/I_b + rs_x_n*rs_x_n/I_s)
        inv_m_t = (1.0/M_b + 1.0/m_s + rb_x_t*rb_x_t/I_b + rs_x_t*rs_x_t/I_s)
        J_n = -(1.0 + e_bs) * v_rel_n / inv_m_n
        v_rel_t = float(v_rel @ t_hat)
        J_t_stick = -v_rel_t / inv_m_t
        cone = mu_bs * abs(J_n)
        J_t = J_t_stick if abs(J_t_stick) <= cone else np.sign(J_t_stick) * cone
        J_vec_b = J_n * n_hat + J_t * t_hat
        J_vec_s = -J_vec_b
        y[IDX['Vxb']] = Vxb + J_vec_b[0]/M_b; y[IDX['Vyb']] = Vyb + J_vec_b[1]/M_b
        y[IDX['omb']] = omb + (r_b[0]*J_vec_b[1] - r_b[1]*J_vec_b[0])/I_b
        y[IDX['Vxs']] = Vxs + J_vec_s[0]/m_s; y[IDX['Vys']] = Vys + J_vec_s[1]/m_s
        y[IDX['oms']] = oms + (r_sv[0]*J_vec_s[1] - r_sv[1]*J_vec_s[0])/I_s
        eps_snap = 1e-6
        for _ in range(8):
            gap = block_sphere_gap(y[IDX['Xb']], y[IDX['Yb']], y[IDX['thb']],
                                   y[IDX['Xs']], y[IDX['Ys']])
            if gap >= eps_snap: break
            _, n_hat_now, _ = block_sphere_contact(
                y[IDX['Xb']], y[IDX['Yb']], y[IDX['thb']],
                y[IDX['Xs']], y[IDX['Ys']])
            push = max(-gap, 0.0) + eps_snap
            y[IDX['Xb']] += push * n_hat_now[0]
            y[IDX['Yb']] += push * n_hat_now[1]
        if y[IDX['Vys']] < 0.0: y[IDX['Vys']] = 0.0
        y[IDX['Vys']] = 0.0
        return y

    def resolve_block_floor(state):
        y = state.copy()
        Xb, Yb, thb = y[IDX['Xb']], y[IDX['Yb']], y[IDX['thb']]
        Vxb, Vyb, omb = y[IDX['Vxb']], y[IDX['Vyb']], y[IDX['omb']]
        for _ in range(12):
            applied = False
            pts = block_corners(Xb, Yb, thb)
            for k in range(4):
                cy_ = pts[k, 1]
                r_x = pts[k, 0] - Xb; r_y = pts[k, 1] - Yb
                v_cx = Vxb - omb * r_y; v_cy = Vyb + omb * r_x
                if cy_ > 1e-9 or v_cy > -1e-9: continue
                inv_m_n = 1.0/M_b + r_x*r_x/I_b
                inv_m_t = 1.0/M_b + r_y*r_y/I_b
                J_n = -(1.0 + e_floor_block) * v_cy / inv_m_n
                J_t_stick = -v_cx / inv_m_t
                cone = mu_floor_block * abs(J_n)
                J_t = max(-cone, min(cone, J_t_stick))
                Vxb += J_t/M_b; Vyb += J_n/M_b
                omb += (r_x*J_n - r_y*J_t)/I_b
                Yb -= cy_
                applied = True
                pts = block_corners(Xb, Yb, thb)
            if not applied: break
        pts = block_corners(Xb, Yb, thb)
        low = float(pts[:, 1].min())
        if low < 1e-7: Yb += (1e-7 - low)
        y[IDX['Xb']] = Xb; y[IDX['Yb']] = Yb; y[IDX['thb']] = thb
        y[IDX['Vxb']] = Vxb; y[IDX['Vyb']] = Vyb; y[IDX['omb']] = omb
        return y

    def resolve_sphere_wall(state, side):
        y = state.copy()
        Vx = y[IDX['Vxs']]
        if side < 0 and Vx < 0.0:
            y[IDX['Vxs']] = -e_wall * Vx
            y[IDX['oms']] *= (1.0 - mu_wall)
            y[IDX['Xs']] = x_left_wall + r_s
        elif side > 0 and Vx > 0.0:
            y[IDX['Vxs']] = -e_wall * Vx
            y[IDX['oms']] *= (1.0 - mu_wall)
            y[IDX['Xs']] = x_right_wall - r_s
        return y

    def resolve_block_wall(state, side):
        y = state.copy()
        Xb, Yb, thb = y[IDX['Xb']], y[IDX['Yb']], y[IDX['thb']]
        Vxb, Vyb, omb = y[IDX['Vxb']], y[IDX['Vyb']], y[IDX['omb']]
        pts = block_corners(Xb, Yb, thb)
        if side < 0:
            k = int(np.argmin(pts[:, 0]))
            n_hat = np.array([+1.0, 0.0])
        else:
            k = int(np.argmax(pts[:, 0]))
            n_hat = np.array([-1.0, 0.0])
        t_hat = np.array([-n_hat[1], n_hat[0]])
        r_x = pts[k, 0] - Xb; r_y = pts[k, 1] - Yb
        v_cx = Vxb - omb * r_y; v_cy = Vyb + omb * r_x
        v_n = v_cx * n_hat[0] + v_cy * n_hat[1]
        if v_n >= 0.0: return y
        v_t = v_cx * t_hat[0] + v_cy * t_hat[1]
        rxn = r_x * n_hat[1] - r_y * n_hat[0]
        rxt = r_x * t_hat[1] - r_y * t_hat[0]
        inv_m_n = 1.0/M_b + rxn*rxn/I_b
        inv_m_t = 1.0/M_b + rxt*rxt/I_b
        J_n = -(1.0 + e_wall) * v_n / inv_m_n
        J_t_stick = -v_t / inv_m_t
        J_t_stick *= (1.0 - mu_wall)
        cone = mu_wall * abs(J_n)
        J_t = max(-cone, min(cone, J_t_stick))
        Jx = J_n * n_hat[0] + J_t * t_hat[0]
        Jy = J_n * n_hat[1] + J_t * t_hat[1]
        y[IDX['Vxb']] = Vxb + Jx/M_b; y[IDX['Vyb']] = Vyb + Jy/M_b
        y[IDX['omb']] = omb + (r_x*Jy - r_y*Jx)/I_b
        pts2 = block_corners(Xb, Yb, thb)
        if side < 0:
            overlap = x_left_wall - pts2[k, 0]
            y[IDX['Xb']] = Xb + max(overlap, 0.0)
        else:
            overlap = pts2[k, 0] - x_right_wall
            y[IDX['Xb']] = Xb - max(overlap, 0.0)
        return y

    events = make_events()
    state = initial_state()
    t_now = 0.0
    samples_t = [0.0]; samples_y = [state.copy()]
    seg = 0; MAX_SEGS = 200
    chatter_count = 0; last_block_floor_t = -1e9
    bs_chatter = 0; last_bs_t = -1e9

    while t_now < duration - 1e-9 and seg < MAX_SEGS:
        seg += 1
        sub_eval = t_grid[(t_grid > t_now + 1e-12) & (t_grid <= duration + 1e-12)]
        sol = solve_ivp(free_flight, (t_now, duration), state,
                        t_eval=sub_eval if sub_eval.size > 0 else None,
                        events=events, method="RK45", rtol=1e-9, atol=1e-11,
                        max_step=0.02, dense_output=True)
        sol_t = np.asarray(sol.t)
        if sol_t.size > 0:
            for i in range(sol_t.size):
                ti = float(sol_t[i])
                if ti <= t_now + 1e-12: continue
                samples_t.append(ti); samples_y.append(sol.y[:, i].copy())
        triggered = -1; t_event = None; y_event = None
        for k_, te in enumerate(sol.t_events):
            if te.size > 0:
                t_e = te[0]
                if t_event is None or t_e < t_event:
                    t_event = t_e; y_event = sol.y_events[k_][0]; triggered = k_
        if triggered < 0:
            state = sol.y[:, -1].copy(); t_now = duration; break
        name = EV_NAMES[triggered]
        state = y_event.copy(); t_now = float(t_event)
        if name == 'block_sphere':
            state = resolve_block_sphere(state)
            if (t_now - last_bs_t) < 2e-3: bs_chatter += 1
            else: bs_chatter = 0
            last_bs_t = t_now
            _bs_cooldown_until[0] = t_now + 1e-4
            if bs_chatter >= 6:
                _, n_hat_esc, _ = block_sphere_contact(
                    state[IDX['Xb']], state[IDX['Yb']], state[IDX['thb']],
                    state[IDX['Xs']], state[IDX['Ys']])
                v_b = np.array([state[IDX['Vxb']], state[IDX['Vyb']]])
                vn = float(v_b @ n_hat_esc)
                if vn < 0.0: v_b = v_b - vn * n_hat_esc
                v_b = v_b + 0.20 * n_hat_esc
                state[IDX['Vxb']] = float(v_b[0]); state[IDX['Vyb']] = float(v_b[1])
                bs_chatter = 0
        elif name == 'block_floor':
            state = resolve_block_floor(state)
        elif name == 'sphere_left':
            state = resolve_sphere_wall(state, -1)
        elif name == 'sphere_right':
            state = resolve_sphere_wall(state, +1)
        elif name == 'block_left':
            state = resolve_block_wall(state, -1)
        elif name == 'block_right':
            state = resolve_block_wall(state, +1)
        elif name == 'sphere_block_settled':
            cp, n_hat, _ = block_sphere_contact(
                state[IDX['Xb']], state[IDX['Yb']], state[IDX['thb']],
                state[IDX['Xs']], state[IDX['Ys']])
            v = np.array([state[IDX['Vxs']], state[IDX['Vys']]])
            vn = float(v @ n_hat)
            if vn > 0.0:
                v_new = v - (1.0 + e_wall) * vn * n_hat
                state[IDX['Vxs']] = v_new[0]; state[IDX['Vys']] = v_new[1]
                state[IDX['oms']] *= (1.0 - mu_wall)
                new_centre = cp - r_s * n_hat
                state[IDX['Xs']] = float(new_centre[0]); state[IDX['Ys']] = r_s
        samples_t.append(t_now); samples_y.append(state.copy())
        pts_now = block_corners(state[IDX['Xb']], state[IDX['Yb']], state[IDX['thb']])
        block_low = float(pts_now[:, 1].min())
        block_KE = (0.5 * M_b * (state[IDX['Vxb']]**2 + state[IDX['Vyb']]**2)
                    + 0.5 * I_b * state[IDX['omb']]**2)
        sphere_KE = (0.5 * m_s * state[IDX['Vxs']]**2
                     + 0.5 * I_s * state[IDX['oms']]**2)
        if name == 'block_floor':
            if (t_now - last_block_floor_t) < 2e-3: chatter_count += 1
            else: chatter_count = 0
            last_block_floor_t = t_now
            if chatter_count >= 3 and abs(block_low) < 0.05:
                th_round = round(state[IDX['thb']] / (np.pi/2.0)) * (np.pi/2.0)
                state[IDX['thb']] = th_round; state[IDX['Yb']] = s/2.0
                state[IDX['Vxb']] = 0.0; state[IDX['Vyb']] = 0.0; state[IDX['omb']] = 0.0
                chatter_count = 0; _settled[0] = True
        if (block_KE + sphere_KE) < 5e-4 and abs(block_low) < 0.02:
            th_round = round(state[IDX['thb']] / (np.pi/2.0)) * (np.pi/2.0)
            state[IDX['thb']] = th_round; state[IDX['Yb']] = s/2.0
            state[IDX['Vxb']] = 0.0; state[IDX['Vyb']] = 0.0; state[IDX['omb']] = 0.0
            state[IDX['Vxs']] = 0.0; state[IDX['oms']] = 0.0
            break

    if t_now < duration - 1e-9:
        last_state = state.copy()
        for ti in t_grid:
            if ti > t_now + 1e-12:
                samples_t.append(float(ti)); samples_y.append(last_state.copy())
    samples_t = np.array(samples_t); samples_y = np.array(samples_y)
    order = np.argsort(samples_t, kind='stable')
    samples_t = samples_t[order]; samples_y = samples_y[order]
    keep = np.concatenate(([True], np.diff(samples_t) > 1e-9))
    samples_t = samples_t[keep]; samples_y = samples_y[keep]

    def interp_frame(ti):
        j = np.searchsorted(samples_t, ti)
        if j <= 0: return samples_y[0].copy()
        if j >= len(samples_t): return samples_y[-1].copy()
        t0, t1 = samples_t[j-1], samples_t[j]
        if t1 - t0 < 1e-12: return samples_y[j].copy()
        a = (ti - t0) / (t1 - t0)
        return (1.0 - a) * samples_y[j-1] + a * samples_y[j]

    frames_y = np.array([interp_frame(ti) for ti in t_grid])
    return t_grid, frames_y


def simulate(params: BlockOnSphereBasinParams,
             duration: float = 12.0, fps: int = 30):
    if duration is not None: params.duration = duration
    t, frames_y = _run_sim(params)
    # Pack as (12, n_frames)
    return t, frames_y.T


def render_video(t, y, params: BlockOnSphereBasinParams,
                 output_path: str, fps: int = 30):
    p = params
    frames_y = y.T  # (n_frames, 12)
    n_frames = frames_y.shape[0]
    IDX = dict(Xb=0, Yb=1, thb=2, Vxb=3, Vyb=4, omb=5,
               Xs=6, Ys=7, ths=8, Vxs=9, Vys=10, oms=11)

    fig_w, fig_h = 8.0, 5.0
    fig_aspect = fig_w / fig_h
    x_lo_d = p.x_left_wall - 0.20; x_hi_d = p.x_right_wall + 0.20
    y_lo_d = -0.10; y_hi_d = p.h_drop + 0.30
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")
    ax.add_patch(patches.Rectangle((x_lo, y_lo), x_hi - x_lo, -y_lo,
                                    facecolor="#4a4e69", edgecolor="none", zorder=0))
    wall_thick = 0.10
    ax.add_patch(patches.Rectangle((p.x_left_wall - wall_thick, 0.0), wall_thick,
                                    p.h_drop + 0.50, facecolor="#4a4e69",
                                    edgecolor="none", zorder=0))
    ax.add_patch(patches.Rectangle((p.x_right_wall, 0.0), wall_thick,
                                    p.h_drop + 0.50, facecolor="#4a4e69",
                                    edgecolor="none", zorder=0))
    ax.plot([x_lo, x_hi], [0, 0], color="#adb5bd", lw=2.5, zorder=1)
    ax.plot([p.x_left_wall, p.x_left_wall], [0, p.h_drop + 0.50],
            color="#adb5bd", lw=2.5, zorder=1)
    ax.plot([p.x_right_wall, p.x_right_wall], [0, p.h_drop + 0.50],
            color="#adb5bd", lw=2.5, zorder=1)

    sphere_patch = patches.Circle((frames_y[0, IDX['Xs']], frames_y[0, IDX['Ys']]),
                                   p.r_s, facecolor="#ffd166",
                                   edgecolor="white", lw=1.5, zorder=3)
    ax.add_patch(sphere_patch)
    sphere_tick, = ax.plot([], [], color="#1a1a2e", lw=2.0, zorder=4)
    block_patch = patches.Rectangle((frames_y[0, IDX['Xb']] - p.s/2.0,
                                      frames_y[0, IDX['Yb']] - p.s/2.0),
                                     p.s, p.s, facecolor="#e63946",
                                     edgecolor="white", lw=1.5, zorder=5)
    ax.add_patch(block_patch)

    def update(f):
        Xs_f = float(frames_y[f, IDX['Xs']]); Ys_f = float(frames_y[f, IDX['Ys']])
        th_s = float(frames_y[f, IDX['ths']])
        sphere_patch.set_center((Xs_f, Ys_f))
        sphere_tick.set_data([Xs_f, Xs_f + p.r_s * np.cos(th_s)],
                              [Ys_f, Ys_f + p.r_s * np.sin(th_s)])
        Xb_f = float(frames_y[f, IDX['Xb']]); Yb_f = float(frames_y[f, IDX['Yb']])
        th_b = float(frames_y[f, IDX['thb']])
        block_patch.set_xy((Xb_f - p.s/2.0, Yb_f - p.s/2.0))
        transform = (Affine2D().rotate_around(Xb_f, Yb_f, th_b) + ax.transData)
        block_patch.set_transform(transform)
        return sphere_patch, sphere_tick, block_patch

    ani = animation.FuncAnimation(fig, update, frames=n_frames,
                                  interval=1000.0/fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: BlockOnSphereBasinParams,
                           duration: float = 12.0) -> str:
    """Build a fully self-contained standalone script in the procedural style
    of the rest of the dataset: parameter literals at module level, `_run_sim`
    and `render_video` defined as plain module-level functions that read those
    parameters via global closure (no `params` argument, no type annotations
    that reference the original module).
    """
    import inspect
    import re
    p = asdict(params)
    p["duration"] = duration
    param_lines = "\n".join(f"{k} = {v!r}" for k, v in p.items())

    # Inline _run_sim, but strip the `(p)` argument and the leading block that
    # shadows module-level params via `p.attribute` access. Subsequent code in
    # the function body reads `g`, `m_s`, etc. from module-level globals.
    run_sim_src = inspect.getsource(_run_sim)
    run_sim_src = run_sim_src.replace("def _run_sim(p):\n", "def _run_sim():\n")
    run_sim_src = re.sub(
        r"^( {4}.*= p\..+\n)+", "", run_sim_src, count=1, flags=re.MULTILINE,
    )

    # Inline render_video: strip the `params: <Type>` argument, the `p = params`
    # alias line, and rewrite every remaining `p.attr` access to `attr` so the
    # function reads parameters from module-level globals.
    render_src = inspect.getsource(render_video)
    render_src = render_src.replace(
        "def render_video(t, y, params: BlockOnSphereBasinParams,\n"
        "                 output_path: str, fps: int = 30):\n",
        "def render_video(t, y, output_path, fps=30):\n",
    )
    render_src = render_src.replace("    p = params\n", "")
    render_src = re.sub(r"\bp\.(\w+)", r"\1", render_src)

    return (
        '"""Block on sphere in basin - standalone script."""\n'
        'import numpy as np\n'
        'from scipy.integrate import solve_ivp\n'
        'import matplotlib.pyplot as plt\n'
        'import matplotlib.animation as animation\n'
        'import matplotlib.patches as patches\n'
        'from matplotlib.transforms import Affine2D\n'
        '\n\n'
        + param_lines
        + '\n\n\n'
        + run_sim_src
        + '\n'
        + render_src
        + '\n\n'
        't, frames_y = _run_sim()\n'
        'render_video(t, frames_y.T, "video.mp4")\n'
        'print("Saved video.mp4")\n'
    )


if __name__ == "__main__":
    p = BlockOnSphereBasinParams()
    t, y = simulate(p, duration=p.duration)
    render_video(t, y, p, "video.mp4")
