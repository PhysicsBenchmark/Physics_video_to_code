"""
Wave Pulse on a Block-Loaded Hanging String
=============================================
A heavy block hangs from a rigid ceiling on a vertical taut string.  At t=0 a
Gaussian transverse pulse propagates DOWN the string at speed c=sqrt(T/mu),
strikes the block, reflects with phase inversion (block much heavier than the
string), and returns to the ceiling.

  d^2 u / d t^2 = c^2 d^2 u / d s^2,   c^2 = T/mu  (interior)
  u(0, t) = 0                                       (rigid ceiling)
  M_block u_tt(L, t) = -T u_s|_L                    (Newton II, block)
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict


@dataclass
class StringBlockWaveParams:
    L: float = 4.0
    mu: float = 0.5
    M_block: float = 0.5
    g: float = 9.81
    A: float = 0.30
    s_pulse: float = 1.0
    sigma: float = 0.30


def simulate(
    params: StringBlockWaveParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Returns (t_eval, U) where U.shape=(N+1, n_frames)."""
    L = params.L
    mu = params.mu
    M_block = params.M_block
    g = params.g
    A = params.A
    s_pulse = params.s_pulse
    sigma = params.sigma
    T = M_block * g
    c = (T / mu) ** 0.5

    N = 200
    dx = L / N
    s_grid = np.linspace(0, L, N + 1)
    n_per_frame = 8
    dt = 1.0 / (fps * n_per_frame)
    factor_int = (c * dt / dx) ** 2
    if factor_int >= 1.0:
        n_per_frame = int(np.ceil(c / (fps * dx))) + 4
        dt = 1.0 / (fps * n_per_frame)
        factor_int = (c * dt / dx) ** 2
    m_eff = M_block + 0.5 * mu * dx
    factor_block = T * dt * dt / (m_eff * dx)

    u_prev = A * np.exp(-((s_grid - s_pulse) ** 2) / (2 * sigma ** 2))
    u_prev[0] = 0.0
    du_ds_init = -A * (s_grid - s_pulse) / sigma ** 2 \
                 * np.exp(-((s_grid - s_pulse) ** 2) / (2 * sigma ** 2))
    v_init = -c * du_ds_init
    v_init[0] = 0.0

    a_init = np.zeros(N + 1)
    a_init[1:-1] = c**2 * (u_prev[2:] - 2 * u_prev[1:-1] + u_prev[:-2]) / dx ** 2
    a_init[-1] = T * (u_prev[-2] - u_prev[-1]) / (m_eff * dx)
    u_curr = u_prev + dt * v_init + 0.5 * dt * dt * a_init
    u_curr[0] = 0.0

    n_frames = int(duration * fps) + 1
    U = np.zeros((N + 1, n_frames))
    U[:, 0] = u_prev
    for frame in range(1, n_frames):
        for _ in range(n_per_frame):
            u_next = np.empty_like(u_curr)
            u_next[1:-1] = (2 * u_curr[1:-1] - u_prev[1:-1]
                            + factor_int * (u_curr[2:] - 2 * u_curr[1:-1] + u_curr[:-2]))
            u_next[0] = 0.0
            u_next[-1] = (2 * u_curr[-1] - u_prev[-1]
                          + factor_block * (u_curr[-2] - u_curr[-1]))
            u_prev, u_curr = u_curr, u_next
        U[:, frame] = u_curr
    return np.linspace(0, duration, n_frames), U


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: StringBlockWaveParams,
    output_path: str,
    fps: int = 30,
) -> None:
    L = params.L
    N = y.shape[0] - 1
    s_grid = np.linspace(0, L, N + 1)
    n_frames = y.shape[1]

    y_ceiling = 0.0
    block_w = 0.40
    block_h = 0.40
    y_block_top = y_ceiling - L
    y_floor = y_block_top - block_h

    fig_w, fig_h = 5, 8
    fig_aspect = fig_w / fig_h
    x_lo_d, x_hi_d = -0.95, 0.95
    y_lo_d = y_floor - 0.40
    y_hi_d = y_ceiling + 0.40
    dx_v, dy_v = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_v / dy_v < fig_aspect:
        extra = (fig_aspect * dy_v - dx_v) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
    else:
        extra = (dx_v / fig_aspect - dy_v) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi)
    ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal")
    ax.axis("off")

    ceiling_patch = patches.Rectangle((x_lo, y_ceiling), x_hi - x_lo, y_hi - y_ceiling,
                                      facecolor="#4a4e69", edgecolor="none", zorder=0)
    ax.add_patch(ceiling_patch)
    ax.plot([x_lo, x_hi], [y_ceiling, y_ceiling], color="#adb5bd", lw=2.5, zorder=1)
    floor_patch = patches.Rectangle((x_lo, y_lo), x_hi - x_lo, y_floor - y_lo,
                                    facecolor="#4a4e69", edgecolor="none", zorder=0)
    ax.add_patch(floor_patch)
    ax.plot([x_lo, x_hi], [y_floor, y_floor], color="#adb5bd", lw=2.5, zorder=1)
    ax.axvline(0.0, color="#3a4357", lw=1, ls="--", zorder=1)

    str_y_plot = y_ceiling - s_grid
    str_ln, = ax.plot([], [], "-", color="#a8dadc", lw=2.4, zorder=4)
    block_patch = patches.Rectangle((-block_w / 2, y_block_top - block_h),
                                    block_w, block_h,
                                    facecolor="#e63946", edgecolor="#adb5bd",
                                    lw=1.5, zorder=5)
    ax.add_patch(block_patch)

    def update(f):
        u_block = y[-1, f]
        str_x = y[:, f].copy()
        str_x[-1] = u_block
        str_ln.set_data(str_x, str_y_plot)
        block_patch.set_xy((u_block - block_w / 2, y_block_top - block_h))
        return str_ln, block_patch

    ani = animation.FuncAnimation(fig, update, frames=n_frames,
                                  interval=1000 / fps, blit=True)
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: StringBlockWaveParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""String Block Wave — auto-generated."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

L = {p["L"]}
mu = {p["mu"]}
M_block = {p["M_block"]}
g = {p["g"]}
A = {p["A"]}
s_pulse = {p["s_pulse"]}
sigma = {p["sigma"]}
duration = {duration}
T = M_block * g
c = (T/mu)**0.5

N = 200
dx = L/N
s_grid = np.linspace(0, L, N+1)
fps = 30
n_per_frame = 8
dt = 1.0/(fps*n_per_frame)
factor_int = (c*dt/dx)**2
if factor_int >= 1.0:
    n_per_frame = int(np.ceil(c/(fps*dx))) + 4
    dt = 1.0/(fps*n_per_frame)
    factor_int = (c*dt/dx)**2
m_eff = M_block + 0.5*mu*dx
factor_block = T*dt*dt/(m_eff*dx)

u_prev = A*np.exp(-((s_grid-s_pulse)**2)/(2*sigma**2))
u_prev[0] = 0.0
du_ds_init = -A*(s_grid-s_pulse)/sigma**2 * np.exp(-((s_grid-s_pulse)**2)/(2*sigma**2))
v_init = -c*du_ds_init; v_init[0] = 0.0

a_init = np.zeros(N+1)
a_init[1:-1] = c**2 * (u_prev[2:] - 2*u_prev[1:-1] + u_prev[:-2])/dx**2
a_init[-1] = T*(u_prev[-2]-u_prev[-1])/(m_eff*dx)
u_curr = u_prev + dt*v_init + 0.5*dt*dt*a_init
u_curr[0] = 0.0

n_frames = int(duration*fps)+1
U_frames = np.zeros((n_frames, N+1))
U_frames[0] = u_prev
for frame in range(1, n_frames):
    for _ in range(n_per_frame):
        u_next = np.empty_like(u_curr)
        u_next[1:-1] = (2*u_curr[1:-1] - u_prev[1:-1]
                        + factor_int*(u_curr[2:] - 2*u_curr[1:-1] + u_curr[:-2]))
        u_next[0] = 0.0
        u_next[-1] = (2*u_curr[-1] - u_prev[-1]
                      + factor_block*(u_curr[-2]-u_curr[-1]))
        u_prev, u_curr = u_curr, u_next
    U_frames[frame] = u_curr

y_ceiling = 0.0
block_w, block_h = 0.40, 0.40
y_block_top = y_ceiling - L
y_floor = y_block_top - block_h

fig_w, fig_h = 5, 8
fig_aspect = fig_w/fig_h
x_lo_d, x_hi_d = -0.95, 0.95
y_lo_d = y_floor - 0.40
y_hi_d = y_ceiling + 0.40
dx_v, dy_v = x_hi_d-x_lo_d, y_hi_d-y_lo_d
if dx_v/dy_v < fig_aspect:
    extra = (fig_aspect*dy_v - dx_v)/2.0
    x_lo, x_hi, y_lo, y_hi = x_lo_d-extra, x_hi_d+extra, y_lo_d, y_hi_d
else:
    extra = (dx_v/fig_aspect - dy_v)/2.0
    x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d-extra, y_hi_d+extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")

ax.add_patch(patches.Rectangle((x_lo, y_ceiling), x_hi-x_lo, y_hi-y_ceiling, facecolor="#4a4e69", edgecolor="none", zorder=0))
ax.plot([x_lo, x_hi], [y_ceiling, y_ceiling], color="#adb5bd", lw=2.5, zorder=1)
ax.add_patch(patches.Rectangle((x_lo, y_lo), x_hi-x_lo, y_floor-y_lo, facecolor="#4a4e69", edgecolor="none", zorder=0))
ax.plot([x_lo, x_hi], [y_floor, y_floor], color="#adb5bd", lw=2.5, zorder=1)
ax.axvline(0.0, color="#3a4357", lw=1, ls="--", zorder=1)

str_y_plot = y_ceiling - s_grid
str_ln, = ax.plot([], [], "-", color="#a8dadc", lw=2.4, zorder=4)
block_patch = patches.Rectangle((-block_w/2, y_block_top-block_h), block_w, block_h,
    facecolor="#e63946", edgecolor="#adb5bd", lw=1.5, zorder=5)
ax.add_patch(block_patch)

def update(f):
    u_block = U_frames[f, -1]
    str_x = U_frames[f, :].copy()
    str_x[-1] = u_block
    str_ln.set_data(str_x, str_y_plot)
    block_patch.set_xy((u_block - block_w/2, y_block_top - block_h))
    return str_ln, block_patch

ani = animation.FuncAnimation(fig, update, frames=n_frames, interval=1000/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="String Block Wave")
    parser.add_argument("--L", type=float, default=4.0)
    parser.add_argument("--mu", type=float, default=0.5)
    parser.add_argument("--M_block", type=float, default=0.5)
    parser.add_argument("--g", type=float, default=9.81)
    parser.add_argument("--A", type=float, default=0.30)
    parser.add_argument("--s_pulse", type=float, default=1.0)
    parser.add_argument("--sigma", type=float, default=0.30)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="string_block_wave.mp4")
    args = parser.parse_args()
    p = StringBlockWaveParams(
        L=args.L, mu=args.mu, M_block=args.M_block, g=args.g,
        A=args.A, s_pulse=args.s_pulse, sigma=args.sigma,
    )
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
