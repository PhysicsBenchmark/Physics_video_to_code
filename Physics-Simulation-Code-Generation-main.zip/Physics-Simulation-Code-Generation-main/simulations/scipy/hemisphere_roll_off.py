"""
Ball Rolling Off a Hemisphere — rolls on a fixed hemisphere, detaches at
cos(theta_c) = 10/17, projectile flight, ground bounces with Newton+Coulomb,
final coast on rolling resistance.
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class HemisphereRollOffParams:
    R: float = 2.50
    r: float = 0.30
    g: float = 9.8
    theta_0: float = 0.03
    e_g: float = 0.45
    mu_g: float = 0.50
    mu_r: float = 0.15


def _integrate(p: HemisphereRollOffParams, duration: float, fps: int):
    R, r, g = p.R, p.r, p.g
    theta_0 = p.theta_0
    e_g, mu_g, mu_r = p.e_g, p.mu_g, p.mu_r
    vy_settle = 0.50

    def derivs_hemi(t, s):
        return [s[1], (5.0 / 7.0) * g * np.sin(s[0]) / (R + r)]

    def event_detach(t, s):
        return 17.0 * np.cos(s[0]) - 10.0
    event_detach.terminal = True
    event_detach.direction = -1

    def derivs_flight(t, s):
        return [s[2], s[3], 0.0, -g]

    def event_ground(t, s):
        return s[1] - r
    event_ground.terminal = True
    event_ground.direction = -1

    t_eval_g = np.linspace(0, duration, int(duration * fps) + 1)
    xb_arr = np.zeros_like(t_eval_g); yb_arr = np.zeros_like(t_eval_g)
    phi_arr = np.zeros_like(t_eval_g)

    sol1 = solve_ivp(derivs_hemi, (0, duration), [theta_0, 0.0],
                     events=event_detach, dense_output=True,
                     rtol=1e-9, atol=1e-11, max_step=0.05)
    t1_end = sol1.t[-1]
    idx1 = np.where(t_eval_g <= t1_end + 1e-12)[0]
    for i in idx1:
        th = sol1.sol(t_eval_g[i])[0]
        xb_arr[i] = (R + r) * np.sin(th)
        yb_arr[i] = (R + r) * np.cos(th)
        phi_arr[i] = -((R + r) / r) * (th - theta_0)
    phi_at_detach = phi_arr[idx1[-1]] if len(idx1) else 0.0

    if sol1.status == 1:
        th_d = sol1.y[0, -1]; thd_d = sol1.y[1, -1]
        state = np.array([
            (R + r) * np.sin(th_d), (R + r) * np.cos(th_d),
            (R + r) * thd_d * np.cos(th_d), -(R + r) * thd_d * np.sin(th_d),
        ])
        omega_curr = -((R + r) / r) * thd_d
        phi_curr = phi_at_detach
        t_cur = t1_end
        for _ in range(50):
            if t_cur >= duration - 1e-9: break
            sol = solve_ivp(derivs_flight, (t_cur, duration), state,
                            events=event_ground, dense_output=True,
                            rtol=1e-9, atol=1e-11)
            seg_end = sol.t[-1]
            for i in np.where((t_eval_g > t_cur) & (t_eval_g <= seg_end + 1e-12))[0]:
                s = sol.sol(t_eval_g[i])
                xb_arr[i] = s[0]; yb_arr[i] = s[1]
                phi_arr[i] = phi_curr + omega_curr * (t_eval_g[i] - t_cur)
            state = sol.y[:, -1].copy()
            phi_curr = phi_curr + omega_curr * (seg_end - t_cur)
            t_cur = seg_end
            if sol.status != 1: break
            x_l, y_l, vx_l, vy_l = state
            vc_x_pre = vx_l + omega_curr * r
            Jn = -(1.0 + e_g) * vy_l
            Jt_stick = -vc_x_pre * (2.0 / 7.0)
            Jt_max = mu_g * Jn
            Jt = max(-Jt_max, min(Jt_max, Jt_stick))
            vx_post = vx_l + Jt
            vy_post = vy_l + Jn
            omega_curr = omega_curr + Jt / (0.4 * r)
            state = np.array([x_l, r + 1e-9, vx_post, vy_post])
            if abs(vy_post) < vy_settle: break
        # Phase 3b: coast on the ground
        if t_cur < duration - 1e-9:
            x_curr = state[0]; vx_curr = state[2]
            if abs(vx_curr) < 1e-3:
                i_rest = np.where(t_eval_g > t_cur)[0]
                xb_arr[i_rest] = x_curr; yb_arr[i_rest] = r
                phi_arr[i_rest] = phi_curr
            else:
                sign_vx = np.sign(vx_curr); decel = mu_r * g
                t_stop = abs(vx_curr) / decel
                t_end_roll = t_cur + t_stop
                for i in np.where((t_eval_g > t_cur) & (t_eval_g <= min(t_end_roll, duration)))[0]:
                    dt = t_eval_g[i] - t_cur
                    xb_arr[i] = x_curr + vx_curr * dt - 0.5 * sign_vx * decel * dt * dt
                    yb_arr[i] = r
                    phi_arr[i] = phi_curr - (vx_curr / r) * dt + (sign_vx * decel / (2 * r)) * dt * dt
                if t_end_roll < duration:
                    x_stop = x_curr + sign_vx * 0.5 * vx_curr * vx_curr / decel
                    phi_stop = phi_curr - (vx_curr / r) * t_stop + (sign_vx * decel / (2 * r)) * t_stop * t_stop
                    i_stop = np.where(t_eval_g > t_end_roll)[0]
                    xb_arr[i_stop] = x_stop; yb_arr[i_stop] = r
                    phi_arr[i_stop] = phi_stop

    return t_eval_g, np.vstack([xb_arr, yb_arr, phi_arr])


def simulate(params: HemisphereRollOffParams, duration: float = 12.0, fps: int = 30):
    return _integrate(params, duration, fps)


def render_video(t, y, params: HemisphereRollOffParams, output_path: str, fps: int = 30):
    p = params
    R, r = p.R, p.r
    xb_arr, yb_arr, phi_arr = y[0], y[1], y[2]
    fig_w, fig_h = 10, 4
    fig_aspect = fig_w / fig_h
    xpad, ypad = 0.40, 0.30
    x_lo_d = -R - xpad
    x_hi_d = max(R + xpad, xb_arr.max() + r + 0.4)
    y_lo_d = -ypad
    y_hi_d = max(R + r + ypad, yb_arr.max() + r + 0.2)
    dx_v, dy_v = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_v / dy_v < fig_aspect:
        extra = (fig_aspect * dy_v - dx_v) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
    else:
        extra = (dx_v / fig_aspect - dy_v) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1]); ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")
    ax.axhspan(y_lo, 0.0, color="#4a4e69", alpha=0.55, zorder=0)
    ax.axhline(0, color="#adb5bd", lw=2.5, zorder=1)
    hemi = patches.Wedge((0, 0), R, 0, 180, facecolor="#a8dadc",
                         edgecolor="white", lw=2, zorder=2)
    ax.add_patch(hemi)
    trail, = ax.plot([], [], "-", color="#e63946", alpha=0.40, lw=1.2, zorder=3)
    tx, ty = [], []
    ball = plt.Circle((xb_arr[0], yb_arr[0]), r, facecolor="#e63946",
                      edgecolor="white", lw=1.5, zorder=4)
    ax.add_patch(ball)
    spoke, = ax.plot([], [], "-", color="white", lw=2.0, zorder=5)

    def update(f):
        cx, cy = xb_arr[f], yb_arr[f]
        ball.set_center((cx, cy))
        sx = cx + r * np.cos(phi_arr[f])
        sy = cy + r * np.sin(phi_arr[f])
        spoke.set_data([cx, sx], [cy, sy])
        tx.append(cx); ty.append(cy)
        if len(tx) > 200:
            tx.pop(0); ty.pop(0)
        trail.set_data(tx, ty)
        return ball, spoke, trail

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000 / fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: HemisphereRollOffParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Hemisphere roll-off standalone script."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

R = {p["R"]}
r = {p["r"]}
g = {p["g"]}
theta_0 = {p["theta_0"]}
e_g = {p["e_g"]}
mu_g = {p["mu_g"]}
mu_r = {p["mu_r"]}
duration = {duration}
fps = 30
vy_settle = 0.50

def derivs_hemi(t, s):
    return [s[1], (5.0/7.0)*g*np.sin(s[0])/(R+r)]
def event_detach(t, s):
    return 17.0*np.cos(s[0]) - 10.0
event_detach.terminal = True; event_detach.direction = -1
def derivs_flight(t, s):
    return [s[2], s[3], 0.0, -g]
def event_ground(t, s):
    return s[1] - r
event_ground.terminal = True; event_ground.direction = -1

t_eval_g = np.linspace(0, duration, int(duration*fps)+1)
xb_arr = np.zeros_like(t_eval_g); yb_arr = np.zeros_like(t_eval_g)
phi_arr = np.zeros_like(t_eval_g)

sol1 = solve_ivp(derivs_hemi, (0, duration), [theta_0, 0.0],
                 events=event_detach, dense_output=True,
                 rtol=1e-9, atol=1e-11, max_step=0.05)
t1_end = sol1.t[-1]
idx1 = np.where(t_eval_g <= t1_end + 1e-12)[0]
for i in idx1:
    th = sol1.sol(t_eval_g[i])[0]
    xb_arr[i] = (R+r)*np.sin(th)
    yb_arr[i] = (R+r)*np.cos(th)
    phi_arr[i] = -((R+r)/r)*(th-theta_0)
phi_at_detach = phi_arr[idx1[-1]] if len(idx1) else 0.0

if sol1.status == 1:
    th_d = sol1.y[0,-1]; thd_d = sol1.y[1,-1]
    state = np.array([(R+r)*np.sin(th_d), (R+r)*np.cos(th_d),
                      (R+r)*thd_d*np.cos(th_d), -(R+r)*thd_d*np.sin(th_d)])
    omega_curr = -((R+r)/r)*thd_d
    phi_curr = phi_at_detach; t_cur = t1_end
    for _ in range(50):
        if t_cur >= duration - 1e-9: break
        sol = solve_ivp(derivs_flight, (t_cur, duration), state,
                        events=event_ground, dense_output=True,
                        rtol=1e-9, atol=1e-11)
        seg_end = sol.t[-1]
        for i in np.where((t_eval_g > t_cur) & (t_eval_g <= seg_end + 1e-12))[0]:
            s = sol.sol(t_eval_g[i])
            xb_arr[i] = s[0]; yb_arr[i] = s[1]
            phi_arr[i] = phi_curr + omega_curr*(t_eval_g[i]-t_cur)
        state = sol.y[:,-1].copy()
        phi_curr = phi_curr + omega_curr*(seg_end-t_cur)
        t_cur = seg_end
        if sol.status != 1: break
        x_l, y_l, vx_l, vy_l = state
        vc_x_pre = vx_l + omega_curr*r
        Jn = -(1.0+e_g)*vy_l
        Jt_stick = -vc_x_pre*(2.0/7.0)
        Jt_max = mu_g*Jn
        Jt = max(-Jt_max, min(Jt_max, Jt_stick))
        vx_post = vx_l + Jt; vy_post = vy_l + Jn
        omega_curr = omega_curr + Jt/(0.4*r)
        state = np.array([x_l, r+1e-9, vx_post, vy_post])
        if abs(vy_post) < vy_settle: break
    if t_cur < duration - 1e-9:
        x_curr = state[0]; vx_curr = state[2]
        if abs(vx_curr) < 1e-3:
            i_rest = np.where(t_eval_g > t_cur)[0]
            xb_arr[i_rest] = x_curr; yb_arr[i_rest] = r
            phi_arr[i_rest] = phi_curr
        else:
            sign_vx = np.sign(vx_curr); decel = mu_r*g
            t_stop = abs(vx_curr)/decel
            t_end_roll = t_cur + t_stop
            for i in np.where((t_eval_g > t_cur) & (t_eval_g <= min(t_end_roll, duration)))[0]:
                dt = t_eval_g[i] - t_cur
                xb_arr[i] = x_curr + vx_curr*dt - 0.5*sign_vx*decel*dt*dt
                yb_arr[i] = r
                phi_arr[i] = phi_curr - (vx_curr/r)*dt + (sign_vx*decel/(2*r))*dt*dt
            if t_end_roll < duration:
                x_stop = x_curr + sign_vx*0.5*vx_curr*vx_curr/decel
                phi_stop = phi_curr - (vx_curr/r)*t_stop + (sign_vx*decel/(2*r))*t_stop*t_stop
                i_stop = np.where(t_eval_g > t_end_roll)[0]
                xb_arr[i_stop] = x_stop; yb_arr[i_stop] = r
                phi_arr[i_stop] = phi_stop

fig_w, fig_h = 10, 4
fig_aspect = fig_w/fig_h
xpad, ypad = 0.40, 0.30
x_lo_d = -R - xpad
x_hi_d = max(R+xpad, xb_arr.max()+r+0.4)
y_lo_d = -ypad
y_hi_d = max(R+r+ypad, yb_arr.max()+r+0.2)
dx_v, dy_v = x_hi_d-x_lo_d, y_hi_d-y_lo_d
if dx_v/dy_v < fig_aspect:
    extra = (fig_aspect*dy_v - dx_v)/2.0
    x_lo, x_hi, y_lo, y_hi = x_lo_d-extra, x_hi_d+extra, y_lo_d, y_hi_d
else:
    extra = (dx_v/fig_aspect - dy_v)/2.0
    x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d-extra, y_hi_d+extra

fig = plt.figure(figsize=(fig_w,fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.axhspan(y_lo, 0.0, color="#4a4e69", alpha=0.55, zorder=0)
ax.axhline(0, color="#adb5bd", lw=2.5, zorder=1)
hemi = patches.Wedge((0,0), R, 0, 180, facecolor="#a8dadc",
                     edgecolor="white", lw=2, zorder=2)
ax.add_patch(hemi)
trail, = ax.plot([],[],"-",color="#e63946", alpha=0.40, lw=1.2, zorder=3)
tx, ty = [], []
ball = plt.Circle((xb_arr[0], yb_arr[0]), r, facecolor="#e63946",
                  edgecolor="white", lw=1.5, zorder=4)
ax.add_patch(ball)
spoke, = ax.plot([],[],"-",color="white", lw=2.0, zorder=5)

def update(f):
    cx, cy = xb_arr[f], yb_arr[f]
    ball.set_center((cx, cy))
    sx = cx + r*np.cos(phi_arr[f])
    sy = cy + r*np.sin(phi_arr[f])
    spoke.set_data([cx,sx],[cy,sy])
    tx.append(cx); ty.append(cy)
    if len(tx)>200: tx.pop(0); ty.pop(0)
    trail.set_data(tx, ty)
    return ball, spoke, trail

ani = animation.FuncAnimation(fig, update, frames=len(t_eval_g),
                              interval=1000/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    for fld, dflt in [("R",2.50),("r",0.30),("g",9.8),("theta_0",0.03),
                       ("e_g",0.45),("mu_g",0.50),("mu_r",0.15)]:
        parser.add_argument(f"--{fld}", type=float, default=dflt)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="hemisphere_roll_off.mp4")
    args = parser.parse_args()
    p = HemisphereRollOffParams(R=args.R, r=args.r, g=args.g,
                                theta_0=args.theta_0, e_g=args.e_g,
                                mu_g=args.mu_g, mu_r=args.mu_r)
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
