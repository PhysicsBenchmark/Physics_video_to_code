"""
Two-Body Gravity - Newton's law of universal gravitation.

Two point masses orbit each other in a closed elliptical Kepler orbit.
Initial conditions are set at periapsis with zero total momentum.
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class TwoBodyGravityParams:
    G: float = 1.0
    m1: float = 2.0
    m2: float = 1.0
    a_orbit: float = 1.0
    e: float = 0.40


def simulate(params: TwoBodyGravityParams, duration: float = 12.0, fps: int = 30):
    G, m1, m2, a, e = params.G, params.m1, params.m2, params.a_orbit, params.e
    M = m1 + m2
    r_p = a * (1.0 - e)
    v_p = np.sqrt(G * M * (1.0 + e) / (a * (1.0 - e)))
    x1_0 = -(m2 / M) * r_p; y1_0 = 0.0
    vx1_0 = 0.0; vy1_0 = +(m2 / M) * v_p
    x2_0 = +(m1 / M) * r_p; y2_0 = 0.0
    vx2_0 = 0.0; vy2_0 = -(m1 / M) * v_p

    def two_body(t, s):
        x1, y1, x2, y2, vx1, vy1, vx2, vy2 = s
        dx = x2 - x1; dy = y2 - y1
        inv_r3 = (dx * dx + dy * dy) ** (-1.5)
        fx = G * m1 * m2 * dx * inv_r3
        fy = G * m1 * m2 * dy * inv_r3
        return [vx1, vy1, vx2, vy2, fx / m1, fy / m1, -fx / m2, -fy / m2]

    t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
    y0 = [x1_0, y1_0, x2_0, y2_0, vx1_0, vy1_0, vx2_0, vy2_0]
    sol = solve_ivp(two_body, (0.0, duration), y0, t_eval=t_eval,
                    method="DOP853", rtol=1e-12, atol=1e-14)
    return sol.t, sol.y


def render_video(t, y, params: TwoBodyGravityParams, output_path: str, fps: int = 30):
    x1, y1, x2, y2 = y[0], y[1], y[2], y[3]
    all_x = np.concatenate([x1, x2])
    all_y = np.concatenate([y1, y2])
    pad = 0.20
    x_lo, x_hi = all_x.min() - pad, all_x.max() + pad
    y_lo, y_hi = all_y.min() - pad, all_y.max() + pad

    fig_w, fig_h = 6.0, 6.0
    fig_aspect = fig_w / fig_h
    dx, dy = x_hi - x_lo, y_hi - y_lo
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo -= extra; x_hi += extra
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        y_lo -= extra; y_hi += extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#0b0b1f")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#0b0b1f")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    rng = np.random.default_rng(7)
    star_x = rng.uniform(x_lo, x_hi, size=140)
    star_y = rng.uniform(y_lo, y_hi, size=140)
    star_s = rng.uniform(0.6, 3.5, size=140) ** 2
    star_a = rng.uniform(0.30, 0.85, size=140)
    ax.scatter(star_x, star_y, s=star_s, c="white", alpha=star_a, zorder=0, edgecolors='none')
    ax.plot([0.0], [0.0], '+', color="#e0e0e0", markersize=11, markeredgewidth=1.0, zorder=1)

    trail1, = ax.plot([], [], '-', color="#80c0ff", lw=1.4, alpha=0.75, zorder=2)
    trail2, = ax.plot([], [], '-', color="#ff8a5c", lw=1.4, alpha=0.75, zorder=2)

    m1, m2 = params.m1, params.m2
    m_max = max(m1, m2)
    size1 = 18.0 * (m1 / m_max) ** (1.0 / 3.0)
    size2 = 18.0 * (m2 / m_max) ** (1.0 / 3.0)
    body1, = ax.plot([], [], 'o', color="#80c0ff", markersize=size1,
                     markeredgecolor="white", markeredgewidth=1.0, zorder=4)
    body2, = ax.plot([], [], 'o', color="#ff8a5c", markersize=size2,
                     markeredgecolor="white", markeredgewidth=1.0, zorder=4)

    def update(f):
        trail1.set_data(x1[:f + 1], y1[:f + 1])
        trail2.set_data(x2[:f + 1], y2[:f + 1])
        body1.set_data([x1[f]], [y1[f]])
        body2.set_data([x2[f]], [y2[f]])
        return trail1, trail2, body1, body2

    ani = animation.FuncAnimation(fig, update, frames=len(t), interval=1000.0 / fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=2400), dpi=120)
    plt.close(fig)


def make_standalone_script(params: TwoBodyGravityParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Two-Body Gravity - auto-generated."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation

G        = {p["G"]}
m1       = {p["m1"]}
m2       = {p["m2"]}
a_orbit  = {p["a_orbit"]}
e        = {p["e"]}
duration = {duration}
fps      = 30

M    = m1 + m2
r_p  = a_orbit*(1.0-e)
v_p  = np.sqrt(G*M*(1.0+e)/(a_orbit*(1.0-e)))

x1_0=-(m2/M)*r_p; y1_0=0.0; vx1_0=0.0; vy1_0=+(m2/M)*v_p
x2_0=+(m1/M)*r_p; y2_0=0.0; vx2_0=0.0; vy2_0=-(m1/M)*v_p

def two_body(t, s):
    x1,y1,x2,y2,vx1,vy1,vx2,vy2 = s
    dx=x2-x1; dy=y2-y1
    inv_r3=(dx*dx+dy*dy)**(-1.5)
    fx=G*m1*m2*dx*inv_r3; fy=G*m1*m2*dy*inv_r3
    return [vx1,vy1,vx2,vy2, fx/m1,fy/m1, -fx/m2,-fy/m2]

t_eval=np.linspace(0.0,duration,int(duration*fps)+1)
y0=[x1_0,y1_0,x2_0,y2_0,vx1_0,vy1_0,vx2_0,vy2_0]
sol=solve_ivp(two_body,(0.0,duration),y0,t_eval=t_eval,
              method="DOP853",rtol=1e-12,atol=1e-14)
x1_arr,y1_arr=sol.y[0],sol.y[1]
x2_arr,y2_arr=sol.y[2],sol.y[3]

all_x=np.concatenate([x1_arr,x2_arr]); all_y=np.concatenate([y1_arr,y2_arr])
pad=0.20
x_lo,x_hi=all_x.min()-pad,all_x.max()+pad
y_lo,y_hi=all_y.min()-pad,all_y.max()+pad
fig_w,fig_h=6.0,6.0; fa=fig_w/fig_h
dx,dy=x_hi-x_lo,y_hi-y_lo
if dx/dy<fa:
    e_=(fa*dy-dx)/2.0; x_lo-=e_; x_hi+=e_
else:
    e_=(dx/fa-dy)/2.0; y_lo-=e_; y_hi+=e_
fig=plt.figure(figsize=(fig_w,fig_h),facecolor="#0b0b1f")
ax=fig.add_axes([0,0,1,1]); ax.set_facecolor("#0b0b1f")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi)
ax.set_aspect("equal"); ax.axis("off")
rng=np.random.default_rng(7)
sx=rng.uniform(x_lo,x_hi,size=140); sy=rng.uniform(y_lo,y_hi,size=140)
ss=rng.uniform(0.6,3.5,size=140)**2; sa=rng.uniform(0.30,0.85,size=140)
ax.scatter(sx,sy,s=ss,c="white",alpha=sa,zorder=0,edgecolors='none')
ax.plot([0.0],[0.0],'+',color="#e0e0e0",markersize=11,markeredgewidth=1.0,zorder=1)
trail1,=ax.plot([],[],'-',color="#80c0ff",lw=1.4,alpha=0.75,zorder=2)
trail2,=ax.plot([],[],'-',color="#ff8a5c",lw=1.4,alpha=0.75,zorder=2)
m_max=max(m1,m2); size1=18.0*(m1/m_max)**(1./3.); size2=18.0*(m2/m_max)**(1./3.)
body1,=ax.plot([],[],'o',color="#80c0ff",markersize=size1,markeredgecolor="white",markeredgewidth=1.0,zorder=4)
body2,=ax.plot([],[],'o',color="#ff8a5c",markersize=size2,markeredgecolor="white",markeredgewidth=1.0,zorder=4)

def update(f):
    trail1.set_data(x1_arr[:f+1],y1_arr[:f+1])
    trail2.set_data(x2_arr[:f+1],y2_arr[:f+1])
    body1.set_data([x1_arr[f]],[y1_arr[f]])
    body2.set_data([x2_arr[f]],[y2_arr[f]])
    return trail1,trail2,body1,body2

ani=animation.FuncAnimation(fig,update,frames=len(t_eval),interval=1000.0/fps,blit=True)
ani.save("video.mp4",writer=animation.FFMpegWriter(fps=fps,bitrate=2400),dpi=120)
plt.close(); print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--G", type=float, default=1.0)
    parser.add_argument("--m1", type=float, default=2.0)
    parser.add_argument("--m2", type=float, default=1.0)
    parser.add_argument("--a_orbit", type=float, default=1.0)
    parser.add_argument("--e", type=float, default=0.40)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="video.mp4")
    args = parser.parse_args()
    p = TwoBodyGravityParams(G=args.G, m1=args.m1, m2=args.m2,
                             a_orbit=args.a_orbit, e=args.e)
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
