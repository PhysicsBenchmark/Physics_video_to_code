"""
Wave pulse interference on an infinite string - 1D wave equation FDM.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class WaveInterferenceParams:
    T: float = 1.0
    mu: float = 1.0
    A_R: float = 0.55
    sigma_R: float = 0.30
    x_R0: float = -2.50
    A_L: float = -0.35
    sigma_L: float = 0.45
    x_L0: float = 2.50


def simulate(params: WaveInterferenceParams, duration: float = 12.0, fps: int = 30):
    p = params
    c = (p.T / p.mu) ** 0.5
    X_max = 18.0
    N = 900
    dx = 2 * X_max / N
    x_grid = np.linspace(-X_max, X_max, N + 1)
    n_per_frame = 5
    dt = 1.0 / (fps * n_per_frame)
    factor = (c * dt / dx) ** 2
    if factor >= 1.0:
        # Reduce dt for CFL
        dt = 0.99 * dx / c / n_per_frame
        factor = (c * dt / dx) ** 2

    def gauss(x, A, x0, sig): return A * np.exp(-((x - x0) ** 2) / (2 * sig ** 2))
    def gauss_dx(x, A, x0, sig):
        return -A * (x - x0) / sig ** 2 * np.exp(-((x - x0) ** 2) / (2 * sig ** 2))

    y_prev = gauss(x_grid, p.A_R, p.x_R0, p.sigma_R) + gauss(x_grid, p.A_L, p.x_L0, p.sigma_L)
    v_init = (-c) * gauss_dx(x_grid, p.A_R, p.x_R0, p.sigma_R) + (c) * gauss_dx(x_grid, p.A_L, p.x_L0, p.sigma_L)
    y_prev[0] = y_prev[-1] = 0.0
    v_init[0] = v_init[-1] = 0.0
    a_init = np.zeros(N + 1)
    a_init[1:-1] = c**2 * (y_prev[2:] - 2 * y_prev[1:-1] + y_prev[:-2]) / dx ** 2
    y_curr = y_prev + dt * v_init + 0.5 * dt * dt * a_init
    y_curr[0] = y_curr[-1] = 0.0

    n_frames = int(duration * fps) + 1
    Y_frames = np.zeros((n_frames, N + 1))
    Y_frames[0] = y_prev
    for frame in range(1, n_frames):
        for _ in range(n_per_frame):
            y_next = np.empty_like(y_curr)
            y_next[1:-1] = (2 * y_curr[1:-1] - y_prev[1:-1]
                            + factor * (y_curr[2:] - 2 * y_curr[1:-1] + y_curr[:-2]))
            y_next[0] = y_next[-1] = 0.0
            y_prev, y_curr = y_curr, y_next
        Y_frames[frame] = y_curr

    t_eval = np.linspace(0.0, duration, n_frames)
    return t_eval, Y_frames.T  # shape (N+1, n_frames)


def render_video(t, y, params: WaveInterferenceParams, output_path: str, fps: int = 30):
    Y_frames = y.T  # (n_frames, N+1)
    n_frames, N1 = Y_frames.shape
    X_max = 18.0
    x_grid = np.linspace(-X_max, X_max, N1)
    fig_w, fig_h = 10, 4
    fig_aspect = fig_w / fig_h
    y_amp_pad = 1.05
    X_view = 4.0
    x_lo_d, x_hi_d = -X_view - 0.2, +X_view + 0.2
    y_lo_d, y_hi_d = -y_amp_pad, +y_amp_pad
    dx_v, dy_v = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_v / dy_v < fig_aspect:
        extra = (fig_aspect * dy_v - dx_v) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
    else:
        extra = (dx_v / fig_aspect - dy_v) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra
    i_lo = max(0, int(np.searchsorted(x_grid, x_lo)))
    i_hi = min(len(x_grid), int(np.searchsorted(x_grid, x_hi)) + 1)
    x_view = x_grid[i_lo:i_hi]

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")
    ax.axhline(0, color="#3a4357", lw=1, ls="--", zorder=1)
    str_ln, = ax.plot([], [], "-", color="#a8dadc", lw=2.4, zorder=3)

    def update(f):
        str_ln.set_data(x_view, Y_frames[f, i_lo:i_hi])
        return (str_ln,)

    ani = animation.FuncAnimation(fig, update, frames=n_frames, interval=1000 / fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: WaveInterferenceParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Wave interference - auto-generated."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

T={p["T"]}; mu={p["mu"]}; c=(T/mu)**0.5
A_R={p["A_R"]}; sigma_R={p["sigma_R"]}; x_R0={p["x_R0"]}
A_L={p["A_L"]}; sigma_L={p["sigma_L"]}; x_L0={p["x_L0"]}
duration={duration}
X_max=18.0; N=900; dx=2*X_max/N
x_grid=np.linspace(-X_max,X_max,N+1)
fps=30; n_per_frame=5
dt=1.0/(fps*n_per_frame)
factor=(c*dt/dx)**2
if factor>=1.0:
    dt=0.99*dx/c/n_per_frame; factor=(c*dt/dx)**2

def gauss(x,A,x0,s): return A*np.exp(-((x-x0)**2)/(2*s**2))
def gauss_dx(x,A,x0,s): return -A*(x-x0)/s**2 * np.exp(-((x-x0)**2)/(2*s**2))

y_prev=gauss(x_grid,A_R,x_R0,sigma_R)+gauss(x_grid,A_L,x_L0,sigma_L)
v_init=(-c)*gauss_dx(x_grid,A_R,x_R0,sigma_R)+( c)*gauss_dx(x_grid,A_L,x_L0,sigma_L)
y_prev[0]=y_prev[-1]=0.0; v_init[0]=v_init[-1]=0.0
a_init=np.zeros(N+1)
a_init[1:-1]=c**2*(y_prev[2:]-2*y_prev[1:-1]+y_prev[:-2])/dx**2
y_curr=y_prev+dt*v_init+0.5*dt*dt*a_init
y_curr[0]=y_curr[-1]=0.0

n_frames=int(duration*fps)+1
Y=np.zeros((n_frames,N+1)); Y[0]=y_prev
for fr in range(1,n_frames):
    for _ in range(n_per_frame):
        y_next=np.empty_like(y_curr)
        y_next[1:-1]=(2*y_curr[1:-1]-y_prev[1:-1]+factor*(y_curr[2:]-2*y_curr[1:-1]+y_curr[:-2]))
        y_next[0]=y_next[-1]=0.0
        y_prev,y_curr=y_curr,y_next
    Y[fr]=y_curr

fig_w,fig_h=10,4; fa=fig_w/fig_h
y_amp_pad=1.05; X_view=4.0
x_lo_d,x_hi_d=-X_view-0.2,+X_view+0.2
y_lo_d,y_hi_d=-y_amp_pad,+y_amp_pad
dx_v,dy_v=x_hi_d-x_lo_d,y_hi_d-y_lo_d
if dx_v/dy_v<fa:
    e=(fa*dy_v-dx_v)/2.0; x_lo,x_hi,y_lo,y_hi=x_lo_d-e,x_hi_d+e,y_lo_d,y_hi_d
else:
    e=(dx_v/fa-dy_v)/2.0; x_lo,x_hi,y_lo,y_hi=x_lo_d,x_hi_d,y_lo_d-e,y_hi_d+e
i_lo=max(0,int(np.searchsorted(x_grid,x_lo)))
i_hi=min(len(x_grid),int(np.searchsorted(x_grid,x_hi))+1)
x_view=x_grid[i_lo:i_hi]

fig=plt.figure(figsize=(fig_w,fig_h),facecolor="#1a1a2e")
ax=fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi); ax.set_aspect("equal"); ax.axis("off")
ax.axhline(0,color="#3a4357",lw=1,ls="--",zorder=1)
str_ln,=ax.plot([],[],"-",color="#a8dadc",lw=2.4,zorder=3)

def update(f):
    str_ln.set_data(x_view,Y[f,i_lo:i_hi]); return (str_ln,)

ani=animation.FuncAnimation(fig,update,frames=n_frames,interval=1000/fps,blit=True)
ani.save("video.mp4",writer=animation.FFMpegWriter(fps=fps,bitrate=1800),dpi=120)
plt.close(); print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    for fld, dflt in asdict(WaveInterferenceParams()).items():
        parser.add_argument(f"--{fld}", type=float, default=dflt)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="video.mp4")
    args = parser.parse_args()
    p = WaveInterferenceParams(**{k: getattr(args, k) for k in asdict(WaveInterferenceParams()).keys()})
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
