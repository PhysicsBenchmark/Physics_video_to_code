"""
Pendulum-Block Strike — pendulum bob hinged above the floor, swinging into
a block sitting on a frictional floor. Closed-form post-impact rule for
oblique pendulum-block collision combined with floor friction on the block.
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle, Circle
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class PendulumBlockStrikeParams:
    g: float = 9.8
    m_b: float = 1.5
    M_B: float = 1.0
    L: float = 1.2
    r_bob: float = 0.10
    s: float = 0.50
    e: float = 0.60
    mu_k: float = 0.30
    b_p: float = 0.05
    theta0: float = 1.13446
    omega0: float = 0.0
    x_b0: float = 0.0
    v_b0: float = 0.0


def _integrate(p: PendulumBlockStrikeParams, duration: float, fps: int):
    g, m_b, M_B = p.g, p.m_b, p.M_B
    L, r_bob, s, e, mu_k, b_p = p.L, p.r_bob, p.s, p.e, p.mu_k, p.b_p
    x_h = p.x_b0 + s / 2.0 + r_bob
    y_h = L + s / 2.0
    I_b = m_b * L * L

    def make_dyn(block_active):
        def dyn(t, y):
            theta, omega, x_b, v_b = y
            dtheta = omega
            domega = -(g / L) * np.sin(theta) - (b_p / I_b) * omega
            if block_active and abs(v_b) > 1e-12:
                dv_b = -mu_k * g * np.sign(v_b); dx_b = v_b
            else:
                dv_b = 0.0; dx_b = 0.0
            return [dtheta, domega, dx_b, dv_b]
        return dyn

    def gap_event(t, y):
        return (x_h + L * np.sin(y[0]) - r_bob) - (y[2] + s / 2.0)
    gap_event.terminal = True; gap_event.direction = -1

    def collision_step(state):
        theta, omega, x_b, v_b = state
        c = np.cos(theta)
        den = m_b + M_B * c * c
        omega_new = (omega * (m_b - e * M_B * c * c)
                     + (1.0 + e) * M_B * v_b * c / L) / den
        v_b_new = v_b - m_b * L * (omega_new - omega) / (M_B * c)
        return np.array([theta, omega_new, x_b, v_b_new])

    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    theta_arr = np.zeros_like(t_eval); omega_arr = np.zeros_like(t_eval)
    xb_arr = np.zeros_like(t_eval); vb_arr = np.zeros_like(t_eval)
    state = np.array([p.theta0, p.omega0, p.x_b0, p.v_b0], dtype=float)
    theta_arr[0], omega_arr[0], xb_arr[0], vb_arr[0] = state
    block_active = abs(p.v_b0) > 1e-12
    last_idx = 1; t_cur = 0.0

    for _seg in range(200):
        if t_cur >= duration - 1e-9 or last_idx >= len(t_eval): break
        events = [gap_event]
        vb_event = None
        if block_active:
            sgn = float(np.sign(state[3]))
            def vb_event_fn(t, y, _sgn=sgn): return y[3]
            vb_event_fn.terminal = True
            vb_event_fn.direction = -sgn
            vb_event = vb_event_fn
            events.append(vb_event)
        sol = solve_ivp(make_dyn(block_active), (t_cur, duration), state,
                        events=events, dense_output=True,
                        max_step=0.02, rtol=1e-9, atol=1e-11)
        seg_end = sol.t[-1]
        while last_idx < len(t_eval) and t_eval[last_idx] <= seg_end + 1e-12:
            st = sol.sol(t_eval[last_idx])
            theta_arr[last_idx], omega_arr[last_idx], xb_arr[last_idx], vb_arr[last_idx] = st
            last_idx += 1
        state = sol.y[:, -1].copy()
        t_cur = seg_end
        if sol.status != 1: break
        fired_collision = (len(sol.t_events[0]) > 0 and
                           abs(sol.t_events[0][-1] - seg_end) < 1e-9)
        fired_block_stop = (vb_event is not None and len(sol.t_events) >= 2 and
                            len(sol.t_events[1]) > 0 and
                            abs(sol.t_events[1][-1] - seg_end) < 1e-9)
        if fired_collision:
            state = collision_step(state)
            block_active = abs(state[3]) > 1e-9
        elif fired_block_stop:
            state[3] = 0.0; block_active = False

    if last_idx < len(t_eval):
        theta_arr[last_idx:] = state[0]
        omega_arr[last_idx:] = state[1]
        xb_arr[last_idx:] = state[2]
        vb_arr[last_idx:] = state[3]

    return t_eval, np.vstack([theta_arr, omega_arr, xb_arr, vb_arr])


def simulate(params: PendulumBlockStrikeParams, duration: float = 12.0, fps: int = 30):
    return _integrate(params, duration, fps)


def render_video(t, y, params: PendulumBlockStrikeParams, output_path: str, fps: int = 30):
    p = params
    L, r_bob, s = p.L, p.r_bob, p.s
    x_h = p.x_b0 + s / 2.0 + r_bob
    y_h = L + s / 2.0
    theta_arr = y[0]; xb_arr = y[2]
    bob_x = x_h + L * np.sin(theta_arr)
    bob_y = y_h - L * np.cos(theta_arr)

    xs_all = np.concatenate([bob_x, xb_arr - s / 2.0 - 0.05, xb_arr + s / 2.0 + 0.05, [x_h]])
    x_min = xs_all.min() - 0.30; x_max = xs_all.max() + 0.30
    y_min = -0.30; y_max = y_h + 0.35
    fig_w, fig_h = 8, 5
    fig_aspect = fig_w / fig_h
    dx = x_max - x_min; dy = y_max - y_min
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_min -= extra; x_max += extra
    else:
        extra = dx / fig_aspect - dy
        y_max += extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1]); ax.set_facecolor("#16213e")
    ax.set_xlim(x_min, x_max); ax.set_ylim(y_min, y_max)
    ax.set_aspect("equal"); ax.axis("off")
    ax.axhspan(y_min, 0.0, color="#4a4e69", alpha=0.55, zorder=0)
    ax.axhline(0, color="#adb5bd", lw=2, zorder=1)
    ax.plot([x_h - 0.09, x_h + 0.09], [y_h + 0.05, y_h + 0.05], '-',
            color="#bcbcbc", lw=3, zorder=4)
    ax.plot([x_h], [y_h], 'o', color="white", ms=8, zorder=5)
    block_patch = Rectangle((xb_arr[0] - s / 2.0, 0.0), s, s,
                            facecolor="#8ecae6", edgecolor="white", lw=1.5, zorder=2)
    ax.add_patch(block_patch)
    rod_line, = ax.plot([], [], '-', color="#a8dadc", lw=2.5, zorder=3)
    bob = Circle((bob_x[0], bob_y[0]), r_bob, facecolor="#e63946",
                 edgecolor="white", lw=1.2, zorder=4)
    ax.add_patch(bob)

    def update(f):
        rod_line.set_data([x_h, bob_x[f]], [y_h, bob_y[f]])
        bob.center = (bob_x[f], bob_y[f])
        block_patch.set_xy((xb_arr[f] - s / 2.0, 0.0))
        return rod_line, bob, block_patch

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0 / fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: PendulumBlockStrikeParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Pendulum-block strike standalone script."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle, Circle

g = {p["g"]}
m_b = {p["m_b"]}
M_B = {p["M_B"]}
L = {p["L"]}
r_bob = {p["r_bob"]}
s = {p["s"]}
e = {p["e"]}
mu_k = {p["mu_k"]}
b_p = {p["b_p"]}
theta0 = {p["theta0"]}
omega0 = {p["omega0"]}
x_b0 = {p["x_b0"]}
v_b0 = {p["v_b0"]}
duration = {duration}
fps = 30

x_h = x_b0 + s/2.0 + r_bob
y_h = L + s/2.0
I_b = m_b*L*L

def make_dyn(block_active):
    def dyn(t, y):
        theta, omega, x_b, v_b = y
        dtheta = omega
        domega = -(g/L)*np.sin(theta) - (b_p/I_b)*omega
        if block_active and abs(v_b) > 1e-12:
            dv_b = -mu_k*g*np.sign(v_b); dx_b = v_b
        else:
            dv_b = 0.0; dx_b = 0.0
        return [dtheta, domega, dx_b, dv_b]
    return dyn

def gap_event(t, y):
    return (x_h + L*np.sin(y[0]) - r_bob) - (y[2] + s/2.0)
gap_event.terminal = True; gap_event.direction = -1

def collision_step(state):
    theta, omega, x_b, v_b = state
    c = np.cos(theta)
    den = m_b + M_B*c*c
    omega_new = (omega*(m_b - e*M_B*c*c) + (1.0+e)*M_B*v_b*c/L)/den
    v_b_new = v_b - m_b*L*(omega_new - omega)/(M_B*c)
    return np.array([theta, omega_new, x_b, v_b_new])

t_eval = np.linspace(0, duration, int(duration*fps)+1)
theta_arr = np.zeros_like(t_eval); omega_arr = np.zeros_like(t_eval)
xb_arr = np.zeros_like(t_eval); vb_arr = np.zeros_like(t_eval)
state = np.array([theta0, omega0, x_b0, v_b0], dtype=float)
theta_arr[0], omega_arr[0], xb_arr[0], vb_arr[0] = state
block_active = abs(v_b0) > 1e-12
last_idx = 1; t_cur = 0.0

for _seg in range(200):
    if t_cur >= duration - 1e-9 or last_idx >= len(t_eval): break
    events = [gap_event]
    vb_event = None
    if block_active:
        sgn = float(np.sign(state[3]))
        def vb_event_fn(t, y, _sgn=sgn): return y[3]
        vb_event_fn.terminal = True; vb_event_fn.direction = -sgn
        vb_event = vb_event_fn
        events.append(vb_event)
    sol = solve_ivp(make_dyn(block_active), (t_cur, duration), state,
                    events=events, dense_output=True,
                    max_step=0.02, rtol=1e-9, atol=1e-11)
    seg_end = sol.t[-1]
    while last_idx < len(t_eval) and t_eval[last_idx] <= seg_end + 1e-12:
        st = sol.sol(t_eval[last_idx])
        theta_arr[last_idx], omega_arr[last_idx], xb_arr[last_idx], vb_arr[last_idx] = st
        last_idx += 1
    state = sol.y[:,-1].copy(); t_cur = seg_end
    if sol.status != 1: break
    fired_collision = (len(sol.t_events[0]) > 0 and
                       abs(sol.t_events[0][-1] - seg_end) < 1e-9)
    fired_block_stop = (vb_event is not None and len(sol.t_events) >= 2 and
                        len(sol.t_events[1]) > 0 and
                        abs(sol.t_events[1][-1] - seg_end) < 1e-9)
    if fired_collision:
        state = collision_step(state)
        block_active = abs(state[3]) > 1e-9
    elif fired_block_stop:
        state[3] = 0.0; block_active = False

if last_idx < len(t_eval):
    theta_arr[last_idx:] = state[0]
    omega_arr[last_idx:] = state[1]
    xb_arr[last_idx:] = state[2]
    vb_arr[last_idx:] = state[3]

bob_x = x_h + L*np.sin(theta_arr)
bob_y = y_h - L*np.cos(theta_arr)
xs_all = np.concatenate([bob_x, xb_arr - s/2.0 - 0.05, xb_arr + s/2.0 + 0.05, [x_h]])
x_min = xs_all.min() - 0.30; x_max = xs_all.max() + 0.30
y_min = -0.30; y_max = y_h + 0.35
fig_w, fig_h = 8, 5
fig_aspect = fig_w/fig_h
dx = x_max-x_min; dy = y_max-y_min
if dx/dy < fig_aspect:
    extra = (fig_aspect*dy - dx)/2.0
    x_min -= extra; x_max += extra
else:
    extra = dx/fig_aspect - dy
    y_max += extra

fig = plt.figure(figsize=(fig_w,fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_min,x_max); ax.set_ylim(y_min,y_max)
ax.set_aspect("equal"); ax.axis("off")
ax.axhspan(y_min, 0.0, color="#4a4e69", alpha=0.55, zorder=0)
ax.axhline(0, color="#adb5bd", lw=2, zorder=1)
ax.plot([x_h-0.09, x_h+0.09],[y_h+0.05, y_h+0.05], '-',
        color="#bcbcbc", lw=3, zorder=4)
ax.plot([x_h],[y_h], 'o', color="white", ms=8, zorder=5)
block_patch = Rectangle((xb_arr[0]-s/2.0, 0.0), s, s,
                        facecolor="#8ecae6", edgecolor="white", lw=1.5, zorder=2)
ax.add_patch(block_patch)
rod_line, = ax.plot([],[], '-', color="#a8dadc", lw=2.5, zorder=3)
bob = Circle((bob_x[0], bob_y[0]), r_bob, facecolor="#e63946",
             edgecolor="white", lw=1.2, zorder=4)
ax.add_patch(bob)

def update(f):
    rod_line.set_data([x_h, bob_x[f]],[y_h, bob_y[f]])
    bob.center = (bob_x[f], bob_y[f])
    block_patch.set_xy((xb_arr[f] - s/2.0, 0.0))
    return rod_line, bob, block_patch

ani = animation.FuncAnimation(fig, update, frames=len(t_eval),
                              interval=1000.0/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    for fld, dflt in [("g",9.8),("m_b",1.5),("M_B",1.0),("L",1.2),
                       ("r_bob",0.10),("s",0.50),("e",0.60),("mu_k",0.30),
                       ("b_p",0.05),("theta0",1.13446),("omega0",0.0),
                       ("x_b0",0.0),("v_b0",0.0)]:
        parser.add_argument(f"--{fld}", type=float, default=dflt)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="pendulum_block_strike.mp4")
    args = parser.parse_args()
    p = PendulumBlockStrikeParams(
        g=args.g, m_b=args.m_b, M_B=args.M_B, L=args.L, r_bob=args.r_bob,
        s=args.s, e=args.e, mu_k=args.mu_k, b_p=args.b_p,
        theta0=args.theta0, omega0=args.omega0, x_b0=args.x_b0, v_b0=args.v_b0)
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
