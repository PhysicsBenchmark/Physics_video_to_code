"""
Tilting Wedge with Upright Cylinder
=====================================
A right-triangular wedge sits on a horizontal floor with its lower-left vertex
pinned at the origin. The wedge's slope angle alpha(t) grows linearly until
the toppling-critical angle alpha_topple = arctan(2R/H). Then in successive
phases:

  Phase 1: quasi-static tilt; cylinder upright on slope
  Phase 2: cylinder topples about its down-slope base edge
  Phase 3: inelastic landing impulse (instantaneous; restitution e)
  Phase 4: cylinder lies flat on slope, slides down with kinetic friction mu_k
  Phase 5: short kinematic tip transition + floor slide under mu_floor until rest
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon
from dataclasses import dataclass, asdict


@dataclass
class TiltingWedgeCylinderParams:
    g: float = 9.8
    R: float = 0.10
    H: float = 0.40
    M: float = 1.0
    mu_s: float = 0.7
    mu_k: float = 0.4
    mu_floor: float = 0.3
    e: float = 0.5
    alpha_0: float = 0.0
    alpha_dot: float = 0.05
    L_slope: float = 1.50
    dt_tip: float = 0.40


def _build_phases(params: TiltingWedgeCylinderParams):
    """Compute all phase boundaries and reusable callbacks. Returns a dict of state."""
    g = params.g
    R = params.R
    H = params.H
    M = params.M
    mu_k = params.mu_k
    mu_floor = params.mu_floor
    e_rest = params.e
    alpha_0 = params.alpha_0
    alpha_dot = params.alpha_dot
    L_slope = params.L_slope
    dt_tip = params.dt_tip

    alpha_topple = float(np.arctan(2.0 * R / H))
    t_topple = (alpha_topple - alpha_0) / alpha_dot
    I_centre = 0.25 * M * R ** 2 + (1.0 / 12.0) * M * H ** 2
    d_pivot = float(np.sqrt(R ** 2 + (H / 2.0) ** 2))
    I_pivot = I_centre + M * d_pivot ** 2
    s_mid = 0.5 * L_slope
    alpha_final = alpha_topple

    def topple_ode(t, state):
        phi, om = state
        dom = M * g * ((H / 2.0) * np.sin(phi + alpha_final)
                       - R * np.cos(phi + alpha_final)) / I_pivot
        return [om, dom]

    def topple_done(t, state):
        return state[0] - np.pi / 2.0
    topple_done.terminal = True
    topple_done.direction = +1

    phi_init = 1e-3
    sol_topple = solve_ivp(topple_ode, (0.0, 10.0), [phi_init, 0.0],
                           events=topple_done, dense_output=True,
                           rtol=1e-9, atol=1e-11, max_step=0.01)
    t_topple_dur = float(sol_topple.t_events[0][0])
    phi_dot_at_end = float(sol_topple.y_events[0][0][1])

    KE_pre = 0.5 * I_pivot * phi_dot_at_end ** 2
    KE_post = (e_rest ** 2) * KE_pre
    v_slide_0 = float(np.sqrt(2.0 * KE_post / M))

    s_pivot = s_mid - R
    s_CoM_after = s_pivot - H / 2.0
    s_CoM_at_foot = H / 2.0
    ds_phase4 = s_CoM_after - s_CoM_at_foot

    a_slope = g * (np.sin(alpha_final) - mu_k * np.cos(alpha_final))
    if a_slope <= 0:
        # Cylinder doesn't slide down — provide a minimal positive value
        a_slope = 1e-6
    v_at_foot = float(np.sqrt(max(v_slide_0 ** 2 + 2.0 * a_slope * ds_phase4, 0.0)))
    t_phase4_dur = (v_at_foot - v_slide_0) / a_slope

    v_lead_h_signed = -v_at_foot * np.cos(alpha_final)
    v_floor_0 = abs(v_lead_h_signed)
    a_floor = mu_floor * g
    t_phase5_floor_dur = v_floor_0 / a_floor if a_floor > 0 else 0.0
    dx_floor_mag = v_floor_0 ** 2 / (2.0 * a_floor) if a_floor > 0 else 0.0

    x_lead_at_tip_start = 0.0
    x_lead_at_tip_end = x_lead_at_tip_start + v_lead_h_signed * dt_tip
    x_CoM_at_tip_end = x_lead_at_tip_end + H / 2.0
    x_CoM_at_rest = x_CoM_at_tip_end - dx_floor_mag

    t1_end = t_topple
    t2_end = t1_end + t_topple_dur
    t4_end = t2_end + t_phase4_dur
    t_tip_end = t4_end + dt_tip
    t_rest = t_tip_end + t_phase5_floor_dur

    return {
        "alpha_0": alpha_0, "alpha_dot": alpha_dot, "alpha_final": alpha_final,
        "alpha_topple": alpha_topple, "t_topple": t_topple,
        "I_pivot": I_pivot, "s_mid": s_mid,
        "sol_topple": sol_topple, "t_topple_dur": t_topple_dur,
        "phi_dot_at_end": phi_dot_at_end,
        "KE_pre": KE_pre, "KE_post": KE_post, "v_slide_0": v_slide_0,
        "s_pivot": s_pivot, "s_CoM_after": s_CoM_after,
        "ds_phase4": ds_phase4, "a_slope": a_slope,
        "v_at_foot": v_at_foot, "t_phase4_dur": t_phase4_dur,
        "v_lead_h_signed": v_lead_h_signed,
        "v_floor_0": v_floor_0, "a_floor": a_floor,
        "t_phase5_floor_dur": t_phase5_floor_dur,
        "x_lead_at_tip_start": x_lead_at_tip_start,
        "x_lead_at_tip_end": x_lead_at_tip_end,
        "x_CoM_at_tip_end": x_CoM_at_tip_end,
        "x_CoM_at_rest": x_CoM_at_rest,
        "t1_end": t1_end, "t2_end": t2_end, "t4_end": t4_end,
        "t_tip_end": t_tip_end, "t_rest": t_rest, "dt_tip": dt_tip,
        "L_slope": L_slope, "R": params.R, "H": params.H,
    }


def simulate(
    params: TiltingWedgeCylinderParams,
    duration: float = 16.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Returns (t, alpha_array) where alpha_array[0] is wedge angle for now."""
    P = _build_phases(params)
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    alpha_arr = np.where(t_eval < P["t_topple"],
                         params.alpha_0 + params.alpha_dot * t_eval,
                         P["alpha_final"])
    return t_eval, alpha_arr.reshape(1, -1)


def _alpha_at(P, t):
    if t < P["t_topple"]:
        return P["alpha_0"] + P["alpha_dot"] * t
    return P["alpha_final"]


def _slope_basis(alpha):
    ca, sa = np.cos(alpha), np.sin(alpha)
    return np.array([ca, sa]), np.array([-sa, ca])


def _slope_to_lab(s, n, alpha):
    e_s, e_n = _slope_basis(alpha)
    return (s * e_s[0] + n * e_n[0], s * e_s[1] + n * e_n[1])


def _wedge_corners(alpha, L_slope):
    e_s, _ = _slope_basis(alpha)
    V0 = np.array([0.0, 0.0])
    V1 = V0 + L_slope * e_s
    V2 = np.array([V1[0], 0.0])
    return [tuple(V0), tuple(V2), tuple(V1)]


def _cylinder_corners_at(P, t):
    R = P["R"]; H = P["H"]
    s_mid = P["s_mid"]
    alpha_final = P["alpha_final"]
    s_pivot = P["s_pivot"]
    if t <= P["t1_end"]:
        alpha = _alpha_at(P, t)
        pts_slope = [(s_mid - R, 0.0), (s_mid + R, 0.0),
                     (s_mid + R, H), (s_mid - R, H)]
        return [_slope_to_lab(s, n, alpha) for s, n in pts_slope]
    if t <= P["t2_end"]:
        phi = float(P["sol_topple"].sol(t - P["t1_end"])[0])
        phi = min(phi, np.pi / 2.0)
        cp, sp = np.cos(phi), np.sin(phi)
        locals_ = [(0.0, 0.0), (2 * R, 0.0), (2 * R, H), (0.0, H)]
        pts_slope = []
        for s_off, n_off in locals_:
            s_new = s_pivot + (s_off * cp - n_off * sp)
            n_new = (s_off * sp + n_off * cp)
            pts_slope.append((s_new, n_new))
        return [_slope_to_lab(s, n, alpha_final) for s, n in pts_slope]
    if t <= P["t4_end"]:
        dt = t - P["t2_end"]
        s_CoM = P["s_CoM_after"] + (-1.0) * (P["v_slide_0"] * dt + 0.5 * P["a_slope"] * dt * dt)
        pts_slope = [(s_CoM - H / 2.0, 0.0), (s_CoM + H / 2.0, 0.0),
                     (s_CoM + H / 2.0, 2 * R), (s_CoM - H / 2.0, 2 * R)]
        return [_slope_to_lab(s, n, alpha_final) for s, n in pts_slope]
    if t <= P["t_tip_end"]:
        dt = t - P["t4_end"]
        theta_b = alpha_final * (1.0 - dt / P["dt_tip"])
        x_lead = P["x_lead_at_tip_start"] + P["v_lead_h_signed"] * dt
        cb, sb = np.cos(theta_b), np.sin(theta_b)
        L_dir = np.array([cb, sb])
        N_dir = np.array([-sb, cb])
        leading = np.array([x_lead, 0.0])
        c0 = leading
        c1 = leading + H * L_dir
        c2 = leading + H * L_dir + 2 * R * N_dir
        c3 = leading + 2 * R * N_dir
        return [tuple(c0), tuple(c1), tuple(c2), tuple(c3)]
    if t <= P["t_rest"]:
        dt = t - P["t_tip_end"]
        x_CoM = P["x_CoM_at_tip_end"] + (-1.0) * (P["v_floor_0"] * dt - 0.5 * P["a_floor"] * dt * dt)
        return [(x_CoM - H / 2.0, 0.0), (x_CoM + H / 2.0, 0.0),
                (x_CoM + H / 2.0, 2 * R), (x_CoM - H / 2.0, 2 * R)]
    x_CoM = P["x_CoM_at_rest"]
    return [(x_CoM - H / 2.0, 0.0), (x_CoM + H / 2.0, 0.0),
            (x_CoM + H / 2.0, 2 * R), (x_CoM - H / 2.0, 2 * R)]


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: TiltingWedgeCylinderParams,
    output_path: str,
    fps: int = 30,
) -> None:
    P = _build_phases(params)
    L_slope = params.L_slope

    ts_grid = t
    all_x, all_y = [], []
    for t_ in ts_grid:
        for c in _cylinder_corners_at(P, t_):
            all_x.append(c[0]); all_y.append(c[1])
        for c in _wedge_corners(_alpha_at(P, t_), L_slope):
            all_x.append(c[0]); all_y.append(c[1])
    all_x = np.array(all_x); all_y = np.array(all_y)

    x_lo_d = all_x.min() - 0.5
    x_hi_d = all_x.max() + 0.5
    y_lo_d = -0.20
    y_hi_d = max(all_y.max(), 1.5) + 0.20

    fig_w, fig_h = 12.0, 5.5
    fig_aspect = fig_w / fig_h
    dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_d / dy_d < fig_aspect:
        extra = (fig_aspect * dy_d - dx_d) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx_d / fig_aspect - dy_d) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    ax.add_patch(Polygon([(x_lo, y_lo), (x_hi, y_lo), (x_hi, 0.0), (x_lo, 0.0)],
                         facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.plot([x_lo, x_hi], [0.0, 0.0], color="#adb5bd", lw=2.0, zorder=1)

    wedge_patch = Polygon([(0, 0)] * 3, facecolor="#bb6f49",
                          edgecolor="#adb5bd", lw=1.5, zorder=2)
    ax.add_patch(wedge_patch)
    cylinder_patch = Polygon([(0, 0)] * 4, facecolor="#8ecae6",
                             edgecolor="#ffffff", lw=1.5, zorder=4)
    ax.add_patch(cylinder_patch)

    def update(f):
        t_ = t[f]
        wedge_patch.set_xy(_wedge_corners(_alpha_at(P, t_), L_slope))
        cylinder_patch.set_xy(_cylinder_corners_at(P, t_))
        return wedge_patch, cylinder_patch

    n_frames = len(t)
    ani = animation.FuncAnimation(fig, update, frames=n_frames,
                                  interval=1000.0 / fps, blit=False)
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: TiltingWedgeCylinderParams, duration: float = 16.0) -> str:
    p = asdict(params)
    return f'''"""Tilting Wedge with Cylinder — auto-generated."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon

g = {p["g"]}
R = {p["R"]}
H = {p["H"]}
M = {p["M"]}
mu_s = {p["mu_s"]}
mu_k = {p["mu_k"]}
mu_floor = {p["mu_floor"]}
e_rest = {p["e"]}
alpha_0 = {p["alpha_0"]}
alpha_dot = {p["alpha_dot"]}
L_slope = {p["L_slope"]}
dt_tip = {p["dt_tip"]}
duration = {duration}
fps = 30

alpha_topple = float(np.arctan(2.0*R/H))
t_topple = (alpha_topple - alpha_0)/alpha_dot
I_centre = 0.25*M*R**2 + (1.0/12.0)*M*H**2
d_pivot = float(np.sqrt(R**2 + (H/2.0)**2))
I_pivot = I_centre + M*d_pivot**2
s_mid = 0.5 * L_slope
alpha_final = alpha_topple

def topple_ode(t, state):
    phi, om = state
    dom = M*g*((H/2.0)*np.sin(phi+alpha_final) - R*np.cos(phi+alpha_final))/I_pivot
    return [om, dom]

def topple_done(t, state):
    return state[0] - np.pi/2.0
topple_done.terminal = True; topple_done.direction = +1

phi_init = 1e-3
sol_topple = solve_ivp(topple_ode, (0.0, 10.0), [phi_init, 0.0],
                       events=topple_done, dense_output=True,
                       rtol=1e-9, atol=1e-11, max_step=0.01)
t_topple_dur = float(sol_topple.t_events[0][0])
phi_dot_at_end = float(sol_topple.y_events[0][0][1])

KE_pre = 0.5 * I_pivot * phi_dot_at_end ** 2
KE_post = (e_rest ** 2) * KE_pre
v_slide_0 = float(np.sqrt(2.0 * KE_post / M))

s_pivot = s_mid - R
s_CoM_after = s_pivot - H/2.0
s_CoM_at_foot = H/2.0
ds_phase4 = s_CoM_after - s_CoM_at_foot

a_slope = g * (np.sin(alpha_final) - mu_k * np.cos(alpha_final))
if a_slope <= 0: a_slope = 1e-6
v_at_foot = float(np.sqrt(max(v_slide_0**2 + 2.0*a_slope*ds_phase4, 0.0)))
t_phase4_dur = (v_at_foot - v_slide_0) / a_slope

v_lead_h_signed = -v_at_foot * np.cos(alpha_final)
v_floor_0 = abs(v_lead_h_signed)
a_floor = mu_floor * g
t_phase5_floor_dur = v_floor_0 / a_floor if a_floor > 0 else 0.0
dx_floor_mag = v_floor_0**2 / (2.0*a_floor) if a_floor > 0 else 0.0

x_lead_at_tip_start = 0.0
x_lead_at_tip_end = x_lead_at_tip_start + v_lead_h_signed * dt_tip
x_CoM_at_tip_end = x_lead_at_tip_end + H/2.0
x_CoM_at_rest = x_CoM_at_tip_end - dx_floor_mag

t1_end = t_topple
t2_end = t1_end + t_topple_dur
t4_end = t2_end + t_phase4_dur
t_tip_end = t4_end + dt_tip
t_rest = t_tip_end + t_phase5_floor_dur

def alpha_at(t):
    if t < t_topple:
        return alpha_0 + alpha_dot * t
    return alpha_final

def slope_basis(alpha):
    ca, sa = np.cos(alpha), np.sin(alpha)
    return np.array([ca, sa]), np.array([-sa, ca])

def slope_to_lab(s, n, alpha, origin=(0.0, 0.0)):
    e_s, e_n = slope_basis(alpha)
    return (origin[0] + s*e_s[0] + n*e_n[0], origin[1] + s*e_s[1] + n*e_n[1])

def wedge_corners(alpha):
    e_s, _ = slope_basis(alpha)
    V0 = np.array([0.0, 0.0])
    V1 = V0 + L_slope * e_s
    V2 = np.array([V1[0], 0.0])
    return [tuple(V0), tuple(V2), tuple(V1)]

def cylinder_corners_at(t):
    if t <= t1_end:
        alpha = alpha_at(t)
        pts = [(s_mid - R, 0.0),(s_mid + R, 0.0),(s_mid + R, H),(s_mid - R, H)]
        return [slope_to_lab(s, n, alpha) for s, n in pts]
    if t <= t2_end:
        phi = float(sol_topple.sol(t - t1_end)[0])
        phi = min(phi, np.pi/2.0)
        cp, sp = np.cos(phi), np.sin(phi)
        locals_ = [(0.0, 0.0),(2*R, 0.0),(2*R, H),(0.0, H)]
        pts = []
        for s_off, n_off in locals_:
            s_new = s_pivot + (s_off*cp - n_off*sp)
            n_new = (s_off*sp + n_off*cp)
            pts.append((s_new, n_new))
        return [slope_to_lab(s, n, alpha_final) for s, n in pts]
    if t <= t4_end:
        dt = t - t2_end
        s_CoM = s_CoM_after - (v_slide_0*dt + 0.5*a_slope*dt*dt)
        pts = [(s_CoM-H/2.0, 0.0),(s_CoM+H/2.0, 0.0),(s_CoM+H/2.0, 2*R),(s_CoM-H/2.0, 2*R)]
        return [slope_to_lab(s, n, alpha_final) for s, n in pts]
    if t <= t_tip_end:
        dt = t - t4_end
        theta_b = alpha_final * (1.0 - dt/dt_tip)
        x_lead = x_lead_at_tip_start + v_lead_h_signed * dt
        cb, sb = np.cos(theta_b), np.sin(theta_b)
        L_dir = np.array([cb, sb]); N_dir = np.array([-sb, cb])
        leading = np.array([x_lead, 0.0])
        c0 = leading; c1 = leading + H*L_dir
        c2 = leading + H*L_dir + 2*R*N_dir; c3 = leading + 2*R*N_dir
        return [tuple(c0), tuple(c1), tuple(c2), tuple(c3)]
    if t <= t_rest:
        dt = t - t_tip_end
        x_CoM = x_CoM_at_tip_end - (v_floor_0*dt - 0.5*a_floor*dt*dt)
        return [(x_CoM-H/2.0, 0.0),(x_CoM+H/2.0, 0.0),(x_CoM+H/2.0, 2*R),(x_CoM-H/2.0, 2*R)]
    x_CoM = x_CoM_at_rest
    return [(x_CoM-H/2.0, 0.0),(x_CoM+H/2.0, 0.0),(x_CoM+H/2.0, 2*R),(x_CoM-H/2.0, 2*R)]

ts_grid = np.linspace(0.0, duration, int(duration*fps)+1)
all_x, all_y = [], []
for t_ in ts_grid:
    for c in cylinder_corners_at(t_):
        all_x.append(c[0]); all_y.append(c[1])
    for c in wedge_corners(alpha_at(t_)):
        all_x.append(c[0]); all_y.append(c[1])
all_x = np.array(all_x); all_y = np.array(all_y)

x_lo_d = all_x.min() - 0.5
x_hi_d = all_x.max() + 0.5
y_lo_d = -0.20
y_hi_d = max(all_y.max(), 1.5) + 0.20
fig_w, fig_h = 12.0, 5.5
fig_aspect = fig_w/fig_h
dx_d, dy_d = x_hi_d-x_lo_d, y_hi_d-y_lo_d
if dx_d/dy_d < fig_aspect:
    extra = (fig_aspect*dy_d - dx_d)/2.0
    x_lo, x_hi = x_lo_d-extra, x_hi_d+extra
    y_lo, y_hi = y_lo_d, y_hi_d
else:
    extra = (dx_d/fig_aspect - dy_d)/2.0
    x_lo, x_hi = x_lo_d, x_hi_d
    y_lo, y_hi = y_lo_d-extra, y_hi_d+extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(Polygon([(x_lo, y_lo),(x_hi, y_lo),(x_hi, 0.0),(x_lo, 0.0)],
    facecolor="#4a4e69", edgecolor="none", zorder=0))
ax.plot([x_lo, x_hi], [0.0, 0.0], color="#adb5bd", lw=2.0, zorder=1)

wedge_patch = Polygon([(0,0)]*3, facecolor="#bb6f49", edgecolor="#adb5bd", lw=1.5, zorder=2)
ax.add_patch(wedge_patch)
cylinder_patch = Polygon([(0,0)]*4, facecolor="#8ecae6", edgecolor="#ffffff", lw=1.5, zorder=4)
ax.add_patch(cylinder_patch)

def update(f):
    t = f / fps
    wedge_patch.set_xy(wedge_corners(alpha_at(t)))
    cylinder_patch.set_xy(cylinder_corners_at(t))
    return wedge_patch, cylinder_patch

n_frames = int(duration*fps)+1
ani = animation.FuncAnimation(fig, update, frames=n_frames, interval=1000.0/fps, blit=False)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Tilting Wedge Cylinder")
    parser.add_argument("--g", type=float, default=9.8)
    parser.add_argument("--R", type=float, default=0.10)
    parser.add_argument("--H", type=float, default=0.40)
    parser.add_argument("--M", type=float, default=1.0)
    parser.add_argument("--mu_s", type=float, default=0.7)
    parser.add_argument("--mu_k", type=float, default=0.4)
    parser.add_argument("--mu_floor", type=float, default=0.3)
    parser.add_argument("--e", type=float, default=0.5)
    parser.add_argument("--alpha_0", type=float, default=0.0)
    parser.add_argument("--alpha_dot", type=float, default=0.05)
    parser.add_argument("--L_slope", type=float, default=1.50)
    parser.add_argument("--dt_tip", type=float, default=0.40)
    parser.add_argument("--duration", type=float, default=16.0)
    parser.add_argument("--output", type=str, default="tilting_wedge_cylinder.mp4")
    args = parser.parse_args()
    p = TiltingWedgeCylinderParams(
        g=args.g, R=args.R, H=args.H, M=args.M, mu_s=args.mu_s, mu_k=args.mu_k,
        mu_floor=args.mu_floor, e=args.e, alpha_0=args.alpha_0, alpha_dot=args.alpha_dot,
        L_slope=args.L_slope, dt_tip=args.dt_tip,
    )
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
