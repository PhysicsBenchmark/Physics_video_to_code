"""
Hammer Projectile Bounce — uniform thin rod + heavy point head, bouncing
with Newton restitution + Coulomb friction at endpoint contacts with the
floor. Free flight + impulsive impacts at tail or head.
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Circle
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class HammerProjectileBounceParams:
    m_rod: float = 0.30
    m_head: float = 1.50
    L_rod: float = 0.40
    g: float = 9.8
    e_rest: float = 0.45
    mu: float = 0.20
    Xc0: float = 0.0
    Yc0: float = 1.5
    theta0: float = 0.40
    Vx0: float = 4.5
    Vy0: float = 6.5
    omega0: float = 5.0


def _integrate(p: HammerProjectileBounceParams, duration: float, fps: int):
    M = p.m_rod + p.m_head
    x_com = (p.m_rod * p.L_rod / 2.0 + p.m_head * p.L_rod) / M
    d_tail = x_com; d_head = p.L_rod - x_com
    I_com = (p.m_rod * p.L_rod**2 / 12.0
             + p.m_rod * (p.L_rod / 2.0 - x_com)**2
             + p.m_head * (p.L_rod - x_com)**2)
    g, e_rest, mu = p.g, p.e_rest, p.mu

    def free_flight(t, y):
        return [y[3], y[4], y[5], 0.0, -g, 0.0]

    def ev_tail(t, y):
        return y[1] - x_com * np.sin(y[2])
    ev_tail.terminal = True; ev_tail.direction = -1

    def ev_head(t, y):
        return y[1] + (p.L_rod - x_com) * np.sin(y[2])
    ev_head.terminal = True; ev_head.direction = -1

    def contact_step(state):
        s = state.copy()
        for _ in range(8):
            any_imp = False
            for sgn, dist in ((-1.0, d_tail), (+1.0, d_head)):
                xc, yc, th, vx, vy, om = s
                rx = sgn * dist * np.cos(th); ry = sgn * dist * np.sin(th)
                ey = yc + ry
                vp_y = vy + rx * om
                if ey > 1e-9 or vp_y > -1e-12:
                    continue
                vp_x = vx - ry * om
                Jn = -(1.0 + e_rest) * vp_y / (1.0 / M + rx * rx / I_com)
                Jt_s = -vp_x / (1.0 / M + ry * ry / I_com)
                mt = mu * Jn
                Jt = max(-mt, min(mt, Jt_s))
                s[3] = vx + Jt / M
                s[4] = vy + Jn / M
                s[5] = om + (rx * Jn - ry * Jt) / I_com
                any_imp = True
            if not any_imp:
                break
        th_f = s[2]
        tail_y = s[1] - x_com * np.sin(th_f)
        head_y = s[1] + (p.L_rod - x_com) * np.sin(th_f)
        lower_y = min(tail_y, head_y)
        if lower_y < 0.0:
            s[1] -= lower_y
        return s

    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    xc_arr = np.zeros_like(t_eval); yc_arr = np.zeros_like(t_eval)
    th_arr = np.zeros_like(t_eval)
    state = np.array([p.Xc0, p.Yc0, p.theta0, p.Vx0, p.Vy0, p.omega0], dtype=float)
    xc_arr[0], yc_arr[0], th_arr[0] = state[0], state[1], state[2]
    last_idx = 1; t_cur = 0.0
    settled = False; short_seg_count = 0

    for _seg in range(2000):
        if t_cur >= duration - 1e-9: break
        sol = solve_ivp(free_flight, (t_cur, duration), state,
                        events=[ev_tail, ev_head], dense_output=True,
                        max_step=0.02, rtol=1e-9, atol=1e-11)
        seg_end = sol.t[-1]
        while last_idx < len(t_eval) and t_eval[last_idx] <= seg_end + 1e-12:
            st = sol.sol(t_eval[last_idx])
            xc_arr[last_idx], yc_arr[last_idx], th_arr[last_idx] = st[0], st[1], st[2]
            last_idx += 1
        state = sol.y[:, -1].copy()
        seg_dt = seg_end - t_cur; t_cur = seg_end
        if sol.status != 1: break
        state = contact_step(state)
        KE = 0.5 * M * (state[3]**2 + state[4]**2) + 0.5 * I_com * state[5]**2
        tail_y = state[1] - x_com * np.sin(state[2])
        head_y = state[1] + (p.L_rod - x_com) * np.sin(state[2])
        lower_y = min(tail_y, head_y)
        if seg_dt < 1e-3:
            short_seg_count += 1
        else:
            short_seg_count = 0
        if KE < 0.05 and lower_y < 0.05:
            th_rest = round(state[2] / np.pi) * np.pi
            state = np.array([state[0], 0.0, th_rest, 0.0, 0.0, 0.0])
            settled = True; break
        if short_seg_count > 25 and lower_y < 0.05:
            th_rest = round(state[2] / np.pi) * np.pi
            state = np.array([state[0], 0.0, th_rest, 0.0, 0.0, 0.0])
            settled = True; break

    if last_idx < len(t_eval):
        xc_arr[last_idx:] = state[0]
        yc_arr[last_idx:] = state[1]
        th_arr[last_idx:] = state[2]

    return t_eval, np.vstack([xc_arr, yc_arr, th_arr])


def simulate(params: HammerProjectileBounceParams, duration: float = 12.0, fps: int = 30):
    return _integrate(params, duration, fps)


def render_video(t, y, params: HammerProjectileBounceParams, output_path: str, fps: int = 30):
    p = params
    M = p.m_rod + p.m_head
    x_com = (p.m_rod * p.L_rod / 2.0 + p.m_head * p.L_rod) / M
    xc_arr, yc_arr, th_arr = y[0], y[1], y[2]
    xs_tail = xc_arr - x_com * np.cos(th_arr)
    ys_tail = yc_arr - x_com * np.sin(th_arr)
    xs_head = xc_arr + (p.L_rod - x_com) * np.cos(th_arr)
    ys_head = yc_arr + (p.L_rod - x_com) * np.sin(th_arr)

    fig_w, fig_h = 9, 5
    fig_aspect = fig_w / fig_h
    xpad, ypad = 0.30, 0.30
    y_lo = -0.30
    x_lo_d = min(xs_tail.min(), xs_head.min()) - xpad
    x_hi_d = max(xs_tail.max(), xs_head.max()) + xpad
    y_hi_d = max(ys_tail.max(), ys_head.max(), yc_arr.max()) + ypad
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi, y_hi = x_lo_d - extra, x_hi_d + extra, y_hi_d
    else:
        extra = dx / fig_aspect - dy
        x_lo, x_hi, y_hi = x_lo_d, x_hi_d, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1]); ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")
    ax.axhspan(y_lo, 0.0, color="#4a4e69", alpha=0.55, zorder=0)
    ax.axhline(0, color="#adb5bd", lw=2, zorder=1)
    rod_ln, = ax.plot([], [], "-", color="#a8dadc", lw=4,
                      solid_capstyle="round", zorder=3)
    head_patch = Circle((xs_head[0], ys_head[0]), 0.05,
                        facecolor="#e63946", edgecolor="white",
                        lw=1.5, zorder=4)
    ax.add_patch(head_patch)

    def update(f):
        rod_ln.set_data([xs_tail[f], xs_head[f]], [ys_tail[f], ys_head[f]])
        head_patch.center = (xs_head[f], ys_head[f])
        return rod_ln, head_patch

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000 / fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: HammerProjectileBounceParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Hammer projectile bounce standalone script."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Circle

m_rod = {p["m_rod"]}
m_head = {p["m_head"]}
L_rod = {p["L_rod"]}
g = {p["g"]}
e_rest = {p["e_rest"]}
mu = {p["mu"]}
Xc0 = {p["Xc0"]}
Yc0 = {p["Yc0"]}
theta0 = {p["theta0"]}
Vx0 = {p["Vx0"]}
Vy0 = {p["Vy0"]}
omega0 = {p["omega0"]}
duration = {duration}
fps = 30

M = m_rod + m_head
x_com = (m_rod*L_rod/2.0 + m_head*L_rod)/M
d_tail = x_com; d_head = L_rod - x_com
I_com = (m_rod*L_rod**2/12.0
         + m_rod*(L_rod/2.0 - x_com)**2
         + m_head*(L_rod - x_com)**2)

def free_flight(t, y): return [y[3], y[4], y[5], 0.0, -g, 0.0]
def ev_tail(t, y): return y[1] - x_com*np.sin(y[2])
ev_tail.terminal = True; ev_tail.direction = -1
def ev_head(t, y): return y[1] + (L_rod - x_com)*np.sin(y[2])
ev_head.terminal = True; ev_head.direction = -1

def contact_step(state):
    s = state.copy()
    for _ in range(8):
        any_imp = False
        for sgn, dist in ((-1.0, d_tail), (+1.0, d_head)):
            xc, yc, th, vx, vy, om = s
            rx = sgn*dist*np.cos(th); ry = sgn*dist*np.sin(th)
            ey = yc + ry
            vp_y = vy + rx*om
            if ey > 1e-9 or vp_y > -1e-12: continue
            vp_x = vx - ry*om
            Jn = -(1.0+e_rest)*vp_y / (1.0/M + rx*rx/I_com)
            Jt_s = -vp_x / (1.0/M + ry*ry/I_com)
            mt = mu*Jn
            Jt = max(-mt, min(mt, Jt_s))
            s[3] = vx + Jt/M
            s[4] = vy + Jn/M
            s[5] = om + (rx*Jn - ry*Jt)/I_com
            any_imp = True
        if not any_imp: break
    th_f = s[2]
    tail_y = s[1] - x_com*np.sin(th_f)
    head_y = s[1] + (L_rod - x_com)*np.sin(th_f)
    lower_y = min(tail_y, head_y)
    if lower_y < 0.0: s[1] -= lower_y
    return s

t_eval = np.linspace(0, duration, int(duration*fps)+1)
xc_arr = np.zeros_like(t_eval); yc_arr = np.zeros_like(t_eval); th_arr = np.zeros_like(t_eval)
state = np.array([Xc0, Yc0, theta0, Vx0, Vy0, omega0], dtype=float)
xc_arr[0], yc_arr[0], th_arr[0] = state[0], state[1], state[2]
last_idx = 1; t_cur = 0.0
settled = False; short_seg_count = 0

for _seg in range(2000):
    if t_cur >= duration - 1e-9: break
    sol = solve_ivp(free_flight, (t_cur, duration), state,
                    events=[ev_tail, ev_head], dense_output=True,
                    max_step=0.02, rtol=1e-9, atol=1e-11)
    seg_end = sol.t[-1]
    while last_idx < len(t_eval) and t_eval[last_idx] <= seg_end + 1e-12:
        st = sol.sol(t_eval[last_idx])
        xc_arr[last_idx], yc_arr[last_idx], th_arr[last_idx] = st[0], st[1], st[2]
        last_idx += 1
    state = sol.y[:, -1].copy()
    seg_dt = seg_end - t_cur; t_cur = seg_end
    if sol.status != 1: break
    state = contact_step(state)
    KE = 0.5*M*(state[3]**2 + state[4]**2) + 0.5*I_com*state[5]**2
    tail_y = state[1] - x_com*np.sin(state[2])
    head_y = state[1] + (L_rod - x_com)*np.sin(state[2])
    lower_y = min(tail_y, head_y)
    if seg_dt < 1e-3: short_seg_count += 1
    else: short_seg_count = 0
    if KE < 0.05 and lower_y < 0.05:
        th_rest = round(state[2]/np.pi)*np.pi
        state = np.array([state[0], 0.0, th_rest, 0.0, 0.0, 0.0])
        settled = True; break
    if short_seg_count > 25 and lower_y < 0.05:
        th_rest = round(state[2]/np.pi)*np.pi
        state = np.array([state[0], 0.0, th_rest, 0.0, 0.0, 0.0])
        settled = True; break

if last_idx < len(t_eval):
    xc_arr[last_idx:] = state[0]
    yc_arr[last_idx:] = state[1]
    th_arr[last_idx:] = state[2]

xs_tail = xc_arr - x_com*np.cos(th_arr)
ys_tail = yc_arr - x_com*np.sin(th_arr)
xs_head = xc_arr + (L_rod - x_com)*np.cos(th_arr)
ys_head = yc_arr + (L_rod - x_com)*np.sin(th_arr)

fig_w, fig_h = 9, 5
fig_aspect = fig_w/fig_h
xpad, ypad = 0.30, 0.30
y_lo = -0.30
x_lo_d = min(xs_tail.min(), xs_head.min()) - xpad
x_hi_d = max(xs_tail.max(), xs_head.max()) + xpad
y_hi_d = max(ys_tail.max(), ys_head.max(), yc_arr.max()) + ypad
dx, dy = x_hi_d-x_lo_d, y_hi_d-y_lo
if dx/dy < fig_aspect:
    extra = (fig_aspect*dy - dx)/2.0
    x_lo, x_hi, y_hi = x_lo_d-extra, x_hi_d+extra, y_hi_d
else:
    extra = dx/fig_aspect - dy
    x_lo, x_hi, y_hi = x_lo_d, x_hi_d, y_hi_d+extra

fig = plt.figure(figsize=(fig_w,fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.axhspan(y_lo, 0.0, color="#4a4e69", alpha=0.55, zorder=0)
ax.axhline(0, color="#adb5bd", lw=2, zorder=1)
rod_ln, = ax.plot([],[],"-", color="#a8dadc", lw=4, solid_capstyle="round", zorder=3)
head_patch = Circle((xs_head[0], ys_head[0]), 0.05, facecolor="#e63946",
                    edgecolor="white", lw=1.5, zorder=4)
ax.add_patch(head_patch)

def update(f):
    rod_ln.set_data([xs_tail[f], xs_head[f]],[ys_tail[f], ys_head[f]])
    head_patch.center = (xs_head[f], ys_head[f])
    return rod_ln, head_patch

ani = animation.FuncAnimation(fig, update, frames=len(t_eval),
                              interval=1000/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    for fld, dflt in [("m_rod",0.30),("m_head",1.50),("L_rod",0.40),
                       ("g",9.8),("e_rest",0.45),("mu",0.20),
                       ("Xc0",0.0),("Yc0",1.5),("theta0",0.40),
                       ("Vx0",4.5),("Vy0",6.5),("omega0",5.0)]:
        parser.add_argument(f"--{fld}", type=float, default=dflt)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="hammer_projectile_bounce.mp4")
    args = parser.parse_args()
    p = HammerProjectileBounceParams(
        m_rod=args.m_rod, m_head=args.m_head, L_rod=args.L_rod, g=args.g,
        e_rest=args.e_rest, mu=args.mu, Xc0=args.Xc0, Yc0=args.Yc0,
        theta0=args.theta0, Vx0=args.Vx0, Vy0=args.Vy0, omega0=args.omega0)
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
