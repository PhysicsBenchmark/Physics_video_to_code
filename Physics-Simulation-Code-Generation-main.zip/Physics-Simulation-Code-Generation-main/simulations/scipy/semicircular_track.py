"""
Semicircular Track — solid sphere rolling without slipping in a half-circular bowl.

Physics: Lagrangian for a rolling sphere with the rolling constraint r·phi_dot = (R-r)·theta_dot
gives effective ODE
    (7/5) m (R-r)^2 theta_ddot + m g (R-r) sin(theta) = 0
    theta_ddot = -(5g)/(7(R-r)) sin(theta) - gamma*theta_dot     (with viscous damping)

State vector: [theta, omega] where omega = theta_dot.
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis


@dataclass
class SemicircularTrackParams:
    g: float = 9.8
    m: float = 0.6
    R: float = 1.20
    r: float = 0.08
    gamma: float = 0.06
    theta0: float = 1.0
    omega0: float = 0.0


def ode(t: float, y: list, p: SemicircularTrackParams):
    th, om = y
    k = 5.0 * p.g / (7.0 * (p.R - p.r))
    return [om, -k * np.sin(th) - p.gamma * om]


def simulate(
    params: SemicircularTrackParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode,
        (0.0, duration),
        [params.theta0, params.omega0],
        t_eval=t_eval,
        args=(params,),
        method="RK45",
        rtol=1e-9,
        atol=1e-11,
    )
    return sol.t, sol.y


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: SemicircularTrackParams,
    output_path: str,
    fps: int = 30,
) -> None:
    theta = y[0]
    R, r = params.R, params.r
    xc = (R - r) * np.sin(theta)
    yc = R - (R - r) * np.cos(theta)

    x_lo_d = -(R - r) - 0.30
    x_hi_d = +(R - r) + 0.30
    y_lo_d = -0.20
    y_hi_d = R + 0.30
    fig_w, fig_h = 6.0, 5.0
    fig_aspect = fig_w / fig_h
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo_d -= extra; x_hi_d += extra
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        y_lo_d -= extra; y_hi_d += extra

    fig, ax = plt.subplots(figsize=(fig_w, fig_h))
    setup_dark_axis(fig, ax, (x_lo_d, x_hi_d), (y_lo_d, y_hi_d))

    arc_phi = np.linspace(np.pi, 2.0 * np.pi, 240)
    bowl_x = R * np.cos(arc_phi)
    bowl_y = R + R * np.sin(arc_phi)
    ax.plot(bowl_x, bowl_y, color="#adb5bd", lw=4.0, solid_capstyle="round", zorder=2)
    ax.plot([x_lo_d, x_hi_d], [0.0, 0.0], color="#6c757d", lw=1.0, alpha=0.7, zorder=1)

    sphere = patches.Circle((xc[0], yc[0]), r,
                            facecolor="#e63946", edgecolor="white",
                            lw=1.2, zorder=4)
    ax.add_patch(sphere)
    trail_len = 30
    trail_line, = ax.plot([], [], color="#e63946", lw=1.2, alpha=0.30, zorder=3)

    def update(f):
        sphere.set_center((xc[f], yc[f]))
        lo = max(0, f - trail_len)
        trail_line.set_data(xc[lo:f + 1], yc[lo:f + 1])
        return sphere, trail_line

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), interval=1000 / fps, blit=True
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(
    params: SemicircularTrackParams,
    duration: float = 12.0,
) -> str:
    p = asdict(params)
    return f'''"""Semicircular track — auto-generated."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

g      = {p["g"]}
m      = {p["m"]}
R      = {p["R"]}
r      = {p["r"]}
gamma  = {p["gamma"]}
theta0 = {p["theta0"]:.6f}
omega0 = {p["omega0"]:.6f}
duration = {duration}
fps = 30

def ode(t, y):
    th, om = y
    k = 5.0*g/(7.0*(R-r))
    return [om, -k*np.sin(th) - gamma*om]

t_eval = np.linspace(0.0, duration, int(duration*fps)+1)
sol = solve_ivp(ode, (0.0, duration), [theta0, omega0], t_eval=t_eval,
                method="RK45", rtol=1e-9, atol=1e-11)
theta = sol.y[0]
xc = (R-r)*np.sin(theta)
yc = R - (R-r)*np.cos(theta)

x_lo, x_hi = -(R-r)-0.30, +(R-r)+0.30
y_lo, y_hi = -0.20, R+0.30
fig_w, fig_h = 6.0, 5.0
fa = fig_w/fig_h
dx, dy = x_hi-x_lo, y_hi-y_lo
if dx/dy < fa:
    e = (fa*dy-dx)/2.0; x_lo -= e; x_hi += e
else:
    e = (dx/fa-dy)/2.0; y_lo -= e; y_hi += e

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1])
ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")

arc_phi = np.linspace(np.pi, 2.0*np.pi, 240)
ax.plot(R*np.cos(arc_phi), R + R*np.sin(arc_phi), color="#adb5bd", lw=4.0,
        solid_capstyle="round", zorder=2)
ax.plot([x_lo, x_hi], [0.0, 0.0], color="#6c757d", lw=1.0, alpha=0.7, zorder=1)
sphere = patches.Circle((xc[0], yc[0]), r, facecolor="#e63946",
                        edgecolor="white", lw=1.2, zorder=4)
ax.add_patch(sphere)
trail_line, = ax.plot([], [], color="#e63946", lw=1.2, alpha=0.30, zorder=3)
trail_len = 30

def update(f):
    sphere.set_center((xc[f], yc[f]))
    lo = max(0, f-trail_len)
    trail_line.set_data(xc[lo:f+1], yc[lo:f+1])
    return sphere, trail_line

ani = animation.FuncAnimation(fig, update, frames=len(sol.t),
                              interval=1000/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Semicircular Track Simulation")
    parser.add_argument("--g", type=float, default=9.8)
    parser.add_argument("--m", type=float, default=0.6)
    parser.add_argument("--R", type=float, default=1.20)
    parser.add_argument("--r", type=float, default=0.08)
    parser.add_argument("--gamma", type=float, default=0.06)
    parser.add_argument("--theta0", type=float, default=1.0)
    parser.add_argument("--omega0", type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="semicircular_track.mp4")
    args = parser.parse_args()

    p = SemicircularTrackParams(
        g=args.g, m=args.m, R=args.R, r=args.r, gamma=args.gamma,
        theta0=args.theta0, omega0=args.omega0,
    )
    print(f"Simulating semicircular track: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
