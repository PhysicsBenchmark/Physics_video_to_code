"""
Spring-Mass Driven String + Fixed End — wave equation simulation.

Spring-mass SHM at angular frequency omega_s = sqrt(k/m); the mass's vertical
motion drives the LEFT end of a horizontal string (length L) of linear density
mu under tension T_str. Wave speed c = sqrt(T_str/mu). Right end is fixed.
Wave equation: u_tt = c^2 u_xx - 2 gamma_w u_t. Driven Dirichlet:
u(0,t) = ramp(t) * y_mass(t); u(L,t) = 0. Explicit leapfrog FDM.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Circle, Rectangle
from dataclasses import dataclass, asdict


@dataclass
class SpringMassStringFixedParams:
    g: float = 9.81
    m_mass: float = 0.30
    k_spring: float = 30.0
    L: float = 4.0
    mu: float = 0.10
    T_str: float = 4.0
    gamma_w: float = 1.0
    tau_ramp: float = 0.40
    H_mass: float = 0.20
    W_mass: float = 0.20
    L_spring_rest: float = 0.50


def simulate(
    params: SpringMassStringFixedParams,
    duration: float = 8.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Returns (t_eval, U) where U.shape = (N+1, n_frames) — string profile per frame.

    Note: U includes the string snapshot u(x, t_frame). Mass position y_mass is
    available via the params (analytic SHM), so we don't need to pack it into y;
    we expose it via a helper, but it is reconstructable in render_video.
    """
    g = params.g; m = params.m_mass; k = params.k_spring
    L = params.L; mu = params.mu; T_str = params.T_str
    gamma_w = params.gamma_w; tau_ramp = params.tau_ramp
    DeltaL_eq = m * g / k
    omega_spring = np.sqrt(k / m)
    c = np.sqrt(T_str / mu)

    N = 200
    dx = L / N
    n_per_frame = 16
    dt = 1.0 / (fps * n_per_frame)
    factor = (c * dt / dx) ** 2
    damp_n = 1.0 / (1.0 + gamma_w * dt)
    damp_p = 1.0 - gamma_w * dt

    n_frames = int(duration * fps) + 1
    t_eval = np.linspace(0.0, duration, n_frames)
    U = np.zeros((N + 1, n_frames))

    u_curr = np.zeros(N + 1)
    u_prev = u_curr.copy()
    U[:, 0] = u_curr

    def y_mass_at(t):
        return DeltaL_eq * np.cos(omega_spring * t)

    for frame in range(1, n_frames):
        for sub in range(n_per_frame):
            t_curr = (frame - 1) / fps + (sub + 1) * dt
            u_next = np.empty_like(u_curr)
            lap_int = u_curr[2:] - 2 * u_curr[1:-1] + u_curr[:-2]
            u_next[1:-1] = damp_n * (
                2 * u_curr[1:-1] - damp_p * u_prev[1:-1] + factor * lap_int
            )
            u_next[-1] = 0.0
            u_next[0] = (1.0 - np.exp(-t_curr / tau_ramp)) * y_mass_at(t_curr)
            u_prev, u_curr = u_curr, u_next
        U[:, frame] = u_curr

    return t_eval, U


def render_video(
    t: np.ndarray,
    U: np.ndarray,
    params: SpringMassStringFixedParams,
    output_path: str,
    fps: int = 30,
) -> None:
    g, m, k = params.g, params.m_mass, params.k_spring
    DeltaL_eq = m * g / k
    omega_spring = np.sqrt(k / m)

    L = params.L
    H_mass = params.H_mass; W_mass = params.W_mass
    L_spring_rest = params.L_spring_rest
    y_string_eq = 0.0
    y_mass_eq = 0.0
    y_ceiling = L_spring_rest + DeltaL_eq + H_mass / 2 + y_mass_eq
    x_mass_c = -W_mass / 2
    spring_x = x_mass_c

    N_grid_pts = U.shape[0]
    x_grid = np.linspace(0.0, L, N_grid_pts)

    fig_w, fig_h = 12.0, 4.5
    fig_aspect = fig_w / fig_h
    x_lo_d = x_mass_c - W_mass / 2 - 0.20
    x_hi_d = L + 0.40
    y_lo_d = -4.5 * DeltaL_eq - 0.10
    y_hi_d = y_ceiling + 0.10
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    ax.add_patch(Rectangle((x_lo, y_ceiling), x_hi - x_lo, y_hi - y_ceiling,
                           facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.plot([x_lo, x_hi], [y_ceiling, y_ceiling],
            color="#adb5bd", lw=2.0, zorder=1)

    spring_line, = ax.plot([], [], color="#a8dadc", lw=2.0, zorder=3)
    mass_patch = Rectangle((x_mass_c - W_mass / 2, DeltaL_eq - H_mass / 2),
                           W_mass, H_mass,
                           facecolor="#e63946", edgecolor="#adb5bd", lw=1.0, zorder=4)
    ax.add_patch(mass_patch)

    ax.add_patch(Rectangle((L, y_lo), 0.12, y_hi - y_lo,
                           facecolor="#4a4e69", edgecolor="#adb5bd", lw=1.5, zorder=2))
    ax.plot([L, L], [y_lo, y_hi], color="#adb5bd", lw=2.0, zorder=3)
    ax.add_patch(Circle((L, 0), 0.05, facecolor="#e63946",
                        edgecolor="#adb5bd", lw=1.0, zorder=5))

    str_line, = ax.plot([], [], color="#a8dadc", lw=2.4, zorder=4)

    def coil_xy(p_top, p_bot, n_coils=10, w=0.04, n_pts=80):
        x1, y1 = p_top; x2, y2 = p_bot
        dxv, dyv = x2 - x1, y2 - y1
        Lc = np.hypot(dxv, dyv)
        if Lc < 1e-9:
            return np.array([x1, x2]), np.array([y1, y2])
        ux, uy = dxv / Lc, dyv / Lc
        nx, ny = -uy, ux
        s = np.linspace(0.0, 1.0, n_pts)
        lead = 0.06
        arc = s * Lc
        middle = (arc >= lead) & (arc <= Lc - lead)
        amp = np.where(middle,
                       w * np.sin(2 * np.pi * n_coils * (arc - lead) / max(Lc - 2 * lead, 1e-6)),
                       0.0)
        xs = x1 + ux * arc + nx * amp
        ys = y1 + uy * arc + ny * amp
        return xs, ys

    def y_mass_at(t):
        return DeltaL_eq * np.cos(omega_spring * t)

    def update(f):
        tval = t[f]
        y_m = y_mass_at(tval)
        mass_patch.set_xy((x_mass_c - W_mass / 2, y_m - H_mass / 2))
        xs_s, ys_s = coil_xy((spring_x, y_ceiling), (spring_x, y_m + H_mass / 2))
        spring_line.set_data(xs_s, ys_s)
        u = U[:, f]
        str_line.set_data(x_grid, u)
        return mass_patch, spring_line, str_line

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0 / fps, blit=True)
    ani.save(output_path,
             writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(
    params: SpringMassStringFixedParams,
    duration: float = 8.0,
) -> str:
    p = asdict(params)
    return f'''"""Spring-mass driven string + fixed end — auto-generated."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Circle, Rectangle

g            = {p["g"]}
m_mass       = {p["m_mass"]}
k_spring     = {p["k_spring"]}
L            = {p["L"]}
mu           = {p["mu"]}
T_str        = {p["T_str"]}
gamma_w      = {p["gamma_w"]}
tau_ramp     = {p["tau_ramp"]}
H_mass       = {p["H_mass"]}
W_mass       = {p["W_mass"]}
L_spring_rest= {p["L_spring_rest"]}
duration     = {duration}
fps          = 30

DeltaL_eq    = m_mass * g / k_spring
omega_spring = np.sqrt(k_spring / m_mass)
c            = np.sqrt(T_str / mu)
y_string_eq  = 0.0; y_mass_eq = 0.0
y_ceiling    = L_spring_rest + DeltaL_eq + H_mass/2 + y_mass_eq
x_mass_c     = -W_mass/2
spring_x     = x_mass_c

def y_mass_at(t):
    return DeltaL_eq * np.cos(omega_spring*t)
def ramp(t):
    return 1.0 - np.exp(-t/tau_ramp)

N            = 200
dx           = L/N
x_grid       = np.linspace(0.0, L, N+1)
n_per_frame  = 16
dt           = 1.0/(fps*n_per_frame)
factor       = (c*dt/dx)**2
damp_n       = 1.0/(1.0 + gamma_w*dt)
damp_p       = 1.0 - gamma_w*dt

u_curr       = np.zeros(N+1)
u_prev       = u_curr.copy()
n_frames     = int(duration*fps)+1
U_frames     = np.zeros((n_frames, N+1))
U_frames[0]  = u_curr.copy()
for frame in range(1, n_frames):
    for sub in range(n_per_frame):
        t_curr = (frame-1)/fps + (sub+1)*dt
        u_next = np.empty_like(u_curr)
        lap_int = u_curr[2:] - 2*u_curr[1:-1] + u_curr[:-2]
        u_next[1:-1] = damp_n*(2*u_curr[1:-1] - damp_p*u_prev[1:-1] + factor*lap_int)
        u_next[-1] = 0.0
        u_next[0] = ramp(t_curr) * (y_mass_at(t_curr) - y_string_eq)
        u_prev, u_curr = u_curr, u_next
    U_frames[frame] = u_curr.copy()

def coil_xy(p_top, p_bot, n_coils=10, w=0.04, n_pts=80):
    x1, y1 = p_top; x2, y2 = p_bot
    dxv, dyv = x2-x1, y2-y1
    Lc = np.hypot(dxv, dyv)
    if Lc < 1e-9: return np.array([x1,x2]), np.array([y1,y2])
    ux, uy = dxv/Lc, dyv/Lc
    nx, ny = -uy, ux
    s = np.linspace(0.0, 1.0, n_pts)
    lead = 0.06
    arc = s*Lc
    middle = (arc >= lead) & (arc <= Lc-lead)
    amp = np.where(middle, w*np.sin(2*np.pi*n_coils*(arc-lead)/max(Lc-2*lead,1e-6)), 0.0)
    return x1+ux*arc+nx*amp, y1+uy*arc+ny*amp

fig_w, fig_h = 12.0, 4.5; fa = fig_w/fig_h
xlo_d = x_mass_c - W_mass/2 - 0.20
xhi_d = L + 0.40
ylo_d = -4.5*DeltaL_eq - 0.10
yhi_d = y_ceiling + 0.10
dx_d, dy_d = xhi_d-xlo_d, yhi_d-ylo_d
if dx_d/dy_d < fa:
    e = (fa*dy_d-dx_d)/2; xlo, xhi, ylo, yhi = xlo_d-e, xhi_d+e, ylo_d, yhi_d
else:
    e = (dx_d/fa-dy_d)/2; xlo, xhi, ylo, yhi = xlo_d, xhi_d, ylo_d-e, yhi_d+e

fig = plt.figure(figsize=(fig_w,fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1])
ax.set_facecolor("#16213e")
ax.set_xlim(xlo,xhi); ax.set_ylim(ylo,yhi)
ax.set_aspect("equal"); ax.axis("off")

ax.add_patch(Rectangle((xlo, y_ceiling), xhi-xlo, yhi-y_ceiling,
                       facecolor="#4a4e69", edgecolor="none", zorder=0))
ax.plot([xlo,xhi], [y_ceiling,y_ceiling], color="#adb5bd", lw=2.0, zorder=1)

spring_line, = ax.plot([], [], color="#a8dadc", lw=2.0, zorder=3)
mass_patch = Rectangle((x_mass_c - W_mass/2, y_mass_at(0.0) - H_mass/2),
                       W_mass, H_mass, facecolor="#e63946", edgecolor="#adb5bd", lw=1.0, zorder=4)
ax.add_patch(mass_patch)
ax.add_patch(Rectangle((L, ylo), 0.12, yhi-ylo,
                       facecolor="#4a4e69", edgecolor="#adb5bd", lw=1.5, zorder=2))
ax.plot([L,L], [ylo,yhi], color="#adb5bd", lw=2.0, zorder=3)
ax.add_patch(Circle((L,0), 0.05, facecolor="#e63946", edgecolor="#adb5bd", lw=1.0, zorder=5))
str_line, = ax.plot([],[], color="#a8dadc", lw=2.4, zorder=4)

def update(f):
    t = f/fps
    y_m = y_mass_at(t)
    mass_patch.set_xy((x_mass_c - W_mass/2, y_m - H_mass/2))
    xs_s, ys_s = coil_xy((spring_x, y_ceiling), (spring_x, y_m + H_mass/2))
    spring_line.set_data(xs_s, ys_s)
    str_line.set_data(x_grid, U_frames[f])
    return mass_patch, spring_line, str_line

ani = animation.FuncAnimation(fig, update, frames=n_frames, interval=1000/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Spring-Mass + String (Fixed End)")
    parser.add_argument("--g", type=float, default=9.81)
    parser.add_argument("--m_mass", type=float, default=0.30)
    parser.add_argument("--k_spring", type=float, default=30.0)
    parser.add_argument("--L", type=float, default=4.0)
    parser.add_argument("--mu", type=float, default=0.10)
    parser.add_argument("--T_str", type=float, default=4.0)
    parser.add_argument("--gamma_w", type=float, default=1.0)
    parser.add_argument("--tau_ramp", type=float, default=0.40)
    parser.add_argument("--H_mass", type=float, default=0.20)
    parser.add_argument("--W_mass", type=float, default=0.20)
    parser.add_argument("--L_spring_rest", type=float, default=0.50)
    parser.add_argument("--duration", type=float, default=8.0)
    parser.add_argument("--output", type=str, default="spring_mass_string_fixed.mp4")
    args = parser.parse_args()

    p = SpringMassStringFixedParams(
        g=args.g, m_mass=args.m_mass, k_spring=args.k_spring,
        L=args.L, mu=args.mu, T_str=args.T_str,
        gamma_w=args.gamma_w, tau_ramp=args.tau_ramp,
        H_mass=args.H_mass, W_mass=args.W_mass, L_spring_rest=args.L_spring_rest,
    )
    print(f"Simulating spring-mass driven string: {asdict(p)}")
    t, U = simulate(p, duration=args.duration)
    render_video(t, U, p, args.output)
    print(f"Saved {args.output}")
