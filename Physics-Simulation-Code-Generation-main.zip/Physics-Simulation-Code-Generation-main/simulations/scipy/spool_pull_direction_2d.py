"""
Spool Pull Direction (2D)
=========================
A spool of outer radius R and inner radius r rests on a horizontal floor.
A continuous tension T is applied through a thread wound around the inner
spindle; the thread emerges tangent at point P = (r sinθ, −r cosθ) (relative
to the spool centre) in direction (cosθ, sinθ).  The whole "pull" therefore
acts at that contact via the thread, instead of through an abstract arrow.

Physical insight (the classic "spool problem"):
  • Net torque about the *contact point* with the floor due to a tension T
    is τ_contact = T (r − R cosθ).
  • Critical angle:  cos θ_c = r / R   (zero torque about contact).
  • θ < θ_c → spool rolls toward the pull (in the +x direction here).
  • θ > θ_c → spool rolls away from the pull (in the −x direction).

Equations of motion (planar Newton-Euler, lab frame):
  • Tension force at P (direction (cosθ, sinθ)):   F_T = T (cosθ, sinθ).
        F_T_x contributes directly to the spool's CoM x-acceleration.
        F_T_y is absorbed by the normal contact force from the floor.
  • Tension torque about CoM: τ_T = (P × F_T)_z = T r  (always CCW).
  • Floor (kinetic) friction at the contact point opposes contact-point
    velocity v_c = v_x + ω R, regularised as
        F_f = −μ_k M g · tanh(α v_c).
  • Newton-Euler:
        M v̇_x = T cosθ + F_f
        I ω̇   = T r + R F_f,    I = I_factor · M R²

Initial conditions: spool starts at rest (v_x = 0, ω = 0).  Once T is
applied, the spool develops a contact slip, friction kicks in, and the
spool rolls accordingly.

State vector: [x, φ, v_x, ω].
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import math
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis


@dataclass
class SpoolPullDirection2DParams:
    M: float = 1.0           # spool mass (kg)
    R: float = 0.20          # outer flange radius (m)
    r_over_R: float = 0.50   # inner-to-outer-radius ratio
    I_factor: float = 0.55   # I_cm = I_factor · M · R²
    mu_k: float = 0.20       # kinetic floor friction
    g: float = 9.81          # gravity (m/s²)
    T: float = 0.6           # continuous thread tension (N)
    theta_deg: float = 30.0  # thread angle above horizontal (deg)
    alpha_tanh: float = 80.0
    x0: float = 0.0
    phi0: float = 0.0

    # Auto-derived:
    r: float = 0.0
    theta: float = 0.0

    def __post_init__(self):
        if self.r <= 0:
            self.r = self.r_over_R * self.R
        if self.theta == 0.0:
            self.theta = math.radians(self.theta_deg)
        # Keep |cos θ − r/R| bounded so the spool both (a) clearly moves and
        # (b) doesn't fly off the frame.  Steady-state acceleration is
        # T·(cosθ − r/R)/[M·(1+I_factor)], so we want |cosθ − r/R| ∈ [0.10, 0.35].
        cos_thc = self.r / self.R
        diff = math.cos(self.theta) - cos_thc
        sgn = 1.0 if diff >= 0 else -1.0
        if abs(diff) < 0.10 or abs(diff) > 0.22:
            target = sgn * (0.10 if abs(diff) < 0.10 else 0.22)
            new_cos = max(-0.95, min(0.95, cos_thc + target))
            self.theta = math.acos(new_cos)
            self.theta_deg = math.degrees(self.theta)


def ode(t: float, y: list, p: SpoolPullDirection2DParams):
    x, phi, vx, omega = y
    I = p.I_factor * p.M * p.R ** 2
    cos_th = math.cos(p.theta)
    v_contact = vx + omega * p.R
    F_f       = -p.mu_k * p.M * p.g * np.tanh(p.alpha_tanh * v_contact)
    F_T_x     = p.T * cos_th                                    # horizontal tension force
    tau_T     = p.T * p.r                                       # always CCW about CoM
    dvx       = (F_T_x + F_f) / p.M
    domega    = (p.R * F_f + tau_T) / I
    return [vx, omega, dvx, domega]


def simulate(
    params: SpoolPullDirection2DParams,
    duration: float = 12.0,
    fps: int = 30,
):
    y0     = [params.x0, params.phi0, 0.0, 0.0]
    t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode, (0.0, duration), y0,
        args=(params,), t_eval=t_eval,
        method="RK45", rtol=1e-9, atol=1e-11,
    )
    return sol.t, sol.y


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: SpoolPullDirection2DParams,
    output_path: str,
    fps: int = 30,
) -> None:
    x, phi = y[0], y[1]
    R, r, theta = params.R, params.r, params.theta
    cos_th, sin_th = math.cos(theta), math.sin(theta)

    L_thread = 1.6  # visible length of the free thread (m)

    pad_x = max(R * 1.5, 0.4)
    x_min = float(np.min(x)) - pad_x - 0.2
    x_max = float(np.max(x)) + pad_x + L_thread * cos_th + 0.5
    if x_max - x_min < 5.0:
        mid = 0.5 * (x_min + x_max)
        x_min, x_max = mid - 2.5, mid + 2.5
    y_top = max(2 * R + 0.5, R - r * cos_th + L_thread * sin_th + 0.4)

    fig, ax = plt.subplots(figsize=(11, 4.6))
    setup_dark_axis(fig, ax, xlim=(x_min, x_max), ylim=(-0.18, y_top))

    ax.axhline(0.0, color="#3a3a4f", lw=2.5, zorder=1)

    outer_disc = patches.Circle(
        (params.x0, R), R,
        facecolor="#457b9d", edgecolor="white", lw=1.5, zorder=3,
    )
    inner_disc = patches.Circle(
        (params.x0, R), r,
        facecolor="#1d3557", edgecolor="white", lw=1.0, zorder=4,
    )
    ax.add_patch(outer_disc)
    ax.add_patch(inner_disc)

    (spoke_line,) = ax.plot([], [], "-", color="#e63946", lw=2.5, zorder=5)
    (tip_dot,)    = ax.plot([], [], "o", color="#e63946", ms=8,    zorder=5)

    # Thread free segment: tangent point on the inner spindle in lab frame is
    # offset (r sinθ, −r cosθ) from the spool centre, extending in (cosθ, sinθ).
    (thread_line,) = ax.plot([], [], "-", color="#ffd166", lw=2.5, zorder=6)
    # Hand/grip at the far end of the thread
    grip = patches.Circle((0, 0), 0.05, facecolor="#ffd166",
                          edgecolor="white", lw=1.0, zorder=7)
    ax.add_patch(grip)

    def update(frame: int):
        cx = float(x[frame])
        ph = float(phi[frame])
        outer_disc.center = (cx, R)
        inner_disc.center = (cx, R)
        sx = cx + R * math.cos(ph)
        sy = R  + R * math.sin(ph)
        spoke_line.set_data([cx, sx], [R, sy])
        tip_dot.set_data([sx], [sy])
        tx0 = cx + r * sin_th
        ty0 = R  - r * cos_th
        tx1 = tx0 + L_thread * cos_th
        ty1 = ty0 + L_thread * sin_th
        thread_line.set_data([tx0, tx1], [ty0, ty1])
        grip.center = (tx1, ty1)
        return [outer_disc, inner_disc, spoke_line, tip_dot, thread_line, grip]

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), interval=1000 / fps, blit=False,
    )
    ani.save(output_path,
             writer=animation.FFMpegWriter(fps=fps, bitrate=1800),
             dpi=120)
    plt.close(fig)


def make_standalone_script(
    params: SpoolPullDirection2DParams,
    duration: float = 12.0,
) -> str:
    p = asdict(params)
    p["theta"] = params.theta
    p["r"]     = params.r
    return f'''"""
Spool Pull Direction (2D) — auto-generated simulation script.

Physics:
  τ_contact = T (r − R cosθ);   critical cos θ_c = r/R.
  M v̇_x = T cosθ + F_f,    I ω̇ = T r + R F_f,    I = I_factor · M R².
  F_f   = −μ_k M g · tanh(α (v_x + ω R))
  Tension acts at P = (r sinθ, −r cosθ) on the inner spindle in direction
  (cosθ, sinθ); torque about CoM is T r CCW (independent of θ).
"""
import math
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

# ── Parameters ──────────────────────────────────────────────────────────────
M          = {p["M"]}
R          = {p["R"]}
r          = {p["r"]}
I_factor   = {p["I_factor"]}
mu_k       = {p["mu_k"]}
g          = {p["g"]}
T          = {p["T"]}
theta      = {p["theta"]}
alpha_tanh = {p["alpha_tanh"]}
x0         = {p["x0"]}
phi0       = {p["phi0"]}
duration   = {duration}
fps        = 30
I          = I_factor * M * R**2

cos_th = math.cos(theta); sin_th = math.sin(theta)

def ode(t, y):
    x, phi, vx, omega = y
    v_contact = vx + omega * R
    F_f    = -mu_k * M * g * np.tanh(alpha_tanh * v_contact)
    F_T_x  = T * cos_th
    tau_T  = T * r
    return [vx, omega, (F_T_x + F_f) / M, (R * F_f + tau_T) / I]

t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
sol = solve_ivp(ode, (0.0, duration), [x0, phi0, 0.0, 0.0],
                t_eval=t_eval, method="RK45", rtol=1e-9, atol=1e-11)
t = sol.t; y = sol.y
x_arr, phi_arr = y[0], y[1]

# ── Visual layout ───────────────────────────────────────────────────────────
L_thread = 1.6
pad_x = max(R * 1.5, 0.4)
x_min = float(np.min(x_arr)) - pad_x - 0.2
x_max = float(np.max(x_arr)) + pad_x + L_thread * cos_th + 0.5
if x_max - x_min < 5.0:
    mid = 0.5 * (x_min + x_max)
    x_min, x_max = mid - 2.5, mid + 2.5
y_top = max(2 * R + 0.5, R - r * cos_th + L_thread * sin_th + 0.4)

fig, ax = plt.subplots(figsize=(11, 4.6), facecolor="#1a1a2e")
ax.set_facecolor("#16213e")
ax.set_xlim(x_min, x_max); ax.set_ylim(-0.18, y_top)
ax.set_aspect("equal"); ax.axis("off")
ax.axhline(0.0, color="#3a3a4f", lw=2.5, zorder=1)

outer_disc = patches.Circle((x0, R), R,
    facecolor="#457b9d", edgecolor="white", lw=1.5, zorder=3)
inner_disc = patches.Circle((x0, R), r,
    facecolor="#1d3557", edgecolor="white", lw=1.0, zorder=4)
ax.add_patch(outer_disc); ax.add_patch(inner_disc)

spoke_line, = ax.plot([], [], "-", color="#e63946", lw=2.5, zorder=5)
tip_dot,    = ax.plot([], [], "o", color="#e63946", ms=8, zorder=5)
thread_line, = ax.plot([], [], "-", color="#ffd166", lw=2.5, zorder=6)
grip = patches.Circle((0, 0), 0.05, facecolor="#ffd166",
                      edgecolor="white", lw=1.0, zorder=7)
ax.add_patch(grip)


def update(frame):
    cx = float(x_arr[frame])
    ph = float(phi_arr[frame])
    outer_disc.center = (cx, R)
    inner_disc.center = (cx, R)
    sx = cx + R * math.cos(ph)
    sy = R  + R * math.sin(ph)
    spoke_line.set_data([cx, sx], [R, sy])
    tip_dot.set_data([sx], [sy])
    tx0 = cx + r * sin_th; ty0 = R - r * cos_th
    tx1 = tx0 + L_thread * cos_th; ty1 = ty0 + L_thread * sin_th
    thread_line.set_data([tx0, tx1], [ty0, ty1])
    grip.center = (tx1, ty1)
    return [outer_disc, inner_disc, spoke_line, tip_dot, thread_line, grip]

ani = animation.FuncAnimation(fig, update, frames=len(t),
                              interval=1000 / fps, blit=False)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Spool Pull Direction (2D)")
    parser.add_argument("--M",         type=float, default=1.0)
    parser.add_argument("--R",         type=float, default=0.20)
    parser.add_argument("--r_over_R",  type=float, default=0.50)
    parser.add_argument("--mu_k",      type=float, default=0.20)
    parser.add_argument("--T",         type=float, default=0.6)
    parser.add_argument("--theta_deg", type=float, default=30.0)
    parser.add_argument("--duration",  type=float, default=12.0)
    parser.add_argument("--output",    type=str,   default="spool_pull_direction_2d.mp4")
    args = parser.parse_args()

    p = SpoolPullDirection2DParams(
        M=args.M, R=args.R, r_over_R=args.r_over_R,
        mu_k=args.mu_k, T=args.T, theta_deg=args.theta_deg,
    )
    print(
        f"Spool: M={p.M:.2f} kg, R={p.R:.3f} m, r={p.r:.3f} m (r/R={p.r_over_R:.2f})\n"
        f"  μ_k={p.mu_k:.3f}\n"
        f"  T={p.T:.3f} N, θ={math.degrees(p.theta):.1f}°  "
        f"(θ_c={math.degrees(math.acos(p.r/p.R)):.1f}°)\n"
    )
    t, y = simulate(p, duration=args.duration)
    print(f"Simulation done. Frames: {y.shape[1]}, "
          f"x ∈ [{y[0].min():+.3f}, {y[0].max():+.3f}] m")
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
