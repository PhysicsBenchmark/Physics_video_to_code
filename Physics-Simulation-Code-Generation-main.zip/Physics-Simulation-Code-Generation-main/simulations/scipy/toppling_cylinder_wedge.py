"""
Toppling Cylinder on a Wedge - 4-phase rigid-body dynamics.

Phase 1: Rigid-body topple about a fixed pivot edge (ODE integrated).
Phase 2: Sliding on the slope under Coulomb kinetic friction (closed form).
Phase 3: Kinematic tip transition over slope foot (linear angle interp).
Phase 4: Floor sliding to rest (closed form).
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis


@dataclass
class TopplingCylinderWedgeParams:
    g: float = 9.81
    alpha_deg: float = 30.0
    H_wedge: float = 0.75
    R_cyl: float = 0.10
    H_cyl: float = 0.50
    m_cyl: float = 1.0
    mu_slope: float = 0.30
    mu_floor: float = 0.30
    e_impact: float = 0.50
    s_pivot: float = 0.30
    dt_tip: float = 0.40


def _build_phases(p: TopplingCylinderWedgeParams):
    g = p.g
    alpha = np.deg2rad(p.alpha_deg)
    H_wedge = p.H_wedge
    L_base = H_wedge / np.tan(alpha)
    L_slope = H_wedge / np.sin(alpha)
    R_cyl, H_cyl, m_cyl = p.R_cyl, p.H_cyl, p.m_cyl

    I_CoM = 0.25 * m_cyl * R_cyl ** 2 + (1.0 / 12.0) * m_cyl * H_cyl ** 2
    d_CoM_pivot = np.sqrt(R_cyl ** 2 + (H_cyl / 2.0) ** 2)
    I_pivot = I_CoM + m_cyl * d_CoM_pivot ** 2

    ca, sa = np.cos(alpha), np.sin(alpha)
    apex_lab = (0.0, H_wedge)
    pivot_lab = (apex_lab[0] + p.s_pivot * ca, apex_lab[1] - p.s_pivot * sa)

    def topple_ode(t, state):
        th, om = state
        dom = m_cyl * g * ((H_cyl / 2) * np.sin(th + alpha) - R_cyl * np.cos(th + alpha)) / I_pivot
        return [om, dom]

    def topple_done(t, state):
        return state[0] - np.pi / 2
    topple_done.terminal = True
    topple_done.direction = +1

    sol_topple = solve_ivp(topple_ode, (0.0, 5.0), [0.0, 0.0],
                           events=topple_done, dense_output=True,
                           rtol=1e-9, atol=1e-11)
    t_topple_end = float(sol_topple.t_events[0][0])
    theta_dot_at_topple = float(sol_topple.y_events[0][0][1])

    KE_pre = 0.5 * I_pivot * theta_dot_at_topple ** 2
    KE_post = p.e_impact ** 2 * KE_pre
    v_slide_0 = np.sqrt(2 * KE_post / m_cyl)

    s_CoM_after_topple = p.s_pivot + H_cyl / 2.0
    s_CoM_at_slope_end = L_slope - H_cyl / 2.0
    ds_phase2 = s_CoM_at_slope_end - s_CoM_after_topple
    a_slope = g * (sa - p.mu_slope * ca)
    if a_slope <= 0 or ds_phase2 <= 0:
        # Friction holds or geometry invalid; fall back to gentle motion
        a_slope = max(a_slope, 0.05)
        ds_phase2 = max(ds_phase2, 0.05)
    v_at_slope_end = np.sqrt(v_slide_0 ** 2 + 2 * a_slope * ds_phase2)
    t_phase2_dur = (v_at_slope_end - v_slide_0) / a_slope

    dt_tip = p.dt_tip
    v_lead_h = v_at_slope_end * ca
    dx_lead_tip = v_lead_h * dt_tip
    x_CoM_at_tip_end = L_base + dx_lead_tip - H_cyl / 2.0

    a_floor = p.mu_floor * g
    v_floor_0 = v_lead_h
    t_phase4_dur = v_floor_0 / a_floor if a_floor > 0 else 0.0
    dx_phase4 = v_floor_0 ** 2 / (2.0 * a_floor) if a_floor > 0 else 0.0

    t1_end = t_topple_end
    t2_end = t1_end + t_phase2_dur
    t3_end = t2_end + dt_tip
    t4_end = t3_end + t_phase4_dur

    info = dict(
        sol_topple=sol_topple, alpha=alpha, ca=ca, sa=sa,
        H_wedge=H_wedge, L_base=L_base, L_slope=L_slope,
        R_cyl=R_cyl, H_cyl=H_cyl,
        apex_lab=apex_lab, pivot_lab=pivot_lab,
        v_slide_0=v_slide_0, a_slope=a_slope,
        s_CoM_after_topple=s_CoM_after_topple,
        v_at_slope_end=v_at_slope_end, dt_tip=dt_tip,
        v_lead_h=v_lead_h, x_CoM_at_tip_end=x_CoM_at_tip_end,
        v_floor_0=v_floor_0, a_floor=a_floor,
        t1_end=t1_end, t2_end=t2_end, t3_end=t3_end, t4_end=t4_end,
        I_pivot=I_pivot, theta_dot_at_topple=theta_dot_at_topple,
    )
    return info


def _corners_at(t, info):
    R_cyl, H_cyl = info["R_cyl"], info["H_cyl"]
    ca, sa = info["ca"], info["sa"]
    pivot_lab = info["pivot_lab"]; apex_lab = info["apex_lab"]
    L_base = info["L_base"]; alpha = info["alpha"]

    def slope_to_lab(x_s, y_s, x_org, y_org):
        return (x_s * ca + y_s * sa + x_org, -x_s * sa + y_s * ca + y_org)

    if t <= info["t1_end"]:
        theta = float(info["sol_topple"].sol(t)[0])
        cos_t, sin_t = np.cos(theta), np.sin(theta)
        pts_slope = [
            (-2 * R_cyl * cos_t, 2 * R_cyl * sin_t),
            (0.0, 0.0),
            (H_cyl * sin_t, H_cyl * cos_t),
            (H_cyl * sin_t - 2 * R_cyl * cos_t, H_cyl * cos_t + 2 * R_cyl * sin_t),
        ]
        return [slope_to_lab(xs, ys, *pivot_lab) for xs, ys in pts_slope]
    if t <= info["t2_end"]:
        dt = t - info["t1_end"]
        s_CoM = info["s_CoM_after_topple"] + info["v_slide_0"] * dt + 0.5 * info["a_slope"] * dt * dt
        pts_slope = [(s_CoM - H_cyl / 2, 0.0), (s_CoM + H_cyl / 2, 0.0),
                     (s_CoM + H_cyl / 2, 2 * R_cyl), (s_CoM - H_cyl / 2, 2 * R_cyl)]
        return [slope_to_lab(xs, ys, *apex_lab) for xs, ys in pts_slope]
    if t <= info["t3_end"]:
        dt = t - info["t2_end"]
        theta_b = alpha * (1.0 - dt / info["dt_tip"])
        x_lead = L_base + info["v_lead_h"] * dt
        cb, sb = np.cos(theta_b), np.sin(theta_b)
        L_dir = np.array([cb, -sb]); S_dir = np.array([sb, cb])
        leading = np.array([x_lead, 0.0])
        c0 = leading
        c1 = leading - L_dir * H_cyl
        c2 = leading - L_dir * H_cyl + S_dir * 2 * R_cyl
        c3 = leading + S_dir * 2 * R_cyl
        return [tuple(c0), tuple(c1), tuple(c2), tuple(c3)]
    if t <= info["t4_end"]:
        dt = t - info["t3_end"]
        x_CoM = info["x_CoM_at_tip_end"] + info["v_floor_0"] * dt - 0.5 * info["a_floor"] * dt * dt
        return [(x_CoM - H_cyl / 2, 0.0), (x_CoM + H_cyl / 2, 0.0),
                (x_CoM + H_cyl / 2, 2 * R_cyl), (x_CoM - H_cyl / 2, 2 * R_cyl)]
    x_CoM = info["x_CoM_at_tip_end"] + info["v_floor_0"] ** 2 / (2.0 * info["a_floor"]) if info["a_floor"] > 0 else info["x_CoM_at_tip_end"]
    return [(x_CoM - H_cyl / 2, 0.0), (x_CoM + H_cyl / 2, 0.0),
            (x_CoM + H_cyl / 2, 2 * R_cyl), (x_CoM - H_cyl / 2, 2 * R_cyl)]


def simulate(params: TopplingCylinderWedgeParams, duration: float = 4.0, fps: int = 30):
    info = _build_phases(params)
    duration = max(duration, info["t4_end"] + 0.5)
    t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
    n = t_eval.size
    y = np.zeros((8, n))   # 4 corners × 2 coords
    for i, t in enumerate(t_eval):
        corners = _corners_at(t, info)
        for k, (cx, cy) in enumerate(corners):
            y[2 * k, i] = cx
            y[2 * k + 1, i] = cy
    return t_eval, y


def render_video(t, y, params: TopplingCylinderWedgeParams, output_path: str, fps: int = 30):
    alpha = np.deg2rad(params.alpha_deg)
    H_wedge = params.H_wedge
    L_base = H_wedge / np.tan(alpha)

    all_x = y[0::2, :].flatten()
    all_y = y[1::2, :].flatten()
    x_lo_d = min(all_x.min(), 0.0) - 0.20
    x_hi_d = max(all_x.max(), L_base) + 0.20
    y_lo_d = -0.20
    y_hi_d = max(all_y.max(), H_wedge) + 0.20

    fig_w, fig_h = 12.0, 5.5
    fig_aspect = fig_w / fig_h
    dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_d / dy_d < fig_aspect:
        extra = (fig_aspect * dy_d - dx_d) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx_d / fig_aspect - dy_d) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h))
    ax = fig.add_axes([0, 0, 1, 1])
    setup_dark_axis(fig, ax, (x_lo, x_hi), (y_lo, y_hi))

    ax.add_patch(Polygon([(x_lo, y_lo), (x_hi, y_lo), (x_hi, 0.0), (x_lo, 0.0)],
                         facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.plot([x_lo, x_hi], [0.0, 0.0], color="#adb5bd", lw=2.0, zorder=1)
    ax.add_patch(Polygon([(0.0, 0.0), (L_base, 0.0), (0.0, H_wedge)],
                         facecolor="#a8dadc", edgecolor="#adb5bd", lw=1.5, zorder=2))

    cyl = Polygon([(0, 0)] * 4, facecolor="#e63946", edgecolor="#adb5bd", lw=1.5, zorder=4)
    ax.add_patch(cyl)

    def update(f):
        pts = [(y[2 * k, f], y[2 * k + 1, f]) for k in range(4)]
        cyl.set_xy(pts)
        return (cyl,)

    ani = animation.FuncAnimation(fig, update, frames=len(t), interval=1000.0 / fps, blit=False)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: TopplingCylinderWedgeParams, duration: float = 4.0) -> str:
    p = asdict(params)
    return f'''"""Toppling Cylinder on a Wedge - auto-generated."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon
from scipy.integrate import solve_ivp

g            = {p["g"]}
alpha        = np.deg2rad({p["alpha_deg"]})
H_wedge      = {p["H_wedge"]}
L_base       = H_wedge / np.tan(alpha)
L_slope      = H_wedge / np.sin(alpha)
R_cyl        = {p["R_cyl"]}
H_cyl        = {p["H_cyl"]}
m_cyl        = {p["m_cyl"]}
mu_slope     = {p["mu_slope"]}
mu_floor     = {p["mu_floor"]}
e_impact     = {p["e_impact"]}
s_pivot      = {p["s_pivot"]}
dt_tip       = {p["dt_tip"]}
fps          = 30

I_CoM        = 0.25 * m_cyl * R_cyl ** 2 + (1.0 / 12.0) * m_cyl * H_cyl ** 2
d_CoM_pivot  = np.sqrt(R_cyl ** 2 + (H_cyl / 2.0) ** 2)
I_pivot      = I_CoM + m_cyl * d_CoM_pivot ** 2
ca, sa       = np.cos(alpha), np.sin(alpha)
apex_lab     = (0.0, H_wedge)
pivot_lab    = (apex_lab[0] + s_pivot * ca, apex_lab[1] - s_pivot * sa)

def slope_to_lab(x_s, y_s, x_org, y_org):
    return (x_s * ca + y_s * sa + x_org, -x_s * sa + y_s * ca + y_org)

def topple_ode(t, state):
    th, om = state
    dom = m_cyl * g * ((H_cyl / 2) * np.sin(th + alpha) - R_cyl * np.cos(th + alpha)) / I_pivot
    return [om, dom]
def topple_done(t, state): return state[0] - np.pi/2
topple_done.terminal = True; topple_done.direction = +1

sol_topple = solve_ivp(topple_ode, (0.0, 5.0), [0.0, 0.0], events=topple_done,
                       dense_output=True, rtol=1e-9, atol=1e-11)
t_topple_end = float(sol_topple.t_events[0][0])
theta_dot_at_topple = float(sol_topple.y_events[0][0][1])

KE_pre  = 0.5 * I_pivot * theta_dot_at_topple ** 2
KE_post = e_impact**2 * KE_pre
v_slide_0 = np.sqrt(2*KE_post/m_cyl)

s_CoM_after_topple = s_pivot + H_cyl/2.0
s_CoM_at_slope_end = L_slope - H_cyl/2.0
ds_phase2 = max(s_CoM_at_slope_end - s_CoM_after_topple, 0.05)
a_slope   = max(g*(sa - mu_slope*ca), 0.05)
v_at_slope_end = np.sqrt(v_slide_0**2 + 2*a_slope*ds_phase2)
t_phase2_dur   = (v_at_slope_end - v_slide_0)/a_slope

v_lead_h        = v_at_slope_end*ca
dx_lead_tip     = v_lead_h*dt_tip
x_CoM_at_tip_end= L_base + dx_lead_tip - H_cyl/2.0
a_floor         = mu_floor*g
v_floor_0       = v_lead_h
t_phase4_dur    = v_floor_0/a_floor if a_floor>0 else 0
dx_phase4       = v_floor_0**2/(2*a_floor) if a_floor>0 else 0

t1_end=t_topple_end; t2_end=t1_end+t_phase2_dur
t3_end=t2_end+dt_tip; t4_end=t3_end+t_phase4_dur
duration = max({duration}, t4_end+0.5)

def corners_phase1(theta):
    cos_t, sin_t = np.cos(theta), np.sin(theta)
    pts_slope = [(-2*R_cyl*cos_t, 2*R_cyl*sin_t), (0.,0.),
                 (H_cyl*sin_t, H_cyl*cos_t),
                 (H_cyl*sin_t-2*R_cyl*cos_t, H_cyl*cos_t+2*R_cyl*sin_t)]
    return [slope_to_lab(xs,ys,*pivot_lab) for xs,ys in pts_slope]
def corners_phase2(s_CoM):
    pts_slope = [(s_CoM-H_cyl/2,0.0),(s_CoM+H_cyl/2,0.0),
                 (s_CoM+H_cyl/2,2*R_cyl),(s_CoM-H_cyl/2,2*R_cyl)]
    return [slope_to_lab(xs,ys,*apex_lab) for xs,ys in pts_slope]
def corners_phase3(theta_b, x_lead):
    cb,sb = np.cos(theta_b), np.sin(theta_b)
    L_dir = np.array([cb,-sb]); S_dir = np.array([sb,cb])
    leading = np.array([x_lead,0.0])
    c0 = leading; c1 = leading-L_dir*H_cyl
    c2 = leading-L_dir*H_cyl+S_dir*2*R_cyl
    c3 = leading+S_dir*2*R_cyl
    return [tuple(c0),tuple(c1),tuple(c2),tuple(c3)]
def corners_phase4(x_CoM):
    return [(x_CoM-H_cyl/2,0.0),(x_CoM+H_cyl/2,0.0),
            (x_CoM+H_cyl/2,2*R_cyl),(x_CoM-H_cyl/2,2*R_cyl)]
def corners_at(t):
    if t<=t1_end:
        return corners_phase1(float(sol_topple.sol(t)[0]))
    if t<=t2_end:
        dt=t-t1_end; s_CoM=s_CoM_after_topple+v_slide_0*dt+0.5*a_slope*dt*dt
        return corners_phase2(s_CoM)
    if t<=t3_end:
        dt=t-t2_end; tb=alpha*(1.-dt/dt_tip); xl=L_base+v_lead_h*dt
        return corners_phase3(tb,xl)
    if t<=t4_end:
        dt=t-t3_end; xc=x_CoM_at_tip_end+v_floor_0*dt-0.5*a_floor*dt*dt
        return corners_phase4(xc)
    return corners_phase4(x_CoM_at_tip_end+dx_phase4)

ts_grid = np.linspace(0., duration, int(duration*fps)+1)
all_x,all_y=[],[]
for t_ in ts_grid:
    for c in corners_at(t_):
        all_x.append(c[0]); all_y.append(c[1])
all_x=np.array(all_x); all_y=np.array(all_y)
x_lo_d=min(all_x.min(),0.0)-0.20; x_hi_d=max(all_x.max(),L_base)+0.20
y_lo_d=-0.20; y_hi_d=max(all_y.max(),H_wedge)+0.20
fig_w,fig_h=12.0,5.5; fa=fig_w/fig_h
dx_d,dy_d=x_hi_d-x_lo_d, y_hi_d-y_lo_d
if dx_d/dy_d<fa:
    e=(fa*dy_d-dx_d)/2.0; x_lo,x_hi=x_lo_d-e,x_hi_d+e; y_lo,y_hi=y_lo_d,y_hi_d
else:
    e=(dx_d/fa-dy_d)/2.0; x_lo,x_hi=x_lo_d,x_hi_d; y_lo,y_hi=y_lo_d-e,y_hi_d+e

fig=plt.figure(figsize=(fig_w,fig_h),facecolor="#1a1a2e")
ax=fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi); ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(Polygon([(x_lo,y_lo),(x_hi,y_lo),(x_hi,0.0),(x_lo,0.0)],
                     facecolor="#4a4e69",edgecolor="none",zorder=0))
ax.plot([x_lo,x_hi],[0.0,0.0],color="#adb5bd",lw=2.0,zorder=1)
ax.add_patch(Polygon([(0.,0.),(L_base,0.),(0.,H_wedge)],
                     facecolor="#a8dadc",edgecolor="#adb5bd",lw=1.5,zorder=2))
cyl=Polygon([(0,0)]*4,facecolor="#e63946",edgecolor="#adb5bd",lw=1.5,zorder=4)
ax.add_patch(cyl)

def update(f):
    cyl.set_xy(corners_at(f/fps)); return (cyl,)

n_frames=int(duration*fps)+1
ani=animation.FuncAnimation(fig,update,frames=n_frames,interval=1000./fps,blit=False)
ani.save("video.mp4",writer=animation.FFMpegWriter(fps=fps,bitrate=1800),dpi=120)
plt.close(); print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--alpha_deg", type=float, default=30.0)
    parser.add_argument("--H_wedge", type=float, default=0.75)
    parser.add_argument("--R_cyl", type=float, default=0.10)
    parser.add_argument("--H_cyl", type=float, default=0.50)
    parser.add_argument("--m_cyl", type=float, default=1.0)
    parser.add_argument("--mu_slope", type=float, default=0.30)
    parser.add_argument("--mu_floor", type=float, default=0.30)
    parser.add_argument("--e_impact", type=float, default=0.50)
    parser.add_argument("--s_pivot", type=float, default=0.30)
    parser.add_argument("--dt_tip", type=float, default=0.40)
    parser.add_argument("--duration", type=float, default=4.0)
    parser.add_argument("--output", type=str, default="video.mp4")
    args = parser.parse_args()
    p = TopplingCylinderWedgeParams(**{k: getattr(args, k) for k in
        ["alpha_deg","H_wedge","R_cyl","H_cyl","m_cyl","mu_slope","mu_floor",
         "e_impact","s_pivot","dt_tip"]})
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
