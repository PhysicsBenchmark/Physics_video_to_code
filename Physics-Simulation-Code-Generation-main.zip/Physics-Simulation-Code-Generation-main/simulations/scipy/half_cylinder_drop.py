"""
Half-Cylinder Drop — 2D side-view of a half-disc falling and rocking.

Phases: free flight, impulsive collision (Newton e + Coulomb mu, decoupled
normal/tangent), and rocking-with-rolling-without-slipping (single-DOF
Lagrangian for theta).
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class HalfCylinderDropParams:
    g: float = 9.8
    M: float = 1.0
    R: float = 0.30
    e_rest: float = 0.50
    mu: float = 0.30
    gamma_rock: float = 0.40
    X_com_0: float = 0.0
    Y_com_0: float = 0.80
    theta_0: float = 0.30
    V_x_0: float = 0.0
    V_y_0: float = 0.0
    omega_0: float = 0.0


def _integrate(p: HalfCylinderDropParams, duration: float, fps: int):
    g, M, R = p.g, p.M, p.R
    e_rest, mu, gamma_rock = p.e_rest, p.mu, p.gamma_rock
    h_com = 4.0 * R / (3.0 * np.pi)
    I_com = M * R * R * (0.5 - 16.0 / (9.0 * np.pi * np.pi))

    def gap(Yc, th):
        # Lab y of body's lowest point, minus 0 (floor).
        # For |th| ≤ pi/2 the curve apex is the lowest; for |th| > pi/2
        # the curve apex lies above the flat edge so a flat-edge corner is lowest.
        cos_t = np.cos(th); sin_t = np.sin(th)
        if cos_t >= 0:
            return Yc + h_com * cos_t - R
        else:
            return Yc + h_com * cos_t - R * abs(sin_t)

    def contact_r(th):
        cos_t = np.cos(th); sin_t = np.sin(th)
        if cos_t >= 0:
            return -h_com * sin_t, h_com * cos_t - R
        # Flat-edge lower corner: body coord (sgn·R, h_com), sgn = -sign(sin_t)
        sgn = -1.0 if sin_t > 0 else 1.0
        rx = sgn * R * cos_t - h_com * sin_t
        ry = sgn * R * sin_t + h_com * cos_t
        return rx, ry

    def free_flight(t, y):
        return [y[3], y[4], y[5], 0.0, -g, 0.0]

    def ev_contact(t, y):
        return gap(y[1], y[2])
    ev_contact.terminal = True
    ev_contact.direction = -1

    def contact_impulse(state):
        s = state.copy()
        Xc, Yc, th, Vx, Vy, om = s
        rx, ry = contact_r(th)
        vcx = Vx - ry * om; vcy = Vy + rx * om
        if vcy > 0.0:
            return s
        Jn = -(1.0 + e_rest) * vcy / (1.0 / M + rx * rx / I_com)
        Jt_stk = -vcx / (1.0 / M + ry * ry / I_com)
        Jt = np.clip(Jt_stk, -mu * Jn, mu * Jn)
        s[3] = Vx + Jt / M
        s[4] = Vy + Jn / M
        s[5] = om + (rx * Jn - ry * Jt) / I_com
        # Snap Yc so the actual contact point sits on the floor, plus a tiny
        # lift so gap > 0 strictly at the start of the next free-flight
        # segment (otherwise solve_ivp's direction=-1 event detection misses
        # the crossing when the post-impulse Vy is still downward).
        cos_t2 = np.cos(s[2]); sin_t2 = np.sin(s[2])
        if cos_t2 >= 0:
            s[1] = R - h_com * cos_t2 + 1e-6
        else:
            s[1] = R * abs(sin_t2) - h_com * cos_t2 + 1e-6
        return s

    def M_eff(th):
        return I_com + M * (R * R - 2.0 * R * h_com * np.cos(th) + h_com * h_com)

    def dM_eff(th):
        return 2.0 * M * R * h_com * np.sin(th)

    def rocking_ode(t, z):
        th, om = z
        Meff = M_eff(th)
        return [om, -(0.5 * dM_eff(th) * om * om + M * g * h_com * np.sin(th)
                       + gamma_rock * om) / Meff]

    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    N = t_eval.size
    Xc_arr = np.zeros(N); Yc_arr = np.zeros(N); th_arr = np.zeros(N)
    state = np.array([p.X_com_0, p.Y_com_0, p.theta_0, p.V_x_0, p.V_y_0, p.omega_0],
                     dtype=float)
    Xc_arr[0], Yc_arr[0], th_arr[0] = state[0], state[1], state[2]
    last_idx = 1; t_cur = 0.0
    rocking_started_at = None
    VY_THRESH = 0.10; GAP_EPS = 5e-4

    for _seg in range(300):
        if t_cur >= duration - 1e-12:
            break
        sol = solve_ivp(free_flight, (t_cur, duration), state,
                        events=[ev_contact], dense_output=True,
                        max_step=0.02, rtol=1e-9, atol=1e-11)
        seg_end = sol.t[-1]
        while last_idx < N and t_eval[last_idx] <= seg_end + 1e-12:
            st = sol.sol(t_eval[last_idx])
            Xc_arr[last_idx], Yc_arr[last_idx], th_arr[last_idx] = st[0], st[1], st[2]
            last_idx += 1
        state = sol.y[:, -1].copy(); t_cur = seg_end
        if sol.status != 1:
            break
        state = contact_impulse(state)
        post_Vy = state[4]
        if abs(post_Vy) < VY_THRESH and abs(gap(state[1], state[2])) < GAP_EPS \
                and np.cos(state[2]) >= 0:
            # Curve-side settling → switch to rocking ODE for the remaining clip.
            rocking_started_at = t_cur
            break

    if rocking_started_at is not None:
        if t_cur < duration - 1e-12:
            sol_r = solve_ivp(rocking_ode, (t_cur, duration), [state[2], state[5]],
                              dense_output=True, max_step=0.01,
                              rtol=1e-9, atol=1e-11)
            rock_start_idx = np.searchsorted(t_eval, t_cur, side='left')
            Xc_cur = state[0]; prev_t = t_cur
            prev_Vx_rock = -state[5] * (R - h_com * np.cos(state[2]))
            for k in range(rock_start_idx, N):
                t_q = max(t_eval[k], t_cur)
                t_q = min(t_q, sol_r.t[-1])
                zq = sol_r.sol(t_q)
                th_q, om_q = zq[0], zq[1]
                Vx_q = -om_q * (R - h_com * np.cos(th_q))
                dt = t_q - prev_t
                if dt > 0:
                    Xc_cur += 0.5 * (prev_Vx_rock + Vx_q) * dt
                Xc_arr[k] = Xc_cur
                Yc_arr[k] = R - h_com * np.cos(th_q)
                th_arr[k] = th_q
                prev_t = t_q; prev_Vx_rock = Vx_q
    else:
        if last_idx < N:
            Xc_arr[last_idx:] = state[0]
            Yc_arr[last_idx:] = state[1]
            th_arr[last_idx:] = state[2]

    return t_eval, np.vstack([Xc_arr, Yc_arr, th_arr])


def simulate(params: HalfCylinderDropParams, duration: float = 12.0, fps: int = 30):
    return _integrate(params, duration, fps)


def render_video(t, y, params: HalfCylinderDropParams, output_path: str, fps: int = 30):
    p = params
    Xc_arr, Yc_arr, th_arr = y[0], y[1], y[2]
    R = p.R
    h_com = 4.0 * R / (3.0 * np.pi)
    _phi = np.linspace(np.pi, 2.0 * np.pi, 80)
    _curve_x = R * np.cos(_phi); _curve_y = h_com + R * np.sin(_phi)
    _body_verts = np.column_stack([
        np.concatenate([[+R, -R], _curve_x]),
        np.concatenate([[h_com, h_com], _curve_y]),
    ])

    def lab_polygon(Xc, Yc, th):
        c, s = np.cos(th), np.sin(th)
        Rmat = np.array([[c, -s], [s, c]])
        return _body_verts @ Rmat.T + np.array([Xc, Yc])

    fig_w, fig_h = 8.0, 5.0
    fig_aspect = fig_w / fig_h
    x_lo_d = p.X_com_0 - 1.0; x_hi_d = p.X_com_0 + 1.0
    y_lo = -0.20; y_hi_d = p.Y_com_0 + 0.50
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi, y_hi = x_lo_d - extra, x_hi_d + extra, y_hi_d
    else:
        extra = dx / fig_aspect - dy
        x_lo, x_hi, y_hi = x_lo_d, x_hi_d, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1]); ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")
    ax.axhspan(y_lo, 0.0, color="#4a4e69", alpha=0.55, zorder=0)
    ax.axhline(0, color="#adb5bd", lw=2, zorder=1)
    body_poly = Polygon(lab_polygon(Xc_arr[0], Yc_arr[0], th_arr[0]),
                        closed=True, facecolor="#ffd166", edgecolor="white",
                        lw=1.5, zorder=3)
    ax.add_patch(body_poly)

    def update(f):
        body_poly.set_xy(lab_polygon(Xc_arr[f], Yc_arr[f], th_arr[f]))
        return (body_poly,)

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0 / fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: HalfCylinderDropParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Half-cylinder drop standalone script."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon

g = {p["g"]}
M = {p["M"]}
R = {p["R"]}
e_rest = {p["e_rest"]}
mu = {p["mu"]}
gamma_rock = {p["gamma_rock"]}
X_com_0 = {p["X_com_0"]}
Y_com_0 = {p["Y_com_0"]}
theta_0 = {p["theta_0"]}
V_x_0 = {p["V_x_0"]}
V_y_0 = {p["V_y_0"]}
omega_0 = {p["omega_0"]}
duration = {duration}
fps = 30

h_com = 4.0*R/(3.0*np.pi)
I_com = M*R*R*(0.5 - 16.0/(9.0*np.pi*np.pi))

_phi = np.linspace(np.pi, 2.0*np.pi, 80)
_curve_x = R*np.cos(_phi); _curve_y = h_com + R*np.sin(_phi)
_body_verts = np.column_stack([
    np.concatenate([[+R,-R], _curve_x]),
    np.concatenate([[h_com, h_com], _curve_y]),
])

def lab_polygon(Xc, Yc, th):
    c, s = np.cos(th), np.sin(th)
    Rmat = np.array([[c,-s],[s,c]])
    return _body_verts @ Rmat.T + np.array([Xc, Yc])

def gap(Yc, th):
    cos_t = np.cos(th); sin_t = np.sin(th)
    if cos_t >= 0:
        return Yc + h_com*cos_t - R
    return Yc + h_com*cos_t - R*abs(sin_t)
def contact_r(th):
    cos_t = np.cos(th); sin_t = np.sin(th)
    if cos_t >= 0:
        return -h_com*sin_t, h_com*cos_t - R
    sgn = -1.0 if sin_t > 0 else 1.0
    return sgn*R*cos_t - h_com*sin_t, sgn*R*sin_t + h_com*cos_t
def free_flight(t, y): return [y[3], y[4], y[5], 0.0, -g, 0.0]
def ev_contact(t, y): return gap(y[1], y[2])
ev_contact.terminal = True; ev_contact.direction = -1

def contact_impulse(state):
    s = state.copy()
    Xc, Yc, th, Vx, Vy, om = s
    rx, ry = contact_r(th)
    vcx = Vx - ry*om; vcy = Vy + rx*om
    if vcy > 0.0: return s
    Jn = -(1.0+e_rest)*vcy / (1.0/M + rx*rx/I_com)
    Jt_stk = -vcx / (1.0/M + ry*ry/I_com)
    Jt = np.clip(Jt_stk, -mu*Jn, mu*Jn)
    s[3] = Vx + Jt/M
    s[4] = Vy + Jn/M
    s[5] = om + (rx*Jn - ry*Jt)/I_com
    cos_t2 = np.cos(s[2]); sin_t2 = np.sin(s[2])
    if cos_t2 >= 0:
        s[1] = R - h_com*cos_t2 + 1e-6
    else:
        s[1] = R*abs(sin_t2) - h_com*cos_t2 + 1e-6
    return s

def M_eff(th): return I_com + M*(R*R - 2.0*R*h_com*np.cos(th) + h_com*h_com)
def dM_eff(th): return 2.0*M*R*h_com*np.sin(th)
def rocking_ode(t, z):
    th, om = z
    Meff = M_eff(th)
    return [om, -(0.5*dM_eff(th)*om*om + M*g*h_com*np.sin(th) + gamma_rock*om)/Meff]

t_eval = np.linspace(0, duration, int(duration*fps)+1)
N = t_eval.size
Xc_arr = np.zeros(N); Yc_arr = np.zeros(N); th_arr = np.zeros(N)
state = np.array([X_com_0, Y_com_0, theta_0, V_x_0, V_y_0, omega_0], dtype=float)
Xc_arr[0], Yc_arr[0], th_arr[0] = state[0], state[1], state[2]
last_idx = 1; t_cur = 0.0; rocking_started_at = None
VY_THRESH = 0.10; GAP_EPS = 5e-4

for _seg in range(300):
    if t_cur >= duration - 1e-12: break
    sol = solve_ivp(free_flight, (t_cur, duration), state,
                    events=[ev_contact], dense_output=True,
                    max_step=0.02, rtol=1e-9, atol=1e-11)
    seg_end = sol.t[-1]
    while last_idx < N and t_eval[last_idx] <= seg_end + 1e-12:
        st = sol.sol(t_eval[last_idx])
        Xc_arr[last_idx], Yc_arr[last_idx], th_arr[last_idx] = st[0], st[1], st[2]
        last_idx += 1
    state = sol.y[:, -1].copy(); t_cur = seg_end
    if sol.status != 1: break
    state = contact_impulse(state)
    if abs(state[4]) < VY_THRESH and abs(gap(state[1], state[2])) < GAP_EPS \
            and np.cos(state[2]) >= 0:
        rocking_started_at = t_cur; break

if rocking_started_at is not None and t_cur < duration - 1e-12:
    sol_r = solve_ivp(rocking_ode, (t_cur, duration), [state[2], state[5]],
                      dense_output=True, max_step=0.01,
                      rtol=1e-9, atol=1e-11)
    rock_start_idx = np.searchsorted(t_eval, t_cur, side='left')
    Xc_cur = state[0]; prev_t = t_cur
    prev_Vx_rock = -state[5]*(R - h_com*np.cos(state[2]))
    for k in range(rock_start_idx, N):
        t_q = max(t_eval[k], t_cur); t_q = min(t_q, sol_r.t[-1])
        zq = sol_r.sol(t_q)
        th_q, om_q = zq[0], zq[1]
        Vx_q = -om_q*(R - h_com*np.cos(th_q))
        dt = t_q - prev_t
        if dt > 0: Xc_cur += 0.5*(prev_Vx_rock + Vx_q)*dt
        Xc_arr[k] = Xc_cur
        Yc_arr[k] = R - h_com*np.cos(th_q)
        th_arr[k] = th_q
        prev_t = t_q; prev_Vx_rock = Vx_q
elif last_idx < N:
    Xc_arr[last_idx:] = state[0]
    Yc_arr[last_idx:] = state[1]
    th_arr[last_idx:] = state[2]

fig_w, fig_h = 8.0, 5.0
fig_aspect = fig_w/fig_h
x_lo_d = X_com_0 - 1.0; x_hi_d = X_com_0 + 1.0
y_lo = -0.20; y_hi_d = Y_com_0 + 0.50
dx, dy = x_hi_d-x_lo_d, y_hi_d-y_lo
if dx/dy < fig_aspect:
    extra = (fig_aspect*dy - dx)/2.0
    x_lo, x_hi, y_hi = x_lo_d-extra, x_hi_d+extra, y_hi_d
else:
    extra = dx/fig_aspect - dy
    x_lo, x_hi, y_hi = x_lo_d, x_hi_d, y_hi_d+extra

fig = plt.figure(figsize=(fig_w,fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.axhspan(y_lo, 0.0, color="#4a4e69", alpha=0.55, zorder=0)
ax.axhline(0, color="#adb5bd", lw=2, zorder=1)
body_poly = Polygon(lab_polygon(Xc_arr[0], Yc_arr[0], th_arr[0]),
                    closed=True, facecolor="#ffd166", edgecolor="white",
                    lw=1.5, zorder=3)
ax.add_patch(body_poly)

def update(f):
    body_poly.set_xy(lab_polygon(Xc_arr[f], Yc_arr[f], th_arr[f]))
    return (body_poly,)

ani = animation.FuncAnimation(fig, update, frames=N,
                              interval=1000.0/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    for fld, dflt in [("g",9.8),("M",1.0),("R",0.30),("e_rest",0.50),
                       ("mu",0.30),("gamma_rock",0.40),("X_com_0",0.0),
                       ("Y_com_0",0.80),("theta_0",0.30),
                       ("V_x_0",0.0),("V_y_0",0.0),("omega_0",0.0)]:
        parser.add_argument(f"--{fld}", type=float, default=dflt)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="half_cylinder_drop.mp4")
    args = parser.parse_args()
    p = HalfCylinderDropParams(g=args.g, M=args.M, R=args.R, e_rest=args.e_rest,
                               mu=args.mu, gamma_rock=args.gamma_rock,
                               X_com_0=args.X_com_0, Y_com_0=args.Y_com_0,
                               theta_0=args.theta_0, V_x_0=args.V_x_0,
                               V_y_0=args.V_y_0, omega_0=args.omega_0)
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
