"""
Simple (Driven Damped) Pendulum Simulation
==========================================
Faithfully translated from myphysicslab/src/sims/pendulum/PendulumSim.ts

Physical Law: Newton's Second Law for Rotational Motion
    τ_net = I · α

Derivation:
    I = m L²                          (moment of inertia, point mass)
    τ_gravity  = -m g L sin(θ)        (restoring torque)
    τ_damping  = -b θ̇                 (b has units kg·m²/s)
    τ_drive    = A cos(k_freq · t)     (external driving torque)

    m L² θ̈ = -m g L sin(θ) - b θ̇ + A cos(k_freq · t)

    Dividing by m L²:
        θ̈ = -(g/L) sin(θ) - (b / m L²) θ̇ + (A / m L²) cos(k_freq · t)

State vector: [θ, ω]  where ω = θ̇
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis, spring_path


@dataclass
class SimplePendulumParams:
    L: float = 1.0          # rod length (m)
    m: float = 1.0          # bob mass (kg)
    g: float = 9.8          # gravitational acceleration (m/s²)
    b: float = 0.5          # angular damping coefficient (kg·m²/s)  [TS default]
    A: float = 0.0          # driving torque amplitude (N·m)
    k_freq: float = 0.0     # driving angular frequency (rad/s)
    theta0: float = np.pi / 4  # initial angle (rad)
    omega0: float = 0.0     # initial angular velocity (rad/s)


def ode(t: float, y: list, p: SimplePendulumParams):
    """
    ODE for the driven damped pendulum.
    Exact translation of PendulumSim.ts evaluate() method.

    change[TH]  = vars[TH_P]
    change[TH_P] = -(g/L)·sin(θ) - (b/(m·L²))·ω + (A/(m·L²))·cos(k_freq·t)
    """
    theta, omega = y
    mlsq = p.m * p.L * p.L
    dtheta = omega
    domega = (
        -(p.g / p.L) * np.sin(theta)
        - (p.b / mlsq) * omega
        + (p.A / mlsq) * np.cos(p.k_freq * t)
    )
    return [dtheta, domega]


def simulate(
    params: SimplePendulumParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Integrate the ODE using RK45 (equivalent to TypeScript RungeKutta solver).
    Returns (t, y) where y.shape = (2, N): [theta, omega] at each time step.
    """
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode,
        (0, duration),
        [params.theta0, params.omega0],
        t_eval=t_eval,
        args=(params,),
        method="RK45",
        rtol=1e-9,
        atol=1e-11,
        dense_output=False,
    )
    return sol.t, sol.y


def energy(t: np.ndarray, y: np.ndarray, p: SimplePendulumParams):
    """Kinetic, potential, and total mechanical energy."""
    theta, omega = y[0], y[1]
    KE = 0.5 * p.m * (p.L * omega) ** 2
    PE = p.m * p.g * p.L * (1 - np.cos(theta))   # zero at hanging equilibrium
    return KE, PE, KE + PE


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: SimplePendulumParams,
    output_path: str,
    fps: int = 30,
    trail_len: int = 90,
) -> None:
    """Render an MP4 video of the pendulum animation."""
    theta = y[0]
    bob_x = params.L * np.sin(theta)
    bob_y = -params.L * np.cos(theta)

    pad = params.L * 0.35
    xlim = (-params.L - pad, params.L + pad)
    ylim = (-params.L - pad, params.L * 0.4)

    fig, ax = plt.subplots(figsize=(5, 5))
    setup_dark_axis(fig, ax, xlim, ylim)

    # Static elements
    ax.plot([0], [0], "o", color="white", ms=7, zorder=5)   # pivot

    # Animated elements
    (rod,) = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
    (bob,) = ax.plot([], [], "o", color="#e63946", ms=14, zorder=4)
    (trail,) = ax.plot([], [], "-", color="#e63946", alpha=0.35, lw=1.2, zorder=2)

    trail_x: list = []
    trail_y: list = []

    def init():
        rod.set_data([], [])
        bob.set_data([], [])
        trail.set_data([], [])
        return rod, bob, trail

    def update(frame):
        rod.set_data([0, bob_x[frame]], [0, bob_y[frame]])
        bob.set_data([bob_x[frame]], [bob_y[frame]])
        trail_x.append(bob_x[frame])
        trail_y.append(bob_y[frame])
        if len(trail_x) > trail_len:
            trail_x.pop(0)
            trail_y.pop(0)
        trail.set_data(trail_x, trail_y)
        return rod, bob, trail

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), init_func=init, interval=1000 / fps, blit=True
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: SimplePendulumParams, duration: float = 12.0) -> str:
    """Return a self-contained Python script string with parameter values embedded."""
    p = asdict(params)
    return f'''"""
Simple Pendulum — auto-generated simulation script.
Physics: θ̈ = -(g/L)·sin(θ) - (b/mL²)·ω + (A/mL²)·cos(k_freq·t)
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation

# ── Physical parameters ─────────────────────────────────────────────────────
L      = {p["L"]}     # rod length (m)
m      = {p["m"]}     # bob mass (kg)
g      = {p["g"]}     # gravitational acceleration (m/s²)
b      = {p["b"]}     # angular damping coefficient (kg·m²/s)
A      = {p["A"]}     # driving torque amplitude (N·m), 0 = undriven
k_freq = {p["k_freq"]}  # driving frequency (rad/s)
theta0 = {p["theta0"]:.6f}  # initial angle (rad)
omega0 = {p["omega0"]:.6f}  # initial angular velocity (rad/s)
duration = {duration}

# ── ODE system ───────────────────────────────────────────────────────────────
def ode(t, y):
    theta, omega = y
    mlsq = m * L * L
    dtheta = omega
    domega = -(g / L) * np.sin(theta) - (b / mlsq) * omega + (A / mlsq) * np.cos(k_freq * t)
    return [dtheta, domega]

# ── Integrate ────────────────────────────────────────────────────────────────
fps = 30
t_eval = np.linspace(0, duration, int(duration * fps) + 1)
sol = solve_ivp(ode, (0, duration), [theta0, omega0],
                t_eval=t_eval, method="RK45", rtol=1e-9, atol=1e-11)
t, theta = sol.t, sol.y[0]

bob_x = L * np.sin(theta)
bob_y = -L * np.cos(theta)

# ── Animate ──────────────────────────────────────────────────────────────────
pad = L * 0.35
fig, ax = plt.subplots(figsize=(5, 5), facecolor="#1a1a2e")
ax.set_facecolor("#16213e")
ax.set_xlim(-L - pad, L + pad); ax.set_ylim(-L - pad, L * 0.4)
ax.set_aspect("equal"); ax.axis("off")
ax.plot([0], [0], "o", color="white", ms=7, zorder=5)

rod,   = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
bob_p, = ax.plot([], [], "o", color="#e63946", ms=14,  zorder=4)
trail, = ax.plot([], [], "-", color="#e63946", alpha=0.35, lw=1.2, zorder=2)
tx, ty = [], []

def update(frame):
    rod.set_data([0, bob_x[frame]], [0, bob_y[frame]])
    bob_p.set_data([bob_x[frame]], [bob_y[frame]])
    tx.append(bob_x[frame]); ty.append(bob_y[frame])
    if len(tx) > 90: tx.pop(0); ty.pop(0)
    trail.set_data(tx, ty)
    return rod, bob_p, trail

ani = animation.FuncAnimation(fig, update, frames=len(t), interval=1000/fps, blit=True)
writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
ani.save("simple_pendulum.mp4", writer=writer, dpi=120)
plt.close()
print("Saved simple_pendulum.mp4")
'''


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Simple Pendulum Simulation")
    parser.add_argument("--L", type=float, default=1.0)
    parser.add_argument("--m", type=float, default=1.0)
    parser.add_argument("--g", type=float, default=9.8)
    parser.add_argument("--b", type=float, default=0.5)
    parser.add_argument("--A", type=float, default=0.0)
    parser.add_argument("--k_freq", type=float, default=0.0)
    parser.add_argument("--theta0", type=float, default=np.pi / 4)
    parser.add_argument("--omega0", type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="simple_pendulum.mp4")
    args = parser.parse_args()

    p = SimplePendulumParams(
        L=args.L, m=args.m, g=args.g, b=args.b,
        A=args.A, k_freq=args.k_freq,
        theta0=args.theta0, omega0=args.omega0,
    )
    print(f"Simulating simple pendulum: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
