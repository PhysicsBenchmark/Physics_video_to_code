"""
Rigid Double Pendulum Simulation
==================================
Faithfully translated from myphysicslab/src/sims/pendulum/RigidDoublePendulumSim.ts

Physical Law: Two rigid uniform rods connected end-to-end (double pendulum).
Each rod has distributed mass — the center of mass is at its midpoint.

Geometry (centered, symmetric case: phi = 0):
    R1 = L1/2      (pivot-1 to CM of rod 1)
    L1 = L1        (pivot-1 to pivot-2 = full length of rod 1)
    R2 = L2/2      (pivot-2 to CM of rod 2)
    I1 = m1*L1^2/12   (moment of inertia of rod 1 about its CM)
    I2 = m2*L2^2/12   (moment of inertia of rod 2 about its CM)

Equations of motion (verbatim from RigidDoublePendulumSim.ts evaluate(),
with phi=0 so sin(th1+phi)=sin(th1), cos(th1+phi)=cos(th1), etc.):

    D = 2*I2*L1^2*m2 + 2*I2*m1*R1^2 + L1^2*m2^2*R2^2 + 2*m1*m2*R1^2*R2^2
        + 2*I1*(I2 + m2*R2^2) - L1^2*m2^2*R2^2*cos(2*(th1-th2))

    ddth1 = -[ 2*g*m1*R1*(I2+m2*R2^2)*sin(th1)
               + L1*m2*(g*(2*I2+m2*R2^2)*sin(th1)
               + R2*(g*m2*R2*sin(th1-2*th2)
               + 2*(dth2^2*(I2+m2*R2^2)
               + dth1^2*L1*m2*R2*cos(th1-th2))*sin(th1-th2)))
             ] / D

    ddth2 = [ m2*R2*(-(g*(2*I1+L1^2*m2+2*m1*R1^2)*sin(th2))
               + L1*(g*m1*R1*sin(th2)          [sin(th2-phi)=sin(th2) when phi=0]
               + 2*dth1^2*(I1+L1^2*m2+m1*R1^2)*sin(th1-th2)
               + dth2^2*L1*m2*R2*sin(2*(th1-th2))
               + g*m1*R1*sin(2*th1-th2)        [sin(2*th1-th2+phi)=sin(2*th1-th2) when phi=0]
               + g*L1*m2*sin(2*th1-th2)))       [sin(2*th1-th2+2*phi)=sin(2*th1-th2) when phi=0]
             ] / D

State vector: [theta1, omega1, theta2, omega2]
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from dataclasses import dataclass, asdict
import sys, os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from .draw_utils import setup_dark_axis


@dataclass
class RigidDoublePendulumParams:
    L1: float       = 1.0    # length of rod 1 (m)
    L2: float       = 1.0    # length of rod 2 (m)
    m1: float       = 1.0    # mass of rod 1 (kg)
    m2: float       = 1.0    # mass of rod 2 (kg)
    g: float        = 9.8    # gravitational acceleration (m/s²)
    theta1_0: float = 0.5    # initial angle of rod 1 (rad)
    omega1_0: float = 0.0    # initial angular velocity of rod 1 (rad/s)
    theta2_0: float = 0.3    # initial angle of rod 2 (rad)
    omega2_0: float = 0.0    # initial angular velocity of rod 2 (rad/s)


def ode(t: float, y: list, p: RigidDoublePendulumParams):
    """
    Exact translation of RigidDoublePendulumSim.ts evaluate() for the
    centered case (phi=0): CM at midpoint of each rod, pivot at rod end.

    R1 = L1/2, R2 = L2/2
    I1 = m1*L1^2/12  (thin rod about CM)
    I2 = m2*L2^2/12
    phi = 0  (vector from pivot-1 to CM-1 is exactly vertical in body frame)
    """
    th1, dth1, th2, dth2 = y
    L1, L2, m1, m2, g = p.L1, p.L2, p.m1, p.m2, p.g

    # Derived geometry
    R1  = L1 / 2.0
    R2  = L2 / 2.0
    I1  = m1 * L1 * L1 / 12.0
    I2  = m2 * L2 * L2 / 12.0
    phi = 0.0   # centered: angle from r1 to l1 is zero

    # Common denominator (phi = 0 so cos(2*(th1-th2+phi)) = cos(2*(th1-th2)))
    denom = (2*I2*L1*L1*m2 + 2*I2*m1*R1*R1
             + L1*L1*m2*m2*R2*R2 + 2*m1*m2*R1*R1*R2*R2
             + 2*I1*(I2 + m2*R2*R2)
             - L1*L1*m2*m2*R2*R2*np.cos(2*(th1 - th2 + phi)))

    # ddth1 — from TS:
    # change[THETA1P] = -( 2*g*m1*R1*(I2+m2*R2^2)*sin(th1)
    #   + L1*m2*(g*(2*I2+m2*R2^2)*sin(th1+phi)
    #   + R2*(g*m2*R2*sin(th1-2*th2+phi)
    #   + 2*(dth2^2*(I2+m2*R2^2)
    #   + dth1^2*L1*m2*R2*cos(th1-th2+phi))*sin(th1-th2+phi)))
    # ) / denom
    # phi = 0:
    sin_th1        = np.sin(th1)
    sin_th1_m2th2  = np.sin(th1 - 2*th2)
    sin_diff       = np.sin(th1 - th2)
    cos_diff       = np.cos(th1 - th2)

    num1 = (2*g*m1*R1*(I2 + m2*R2*R2)*sin_th1
            + L1*m2*(g*(2*I2 + m2*R2*R2)*sin_th1
            + R2*(g*m2*R2*sin_th1_m2th2
            + 2*(dth2*dth2*(I2 + m2*R2*R2)
                 + dth1*dth1*L1*m2*R2*cos_diff)*sin_diff)))
    ddth1 = -num1 / denom

    # ddth2 — from TS:
    # change[THETA2P] = ( m2*R2*(-(g*(2*I1+L1^2*m2+2*m1*R1^2)*sin(th2))
    #   + L1*(g*m1*R1*sin(th2-phi)
    #   + 2*dth1^2*(I1+L1^2*m2+m1*R1^2)*sin(th1-th2+phi)
    #   + dth2^2*L1*m2*R2*sin(2*(th1-th2+phi))
    #   + g*m1*R1*sin(2*th1-th2+phi)
    #   + g*L1*m2*sin(2*th1-th2+2*phi)))
    # ) / denom
    # phi = 0:
    sin_th2          = np.sin(th2)
    sin_2th1_mth2    = np.sin(2*th1 - th2)
    sin_2diff        = np.sin(2*(th1 - th2))

    num2 = m2*R2*(-(g*(2*I1 + L1*L1*m2 + 2*m1*R1*R1)*sin_th2)
                  + L1*(g*m1*R1*sin_th2                      # sin(th2-0)=sin(th2)
                        + 2*dth1*dth1*(I1 + L1*L1*m2 + m1*R1*R1)*sin_diff
                        + dth2*dth2*L1*m2*R2*sin_2diff
                        + g*m1*R1*sin_2th1_mth2
                        + g*L1*m2*sin_2th1_mth2))
    ddth2 = num2 / denom

    return [dth1, ddth1, dth2, ddth2]


def simulate(
    params: RigidDoublePendulumParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Integrate using RK45. Returns (t, y) with y.shape = (4, N)."""
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode,
        (0, duration),
        [params.theta1_0, params.omega1_0, params.theta2_0, params.omega2_0],
        t_eval=t_eval,
        args=(params,),
        method="RK45",
        rtol=1e-8,
        atol=1e-10,
    )
    return sol.t, sol.y


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: RigidDoublePendulumParams,
    output_path: str,
    fps: int = 30,
) -> None:
    """Render animated rigid double pendulum. Each rod drawn as thick colored line."""
    th1, _, th2, _ = y
    L1, L2 = params.L1, params.L2

    # Pivot-1 at origin; end of rod 1 = pivot-2; end of rod 2 = tip
    x1 = L1 * np.sin(th1)
    y1 = -L1 * np.cos(th1)
    x2 = x1 + L2 * np.sin(th2)
    y2 = y1 - L2 * np.cos(th2)

    total_L = L1 + L2
    pad = total_L * 0.2
    lim = total_L + pad
    xlim = (-lim, lim)
    ylim = (-lim, lim * 0.25)

    fig, ax = plt.subplots(figsize=(8, 6))
    setup_dark_axis(fig, ax, xlim, ylim)

    # Fixed pivot
    ax.plot([0], [0], "o", color="white", ms=8, zorder=5)

    (rod1,)  = ax.plot([], [], "-", color="#a8dadc", lw=5, zorder=3, solid_capstyle="round")
    (rod2,)  = ax.plot([], [], "-", color="#f4a261", lw=5, zorder=3, solid_capstyle="round")
    (joint1,)= ax.plot([], [], "o", color="#e2e2e2", ms=9, zorder=4)
    (joint2,)= ax.plot([], [], "o", color="#e2e2e2", ms=9, zorder=4)

    def init():
        for obj in [rod1, rod2, joint1, joint2]:
            obj.set_data([], [])
        return rod1, rod2, joint1, joint2

    def update(frame):
        rod1.set_data([0, x1[frame]],         [0, y1[frame]])
        rod2.set_data([x1[frame], x2[frame]],  [y1[frame], y2[frame]])
        joint1.set_data([x1[frame]], [y1[frame]])
        joint2.set_data([x2[frame]], [y2[frame]])
        return rod1, rod2, joint1, joint2

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), init_func=init, interval=1000 / fps, blit=True
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=100)
    plt.close(fig)


def make_standalone_script(params: RigidDoublePendulumParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""
Rigid Double Pendulum — auto-generated simulation script.
Physics: Two rigid uniform rods (distributed mass, CM at midpoint).
R1=L1/2, R2=L2/2, I1=m1*L1^2/12, I2=m2*L2^2/12, phi=0 (centered).
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation

L1, L2       = {p["L1"]}, {p["L2"]}
m1, m2       = {p["m1"]}, {p["m2"]}
g            = {p["g"]}
theta1_0     = {p["theta1_0"]:.6f}
omega1_0     = {p["omega1_0"]:.6f}
theta2_0     = {p["theta2_0"]:.6f}
omega2_0     = {p["omega2_0"]:.6f}
duration     = {duration}

def ode(t, y):
    th1, dth1, th2, dth2 = y
    R1 = L1/2; R2 = L2/2
    I1 = m1*L1*L1/12; I2 = m2*L2*L2/12
    denom = (2*I2*L1*L1*m2 + 2*I2*m1*R1*R1
             + L1*L1*m2*m2*R2*R2 + 2*m1*m2*R1*R1*R2*R2
             + 2*I1*(I2 + m2*R2*R2)
             - L1*L1*m2*m2*R2*R2*np.cos(2*(th1-th2)))
    sin_th1 = np.sin(th1); sin_diff = np.sin(th1-th2); cos_diff = np.cos(th1-th2)
    num1 = (2*g*m1*R1*(I2+m2*R2*R2)*sin_th1
            + L1*m2*(g*(2*I2+m2*R2*R2)*sin_th1
            + R2*(g*m2*R2*np.sin(th1-2*th2)
            + 2*(dth2**2*(I2+m2*R2*R2)+dth1**2*L1*m2*R2*cos_diff)*sin_diff)))
    ddth1 = -num1 / denom
    sin_th2 = np.sin(th2); sin_2th1_mth2 = np.sin(2*th1-th2)
    num2 = m2*R2*(-(g*(2*I1+L1*L1*m2+2*m1*R1*R1)*sin_th2)
                  + L1*(g*m1*R1*sin_th2
                        + 2*dth1**2*(I1+L1*L1*m2+m1*R1*R1)*sin_diff
                        + dth2**2*L1*m2*R2*np.sin(2*(th1-th2))
                        + g*m1*R1*sin_2th1_mth2 + g*L1*m2*sin_2th1_mth2))
    ddth2 = num2 / denom
    return [dth1, ddth1, dth2, ddth2]

fps    = 30
t_eval = np.linspace(0, duration, int(duration*fps)+1)
sol    = solve_ivp(ode, (0, duration),
                   [theta1_0, omega1_0, theta2_0, omega2_0],
                   t_eval=t_eval, method="RK45", rtol=1e-8, atol=1e-10)
th1, th2 = sol.y[0], sol.y[2]
x1 = L1*np.sin(th1);      y1 = -L1*np.cos(th1)
x2 = x1+L2*np.sin(th2);   y2 = y1-L2*np.cos(th2)

lim = (L1+L2)*1.2
fig, ax = plt.subplots(figsize=(8,6), facecolor="#1a1a2e")
ax.set_facecolor("#16213e"); ax.set_xlim(-lim,lim); ax.set_ylim(-lim,lim*0.25)
ax.set_aspect("equal"); ax.axis("off")
ax.plot([0],[0],"o",color="white",ms=8,zorder=5)
rod1,   = ax.plot([],[],"-",color="#a8dadc",lw=5,zorder=3,solid_capstyle="round")
rod2,   = ax.plot([],[],"-",color="#f4a261",lw=5,zorder=3,solid_capstyle="round")
joint1, = ax.plot([],[],"o",color="#e2e2e2",ms=9,zorder=4)
joint2, = ax.plot([],[],"o",color="#e2e2e2",ms=9,zorder=4)

def update(f):
    rod1.set_data([0,x1[f]],[0,y1[f]])
    rod2.set_data([x1[f],x2[f]],[y1[f],y2[f]])
    joint1.set_data([x1[f]],[y1[f]]); joint2.set_data([x2[f]],[y2[f]])
    return rod1, rod2, joint1, joint2

ani = animation.FuncAnimation(fig, update, frames=len(sol.t), interval=1000/fps, blit=True)
ani.save("rigid_double_pendulum.mp4", writer=animation.FFMpegWriter(fps=fps,bitrate=1800), dpi=100)
plt.close(); print("Saved rigid_double_pendulum.mp4")
'''


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Rigid Double Pendulum Simulation")
    parser.add_argument("--L1",       type=float, default=1.0)
    parser.add_argument("--L2",       type=float, default=1.0)
    parser.add_argument("--m1",       type=float, default=1.0)
    parser.add_argument("--m2",       type=float, default=1.0)
    parser.add_argument("--g",        type=float, default=9.8)
    parser.add_argument("--theta1_0", type=float, default=0.5)
    parser.add_argument("--theta2_0", type=float, default=0.3)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output",   type=str,   default="rigid_double_pendulum.mp4")
    args = parser.parse_args()

    p = RigidDoublePendulumParams(
        L1=args.L1, L2=args.L2, m1=args.m1, m2=args.m2, g=args.g,
        theta1_0=args.theta1_0, theta2_0=args.theta2_0,
    )
    print(f"Simulating rigid double pendulum: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")


if __name__ == "__main__":
    main()
