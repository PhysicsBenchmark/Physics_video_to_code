"""
Wheel Wall Bounce - rolling wheel hits vertical wall, bounces under Routh impulse,
then slip-equilibrates and rolls to rest under rolling resistance.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle, Circle, Polygon
from matplotlib.lines import Line2D
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class WheelWallBounceParams:
    g: float = 9.8
    m: float = 1.0
    r_w: float = 0.10
    v_x_0: float = -1.50
    e_w: float = 0.70
    mu_w: float = 0.40
    mu_g: float = 0.30
    mu_r: float = 0.05
    x_wall: float = -1.50
    X_0: float = 1.80
    floor_y: float = 0.0


def _build(p: WheelWallBounceParams):
    g = p.g; m = p.m; r_w = p.r_w
    omega_0 = -p.v_x_0 / r_w
    I_w = 0.5 * m * r_w * r_w
    t_impact = (p.X_0 - r_w - p.x_wall) / abs(p.v_x_0)
    x_impact = p.x_wall + r_w
    theta_at_impact = omega_0 * t_impact

    Jn = -(1.0 + p.e_w) * m * p.v_x_0
    Jt_stk = r_w * omega_0 * m / 3.0
    cone = p.mu_w * abs(Jn)
    if abs(Jt_stk) <= cone:
        Jt = Jt_stk
    else:
        Jt = np.sign(Jt_stk) * cone
    vx_post = p.v_x_0 + Jn / m
    vy_post = 0.0 + Jt / m
    om_post = omega_0 - r_w * Jt / I_w

    s_0 = vx_post + om_post * r_w
    sgn_s = np.sign(s_0) if s_0 != 0 else 1.0
    a_vx_3 = -p.mu_g * g * sgn_s
    a_om_3 = -2.0 * p.mu_g * g / r_w * sgn_s
    t_slip = abs(s_0) / (3.0 * p.mu_g * g) if abs(s_0) > 1e-12 else 0.0
    vx_after_slip = vx_post + a_vx_3 * t_slip
    om_after_slip = om_post + a_om_3 * t_slip
    x_after_slip = x_impact + vx_post * t_slip + 0.5 * a_vx_3 * t_slip**2
    th_after_slip = theta_at_impact + om_post * t_slip + 0.5 * a_om_3 * t_slip**2
    t_slip_end_global = t_impact + t_slip

    a_vx_4 = -p.mu_r * g if vx_after_slip > 0 else (p.mu_r * g if vx_after_slip < 0 else 0.0)
    a_om_4 = -a_vx_4 / r_w
    t_stop_dur = abs(vx_after_slip / a_vx_4) if abs(a_vx_4) > 1e-12 else 0.0
    t_stop_global = t_slip_end_global + t_stop_dur
    x_stop = x_after_slip + vx_after_slip * t_stop_dur + 0.5 * a_vx_4 * t_stop_dur**2
    th_stop = th_after_slip + om_after_slip * t_stop_dur + 0.5 * a_om_4 * t_stop_dur**2

    return dict(
        omega_0=omega_0, I_w=I_w, t_impact=t_impact, x_impact=x_impact,
        theta_at_impact=theta_at_impact, vx_post=vx_post, vy_post=vy_post,
        om_post=om_post, a_vx_3=a_vx_3, a_om_3=a_om_3, t_slip=t_slip,
        vx_after_slip=vx_after_slip, om_after_slip=om_after_slip,
        x_after_slip=x_after_slip, th_after_slip=th_after_slip,
        t_slip_end_global=t_slip_end_global, a_vx_4=a_vx_4, a_om_4=a_om_4,
        t_stop_global=t_stop_global, x_stop=x_stop, th_stop=th_stop,
    )


def _state_at(t, p, info):
    if t <= info["t_impact"]:
        return (p.X_0 + p.v_x_0 * t, p.floor_y + p.r_w,
                p.v_x_0, 0.0, info["omega_0"], info["omega_0"] * t)
    if t <= info["t_slip_end_global"]:
        dt = t - info["t_impact"]
        return (info["x_impact"] + info["vx_post"] * dt + 0.5 * info["a_vx_3"] * dt * dt,
                p.floor_y + p.r_w,
                info["vx_post"] + info["a_vx_3"] * dt, 0.0,
                info["om_post"] + info["a_om_3"] * dt,
                info["theta_at_impact"] + info["om_post"] * dt + 0.5 * info["a_om_3"] * dt * dt)
    if t <= info["t_stop_global"]:
        dt = t - info["t_slip_end_global"]
        return (info["x_after_slip"] + info["vx_after_slip"] * dt + 0.5 * info["a_vx_4"] * dt * dt,
                p.floor_y + p.r_w,
                info["vx_after_slip"] + info["a_vx_4"] * dt, 0.0,
                info["om_after_slip"] + info["a_om_4"] * dt,
                info["th_after_slip"] + info["om_after_slip"] * dt + 0.5 * info["a_om_4"] * dt * dt)
    return (info["x_stop"], p.floor_y + p.r_w, 0.0, 0.0, 0.0, info["th_stop"])


def simulate(params: WheelWallBounceParams, duration: float = 12.0, fps: int = 30):
    info = _build(params)
    n = int(duration * fps) + 1
    t_eval = np.linspace(0.0, duration, n)
    y = np.zeros((6, n))
    for i, t in enumerate(t_eval):
        x, yc, vx, vy, om, th = _state_at(t, params, info)
        y[:, i] = [x, yc, vx, vy, om, th]
    return t_eval, y


def render_video(t, y, params: WheelWallBounceParams, output_path: str, fps: int = 30):
    p = params
    xs, ys, ths = y[0], y[1], y[5]
    fig_w, fig_h = 9.0, 5.0
    fig_aspect = fig_w / fig_h
    x_lo_d = p.x_wall - 0.20
    x_hi_d = p.X_0 + 0.40
    y_lo_d = p.floor_y - 0.25
    y_hi_d = max(p.floor_y + 1.10, p.floor_y + 2 * p.r_w + 0.50)
    dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_d / dy_d < fig_aspect:
        extra = (fig_aspect * dy_d - dx_d) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx_d / fig_aspect - dy_d) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")
    ax.add_patch(Polygon([(x_lo, y_lo), (x_hi, y_lo), (x_hi, p.floor_y), (x_lo, p.floor_y)],
                         facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.plot([x_lo, x_hi], [p.floor_y, p.floor_y], color="#adb5bd", lw=2.0, zorder=1)
    wall_thick = 0.06
    wall_height = y_hi - p.floor_y
    ax.add_patch(Rectangle((p.x_wall - wall_thick, p.floor_y),
                           wall_thick, wall_height,
                           facecolor="#adb5bd", edgecolor="#adb5bd", lw=0, zorder=2))
    wheel_patch = Circle((xs[0], ys[0]), p.r_w,
                         facecolor="#80c0ff", edgecolor="#ffffff", lw=1.5, zorder=5)
    ax.add_patch(wheel_patch)
    spin_markers = []
    for k in range(4):
        ang0 = ths[0] + k * (np.pi / 2.0)
        line = Line2D([xs[0], xs[0] + p.r_w * np.cos(ang0)],
                      [ys[0], ys[0] + p.r_w * np.sin(ang0)],
                      color="#e63946", lw=2.8, zorder=6)
        ax.add_line(line); spin_markers.append(line)

    def update(f):
        cx, cy, th = xs[f], ys[f], ths[f]
        wheel_patch.set_center((cx, cy))
        for k, line in enumerate(spin_markers):
            ang = th + k * (np.pi / 2.0)
            line.set_data([cx, cx + p.r_w * np.cos(ang)],
                          [cy, cy + p.r_w * np.sin(ang)])
        return (wheel_patch, *spin_markers)

    ani = animation.FuncAnimation(fig, update, frames=len(t), interval=1000.0 / fps, blit=False)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: WheelWallBounceParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Wheel wall bounce - auto-generated."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle, Circle, Polygon
from matplotlib.lines import Line2D

g={p["g"]}; m={p["m"]}; r_w={p["r_w"]}
v_x_0={p["v_x_0"]}; omega_0=-v_x_0/r_w
e_w={p["e_w"]}; mu_w={p["mu_w"]}; mu_g={p["mu_g"]}; mu_r={p["mu_r"]}
x_wall={p["x_wall"]}; X_0={p["X_0"]}; floor_y={p["floor_y"]}
duration={duration}; fps=30
I_w=0.5*m*r_w*r_w

t_impact=(X_0-r_w-x_wall)/abs(v_x_0)
x_impact=x_wall+r_w
theta_at_impact=omega_0*t_impact

Jn=-(1.0+e_w)*m*v_x_0
Jt_stk=r_w*omega_0*m/3.0
cone=mu_w*abs(Jn)
if abs(Jt_stk)<=cone:
    Jt=Jt_stk
else:
    Jt=np.sign(Jt_stk)*cone
vx_post=v_x_0+Jn/m
vy_post=0.0+Jt/m
om_post=omega_0-r_w*Jt/I_w

s_0=vx_post+om_post*r_w
sgn_s=np.sign(s_0) if s_0!=0 else 1.0
a_vx_3=-mu_g*g*sgn_s
a_om_3=-2.0*mu_g*g/r_w*sgn_s
t_slip=abs(s_0)/(3.0*mu_g*g) if abs(s_0)>1e-12 else 0.0
vx_after_slip=vx_post+a_vx_3*t_slip
om_after_slip=om_post+a_om_3*t_slip
x_after_slip=x_impact+vx_post*t_slip+0.5*a_vx_3*t_slip**2
th_after_slip=theta_at_impact+om_post*t_slip+0.5*a_om_3*t_slip**2
t_slip_end_global=t_impact+t_slip

a_vx_4=-mu_r*g if vx_after_slip>0 else (mu_r*g if vx_after_slip<0 else 0.0)
a_om_4=-a_vx_4/r_w
t_stop_dur=abs(vx_after_slip/a_vx_4) if abs(a_vx_4)>1e-12 else 0.0
t_stop_global=t_slip_end_global+t_stop_dur
x_stop=x_after_slip+vx_after_slip*t_stop_dur+0.5*a_vx_4*t_stop_dur**2
th_stop=th_after_slip+om_after_slip*t_stop_dur+0.5*a_om_4*t_stop_dur**2

def state_at(t):
    if t<=t_impact:
        return (X_0+v_x_0*t, floor_y+r_w, v_x_0, 0.0, omega_0, omega_0*t)
    if t<=t_slip_end_global:
        dt=t-t_impact
        return (x_impact+vx_post*dt+0.5*a_vx_3*dt*dt, floor_y+r_w,
                vx_post+a_vx_3*dt, 0.0,
                om_post+a_om_3*dt,
                theta_at_impact+om_post*dt+0.5*a_om_3*dt*dt)
    if t<=t_stop_global:
        dt=t-t_slip_end_global
        return (x_after_slip+vx_after_slip*dt+0.5*a_vx_4*dt*dt, floor_y+r_w,
                vx_after_slip+a_vx_4*dt, 0.0,
                om_after_slip+a_om_4*dt,
                th_after_slip+om_after_slip*dt+0.5*a_om_4*dt*dt)
    return (x_stop, floor_y+r_w, 0.0, 0.0, 0.0, th_stop)

n_frames=int(duration*fps)+1
t_grid=np.linspace(0.0,duration,n_frames)
xs=np.empty(n_frames); ys=np.empty(n_frames); ths=np.empty(n_frames)
for i,t in enumerate(t_grid):
    x,yc,_,_,_,th=state_at(t)
    xs[i]=x; ys[i]=yc; ths[i]=th

fig_w,fig_h=9.0,5.0; fa=fig_w/fig_h
x_lo_d=x_wall-0.20; x_hi_d=X_0+0.40
y_lo_d=floor_y-0.25
y_hi_d=max(floor_y+1.10, floor_y+2*r_w+0.50)
dx_d,dy_d=x_hi_d-x_lo_d,y_hi_d-y_lo_d
if dx_d/dy_d<fa:
    e=(fa*dy_d-dx_d)/2.0; x_lo,x_hi=x_lo_d-e,x_hi_d+e; y_lo,y_hi=y_lo_d,y_hi_d
else:
    e=(dx_d/fa-dy_d)/2.0; x_lo,x_hi=x_lo_d,x_hi_d; y_lo,y_hi=y_lo_d-e,y_hi_d+e

fig=plt.figure(figsize=(fig_w,fig_h),facecolor="#1a1a2e")
ax=fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi); ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(Polygon([(x_lo,y_lo),(x_hi,y_lo),(x_hi,floor_y),(x_lo,floor_y)],
                     facecolor="#4a4e69",edgecolor="none",zorder=0))
ax.plot([x_lo,x_hi],[floor_y,floor_y],color="#adb5bd",lw=2.0,zorder=1)
wall_thick=0.06; wall_height=y_hi-floor_y
ax.add_patch(Rectangle((x_wall-wall_thick,floor_y),wall_thick,wall_height,
                       facecolor="#adb5bd",edgecolor="#adb5bd",lw=0,zorder=2))
wheel_patch=Circle((xs[0],ys[0]),r_w,facecolor="#80c0ff",edgecolor="#ffffff",lw=1.5,zorder=5)
ax.add_patch(wheel_patch)
spin_markers=[]
for k in range(4):
    ang0=ths[0]+k*(np.pi/2.0)
    line=Line2D([xs[0],xs[0]+r_w*np.cos(ang0)],[ys[0],ys[0]+r_w*np.sin(ang0)],
                color="#e63946",lw=2.8,zorder=6)
    ax.add_line(line); spin_markers.append(line)

def update(f):
    cx,cy,th=xs[f],ys[f],ths[f]
    wheel_patch.set_center((cx,cy))
    for k,line in enumerate(spin_markers):
        ang=th+k*(np.pi/2.0)
        line.set_data([cx,cx+r_w*np.cos(ang)],[cy,cy+r_w*np.sin(ang)])
    return (wheel_patch,*spin_markers)

ani=animation.FuncAnimation(fig,update,frames=n_frames,interval=1000.0/fps,blit=False)
ani.save("video.mp4",writer=animation.FFMpegWriter(fps=fps,bitrate=1800),dpi=120)
plt.close(); print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    for fld, dflt in asdict(WheelWallBounceParams()).items():
        parser.add_argument(f"--{fld}", type=float, default=dflt)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="video.mp4")
    args = parser.parse_args()
    p = WheelWallBounceParams(**{k: getattr(args, k) for k in asdict(WheelWallBounceParams()).keys()})
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
