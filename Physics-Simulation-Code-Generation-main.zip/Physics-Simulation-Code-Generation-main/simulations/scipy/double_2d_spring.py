"""
Double 2D Spring Simulation
============================
Faithfully translated from myphysicslab/src/sims/springs/Double2DSpringSim.ts

Physical Setup:
    - Fixed top anchor at (ax1, ay1)
    - Spring 1 connects anchor → bob1
    - Spring 2 connects bob1 → bob2
    No third spring (only 2 springs as in the TS source).

Equations of Motion (from Double2DSpringSim.ts evaluate()):
    U1x' = V1x
    U1y' = V1y
    V1x' = (f12x + f21x - b*V1x) / m1
    V1y' = -g + (f12y + f21y - b*V1y) / m1
    U2x' = V2x
    U2y' = V2y
    V2x' = (f22x - b*V2x) / m2
    V2y' = -g + (f22y - b*V2y) / m2

where:
    Spring 1 forces: top anchor → bob1
        xx1 = U1x - Tx,  yy1 = U1y - Ty
        len1 = sqrt(xx1^2 + yy1^2),  L1 = len1 - R1
        sin(th1) = xx1/len1,  cos(th1) = -yy1/len1
        f12 (force on bob1 from spring1): spring pulls bob1 toward anchor
            f12x = -k1*L1*sin(th1),  f12y = k1*L1*cos(th1)

    Spring 2 forces: bob1 → bob2
        xx2 = U2x - U1x,  yy2 = U2y - U1y
        len2 = sqrt(xx2^2 + yy2^2),  L2 = len2 - R2
        sin(th2) = xx2/len2,  cos(th2) = -yy2/len2
        f21 (force on bob1 from spring2): spring2 pulls bob1 toward bob2
            f21x = k2*L2*sin(th2),   f21y = -k2*L2*cos(th2)
              → Wait: in TS, forces2 = spring2.calculateForces()
                forces2[0] is force on bob1 (start of spring2),
                forces2[1] is force on bob2 (end of spring2)
              → f21 = forces2[0]: spring pulls bob1 toward bob2
                f22 = forces2[1]: spring pulls bob2 toward bob1

    Explicitly (using the same convention as spring1 for direction):
        f21x = -k2*L2*sin(th2_reversed)   where th2 is angle from bob2's perspective
             = k2*L2*sin(th2) ... need to use TS convention consistently
        Actually from TS: force on bob1 from spring2 pushes bob1 toward bob2:
            f21 = +k2*L2*(unit vector from bob1 to bob2)
                = k2*L2*(xx2/len2, yy2/len2)   [not using the th convention]
        Force on bob2 from spring2 = opposite:
            f22 = -k2*L2*(xx2/len2, yy2/len2)
                = k2*L2*(unit vector from bob2 to bob1)

State vector: [x1, y1, x2, y2, vx1, vy1, vx2, vy2]
Variables layout mirrors TS: U1x,U1y,U2x,U2y,V1x,V1y,V2x,V2y
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from .draw_utils import setup_dark_axis, spring_path


@dataclass
class Double2DSpringParams:
    k: float = 3.0       # spring stiffness for both springs (N/m)
    m1: float = 0.5      # mass of bob1 (kg)
    m2: float = 0.5      # mass of bob2 (kg)
    b: float = 0.1       # damping coefficient (kg/s)
    g: float = 9.8       # gravitational acceleration (m/s^2)
    R: float = 1.5       # rest length for both springs (m)
    ax1: float = 0.0     # anchor x position (m)
    ay1: float = 4.0     # anchor y position (m)
    x1_0: float = 0.5    # initial bob1 x position (m)
    y1_0: float = 2.0    # initial bob1 y position (m)
    x2_0: float = 2.5    # initial bob2 x position (m)
    y2_0: float = 2.0    # initial bob2 y position (m)
    vx1_0: float = 0.0   # initial bob1 x velocity (m/s)
    vy1_0: float = 0.0   # initial bob1 y velocity (m/s)
    vx2_0: float = 0.0   # initial bob2 x velocity (m/s)
    vy2_0: float = 0.0   # initial bob2 y velocity (m/s)


def _spring_force(x_start, y_start, x_end, y_end, k, R):
    """
    Compute force on the END point of a spring connecting start→end.
    The force on the end is: F_end = -k*(dist-R)*(unit vector from start to end)
                                    pointing end back toward start when stretched.
    Force on start is equal and opposite: F_start = +k*(dist-R)*(unit from start to end).
    Returns (fx_on_start, fy_on_start, fx_on_end, fy_on_end).
    Convention from Double2DSpringSim.ts: spring pulls both endpoints toward each other.
    """
    dx = x_end - x_start
    dy = y_end - y_start
    dist = np.hypot(dx, dy)
    if dist < 1e-10:
        return 0.0, 0.0, 0.0, 0.0
    stretch = dist - R
    # Force magnitude = k * stretch (attractive when positive stretch)
    # Unit vector from start to end: (dx/dist, dy/dist)
    # Force on start: k*stretch*(toward end) = k*stretch*(dx/dist, dy/dist)
    # Force on end: k*stretch*(toward start) = -k*stretch*(dx/dist, dy/dist)
    fx_unit = dx / dist
    fy_unit = dy / dist
    fx_on_start = k * stretch * fx_unit
    fy_on_start = k * stretch * fy_unit
    fx_on_end   = -k * stretch * fx_unit
    fy_on_end   = -k * stretch * fy_unit
    return fx_on_start, fy_on_start, fx_on_end, fy_on_end


def ode(t: float, state: list, p: Double2DSpringParams):
    """
    Exact translation of Double2DSpringSim.ts evaluate():
        forces1 = spring1.calculateForces()  [anchor -> bob1]
        f12 = forces1[1]  (force on bob1 from spring1)
        forces2 = spring2.calculateForces()  [bob1 -> bob2]
        f21 = forces2[0]  (force on bob1 from spring2)
        f22 = forces2[1]  (force on bob2 from spring2)

        V1x' = (f12.x + f21.x - b*V1x) / m1
        V1y' = -g + (f12.y + f21.y - b*V1y) / m1
        V2x' = (f22.x - b*V2x) / m2
        V2y' = -g + (f22.y - b*V2y) / m2
    """
    x1, y1, x2, y2, vx1, vy1, vx2, vy2 = state

    # Spring 1: anchor -> bob1
    _, _, f12x, f12y = _spring_force(p.ax1, p.ay1, x1, y1, p.k, p.R)
    # Spring 2: bob1 -> bob2
    f21x, f21y, f22x, f22y = _spring_force(x1, y1, x2, y2, p.k, p.R)

    dx1 = vx1
    dy1 = vy1
    dx2 = vx2
    dy2 = vy2
    dvx1 = (f12x + f21x - p.b * vx1) / p.m1
    dvy1 = -p.g + (f12y + f21y - p.b * vy1) / p.m1
    dvx2 = (f22x - p.b * vx2) / p.m2
    dvy2 = -p.g + (f22y - p.b * vy2) / p.m2

    return [dx1, dy1, dx2, dy2, dvx1, dvy1, dvx2, dvy2]


def simulate(
    params: Double2DSpringParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Integrate using RK45. Returns (t, y) with y.shape = (8, N)."""
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    y0 = [
        params.x1_0, params.y1_0, params.x2_0, params.y2_0,
        params.vx1_0, params.vy1_0, params.vx2_0, params.vy2_0,
    ]
    sol = solve_ivp(
        ode,
        (0, duration),
        y0,
        t_eval=t_eval,
        args=(params,),
        method="RK45",
        rtol=1e-8,
        atol=1e-10,
    )
    return sol.t, sol.y


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: Double2DSpringParams,
    output_path: str,
    fps: int = 30,
) -> None:
    """
    Render double 2D spring system:
      [anchor square] ~~~spring1~~~ [bob1 circle] ~~~spring2~~~ [bob2 circle]
    """
    x1_arr = y[0]
    y1_arr = y[1]
    x2_arr = y[2]
    y2_arr = y[3]

    # Determine view bounds
    all_x = np.concatenate([[params.ax1], x1_arr, x2_arr])
    all_y = np.concatenate([[params.ay1], y1_arr, y2_arr])
    margin = max(params.R * 1.5, 1.5)
    xlim = (all_x.min() - margin, all_x.max() + margin)
    ylim = (all_y.min() - margin, all_y.max() + margin)

    bob_r = 0.18

    fig, ax = plt.subplots(figsize=(8, 6))
    setup_dark_axis(fig, ax, xlim, ylim)

    # Static: anchor square
    anchor_sz = 0.22
    anchor_patch = patches.Rectangle(
        (params.ax1 - anchor_sz / 2, params.ay1 - anchor_sz / 2),
        anchor_sz, anchor_sz,
        facecolor="#4a4e69", edgecolor="#adb5bd", lw=1.5, zorder=4,
    )
    ax.add_patch(anchor_patch)

    # Animated elements
    (spring1_line,) = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
    (spring2_line,) = ax.plot([], [], "-", color="#90e0ef", lw=2.5, zorder=3)
    bob1_circle = plt.Circle(
        (params.x1_0, params.y1_0), bob_r,
        facecolor="#e63946", edgecolor="white", linewidth=1.5, zorder=5,
    )
    bob2_circle = plt.Circle(
        (params.x2_0, params.y2_0), bob_r,
        facecolor="#f4a261", edgecolor="white", linewidth=1.5, zorder=5,
    )
    ax.add_patch(bob1_circle)
    ax.add_patch(bob2_circle)

    # Labels for bobs

    def init():
        spring1_line.set_data([], [])
        spring2_line.set_data([], [])
        return (spring1_line, spring2_line)

    def update(frame):
        b1x = x1_arr[frame]
        b1y = y1_arr[frame]
        b2x = x2_arr[frame]
        b2y = y2_arr[frame]

        bob1_circle.set_center((b1x, b1y))
        bob2_circle.set_center((b2x, b2y))

        sx1, sy1 = spring_path(params.ax1, params.ay1, b1x, b1y, n_coils=7, coil_radius=0.12)
        spring1_line.set_data(sx1, sy1)

        sx2, sy2 = spring_path(b1x, b1y, b2x, b2y, n_coils=7, coil_radius=0.12)
        spring2_line.set_data(sx2, sy2)

        return (spring1_line, spring2_line, bob1_circle, bob2_circle)

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), init_func=init, interval=1000 / fps, blit=False
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=100)
    plt.close(fig)


def make_standalone_script(params: Double2DSpringParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""
Double 2D Spring — auto-generated simulation script.
Physics (Double2DSpringSim.ts):
    Spring 1: anchor({p["ax1"]},{p["ay1"]}) -> bob1,  Spring 2: bob1 -> bob2
    V1x' = (f12x + f21x - b*V1x) / m1
    V1y' = -g + (f12y + f21y - b*V1y) / m1
    V2x' = (f22x - b*V2x) / m2
    V2y' = -g + (f22y - b*V2y) / m2
Parameters: k={p["k"]} N/m, m1={p["m1"]} kg, m2={p["m2"]} kg, b={p["b"]} kg/s
  g={p["g"]} m/s^2, R={p["R"]} m (rest length)
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

k, m1, m2, b, g = {p["k"]}, {p["m1"]}, {p["m2"]}, {p["b"]}, {p["g"]}
R = {p["R"]}
ax1, ay1 = {p["ax1"]}, {p["ay1"]}
x1_0,y1_0,x2_0,y2_0 = {p["x1_0"]:.6f},{p["y1_0"]:.6f},{p["x2_0"]:.6f},{p["y2_0"]:.6f}
vx1_0,vy1_0,vx2_0,vy2_0 = {p["vx1_0"]:.6f},{p["vy1_0"]:.6f},{p["vx2_0"]:.6f},{p["vy2_0"]:.6f}
duration = {duration}

def spring_force(xs, ys, xe, ye, k, R):
    dx, dy = xe-xs, ye-ys
    dist = np.hypot(dx, dy)
    if dist < 1e-10: return 0,0,0,0
    st = dist - R; ux, uy = dx/dist, dy/dist
    return k*st*ux, k*st*uy, -k*st*ux, -k*st*uy

def ode(t, s):
    x1,y1,x2,y2,vx1,vy1,vx2,vy2 = s
    _,_,f12x,f12y = spring_force(ax1,ay1,x1,y1,k,R)
    f21x,f21y,f22x,f22y = spring_force(x1,y1,x2,y2,k,R)
    return [vx1,vy1,vx2,vy2,
            (f12x+f21x-b*vx1)/m1, -g+(f12y+f21y-b*vy1)/m1,
            (f22x-b*vx2)/m2, -g+(f22y-b*vy2)/m2]

fps = 30
t_eval = np.linspace(0,duration,int(duration*fps)+1)
sol = solve_ivp(ode,(0,duration),[x1_0,y1_0,x2_0,y2_0,vx1_0,vy1_0,vx2_0,vy2_0],
                t_eval=t_eval,method="RK45",rtol=1e-8,atol=1e-10)
x1a,y1a,x2a,y2a = sol.y[0],sol.y[1],sol.y[2],sol.y[3]

all_x=np.concatenate([[ax1],x1a,x2a]); all_y=np.concatenate([[ay1],y1a,y2a])
mg=1.5
xlim=(all_x.min()-mg,all_x.max()+mg); ylim=(all_y.min()-mg,all_y.max()+mg)

fig,ax=plt.subplots(figsize=(8,6),facecolor="#1a1a2e")
ax.set_facecolor("#16213e"); ax.set_xlim(xlim); ax.set_ylim(ylim)
ax.set_aspect("equal"); ax.axis("off")

asq=0.22
ax.add_patch(patches.Rectangle((ax1-asq/2,ay1-asq/2),asq,asq,
    facecolor="#4a4e69",edgecolor="#adb5bd",lw=1.5,zorder=4))
sp1,=ax.plot([],[],"-",color="#a8dadc",lw=2.5,zorder=3)
sp2,=ax.plot([],[],"-",color="#90e0ef",lw=2.5,zorder=3)
b1c=plt.Circle((x1_0,y1_0),0.18,facecolor="#e63946",edgecolor="white",lw=1.5,zorder=5)
b2c=plt.Circle((x2_0,y2_0),0.18,facecolor="#f4a261",edgecolor="white",lw=1.5,zorder=5)
ax.add_patch(b1c); ax.add_patch(b2c)

def spfn(x1,y1,x2,y2,n=7,r=0.12):
    dx,dy=x2-x1,y2-y1; L=np.hypot(dx,dy)
    if L<1e-10: return np.array([x1,x2]),np.array([y1,y2])
    ux,uy=dx/L,dy/L; nx,ny=-uy,ux
    n_pts=n*20+2; t=np.linspace(0,1,n_pts); mg2=0.08
    env=np.where((t<mg2)|(t>1-mg2),0,np.sin(n*2*np.pi*(t-mg2)/(1-2*mg2)))
    return x1+t*dx+r*env*nx, y1+t*dy+r*env*ny

def update(f):
    b1x,b1y=x1a[f],y1a[f]; b2x,b2y=x2a[f],y2a[f]
    b1c.set_center((b1x,b1y)); b2c.set_center((b2x,b2y))
    s1x,s1y=spfn(ax1,ay1,b1x,b1y); sp1.set_data(s1x,s1y)
    s2x,s2y=spfn(b1x,b1y,b2x,b2y); sp2.set_data(s2x,s2y)
    return (sp1,sp2,b1c,b2c)

ani=animation.FuncAnimation(fig,update,frames=len(sol.t),interval=1000/fps,blit=False)
ani.save("double_2d_spring.mp4",writer=animation.FFMpegWriter(fps=fps,bitrate=1800),dpi=100)
plt.close(); print("Saved double_2d_spring.mp4")
'''


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Double 2D Spring Simulation")
    parser.add_argument("--k",    type=float, default=3.0)
    parser.add_argument("--m1",   type=float, default=0.5)
    parser.add_argument("--m2",   type=float, default=0.5)
    parser.add_argument("--b",    type=float, default=0.1)
    parser.add_argument("--g",    type=float, default=9.8)
    parser.add_argument("--R",    type=float, default=1.5)
    parser.add_argument("--ax1",  type=float, default=0.0)
    parser.add_argument("--ay1",  type=float, default=4.0)
    parser.add_argument("--x1_0", type=float, default=0.5)
    parser.add_argument("--y1_0", type=float, default=2.0)
    parser.add_argument("--x2_0", type=float, default=2.5)
    parser.add_argument("--y2_0", type=float, default=2.0)
    parser.add_argument("--vx1_0", type=float, default=0.0)
    parser.add_argument("--vy1_0", type=float, default=0.0)
    parser.add_argument("--vx2_0", type=float, default=0.0)
    parser.add_argument("--vy2_0", type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output",   type=str,   default="double_2d_spring.mp4")
    args = parser.parse_args()
    p = Double2DSpringParams(
        k=args.k, m1=args.m1, m2=args.m2, b=args.b, g=args.g, R=args.R,
        ax1=args.ax1, ay1=args.ay1,
        x1_0=args.x1_0, y1_0=args.y1_0,
        x2_0=args.x2_0, y2_0=args.y2_0,
        vx1_0=args.vx1_0, vy1_0=args.vy1_0,
        vx2_0=args.vx2_0, vy2_0=args.vy2_0,
    )
    print(f"Simulating double 2D spring: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")


if __name__ == "__main__":
    main()
