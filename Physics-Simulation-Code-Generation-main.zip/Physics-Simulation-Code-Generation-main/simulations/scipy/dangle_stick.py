"""
Dangle Stick Simulation
========================
Faithfully translated from myphysicslab/src/sims/springs/DangleStickSim.ts

Physical Setup:
    A spring attached to a fixed point at the origin, with mass m1 at the spring's
    lower end. A rigid stick of length L hangs from that mass, with mass m2 at its tip.

    theta = angle of spring from vertical (down = 0, positive = counter-clockwise)
    r     = length of spring (variable, can stretch)
    phi   = angle of stick from vertical (down = 0, positive = counter-clockwise)

    Origin fixed at (0, 0). Spring hangs downward; stick hangs from spring's end.

Positions:
    bob1 (spring end, mass m1):  (r*sin(theta), -r*cos(theta))
    bob2 (stick end, mass m2):   bob1 + (L*sin(phi), -L*cos(phi))

Equations of Motion (exact from DangleStickSim.ts evaluate()):

    theta'' = (-4*m1*(m1+m2)*r'*theta'
               + 2*m1*m2*L*phi'^2*sin(phi-theta)
               - 2*g*m1*(m1+m2)*sin(theta)
               + k*m2*(b-r)*sin(2*(theta-phi)))
              / (2*m1*(m1+m2)*r)

    r'' = (2*b_rest*k*m1
           + b_rest*k*m2
           - 2*k*m1*r
           - k*m2*r
           - k*m2*(b_rest-r)*cos(2*(theta-phi))
           + 2*L*m1*m2*cos(phi-theta)*phi'^2)
          / (2*m1*(m1+m2))
          + r*theta'^2
          + g*cos(theta)

    phi'' = k*(b_rest-r)*sin(phi-theta) / (L*m1)

State vector: [theta, theta_dot, r, r_dot, phi, phi_dot]
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from .draw_utils import setup_dark_axis, spring_path


@dataclass
class DangleStickParams:
    m1: float = 0.5         # mass at spring end (kg)
    m2: float = 0.5         # mass at stick tip (kg)
    L: float = 1.0          # stick length (m)
    k: float = 3.0          # spring stiffness (N/m)
    b_rest: float = 1.0     # spring rest length (m)
    g: float = 9.8          # gravitational acceleration (m/s^2)
    theta0: float = 0.5     # initial spring angle from vertical (rad)
    theta_dot0: float = 0.0 # initial spring angular velocity (rad/s)
    r0: float = 1.2         # initial spring length (m)
    r_dot0: float = 0.0     # initial spring length velocity (m/s)
    phi0: float = 0.2       # initial stick angle from vertical (rad)
    phi_dot0: float = 0.0   # initial stick angular velocity (rad/s)


def ode(t: float, y: list, p: DangleStickParams):
    """
    Exact translation of DangleStickSim.ts evaluate():
        change[THETA] = vars[THETAP]
        change[R] = vars[RP]
        change[PHI] = vars[PHIP]
        change[THETAP] = sum/(2*m1*(m1+m2)*r)
        change[RP]     = sum/(2*m1*(m1+m2)) + r*theta'^2 + g*cos(theta)
        change[PHIP]   = k*(b-r)*sin(phi-theta)/(L*m1)
    """
    theta, theta_dot, r, r_dot, phi, phi_dot = y
    m1, m2, L, k, b = p.m1, p.m2, p.L, p.k, p.b_rest
    g = p.g

    # theta'' numerator:
    # -4*m1*(m1+m2)*r_dot*theta_dot
    # + 2*m1*m2*L*phi_dot^2*sin(phi-theta)
    # - 2*g*m1*(m1+m2)*sin(theta)
    # + k*m2*(b-r)*sin(2*(theta-phi))
    theta_sum = (
        -4.0 * m1 * (m1 + m2) * r_dot * theta_dot
        + 2.0 * m1 * m2 * L * phi_dot**2 * np.sin(phi - theta)
        - 2.0 * g * m1 * (m1 + m2) * np.sin(theta)
        + k * m2 * (b - r) * np.sin(2.0 * (theta - phi))
    )
    # Avoid division by zero when r is near zero
    if abs(r) < 1e-10:
        dtheta_dot = 0.0
    else:
        dtheta_dot = theta_sum / (2.0 * m1 * (m1 + m2) * r)

    # r'' = r_sum / (2*m1*(m1+m2)) + r*theta_dot^2 + g*cos(theta)
    # r_sum = 2*b*k*m1 + b*k*m2 - 2*k*m1*r - k*m2*r
    #         - k*m2*(b-r)*cos(2*(theta-phi))
    #         + 2*L*m1*m2*cos(phi-theta)*phi_dot^2
    r_sum = (
        2.0 * b * k * m1
        + b * k * m2
        - 2.0 * k * m1 * r
        - k * m2 * r
        - k * m2 * (b - r) * np.cos(2.0 * (theta - phi))
        + 2.0 * L * m1 * m2 * np.cos(phi - theta) * phi_dot**2
    )
    dr_dot = (r_sum / (2.0 * m1 * (m1 + m2))
              + r * theta_dot**2
              + g * np.cos(theta))

    # phi'' = k*(b-r)*sin(phi-theta)/(L*m1)
    dphi_dot = k * (b - r) * np.sin(phi - theta) / (L * m1)

    return [theta_dot, dtheta_dot, r_dot, dr_dot, phi_dot, dphi_dot]


def simulate(
    params: DangleStickParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Integrate using RK45. Returns (t, y) with y.shape = (6, N)."""
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    y0 = [
        params.theta0, params.theta_dot0,
        params.r0, params.r_dot0,
        params.phi0, params.phi_dot0,
    ]
    sol = solve_ivp(
        ode,
        (0, duration),
        y0,
        t_eval=t_eval,
        args=(params,),
        method="RK45",
        rtol=1e-8,
        atol=1e-10,
    )
    return sol.t, sol.y


def _positions(y: np.ndarray, params: DangleStickParams):
    """Compute bob1 and bob2 positions from state array."""
    theta = y[0]
    r = y[2]
    phi = y[4]
    # bob1 = (r*sin(theta), -r*cos(theta))
    x1 = r * np.sin(theta)
    y1 = -r * np.cos(theta)
    # bob2 = bob1 + (L*sin(phi), -L*cos(phi))
    x2 = x1 + params.L * np.sin(phi)
    y2 = y1 - params.L * np.cos(phi)
    return x1, y1, x2, y2


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: DangleStickParams,
    output_path: str,
    fps: int = 30,
) -> None:
    """
    Render dangle-stick system:
      Fixed origin (0,0) → [spring zigzag] → [bob1 circle] → [stick line] → [bob2 circle]
    """
    x1_arr, y1_arr, x2_arr, y2_arr = _positions(y, params)

    # Determine view bounds
    all_x = np.concatenate([[0.0], x1_arr, x2_arr])
    all_y = np.concatenate([[0.0], y1_arr, y2_arr])
    margin = max(params.b_rest * 1.5, params.L * 1.5, 1.5)
    xlim = (all_x.min() - margin, all_x.max() + margin)
    ylim = (all_y.min() - margin, all_y.max() + margin)

    bob_r = 0.15

    fig, ax = plt.subplots(figsize=(8, 6))
    setup_dark_axis(fig, ax, xlim, ylim)

    # Static: fixed anchor square at origin
    anchor_sz = 0.22
    anchor_patch = patches.Rectangle(
        (-anchor_sz / 2, -anchor_sz / 2),
        anchor_sz, anchor_sz,
        facecolor="#4a4e69", edgecolor="#adb5bd", lw=1.5, zorder=4,
    )
    ax.add_patch(anchor_patch)

    # Animated elements
    (spring_line,) = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
    (stick_line,)  = ax.plot([], [], "-", color="#e9c46a", lw=3.0, zorder=3)
    bob1_circle = plt.Circle(
        (x1_arr[0], y1_arr[0]), bob_r,
        facecolor="#e63946", edgecolor="white", linewidth=1.5, zorder=5,
    )
    bob2_circle = plt.Circle(
        (x2_arr[0], y2_arr[0]), bob_r,
        facecolor="#f4a261", edgecolor="white", linewidth=1.5, zorder=5,
    )
    ax.add_patch(bob1_circle)
    ax.add_patch(bob2_circle)

    def init():
        spring_line.set_data([], [])
        stick_line.set_data([], [])
        return (spring_line, stick_line)

    def update(frame):
        b1x = x1_arr[frame]
        b1y = y1_arr[frame]
        b2x = x2_arr[frame]
        b2y = y2_arr[frame]

        bob1_circle.set_center((b1x, b1y))
        bob2_circle.set_center((b2x, b2y))

        # Spring from origin (0,0) to bob1
        sx, sy = spring_path(0.0, 0.0, b1x, b1y, n_coils=8, coil_radius=0.12)
        spring_line.set_data(sx, sy)

        # Stick is a straight rod from bob1 to bob2
        stick_line.set_data([b1x, b2x], [b1y, b2y])

        return (spring_line, stick_line, bob1_circle, bob2_circle)

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), init_func=init, interval=1000 / fps, blit=False
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=100)
    plt.close(fig)


def make_standalone_script(params: DangleStickParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""
Dangle Stick — auto-generated simulation script.
Physics (DangleStickSim.ts):
    theta'' = (-4*m1*(m1+m2)*r'*theta' + 2*m1*m2*L*phi'^2*sin(phi-theta)
               - 2*g*m1*(m1+m2)*sin(theta) + k*m2*(b-r)*sin(2*(theta-phi)))
              / (2*m1*(m1+m2)*r)
    r'' = (2*b*k*m1 + b*k*m2 - 2*k*m1*r - k*m2*r - k*m2*(b-r)*cos(2*(theta-phi))
           + 2*L*m1*m2*cos(phi-theta)*phi'^2) / (2*m1*(m1+m2)) + r*theta'^2 + g*cos(theta)
    phi'' = k*(b-r)*sin(phi-theta)/(L*m1)
Parameters: m1={p["m1"]} kg, m2={p["m2"]} kg, L={p["L"]} m, k={p["k"]} N/m
  b_rest={p["b_rest"]} m, g={p["g"]} m/s^2
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

m1, m2, L, k, b = {p["m1"]}, {p["m2"]}, {p["L"]}, {p["k"]}, {p["b_rest"]}
g = {p["g"]}
theta0, theta_dot0 = {p["theta0"]:.6f}, {p["theta_dot0"]:.6f}
r0, r_dot0 = {p["r0"]:.6f}, {p["r_dot0"]:.6f}
phi0, phi_dot0 = {p["phi0"]:.6f}, {p["phi_dot0"]:.6f}
duration = {duration}

def ode(t, y):
    theta, theta_dot, r, r_dot, phi, phi_dot = y
    tsum = (-4*m1*(m1+m2)*r_dot*theta_dot
            + 2*m1*m2*L*phi_dot**2*np.sin(phi-theta)
            - 2*g*m1*(m1+m2)*np.sin(theta)
            + k*m2*(b-r)*np.sin(2*(theta-phi)))
    dtheta_dot = tsum/(2*m1*(m1+m2)*r) if abs(r)>1e-10 else 0.0
    rsum = (2*b*k*m1 + b*k*m2 - 2*k*m1*r - k*m2*r
            - k*m2*(b-r)*np.cos(2*(theta-phi))
            + 2*L*m1*m2*np.cos(phi-theta)*phi_dot**2)
    dr_dot = rsum/(2*m1*(m1+m2)) + r*theta_dot**2 + g*np.cos(theta)
    dphi_dot = k*(b-r)*np.sin(phi-theta)/(L*m1)
    return [theta_dot, dtheta_dot, r_dot, dr_dot, phi_dot, dphi_dot]

fps = 30
t_eval = np.linspace(0, duration, int(duration*fps)+1)
sol = solve_ivp(ode, (0, duration),
                [theta0, theta_dot0, r0, r_dot0, phi0, phi_dot0],
                t_eval=t_eval, method="RK45", rtol=1e-8, atol=1e-10)
theta_a, r_a, phi_a = sol.y[0], sol.y[2], sol.y[4]
x1a = r_a*np.sin(theta_a); y1a = -r_a*np.cos(theta_a)
x2a = x1a + L*np.sin(phi_a); y2a = y1a - L*np.cos(phi_a)

all_x = np.concatenate([[0], x1a, x2a]); all_y = np.concatenate([[0], y1a, y2a])
mg = max(b*1.5, L*1.5, 1.5)
xlim=(all_x.min()-mg, all_x.max()+mg); ylim=(all_y.min()-mg, all_y.max()+mg)

fig, axv = plt.subplots(figsize=(8,6), facecolor="#1a1a2e")
axv.set_facecolor("#16213e"); axv.set_xlim(xlim); axv.set_ylim(ylim)
axv.set_aspect("equal"); axv.axis("off")

asq=0.22
axv.add_patch(patches.Rectangle((-asq/2,-asq/2),asq,asq,
    facecolor="#4a4e69",edgecolor="#adb5bd",lw=1.5,zorder=4))
sp,=axv.plot([],[],"-",color="#a8dadc",lw=2.5,zorder=3)
st,=axv.plot([],[],"-",color="#e9c46a",lw=3.0,zorder=3)
b1c=plt.Circle((x1a[0],y1a[0]),0.15,facecolor="#e63946",edgecolor="white",lw=1.5,zorder=5)
b2c=plt.Circle((x2a[0],y2a[0]),0.15,facecolor="#f4a261",edgecolor="white",lw=1.5,zorder=5)
axv.add_patch(b1c); axv.add_patch(b2c)

def spfn(x1,y1,x2,y2,n=8,r=0.12):
    dx,dy=x2-x1,y2-y1; dist=np.hypot(dx,dy)
    if dist<1e-10: return np.array([x1,x2]),np.array([y1,y2])
    ux,uy=dx/dist,dy/dist; nx,ny=-uy,ux
    n_pts=n*20+2; t=np.linspace(0,1,n_pts); mg2=0.08
    env=np.where((t<mg2)|(t>1-mg2),0,np.sin(n*2*np.pi*(t-mg2)/(1-2*mg2)))
    return x1+t*dx+r*env*nx, y1+t*dy+r*env*ny

def update(f):
    b1x,b1y=x1a[f],y1a[f]; b2x,b2y=x2a[f],y2a[f]
    b1c.set_center((b1x,b1y)); b2c.set_center((b2x,b2y))
    sx,sy=spfn(0,0,b1x,b1y); sp.set_data(sx,sy)
    st.set_data([b1x,b2x],[b1y,b2y])
    return (sp,st,b1c,b2c)

ani=animation.FuncAnimation(fig,update,frames=len(sol.t),interval=1000/fps,blit=False)
ani.save("dangle_stick.mp4",writer=animation.FFMpegWriter(fps=fps,bitrate=1800),dpi=100)
plt.close(); print("Saved dangle_stick.mp4")
'''


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Dangle Stick Simulation")
    parser.add_argument("--m1",        type=float, default=0.5)
    parser.add_argument("--m2",        type=float, default=0.5)
    parser.add_argument("--L",         type=float, default=1.0)
    parser.add_argument("--k",         type=float, default=3.0)
    parser.add_argument("--b_rest",    type=float, default=1.0)
    parser.add_argument("--g",         type=float, default=9.8)
    parser.add_argument("--theta0",    type=float, default=0.5)
    parser.add_argument("--theta_dot0",type=float, default=0.0)
    parser.add_argument("--r0",        type=float, default=1.2)
    parser.add_argument("--r_dot0",    type=float, default=0.0)
    parser.add_argument("--phi0",      type=float, default=0.2)
    parser.add_argument("--phi_dot0",  type=float, default=0.0)
    parser.add_argument("--duration",  type=float, default=12.0)
    parser.add_argument("--output",    type=str,   default="dangle_stick.mp4")
    args = parser.parse_args()
    p = DangleStickParams(
        m1=args.m1, m2=args.m2, L=args.L,
        k=args.k, b_rest=args.b_rest, g=args.g,
        theta0=args.theta0, theta_dot0=args.theta_dot0,
        r0=args.r0, r_dot0=args.r_dot0,
        phi0=args.phi0, phi_dot0=args.phi_dot0,
    )
    print(f"Simulating dangle stick: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")


if __name__ == "__main__":
    main()
