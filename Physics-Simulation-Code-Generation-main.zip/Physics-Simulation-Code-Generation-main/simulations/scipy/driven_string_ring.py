"""
Driven String + Free-end Ring on a Rod.

A taut string is driven sinusoidally at the LEFT end and reflects off a
massless ring on a frictionless rod at the RIGHT (free) end.  Linear viscous
damping bounds the steady-state amplitude.  Solved with explicit leapfrog FDM.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Arc, Circle
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class DrivenStringRingParams:
    L: float = 4.0
    mu: float = 0.10
    T: float = 4.0
    A: float = 0.10
    f_drive: float = 2.0
    gamma_w: float = 1.0
    N_grid: int = 200
    n_per_frame: int = 16


def _integrate(p: DrivenStringRingParams, duration: float, fps: int):
    L, mu, T, A, f_drive, gamma_w = p.L, p.mu, p.T, p.A, p.f_drive, p.gamma_w
    N = int(p.N_grid)
    n_per_frame = int(p.n_per_frame)
    omega = 2 * np.pi * f_drive
    c = np.sqrt(T / mu)
    dx = L / N
    x_grid = np.linspace(0.0, L, N + 1)
    dt = 1.0 / (fps * n_per_frame)
    factor = (c * dt / dx) ** 2
    damp_n = 1.0 / (1.0 + gamma_w * dt)
    damp_p = 1.0 - gamma_w * dt
    if factor >= 1.0:
        raise RuntimeError(f"CFL violated: factor={factor:.4f}")
    u_curr = np.zeros(N + 1); u_prev = np.zeros(N + 1)
    n_frames = int(duration * fps) + 1
    U_frames = np.zeros((n_frames, N + 1))
    U_frames[0] = u_curr.copy()
    for frame in range(1, n_frames):
        for sub in range(n_per_frame):
            t_curr = (frame - 1) / fps + (sub + 1) * dt
            u_next = np.empty_like(u_curr)
            lap_int = u_curr[2:] - 2 * u_curr[1:-1] + u_curr[:-2]
            u_next[1:-1] = damp_n * (2 * u_curr[1:-1] - damp_p * u_prev[1:-1] + factor * lap_int)
            lap_right = 2 * (u_curr[-2] - u_curr[-1])
            u_next[-1] = damp_n * (2 * u_curr[-1] - damp_p * u_prev[-1] + factor * lap_right)
            u_next[0] = A * np.sin(omega * t_curr)
            u_prev, u_curr = u_curr, u_next
        U_frames[frame] = u_curr.copy()
    return np.linspace(0, duration, n_frames), x_grid, U_frames


def simulate(params: DrivenStringRingParams, duration: float = 8.0, fps: int = 30):
    t, _, U = _integrate(params, duration, fps)
    return t, U.T  # shape (N+1, n_frames)


def render_video(t, y, params: DrivenStringRingParams, output_path: str, fps: int = 30):
    L, A = params.L, params.A
    N = int(params.N_grid)
    dx = L / N
    x_grid = np.linspace(0.0, L, N + 1)
    U_frames = y.T  # (n_frames, N+1)

    fig_w, fig_h = 12.0, 4.0
    fig_aspect = fig_w / fig_h
    x_lo_d, x_hi_d = -0.40, L + 0.40
    y_lo_d, y_hi_d = -4.5 * A, 4.5 * A
    dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_d / dy_d < fig_aspect:
        extra = (fig_aspect * dy_d - dx_d) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx_d / fig_aspect - dy_d) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")
    ax.axhline(0.0, color="#3a4357", lw=1, ls="--", zorder=0)
    ax.plot([0, 0], [y_lo, y_hi], color="#4a4e69", lw=1.5, ls=":", zorder=1)
    driver_dot = Circle((0, 0), 0.04, facecolor="#e63946",
                        edgecolor="#adb5bd", lw=1.0, zorder=5)
    ax.add_patch(driver_dot)
    r_x = 0.22; r_y = 0.11
    back_arc = Arc((L, 0), 2 * r_x, 2 * r_y, theta1=0, theta2=180,
                   edgecolor="#e63946", lw=10, zorder=2)
    ax.add_patch(back_arc)
    ax.plot([L, L], [y_lo, y_hi], color="#adb5bd", lw=14,
            solid_capstyle="butt", zorder=3)
    front_arc = Arc((L, 0), 2 * r_x, 2 * r_y, theta1=180, theta2=360,
                    edgecolor="#e63946", lw=10, zorder=5)
    ax.add_patch(front_arc)
    n_cut = int(round(r_x / dx))
    n_inside = (N + 1) - n_cut
    str_x_plot = x_grid[:n_inside]
    str_line, = ax.plot([], [], color="#a8dadc", lw=2.4, zorder=4)

    def update(f):
        u = U_frames[f]; yy = u[-1]
        str_y = u[:n_inside].copy()
        str_y[-1] = yy
        str_line.set_data(str_x_plot, str_y)
        driver_dot.center = (0, u[0])
        back_arc.set_center((L, yy))
        front_arc.set_center((L, yy))
        return str_line, driver_dot, back_arc, front_arc

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0 / fps, blit=False)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: DrivenStringRingParams, duration: float = 8.0) -> str:
    p = asdict(params)
    return f'''"""Driven string + free-end ring standalone script."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Arc, Circle

L = {p["L"]}
mu = {p["mu"]}
T = {p["T"]}
A = {p["A"]}
f_drive = {p["f_drive"]}
gamma_w = {p["gamma_w"]}
N = {int(p["N_grid"])}
n_per_frame = {int(p["n_per_frame"])}
duration = {duration}
fps = 30

omega = 2*np.pi*f_drive
c = np.sqrt(T/mu)
dx = L/N
x_grid = np.linspace(0.0, L, N+1)
dt = 1.0/(fps*n_per_frame)
factor = (c*dt/dx)**2
damp_n = 1.0/(1.0+gamma_w*dt)
damp_p = 1.0 - gamma_w*dt
assert factor < 1.0, f"CFL violated: factor={{factor:.3f}}"

u_curr = np.zeros(N+1); u_prev = np.zeros(N+1)
n_frames = int(duration*fps)+1
U_frames = np.zeros((n_frames, N+1))
U_frames[0] = u_curr.copy()
for frame in range(1, n_frames):
    for sub in range(n_per_frame):
        t_curr = (frame-1)/fps + (sub+1)*dt
        u_next = np.empty_like(u_curr)
        lap_int = u_curr[2:] - 2*u_curr[1:-1] + u_curr[:-2]
        u_next[1:-1] = damp_n*(2*u_curr[1:-1] - damp_p*u_prev[1:-1] + factor*lap_int)
        lap_right = 2*(u_curr[-2] - u_curr[-1])
        u_next[-1] = damp_n*(2*u_curr[-1] - damp_p*u_prev[-1] + factor*lap_right)
        u_next[0] = A*np.sin(omega*t_curr)
        u_prev, u_curr = u_curr, u_next
    U_frames[frame] = u_curr.copy()

fig_w, fig_h = 12.0, 4.0
fig_aspect = fig_w/fig_h
x_lo_d, x_hi_d = -0.40, L+0.40
y_lo_d, y_hi_d = -4.5*A, 4.5*A
dx_d, dy_d = x_hi_d-x_lo_d, y_hi_d-y_lo_d
if dx_d/dy_d < fig_aspect:
    extra = (fig_aspect*dy_d - dx_d)/2.0
    x_lo, x_hi = x_lo_d-extra, x_hi_d+extra
    y_lo, y_hi = y_lo_d, y_hi_d
else:
    extra = (dx_d/fig_aspect - dy_d)/2.0
    x_lo, x_hi = x_lo_d, x_hi_d
    y_lo, y_hi = y_lo_d-extra, y_hi_d+extra

fig = plt.figure(figsize=(fig_w,fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.axhline(0.0, color="#3a4357", lw=1, ls="--", zorder=0)
ax.plot([0,0],[y_lo,y_hi], color="#4a4e69", lw=1.5, ls=":", zorder=1)
driver_dot = Circle((0,0), 0.04, facecolor="#e63946",
                    edgecolor="#adb5bd", lw=1.0, zorder=5)
ax.add_patch(driver_dot)
r_x = 0.22; r_y = 0.11
back_arc = Arc((L,0), 2*r_x, 2*r_y, theta1=0, theta2=180,
               edgecolor="#e63946", lw=10, zorder=2)
ax.add_patch(back_arc)
ax.plot([L,L],[y_lo,y_hi], color="#adb5bd", lw=14, solid_capstyle="butt", zorder=3)
front_arc = Arc((L,0), 2*r_x, 2*r_y, theta1=180, theta2=360,
                edgecolor="#e63946", lw=10, zorder=5)
ax.add_patch(front_arc)
n_cut = int(round(r_x/dx))
n_inside = (N+1) - n_cut
str_x_plot = x_grid[:n_inside]
str_line, = ax.plot([],[], color="#a8dadc", lw=2.4, zorder=4)

def update(f):
    u = U_frames[f]; yy = u[-1]
    str_y = u[:n_inside].copy(); str_y[-1] = yy
    str_line.set_data(str_x_plot, str_y)
    driver_dot.center = (0, u[0])
    back_arc.set_center((L, yy))
    front_arc.set_center((L, yy))
    return str_line, driver_dot, back_arc, front_arc

ani = animation.FuncAnimation(fig, update, frames=n_frames,
                              interval=1000.0/fps, blit=False)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--L", type=float, default=4.0)
    parser.add_argument("--mu", type=float, default=0.10)
    parser.add_argument("--T", type=float, default=4.0)
    parser.add_argument("--A", type=float, default=0.10)
    parser.add_argument("--f_drive", type=float, default=2.0)
    parser.add_argument("--gamma_w", type=float, default=1.0)
    parser.add_argument("--N_grid", type=int, default=200)
    parser.add_argument("--n_per_frame", type=int, default=16)
    parser.add_argument("--duration", type=float, default=8.0)
    parser.add_argument("--output", type=str, default="driven_string_ring.mp4")
    args = parser.parse_args()
    p = DrivenStringRingParams(L=args.L, mu=args.mu, T=args.T, A=args.A,
                               f_drive=args.f_drive, gamma_w=args.gamma_w,
                               N_grid=args.N_grid, n_per_frame=args.n_per_frame)
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
