"""
Molecule Simulation (N=2 atoms)
================================
Faithfully translated from myphysicslab/src/sims/springs/MoleculeSim.ts

Two atoms interact via a linear spring force and bounce within a 2D box.
The original MoleculeSim uses elastic wall collisions (MoleculeCollision),
but to keep this as a pure ODE we use **soft wall repulsion**: a stiff
one-sided spring activates whenever an atom crosses the wall boundary.

Spring Force between atoms (from Spring.calculateForces() in the TS source):
    v     = pos2 - pos1            (vector from atom 1 to atom 2)
    len   = |v|                    (current distance)
    L     = len - D                (stretch from rest distance D)
    sf    = -k * L                 (spring scalar force; >0 compressed, <0 stretched)
    F_on_atom1 = -sf * (v / len)   (force pointing toward atom 2 when L>0)
    F_on_atom2 = +sf * (v / len)   = -F_on_atom1  (Newton's 3rd)

Equivalently, the force magnitude on each atom is k*(len-D), directed
along the line connecting them (attractive when stretched, repulsive when compressed).

Damping: each atom independently experiences -b * velocity (from MoleculeSim.evaluate).

Soft wall: one-sided spring with stiffness k_wall = 500 (stiff enough to reflect cleanly).
    If atom.x < x_min + r  → wall pushes right:  F_wall_x = +k_wall*(x_min+r - atom.x)
    If atom.x > x_max - r  → wall pushes left:   F_wall_x = -k_wall*(atom.x - (x_max-r))
    (same for y, using y_min and y_max)
where r is the atom radius (used for display only; in the ODE we treat atoms as points
but apply wall force at the atom boundary).

State vector: [x1, y1, vx1, vy1, x2, y2, vx2, vy2]  (8 variables)

Parameters follow MoleculeSim.ts defaults:
    gravity = 0 (set to 0 for simplicity / dataset diversity)
    elasticity = 1 (elastic collisions; approximated by stiff soft walls)
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis


@dataclass
class Molecule2Params:
    k: float = 3.0        # inter-atom spring stiffness (N/m)
    m: float = 0.5        # mass of each atom (kg)
    b: float = 0.1        # damping coefficient (kg/s)
    D: float = 2.0        # rest distance between atoms (m)
    box_width: float = 6.0   # box half-width (box spans [-bw, +bw] in x)
    box_height: float = 6.0  # box half-height (box spans [-bh, +bh] in y)
    k_wall: float = 500.0    # soft wall spring stiffness
    atom_r: float = 0.2      # atom radius (for display and wall contact)
    # Initial conditions (box spans [-box_width/2, box_width/2] x [-box_height/2, box_height/2])
    # Default box: x in [-3,3], y in [-3,3]
    x1_0: float = -0.5
    y1_0: float = 0.0
    vx1_0: float = 1.5
    vy1_0: float = 0.5
    x2_0: float = 1.5
    y2_0: float = 0.0
    vx2_0: float = -1.0
    vy2_0: float = -0.5


def _wall_force(pos: float, lo: float, hi: float, r: float, k_wall: float) -> float:
    """One-sided soft wall: repulsive spring that activates when pos is outside [lo+r, hi-r]."""
    if pos < lo + r:
        return k_wall * (lo + r - pos)
    elif pos > hi - r:
        return -k_wall * (pos - (hi - r))
    return 0.0


def ode(t: float, y: list, p: Molecule2Params) -> list:
    """
    Equations of motion for 2 atoms.

    Spring force between atoms (from MoleculeSim / Spring.calculateForces):
        v   = (x2-x1, y2-y1)
        len = |v|
        L   = len - D                   (stretch)
        sf  = -k * L                    (scalar spring force)
        F1  = -sf * (v / len)           (force on atom 1, away from atom 2 when compressed)
        F2  = +sf * (v / len)           (force on atom 2, Newton's 3rd)

    Damping (applied independently to each atom velocity, from MoleculeSim.evaluate):
        F_damp_i = -b * v_i

    Wall: soft one-sided springs on all four walls.
    """
    x1, y1, vx1, vy1, x2, y2, vx2, vy2 = y

    bw = p.box_width / 2.0
    bh = p.box_height / 2.0
    r  = p.atom_r

    # Inter-atom spring force
    dx = x2 - x1
    dy = y2 - y1
    dist = np.hypot(dx, dy)

    if dist < 1e-12:
        # Degenerate: atoms at same position, no force direction
        fsx1 = fsy1 = fsx2 = fsy2 = 0.0
    else:
        L  = dist - p.D              # stretch (positive = stretched)
        sf = -p.k * L               # scalar spring force (negative = attractive on body1)
        # Force on atom 1 is  -sf * (v/len)  (pulls toward atom2 when L>0, i.e. sf<0)
        fsx1 = -sf * (dx / dist)
        fsy1 = -sf * (dy / dist)
        # Force on atom 2 is opposite
        fsx2 = -fsx1
        fsy2 = -fsy1

    # Damping
    fdx1 = -p.b * vx1;  fdy1 = -p.b * vy1
    fdx2 = -p.b * vx2;  fdy2 = -p.b * vy2

    # Soft wall repulsion
    fwx1 = _wall_force(x1, -bw, bw, r, p.k_wall)
    fwy1 = _wall_force(y1, -bh, bh, r, p.k_wall)
    fwx2 = _wall_force(x2, -bw, bw, r, p.k_wall)
    fwy2 = _wall_force(y2, -bh, bh, r, p.k_wall)

    ax1 = (fsx1 + fdx1 + fwx1) / p.m
    ay1 = (fsy1 + fdy1 + fwy1) / p.m
    ax2 = (fsx2 + fdx2 + fwx2) / p.m
    ay2 = (fsy2 + fdy2 + fwy2) / p.m

    return [vx1, vy1, ax1, ay1, vx2, vy2, ax2, ay2]


def simulate(
    params: Molecule2Params,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Integrate using RK45. Returns (t, y) with y.shape = (8, N)."""
    y0 = [
        params.x1_0, params.y1_0, params.vx1_0, params.vy1_0,
        params.x2_0, params.y2_0, params.vx2_0, params.vy2_0,
    ]
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode,
        (0, duration),
        y0,
        t_eval=t_eval,
        args=(params,),
        method="RK45",
        rtol=1e-8,
        atol=1e-10,
    )
    return sol.t, sol.y


def energy(t: np.ndarray, y: np.ndarray, p: Molecule2Params):
    x1, y1, vx1, vy1, x2, y2, vx2, vy2 = y
    dx = x2 - x1;  dy = y2 - y1
    dist = np.hypot(dx, dy)
    L = dist - p.D
    KE = 0.5 * p.m * (vx1**2 + vy1**2 + vx2**2 + vy2**2)
    PE = 0.5 * p.k * L**2
    return KE, PE, KE + PE


def _atom_color_by_dist(dist: float, D: float):
    """
    Color the inter-atom bond:
      green  = near equilibrium  (|stretch| < 0.1*D)
      red    = compressed        (dist < D - 0.1*D)
      blue   = stretched         (dist > D + 0.1*D)
    """
    tol = 0.15 * D
    if dist < D - tol:
        return "#e63946"   # red: compressed
    elif dist > D + tol:
        return "#457b9d"   # blue: stretched
    else:
        return "#06d6a0"   # green: near equilibrium


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: Molecule2Params,
    output_path: str,
    fps: int = 30,
) -> None:
    """Render 2D box with two atoms and a bond line colored by distance."""
    x1a, y1a, x2a, y2a = y[0], y[1], y[4], y[5]

    bw = params.box_width / 2.0
    bh = params.box_height / 2.0
    pad = 0.5

    fig, ax = plt.subplots(figsize=(7, 7))
    setup_dark_axis(
        fig, ax,
        (-bw - pad, bw + pad),
        (-bh - pad, bh + pad),
    )

    # Box boundary
    box_rect = patches.Rectangle(
        (-bw, -bh), params.box_width, params.box_height,
        linewidth=2, edgecolor="#a8dadc", facecolor="none", zorder=2,
    )
    ax.add_patch(box_rect)

    # Animated elements
    (bond_line,) = ax.plot([], [], "-", lw=2.5, zorder=3, color="#06d6a0")

    atom1_circle = plt.Circle(
        (params.x1_0, params.y1_0), params.atom_r,
        color="#e63946", zorder=4, linewidth=1.5,
    )
    atom2_circle = plt.Circle(
        (params.x2_0, params.y2_0), params.atom_r,
        color="#f4d35e", zorder=4, linewidth=1.5,
    )
    ax.add_patch(atom1_circle)
    ax.add_patch(atom2_circle)

    # Labels

    # Distance text

    def init():
        bond_line.set_data([], [])
        return bond_line, atom1_circle, atom2_circle, 
    def update(frame):
        px1, py1 = x1a[frame], y1a[frame]
        px2, py2 = x2a[frame], y2a[frame]

        atom1_circle.center = (px1, py1)
        atom2_circle.center = (px2, py2)

        bond_line.set_data([px1, px2], [py1, py2])
        dist = np.hypot(px2 - px1, py2 - py1)
        bond_line.set_color(_atom_color_by_dist(dist, params.D))

        return bond_line, atom1_circle, atom2_circle, 
    ani = animation.FuncAnimation(
        fig, update, frames=len(t), init_func=init, interval=1000 / fps, blit=False
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: Molecule2Params, duration: float = 12.0) -> str:
    p = asdict(params)
    bw = params.box_width / 2.0
    bh = params.box_height / 2.0
    return f'''"""
Molecule Simulation (N=2 atoms) — auto-generated simulation script.
Physics:
  Inter-atom spring (from MoleculeSim.ts / Spring.calculateForces):
    dx,dy = pos2 - pos1;  dist = sqrt(dx^2+dy^2);  L = dist - D
    sf = -k*L  (scalar)
    F_atom1 = -sf*(dx,dy)/dist;  F_atom2 = +sf*(dx,dy)/dist
  Damping:  F_damp_i = -b*v_i
  Soft walls (stiff one-sided spring, k_wall={p["k_wall"]}):
    Activate when atom position crosses box boundary [+-bw, +-bh] by atom_r.
Box: x in [{-bw:.2f}, {bw:.2f}], y in [{-bh:.2f}, {bh:.2f}]
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

k, m, b = {p["k"]}, {p["m"]}, {p["b"]}
D = {p["D"]}
k_wall = {p["k_wall"]}
atom_r = {p["atom_r"]}
bw, bh = {bw:.4f}, {bh:.4f}
y0 = [{p["x1_0"]}, {p["y1_0"]}, {p["vx1_0"]}, {p["vy1_0"]},
      {p["x2_0"]}, {p["y2_0"]}, {p["vx2_0"]}, {p["vy2_0"]}]
duration = {duration}

def wall_f(pos, lo, hi, r, kw):
    if pos < lo + r:   return kw*(lo + r - pos)
    elif pos > hi - r: return -kw*(pos - (hi - r))
    return 0.0

def ode(t, y):
    x1, y1, vx1, vy1, x2, y2, vx2, vy2 = y
    dx, dy = x2-x1, y2-y1
    dist = np.hypot(dx, dy)
    if dist < 1e-12:
        fsx1=fsy1=fsx2=fsy2=0.0
    else:
        L = dist - D; sf = -k*L
        fsx1=-sf*dx/dist; fsy1=-sf*dy/dist
        fsx2=-fsx1;       fsy2=-fsy1
    ax1=(fsx1-b*vx1+wall_f(x1,-bw,bw,atom_r,k_wall))/m
    ay1=(fsy1-b*vy1+wall_f(y1,-bh,bh,atom_r,k_wall))/m
    ax2=(fsx2-b*vx2+wall_f(x2,-bw,bw,atom_r,k_wall))/m
    ay2=(fsy2-b*vy2+wall_f(y2,-bh,bh,atom_r,k_wall))/m
    return [vx1, vy1, ax1, ay1, vx2, vy2, ax2, ay2]

fps = 30
t_eval = np.linspace(0, duration, int(duration*fps)+1)
sol = solve_ivp(ode, (0, duration), y0, t_eval=t_eval, method="RK45", rtol=1e-8, atol=1e-10)
x1a,y1a,x2a,y2a = sol.y[0],sol.y[1],sol.y[4],sol.y[5]

fig, ax = plt.subplots(figsize=(7,7), facecolor="#1a1a2e")
ax.set_facecolor("#16213e"); ax.set_xlim(-bw-0.5,bw+0.5); ax.set_ylim(-bh-0.5,bh+0.5)
ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(patches.Rectangle((-bw,-bh),2*bw,2*bh,lw=2,edgecolor="#a8dadc",facecolor="none"))

bond, = ax.plot([],[],"--",lw=2.5,color="#06d6a0",zorder=3)
c1 = plt.Circle((y0[0],y0[1]),atom_r,color="#e63946",zorder=4); ax.add_patch(c1)
c2 = plt.Circle((y0[4],y0[5]),atom_r,color="#f4d35e",zorder=4); ax.add_patch(c2)

def upd(f):
    p1x,p1y,p2x,p2y = x1a[f],y1a[f],x2a[f],y2a[f]
    c1.center=(p1x,p1y); c2.center=(p2x,p2y)
    bond.set_data([p1x,p2x],[p1y,p2y])
    dist=np.hypot(p2x-p1x,p2y-p1y)
    col = "#e63946" if dist<D*0.85 else ("#457b9d" if dist>D*1.15 else "#06d6a0")
    bond.set_color(col)
    return bond,c1,c2
ani=animation.FuncAnimation(fig,upd,frames=len(sol.t),interval=1000/fps,blit=False)
ani.save("molecule_2.mp4",writer=animation.FFMpegWriter(fps=fps,bitrate=1800),dpi=120)
plt.close(); print("Saved molecule_2.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Molecule Simulation (N=2 atoms)")
    parser.add_argument("--k",        type=float, default=3.0)
    parser.add_argument("--m",        type=float, default=0.5)
    parser.add_argument("--b",        type=float, default=0.1)
    parser.add_argument("--D",        type=float, default=2.0)
    parser.add_argument("--box_width",  type=float, default=6.0)
    parser.add_argument("--box_height", type=float, default=6.0)
    parser.add_argument("--k_wall",   type=float, default=500.0)
    parser.add_argument("--atom_r",   type=float, default=0.2)
    parser.add_argument("--x1_0",    type=float, default=-0.5)
    parser.add_argument("--y1_0",    type=float, default=0.0)
    parser.add_argument("--vx1_0",   type=float, default=1.5)
    parser.add_argument("--vy1_0",   type=float, default=0.5)
    parser.add_argument("--x2_0",    type=float, default=1.5)
    parser.add_argument("--y2_0",    type=float, default=0.0)
    parser.add_argument("--vx2_0",   type=float, default=-1.0)
    parser.add_argument("--vy2_0",   type=float, default=-0.5)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output",   type=str,   default="molecule_2.mp4")
    args = parser.parse_args()
    p = Molecule2Params(
        k=args.k, m=args.m, b=args.b, D=args.D,
        box_width=args.box_width, box_height=args.box_height,
        k_wall=args.k_wall, atom_r=args.atom_r,
        x1_0=args.x1_0, y1_0=args.y1_0, vx1_0=args.vx1_0, vy1_0=args.vy1_0,
        x2_0=args.x2_0, y2_0=args.y2_0, vx2_0=args.vx2_0, vy2_0=args.vy2_0,
    )
    print(f"Simulating molecule (N=2): {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
