"""
Roller Single Simulation
========================
Faithfully translated from myphysicslab/src/sims/roller/RollerSingleSim.ts

Physical Law: Euler-Lagrange equations for a ball constrained to a 2D curve.

Track shape: sine wave  y = A * sin(B * x)

Derivation:
    Lagrangian:  L = (m/2) * (1 + f'(x)^2) * x_dot^2 - m*g*f(x)

    where f(x)  = A * sin(B * x)
          f'(x) = A*B * cos(B * x)
          f''(x)= -A*B^2 * sin(B * x)

    Euler-Lagrange gives:
        (1 + f'^2) * x_ddot + f'*f'' * x_dot^2 + g*f' = -(b/m)*sqrt(1+f'^2)*x_dot

    Solving for x_ddot:
        x_ddot = [-f'*f'' * x_dot^2 - g*f' - (b/m)*sqrt(1+f'^2)*x_dot] / (1 + f'^2)

State vector: [x, v]   where v = dx/dt
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from dataclasses import dataclass, asdict
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from .draw_utils import setup_dark_axis


@dataclass
class RollerSingleParams:
    A: float = 1.0       # sine wave amplitude (m)
    B: float = 1.0       # sine wave frequency (rad/m)
    m: float = 1.0       # ball mass (kg)
    b: float = 0.1       # linear damping coefficient
    g: float = 9.8       # gravitational acceleration (m/s^2)
    x0: float = 0.0      # initial horizontal position (m)
    v0: float = 2.0      # initial horizontal velocity (m/s)


def _track(x: np.ndarray, p: RollerSingleParams):
    """Return (y, f_prime, f_double_prime) for the sine wave track."""
    y      =  p.A * np.sin(p.B * x)
    fp     =  p.A * p.B * np.cos(p.B * x)
    fpp    = -p.A * p.B ** 2 * np.sin(p.B * x)
    return y, fp, fpp


def ode(t: float, y: list, p: RollerSingleParams):
    """
    ODE for a ball rolling (no friction) on a sine-wave track.
    Translated from RollerSingleSim.ts evaluate() via Lagrangian derivation.

    dx/dt  = v
    dv/dt  = [-f'*f'' * v^2 - g*f' - (b/m)*sqrt(1+f'^2)*v] / (1 + f'^2)
    """
    x, v = y
    _, fp, fpp = _track(np.array([x]), p)
    fp  = fp[0]
    fpp = fpp[0]

    fp2      = fp * fp
    denom    = 1.0 + fp2
    drag     = (p.b / p.m) * np.sqrt(denom) * v
    dv       = (-fp * fpp * v * v - p.g * fp - drag) / denom

    return [v, dv]


def simulate(
    params: RollerSingleParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Integrate the ODE using RK45.
    Returns (t, y) where y.shape = (2, N): [x, v] at each time step.
    """
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode,
        (0, duration),
        [params.x0, params.v0],
        t_eval=t_eval,
        args=(params,),
        method="RK45",
        rtol=1e-8,
        atol=1e-10,
        dense_output=False,
    )
    return sol.t, sol.y


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: RollerSingleParams,
    output_path: str,
    fps: int = 30,
    trail_len: int = 60,
) -> None:
    """Render an MP4 video of the ball rolling along the sine-wave track."""
    x_ball = y[0]
    y_ball, _, _ = _track(x_ball, params)

    # Build the static track curve
    x_range = np.linspace(x_ball.min() - 1.0, x_ball.max() + 1.0, 600)
    y_track, _, _ = _track(x_range, params)

    pad_x = (x_ball.max() - x_ball.min()) * 0.15 + 0.5
    pad_y = (y_track.max() - y_track.min()) * 0.25 + 0.5
    xlim = (x_range.min(), x_range.max())
    ylim = (y_track.min() - pad_y, y_track.max() + pad_y)

    fig, ax = plt.subplots(figsize=(8, 5))
    setup_dark_axis(fig, ax, xlim, ylim)

    # Static track
    ax.plot(x_range, y_track, "-", color="#a8dadc", lw=2.0, zorder=2, alpha=0.7)

    # Animated elements
    (ball,)  = ax.plot([], [], "o", color="#e63946", ms=12, zorder=5)
    (trail,) = ax.plot([], [], "-", color="#e63946", alpha=0.4, lw=1.5, zorder=4)

    trail_x: list = []
    trail_y: list = []

    def init():
        ball.set_data([], [])
        trail.set_data([], [])
        return ball, trail

    def update(frame):
        bx = x_ball[frame]
        by = y_ball[frame]
        ball.set_data([bx], [by])
        trail_x.append(bx)
        trail_y.append(by)
        if len(trail_x) > trail_len:
            trail_x.pop(0)
            trail_y.pop(0)
        trail.set_data(trail_x, trail_y)
        return ball, trail

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), init_func=init, interval=1000 / fps, blit=True
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: RollerSingleParams, duration: float = 12.0) -> str:
    """Return a self-contained Python script string with parameter values embedded."""
    p = asdict(params)
    return f'''"""
Roller (Sine Wave Track) — auto-generated simulation script.
Physics:  x_ddot = [-f\'*f\'\' * v^2 - g*f\' - (b/m)*sqrt(1+f\'^2)*v] / (1 + f\'^2)
Track:    y = A*sin(B*x),  f\'=A*B*cos(B*x),  f\'\'=-A*B^2*sin(B*x)
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation

# ── Physical parameters ─────────────────────────────────────────────────────
A  = {p["A"]}    # sine wave amplitude (m)
B  = {p["B"]}    # sine wave spatial frequency (rad/m)
m  = {p["m"]}    # ball mass (kg)
b  = {p["b"]}    # damping coefficient
g  = {p["g"]}    # gravitational acceleration (m/s^2)
x0 = {p["x0"]}   # initial x position (m)
v0 = {p["v0"]}   # initial x velocity (m/s)
duration = {duration}

# ── Track helpers ─────────────────────────────────────────────────────────────
def track(x):
    y   =  A * np.sin(B * x)
    fp  =  A * B * np.cos(B * x)
    fpp = -A * B**2 * np.sin(B * x)
    return y, fp, fpp

# ── ODE system ───────────────────────────────────────────────────────────────
def ode(t, state):
    x, v = state
    yt, fp, fpp = track(np.array([x]))
    fp, fpp = fp[0], fpp[0]
    denom = 1.0 + fp*fp
    drag  = (b / m) * np.sqrt(denom) * v
    dv    = (-fp*fpp*v*v - g*fp - drag) / denom
    return [v, dv]

# ── Integrate ────────────────────────────────────────────────────────────────
fps    = 30
t_eval = np.linspace(0, duration, int(duration * fps) + 1)
sol    = solve_ivp(ode, (0, duration), [x0, v0],
                   t_eval=t_eval, method="RK45", rtol=1e-8, atol=1e-10)
t, x_ball = sol.t, sol.y[0]
y_ball, _, _ = track(x_ball)

# ── Build static track ───────────────────────────────────────────────────────
x_range = np.linspace(x_ball.min() - 1, x_ball.max() + 1, 600)
y_track, _, _ = track(x_range)

# ── Animate ──────────────────────────────────────────────────────────────────
pad_y = (y_track.max() - y_track.min()) * 0.25 + 0.5
fig, ax = plt.subplots(figsize=(8, 5), facecolor="#1a1a2e")
ax.set_facecolor("#16213e")
ax.set_xlim(x_range.min(), x_range.max())
ax.set_ylim(y_track.min() - pad_y, y_track.max() + pad_y)
ax.set_aspect("equal"); ax.axis("off")
ax.plot(x_range, y_track, "-", color="#a8dadc", lw=2.0, alpha=0.7)

ball,  = ax.plot([], [], "o", color="#e63946", ms=12, zorder=5)
trail, = ax.plot([], [], "-", color="#e63946", alpha=0.4, lw=1.5)
tx, ty = [], []

def update(frame):
    ball.set_data([x_ball[frame]], [y_ball[frame]])
    tx.append(x_ball[frame]); ty.append(y_ball[frame])
    if len(tx) > 60: tx.pop(0); ty.pop(0)
    trail.set_data(tx, ty)
    return ball, trail

ani = animation.FuncAnimation(fig, update, frames=len(t), interval=1000/fps, blit=True)
writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
ani.save("roller_single.mp4", writer=writer, dpi=120)
plt.close()
print("Saved roller_single.mp4")
'''


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Roller — Sine Wave Track Simulation")
    parser.add_argument("--A",        type=float, default=1.0)
    parser.add_argument("--B",        type=float, default=1.0)
    parser.add_argument("--m",        type=float, default=1.0)
    parser.add_argument("--b",        type=float, default=0.1)
    parser.add_argument("--g",        type=float, default=9.8)
    parser.add_argument("--x0",       type=float, default=0.0)
    parser.add_argument("--v0",       type=float, default=2.0)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output",   type=str,   default="roller_single.mp4")
    args = parser.parse_args()

    p = RollerSingleParams(
        A=args.A, B=args.B, m=args.m, b=args.b,
        g=args.g, x0=args.x0, v0=args.v0,
    )
    print(f"Simulating roller (sine wave): {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
