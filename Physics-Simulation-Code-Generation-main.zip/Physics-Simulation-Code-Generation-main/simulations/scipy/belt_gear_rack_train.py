"""
Belt-Gear-Rack Train — vertical stack: top gear (driven by belt) -> middle gear -> rack.
Kinematics in closed form (no ODE).
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon, Circle, Rectangle
from matplotlib.collections import LineCollection
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class BeltGearRackTrainParams:
    # Seed in [0, 1) drives the gear-tooth-count randomization (and thus R_top, R_mid,
    # gear ratio R_top/R_mid, and the geometric placements y_top, y_mid that follow
    # from those radii). All meshing gears share a single fixed module m = 2 R / N.
    seed: float = 0.5
    module: float = 0.020       # circular-pitch module (m = 2R/N), fixed across the gear set
    addendum: float = 0.022
    dedendum: float = 0.030
    tooth_frac: float = 0.40
    r_pulley: float = 0.06
    omega_max: float = 1.50
    t_ramp: float = 2.0
    x_axle: float = 0.0
    y_rack: float = -0.16        # rack pitch-line y; geometry of y_top, y_mid follows
    rack_length: float = 4.0
    rack_height: float = 0.16
    x_rack_0: float = 0.50
    duration: float = 12.0
    fps: int = 30
    # Auto-populated in __post_init__ from `seed` unless explicitly set.
    N_top: int = 0
    N_mid: int = 0
    R_top: float = 0.0
    R_mid: float = 0.0
    y_top: float = 0.0
    y_mid: float = 0.0

    def __post_init__(self):
        # Only derive the gear-set geometry when N_top has not been explicitly provided.
        if self.N_top == 0:
            self._derive_from_seed()

    def _derive_from_seed(self):
        rng = np.random.default_rng(int(round(self.seed * 10_000_000)))
        # Random tooth counts. Ranges chosen so the gear ratio N_top/N_mid spans roughly
        # 1.0 to 3.0 across samples (default 30/18 ≈ 1.67 sits in the middle).
        self.N_top = int(rng.integers(22, 36))   # 22..35
        self.N_mid = int(rng.integers(12, 22))   # 12..21
        # Gears with the same module: pitch-radius R = m N / 2.
        self.R_top = self.module * self.N_top / 2.0
        self.R_mid = self.module * self.N_mid / 2.0
        # Geometric placement: rack pitch-line at y_rack; mid-gear axle one mid-pitch-radius
        # above the rack; top-gear axle one (R_top + R_mid) above the mid-gear axle.
        self.y_mid = self.y_rack + self.R_mid
        self.y_top = self.y_mid + self.R_mid + self.R_top


def _theta_top_int_raw(t, omega_max, t_ramp):
    if isinstance(t, np.ndarray):
        return np.where(t <= t_ramp,
                        omega_max * t * t / (2.0 * t_ramp),
                        omega_max * (t - t_ramp / 2.0))
    if t <= t_ramp:
        return omega_max * t * t / (2.0 * t_ramp)
    return omega_max * (t - t_ramp / 2.0)


def simulate(params: BeltGearRackTrainParams, duration: float = 12.0, fps: int = 30):
    if duration is not None: params.duration = duration
    p = params
    target = (p.x_rack_0 + p.rack_length / 2.0 - p.x_axle) / p.R_top
    theta_at_ramp_end = p.omega_max * p.t_ramp / 2.0
    if target <= theta_at_ramp_end:
        t_disengage = float(np.sqrt(2.0 * p.t_ramp * target / p.omega_max))
    else:
        t_disengage = target / p.omega_max + p.t_ramp / 2.0
    n = int(p.duration * fps) + 1
    t = np.linspace(0.0, p.duration, n)
    t_clamped = np.minimum(t, t_disengage)
    theta_top = _theta_top_int_raw(t_clamped, p.omega_max, p.t_ramp)
    theta_mid = -(p.R_top / p.R_mid) * theta_top
    x_rack = p.x_rack_0 - p.R_top * theta_top
    return t, np.stack([theta_top, theta_mid, x_rack])


def render_video(t, y, params: BeltGearRackTrainParams,
                 output_path: str, fps: int = 30):
    p = params
    theta_top_arr, theta_mid_arr, x_rack_arr = y[0], y[1], y[2]

    cTop = np.array([p.x_axle, p.y_top])
    cMid = np.array([p.x_axle, p.y_mid])
    rack_pitch = 2.0 * np.pi * p.R_mid / p.N_mid

    rack_left_edge_min = float(x_rack_arr.min()) - 0.5 * p.rack_length
    rack_right_edge_max = float(x_rack_arr.max()) + 0.5 * p.rack_length

    fig_w, fig_h = 12.0, 6.5
    fig_aspect = fig_w / fig_h
    x_lo_d = rack_left_edge_min - 0.30
    x_hi_d = rack_right_edge_max + 0.30
    y_lo_d = p.y_rack - p.rack_height - 0.30
    y_hi_d = p.y_top + p.R_top + p.addendum + 1.30
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    def gear_polygon(cx, cy, R, N_teeth, theta=0.0):
        r_add = R + p.addendum; r_ded = R - p.dedendum
        pitch = 2.0 * np.pi / N_teeth
        phi = 0.5 * p.tooth_frac * pitch
        pts = np.empty((4 * N_teeth, 2))
        for i in range(N_teeth):
            theta_c = i * pitch + theta
            for k_, (r, dphi) in enumerate(((r_ded, -phi), (r_add, -phi),
                                              (r_add, +phi), (r_ded, +phi))):
                ang = theta_c + dphi
                pts[4 * i + k_, 0] = cx + r * np.cos(ang)
                pts[4 * i + k_, 1] = cy + r * np.sin(ang)
        return pts

    def rack_polygon(cx, cy_pitch, length, height, pitch_x, x_offset=0.0):
        add_r = p.addendum; ded_r = p.dedendum
        half_tooth = 0.5 * p.tooth_frac * pitch_x
        x_left = cx - 0.5 * length; x_right = cx + 0.5 * length
        y_ded = cy_pitch - ded_r; y_add = cy_pitch + add_r
        y_bot = cy_pitch - ded_r - height
        k_min = int(np.floor((x_left - x_offset) / pitch_x)) - 1
        k_max = int(np.ceil((x_right - x_offset) / pitch_x)) + 1
        top_pts = [(x_left, y_ded)]
        for k in range(k_min, k_max + 1):
            xc = k * pitch_x + x_offset
            x0 = xc - half_tooth; x1 = xc + half_tooth
            if x1 < x_left or x0 > x_right: continue
            x0c = max(x0, x_left); x1c = min(x1, x_right)
            if x0 >= x_left:
                top_pts.append((x0c, y_ded)); top_pts.append((x0c, y_add))
            else:
                top_pts.append((x_left, y_add))
            if x1 <= x_right:
                top_pts.append((x1c, y_add)); top_pts.append((x1c, y_ded))
            else:
                top_pts.append((x_right, y_add))
        top_pts.append((x_right, y_ded))
        bot_pts = [(x_right, y_bot), (x_left, y_bot)]
        return np.array(top_pts + bot_pts)

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    ax.add_patch(Polygon([(x_lo, y_lo), (x_hi, y_lo),
                          (x_hi, p.y_rack - p.dedendum - p.rack_height - 0.04),
                          (x_lo, p.y_rack - p.dedendum - p.rack_height - 0.04)],
                          facecolor="#0f1525", edgecolor="none", zorder=0))

    gear_pitch_mid = 2.0 * np.pi / p.N_mid
    theta_mid_0 = -np.pi / 2 + np.pi / p.N_mid
    theta_mid_0 -= np.floor(theta_mid_0 / gear_pitch_mid) * gear_pitch_mid
    gear_pitch_top = 2.0 * np.pi / p.N_top
    theta_top_0 = -np.pi / 2
    theta_top_0 -= np.floor(theta_top_0 / gear_pitch_top) * gear_pitch_top
    rack_phase_offset_0 = p.x_axle

    gTop_patch = Polygon(gear_polygon(cTop[0], cTop[1], p.R_top, p.N_top, theta=theta_top_0),
                          facecolor="#a8dadc", edgecolor="#adb5bd", lw=1.2, zorder=4)
    gMid_patch = Polygon(gear_polygon(cMid[0], cMid[1], p.R_mid, p.N_mid, theta=theta_mid_0),
                          facecolor="#a8dadc", edgecolor="#adb5bd", lw=1.2, zorder=4)
    ax.add_patch(gTop_patch); ax.add_patch(gMid_patch)
    ax.add_patch(Circle(cTop, p.R_top - p.dedendum * 1.4, facecolor="#3a4357",
                         edgecolor="none", zorder=4.2))
    ax.add_patch(Circle(cMid, p.R_mid - p.dedendum * 1.5, facecolor="#3a4357",
                         edgecolor="none", zorder=4.2))
    spokeTop_a, = ax.plot([], [], color="#e63946", lw=3.0, zorder=4.5)
    spokeTop_b, = ax.plot([], [], color="#f9c74f", lw=2.5, zorder=4.5)
    spokeMid_a, = ax.plot([], [], color="#e63946", lw=3.0, zorder=4.5)
    spokeMid_b, = ax.plot([], [], color="#f9c74f", lw=2.5, zorder=4.5)
    rack_patch = Polygon(rack_polygon(p.x_rack_0, p.y_rack, p.rack_length, p.rack_height,
                                       rack_pitch, x_offset=rack_phase_offset_0),
                          facecolor="#a8dadc", edgecolor="#adb5bd", lw=1.2, zorder=3.5)
    ax.add_patch(rack_patch)
    rack_hash_lc = LineCollection([], colors="#3a4357", linewidths=2.0, zorder=3.7)
    ax.add_collection(rack_hash_lc)

    y_top_off = y_hi + 0.10
    n_arc = 60
    arc_angles = np.linspace(np.pi, 2.0 * np.pi, n_arc)
    arc_pts = np.column_stack([cTop[0] + p.r_pulley * np.cos(arc_angles),
                                cTop[1] + p.r_pulley * np.sin(arc_angles)])
    belt_path = np.concatenate([
        [[cTop[0] - p.r_pulley, y_top_off]], arc_pts,
        [[cTop[0] + p.r_pulley, y_top_off]],
    ])
    ax.plot(belt_path[:, 0], belt_path[:, 1], color="#4a4e69",
            lw=10, solid_capstyle="butt", zorder=6)
    ax.plot(belt_path[:, 0], belt_path[:, 1], color="#3a4357",
            lw=7, solid_capstyle="butt", zorder=6.5)
    ax.add_patch(Circle(cTop, p.r_pulley * 0.85, facecolor="#3a4357",
                         edgecolor="#adb5bd", lw=1.0, zorder=8))
    ax.add_patch(Circle(cTop, 0.030, facecolor="#e63946",
                         edgecolor="#adb5bd", lw=0.8, zorder=9))
    ax.add_patch(Circle(cMid, 0.030, facecolor="#e63946",
                         edgecolor="#adb5bd", lw=0.8, zorder=9))

    rack_hash_spacing = 0.20
    rack_hash_w_y = p.rack_height * 0.6

    def update(f):
        th_top = theta_top_0 + theta_top_arr[f]
        th_mid = theta_mid_0 + theta_mid_arr[f]
        gTop_patch.set_xy(gear_polygon(cTop[0], cTop[1], p.R_top, p.N_top, theta=th_top))
        gMid_patch.set_xy(gear_polygon(cMid[0], cMid[1], p.R_mid, p.N_mid, theta=th_mid))
        rmTop = p.R_top + p.addendum * 0.5
        spokeTop_a.set_data([cTop[0], cTop[0] + rmTop * np.cos(th_top)],
                             [cTop[1], cTop[1] + rmTop * np.sin(th_top)])
        spokeTop_b.set_data([cTop[0], cTop[0] + rmTop * np.cos(th_top + np.pi/2)],
                             [cTop[1], cTop[1] + rmTop * np.sin(th_top + np.pi/2)])
        rmMid = p.R_mid + p.addendum * 0.5
        spokeMid_a.set_data([cMid[0], cMid[0] + rmMid * np.cos(th_mid)],
                             [cMid[1], cMid[1] + rmMid * np.sin(th_mid)])
        spokeMid_b.set_data([cMid[0], cMid[0] + rmMid * np.cos(th_mid + np.pi/2)],
                             [cMid[1], cMid[1] + rmMid * np.sin(th_mid + np.pi/2)])
        cx_rack = float(x_rack_arr[f])
        rack_disp = cx_rack - p.x_rack_0
        tooth_phase = rack_phase_offset_0 + rack_disp
        rack_patch.set_xy(rack_polygon(cx_rack, p.y_rack, p.rack_length, p.rack_height,
                                          rack_pitch, x_offset=tooth_phase))
        y_bot_top = p.y_rack - p.dedendum - p.rack_height
        x_left = cx_rack - 0.5 * p.rack_length
        x_right = cx_rack + 0.5 * p.rack_length
        n_marks = int(np.floor(p.rack_length / rack_hash_spacing))
        segs = []
        for k in range(n_marks):
            u_k = (k + 0.5) * rack_hash_spacing - 0.5 * p.rack_length
            xm = cx_rack + u_k
            if x_left + 0.02 <= xm <= x_right - 0.02:
                segs.append([(xm, y_bot_top + 0.01),
                             (xm, y_bot_top + p.rack_height * 0.85)])
        rack_hash_lc.set_segments(segs)
        return (gTop_patch, gMid_patch, rack_patch,
                spokeTop_a, spokeTop_b, spokeMid_a, spokeMid_b, rack_hash_lc)

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0/fps, blit=False)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: BeltGearRackTrainParams,
                           duration: float = 12.0) -> str:
    p = asdict(params)
    p["duration"] = duration
    return f'''"""Belt-gear-rack-train - standalone script."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon, Circle, Rectangle
from matplotlib.collections import LineCollection

N_top = {p["N_top"]}; N_mid = {p["N_mid"]}
R_top = {p["R_top"]}; R_mid = {p["R_mid"]}
addendum = {p["addendum"]}; dedendum = {p["dedendum"]}
tooth_frac = {p["tooth_frac"]}; r_pulley = {p["r_pulley"]}
omega_max = {p["omega_max"]}; t_ramp = {p["t_ramp"]}
x_axle = {p["x_axle"]}; y_top = {p["y_top"]}; y_mid = {p["y_mid"]}; y_rack = {p["y_rack"]}
rack_length = {p["rack_length"]}; rack_height = {p["rack_height"]}; x_rack_0 = {p["x_rack_0"]}
rack_pitch = 2.0 * np.pi * R_mid / N_mid
duration = {p["duration"]}; fps = {p["fps"]}


def theta_top_int_raw(t):
    if isinstance(t, np.ndarray):
        ramp = t <= t_ramp
        return np.where(ramp, omega_max * t * t / (2.0 * t_ramp),
                              omega_max * (t - t_ramp / 2.0))
    if t <= t_ramp: return omega_max * t * t / (2.0 * t_ramp)
    return omega_max * (t - t_ramp / 2.0)


target_theta_disengage = (x_rack_0 + rack_length / 2.0 - x_axle) / R_top
_theta_at_ramp_end = omega_max * t_ramp / 2.0
if target_theta_disengage <= _theta_at_ramp_end:
    t_disengage = np.sqrt(2.0 * t_ramp * target_theta_disengage / omega_max)
else:
    t_disengage = target_theta_disengage / omega_max + t_ramp / 2.0


def theta_top_int(t):
    if isinstance(t, np.ndarray):
        return theta_top_int_raw(np.minimum(t, t_disengage))
    return theta_top_int_raw(min(t, t_disengage))


def theta_top(t): return +theta_top_int(t)
def theta_mid(t): return -(R_top / R_mid) * theta_top(t)
def x_rack_centre(t): return x_rack_0 - R_top * theta_top(t)


def gear_polygon(cx, cy, R, N_teeth, theta=0.0):
    r_add = R + addendum; r_ded = R - dedendum
    pitch = 2.0 * np.pi / N_teeth
    phi = 0.5 * tooth_frac * pitch
    pts = np.empty((4 * N_teeth, 2))
    for i in range(N_teeth):
        theta_c = i * pitch + theta
        for k_, (r, dphi) in enumerate(((r_ded, -phi), (r_add, -phi),
                                          (r_add, +phi), (r_ded, +phi))):
            ang = theta_c + dphi
            pts[4 * i + k_, 0] = cx + r * np.cos(ang)
            pts[4 * i + k_, 1] = cy + r * np.sin(ang)
    return pts


def rack_polygon(cx, cy_pitch, length, height, pitch_x, x_offset=0.0):
    add_r = addendum; ded_r = dedendum
    half_tooth = 0.5 * tooth_frac * pitch_x
    x_left = cx - 0.5 * length; x_right = cx + 0.5 * length
    y_ded = cy_pitch - ded_r; y_add = cy_pitch + add_r
    y_bot = cy_pitch - ded_r - height
    k_min = int(np.floor((x_left - x_offset) / pitch_x)) - 1
    k_max = int(np.ceil((x_right - x_offset) / pitch_x)) + 1
    top_pts = [(x_left, y_ded)]
    for k in range(k_min, k_max + 1):
        xc = k * pitch_x + x_offset
        x0 = xc - half_tooth; x1 = xc + half_tooth
        if x1 < x_left or x0 > x_right: continue
        x0c = max(x0, x_left); x1c = min(x1, x_right)
        if x0 >= x_left:
            top_pts.append((x0c, y_ded)); top_pts.append((x0c, y_add))
        else:
            top_pts.append((x_left, y_add))
        if x1 <= x_right:
            top_pts.append((x1c, y_add)); top_pts.append((x1c, y_ded))
        else:
            top_pts.append((x_right, y_add))
    top_pts.append((x_right, y_ded))
    bot_pts = [(x_right, y_bot), (x_left, y_bot)]
    return np.array(top_pts + bot_pts)


cTop = np.array([x_axle, y_top])
cMid = np.array([x_axle, y_mid])
rack_disp_total = -R_top * theta_top_int(duration)
x_rack_min = x_rack_0 + rack_disp_total
x_rack_max = x_rack_0
rack_left_edge_min  = x_rack_min - 0.5 * rack_length
rack_right_edge_max = x_rack_max + 0.5 * rack_length

fig_w, fig_h = 12.0, 6.5
fig_aspect = fig_w / fig_h
x_lo_d = rack_left_edge_min - 0.30
x_hi_d = rack_right_edge_max + 0.30
y_lo_d = y_rack - rack_height - 0.30
y_hi_d = y_top + R_top + addendum + 1.30
dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
if dx / dy < fig_aspect:
    extra = (fig_aspect * dy - dx) / 2.0
    x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
    y_lo, y_hi = y_lo_d, y_hi_d
else:
    extra = (dx / fig_aspect - dy) / 2.0
    x_lo, x_hi = x_lo_d, x_hi_d
    y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0, 0, 1, 1])
ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")

ax.add_patch(Polygon([(x_lo, y_lo), (x_hi, y_lo),
                      (x_hi, y_rack - dedendum - rack_height - 0.04),
                      (x_lo, y_rack - dedendum - rack_height - 0.04)],
                      facecolor="#0f1525", edgecolor="none", zorder=0))

gear_pitch_mid = 2.0 * np.pi / N_mid
theta_mid_0 = -np.pi / 2 + np.pi / N_mid
theta_mid_0 -= np.floor(theta_mid_0 / gear_pitch_mid) * gear_pitch_mid
gear_pitch_top = 2.0 * np.pi / N_top
theta_top_0 = -np.pi / 2
theta_top_0 -= np.floor(theta_top_0 / gear_pitch_top) * gear_pitch_top
rack_phase_offset_0 = x_axle

gTop_patch = Polygon(gear_polygon(cTop[0], cTop[1], R_top, N_top, theta=theta_top_0),
                      facecolor="#a8dadc", edgecolor="#adb5bd", lw=1.2, zorder=4)
gMid_patch = Polygon(gear_polygon(cMid[0], cMid[1], R_mid, N_mid, theta=theta_mid_0),
                      facecolor="#a8dadc", edgecolor="#adb5bd", lw=1.2, zorder=4)
ax.add_patch(gTop_patch); ax.add_patch(gMid_patch)
ax.add_patch(Circle(cTop, R_top - dedendum * 1.4, facecolor="#3a4357",
                     edgecolor="none", zorder=4.2))
ax.add_patch(Circle(cMid, R_mid - dedendum * 1.5, facecolor="#3a4357",
                     edgecolor="none", zorder=4.2))
spokeTop_a, = ax.plot([], [], color="#e63946", lw=3.0, zorder=4.5)
spokeTop_b, = ax.plot([], [], color="#f9c74f", lw=2.5, zorder=4.5)
spokeMid_a, = ax.plot([], [], color="#e63946", lw=3.0, zorder=4.5)
spokeMid_b, = ax.plot([], [], color="#f9c74f", lw=2.5, zorder=4.5)
rack_patch = Polygon(rack_polygon(x_rack_0, y_rack, rack_length, rack_height,
                                    rack_pitch, x_offset=rack_phase_offset_0),
                      facecolor="#a8dadc", edgecolor="#adb5bd", lw=1.2, zorder=3.5)
ax.add_patch(rack_patch)
rack_hash_lc = LineCollection([], colors="#3a4357", linewidths=2.0, zorder=3.7)
ax.add_collection(rack_hash_lc)

y_top_off = y_hi + 0.10
n_arc = 60
arc_angles = np.linspace(np.pi, 2.0 * np.pi, n_arc)
arc_pts = np.column_stack([cTop[0] + r_pulley * np.cos(arc_angles),
                            cTop[1] + r_pulley * np.sin(arc_angles)])
belt_path = np.concatenate([
    [[cTop[0] - r_pulley, y_top_off]], arc_pts,
    [[cTop[0] + r_pulley, y_top_off]],
])
ax.plot(belt_path[:, 0], belt_path[:, 1], color="#4a4e69",
        lw=10, solid_capstyle="butt", zorder=6)
ax.plot(belt_path[:, 0], belt_path[:, 1], color="#3a4357",
        lw=7, solid_capstyle="butt", zorder=6.5)
ax.add_patch(Circle(cTop, r_pulley * 0.85, facecolor="#3a4357",
                     edgecolor="#adb5bd", lw=1.0, zorder=8))
ax.add_patch(Circle(cTop, 0.030, facecolor="#e63946",
                     edgecolor="#adb5bd", lw=0.8, zorder=9))
ax.add_patch(Circle(cMid, 0.030, facecolor="#e63946",
                     edgecolor="#adb5bd", lw=0.8, zorder=9))

rack_hash_spacing = 0.20

def update(f):
    t = f / fps
    th_top = theta_top_0 + theta_top(t)
    th_mid = theta_mid_0 + theta_mid(t)
    gTop_patch.set_xy(gear_polygon(cTop[0], cTop[1], R_top, N_top, theta=th_top))
    gMid_patch.set_xy(gear_polygon(cMid[0], cMid[1], R_mid, N_mid, theta=th_mid))
    rmTop = R_top + addendum * 0.5
    spokeTop_a.set_data([cTop[0], cTop[0] + rmTop * np.cos(th_top)],
                         [cTop[1], cTop[1] + rmTop * np.sin(th_top)])
    spokeTop_b.set_data([cTop[0], cTop[0] + rmTop * np.cos(th_top + np.pi/2)],
                         [cTop[1], cTop[1] + rmTop * np.sin(th_top + np.pi/2)])
    rmMid = R_mid + addendum * 0.5
    spokeMid_a.set_data([cMid[0], cMid[0] + rmMid * np.cos(th_mid)],
                         [cMid[1], cMid[1] + rmMid * np.sin(th_mid)])
    spokeMid_b.set_data([cMid[0], cMid[0] + rmMid * np.cos(th_mid + np.pi/2)],
                         [cMid[1], cMid[1] + rmMid * np.sin(th_mid + np.pi/2)])
    cx_rack = x_rack_centre(t)
    rack_disp = cx_rack - x_rack_0
    tooth_phase = rack_phase_offset_0 + rack_disp
    rack_patch.set_xy(rack_polygon(cx_rack, y_rack, rack_length, rack_height,
                                      rack_pitch, x_offset=tooth_phase))
    y_bot_top = y_rack - dedendum - rack_height
    x_left = cx_rack - 0.5 * rack_length
    x_right = cx_rack + 0.5 * rack_length
    n_marks = int(np.floor(rack_length / rack_hash_spacing))
    segs = []
    for k in range(n_marks):
        u_k = (k + 0.5) * rack_hash_spacing - 0.5 * rack_length
        xm = cx_rack + u_k
        if x_left + 0.02 <= xm <= x_right - 0.02:
            segs.append([(xm, y_bot_top + 0.01),
                         (xm, y_bot_top + rack_height * 0.85)])
    rack_hash_lc.set_segments(segs)
    return (gTop_patch, gMid_patch, rack_patch,
            spokeTop_a, spokeTop_b, spokeMid_a, spokeMid_b, rack_hash_lc)


n_frames = int(duration * fps) + 1
ani = animation.FuncAnimation(fig, update, frames=n_frames,
                              interval=1000.0/fps, blit=False)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    p = BeltGearRackTrainParams()
    t, y = simulate(p, duration=p.duration)
    render_video(t, y, p, "video.mp4")
