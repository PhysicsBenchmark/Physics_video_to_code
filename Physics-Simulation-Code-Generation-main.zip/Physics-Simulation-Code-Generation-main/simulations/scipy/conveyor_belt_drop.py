"""
Conveyor Belt Drop
==================
A cube is dropped onto a conveyor belt that moves rightward at v_belt; Coulomb
friction accelerates the cube to belt speed; it rides off the right edge,
falls to the floor, and slides to rest under floor friction.

Five closed-form analytic phases:
  1. Free fall onto the belt
  2. Slipping on belt (mu_belt) until v_x = v_belt
  3. No-slip ride to the belt's right edge
  4. Free fall to floor (vx = v_belt conserved)
  5. Slide on floor (mu_floor) to rest
"""

from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle, Circle, Polygon
from matplotlib.collections import LineCollection
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class ConveyorBeltDropParams:
    g: float = 9.81
    v_belt: float = 1.20
    mu_belt: float = 0.30
    mu_floor: float = 0.30
    m_cube: float = 0.50
    x_belt_left: float = 0.30
    x_belt_right: float = 1.80
    y_belt_top: float = 1.00
    r_pulley: float = 0.07
    cube_size: float = 0.18
    x_drop: float = 0.55
    y_drop_top: float = 1.55


def _phase_table(p: ConveyorBeltDropParams):
    g = p.g
    fall_dist_1 = (p.y_drop_top - p.cube_size) - p.y_belt_top
    t1_dur = float(np.sqrt(max(2.0 * fall_dist_1 / g, 0.0)))
    a_friction = p.mu_belt * g
    t2_dur = p.v_belt / a_friction if a_friction > 0 else 0.0
    dx2 = 0.5 * a_friction * t2_dur ** 2
    x_at_p3 = p.x_drop + dx2
    t3_dur = max(0.0, (p.x_belt_right - x_at_p3) / p.v_belt) if p.v_belt > 0 else 0.0
    fall_dist_4 = p.y_belt_top
    t4_dur = float(np.sqrt(2.0 * fall_dist_4 / g))
    dx4 = p.v_belt * t4_dur
    a_floor = p.mu_floor * g
    t5_dur = p.v_belt / a_floor if a_floor > 0 else 0.0
    dx5 = p.v_belt ** 2 / (2.0 * a_floor) if a_floor > 0 else 0.0
    t1_end = t1_dur
    t2_end = t1_end + t2_dur
    t3_end = t2_end + t3_dur
    t4_end = t3_end + t4_dur
    t5_end = t4_end + t5_dur
    return {
        "t1_end": t1_end, "t2_end": t2_end, "t3_end": t3_end,
        "t4_end": t4_end, "t5_end": t5_end,
        "a_friction": a_friction, "a_floor": a_floor,
        "x_at_p3": x_at_p3, "dx4": dx4, "dx5": dx5,
        "fall_dist_1": fall_dist_1, "fall_dist_4": fall_dist_4,
    }


def simulate(
    params: ConveyorBeltDropParams,
    duration: float = 6.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    p = params
    tab = _phase_table(p)
    t1, t2, t3, t4, t5 = tab["t1_end"], tab["t2_end"], tab["t3_end"], tab["t4_end"], tab["t5_end"]

    n_frames = int(duration * fps) + 1
    t_eval = np.linspace(0.0, duration, n_frames)
    cx = np.zeros(n_frames); cy = np.zeros(n_frames)
    for i, t in enumerate(t_eval):
        if t <= t1:
            cx[i] = p.x_drop
            cy[i] = (p.y_drop_top - p.cube_size / 2) - 0.5 * p.g * t ** 2
        elif t <= t2:
            dt = t - t1
            cx[i] = p.x_drop + 0.5 * tab["a_friction"] * dt ** 2
            cy[i] = p.y_belt_top + p.cube_size / 2
        elif t <= t3:
            dt = t - t2
            cx[i] = tab["x_at_p3"] + p.v_belt * dt
            cy[i] = p.y_belt_top + p.cube_size / 2
        elif t <= t4:
            dt = t - t3
            cx[i] = p.x_belt_right + p.v_belt * dt
            cy[i] = (p.y_belt_top + p.cube_size / 2) - 0.5 * p.g * dt ** 2
        elif t <= t5:
            dt = t - t4
            cx[i] = p.x_belt_right + tab["dx4"] + p.v_belt * dt - 0.5 * tab["a_floor"] * dt ** 2
            cy[i] = p.cube_size / 2
        else:
            cx[i] = p.x_belt_right + tab["dx4"] + tab["dx5"]
            cy[i] = p.cube_size / 2
    return t_eval, np.vstack([cx, cy])


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: ConveyorBeltDropParams,
    output_path: str,
    fps: int = 30,
) -> None:
    p = params
    cx_arr, cy_arr = y[0], y[1]
    tab = _phase_table(p)
    fig_w, fig_h = 11.0, 6.0
    fig_aspect = fig_w / fig_h
    x_lo_d = -0.20
    x_hi_d = p.x_belt_right + tab["dx4"] + tab["dx5"] + 0.30
    y_lo_d = -0.25
    y_hi_d = p.y_drop_top + 0.20
    dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_d / dy_d < fig_aspect:
        extra = (fig_aspect * dy_d - dx_d) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx_d / fig_aspect - dy_d) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    ax.add_patch(Polygon([(x_lo, y_lo), (x_hi, y_lo), (x_hi, 0.0), (x_lo, 0.0)],
                         facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.plot([x_lo, x_hi], [0.0, 0.0], color="#adb5bd", lw=2.0, zorder=1)

    y_pulley_c = p.y_belt_top - p.r_pulley
    ax.plot([p.x_belt_left, p.x_belt_right], [p.y_belt_top, p.y_belt_top],
            color="#4a4e69", lw=10, solid_capstyle="butt", zorder=2)
    ax.plot([p.x_belt_left, p.x_belt_right],
            [p.y_belt_top - 2 * p.r_pulley, p.y_belt_top - 2 * p.r_pulley],
            color="#4a4e69", lw=10, solid_capstyle="butt", zorder=2)
    ax.add_patch(Circle((p.x_belt_left, y_pulley_c), p.r_pulley,
                        facecolor="#3a4357", edgecolor="#adb5bd", lw=1.2, zorder=3))
    ax.add_patch(Circle((p.x_belt_right, y_pulley_c), p.r_pulley,
                        facecolor="#3a4357", edgecolor="#adb5bd", lw=1.2, zorder=3))

    hash_spacing = 0.12
    hash_w = 0.025
    hash_lc = LineCollection([], colors="#adb5bd", linewidths=2.0, zorder=4)
    ax.add_collection(hash_lc)

    cube_patch = Rectangle((0, 0), p.cube_size, p.cube_size,
                           facecolor="#e63946", edgecolor="#adb5bd", lw=1.2, zorder=5)
    ax.add_patch(cube_patch)

    def update(f):
        cx, cy = cx_arr[f], cy_arr[f]
        cube_patch.set_xy((cx - p.cube_size / 2, cy - p.cube_size / 2))
        s0 = (p.v_belt * t[f]) % hash_spacing
        span = p.x_belt_right - p.x_belt_left
        n_marks = int(np.ceil(span / hash_spacing)) + 1
        segs = []
        for k in range(n_marks):
            x_m = p.x_belt_left + s0 + k * hash_spacing
            if p.x_belt_left <= x_m <= p.x_belt_right:
                segs.append([(x_m, p.y_belt_top - hash_w), (x_m, p.y_belt_top + hash_w)])
            x_m_b = p.x_belt_right - s0 - k * hash_spacing
            if p.x_belt_left <= x_m_b <= p.x_belt_right:
                y_b = p.y_belt_top - 2 * p.r_pulley
                segs.append([(x_m_b, y_b - hash_w), (x_m_b, y_b + hash_w)])
        hash_lc.set_segments(segs)
        return cube_patch, hash_lc

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0 / fps, blit=False)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: ConveyorBeltDropParams, duration: float = 6.0) -> str:
    p = asdict(params)
    return f'''"""
Conveyor Belt Drop — auto-generated.
"""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle, Circle, Polygon
from matplotlib.collections import LineCollection

g            = {p["g"]}
v_belt       = {p["v_belt"]}
mu_belt      = {p["mu_belt"]}
mu_floor     = {p["mu_floor"]}
m_cube       = {p["m_cube"]}
x_belt_left  = {p["x_belt_left"]}
x_belt_right = {p["x_belt_right"]}
y_belt_top   = {p["y_belt_top"]}
r_pulley     = {p["r_pulley"]}
cube_size    = {p["cube_size"]}
x_drop       = {p["x_drop"]}
y_drop_top   = {p["y_drop_top"]}
duration     = {duration}
fps          = 30

fall_dist_1 = (y_drop_top - cube_size) - y_belt_top
t1_dur = np.sqrt(max(2.0 * fall_dist_1 / g, 0.0))
a_friction = mu_belt * g
t2_dur = v_belt / a_friction if a_friction > 0 else 0.0
dx2 = 0.5 * a_friction * t2_dur ** 2
x_at_phase3_start = x_drop + dx2
t3_dur = max(0.0, (x_belt_right - x_at_phase3_start) / v_belt) if v_belt > 0 else 0.0
fall_dist_4 = y_belt_top
t4_dur = np.sqrt(2.0 * fall_dist_4 / g)
dx4 = v_belt * t4_dur
a_floor = mu_floor * g
t5_dur = v_belt / a_floor if a_floor > 0 else 0.0
dx5 = v_belt ** 2 / (2.0 * a_floor) if a_floor > 0 else 0.0
t1_end = t1_dur
t2_end = t1_end + t2_dur
t3_end = t2_end + t3_dur
t4_end = t3_end + t4_dur
t5_end = t4_end + t5_dur

def cube_com(t):
    if t <= t1_end:
        return (x_drop, (y_drop_top - cube_size/2) - 0.5*g*t**2)
    if t <= t2_end:
        dt = t - t1_end
        return (x_drop + 0.5*a_friction*dt**2, y_belt_top + cube_size/2)
    if t <= t3_end:
        dt = t - t2_end
        return (x_at_phase3_start + v_belt*dt, y_belt_top + cube_size/2)
    if t <= t4_end:
        dt = t - t3_end
        return (x_belt_right + v_belt*dt, (y_belt_top + cube_size/2) - 0.5*g*dt**2)
    if t <= t5_end:
        dt = t - t4_end
        return (x_belt_right + dx4 + v_belt*dt - 0.5*a_floor*dt**2, cube_size/2)
    return (x_belt_right + dx4 + dx5, cube_size/2)

fig_w, fig_h = 11.0, 6.0
fig_aspect = fig_w / fig_h
x_lo_d = -0.20
x_hi_d = x_belt_right + dx4 + dx5 + 0.30
y_lo_d = -0.25
y_hi_d = y_drop_top + 0.20
dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
if dx_d / dy_d < fig_aspect:
    extra = (fig_aspect * dy_d - dx_d) / 2.0
    x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
    y_lo, y_hi = y_lo_d, y_hi_d
else:
    extra = (dx_d / fig_aspect - dy_d) / 2.0
    x_lo, x_hi = x_lo_d, x_hi_d
    y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0, 0, 1, 1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(Polygon([(x_lo, y_lo), (x_hi, y_lo), (x_hi, 0.0), (x_lo, 0.0)],
                     facecolor="#4a4e69", edgecolor="none", zorder=0))
ax.plot([x_lo, x_hi], [0.0, 0.0], color="#adb5bd", lw=2.0, zorder=1)
y_pulley_c = y_belt_top - r_pulley
ax.plot([x_belt_left, x_belt_right], [y_belt_top, y_belt_top],
        color="#4a4e69", lw=10, solid_capstyle="butt", zorder=2)
ax.plot([x_belt_left, x_belt_right], [y_belt_top - 2*r_pulley, y_belt_top - 2*r_pulley],
        color="#4a4e69", lw=10, solid_capstyle="butt", zorder=2)
ax.add_patch(Circle((x_belt_left, y_pulley_c), r_pulley, facecolor="#3a4357", edgecolor="#adb5bd", lw=1.2, zorder=3))
ax.add_patch(Circle((x_belt_right, y_pulley_c), r_pulley, facecolor="#3a4357", edgecolor="#adb5bd", lw=1.2, zorder=3))

hash_spacing = 0.12; hash_w = 0.025
hash_lc = LineCollection([], colors="#adb5bd", linewidths=2.0, zorder=4)
ax.add_collection(hash_lc)

cube_patch = Rectangle((0, 0), cube_size, cube_size, facecolor="#e63946",
                       edgecolor="#adb5bd", lw=1.2, zorder=5)
ax.add_patch(cube_patch)

def update(f):
    t = f / fps
    cx, cy = cube_com(t)
    cube_patch.set_xy((cx - cube_size/2, cy - cube_size/2))
    s0 = (v_belt * t) % hash_spacing
    span = x_belt_right - x_belt_left
    n_marks = int(np.ceil(span / hash_spacing)) + 1
    segs = []
    for k in range(n_marks):
        x_m = x_belt_left + s0 + k * hash_spacing
        if x_belt_left <= x_m <= x_belt_right:
            segs.append([(x_m, y_belt_top - hash_w), (x_m, y_belt_top + hash_w)])
        x_m_b = x_belt_right - s0 - k * hash_spacing
        if x_belt_left <= x_m_b <= x_belt_right:
            y_b = y_belt_top - 2 * r_pulley
            segs.append([(x_m_b, y_b - hash_w), (x_m_b, y_b + hash_w)])
    hash_lc.set_segments(segs)
    return cube_patch, hash_lc

n_frames = int(duration * fps) + 1
ani = animation.FuncAnimation(fig, update, frames=n_frames, interval=1000.0/fps, blit=False)
ani.save("conveyor_belt_drop.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close(); print("Saved conveyor_belt_drop.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Conveyor Belt Drop")
    for k, v in asdict(ConveyorBeltDropParams()).items():
        parser.add_argument(f"--{k}", type=float, default=v)
    parser.add_argument("--duration", type=float, default=6.0)
    parser.add_argument("--output", type=str, default="conveyor_belt_drop.mp4")
    args = parser.parse_args()
    fields = {k: getattr(args, k) for k in asdict(ConveyorBeltDropParams()).keys()}
    p = ConveyorBeltDropParams(**fields)
    print(f"Simulating conveyor belt drop: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
