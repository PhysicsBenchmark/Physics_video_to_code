"""
Moveable Pendulum Simulation
=============================
Faithfully translated from myphysicslab/src/sims/pendulum/MoveablePendulumSim.ts

Physical Law: Pendulum hanging from a sinusoidally-driven anchor point.
The anchor moves vertically: y_anchor(t) = A_drive * sin(omega_drive * t)
No mouse interaction — purely analytical sinusoidal driving.

Equation of motion (from MoveablePendulumSim.ts evaluate()):

    dtheta/dt = omega

    domega/dt = -(g/R)*sin(theta)
                - (b / (m*R^2)) * omega
                - (ddx0/R)*cos(theta)
                - (ddy0/R)*sin(theta)

where for purely vertical driving (ddx0 = 0):
    ddy0 = anchor_yddot = -A_drive * omega_drive^2 * sin(omega_drive * t)

State vector: [theta, omega]
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from dataclasses import dataclass, asdict
import sys, os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from .draw_utils import setup_dark_axis


@dataclass
class MoveablePendulumParams:
    R: float          = 1.0    # length of pendulum rod (m)
    m: float          = 1.0    # mass of pendulum bob (kg)
    g: float          = 9.8    # gravitational acceleration (m/s²)
    b: float          = 0.5    # damping coefficient
    theta0: float     = 0.3    # initial angle (rad)
    omega0: float     = 0.0    # initial angular velocity (rad/s)
    A_drive: float    = 0.5    # amplitude of anchor vertical oscillation (m)
    omega_drive: float = 3.0   # angular frequency of anchor oscillation (rad/s)


def ode(t: float, y: list, p: MoveablePendulumParams):
    """
    Exact translation of MoveablePendulumSim.ts evaluate() method.
    Anchor moves vertically only: ddx0 = 0, ddy0 = -A*omega^2*sin(omega*t).

    change[ANGLEP] = -(g/R)*sin(theta)
                     - (b/(m*R^2))*omega
                     - (ddx0/R)*cos(theta)   [= 0, no horizontal driving]
                     - (ddy0/R)*sin(theta)
    """
    theta, omega = y
    R, m, g, b = p.R, p.m, p.g, p.b

    # Anchor acceleration: vertical only
    ddy0 = -p.A_drive * p.omega_drive**2 * np.sin(p.omega_drive * t)
    ddx0 = 0.0

    dtheta = omega
    domega = (-(g / R) * np.sin(theta)
              - (b / (m * R * R)) * omega
              - (ddx0 / R) * np.cos(theta)
              - (ddy0 / R) * np.sin(theta))

    return [dtheta, domega]


def simulate(
    params: MoveablePendulumParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Integrate using RK45. Returns (t, y) with y.shape = (2, N)."""
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode,
        (0, duration),
        [params.theta0, params.omega0],
        t_eval=t_eval,
        args=(params,),
        method="RK45",
        rtol=1e-8,
        atol=1e-10,
    )
    return sol.t, sol.y


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: MoveablePendulumParams,
    output_path: str,
    fps: int = 30,
) -> None:
    """Render animated moveable pendulum. Anchor oscillates vertically."""
    theta, _ = y
    R = params.R

    # Anchor position over time (vertical oscillation)
    anchor_y = params.A_drive * np.sin(params.omega_drive * t)
    anchor_x = np.zeros_like(anchor_y)

    # Bob position relative to world
    bob_x = anchor_x + R * np.sin(theta)
    bob_y = anchor_y - R * np.cos(theta)

    pad = R * 0.3
    lim = R + params.A_drive + pad
    xlim = (-lim, lim)
    ylim = (-lim * 1.2, lim * 0.6)

    fig, ax = plt.subplots(figsize=(8, 6))
    setup_dark_axis(fig, ax, xlim, ylim)

    # Static reference cross for world origin
    ax.plot([0], [0], "+", color="#ffffff", ms=8, alpha=0.4, zorder=2)

    (anchor_dot,) = ax.plot([], [], "s", color="#f4d35e", ms=10, zorder=5)
    (rod,)        = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
    (bob,)        = ax.plot([], [], "o", color="#e63946", ms=13, zorder=4)
    (trail,)      = ax.plot([], [], "-", color="#e63946", alpha=0.35, lw=1.0, zorder=2)

    tx: list = []
    ty: list = []
    TRAIL = 120

    def init():
        for obj in [anchor_dot, rod, bob, trail]:
            obj.set_data([], [])
        return anchor_dot, rod, bob, trail

    def update(frame):
        ax_x = anchor_x[frame]
        ay_y = anchor_y[frame]
        bx   = bob_x[frame]
        by   = bob_y[frame]

        anchor_dot.set_data([ax_x], [ay_y])
        rod.set_data([ax_x, bx], [ay_y, by])
        bob.set_data([bx], [by])

        tx.append(bx)
        ty.append(by)
        if len(tx) > TRAIL:
            tx.pop(0)
            ty.pop(0)
        trail.set_data(tx, ty)
        return anchor_dot, rod, bob, trail

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), init_func=init, interval=1000 / fps, blit=True
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=133)   # ~800x600 at 6in x 6in * 133dpi
    plt.close(fig)


def make_standalone_script(params: MoveablePendulumParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""
Moveable Pendulum — auto-generated simulation script.
Physics (anchor driven vertically: y0 = A*sin(omega_drive*t)):
    dtheta/dt = omega
    domega/dt = -(g/R)*sin(theta) - (b/(m*R^2))*omega - (ddy0/R)*sin(theta)
    ddy0 = -A_drive * omega_drive^2 * sin(omega_drive * t)
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation

R           = {p["R"]}
m           = {p["m"]}
g           = {p["g"]}
b           = {p["b"]}
theta0      = {p["theta0"]:.6f}
omega0      = {p["omega0"]:.6f}
A_drive     = {p["A_drive"]}
omega_drive = {p["omega_drive"]}
duration    = {duration}

def ode(t, y):
    theta, omega = y
    ddy0 = -A_drive * omega_drive**2 * np.sin(omega_drive * t)
    dtheta = omega
    domega = (-(g/R)*np.sin(theta)
              - (b/(m*R*R))*omega
              - (ddy0/R)*np.sin(theta))
    return [dtheta, domega]

fps    = 30
t_eval = np.linspace(0, duration, int(duration*fps)+1)
sol    = solve_ivp(ode, (0, duration), [theta0, omega0],
                   t_eval=t_eval, method="RK45", rtol=1e-8, atol=1e-10)
theta = sol.y[0]
anchor_y = A_drive * np.sin(omega_drive * sol.t)
bob_x    = np.sin(theta) * R
bob_y    = anchor_y - np.cos(theta) * R

lim = R + A_drive + 0.3
fig, ax = plt.subplots(figsize=(8, 6), facecolor="#1a1a2e")
ax.set_facecolor("#16213e"); ax.set_xlim(-lim, lim); ax.set_ylim(-lim*1.2, lim*0.6)
ax.set_aspect("equal"); ax.axis("off")
ax.plot([0],[0],"+",color="white",ms=8,alpha=0.4,zorder=2)
anchor_dot, = ax.plot([],[],"s",color="#f4d35e",ms=10,zorder=5)
rod,        = ax.plot([],[],"-",color="#a8dadc",lw=2.5,zorder=3)
bob_plt,    = ax.plot([],[],"o",color="#e63946",ms=13,zorder=4)
trail,      = ax.plot([],[],"-",color="#e63946",alpha=0.35,lw=1.0,zorder=2)
tx, ty = [], []

def update(f):
    ax_x, ay_y = 0, anchor_y[f]
    bx, by = bob_x[f], bob_y[f]
    anchor_dot.set_data([ax_x],[ay_y])
    rod.set_data([ax_x,bx],[ay_y,by])
    bob_plt.set_data([bx],[by])
    tx.append(bx); ty.append(by)
    if len(tx)>120: tx.pop(0); ty.pop(0)
    trail.set_data(tx,ty)
    return anchor_dot, rod, bob_plt, trail

ani = animation.FuncAnimation(fig, update, frames=len(sol.t), interval=1000/fps, blit=True)
ani.save("moveable_pendulum.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=133)
plt.close(); print("Saved moveable_pendulum.mp4")
'''


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Moveable Pendulum Simulation")
    parser.add_argument("--R",           type=float, default=1.0)
    parser.add_argument("--m",           type=float, default=1.0)
    parser.add_argument("--g",           type=float, default=9.8)
    parser.add_argument("--b",           type=float, default=0.5)
    parser.add_argument("--theta0",      type=float, default=0.3)
    parser.add_argument("--omega0",      type=float, default=0.0)
    parser.add_argument("--A_drive",     type=float, default=0.5)
    parser.add_argument("--omega_drive", type=float, default=3.0)
    parser.add_argument("--duration",    type=float, default=12.0)
    parser.add_argument("--output",      type=str,   default="moveable_pendulum.mp4")
    args = parser.parse_args()

    p = MoveablePendulumParams(
        R=args.R, m=args.m, g=args.g, b=args.b,
        theta0=args.theta0, omega0=args.omega0,
        A_drive=args.A_drive, omega_drive=args.omega_drive,
    )
    print(f"Simulating moveable pendulum: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")


if __name__ == "__main__":
    main()
