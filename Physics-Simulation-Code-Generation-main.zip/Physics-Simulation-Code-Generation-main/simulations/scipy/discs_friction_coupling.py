"""
Discs Friction Coupling
========================
Top-down view of two solid discs spinning on parallel axles.  Disc 2's axle is
slowly translated toward disc 1 (approach phase), then a constant normal force
holds them in contact while Coulomb friction decelerates the slip until
omega_1 R_1 + omega_2 R_2 = 0 (gear-like no-slip condition).
"""

from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Circle
from matplotlib.collections import LineCollection
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class DiscsFrictionCouplingParams:
    m_1: float = 0.50
    m_2: float = 0.30
    R_1: float = 0.40
    R_2: float = 0.25
    omega_1_0: float = 8.0
    omega_2_0: float = 12.0
    mu_k: float = 0.05
    F_n: float = 3.0
    gap_0: float = 0.30
    approach_speed: float = 0.10


def _phase_table(p: DiscsFrictionCouplingParams):
    I_1 = 0.5 * p.m_1 * p.R_1 ** 2
    I_2 = 0.5 * p.m_2 * p.R_2 ** 2
    X_1 = 0.0
    X_2_initial = X_1 + p.R_1 + p.R_2 + p.gap_0
    t_approach = p.gap_0 / p.approach_speed
    s_0 = -(p.omega_1_0 * p.R_1 + p.omega_2_0 * p.R_2)
    denom = p.mu_k * p.F_n * (p.R_1 ** 2 / I_1 + p.R_2 ** 2 / I_2)
    if denom <= 0:
        delta_t_slip = 0.0
    else:
        delta_t_slip = abs(s_0) / denom
    t_no_slip = t_approach + delta_t_slip
    sign_s0 = np.sign(s_0) if s_0 != 0 else 0.0
    alpha_1 = p.R_1 * p.mu_k * p.F_n * sign_s0 / I_1
    alpha_2 = p.R_2 * p.mu_k * p.F_n * sign_s0 / I_2
    omega_1_final = p.omega_1_0 + alpha_1 * delta_t_slip
    omega_2_final = p.omega_2_0 + alpha_2 * delta_t_slip
    return {
        "I_1": I_1, "I_2": I_2, "X_1": X_1, "X_2_initial": X_2_initial,
        "t_approach": t_approach, "delta_t_slip": delta_t_slip,
        "t_no_slip": t_no_slip, "alpha_1": alpha_1, "alpha_2": alpha_2,
        "omega_1_final": omega_1_final, "omega_2_final": omega_2_final,
        "s_0": s_0,
    }


def simulate(
    params: DiscsFrictionCouplingParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    p = params
    tab = _phase_table(p)
    t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)

    cx2 = np.empty_like(t_eval)
    phi1 = np.empty_like(t_eval)
    phi2 = np.empty_like(t_eval)
    omega1 = np.empty_like(t_eval)
    omega2 = np.empty_like(t_eval)

    t_app = tab["t_approach"]; t_ns = tab["t_no_slip"]
    a1 = tab["alpha_1"]; a2 = tab["alpha_2"]
    of1 = tab["omega_1_final"]; of2 = tab["omega_2_final"]
    X_1 = tab["X_1"]; X2i = tab["X_2_initial"]

    for i, t in enumerate(t_eval):
        if t < t_app:
            cx2[i] = X2i - p.approach_speed * t
        else:
            cx2[i] = X_1 + p.R_1 + p.R_2

        if t <= t_app:
            omega1[i] = p.omega_1_0
            omega2[i] = p.omega_2_0
            phi1[i] = p.omega_1_0 * t
            phi2[i] = p.omega_2_0 * t
        elif t <= t_ns:
            dt = t - t_app
            omega1[i] = p.omega_1_0 + a1 * dt
            omega2[i] = p.omega_2_0 + a2 * dt
            phi1[i] = p.omega_1_0 * t_app + p.omega_1_0 * dt + 0.5 * a1 * dt ** 2
            phi2[i] = p.omega_2_0 * t_app + p.omega_2_0 * dt + 0.5 * a2 * dt ** 2
        else:
            dt_slip = t_ns - t_app
            base1 = p.omega_1_0 * t_app + p.omega_1_0 * dt_slip + 0.5 * a1 * dt_slip ** 2
            base2 = p.omega_2_0 * t_app + p.omega_2_0 * dt_slip + 0.5 * a2 * dt_slip ** 2
            omega1[i] = of1
            omega2[i] = of2
            phi1[i] = base1 + of1 * (t - t_ns)
            phi2[i] = base2 + of2 * (t - t_ns)

    y = np.vstack([cx2, phi1, phi2, omega1, omega2])
    return t_eval, y


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: DiscsFrictionCouplingParams,
    output_path: str,
    fps: int = 30,
) -> None:
    p = params
    cx2_arr, phi1_arr, phi2_arr = y[0], y[1], y[2]
    R_1, R_2 = p.R_1, p.R_2
    X_1 = 0.0
    X_2_initial = X_1 + R_1 + R_2 + p.gap_0

    pad = 0.35
    x_lo_d = X_1 - R_1 - pad
    x_hi_d = X_2_initial + R_2 + pad
    y_lo_d = -max(R_1, R_2) - pad
    y_hi_d = +max(R_1, R_2) + pad
    fig_w, fig_h = 10.0, 5.0
    fig_aspect = fig_w / fig_h
    dx = x_hi_d - x_lo_d; dy = y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    disc1_patch = Circle((X_1, 0.0), R_1, facecolor="#80c0ff", edgecolor="#ffffff",
                         lw=1.6, zorder=3)
    disc2_patch = Circle((cx2_arr[0], 0.0), R_2, facecolor="#ffd166",
                         edgecolor="#ffffff", lw=1.6, zorder=3)
    ax.add_patch(disc1_patch); ax.add_patch(disc2_patch)

    axle1_dot = Circle((X_1, 0.0), 0.022, facecolor="#1a1a2e",
                       edgecolor="#ffffff", lw=0.8, zorder=6)
    axle2_dot = Circle((cx2_arr[0], 0.0), 0.022, facecolor="#1a1a2e",
                       edgecolor="#ffffff", lw=0.8, zorder=6)
    ax.add_patch(axle1_dot); ax.add_patch(axle2_dot)

    N_TICKS = 6
    ticks1_lc = LineCollection([], colors="#1a1a2e", linewidths=2.8, zorder=5)
    ticks2_lc = LineCollection([], colors="#1a1a2e", linewidths=2.8, zorder=5)
    ax.add_collection(ticks1_lc); ax.add_collection(ticks2_lc)
    hi_tick1, = ax.plot([], [], color="#e63946", lw=3.4, zorder=5.5)
    hi_tick2, = ax.plot([], [], color="#e63946", lw=3.4, zorder=5.5)

    def radial_tick_segments(cx, cy, R, phi, n=N_TICKS, inner_frac=0.12):
        angles = phi + 2.0 * np.pi * np.arange(n) / n
        r0 = inner_frac * R; r1 = R * 0.97
        segs = np.empty((n, 2, 2))
        segs[:, 0, 0] = cx + r0 * np.cos(angles)
        segs[:, 0, 1] = cy + r0 * np.sin(angles)
        segs[:, 1, 0] = cx + r1 * np.cos(angles)
        segs[:, 1, 1] = cy + r1 * np.sin(angles)
        return segs

    def update(f):
        cx2 = cx2_arr[f]
        disc2_patch.center = (cx2, 0.0)
        axle2_dot.center = (cx2, 0.0)
        th1 = phi1_arr[f]; th2 = phi2_arr[f]
        ticks1_lc.set_segments(radial_tick_segments(X_1, 0.0, R_1, th1))
        ticks2_lc.set_segments(radial_tick_segments(cx2, 0.0, R_2, th2))
        hi_tick1.set_data([X_1 + 0.12 * R_1 * np.cos(th1),
                           X_1 + 0.97 * R_1 * np.cos(th1)],
                          [0.0 + 0.12 * R_1 * np.sin(th1),
                           0.0 + 0.97 * R_1 * np.sin(th1)])
        hi_tick2.set_data([cx2 + 0.12 * R_2 * np.cos(th2),
                           cx2 + 0.97 * R_2 * np.cos(th2)],
                          [0.0 + 0.12 * R_2 * np.sin(th2),
                           0.0 + 0.97 * R_2 * np.sin(th2)])
        return (disc1_patch, disc2_patch, axle1_dot, axle2_dot,
                ticks1_lc, ticks2_lc, hi_tick1, hi_tick2)

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0 / fps, blit=False)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=2400), dpi=120)
    plt.close(fig)


def make_standalone_script(params: DiscsFrictionCouplingParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""
Discs Friction Coupling — auto-generated.
"""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Circle
from matplotlib.collections import LineCollection

m_1 = {p["m_1"]}
m_2 = {p["m_2"]}
R_1 = {p["R_1"]}
R_2 = {p["R_2"]}
omega_1_0 = {p["omega_1_0"]}
omega_2_0 = {p["omega_2_0"]}
mu_k = {p["mu_k"]}
F_n  = {p["F_n"]}
gap_0 = {p["gap_0"]}
approach_speed = {p["approach_speed"]}
duration = {duration}
fps = 30

I_1 = 0.5 * m_1 * R_1 ** 2
I_2 = 0.5 * m_2 * R_2 ** 2
X_1_fixed = 0.0
X_2_initial = X_1_fixed + R_1 + R_2 + gap_0
t_approach = gap_0 / approach_speed
s_0 = -(omega_1_0 * R_1 + omega_2_0 * R_2)
denom = mu_k * F_n * (R_1 ** 2 / I_1 + R_2 ** 2 / I_2)
delta_t_slip = abs(s_0) / denom if denom > 0 else 0.0
t_no_slip = t_approach + delta_t_slip
sign_s0 = np.sign(s_0)
alpha_1 = R_1 * mu_k * F_n * sign_s0 / I_1
alpha_2 = R_2 * mu_k * F_n * sign_s0 / I_2
omega_1_final = omega_1_0 + alpha_1 * delta_t_slip
omega_2_final = omega_2_0 + alpha_2 * delta_t_slip

def disc2_centre_x(t):
    if t < t_approach: return X_2_initial - approach_speed * t
    return X_1_fixed + R_1 + R_2

def phi_1(t):
    if t <= t_approach: return omega_1_0 * t
    base = omega_1_0 * t_approach
    if t <= t_no_slip:
        dt = t - t_approach
        return base + omega_1_0 * dt + 0.5 * alpha_1 * dt ** 2
    dt_slip = t_no_slip - t_approach
    base_slip = base + omega_1_0 * dt_slip + 0.5 * alpha_1 * dt_slip ** 2
    return base_slip + omega_1_final * (t - t_no_slip)

def phi_2(t):
    if t <= t_approach: return omega_2_0 * t
    base = omega_2_0 * t_approach
    if t <= t_no_slip:
        dt = t - t_approach
        return base + omega_2_0 * dt + 0.5 * alpha_2 * dt ** 2
    dt_slip = t_no_slip - t_approach
    base_slip = base + omega_2_0 * dt_slip + 0.5 * alpha_2 * dt_slip ** 2
    return base_slip + omega_2_final * (t - t_no_slip)

pad = 0.35
x_lo_d = X_1_fixed - R_1 - pad
x_hi_d = X_2_initial + R_2 + pad
y_lo_d = -max(R_1, R_2) - pad
y_hi_d = +max(R_1, R_2) + pad
fig_w, fig_h = 10.0, 5.0
fig_aspect = fig_w / fig_h
dx = x_hi_d - x_lo_d; dy = y_hi_d - y_lo_d
if dx / dy < fig_aspect:
    extra = (fig_aspect * dy - dx) / 2.0
    x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
else:
    extra = (dx / fig_aspect - dy) / 2.0
    x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0, 0, 1, 1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")

disc1_patch = Circle((X_1_fixed, 0.0), R_1, facecolor="#80c0ff", edgecolor="#ffffff", lw=1.6, zorder=3)
disc2_patch = Circle((X_2_initial, 0.0), R_2, facecolor="#ffd166", edgecolor="#ffffff", lw=1.6, zorder=3)
ax.add_patch(disc1_patch); ax.add_patch(disc2_patch)
axle1_dot = Circle((X_1_fixed, 0.0), 0.022, facecolor="#1a1a2e", edgecolor="#ffffff", lw=0.8, zorder=6)
axle2_dot = Circle((X_2_initial, 0.0), 0.022, facecolor="#1a1a2e", edgecolor="#ffffff", lw=0.8, zorder=6)
ax.add_patch(axle1_dot); ax.add_patch(axle2_dot)

N_TICKS = 6
ticks1_lc = LineCollection([], colors="#1a1a2e", linewidths=2.8, zorder=5)
ticks2_lc = LineCollection([], colors="#1a1a2e", linewidths=2.8, zorder=5)
ax.add_collection(ticks1_lc); ax.add_collection(ticks2_lc)
hi_tick1, = ax.plot([], [], color="#e63946", lw=3.4, zorder=5.5)
hi_tick2, = ax.plot([], [], color="#e63946", lw=3.4, zorder=5.5)

def radial_tick_segments(cx, cy, R, phi, n=N_TICKS, inner_frac=0.12):
    angles = phi + 2.0 * np.pi * np.arange(n) / n
    r0 = inner_frac * R; r1 = R * 0.97
    segs = np.empty((n, 2, 2))
    segs[:, 0, 0] = cx + r0 * np.cos(angles); segs[:, 0, 1] = cy + r0 * np.sin(angles)
    segs[:, 1, 0] = cx + r1 * np.cos(angles); segs[:, 1, 1] = cy + r1 * np.sin(angles)
    return segs

def update(f):
    t = f / fps
    cx2 = disc2_centre_x(t)
    disc2_patch.center = (cx2, 0.0); axle2_dot.center = (cx2, 0.0)
    th1 = phi_1(t); th2 = phi_2(t)
    ticks1_lc.set_segments(radial_tick_segments(X_1_fixed, 0.0, R_1, th1))
    ticks2_lc.set_segments(radial_tick_segments(cx2, 0.0, R_2, th2))
    hi_tick1.set_data([X_1_fixed + 0.12*R_1*np.cos(th1), X_1_fixed + 0.97*R_1*np.cos(th1)],
                      [0.0 + 0.12*R_1*np.sin(th1), 0.0 + 0.97*R_1*np.sin(th1)])
    hi_tick2.set_data([cx2 + 0.12*R_2*np.cos(th2), cx2 + 0.97*R_2*np.cos(th2)],
                      [0.0 + 0.12*R_2*np.sin(th2), 0.0 + 0.97*R_2*np.sin(th2)])
    return disc1_patch, disc2_patch, axle1_dot, axle2_dot, ticks1_lc, ticks2_lc, hi_tick1, hi_tick2

n_frames = int(duration * fps) + 1
ani = animation.FuncAnimation(fig, update, frames=n_frames, interval=1000.0/fps, blit=False)
ani.save("discs_friction_coupling.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=2400), dpi=120)
plt.close(); print("Saved discs_friction_coupling.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Discs Friction Coupling")
    for k, v in asdict(DiscsFrictionCouplingParams()).items():
        parser.add_argument(f"--{k}", type=float, default=v)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="discs_friction_coupling.mp4")
    args = parser.parse_args()
    fields = {k: getattr(args, k) for k in asdict(DiscsFrictionCouplingParams()).keys()}
    p = DiscsFrictionCouplingParams(**fields)
    print(f"Simulating discs friction coupling: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
