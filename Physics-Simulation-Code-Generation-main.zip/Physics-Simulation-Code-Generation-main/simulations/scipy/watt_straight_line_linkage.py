"""
Watt Straight-Line Linkage (Approximate)
========================================
A planar three-bar mechanism — two cranks pinned to the ground at fixed
pivots A and B, joined at their free ends C and D by a floating coupler CD —
whose floating-coupler midpoint  M = (C + D) / 2  traces an approximate
straight line over a finite range of crank rotation. James Watt invented this
linkage in 1784 to convert the (almost) straight-line motion of a beam-engine
piston into the rotary motion of a flywheel without using rollers or guides.

Geometry (the only kinematic constraint is the loop closure):

           C─────coupler L_c─────D
          /                       \\
       L_a                         L_b
        /                           \\
       A───────── d_AB ──────────────B          (A, B are fixed pivots)

Independent coordinate (single DOF): θ_a  =  angle of the left crank AC
measured from +x.  We drive θ_a sinusoidally about a centre angle to keep the
mechanism in motion throughout the clip:

    θ_a(t) = θ_a_centre + θ_a_amp · sin(ω · t + φ)

The right-crank angle θ_b is then determined by the holonomic constraint

    (D − C) · (D − C)  =  L_c² ,

which becomes, after substituting C = A + L_a · (cos θ_a, sin θ_a) and
D = B + L_b · (cos θ_b, sin θ_b):

    L_b² + 2 L_b · (B − C) · (cos θ_b, sin θ_b) + |B − C|²  =  L_c²
    cos(θ_b − φ_r)  =  (L_c² − L_b² − |B − C|²) / (2 · L_b · |B − C|)

with φ_r = atan2(B_y − C_y, B_x − C_x).  This yields two solutions per
input θ_a (the "elbow up / elbow down" branches); we pick the branch that
varies continuously with θ_a from the user-chosen initial branch sign
("up" by default).

Once θ_b is known the position of every point on the linkage is closed-form:

    C  = A + L_a · (cos θ_a , sin θ_a)
    D  = B + L_b · (cos θ_b , sin θ_b)
    M  = ½ (C + D)        ← traces the (approximate) straight line.

For the symmetric ideal proportions  L_a = L_b ,   L_c = d_AB ,  the trace
is centred on the perpendicular bisector of AB and is rectilinear to several
decimal places over a useful range of crank motion.

Although the kinematics fixes the geometry, the underlying physics is still
Newton-Euler / Lagrangian mechanics for the linked rigid bodies; the COT
records both the constraint-Jacobian formulation and the velocity/
acceleration kinematics derived from it.
"""

from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis


@dataclass
class WattStraightLineLinkageParams:
    L_a: float = 1.00          # left crank length (m)
    L_b: float = 1.00          # right crank length (m)
    L_c: float = 2.00          # coupler length (m)
    d_AB: float = 2.00         # distance between fixed pivots A and B (m)
    A_y: float = 0.00          # height of pivot A (m); B is at the same height
    theta_a_centre: float = float(np.pi / 2)   # neutral left-crank angle (rad)
    theta_a_amp: float = 0.55  # drive amplitude (rad)
    omega_drive: float = 1.20  # drive angular frequency (rad/s)
    phase: float = 0.0         # drive phase (rad)
    branch_up: bool = True     # which intersection branch to take initially


def _solve_theta_b(
    theta_a: float, A: np.ndarray, B: np.ndarray,
    L_a: float, L_b: float, L_c: float,
    theta_b_prev: float | None,
    branch_up_initial: bool,
) -> float:
    """
    Closed-form (law-of-cosines) solver for the right-crank angle given the
    left-crank angle. The two solutions correspond to the two intersection
    points of the circles |D - B| = L_b and |D - C| = L_c. We pick the branch
    that varies continuously from the previous frame; on the first frame we
    use `branch_up_initial` to disambiguate (D placed "above" the AB line).
    """
    C = A + L_a * np.array([np.cos(theta_a), np.sin(theta_a)])
    r = B - C
    r_norm = float(np.linalg.norm(r))
    if r_norm < 1e-12:
        # Degenerate — should not happen for valid params.
        return theta_b_prev if theta_b_prev is not None else 0.0
    phi_r = float(np.arctan2(r[1], r[0]))
    cos_arg = (L_c * L_c - L_b * L_b - r_norm * r_norm) / (2.0 * L_b * r_norm)
    cos_arg = float(np.clip(cos_arg, -1.0, 1.0))
    delta = float(np.arccos(cos_arg))

    cand_a = phi_r + delta
    cand_b = phi_r - delta

    # Wrap candidates and previous to [-π, π] for stable comparison
    def _wrap(x):
        return (x + np.pi) % (2 * np.pi) - np.pi

    if theta_b_prev is None:
        # First frame: pick the branch with sin(θ_b) > 0 (D above x-axis-line)
        # if branch_up_initial, else the lower one.
        if branch_up_initial:
            return cand_a if np.sin(cand_a) > np.sin(cand_b) else cand_b
        else:
            return cand_a if np.sin(cand_a) < np.sin(cand_b) else cand_b

    diff_a = abs(_wrap(cand_a - theta_b_prev))
    diff_b = abs(_wrap(cand_b - theta_b_prev))
    return cand_a if diff_a <= diff_b else cand_b


def simulate(
    params: WattStraightLineLinkageParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Run the kinematics. Returns (t, y) where y has rows

        y[0] = theta_a(t)            crank angle at A (rad)
        y[1] = theta_b(t)            crank angle at B (rad)
        y[2] = Cx(t),  y[3] = Cy(t)
        y[4] = Dx(t),  y[5] = Dy(t)
        y[6] = Mx(t),  y[7] = My(t)
    """
    n_frames = int(duration * fps) + 1
    t = np.linspace(0, duration, n_frames)

    A = np.array([-params.d_AB / 2.0, params.A_y])
    B = np.array([+params.d_AB / 2.0, params.A_y])

    theta_a = (
        params.theta_a_centre
        + params.theta_a_amp * np.sin(params.omega_drive * t + params.phase)
    )

    theta_b = np.empty(n_frames)
    Cx = np.empty(n_frames); Cy = np.empty(n_frames)
    Dx = np.empty(n_frames); Dy = np.empty(n_frames)
    Mx = np.empty(n_frames); My = np.empty(n_frames)

    prev = None
    for i in range(n_frames):
        tb = _solve_theta_b(
            theta_a[i], A, B, params.L_a, params.L_b, params.L_c,
            prev, params.branch_up,
        )
        theta_b[i] = tb
        prev = tb

        C = A + params.L_a * np.array([np.cos(theta_a[i]), np.sin(theta_a[i])])
        D = B + params.L_b * np.array([np.cos(tb), np.sin(tb)])
        Cx[i], Cy[i] = C
        Dx[i], Dy[i] = D
        Mx[i], My[i] = 0.5 * (C + D)

    y = np.vstack([theta_a, theta_b, Cx, Cy, Dx, Dy, Mx, My])
    return t, y


def trace_summary(t: np.ndarray, y: np.ndarray) -> dict:
    """Quantify how 'straight' the midpoint trace is."""
    Mx, My = y[6], y[7]
    # Best-fit line to all (Mx, My) using SVD on the centred point cloud.
    pts = np.column_stack([Mx, My])
    centroid = pts.mean(axis=0)
    centred = pts - centroid
    _, S, Vt = np.linalg.svd(centred, full_matrices=False)
    direction = Vt[0]                    # principal axis (unit vector)
    normal = np.array([-direction[1], direction[0]])
    # Perpendicular distances of the trace to its best-fit line.
    perp = centred @ normal
    return {
        "trace_centroid": tuple(centroid),
        "principal_axis_direction": tuple(direction),
        "trace_length_along_axis": float(centred @ direction).max() - float(centred @ direction).min()
            if False else float((centred @ direction).max() - (centred @ direction).min()),
        "max_perpendicular_deviation_m": float(np.max(np.abs(perp))),
        "rms_perpendicular_deviation_m": float(np.sqrt(np.mean(perp ** 2))),
    }


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: WattStraightLineLinkageParams,
    output_path: str,
    fps: int = 30,
    trail_len: int = 600,
) -> None:
    Cx, Cy = y[2], y[3]
    Dx, Dy = y[4], y[5]
    Mx, My = y[6], y[7]

    Ax, Ay = -params.d_AB / 2, params.A_y
    Bx, By = +params.d_AB / 2, params.A_y

    # Frame extent
    span = max(params.d_AB, params.L_a + params.L_b, params.L_c) * 1.2
    pad_y = max(params.L_a, params.L_b) * 0.6
    xlim = (-span, span)
    ylim = (params.A_y - pad_y - 0.4, params.A_y + max(params.L_a, params.L_b) + 0.6)

    fig, ax = plt.subplots(figsize=(7, 5.5))
    setup_dark_axis(fig, ax, xlim, ylim)

    # Static elements
    ax.plot([Ax], [Ay], "o", color="white", ms=8, zorder=6)
    ax.plot([Bx], [By], "o", color="white", ms=8, zorder=6)
    ax.axhline(params.A_y, color="#4a4e69", lw=0.8, ls=":", alpha=0.4, zorder=1)

    # Animated lines: left crank, right crank, coupler, midpoint trail, midpoint dot
    (left_crank,)  = ax.plot([], [], "-", color="#a8dadc", lw=3.0, zorder=4)
    (right_crank,) = ax.plot([], [], "-", color="#a8dadc", lw=3.0, zorder=4)
    (coupler,)     = ax.plot([], [], "-", color="#f1faee", lw=3.5, zorder=4)
    (full_trail,)  = ax.plot([], [], "-", color="#f4a261", lw=1.0, alpha=0.45, zorder=2)
    (recent_trail,)= ax.plot([], [], "-", color="#e76f51", lw=2.0, alpha=0.85, zorder=3)
    (cpt_C,)       = ax.plot([], [], "o", color="#457b9d", ms=8, zorder=5)
    (cpt_D,)       = ax.plot([], [], "o", color="#457b9d", ms=8, zorder=5)
    (cpt_M,)       = ax.plot([], [], "o", color="#e63946", ms=10, zorder=6)


    full_x: list = []
    full_y: list = []

    def init():
        for a in (left_crank, right_crank, coupler,
                  full_trail, recent_trail, cpt_C, cpt_D, cpt_M):
            a.set_data([], [])
        return (left_crank, right_crank, coupler,
                full_trail, recent_trail, cpt_C, cpt_D, cpt_M)

    def update(frame):
        cx, cy = Cx[frame], Cy[frame]
        dx, dy = Dx[frame], Dy[frame]
        mx, my = Mx[frame], My[frame]

        left_crank.set_data([Ax, cx], [Ay, cy])
        right_crank.set_data([Bx, dx], [By, dy])
        coupler.set_data([cx, dx], [cy, dy])

        full_x.append(mx); full_y.append(my)
        full_trail.set_data(full_x, full_y)
        # Recent trail (last `trail_len` points)
        if len(full_x) > trail_len:
            recent_trail.set_data(full_x[-trail_len:], full_y[-trail_len:])
        else:
            recent_trail.set_data(full_x, full_y)

        cpt_C.set_data([cx], [cy])
        cpt_D.set_data([dx], [dy])
        cpt_M.set_data([mx], [my])

        return (left_crank, right_crank, coupler,
                full_trail, recent_trail, cpt_C, cpt_D, cpt_M)

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), init_func=init, interval=1000 / fps, blit=False
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(
    params: WattStraightLineLinkageParams,
    duration: float = 12.0,
) -> str:
    p = asdict(params)
    return f'''"""
Watt Straight-Line Linkage — auto-generated simulation script.

Geometry (planar 4-bar with the ground link being AB):
  A = (-d_AB/2, A_y),  B = (+d_AB/2, A_y)              (fixed pivots)
  C = A + L_a (cos theta_a, sin theta_a)                (left-crank tip)
  D = B + L_b (cos theta_b, sin theta_b)                (right-crank tip)
  Loop closure:  |D - C| = L_c                         (coupler length)
  Midpoint:      M = (C + D) / 2                        (traces approx. straight line)

Drive: theta_a(t) = theta_a_centre + theta_a_amp * sin(omega_drive * t + phase).
Solve for theta_b each frame from the law of cosines on the triangle BCD.
"""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

# ── Parameters ─────────────────────────────────────────────────────────────
L_a            = {p["L_a"]}
L_b            = {p["L_b"]}
L_c            = {p["L_c"]}
d_AB           = {p["d_AB"]}
A_y            = {p["A_y"]}
theta_a_centre = {p["theta_a_centre"]:.6f}
theta_a_amp    = {p["theta_a_amp"]:.6f}
omega_drive    = {p["omega_drive"]:.6f}
phase          = {p["phase"]:.6f}
branch_up      = {bool(p["branch_up"])}
duration       = {duration}
fps            = 30

A = np.array([-d_AB/2.0, A_y]); B = np.array([+d_AB/2.0, A_y])

# ── Solve theta_b (law of cosines, branch chosen for continuity) ───────────
def _solve_theta_b(theta_a, prev):
    C = A + L_a * np.array([np.cos(theta_a), np.sin(theta_a)])
    r = B - C; rn = float(np.linalg.norm(r))
    phi_r = float(np.arctan2(r[1], r[0]))
    cos_arg = (L_c**2 - L_b**2 - rn**2) / (2.0 * L_b * rn)
    cos_arg = float(np.clip(cos_arg, -1.0, 1.0))
    delta = float(np.arccos(cos_arg))
    a, b = phi_r + delta, phi_r - delta
    def _w(x): return (x + np.pi) % (2*np.pi) - np.pi
    if prev is None:
        if branch_up:
            return a if np.sin(a) > np.sin(b) else b
        return a if np.sin(a) < np.sin(b) else b
    return a if abs(_w(a - prev)) <= abs(_w(b - prev)) else b

# ── Sample on a uniform time grid ───────────────────────────────────────────
n_frames = int(duration * fps) + 1
t = np.linspace(0, duration, n_frames)
theta_a = theta_a_centre + theta_a_amp * np.sin(omega_drive * t + phase)

theta_b = np.empty(n_frames)
Cx = np.empty(n_frames); Cy = np.empty(n_frames)
Dx = np.empty(n_frames); Dy = np.empty(n_frames)
Mx = np.empty(n_frames); My = np.empty(n_frames)

prev = None
for i in range(n_frames):
    tb = _solve_theta_b(theta_a[i], prev); prev = tb; theta_b[i] = tb
    C = A + L_a * np.array([np.cos(theta_a[i]), np.sin(theta_a[i])])
    D = B + L_b * np.array([np.cos(tb), np.sin(tb)])
    Cx[i], Cy[i] = C
    Dx[i], Dy[i] = D
    Mx[i], My[i] = 0.5 * (C + D)

# ── Animation ───────────────────────────────────────────────────────────────
span = max(d_AB, L_a + L_b, L_c) * 1.2
pad_y = max(L_a, L_b) * 0.6
xlim = (-span, span)
ylim = (A_y - pad_y - 0.4, A_y + max(L_a, L_b) + 0.6)

fig, ax = plt.subplots(figsize=(7, 5.5), facecolor="#1a1a2e")
ax.set_facecolor("#16213e")
ax.set_xlim(xlim); ax.set_ylim(ylim); ax.set_aspect("equal"); ax.axis("off")
ax.plot([-d_AB/2], [A_y], "o", color="white", ms=8, zorder=6)
ax.plot([+d_AB/2], [A_y], "o", color="white", ms=8, zorder=6)
ax.axhline(A_y, color="#4a4e69", lw=0.8, ls=":", alpha=0.4, zorder=1)

left_crank,   = ax.plot([], [], "-", color="#a8dadc", lw=3.0, zorder=4)
right_crank,  = ax.plot([], [], "-", color="#a8dadc", lw=3.0, zorder=4)
coupler,      = ax.plot([], [], "-", color="#f1faee", lw=3.5, zorder=4)
full_trail,   = ax.plot([], [], "-", color="#f4a261", lw=1.0, alpha=0.45, zorder=2)
recent_trail, = ax.plot([], [], "-", color="#e76f51", lw=2.0, alpha=0.85, zorder=3)
cpt_C,        = ax.plot([], [], "o", color="#457b9d", ms=8, zorder=5)
cpt_D,        = ax.plot([], [], "o", color="#457b9d", ms=8, zorder=5)
cpt_M,        = ax.plot([], [], "o", color="#e63946", ms=10, zorder=6)

fx, fy = [], []
TRAIL_LEN = 600

INFO_FMT = "theta_a = {{:+6.1f}} deg\\ntheta_b = {{:+6.1f}} deg\\nM = ({{:+.3f}}, {{:+.3f}}) m"

def update(f):
    Ax_, Ay_ = -d_AB/2, A_y; Bx_, By_ = +d_AB/2, A_y
    left_crank.set_data([Ax_, Cx[f]], [Ay_, Cy[f]])
    right_crank.set_data([Bx_, Dx[f]], [By_, Dy[f]])
    coupler.set_data([Cx[f], Dx[f]], [Cy[f], Dy[f]])
    fx.append(Mx[f]); fy.append(My[f])
    full_trail.set_data(fx, fy)
    if len(fx) > TRAIL_LEN:
        recent_trail.set_data(fx[-TRAIL_LEN:], fy[-TRAIL_LEN:])
    else:
        recent_trail.set_data(fx, fy)
    cpt_C.set_data([Cx[f]], [Cy[f]])
    cpt_D.set_data([Dx[f]], [Dy[f]])
    cpt_M.set_data([Mx[f]], [My[f]])
    return (left_crank, right_crank, coupler,
            full_trail, recent_trail, cpt_C, cpt_D, cpt_M)

ani = animation.FuncAnimation(fig, update, frames=n_frames,
                              interval=1000/fps, blit=False)
ani.save("watt_straight_line_linkage.mp4",
         writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved watt_straight_line_linkage.mp4")
'''


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Watt Straight-Line Linkage")
    parser.add_argument("--L_a",  type=float, default=1.0)
    parser.add_argument("--L_b",  type=float, default=1.0)
    parser.add_argument("--L_c",  type=float, default=2.0)
    parser.add_argument("--d_AB", type=float, default=2.0)
    parser.add_argument("--A_y",  type=float, default=0.0)
    parser.add_argument("--theta_a_centre", type=float, default=float(np.pi / 2))
    parser.add_argument("--theta_a_amp",    type=float, default=0.55)
    parser.add_argument("--omega_drive",    type=float, default=1.20)
    parser.add_argument("--phase",          type=float, default=0.0)
    parser.add_argument("--branch_up",      action="store_true", default=True)
    parser.add_argument("--duration",       type=float, default=12.0)
    parser.add_argument("--output",         type=str, default="watt_straight_line_linkage.mp4")
    args = parser.parse_args()

    p = WattStraightLineLinkageParams(
        L_a=args.L_a, L_b=args.L_b, L_c=args.L_c,
        d_AB=args.d_AB, A_y=args.A_y,
        theta_a_centre=args.theta_a_centre, theta_a_amp=args.theta_a_amp,
        omega_drive=args.omega_drive, phase=args.phase,
        branch_up=args.branch_up,
    )
    print(f"Simulating Watt linkage: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    print(f"  trace summary: {trace_summary(t, y)}")
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
