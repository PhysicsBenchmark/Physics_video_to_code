"""
Robot Speed Simulation
======================
A wheeled robot moving along an inclined ramp. Velocity approaches a terminal
value with a first-order time constant; the terminal value implicitly bakes in
motor power, slope gravity, and drag, so every parameter is directly visible
from the video.

Physics:
    dx/dt = v
    dv/dt = (v_terminal − v) / tau

Closed form: v(t) = v_terminal + (v0 − v_terminal)·exp(−t/tau).
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.animation as animation
from dataclasses import dataclass, asdict
import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from .draw_utils import setup_dark_axis


@dataclass
class RobotSpeedParams:
    r_wheel: float = 0.045     # wheel radius (m) — visible in video
    slope_deg: float = 5.0     # ramp angle in degrees — visible
    v_terminal: float = 1.0    # asymptotic velocity (m/s) — visible as the steady-state speed
    tau: float = 1.5           # time constant (s) — visible from how fast v ramps up
    x0: float = 0.0            # initial position along ramp (m) — visible
    v0: float = 0.0            # initial velocity (m/s) — visible


def ode(t: float, y: list, p: RobotSpeedParams):
    x, v = y
    return [v, (p.v_terminal - v) / p.tau]


def simulate(
    params: RobotSpeedParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode,
        (0, duration),
        [params.x0, params.v0],
        t_eval=t_eval,
        args=(params,),
        method="RK45",
        rtol=1e-8,
        atol=1e-10,
    )
    return sol.t, sol.y


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: RobotSpeedParams,
    output_path: str,
    fps: int = 30,
) -> None:
    x_traj = y[0]

    slope_rad = np.radians(params.slope_deg)
    cs = np.cos(slope_rad)
    ss = np.sin(slope_rad)

    robot_w = 0.3
    robot_h = 0.1
    r = params.r_wheel

    ramp_len = 5.5
    ramp_x0, ramp_y0 = -0.5 * cs, -0.5 * ss
    ramp_x1, ramp_y1 = ramp_len * cs, ramp_len * ss

    view_xmin = -0.8
    view_xmax = ramp_len + 0.3
    view_ymin = min(-0.3, ramp_len * ss - 0.3)
    view_ymax = max(0.6, ramp_len * ss + 0.6)

    fig, ax = plt.subplots(figsize=(8, 4))
    setup_dark_axis(fig, ax, (view_xmin, view_xmax), (view_ymin, view_ymax))

    ax.plot([ramp_x0, ramp_x1], [ramp_y0, ramp_y1],
            color="#a8dadc", lw=3, zorder=2)

    def robot_corners(pos_x: float) -> np.ndarray:
        half_w = robot_w / 2.0
        base_y = r
        corners_local = np.array([
            [-half_w,  base_y],
            [ half_w,  base_y],
            [ half_w,  base_y + robot_h],
            [-half_w,  base_y + robot_h],
        ])
        R_mat = np.array([[cs, -ss], [ss, cs]])
        cx_world = pos_x * cs
        cy_world = pos_x * ss
        corners_world = (R_mat @ corners_local.T).T
        corners_world[:, 0] += cx_world
        corners_world[:, 1] += cy_world
        return corners_world

    robot_poly = plt.Polygon(robot_corners(params.x0), closed=True,
                              facecolor="#457b9d", edgecolor="#a8dadc",
                              lw=1.5, zorder=4)
    ax.add_patch(robot_poly)

    wheel_f = mpatches.Circle((0, 0), r, color="#e63946", zorder=5)
    wheel_r = mpatches.Circle((0, 0), r, color="#e63946", zorder=5)
    ax.add_patch(wheel_f)
    ax.add_patch(wheel_r)

    def update(frame):
        px = x_traj[frame]
        robot_poly.set_xy(robot_corners(px))
        wf_x = (px + 0.1) * cs + r * (-ss)
        wf_y = (px + 0.1) * ss + r * cs
        wr_x = (px - 0.1) * cs + r * (-ss)
        wr_y = (px - 0.1) * ss + r * cs
        wheel_f.set_center((wf_x, wf_y))
        wheel_r.set_center((wr_x, wr_y))
        return [robot_poly, wheel_f, wheel_r]

    ani = animation.FuncAnimation(
        fig, update, frames=len(t),
        interval=1000 / fps, blit=True
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: RobotSpeedParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""
Robot Speed — auto-generated simulation script.

Physics:
    dx/dt = v
    dv/dt = (v_terminal − v) / tau
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as mpatches

# ── Parameters ──────────────────────────────────────────────────────────────
r_wheel    = {p["r_wheel"]}
slope_deg  = {p["slope_deg"]}
v_terminal = {p["v_terminal"]}
tau        = {p["tau"]}
x0         = {p["x0"]:.6f}
v0         = {p["v0"]:.6f}
duration   = {duration}

slope_rad = np.radians(slope_deg)
cs, ss = np.cos(slope_rad), np.sin(slope_rad)

def ode(time, y):
    x, v = y
    return [v, (v_terminal - v) / tau]

fps = 30
t_eval = np.linspace(0, duration, int(duration * fps) + 1)
sol = solve_ivp(ode, (0, duration), [x0, v0], t_eval=t_eval,
                method="RK45", rtol=1e-8, atol=1e-10)
sol_t, (x_traj, v_traj) = sol.t, sol.y

r = r_wheel
robot_w, robot_h = 0.3, 0.1
ramp_len = 5.5

fig, ax = plt.subplots(figsize=(8, 4), facecolor="#1a1a2e")
ax.set_facecolor("#16213e")
ax.set_xlim(-0.8, ramp_len + 0.3)
ax.set_ylim(min(-0.3, ramp_len*ss - 0.3), max(0.6, ramp_len*ss + 0.6))
ax.set_aspect("equal"); ax.axis("off")
ax.plot([-0.5*cs, ramp_len*cs], [-0.5*ss, ramp_len*ss], color="#a8dadc", lw=3)

def robot_corners(px):
    half_w = robot_w / 2.0
    base_y = r
    corners_local = np.array([
        [-half_w, base_y], [half_w, base_y],
        [half_w, base_y + robot_h], [-half_w, base_y + robot_h]
    ])
    R_mat = np.array([[cs, -ss], [ss, cs]])
    cx, cy = px * cs, px * ss
    c = (R_mat @ corners_local.T).T
    c[:, 0] += cx; c[:, 1] += cy
    return c

robot_poly = plt.Polygon(robot_corners(x0), closed=True,
                          facecolor="#457b9d", edgecolor="#a8dadc", lw=1.5, zorder=4)
ax.add_patch(robot_poly)
wheel_f = mpatches.Circle((0, 0), r, color="#e63946", zorder=5)
wheel_r = mpatches.Circle((0, 0), r, color="#e63946", zorder=5)
ax.add_patch(wheel_f); ax.add_patch(wheel_r)

def update(frame):
    px = x_traj[frame]
    robot_poly.set_xy(robot_corners(px))
    for wh, off in zip([wheel_f, wheel_r], [0.1, -0.1]):
        wx = (px + off)*cs + r*(-ss); wy = (px + off)*ss + r*cs
        wh.set_center((wx, wy))
    return [robot_poly, wheel_f, wheel_r]

ani = animation.FuncAnimation(fig, update, frames=len(sol_t), interval=1000/fps, blit=True)
ani.save("robot_speed.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved robot_speed.mp4")
'''


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Robot Speed Simulation")
    parser.add_argument("--r_wheel", type=float, default=0.045)
    parser.add_argument("--slope_deg", type=float, default=5.0)
    parser.add_argument("--v_terminal", type=float, default=1.0)
    parser.add_argument("--tau", type=float, default=1.5)
    parser.add_argument("--x0", type=float, default=0.0)
    parser.add_argument("--v0", type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="robot_speed.mp4")
    args = parser.parse_args()

    p = RobotSpeedParams(
        r_wheel=args.r_wheel, slope_deg=args.slope_deg,
        v_terminal=args.v_terminal, tau=args.tau,
        x0=args.x0, v0=args.v0,
    )
    print(f"Simulating robot speed: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")


if __name__ == "__main__":
    main()
