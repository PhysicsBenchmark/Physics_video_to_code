"""
Spinning Disc + Block + Spring (top-down).

Disc spins about origin with omega(t) ramping from 0 to omega_max over t_ramp.
Block sits on disc surface, tethered to fixed lab origin by a Hookean spring of
stiffness k and rest length L_0. Coulomb friction (mu_s static, mu_k kinetic)
couples block to disc surface. Hybrid stick/slip integration.
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle, Circle
import matplotlib.transforms as mtransforms
from dataclasses import dataclass, asdict


@dataclass
class SpinningDiscBlockSpringParams:
    g: float = 9.8
    m_b: float = 0.30
    R_disc: float = 0.80
    L_0: float = 0.30
    k: float = 8.0
    mu_s: float = 0.40
    mu_k: float = 0.30
    omega_max: float = 5.0
    t_ramp: float = 4.0
    x_b_0: float = 0.30
    y_b_0: float = 0.0
    vx_b_0: float = 0.0
    vy_b_0: float = 0.0


def simulate(
    params: SpinningDiscBlockSpringParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Returns (t, y) where y.shape = (4, N): [x, y, theta_disc, status].

    status: 0=stick, 1=slip.
    """
    g = params.g; m_b = params.m_b
    R_disc = params.R_disc; L_0 = params.L_0; k = params.k
    mu_s = params.mu_s; mu_k = params.mu_k
    omega_max = params.omega_max; t_ramp = params.t_ramp

    def omega_disc(t):
        if t < t_ramp:
            return omega_max * (t / t_ramp)
        return omega_max

    def alpha_disc(t):
        return omega_max / t_ramp if t < t_ramp else 0.0

    def theta_disc_of_t(t):
        if t <= t_ramp:
            return 0.5 * (omega_max / t_ramp) * t * t
        return 0.5 * omega_max * t_ramp + omega_max * (t - t_ramp)

    def required_static_force(x, y, t):
        om = omega_disc(t)
        r = np.hypot(x, y)
        if r < 1e-12:
            return 0.0
        rhat = np.array([x, y]) / r
        a_req = -r * om * om * rhat
        F_spring = -k * (r - L_0) * rhat
        al = alpha_disc(t)
        that = np.array([-rhat[1], rhat[0]])
        a_req_tan = al * r * that
        F_req = m_b * (a_req + a_req_tan) - F_spring
        return float(np.linalg.norm(F_req))

    def slip_ode(t, y):
        x, yy, vx, vy = y
        r = np.hypot(x, yy)
        if r < 1e-12:
            Fs = np.zeros(2)
        else:
            rhat = np.array([x, yy]) / r
            Fs = -k * (r - L_0) * rhat
        if r <= R_disc:
            om = omega_disc(t)
            v_disc = np.array([-om * yy, om * x])
            v_slip = np.array([vx, vy]) - v_disc
            vsm = float(np.linalg.norm(v_slip))
            if vsm < 1e-12:
                Ff = np.zeros(2)
            else:
                Ff = -mu_k * m_b * g * v_slip / vsm
        else:
            Ff = np.zeros(2)
        a = (Fs + Ff) / m_b
        return [vx, vy, a[0], a[1]]

    n_frames = int(duration * fps) + 1
    t_frames = np.linspace(0.0, duration, n_frames)
    X_hist = np.zeros(n_frames)
    Y_hist = np.zeros(n_frames)
    DISC_HIST = np.zeros(n_frames)
    STATUS_HIST = np.zeros(n_frames, dtype=int)

    v_slip_eps = 1.0e-3
    status = 0
    t = 0.0
    x = params.x_b_0
    yy = params.y_b_0
    vx = params.vx_b_0
    vy = params.vy_b_0
    r_stick = np.hypot(x, yy)
    phi_stick_offset = np.arctan2(yy, x) - theta_disc_of_t(0.0)

    def re_stick_event(tt, yvec):
        xs, ys, vxs, vys = yvec
        om_l = omega_disc(tt)
        return np.hypot(vxs - (-om_l * ys), vys - (om_l * xs)) - v_slip_eps
    re_stick_event.terminal = True
    re_stick_event.direction = -1

    frame_idx = 0
    SAFETY = 0
    while frame_idx < n_frames:
        SAFETY += 1
        if SAFETY > 200:
            break
        if status == 0:  # STICK
            ds = 1e-3
            slip_at = None
            t_local = t
            while t_local < duration - 1e-15:
                t_next = min(t_local + ds, duration)
                theta_d = theta_disc_of_t(t_next)
                x_n = r_stick * np.cos(phi_stick_offset + theta_d)
                y_n = r_stick * np.sin(phi_stick_offset + theta_d)
                Freq_mag = required_static_force(x_n, y_n, t_next)
                if Freq_mag > mu_s * m_b * g:
                    lo, hi = t_local, t_next
                    for _ in range(40):
                        mid = 0.5 * (lo + hi)
                        th_mid = theta_disc_of_t(mid)
                        xm = r_stick * np.cos(phi_stick_offset + th_mid)
                        ym = r_stick * np.sin(phi_stick_offset + th_mid)
                        Fm = required_static_force(xm, ym, mid)
                        if Fm > mu_s * m_b * g:
                            hi = mid
                        else:
                            lo = mid
                    slip_at = hi
                    break
                t_local = t_next

            seg_end = duration if slip_at is None else slip_at
            while frame_idx < n_frames and t_frames[frame_idx] <= seg_end + 1e-12:
                tf = t_frames[frame_idx]
                if tf < t - 1e-12:
                    tf = t
                theta_d = theta_disc_of_t(tf)
                xv = r_stick * np.cos(phi_stick_offset + theta_d)
                yv = r_stick * np.sin(phi_stick_offset + theta_d)
                X_hist[frame_idx] = xv
                Y_hist[frame_idx] = yv
                DISC_HIST[frame_idx] = theta_d
                STATUS_HIST[frame_idx] = 0
                frame_idx += 1
            if slip_at is None:
                t = duration
                break
            t = slip_at
            theta_d = theta_disc_of_t(t)
            x = r_stick * np.cos(phi_stick_offset + theta_d)
            yy = r_stick * np.sin(phi_stick_offset + theta_d)
            om = omega_disc(t)
            vx = -om * yy
            vy = om * x
            status = 1
            continue

        # SLIP
        rem_mask = (t_frames > t + 1e-12) & (t_frames <= duration + 1e-12)
        t_eval_seg = t_frames[rem_mask] if rem_mask.any() else None
        sol = solve_ivp(slip_ode, (t, duration), [x, yy, vx, vy],
                        method="RK45", rtol=1e-9, atol=1e-11,
                        max_step=5e-3, events=re_stick_event,
                        t_eval=t_eval_seg)
        for j, tf in enumerate(sol.t):
            if frame_idx < n_frames and abs(t_frames[frame_idx] - tf) < 1e-6:
                X_hist[frame_idx] = sol.y[0, j]
                Y_hist[frame_idx] = sol.y[1, j]
                DISC_HIST[frame_idx] = theta_disc_of_t(tf)
                STATUS_HIST[frame_idx] = 1
                frame_idx += 1

        if sol.t_events[0].size > 0:
            t_event = sol.t_events[0][0]
            y_event = sol.y_events[0][0]
            while frame_idx < n_frames and t_frames[frame_idx] <= t_event + 1e-9:
                tf = t_frames[frame_idx]
                X_hist[frame_idx] = y_event[0]
                Y_hist[frame_idx] = y_event[1]
                DISC_HIST[frame_idx] = theta_disc_of_t(tf)
                STATUS_HIST[frame_idx] = 1
                frame_idx += 1
            t = t_event
            x, yy, vx, vy = y_event
            Freq_mag = required_static_force(x, yy, t)
            if Freq_mag <= mu_s * m_b * g:
                status = 0
                r_stick = np.hypot(x, yy)
                theta_d = theta_disc_of_t(t)
                phi_stick_offset = np.arctan2(yy, x) - theta_d
            else:
                r_here = np.hypot(x, yy)
                if r_here > 1e-9:
                    rhx, rhy = x / r_here, yy / r_here
                    vx += 1e-2 * rhx
                    vy += 1e-2 * rhy
        else:
            t = duration
            if sol.y.shape[1] > 0:
                x, yy, vx, vy = sol.y[:, -1]
            break

    while frame_idx < n_frames:
        X_hist[frame_idx] = x
        Y_hist[frame_idx] = yy
        DISC_HIST[frame_idx] = theta_disc_of_t(t_frames[frame_idx])
        STATUS_HIST[frame_idx] = status
        frame_idx += 1

    return t_frames, np.vstack([X_hist, Y_hist, DISC_HIST, STATUS_HIST.astype(float)])


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: SpinningDiscBlockSpringParams,
    output_path: str,
    fps: int = 30,
) -> None:
    X_hist, Y_hist, DISC_HIST = y[0], y[1], y[2]
    R_disc = params.R_disc

    W, H = 6.0, 6.0
    fig = plt.figure(figsize=(W, H), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.axis("off")
    ax.set_aspect("equal")
    extent = R_disc + 0.20
    ax.set_xlim(-extent, +extent)
    ax.set_ylim(-extent, +extent)

    disc_patch = Circle((0.0, 0.0), R_disc,
                        facecolor="#21304e", edgecolor="#a8dadc",
                        lw=1.2, zorder=1)
    ax.add_patch(disc_patch)
    spoke_lines = []
    for i in range(4):
        line, = ax.plot([], [], "-", color="#a8dadc", lw=1.6, zorder=2)
        spoke_lines.append(line)
    anchor_dot = Circle((0.0, 0.0), 0.018,
                        facecolor="#ffffff", edgecolor="#1a1a2e",
                        lw=0.6, zorder=6)
    ax.add_patch(anchor_dot)
    spring_line, = ax.plot([], [], "-", color="#f4a261", lw=1.8, zorder=4)
    TRAIL_LEN = 150
    trail_line, = ax.plot([], [], "-", color="#e63946",
                          lw=1.0, alpha=0.5, zorder=3)
    block_size = 0.10
    block_patch = Rectangle((-block_size / 2, -block_size / 2),
                            block_size, block_size,
                            facecolor="#e63946", edgecolor="#ffffff",
                            lw=1.0, zorder=5)
    ax.add_patch(block_patch)

    def spring_path(x1, y1, x2, y2, n_coils=10, amp=0.025):
        dx, dy = x2 - x1, y2 - y1
        L = np.hypot(dx, dy)
        if L < 1e-10:
            return np.array([x1, x2]), np.array([y1, y2])
        ux, uy = dx / L, dy / L
        nx, ny = -uy, ux
        n_pts = n_coils * 20 + 2
        s = np.linspace(0.0, 1.0, n_pts)
        margin = 0.10
        env = np.where((s < margin) | (s > 1.0 - margin), 0.0,
                       np.sin(n_coils * 2 * np.pi * (s - margin) /
                              (1.0 - 2 * margin)))
        xs = x1 + s * dx + amp * env * nx
        ys = y1 + s * dy + amp * env * ny
        return xs, ys

    def update(f):
        th_d = DISC_HIST[f]
        for i, line in enumerate(spoke_lines):
            ang = th_d + i * (np.pi / 2.0)
            sx = R_disc * 0.95 * np.cos(ang)
            sy = R_disc * 0.95 * np.sin(ang)
            line.set_data([0.0, sx], [0.0, sy])
        bx, by = X_hist[f], Y_hist[f]
        xs, ys = spring_path(0.0, 0.0, bx, by)
        spring_line.set_data(xs, ys)
        lo = max(0, f - TRAIL_LEN)
        trail_line.set_data(X_hist[lo:f + 1], Y_hist[lo:f + 1])
        tr = (mtransforms.Affine2D()
              .rotate(th_d)
              .translate(bx, by)) + ax.transData
        block_patch.set_transform(tr)
        return spoke_lines + [spring_line, trail_line, block_patch, anchor_dot]

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0 / fps, blit=False)
    ani.save(output_path,
             writer=animation.FFMpegWriter(fps=fps, bitrate=2400), dpi=120)
    plt.close(fig)


def make_standalone_script(
    params: SpinningDiscBlockSpringParams,
    duration: float = 12.0,
) -> str:
    p = asdict(params)
    return f'''"""Spinning disc + block + spring — auto-generated."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle, Circle
import matplotlib.transforms as mtransforms

g          = {p["g"]}
m_b        = {p["m_b"]}
R_disc     = {p["R_disc"]}
L_0        = {p["L_0"]}
k          = {p["k"]}
mu_s       = {p["mu_s"]}
mu_k       = {p["mu_k"]}
omega_max  = {p["omega_max"]}
t_ramp     = {p["t_ramp"]}
x_b_0      = {p["x_b_0"]}
y_b_0      = {p["y_b_0"]}
vx_b_0     = {p["vx_b_0"]}
vy_b_0     = {p["vy_b_0"]}
duration   = {duration}
fps        = 30

def omega_disc(t):
    if t < t_ramp: return omega_max*(t/t_ramp)
    return omega_max
def alpha_disc(t):
    return omega_max/t_ramp if t < t_ramp else 0.0
def theta_disc_of_t(t):
    if t <= t_ramp: return 0.5*(omega_max/t_ramp)*t*t
    return 0.5*omega_max*t_ramp + omega_max*(t - t_ramp)

def req_force(x, y, t):
    om = omega_disc(t); r = np.hypot(x, y)
    if r < 1e-12: return 0.0
    rh = np.array([x,y])/r
    a_req = -r*om*om*rh
    F_spring = -k*(r-L_0)*rh
    al = alpha_disc(t); that = np.array([-rh[1], rh[0]])
    a_tan = al*r*that
    F_req = m_b*(a_req + a_tan) - F_spring
    return float(np.linalg.norm(F_req))

def slip_ode(t, y):
    x, yy, vx, vy = y
    r = np.hypot(x, yy)
    if r < 1e-12: Fs = np.zeros(2)
    else:
        rh = np.array([x,yy])/r
        Fs = -k*(r-L_0)*rh
    if r <= R_disc:
        om = omega_disc(t)
        v_d = np.array([-om*yy, om*x])
        v_s = np.array([vx,vy]) - v_d
        vsm = float(np.linalg.norm(v_s))
        if vsm < 1e-12: Ff = np.zeros(2)
        else: Ff = -mu_k*m_b*g*v_s/vsm
    else: Ff = np.zeros(2)
    a = (Fs+Ff)/m_b
    return [vx, vy, a[0], a[1]]

n_frames = int(duration*fps)+1
t_frames = np.linspace(0.0, duration, n_frames)
X_hist = np.zeros(n_frames); Y_hist = np.zeros(n_frames)
DISC_HIST = np.zeros(n_frames); STATUS = np.zeros(n_frames, dtype=int)

v_slip_eps = 1e-3
status = 0; t = 0.0
x = x_b_0; yy = y_b_0; vx = vx_b_0; vy = vy_b_0
r_stick = np.hypot(x, yy)
phi_stick = np.arctan2(yy, x) - theta_disc_of_t(0.0)

def re_stick(tt, yv):
    xs, ys, vxs, vys = yv
    om = omega_disc(tt)
    return np.hypot(vxs-(-om*ys), vys-(om*xs)) - v_slip_eps
re_stick.terminal=True; re_stick.direction=-1

fi = 0; SAFETY=0
while fi < n_frames:
    SAFETY += 1
    if SAFETY > 200: break
    if status == 0:
        ds = 1e-3; slip_at = None; t_loc = t
        while t_loc < duration - 1e-15:
            t_n = min(t_loc + ds, duration)
            th_d = theta_disc_of_t(t_n)
            x_n = r_stick*np.cos(phi_stick + th_d)
            y_n = r_stick*np.sin(phi_stick + th_d)
            if req_force(x_n, y_n, t_n) > mu_s*m_b*g:
                lo, hi = t_loc, t_n
                for _ in range(40):
                    mid = 0.5*(lo+hi)
                    thm = theta_disc_of_t(mid)
                    xm = r_stick*np.cos(phi_stick + thm)
                    ym = r_stick*np.sin(phi_stick + thm)
                    if req_force(xm, ym, mid) > mu_s*m_b*g: hi = mid
                    else: lo = mid
                slip_at = hi; break
            t_loc = t_n
        seg_end = duration if slip_at is None else slip_at
        while fi < n_frames and t_frames[fi] <= seg_end + 1e-12:
            tf = t_frames[fi]
            if tf < t - 1e-12: tf = t
            th_d = theta_disc_of_t(tf)
            X_hist[fi] = r_stick*np.cos(phi_stick + th_d)
            Y_hist[fi] = r_stick*np.sin(phi_stick + th_d)
            DISC_HIST[fi] = th_d; STATUS[fi] = 0; fi += 1
        if slip_at is None:
            t = duration; break
        t = slip_at; th_d = theta_disc_of_t(t)
        x = r_stick*np.cos(phi_stick + th_d)
        yy = r_stick*np.sin(phi_stick + th_d)
        om = omega_disc(t); vx = -om*yy; vy = om*x
        status = 1; continue

    rm = (t_frames > t + 1e-12) & (t_frames <= duration + 1e-12)
    t_eval_seg = t_frames[rm] if rm.any() else None
    sol = solve_ivp(slip_ode, (t, duration), [x, yy, vx, vy],
                    method="RK45", rtol=1e-9, atol=1e-11,
                    max_step=5e-3, events=re_stick, t_eval=t_eval_seg)
    for j, tf in enumerate(sol.t):
        if fi < n_frames and abs(t_frames[fi]-tf) < 1e-6:
            X_hist[fi] = sol.y[0,j]; Y_hist[fi] = sol.y[1,j]
            DISC_HIST[fi] = theta_disc_of_t(tf); STATUS[fi] = 1; fi += 1
    if sol.t_events[0].size > 0:
        te = sol.t_events[0][0]; ye = sol.y_events[0][0]
        while fi < n_frames and t_frames[fi] <= te + 1e-9:
            tf = t_frames[fi]
            X_hist[fi] = ye[0]; Y_hist[fi] = ye[1]
            DISC_HIST[fi] = theta_disc_of_t(tf); STATUS[fi] = 1; fi += 1
        t = te; x, yy, vx, vy = ye
        if req_force(x, yy, t) <= mu_s*m_b*g:
            status = 0; r_stick = np.hypot(x, yy)
            phi_stick = np.arctan2(yy, x) - theta_disc_of_t(t)
        else:
            r_here = np.hypot(x, yy)
            if r_here > 1e-9:
                vx += 1e-2*x/r_here; vy += 1e-2*yy/r_here
    else:
        t = duration
        if sol.y.shape[1] > 0: x, yy, vx, vy = sol.y[:,-1]
        break

while fi < n_frames:
    X_hist[fi] = x; Y_hist[fi] = yy
    DISC_HIST[fi] = theta_disc_of_t(t_frames[fi])
    STATUS[fi] = status; fi += 1

W, H = 6.0, 6.0
fig = plt.figure(figsize=(W,H), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1])
ax.set_facecolor("#16213e")
ax.axis("off"); ax.set_aspect("equal")
extent = R_disc + 0.20
ax.set_xlim(-extent, +extent); ax.set_ylim(-extent, +extent)

disc = Circle((0.0,0.0), R_disc, facecolor="#21304e", edgecolor="#a8dadc", lw=1.2, zorder=1)
ax.add_patch(disc)
spokes = []
for i in range(4):
    ln, = ax.plot([],[], "-", color="#a8dadc", lw=1.6, zorder=2)
    spokes.append(ln)
anchor = Circle((0.0,0.0), 0.018, facecolor="#ffffff", edgecolor="#1a1a2e", lw=0.6, zorder=6)
ax.add_patch(anchor)
spring_l, = ax.plot([],[], "-", color="#f4a261", lw=1.8, zorder=4)
trail, = ax.plot([],[], "-", color="#e63946", lw=1.0, alpha=0.5, zorder=3)
block_size = 0.10
block = Rectangle((-block_size/2, -block_size/2), block_size, block_size,
                  facecolor="#e63946", edgecolor="#ffffff", lw=1.0, zorder=5)
ax.add_patch(block)

def sp_path(x1, y1, x2, y2, n_coils=10, amp=0.025):
    dx, dy = x2-x1, y2-y1; L = np.hypot(dx,dy)
    if L < 1e-10: return np.array([x1,x2]), np.array([y1,y2])
    ux, uy = dx/L, dy/L; nx, ny = -uy, ux
    np_pts = n_coils*20+2
    s = np.linspace(0,1, np_pts); m = 0.10
    env = np.where((s<m)|(s>1-m), 0.0, np.sin(n_coils*2*np.pi*(s-m)/(1-2*m)))
    return x1+s*dx+amp*env*nx, y1+s*dy+amp*env*ny

def update(f):
    th_d = DISC_HIST[f]
    for i, ln in enumerate(spokes):
        ang = th_d + i*(np.pi/2.0)
        ln.set_data([0.0, R_disc*0.95*np.cos(ang)],
                    [0.0, R_disc*0.95*np.sin(ang)])
    bx, by = X_hist[f], Y_hist[f]
    sxs, sys = sp_path(0.0, 0.0, bx, by)
    spring_l.set_data(sxs, sys)
    lo = max(0, f-150)
    trail.set_data(X_hist[lo:f+1], Y_hist[lo:f+1])
    tr = (mtransforms.Affine2D().rotate(th_d).translate(bx, by)) + ax.transData
    block.set_transform(tr)
    return spokes + [spring_l, trail, block, anchor]

ani = animation.FuncAnimation(fig, update, frames=n_frames, interval=1000/fps, blit=False)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=2400), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Spinning Disc + Block + Spring")
    parser.add_argument("--g", type=float, default=9.8)
    parser.add_argument("--m_b", type=float, default=0.30)
    parser.add_argument("--R_disc", type=float, default=0.80)
    parser.add_argument("--L_0", type=float, default=0.30)
    parser.add_argument("--k", type=float, default=8.0)
    parser.add_argument("--mu_s", type=float, default=0.40)
    parser.add_argument("--mu_k", type=float, default=0.30)
    parser.add_argument("--omega_max", type=float, default=5.0)
    parser.add_argument("--t_ramp", type=float, default=4.0)
    parser.add_argument("--x_b_0", type=float, default=0.30)
    parser.add_argument("--y_b_0", type=float, default=0.0)
    parser.add_argument("--vx_b_0", type=float, default=0.0)
    parser.add_argument("--vy_b_0", type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="spinning_disc_block_spring.mp4")
    args = parser.parse_args()

    p = SpinningDiscBlockSpringParams(
        g=args.g, m_b=args.m_b, R_disc=args.R_disc, L_0=args.L_0, k=args.k,
        mu_s=args.mu_s, mu_k=args.mu_k,
        omega_max=args.omega_max, t_ramp=args.t_ramp,
        x_b_0=args.x_b_0, y_b_0=args.y_b_0,
        vx_b_0=args.vx_b_0, vy_b_0=args.vy_b_0,
    )
    print(f"Simulating spinning disc + block + spring: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
