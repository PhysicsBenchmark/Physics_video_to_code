"""
Spinning Ball on a Moving Belt (with belt acceleration)
=======================================================
A solid (or hollow) ball is placed on a horizontal conveyor belt whose
velocity itself can change linearly:
  v_belt(t)  =  v_belt_0 + a_belt · t
Either the belt or the ball (or both) may have non-zero initial motion in
either direction.  Coulomb friction at the ball-belt contact translates and
spins the ball; both evolve until the contact-point velocity matches the
instantaneous belt-surface velocity (pure rolling on the *moving* belt):
  v_ball − ω r  =  v_belt(t).
If the belt itself is accelerating the rolling state must also accelerate;
once |a_belt| > μ_k g (1 + 1/I_factor) the ball *cannot* keep up and slips
forever.

Conventions (1-D translation + planar spin):
  • ω is the FORWARD-ROLLING angular rate (ω > 0 ⇒ top of ball moves +x).
  • v_contact = v_ball − ω r          (lab velocity of the bottom of the ball)
  • v_rel    = v_contact − v_belt(t)  (slip speed of contact relative to belt)

Equations of motion:
  F_x = − μ_k M g · sgn(v_rel)        (regularised: − μ_k M g · tanh(α v_rel))
  M dv/dt   = F_x
  I dω/dt   = (r_contact × F)_⊥ = − r F_x   ⇒   dω/dt = −F_x / (I_factor · M · r)
  dx/dt     = v
  dθ/dt     = − ω        (visual marker rotates CW when ω > 0)

The render uses a CAMERA-FOLLOWING window (axis recentres on the ball each
frame) so the ball is always visible regardless of belt direction or how
much the belt has accelerated.  Belt-surface motion is conveyed by drifting
tick marks whose lab positions evolve as
  x_tick_i(t)  =  i · tick_spacing + ∫₀ᵗ v_belt(τ) dτ
                  = i · tick_spacing + v_belt_0 t + ½ a_belt t²
and are wrapped into the visible window each frame.  No on-frame text or
numerals are rendered — pure visual only.
"""

from __future__ import annotations
import math
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis


@dataclass
class SpinningBallOnMovingBeltParams:
    M: float = 1.0           # ball mass (kg)
    r: float = 0.12          # ball radius (m)
    v_belt_0: float = 0.7    # initial belt velocity (m/s, signed)
    a_belt: float = 0.0      # belt acceleration (m/s², signed)
    mu_k: float = 0.05       # Coulomb friction coefficient (ball-belt)
    I_factor: float = 0.40   # I_cm = I_factor · M · r²  (0.4 solid sphere → 0.667 thin shell)
    g: float = 9.81
    alpha_tanh: float = 80.0
    x0: float = 0.0
    v0: float = 0.0
    theta0: float = 0.0
    omega0: float = 0.0      # initial ball angular velocity (forward-rolling sign)
    cam_window: float = 4.0  # full width of the camera-following frame (m)
    belt_thickness: float = 0.12


def ode(t: float, y: list, p: SpinningBallOnMovingBeltParams):
    x, v, theta, omega = y
    v_belt_t  = p.v_belt_0 + p.a_belt * t
    v_contact = v - omega * p.r
    v_rel     = v_contact - v_belt_t
    F_x       = -p.mu_k * p.M * p.g * np.tanh(p.alpha_tanh * v_rel)
    I         = p.I_factor * p.M * p.r * p.r
    dv        = F_x / p.M
    domega    = -p.r * F_x / I
    dtheta    = -omega
    return [v, dv, dtheta, domega]


def simulate(params: SpinningBallOnMovingBeltParams,
             duration: float = 12.0, fps: int = 30):
    t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode, (0.0, duration),
        [params.x0, params.v0, params.theta0, params.omega0],
        args=(params,), t_eval=t_eval,
        method="RK45", rtol=1e-9, atol=1e-11,
    )
    return sol.t, sol.y


def render_video(t: np.ndarray, y: np.ndarray,
                 params: SpinningBallOnMovingBeltParams,
                 output_path: str, fps: int = 30) -> None:
    x, v, theta, omega = y[0], y[1], y[2], y[3]
    r          = params.r
    belt_thick = params.belt_thickness
    W          = params.cam_window                 # full window width
    HW         = W / 2.0                            # half width

    y_min = -belt_thick - 0.18
    y_max = 2.0 * r + 0.30

    fig, ax = plt.subplots(figsize=(10, 4.4))
    setup_dark_axis(
        fig, ax,
        xlim=(-HW, HW), ylim=(y_min, y_max),       # placeholder, updated each frame
        title="",
    )

    # Belt body — drawn very wide so it always covers the camera window
    belt_rect = patches.Rectangle(
        (-200.0, -belt_thick), 400.0, belt_thick,
        facecolor="#3a3a4f", edgecolor="white", lw=1.2, zorder=1,
    )
    ax.add_patch(belt_rect)

    # Drifting tick marks (visual indicator of belt direction & speed)
    N_ticks      = 24
    tick_spacing = W / N_ticks
    tick_y0      = -belt_thick * 0.85
    tick_y1      = -belt_thick * 0.15
    tick_lines   = [ax.plot([], [], "-", color="#a8dadc", lw=1.5,
                            zorder=3)[0] for _ in range(N_ticks)]

    # Ball + two perpendicular rotation spokes
    ball_circle = patches.Circle((params.x0, r), r,
                                  facecolor="#457b9d", edgecolor="white",
                                  lw=1.6, zorder=4)
    ax.add_patch(ball_circle)
    spoke_h, = ax.plot([], [], "-", color="#e63946", lw=2.6, zorder=5)
    spoke_v, = ax.plot([], [], "-", color="#ffd166", lw=2.6, zorder=5)

    def update(frame: int):
        cx       = float(x[frame])
        th       = float(theta[frame])
        t_now    = float(t[frame])
        belt_disp = params.v_belt_0 * t_now + 0.5 * params.a_belt * t_now * t_now

        # Camera follows the ball
        ax.set_xlim(cx - HW, cx + HW)

        ball_circle.center = (cx, r)
        spoke_h.set_data(
            [cx, cx + r * math.cos(th)],
            [r,  r  + r * math.sin(th)],
        )
        spoke_v.set_data(
            [cx, cx + r * math.cos(th + math.pi / 2.0)],
            [r,  r  + r * math.sin(th + math.pi / 2.0)],
        )

        # Drift the ticks at v_belt(t); wrap inside camera window centred on ball
        for i, line in enumerate(tick_lines):
            x_orig_rel = (i + 0.5) * tick_spacing - HW
            x_drifted  = x_orig_rel + belt_disp
            x_wrapped  = ((x_drifted + HW) % W) - HW
            x_lab      = cx + x_wrapped
            line.set_data([x_lab, x_lab], [tick_y0, tick_y1])
        return [ball_circle, spoke_h, spoke_v] + tick_lines

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), interval=1000 / fps, blit=False,
    )
    ani.save(output_path,
             writer=animation.FFMpegWriter(fps=fps, bitrate=1800),
             dpi=120)
    plt.close(fig)


def make_standalone_script(params: SpinningBallOnMovingBeltParams,
                           duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""
Spinning Ball on a Moving Belt — auto-generated standalone simulation.

Belt:  v_belt(t) = v_belt_0 + a_belt · t.
Ball:  Newton-Euler, Coulomb friction at the contact point opposing
       v_rel = (v - omega r) - v_belt(t).
Camera-following render; no on-frame text or numerals.
"""
import math
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

# ── Parameters ──────────────────────────────────────────────────────────────
M             = {p["M"]}
r             = {p["r"]}
v_belt_0      = {p["v_belt_0"]}
a_belt        = {p["a_belt"]}
mu_k          = {p["mu_k"]}
I_factor      = {p["I_factor"]}
g             = {p["g"]}
alpha_tanh    = {p["alpha_tanh"]}
x0            = {p["x0"]}
v0            = {p["v0"]}
theta0        = {p["theta0"]}
omega0        = {p["omega0"]}
cam_window    = {p["cam_window"]}
belt_thick    = {p["belt_thickness"]}
duration      = {duration}
fps           = 30
I             = I_factor * M * r * r

def ode(t, y):
    x, v, theta, omega = y
    v_belt_t  = v_belt_0 + a_belt * t
    v_contact = v - omega * r
    v_rel     = v_contact - v_belt_t
    F_x       = -mu_k * M * g * np.tanh(alpha_tanh * v_rel)
    return [v, F_x / M, -omega, -r * F_x / I]

t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
sol = solve_ivp(ode, (0.0, duration), [x0, v0, theta0, omega0],
                t_eval=t_eval, method="RK45", rtol=1e-9, atol=1e-11)
t = sol.t; x_arr, v_arr, theta_arr, omega_arr = sol.y[0], sol.y[1], sol.y[2], sol.y[3]

# ── Camera-following render (no on-frame text) ─────────────────────────────
HW = cam_window / 2.0
y_min = -belt_thick - 0.18
y_max = 2.0 * r + 0.30

fig, ax = plt.subplots(figsize=(10, 4.4), facecolor="#1a1a2e")
ax.set_facecolor("#16213e")
ax.set_xlim(-HW, HW); ax.set_ylim(y_min, y_max)
ax.set_aspect("equal"); ax.axis("off")

belt_rect = patches.Rectangle((-200.0, -belt_thick), 400.0, belt_thick,
    facecolor="#3a3a4f", edgecolor="white", lw=1.2, zorder=1)
ax.add_patch(belt_rect)

N_ticks      = 24
tick_spacing = cam_window / N_ticks
tick_y0      = -belt_thick * 0.85
tick_y1      = -belt_thick * 0.15
tick_lines   = [ax.plot([], [], "-", color="#a8dadc", lw=1.5,
                        zorder=3)[0] for _ in range(N_ticks)]

ball_circle = patches.Circle((x0, r), r, facecolor="#457b9d", edgecolor="white",
                              lw=1.6, zorder=4)
ax.add_patch(ball_circle)
spoke_h, = ax.plot([], [], "-", color="#e63946", lw=2.6, zorder=5)
spoke_v, = ax.plot([], [], "-", color="#ffd166", lw=2.6, zorder=5)


def update(frame):
    cx = float(x_arr[frame]); th = float(theta_arr[frame])
    t_now = float(t[frame])
    belt_disp = v_belt_0 * t_now + 0.5 * a_belt * t_now * t_now

    ax.set_xlim(cx - HW, cx + HW)
    ball_circle.center = (cx, r)
    spoke_h.set_data([cx, cx + r * math.cos(th)],
                     [r,  r  + r * math.sin(th)])
    spoke_v.set_data([cx, cx + r * math.cos(th + math.pi / 2.0)],
                     [r,  r  + r * math.sin(th + math.pi / 2.0)])
    for i, line in enumerate(tick_lines):
        x_orig_rel = (i + 0.5) * tick_spacing - HW
        x_drifted  = x_orig_rel + belt_disp
        x_wrapped  = ((x_drifted + HW) % cam_window) - HW
        x_lab      = cx + x_wrapped
        line.set_data([x_lab, x_lab], [tick_y0, tick_y1])
    return [ball_circle, spoke_h, spoke_v] + tick_lines

ani = animation.FuncAnimation(fig, update, frames=len(t),
                              interval=1000 / fps, blit=False)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close(); print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Spinning ball on moving belt")
    ap.add_argument("--M",         type=float, default=1.0)
    ap.add_argument("--r",         type=float, default=0.12)
    ap.add_argument("--v_belt_0",  type=float, default=0.7)
    ap.add_argument("--a_belt",    type=float, default=0.0)
    ap.add_argument("--omega0",    type=float, default=0.0)
    ap.add_argument("--mu_k",      type=float, default=0.05)
    ap.add_argument("--I_factor",  type=float, default=0.40)
    ap.add_argument("--duration",  type=float, default=12.0)
    ap.add_argument("--output",    type=str,   default="spinning_ball_on_moving_belt.mp4")
    args = ap.parse_args()

    p = SpinningBallOnMovingBeltParams(
        M=args.M, r=args.r, v_belt_0=args.v_belt_0, a_belt=args.a_belt,
        mu_k=args.mu_k, I_factor=args.I_factor, omega0=args.omega0,
    )
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
