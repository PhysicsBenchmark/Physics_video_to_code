"""
Balls in a Basin — N spherical balls fall into a U-shaped basin and bounce.
Velocity-Verlet integrator with ball-wall and ball-ball collision impulses.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, field, asdict
from typing import List
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class BallsInBasinParams:
    g: float = 9.8
    # Seed in [0, 1) drives all per-ball randomization (N, radii, masses, pos_0, vel_0).
    # Allows the generator to vary the layout deterministically by varying just `seed`.
    seed: float = 0.5
    e_wall: float = 0.78
    e_ball: float = 0.92
    mu_floor: float = 0.04
    x_left: float = -1.10
    x_right: float = 1.10
    y_wall: float = 1.60
    duration: float = 12.0
    dt: float = 0.002
    # Auto-populated in __post_init__ from `seed` unless explicitly set.
    N: int = 0
    masses: List[float] = field(default_factory=list)
    radii: List[float] = field(default_factory=list)
    pos_0: List[List[float]] = field(default_factory=list)
    vel_0: List[List[float]] = field(default_factory=list)

    def __post_init__(self):
        # Only derive when N hasn't been explicitly provided (== 0).
        if self.N == 0:
            self._derive_from_seed()

    def _derive_from_seed(self):
        rng = np.random.default_rng(int(round(self.seed * 10_000_000)))
        # N: integer in [3, 8] inclusive.
        self.N = int(rng.integers(3, 9))
        # Radii: uniform in [0.07, 0.13] m.
        self.radii = rng.uniform(0.07, 0.13, size=self.N).tolist()
        # Masses: roughly area-proportional to radius² with a 15% multiplicative jitter.
        self.masses = [
            float(0.30 + 0.60 * (r / 0.10) ** 2 * rng.uniform(0.85, 1.15))
            for r in self.radii
        ]
        # Positions: evenly spread across the basin width (with small jitter), random
        # y in the upper half of the basin so they all start in the air.
        r_max = max(self.radii)
        usable_x = (self.x_right - self.x_left) - 2 * r_max - 0.10
        x_step = usable_x / max(self.N, 1)
        x_start = self.x_left + r_max + 0.05 + x_step / 2
        positions = []
        for i in range(self.N):
            x_target = x_start + i * x_step
            jitter = rng.uniform(-x_step / 4, x_step / 4)
            y_min = 0.70
            y_max = max(y_min + 1e-3, self.y_wall - 0.30)
            positions.append([float(x_target + jitter), float(rng.uniform(y_min, y_max))])
        self.pos_0 = positions
        # Velocities: alternating-sign small horizontal kicks; zero vertical velocity.
        signs = rng.choice([-1.0, 1.0], size=self.N).tolist()
        speeds = rng.uniform(0.20, 0.55, size=self.N).tolist()
        self.vel_0 = [[float(speeds[i] * signs[i]), 0.0] for i in range(self.N)]


def _run_sim(p):
    N = p.N
    masses = np.asarray(p.masses, dtype=float)
    radii = np.asarray(p.radii, dtype=float)
    pos = np.asarray(p.pos_0, dtype=float).copy()
    vel = np.asarray(p.vel_0, dtype=float).copy()
    dt = p.dt
    n_steps = int(round(p.duration / dt))
    fps = 30
    stride = int(round((1.0 / fps) / dt))
    n_frames = n_steps // stride + 1
    a_grav = np.array([0.0, -p.g])
    frames_pos = np.zeros((n_frames, N, 2))
    frames_pos[0] = pos
    frame_idx = 1

    def resolve_walls():
        for i in range(N):
            r = radii[i]
            if pos[i, 0] - r < p.x_left:
                pos[i, 0] = p.x_left + r
                if vel[i, 0] < 0.0:
                    vel[i, 0] = -p.e_wall * vel[i, 0]
            if pos[i, 0] + r > p.x_right:
                pos[i, 0] = p.x_right - r
                if vel[i, 0] > 0.0:
                    vel[i, 0] = -p.e_wall * vel[i, 0]
            if pos[i, 1] - r < 0.0:
                pos[i, 1] = r
                if vel[i, 1] < 0.0:
                    vel[i, 1] = -p.e_wall * vel[i, 1]
                    vel[i, 0] *= (1.0 - p.mu_floor)

    def resolve_pairs():
        for _it in range(4):
            any_overlap = False
            for i in range(N):
                for j in range(i+1, N):
                    d = pos[j] - pos[i]
                    dist = float(np.hypot(d[0], d[1]))
                    rsum = radii[i] + radii[j]
                    if dist >= rsum or dist < 1e-12:
                        continue
                    nhat = d / dist
                    v_rel = vel[j] - vel[i]
                    vn = float(v_rel @ nhat)
                    overlap = rsum - dist
                    inv_mi = 1.0 / masses[i]
                    inv_mj = 1.0 / masses[j]
                    inv_sum = inv_mi + inv_mj
                    pos[i] -= (overlap * inv_mi / inv_sum) * nhat
                    pos[j] += (overlap * inv_mj / inv_sum) * nhat
                    if vn < 0.0:
                        Jn = -(1.0 + p.e_ball) * vn / inv_sum
                        vel[i] -= (Jn * inv_mi) * nhat
                        vel[j] += (Jn * inv_mj) * nhat
                    any_overlap = True
            if not any_overlap:
                break

    for step in range(1, n_steps + 1):
        vel += 0.5 * a_grav * dt
        pos += vel * dt
        vel += 0.5 * a_grav * dt
        resolve_walls()
        resolve_pairs()
        if step % stride == 0 and frame_idx < n_frames:
            frames_pos[frame_idx] = pos
            frame_idx += 1
    return frames_pos, n_frames


def simulate(params: BallsInBasinParams, duration: float = 12.0, fps: int = 30):
    if duration is not None:
        params.duration = duration
    frames_pos, n_frames = _run_sim(params)
    t = np.linspace(0.0, params.duration, n_frames)
    # Pack as y of shape (2*N, n_frames)
    N = params.N
    y = np.zeros((2 * N, n_frames))
    for i in range(N):
        y[2*i] = frames_pos[:, i, 0]
        y[2*i+1] = frames_pos[:, i, 1]
    return t, y


def render_video(t, y, params: BallsInBasinParams, output_path: str, fps: int = 30):
    p = params
    N = p.N
    radii = np.asarray(p.radii)
    n_frames = y.shape[1]
    frames_pos = np.zeros((n_frames, N, 2))
    for i in range(N):
        frames_pos[:, i, 0] = y[2*i]
        frames_pos[:, i, 1] = y[2*i+1]

    fig_w, fig_h = 8, 5
    fig_aspect = fig_w / fig_h
    x_lo_d, x_hi_d = p.x_left - 0.20, p.x_right + 0.20
    y_lo_d, y_hi_d = -0.20, p.y_wall + 0.40
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")
    ax.add_patch(patches.Rectangle((x_lo, y_lo), x_hi - x_lo, -y_lo,
                                    facecolor="#4a4e69", edgecolor="none", zorder=0))
    wall_thick = 0.10
    ax.add_patch(patches.Rectangle((p.x_left - wall_thick, 0.0), wall_thick, p.y_wall,
                                    facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.add_patch(patches.Rectangle((p.x_right, 0.0), wall_thick, p.y_wall,
                                    facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.plot([x_lo, x_hi], [0, 0], color="#adb5bd", lw=2.5, zorder=1)
    ax.plot([p.x_left, p.x_left], [0, p.y_wall], color="#adb5bd", lw=2.5, zorder=1)
    ax.plot([p.x_right, p.x_right], [0, p.y_wall], color="#adb5bd", lw=2.5, zorder=1)

    ball_colors = ["#e63946", "#ffd166", "#06d6a0", "#118ab2", "#7b2cbf",
                   "#f4a261", "#9b5de5", "#00bbf9", "#fb6f92", "#80ed99"]
    circles = []
    for i in range(N):
        c = patches.Circle(tuple(frames_pos[0, i]), float(radii[i]),
                           facecolor=ball_colors[i % len(ball_colors)],
                           edgecolor="white", lw=1.5, zorder=3)
        ax.add_patch(c)
        circles.append(c)

    def update(f):
        for i, c in enumerate(circles):
            c.center = (float(frames_pos[f, i, 0]), float(frames_pos[f, i, 1]))
        return circles

    ani = animation.FuncAnimation(fig, update, frames=n_frames,
                                  interval=1000.0/fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: BallsInBasinParams, duration: float = 12.0) -> str:
    p = asdict(params)
    p["duration"] = duration
    return f'''"""Balls in basin - standalone script."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

g        = {p["g"]}
N        = {p["N"]}
masses   = np.array({p["masses"]})
radii    = np.array({p["radii"]})
e_wall   = {p["e_wall"]}
e_ball   = {p["e_ball"]}
mu_floor = {p["mu_floor"]}
x_left   = {p["x_left"]}
x_right  = {p["x_right"]}
y_wall   = {p["y_wall"]}
duration = {p["duration"]}
pos_0 = np.array({p["pos_0"]}, dtype=float)
vel_0 = np.array({p["vel_0"]}, dtype=float)

dt = {p["dt"]}
n_steps = int(round(duration / dt))
fps = 30
stride = max(1, int(round((1.0 / fps) / dt)))
n_frames = n_steps // stride + 1
a_grav = np.array([0.0, -g])

pos = pos_0.copy()
vel = vel_0.copy()
frames_pos = np.zeros((n_frames, N, 2))
frames_pos[0] = pos
frame_idx = 1

def resolve_walls():
    for i in range(N):
        r = radii[i]
        if pos[i, 0] - r < x_left:
            pos[i, 0] = x_left + r
            if vel[i, 0] < 0.0:
                vel[i, 0] = -e_wall * vel[i, 0]
        if pos[i, 0] + r > x_right:
            pos[i, 0] = x_right - r
            if vel[i, 0] > 0.0:
                vel[i, 0] = -e_wall * vel[i, 0]
        if pos[i, 1] - r < 0.0:
            pos[i, 1] = r
            if vel[i, 1] < 0.0:
                vel[i, 1] = -e_wall * vel[i, 1]
                vel[i, 0] *= (1.0 - mu_floor)

def resolve_pairs():
    for _it in range(4):
        any_overlap = False
        for i in range(N):
            for j in range(i+1, N):
                d = pos[j] - pos[i]
                dist = float(np.hypot(d[0], d[1]))
                rsum = radii[i] + radii[j]
                if dist >= rsum or dist < 1e-12:
                    continue
                nhat = d / dist
                v_rel = vel[j] - vel[i]
                vn = float(v_rel @ nhat)
                overlap = rsum - dist
                inv_mi = 1.0 / masses[i]
                inv_mj = 1.0 / masses[j]
                inv_sum = inv_mi + inv_mj
                pos[i] -= (overlap * inv_mi / inv_sum) * nhat
                pos[j] += (overlap * inv_mj / inv_sum) * nhat
                if vn < 0.0:
                    Jn = -(1.0 + e_ball) * vn / inv_sum
                    vel[i] -= (Jn * inv_mi) * nhat
                    vel[j] += (Jn * inv_mj) * nhat
                any_overlap = True
        if not any_overlap:
            break

for step in range(1, n_steps + 1):
    vel += 0.5 * a_grav * dt
    pos += vel * dt
    vel += 0.5 * a_grav * dt
    resolve_walls()
    resolve_pairs()
    if step % stride == 0 and frame_idx < n_frames:
        frames_pos[frame_idx] = pos
        frame_idx += 1

fig_w, fig_h = 8, 5
fig_aspect = fig_w / fig_h
x_lo_d, x_hi_d = x_left - 0.20, x_right + 0.20
y_lo_d, y_hi_d = -0.20, y_wall + 0.40
dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
if dx / dy < fig_aspect:
    extra = (fig_aspect * dy - dx) / 2.0
    x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
else:
    extra = (dx / fig_aspect - dy) / 2.0
    x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0, 0, 1, 1])
ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(patches.Rectangle((x_lo, y_lo), x_hi - x_lo, -y_lo,
                                facecolor="#4a4e69", edgecolor="none", zorder=0))
wall_thick = 0.10
ax.add_patch(patches.Rectangle((x_left - wall_thick, 0.0), wall_thick, y_wall,
                                facecolor="#4a4e69", edgecolor="none", zorder=0))
ax.add_patch(patches.Rectangle((x_right, 0.0), wall_thick, y_wall,
                                facecolor="#4a4e69", edgecolor="none", zorder=0))
ax.plot([x_lo, x_hi], [0, 0], color="#adb5bd", lw=2.5, zorder=1)
ax.plot([x_left, x_left], [0, y_wall], color="#adb5bd", lw=2.5, zorder=1)
ax.plot([x_right, x_right], [0, y_wall], color="#adb5bd", lw=2.5, zorder=1)

ball_colors = ["#e63946", "#ffd166", "#06d6a0", "#118ab2", "#7b2cbf",
               "#f4a261", "#9b5de5", "#00bbf9", "#fb6f92", "#80ed99"]
circles = []
for i in range(N):
    c = patches.Circle(tuple(frames_pos[0, i]), float(radii[i]),
                       facecolor=ball_colors[i % len(ball_colors)],
                       edgecolor="white", lw=1.5, zorder=3)
    ax.add_patch(c)
    circles.append(c)

def update(f):
    for i, c in enumerate(circles):
        c.center = (float(frames_pos[f, i, 0]), float(frames_pos[f, i, 1]))
    return circles

ani = animation.FuncAnimation(fig, update, frames=n_frames,
                              interval=1000.0/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    p = BallsInBasinParams()
    t, y = simulate(p, duration=p.duration)
    render_video(t, y, p, "video.mp4")
