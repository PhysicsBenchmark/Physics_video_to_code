"""
Accelerating Beaker — Water Surface Tilts to Angled Equilibrium.

In a frame accelerating leftward at constant magnitude a, the water free surface
in a beaker tilts toward +x by theta_eq = atan(a/g).  Approach to equilibrium is
modelled as a damped oscillation with omega_slosh = sqrt(g (pi/L) tanh(pi h/L))
and damping gamma_settle.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon, Rectangle
from matplotlib.collections import LineCollection
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class AcceleratingBeakerWaterParams:
    g: float = 9.81
    a_lab: float = 2.0
    L_beaker: float = 1.00
    H_beaker: float = 0.60
    wall_thick: float = 0.025
    h_water_eq: float = 0.30
    gamma_settle: float = 0.8
    duration: float = 5.0
    fps: int = 30


def simulate(params: AcceleratingBeakerWaterParams,
             duration: float = 5.0, fps: int = 30):
    """Returns (t, y) where y[0] = theta(t), y[1] = x_beaker_lab(t)."""
    g = params.g
    a = params.a_lab
    L = params.L_beaker
    h = params.h_water_eq
    gamma = params.gamma_settle
    theta_eq = np.arctan(a / g)
    omega_slosh = np.sqrt(g * (np.pi / L) * np.tanh(np.pi * h / L))
    omega_d = np.sqrt(max(omega_slosh**2 - gamma**2, 1e-12))
    n_frames = int(duration * fps) + 1
    t = np.linspace(0.0, duration, n_frames)
    theta = theta_eq * (1.0 - np.exp(-gamma * t)
                        * (np.cos(omega_d * t) + (gamma / omega_d) * np.sin(omega_d * t)))
    x_beaker = -0.5 * a * t * t
    y = np.stack([theta, x_beaker])
    return t, y


def render_video(t, y, params: AcceleratingBeakerWaterParams,
                 output_path: str, fps: int = 30):
    L_beaker = params.L_beaker
    H_beaker = params.H_beaker
    wall_thick = params.wall_thick
    h_water_eq = params.h_water_eq
    theta_arr = y[0]
    x_beaker_arr = y[1]

    fig_w, fig_h = 12.0, 6.0
    fig_aspect = fig_w / fig_h
    x_lo_d, x_hi_d = -2.6, 2.6
    y_lo_d, y_hi_d = -0.30, H_beaker + 0.50
    dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_d / dy_d < fig_aspect:
        extra = (fig_aspect * dy_d - dx_d) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx_d / fig_aspect - dy_d) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    ax.add_patch(Polygon([(x_lo, y_lo), (x_hi, y_lo), (x_hi, 0.0), (x_lo, 0.0)],
                         facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.plot([x_lo, x_hi], [0.0, 0.0], color="#adb5bd", lw=2.0, zorder=1)

    dx_marker = 0.35
    marker_lc = LineCollection([], colors="#adb5bd", linewidths=1.5, zorder=1)
    ax.add_collection(marker_lc)

    ax.add_patch(Rectangle((-L_beaker / 2 - wall_thick, 0.0), wall_thick, H_beaker,
                           facecolor="#3a4357", edgecolor="#adb5bd", lw=1.0, zorder=4))
    ax.add_patch(Rectangle((+L_beaker / 2, 0.0), wall_thick, H_beaker,
                           facecolor="#3a4357", edgecolor="#adb5bd", lw=1.0, zorder=4))
    ax.add_patch(Rectangle((-L_beaker / 2 - wall_thick, -wall_thick),
                           L_beaker + 2 * wall_thick, wall_thick,
                           facecolor="#3a4357", edgecolor="#adb5bd", lw=1.0, zorder=4))

    water_poly = Polygon([(0, 0)] * 4, facecolor="#5b8db8",
                         edgecolor="#a8dadc", lw=1.5, alpha=0.90, zorder=2)
    ax.add_patch(water_poly)

    # Acceleration arrow indicator (no text labels)
    y_arrow = y_hi - 0.16
    ax.annotate("", xy=(-0.55, y_arrow), xytext=(0.55, y_arrow),
                arrowprops=dict(arrowstyle="->,head_length=0.4,head_width=0.2",
                                color="#e63946", lw=3.0), zorder=10)

    half = L_beaker / 2

    def update(f):
        theta = float(theta_arr[f])
        y_left = h_water_eq + np.tan(theta) * (-half)
        y_right = h_water_eq + np.tan(theta) * (+half)
        water_poly.set_xy([(-half, 0.0), (+half, 0.0),
                           (+half, y_right), (-half, y_left)])
        shift = -float(x_beaker_arr[f])
        k_min = int(np.floor((x_lo - shift) / dx_marker)) - 1
        k_max = int(np.ceil((x_hi - shift) / dx_marker)) + 1
        segs = []
        for k in range(k_min, k_max + 1):
            xm = k * dx_marker + shift
            if x_lo - 0.05 <= xm <= x_hi + 0.05:
                segs.append([(xm, -0.05), (xm, 0.05)])
        marker_lc.set_segments(segs)
        return water_poly, marker_lc

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0 / fps, blit=False)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: AcceleratingBeakerWaterParams,
                           duration: float = 5.0) -> str:
    p = asdict(params)
    return f'''"""Accelerating beaker water - standalone script."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon, Rectangle
from matplotlib.collections import LineCollection

g = {p["g"]}
a_lab = {p["a_lab"]}
L_beaker = {p["L_beaker"]}
H_beaker = {p["H_beaker"]}
wall_thick = {p["wall_thick"]}
h_water_eq = {p["h_water_eq"]}
gamma_set = {p["gamma_settle"]}
duration = {duration}
fps = {p["fps"]}

theta_eq = np.arctan(a_lab / g)
omega_slosh = np.sqrt(g * (np.pi / L_beaker) * np.tanh(np.pi * h_water_eq / L_beaker))
omega_d = np.sqrt(max(omega_slosh**2 - gamma_set**2, 1e-12))
n_frames = int(duration * fps) + 1


def theta_at(t):
    return theta_eq * (1.0 - np.exp(-gamma_set * t) * (np.cos(omega_d * t) + (gamma_set / omega_d) * np.sin(omega_d * t)))


def x_beaker_lab(t):
    return -0.5 * a_lab * t * t


fig_w, fig_h = 12.0, 6.0
fig_aspect = fig_w / fig_h
x_lo_d, x_hi_d = -2.6, 2.6
y_lo_d, y_hi_d = -0.30, H_beaker + 0.50
dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
if dx_d / dy_d < fig_aspect:
    extra = (fig_aspect * dy_d - dx_d) / 2.0
    x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
    y_lo, y_hi = y_lo_d, y_hi_d
else:
    extra = (dx_d / fig_aspect - dy_d) / 2.0
    x_lo, x_hi = x_lo_d, x_hi_d
    y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0, 0, 1, 1])
ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")

ax.add_patch(Polygon([(x_lo, y_lo), (x_hi, y_lo), (x_hi, 0.0), (x_lo, 0.0)],
                     facecolor="#4a4e69", edgecolor="none", zorder=0))
ax.plot([x_lo, x_hi], [0.0, 0.0], color="#adb5bd", lw=2.0, zorder=1)

dx_marker = 0.35
marker_lc = LineCollection([], colors="#adb5bd", linewidths=1.5, zorder=1)
ax.add_collection(marker_lc)

ax.add_patch(Rectangle((-L_beaker / 2 - wall_thick, 0.0), wall_thick, H_beaker,
                       facecolor="#3a4357", edgecolor="#adb5bd", lw=1.0, zorder=4))
ax.add_patch(Rectangle((+L_beaker / 2, 0.0), wall_thick, H_beaker,
                       facecolor="#3a4357", edgecolor="#adb5bd", lw=1.0, zorder=4))
ax.add_patch(Rectangle((-L_beaker / 2 - wall_thick, -wall_thick),
                       L_beaker + 2 * wall_thick, wall_thick,
                       facecolor="#3a4357", edgecolor="#adb5bd", lw=1.0, zorder=4))

water_poly = Polygon([(0, 0)] * 4, facecolor="#5b8db8",
                     edgecolor="#a8dadc", lw=1.5, alpha=0.90, zorder=2)
ax.add_patch(water_poly)

y_arrow = y_hi - 0.16
ax.annotate("", xy=(-0.55, y_arrow), xytext=(0.55, y_arrow),
            arrowprops=dict(arrowstyle="->,head_length=0.4,head_width=0.2",
                            color="#e63946", lw=3.0), zorder=10)


def update(f):
    t = f / fps
    theta = theta_at(t)
    half = L_beaker / 2
    y_left = h_water_eq + np.tan(theta) * (-half)
    y_right = h_water_eq + np.tan(theta) * (+half)
    water_poly.set_xy([(-half, 0.0), (+half, 0.0),
                       (+half, y_right), (-half, y_left)])
    shift = -x_beaker_lab(t)
    k_min = int(np.floor((x_lo - shift) / dx_marker)) - 1
    k_max = int(np.ceil((x_hi - shift) / dx_marker)) + 1
    segs = []
    for k in range(k_min, k_max + 1):
        xm = k * dx_marker + shift
        if x_lo - 0.05 <= xm <= x_hi + 0.05:
            segs.append([(xm, -0.05), (xm, 0.05)])
    marker_lc.set_segments(segs)
    return water_poly, marker_lc


ani = animation.FuncAnimation(fig, update, frames=n_frames,
                              interval=1000.0 / fps, blit=False)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--g", type=float, default=9.81)
    parser.add_argument("--a_lab", type=float, default=2.0)
    parser.add_argument("--L_beaker", type=float, default=1.00)
    parser.add_argument("--H_beaker", type=float, default=0.60)
    parser.add_argument("--wall_thick", type=float, default=0.025)
    parser.add_argument("--h_water_eq", type=float, default=0.30)
    parser.add_argument("--gamma_settle", type=float, default=0.8)
    parser.add_argument("--duration", type=float, default=5.0)
    parser.add_argument("--output", type=str, default="video.mp4")
    args = parser.parse_args()
    p = AcceleratingBeakerWaterParams(g=args.g, a_lab=args.a_lab,
                                       L_beaker=args.L_beaker, H_beaker=args.H_beaker,
                                       wall_thick=args.wall_thick,
                                       h_water_eq=args.h_water_eq,
                                       gamma_settle=args.gamma_settle,
                                       duration=args.duration)
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
