"""
Complex Collision Plane — multiple objects on a frictionless 1-D track.
========================================================================
Top-view setup:
    [left wall] -- (objects with various types) -- [right wall]

Object types
------------
  * sphere       : circular rigid body, hard collisions
  * block        : rectangular rigid body, hard collisions
  * spring_a     : block with a free helical spring attached on one side
                   (collisions on that side are spring-mediated until the spring
                   fully compresses, then a hard contact takes over)
  * spring_pair  : two blocks coupled by a permanent internal helical spring
                   (a "diatomic" pair that translates and oscillates)

Physics
-------
  - Each body i obeys Newton's 2nd Law: m_i ẍ_i = ΣF_i.
  - Hard contacts are modeled as one-sided penalty springs with damping
    calibrated to deliver Newton's restitution e via
        e = exp(−π ζ / √(1−ζ²))   ⇒   ζ = −ln(e) / √(π² + ln²(e)).
  - Spring contacts (spring_a side, spring_pair internal) follow Hooke's law
        F = −k · Δx.
  - Walls are stiff one-sided penalty springs at the boundaries.
  - Total linear momentum is conserved (no external forces); total energy is
    conserved at e=1 and decreases by (1−e²)·½μ·v_rel² per pairwise impulsive
    collision (μ = m₁m₂/(m₁+m₂)).

State vector: [x_1, v_1, x_2, v_2, ..., x_M, v_M]   (2M elements)
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, field
from typing import List, Dict, Any
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis, spring_path


@dataclass
class ComplexCollisionPlaneParams:
    """
    Top-level controls (sample_params fills these):
      setup_seed   — int seed driving randomized layout
      restitution  — Newton's restitution e ∈ (0, 1]
      track_left, track_right, k_contact — fixed defaults

    Structural fields are auto-populated by __post_init__ from setup_seed:
      body_kinds, masses, half_sizes, x0, v0, spring_a, spring_pair
    """
    setup_seed: float = 0.0
    restitution: float = 0.85
    track_left: float = -4.0
    track_right: float = 4.0
    k_contact: float = 5000.0

    body_kinds:  List[str]            = field(default_factory=list)
    masses:      List[float]          = field(default_factory=list)
    half_sizes:  List[float]          = field(default_factory=list)
    x0:          List[float]          = field(default_factory=list)
    v0:          List[float]          = field(default_factory=list)
    spring_a:    List[Dict[str, Any]] = field(default_factory=list)
    spring_pair: List[Dict[str, Any]] = field(default_factory=list)

    def __post_init__(self):
        if not self.body_kinds:
            self._build_layout()

    def _build_layout(self):
        seed = int(self.setup_seed)
        rng  = np.random.default_rng(seed)

        n_entities = int(rng.integers(2, 7))                     # [2, 6]
        type_options = ['sphere', 'block', 'spring_a', 'spring_pair']
        type_weights = np.array([0.30, 0.30, 0.20, 0.20])

        body_kinds, masses, half_sizes = [], [], []
        spring_a, spring_pair = [], []

        for _ in range(n_entities):
            ent = rng.choice(type_options, p=type_weights)
            if ent == 'sphere':
                body_kinds.append('sphere')
                masses.append(float(rng.uniform(0.3, 2.0)))
                half_sizes.append(float(rng.uniform(0.06, 0.12)))
            elif ent == 'block':
                body_kinds.append('block')
                masses.append(float(rng.uniform(0.3, 2.0)))
                half_sizes.append(float(rng.uniform(0.08, 0.16)))
            elif ent == 'spring_a':
                idx = len(body_kinds)
                body_kinds.append('spring_a')
                masses.append(float(rng.uniform(0.3, 2.0)))
                half_sizes.append(float(rng.uniform(0.08, 0.16)))
                spring_a.append({
                    'body_idx': idx,
                    'k':        float(rng.uniform(10.0, 200.0)),
                    'L':        float(rng.uniform(0.10, 0.30)),
                    'side':     int(rng.choice([+1, -1])),
                })
            else:  # spring_pair
                l_idx = len(body_kinds)
                body_kinds.append('pair_left')
                masses.append(float(rng.uniform(0.3, 2.0)))
                half_sizes.append(float(rng.uniform(0.08, 0.16)))
                r_idx = len(body_kinds)
                body_kinds.append('pair_right')
                masses.append(float(rng.uniform(0.3, 2.0)))
                half_sizes.append(float(rng.uniform(0.08, 0.16)))
                spring_pair.append({
                    'left_body_idx':  l_idx,
                    'right_body_idx': r_idx,
                    'k': float(rng.uniform(10.0, 200.0)),
                    'L': float(rng.uniform(0.10, 0.30)),
                })

        M = len(body_kinds)

        # Place bodies left → right with proper spacing for spring lengths
        margin_min = 0.10
        x0 = [self.track_left + margin_min + half_sizes[0]]
        for i in range(1, M):
            spacing = margin_min
            for sa in spring_a:
                if sa['body_idx'] == i - 1 and sa['side'] == +1:
                    spacing = sa['L'] + margin_min; break
            for sa in spring_a:
                if sa['body_idx'] == i and sa['side'] == -1:
                    spacing = max(spacing, sa['L'] + margin_min); break
            for sp in spring_pair:
                if sp['left_body_idx'] == i - 1 and sp['right_body_idx'] == i:
                    spacing = sp['L']; break
            prev_right = x0[i - 1] + half_sizes[i - 1]
            x0.append(prev_right + spacing + half_sizes[i])

        # Expand track if bodies don't fit; centre layout
        final_right = x0[-1] + half_sizes[-1]
        if final_right + margin_min > self.track_right:
            self.track_right = final_right + margin_min
        right_gap = self.track_right - (x0[-1] + half_sizes[-1])
        left_gap  = (x0[0] - half_sizes[0]) - self.track_left
        shift = (right_gap - left_gap) / 2.0
        x0 = [x + shift for x in x0]

        v0 = [float(rng.uniform(-2.5, 2.5)) for _ in range(M)]
        # Cohere spring-pair internal velocities so the pair starts together
        for sp in spring_pair:
            v_avg = (v0[sp['left_body_idx']] + v0[sp['right_body_idx']]) / 2.0
            v0[sp['left_body_idx']]  = v_avg
            v0[sp['right_body_idx']] = v_avg

        self.body_kinds  = body_kinds
        self.masses      = masses
        self.half_sizes  = half_sizes
        self.x0          = x0
        self.v0          = v0
        self.spring_a    = spring_a
        self.spring_pair = spring_pair


def _zeta_from_e(e: float) -> float:
    """Damping ratio ζ that yields Newton's restitution e for a 1-D oscillator
    contact:  e = exp(−π ζ / √(1−ζ²))."""
    if e <= 0.001: return 1.0
    if e >= 0.999: return 0.0
    log_e = np.log(e)
    return -log_e / np.sqrt(np.pi ** 2 + log_e ** 2)


def _ode(t: float, y: List[float], p: ComplexCollisionPlaneParams):
    M = len(p.body_kinds)
    x = np.array([y[2 * i]     for i in range(M)])
    v = np.array([y[2 * i + 1] for i in range(M)])
    F = np.zeros(M)

    zeta = _zeta_from_e(p.restitution)

    spring_pair_set = set()
    for sp in p.spring_pair:
        spring_pair_set.add(tuple(sorted([sp['left_body_idx'],
                                          sp['right_body_idx']])))

    # Pairwise contacts
    for i in range(M):
        for j in range(i + 1, M):
            if (i, j) in spring_pair_set:
                continue                      # handled separately below
            left, right = (i, j) if x[i] < x[j] else (j, i)
            sign_right = +1 if right == j else -1

            left_face_right = x[left]  + p.half_sizes[left]
            right_face_left = x[right] - p.half_sizes[right]

            # Find an applicable spring_a pointing across the gap
            spring_data = None
            for sa in p.spring_a:
                if sa['body_idx'] == left and sa['side'] == +1:
                    spring_data = ('LR', sa); break
                if sa['body_idx'] == right and sa['side'] == -1:
                    spring_data = ('RL', sa); break

            if spring_data is not None:
                kind, sa = spring_data
                if kind == 'LR':
                    spring_tip  = left_face_right + sa['L']
                    if right_face_left < spring_tip:
                        compression = spring_tip - right_face_left
                        F_s = sa['k'] * compression
                        F[right] += sign_right * F_s
                        F[left]  -= sign_right * F_s
                        if compression > sa['L']:                # fully compressed
                            extra = compression - sa['L']
                            v_rel = v[right] - v[left]
                            m_eff = p.masses[left] * p.masses[right] / (p.masses[left] + p.masses[right])
                            c_damp = 2 * zeta * np.sqrt(m_eff * p.k_contact)
                            F_h = p.k_contact * extra
                            F_d = -c_damp * v_rel
                            F[right] += sign_right * (F_h + F_d)
                            F[left]  -= sign_right * (F_h + F_d)
                else:                                            # 'RL'
                    spring_tip = right_face_left - sa['L']
                    if left_face_right > spring_tip:
                        compression = left_face_right - spring_tip
                        F_s = sa['k'] * compression
                        F[right] += sign_right * F_s
                        F[left]  -= sign_right * F_s
                        if compression > sa['L']:
                            extra = compression - sa['L']
                            v_rel = v[right] - v[left]
                            m_eff = p.masses[left] * p.masses[right] / (p.masses[left] + p.masses[right])
                            c_damp = 2 * zeta * np.sqrt(m_eff * p.k_contact)
                            F_h = p.k_contact * extra
                            F_d = -c_damp * v_rel
                            F[right] += sign_right * (F_h + F_d)
                            F[left]  -= sign_right * (F_h + F_d)
            else:
                # Pure hard contact (penalty + damping for restitution)
                if right_face_left < left_face_right:
                    overlap = left_face_right - right_face_left
                    v_rel = v[right] - v[left]
                    m_eff = p.masses[left] * p.masses[right] / (p.masses[left] + p.masses[right])
                    c_damp = 2 * zeta * np.sqrt(m_eff * p.k_contact)
                    F_h = p.k_contact * overlap
                    F_d = -c_damp * v_rel
                    F[right] += sign_right * (F_h + F_d)
                    F[left]  -= sign_right * (F_h + F_d)

    # Walls (with spring-A mediation when the free spring points at a wall)
    for i in range(M):
        sa_left  = next((sa for sa in p.spring_a
                         if sa['body_idx'] == i and sa['side'] == -1), None)
        sa_right = next((sa for sa in p.spring_a
                         if sa['body_idx'] == i and sa['side'] == +1), None)

        lf = x[i] - p.half_sizes[i]
        if sa_left is not None:
            spring_tip = lf - sa_left['L']
            if spring_tip < p.track_left:
                compression = p.track_left - spring_tip
                F[i] += sa_left['k'] * compression
                if compression > sa_left['L']:
                    extra = compression - sa_left['L']
                    c_damp = 2 * zeta * np.sqrt(p.masses[i] * p.k_contact)
                    F[i] += p.k_contact * extra - c_damp * v[i]
        else:
            if lf < p.track_left:
                overlap = p.track_left - lf
                c_damp = 2 * zeta * np.sqrt(p.masses[i] * p.k_contact)
                F[i] += p.k_contact * overlap - c_damp * v[i]

        rf = x[i] + p.half_sizes[i]
        if sa_right is not None:
            spring_tip = rf + sa_right['L']
            if spring_tip > p.track_right:
                compression = spring_tip - p.track_right
                F[i] -= sa_right['k'] * compression
                if compression > sa_right['L']:
                    extra = compression - sa_right['L']
                    c_damp = 2 * zeta * np.sqrt(p.masses[i] * p.k_contact)
                    F[i] += -p.k_contact * extra - c_damp * v[i]
        else:
            if rf > p.track_right:
                overlap = rf - p.track_right
                c_damp = 2 * zeta * np.sqrt(p.masses[i] * p.k_contact)
                F[i] += -p.k_contact * overlap - c_damp * v[i]

    # Spring-pair internal force (always active)
    for sp in p.spring_pair:
        l, r = sp['left_body_idx'], sp['right_body_idx']
        sep      = x[r] - x[l]
        rest_sep = sp['L'] + p.half_sizes[l] + p.half_sizes[r]
        stretch  = sep - rest_sep
        F[l] += sp['k'] * stretch
        F[r] -= sp['k'] * stretch
        # Hard-contact safeguard if internal spring is over-compressed
        face_sep = sep - p.half_sizes[l] - p.half_sizes[r]
        if face_sep < 0:
            overlap = -face_sep
            v_rel = v[r] - v[l]
            m_eff = p.masses[l] * p.masses[r] / (p.masses[l] + p.masses[r])
            c_damp = 2 * zeta * np.sqrt(m_eff * p.k_contact)
            extra = p.k_contact * overlap - c_damp * v_rel
            F[l] -= extra
            F[r] += extra

    derivs = []
    for i in range(M):
        derivs.append(v[i])
        derivs.append(F[i] / p.masses[i])
    return derivs


def simulate(params: ComplexCollisionPlaneParams,
             duration: float = 4.5,
             fps: int = 30):
    M  = len(params.body_kinds)
    y0 = []
    for i in range(M):
        y0.append(params.x0[i]); y0.append(params.v0[i])
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        _ode, (0, duration), y0,
        t_eval=t_eval, args=(params,),
        method="LSODA", rtol=1e-7, atol=1e-9, max_step=0.005,
    )
    return sol.t, sol.y


def render_video(t, y, params: ComplexCollisionPlaneParams,
                 output_path: str, fps: int = 30):
    M = len(params.body_kinds)
    fig, ax = plt.subplots(figsize=(12, 4))
    setup_dark_axis(
        fig, ax,
        xlim=(params.track_left - 0.4, params.track_right + 0.4),
        ylim=(-0.55, 0.55),
    )

    ax.axhline(0, color="#3a3a4f", lw=1.5, zorder=1)
    wall_h = 0.4
    for wx in [params.track_left, params.track_right]:
        x_off = -0.06 if wx == params.track_left else 0.0
        ax.add_patch(patches.Rectangle(
            (wx + x_off, -wall_h), 0.06, 2 * wall_h,
            facecolor="#4a4e69", edgecolor="#adb5bd", lw=1, hatch="////",
        ))

    palette = ["#e63946", "#457b9d", "#2a9d8f", "#f4a261", "#e76f51",
               "#06d6a0", "#118ab2", "#ef476f", "#9d4edd"]

    body_patches = []
    for i, kind in enumerate(params.body_kinds):
        c = palette[i % len(palette)]
        if kind == 'sphere':
            patch = patches.Circle((params.x0[i], 0), params.half_sizes[i],
                                   facecolor=c, edgecolor='white', lw=1.5)
        else:
            hs = params.half_sizes[i]
            patch = patches.FancyBboxPatch(
                (params.x0[i] - hs, -hs), 2 * hs, 2 * hs,
                boxstyle="round,pad=0.01", linewidth=1.5,
                edgecolor='white', facecolor=c,
            )
        ax.add_patch(patch); body_patches.append(patch)

    spring_a_lines    = [(sa, ax.plot([], [], '-', color="#ffd166",
                                       lw=2.0, zorder=2)[0]) for sa in params.spring_a]
    spring_pair_lines = [(sp, ax.plot([], [], '-', color="#a8dadc",
                                       lw=2.0, zorder=2)[0]) for sp in params.spring_pair]

    def update(frame):
        for i in range(M):
            xi = y[2 * i, frame]
            hs = params.half_sizes[i]
            if params.body_kinds[i] == 'sphere':
                body_patches[i].center = (xi, 0)
            else:
                body_patches[i].set_x(xi - hs)

        for sa, line in spring_a_lines:
            i  = sa['body_idx']; xi = y[2 * i, frame]; hs = params.half_sizes[i]
            if sa['side'] == +1:
                x_a = xi + hs; tip = x_a + sa['L']
                for j in range(M):
                    if j == i: continue
                    xj = y[2 * j, frame]
                    if xj > xi:
                        jl = xj - params.half_sizes[j]
                        if jl < tip: tip = jl; break
                if tip > params.track_right: tip = params.track_right
            else:
                x_a = xi - hs; tip = x_a - sa['L']
                for j in range(M):
                    if j == i: continue
                    xj = y[2 * j, frame]
                    if xj < xi:
                        jr = xj + params.half_sizes[j]
                        if jr > tip: tip = jr; break
                if tip < params.track_left: tip = params.track_left
            sx, sy = spring_path(x_a, 0, tip, 0,
                                  n_coils=max(3, int(sa['L'] * 15)),
                                  coil_radius=0.06)
            line.set_data(sx, sy)

        for sp, line in spring_pair_lines:
            l, r = sp['left_body_idx'], sp['right_body_idx']
            xl = y[2 * l, frame] + params.half_sizes[l]
            xr = y[2 * r, frame] - params.half_sizes[r]
            if xr - xl > 0.01:
                sx, sy = spring_path(xl, 0, xr, 0,
                                      n_coils=max(3, int(sp['L'] * 15)),
                                      coil_radius=0.06)
                line.set_data(sx, sy)
            else:
                line.set_data([], [])

        return body_patches + [l for _, l in spring_a_lines] + \
               [l for _, l in spring_pair_lines]

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000 / fps, blit=False)
    ani.save(output_path,
             writer=animation.FFMpegWriter(fps=fps, bitrate=1800),
             dpi=120)
    plt.close(fig)


def make_standalone_script(params: ComplexCollisionPlaneParams,
                           duration: float = 4.5) -> str:
    body_kinds       = list(params.body_kinds)
    masses           = list(params.masses)
    half_sizes       = list(params.half_sizes)
    x0_list          = list(params.x0)
    v0_list          = list(params.v0)
    spring_a_data    = list(params.spring_a)
    spring_pair_data = list(params.spring_pair)

    return f'''"""
Complex Collision Plane — auto-generated standalone simulation script.

Physics:
  - 1-D motion along a frictionless plane bounded by walls at
    x={params.track_left:.3f} and x={params.track_right:.3f}.
  - Each body i obeys m_i ẍ_i = ΣF_i.
  - Hard contacts use a one-sided penalty spring (k_c={params.k_contact:.0f} N/m)
    with damping calibrated to deliver Newton's restitution e={params.restitution:.4f}
    via   e = exp(-π ζ / sqrt(1-ζ²))   ⇒   ζ = -ln(e)/sqrt(π²+ln²(e)).
  - Spring-A bodies have a free helical spring on one side: while compressed,
    F_spring = -k * compression  (Hooke's Law).
  - Spring-pair: two blocks coupled by a permanent internal helical spring.
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

# ── Parameters ──────────────────────────────────────────────────────────────
track_left   = {params.track_left}
track_right  = {params.track_right}
restitution  = {params.restitution}
k_contact    = {params.k_contact}
body_kinds   = {body_kinds!r}
masses       = {masses!r}
half_sizes   = {half_sizes!r}
x0_list      = {x0_list!r}
v0_list      = {v0_list!r}
spring_a     = {spring_a_data!r}
spring_pair  = {spring_pair_data!r}
duration     = {duration}
fps          = 30
M = len(body_kinds)

if   restitution <= 0.001: zeta = 1.0
elif restitution >= 0.999: zeta = 0.0
else:
    log_e = np.log(restitution)
    zeta  = -log_e / np.sqrt(np.pi ** 2 + log_e ** 2)

spring_pair_set = set()
for sp in spring_pair:
    spring_pair_set.add(tuple(sorted([sp["left_body_idx"], sp["right_body_idx"]])))


def ode(t, y):
    x = np.array([y[2 * i]     for i in range(M)])
    v = np.array([y[2 * i + 1] for i in range(M)])
    F = np.zeros(M)

    for i in range(M):
        for j in range(i + 1, M):
            if (i, j) in spring_pair_set:
                continue
            left, right = (i, j) if x[i] < x[j] else (j, i)
            sign_right = +1 if right == j else -1
            left_face_right = x[left]  + half_sizes[left]
            right_face_left = x[right] - half_sizes[right]

            spring_data = None
            for sa in spring_a:
                if sa["body_idx"] == left  and sa["side"] == +1:
                    spring_data = ("LR", sa); break
                if sa["body_idx"] == right and sa["side"] == -1:
                    spring_data = ("RL", sa); break

            if spring_data is not None:
                kind, sa = spring_data
                if kind == "LR":
                    spring_tip = left_face_right + sa["L"]
                    if right_face_left < spring_tip:
                        compression = spring_tip - right_face_left
                        F_s = sa["k"] * compression
                        F[right] += sign_right * F_s
                        F[left]  -= sign_right * F_s
                        if compression > sa["L"]:
                            extra = compression - sa["L"]
                            v_rel = v[right] - v[left]
                            m_eff = masses[left] * masses[right] / (masses[left] + masses[right])
                            c_damp = 2 * zeta * np.sqrt(m_eff * k_contact)
                            F_h = k_contact * extra
                            F_d = -c_damp * v_rel
                            F[right] += sign_right * (F_h + F_d)
                            F[left]  -= sign_right * (F_h + F_d)
                else:
                    spring_tip = right_face_left - sa["L"]
                    if left_face_right > spring_tip:
                        compression = left_face_right - spring_tip
                        F_s = sa["k"] * compression
                        F[right] += sign_right * F_s
                        F[left]  -= sign_right * F_s
                        if compression > sa["L"]:
                            extra = compression - sa["L"]
                            v_rel = v[right] - v[left]
                            m_eff = masses[left] * masses[right] / (masses[left] + masses[right])
                            c_damp = 2 * zeta * np.sqrt(m_eff * k_contact)
                            F_h = k_contact * extra
                            F_d = -c_damp * v_rel
                            F[right] += sign_right * (F_h + F_d)
                            F[left]  -= sign_right * (F_h + F_d)
            else:
                if right_face_left < left_face_right:
                    overlap = left_face_right - right_face_left
                    v_rel = v[right] - v[left]
                    m_eff = masses[left] * masses[right] / (masses[left] + masses[right])
                    c_damp = 2 * zeta * np.sqrt(m_eff * k_contact)
                    F_h = k_contact * overlap
                    F_d = -c_damp * v_rel
                    F[right] += sign_right * (F_h + F_d)
                    F[left]  -= sign_right * (F_h + F_d)

    for i in range(M):
        sa_left  = next((sa for sa in spring_a
                         if sa["body_idx"] == i and sa["side"] == -1), None)
        sa_right = next((sa for sa in spring_a
                         if sa["body_idx"] == i and sa["side"] == +1), None)

        lf = x[i] - half_sizes[i]
        if sa_left is not None:
            spring_tip = lf - sa_left["L"]
            if spring_tip < track_left:
                compression = track_left - spring_tip
                F[i] += sa_left["k"] * compression
                if compression > sa_left["L"]:
                    extra = compression - sa_left["L"]
                    c_damp = 2 * zeta * np.sqrt(masses[i] * k_contact)
                    F[i] += k_contact * extra - c_damp * v[i]
        else:
            if lf < track_left:
                overlap = track_left - lf
                c_damp = 2 * zeta * np.sqrt(masses[i] * k_contact)
                F[i] += k_contact * overlap - c_damp * v[i]

        rf = x[i] + half_sizes[i]
        if sa_right is not None:
            spring_tip = rf + sa_right["L"]
            if spring_tip > track_right:
                compression = spring_tip - track_right
                F[i] -= sa_right["k"] * compression
                if compression > sa_right["L"]:
                    extra = compression - sa_right["L"]
                    c_damp = 2 * zeta * np.sqrt(masses[i] * k_contact)
                    F[i] += -k_contact * extra - c_damp * v[i]
        else:
            if rf > track_right:
                overlap = rf - track_right
                c_damp = 2 * zeta * np.sqrt(masses[i] * k_contact)
                F[i] += -k_contact * overlap - c_damp * v[i]

    for sp in spring_pair:
        l, r = sp["left_body_idx"], sp["right_body_idx"]
        sep      = x[r] - x[l]
        rest_sep = sp["L"] + half_sizes[l] + half_sizes[r]
        stretch  = sep - rest_sep
        F[l] += sp["k"] * stretch
        F[r] -= sp["k"] * stretch
        face_sep = sep - half_sizes[l] - half_sizes[r]
        if face_sep < 0:
            overlap = -face_sep
            v_rel = v[r] - v[l]
            m_eff = masses[l] * masses[r] / (masses[l] + masses[r])
            c_damp = 2 * zeta * np.sqrt(m_eff * k_contact)
            extra = k_contact * overlap - c_damp * v_rel
            F[l] -= extra
            F[r] += extra

    derivs = []
    for i in range(M):
        derivs.append(v[i])
        derivs.append(F[i] / masses[i])
    return derivs


y0 = []
for i in range(M):
    y0.append(x0_list[i]); y0.append(v0_list[i])
t_eval = np.linspace(0, duration, int(duration * fps) + 1)
sol = solve_ivp(ode, (0, duration), y0, t_eval=t_eval, method="LSODA",
                rtol=1e-7, atol=1e-9, max_step=0.005)
y = sol.y


def spring_path(x1, y1, x2, y2, n=8, r=0.05):
    dx, dy = x2 - x1, y2 - y1
    L = np.hypot(dx, dy)
    if L < 1e-10:
        return np.array([x1, x2]), np.array([y1, y2])
    ux, uy = dx / L, dy / L
    nx_, ny_ = -uy, ux
    pts = n * 20 + 2
    tt  = np.linspace(0, 1, pts)
    margin = 0.08
    env = np.where((tt < margin) | (tt > 1 - margin), 0,
                   np.sin(n * 2 * np.pi * (tt - margin) / (1 - 2 * margin)))
    return x1 + tt * dx + r * env * nx_, y1 + tt * dy + r * env * ny_


fig, ax = plt.subplots(figsize=(12, 4), facecolor="#1a1a2e")
ax.set_facecolor("#16213e")
ax.set_xlim(track_left - 0.4, track_right + 0.4); ax.set_ylim(-0.55, 0.55)
ax.set_aspect("equal"); ax.axis("off")
ax.axhline(0, color="#3a3a4f", lw=1.5, zorder=1)
wall_h = 0.4
for wx in [track_left, track_right]:
    x_off = -0.06 if wx == track_left else 0.0
    ax.add_patch(patches.Rectangle(
        (wx + x_off, -wall_h), 0.06, 2 * wall_h,
        facecolor="#4a4e69", edgecolor="#adb5bd", lw=1, hatch="////"))

palette = ["#e63946", "#457b9d", "#2a9d8f", "#f4a261", "#e76f51",
           "#06d6a0", "#118ab2", "#ef476f", "#9d4edd"]
body_patches = []
for i, kind in enumerate(body_kinds):
    c = palette[i % len(palette)]
    if kind == "sphere":
        p_ = patches.Circle((x0_list[i], 0), half_sizes[i],
                            facecolor=c, edgecolor="white", lw=1.5)
    else:
        hs = half_sizes[i]
        p_ = patches.FancyBboxPatch(
            (x0_list[i] - hs, -hs), 2 * hs, 2 * hs,
            boxstyle="round,pad=0.01", lw=1.5, edgecolor="white", facecolor=c)
    ax.add_patch(p_); body_patches.append(p_)

spring_a_lines    = [(sa, ax.plot([], [], "-", color="#ffd166",
                                   lw=2, zorder=2)[0]) for sa in spring_a]
spring_pair_lines = [(sp, ax.plot([], [], "-", color="#a8dadc",
                                   lw=2, zorder=2)[0]) for sp in spring_pair]


def update(frame):
    for i in range(M):
        xi = y[2 * i, frame]
        if body_kinds[i] == "sphere":
            body_patches[i].center = (xi, 0)
        else:
            body_patches[i].set_x(xi - half_sizes[i])
    for sa, line in spring_a_lines:
        i = sa["body_idx"]; xi = y[2 * i, frame]; hs = half_sizes[i]
        if sa["side"] == +1:
            x_a = xi + hs; tip = x_a + sa["L"]
            for j in range(M):
                if j != i and y[2 * j, frame] > xi:
                    jl = y[2 * j, frame] - half_sizes[j]
                    if jl < tip: tip = jl; break
            if tip > track_right: tip = track_right
        else:
            x_a = xi - hs; tip = x_a - sa["L"]
            for j in range(M):
                if j != i and y[2 * j, frame] < xi:
                    jr = y[2 * j, frame] + half_sizes[j]
                    if jr > tip: tip = jr; break
            if tip < track_left: tip = track_left
        sx, sy_ = spring_path(x_a, 0, tip, 0,
                               n=max(3, int(sa["L"] * 15)), r=0.06)
        line.set_data(sx, sy_)
    for sp, line in spring_pair_lines:
        l, r = sp["left_body_idx"], sp["right_body_idx"]
        xl = y[2 * l, frame] + half_sizes[l]
        xr = y[2 * r, frame] - half_sizes[r]
        if xr - xl > 0.01:
            sx, sy_ = spring_path(xl, 0, xr, 0,
                                   n=max(3, int(sp["L"] * 15)), r=0.06)
            line.set_data(sx, sy_)
        else:
            line.set_data([], [])
    return body_patches + [l for _, l in spring_a_lines] + \
           [l for _, l in spring_pair_lines]


ani = animation.FuncAnimation(fig, update, frames=len(sol.t),
                              interval=1000 / fps, blit=False)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800),
         dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Complex Collision Plane")
    parser.add_argument("--seed",        type=float, default=42)
    parser.add_argument("--restitution", type=float, default=0.85)
    parser.add_argument("--duration",    type=float, default=4.5)
    parser.add_argument("--output",      type=str,   default="complex_collision.mp4")
    args = parser.parse_args()

    p = ComplexCollisionPlaneParams(setup_seed=args.seed, restitution=args.restitution)
    print(f"Built layout: M = {len(p.body_kinds)} bodies")
    print(f"  kinds      : {p.body_kinds}")
    print(f"  masses     : {[round(m,2) for m in p.masses]}")
    print(f"  half_sizes : {[round(h,3) for h in p.half_sizes]}")
    print(f"  x0         : {[round(x,2) for x in p.x0]}")
    print(f"  v0         : {[round(v,2) for v in p.v0]}")
    print(f"  spring_a   : {p.spring_a}")
    print(f"  spring_pair: {p.spring_pair}")

    t, y = simulate(p, duration=args.duration)
    print(f"Simulation done. Frames: {y.shape[1]}")
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
