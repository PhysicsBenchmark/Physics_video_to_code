"""
Rod-Ball Strike — top-down 2D collision: ball hits rigid uniform rod.

Free-motion: ball and rod both slide with floor friction (-mu_k g v_hat); rod
also has decoupled rotational drag. Impact: instantaneous frictionless normal
restitution at the closest-point contact (uses J = -(1+e) v_app / (1/m + 1/M
+ (r x n)^2/I)).

State (10): (xb, yb, vbx, vby, xR, yR, theta, VRx, VRy, omega).
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from dataclasses import dataclass, asdict


@dataclass
class RodBallStrikeParams:
    L: float = 1.4
    M: float = 2.0
    m_ball: float = 0.6
    r_ball: float = 0.12
    g: float = 9.8
    e_rest: float = 0.65
    mu_k: float = 0.010
    xb0: float = 0.7
    yb0: float = -1.50
    vbx0: float = 0.0
    vby0: float = 1.50
    xR0: float = 0.0
    yR0: float = 0.0
    theta0: float = 0.0
    VRx0: float = 0.0
    VRy0: float = 0.0
    omega0: float = 0.0


def _derivs(t, s, p: RodBallStrikeParams):
    xb, yb, vbx, vby, xR, yR, th, VRx, VRy, om = s
    v_eps = 1e-3
    sb = np.hypot(vbx, vby)
    if sb > v_eps:
        ax_b, ay_b = -p.mu_k * p.g * vbx / sb, -p.mu_k * p.g * vby / sb
    else:
        ax_b = ay_b = 0.0
    sR = np.hypot(VRx, VRy)
    if sR > v_eps:
        ax_R, ay_R = -p.mu_k * p.g * VRx / sR, -p.mu_k * p.g * VRy / sR
    else:
        ax_R = ay_R = 0.0
    alpha = -3.0 * p.mu_k * p.g / p.L * np.sign(om) if abs(om) > v_eps else 0.0
    return [vbx, vby, ax_b, ay_b, VRx, VRy, om, ax_R, ay_R, alpha]


def _closest_dist(s, p: RodBallStrikeParams):
    xb, yb, _, _, xR, yR, th, *_ = s
    cos_t, sin_t = np.cos(th), np.sin(th)
    Ax, Ay = xR - p.L / 2 * cos_t, yR - p.L / 2 * sin_t
    Bx, By = xR + p.L / 2 * cos_t, yR + p.L / 2 * sin_t
    abx, aby = Bx - Ax, By - Ay
    apx, apy = xb - Ax, yb - Ay
    ab2 = abx * abx + aby * aby
    t_proj = max(0.0, min(1.0, (apx * abx + apy * aby) / ab2))
    cx, cy = Ax + t_proj * abx, Ay + t_proj * aby
    return np.hypot(xb - cx, yb - cy) - p.r_ball


def _apply_impulse(s, p: RodBallStrikeParams):
    xb, yb, vbx, vby, xR, yR, th, VRx, VRy, om = s
    cos_t, sin_t = np.cos(th), np.sin(th)
    Ax, Ay = xR - p.L / 2 * cos_t, yR - p.L / 2 * sin_t
    Bx, By = xR + p.L / 2 * cos_t, yR + p.L / 2 * sin_t
    abx, aby = Bx - Ax, By - Ay
    apx, apy = xb - Ax, yb - Ay
    ab2 = abx * abx + aby * aby
    t_proj = max(0.0, min(1.0, (apx * abx + apy * aby) / ab2))
    cx, cy = Ax + t_proj * abx, Ay + t_proj * aby
    nx, ny = xb - cx, yb - cy
    nn = np.hypot(nx, ny)
    if nn < 1e-12:
        return s
    nx /= nn; ny /= nn
    rRx, rRy = cx - xR, cy - yR
    cross = rRx * ny - rRy * nx
    vR_cx, vR_cy = VRx - om * rRy, VRy + om * rRx
    v_app = (vbx - vR_cx) * nx + (vby - vR_cy) * ny
    if v_app >= 0:
        return s
    I_rod = p.M * p.L * p.L / 12.0
    J = -(1.0 + p.e_rest) * v_app / (1.0 / p.m_ball + 1.0 / p.M + cross * cross / I_rod)
    return np.array([
        xb, yb,
        vbx + J * nx / p.m_ball, vby + J * ny / p.m_ball,
        xR, yR, th,
        VRx - J * nx / p.M, VRy - J * ny / p.M,
        om - J * cross / I_rod
    ])


def simulate(
    params: RodBallStrikeParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Returns (t, S) where S.shape = (10, N): full state at frame timestamps."""
    t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
    S = np.zeros((10, len(t_eval)))
    state = np.array([
        params.xb0, params.yb0, params.vbx0, params.vby0,
        params.xR0, params.yR0, params.theta0,
        params.VRx0, params.VRy0, params.omega0
    ], float)
    S[:, 0] = state
    last_idx = 1
    t_cur = 0.0

    def event_collision(t, s, p):
        return _closest_dist(s, p)
    event_collision.terminal = True
    event_collision.direction = -1

    for _ in range(50):
        if t_cur >= duration - 1e-9:
            break
        sol = solve_ivp(
            _derivs, (t_cur, duration), state,
            args=(params,), events=event_collision,
            dense_output=True, max_step=0.05, rtol=1e-9, atol=1e-11,
        )
        seg_end = sol.t[-1]
        while last_idx < len(t_eval) and t_eval[last_idx] <= seg_end + 1e-12:
            S[:, last_idx] = sol.sol(t_eval[last_idx])
            last_idx += 1
        state = sol.y[:, -1].copy()
        t_cur = seg_end
        if sol.status != 1:
            break
        state = _apply_impulse(state, params)

    if last_idx < len(t_eval):
        S[:, last_idx:] = state[:, None]
    return t_eval, S


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: RodBallStrikeParams,
    output_path: str,
    fps: int = 30,
) -> None:
    L = params.L
    xb_arr, yb_arr = y[0], y[1]
    xR_arr, yR_arr = y[4], y[5]
    th_arr = y[6]
    xs_p = xR_arr + (L / 2) * np.cos(th_arr); ys_p = yR_arr + (L / 2) * np.sin(th_arr)
    xs_m = xR_arr - (L / 2) * np.cos(th_arr); ys_m = yR_arr - (L / 2) * np.sin(th_arr)

    fig_w, fig_h = 8, 5
    fig_aspect = fig_w / fig_h
    all_x = np.concatenate([xs_p, xs_m, xb_arr])
    all_y = np.concatenate([ys_p, ys_m, yb_arr])
    pad = 0.5
    x_lo_d, x_hi_d = all_x.min() - pad, all_x.max() + pad
    y_lo_d, y_hi_d = all_y.min() - pad, all_y.max() + pad
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    ball_trail, = ax.plot([], [], "-", color="#f4d35e", alpha=0.40, lw=1.4, zorder=2)
    rod_trail, = ax.plot([], [], "-", color="#e63946", alpha=0.30, lw=1.0, zorder=2)
    rod_ln, = ax.plot([], [], "-", color="#e63946", lw=12,
                      solid_capstyle="round", zorder=4)
    ball_c = plt.Circle((params.xb0, params.yb0), params.r_ball, facecolor="#f4d35e",
                        edgecolor="white", lw=1.5, zorder=5)
    ax.add_patch(ball_c)
    btx, bty, rtx, rty = [], [], [], []

    def update(f):
        rod_ln.set_data([xs_m[f], xs_p[f]], [ys_m[f], ys_p[f]])
        ball_c.set_center((xb_arr[f], yb_arr[f]))
        btx.append(xb_arr[f]); bty.append(yb_arr[f])
        rtx.append(xR_arr[f]); rty.append(yR_arr[f])
        if len(btx) > 90: btx.pop(0); bty.pop(0)
        if len(rtx) > 90: rtx.pop(0); rty.pop(0)
        ball_trail.set_data(btx, bty)
        rod_trail.set_data(rtx, rty)
        return rod_ln, ball_c, ball_trail, rod_trail

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000 / fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(
    params: RodBallStrikeParams,
    duration: float = 12.0,
) -> str:
    p = asdict(params)
    return f'''"""Rod-ball strike — auto-generated."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation

L      = {p["L"]}
M      = {p["M"]}
m_ball = {p["m_ball"]}
r_ball = {p["r_ball"]}
g      = {p["g"]}
e_rest = {p["e_rest"]}
mu_k   = {p["mu_k"]}
xb0, yb0 = {p["xb0"]}, {p["yb0"]}
vbx0, vby0 = {p["vbx0"]}, {p["vby0"]}
xR0, yR0 = {p["xR0"]}, {p["yR0"]}
th0    = {p["theta0"]}
VRx0, VRy0 = {p["VRx0"]}, {p["VRy0"]}
om0    = {p["omega0"]}
duration = {duration}

I_rod = M*L*L/12.0
fps = 30
v_eps = 1e-3

def derivs(t, s):
    xb, yb, vbx, vby, xR, yR, th, VRx, VRy, om = s
    sb = np.hypot(vbx, vby)
    if sb > v_eps:
        ax_b, ay_b = -mu_k*g*vbx/sb, -mu_k*g*vby/sb
    else:
        ax_b = ay_b = 0.0
    sR = np.hypot(VRx, VRy)
    if sR > v_eps:
        ax_R, ay_R = -mu_k*g*VRx/sR, -mu_k*g*VRy/sR
    else:
        ax_R = ay_R = 0.0
    alpha = -3.0*mu_k*g/L*np.sign(om) if abs(om) > v_eps else 0.0
    return [vbx, vby, ax_b, ay_b, VRx, VRy, om, ax_R, ay_R, alpha]

def closest_dist(s):
    xb, yb, _, _, xR, yR, th, *_ = s
    c, s_ = np.cos(th), np.sin(th)
    Ax, Ay = xR - L/2*c, yR - L/2*s_
    Bx, By = xR + L/2*c, yR + L/2*s_
    abx, aby = Bx-Ax, By-Ay
    apx, apy = xb-Ax, yb-Ay
    ab2 = abx*abx+aby*aby
    tpr = max(0.0, min(1.0, (apx*abx+apy*aby)/ab2))
    cx, cy = Ax+tpr*abx, Ay+tpr*aby
    return np.hypot(xb-cx, yb-cy) - r_ball

def event_col(t, s):
    return closest_dist(s)
event_col.terminal=True; event_col.direction=-1

def apply_imp(s):
    xb, yb, vbx, vby, xR, yR, th, VRx, VRy, om = s
    c, s_ = np.cos(th), np.sin(th)
    Ax, Ay = xR - L/2*c, yR - L/2*s_
    Bx, By = xR + L/2*c, yR + L/2*s_
    abx, aby = Bx-Ax, By-Ay
    apx, apy = xb-Ax, yb-Ay
    ab2 = abx*abx+aby*aby
    tpr = max(0.0, min(1.0, (apx*abx+apy*aby)/ab2))
    cx, cy = Ax+tpr*abx, Ay+tpr*aby
    nx, ny = xb-cx, yb-cy
    nn = np.hypot(nx, ny)
    if nn < 1e-12: return s
    nx/=nn; ny/=nn
    rRx, rRy = cx-xR, cy-yR
    cross = rRx*ny - rRy*nx
    vR_cx, vR_cy = VRx - om*rRy, VRy + om*rRx
    v_app = (vbx-vR_cx)*nx + (vby-vR_cy)*ny
    if v_app >= 0: return s
    J = -(1.0+e_rest)*v_app / (1.0/m_ball + 1.0/M + cross*cross/I_rod)
    return np.array([xb,yb, vbx+J*nx/m_ball, vby+J*ny/m_ball,
                     xR,yR,th, VRx-J*nx/M, VRy-J*ny/M, om-J*cross/I_rod])

t_eval_g = np.linspace(0, duration, int(duration*fps)+1)
S = np.zeros((10, len(t_eval_g)))
state = np.array([xb0,yb0,vbx0,vby0,xR0,yR0,th0,VRx0,VRy0,om0], float)
S[:,0] = state; last=1; t_cur=0.0
for _ in range(50):
    if t_cur >= duration - 1e-9: break
    sol = solve_ivp(derivs,(t_cur,duration), state, events=event_col,
                    dense_output=True, max_step=0.05, rtol=1e-9, atol=1e-11)
    se = sol.t[-1]
    while last < len(t_eval_g) and t_eval_g[last] <= se + 1e-12:
        S[:,last] = sol.sol(t_eval_g[last]); last += 1
    state = sol.y[:,-1].copy(); t_cur = se
    if sol.status != 1: break
    state = apply_imp(state)
if last < len(t_eval_g):
    S[:, last:] = state[:, None]

xb_a, yb_a = S[0], S[1]
xR_a, yR_a = S[4], S[5]
th_a = S[6]
xs_p = xR_a + (L/2)*np.cos(th_a); ys_p = yR_a + (L/2)*np.sin(th_a)
xs_m = xR_a - (L/2)*np.cos(th_a); ys_m = yR_a - (L/2)*np.sin(th_a)

fig_w, fig_h = 8, 5; fa = fig_w/fig_h
all_x = np.concatenate([xs_p, xs_m, xb_a])
all_y = np.concatenate([ys_p, ys_m, yb_a])
pad = 0.5
xlo, xhi = all_x.min()-pad, all_x.max()+pad
ylo, yhi = all_y.min()-pad, all_y.max()+pad
dx, dy = xhi-xlo, yhi-ylo
if dx/dy < fa:
    e=(fa*dy-dx)/2.0; xlo-=e; xhi+=e
else:
    e=(dx/fa-dy)/2.0; ylo-=e; yhi+=e

fig = plt.figure(figsize=(fig_w,fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1])
ax.set_facecolor("#16213e")
ax.set_xlim(xlo,xhi); ax.set_ylim(ylo,yhi)
ax.set_aspect("equal"); ax.axis("off")
btr, = ax.plot([],[],"-",color="#f4d35e", alpha=0.40, lw=1.4, zorder=2)
rtr, = ax.plot([],[],"-",color="#e63946", alpha=0.30, lw=1.0, zorder=2)
rod_ln, = ax.plot([],[],"-",color="#e63946", lw=12, solid_capstyle="round", zorder=4)
ball_c = plt.Circle((xb0,yb0), r_ball, facecolor="#f4d35e", edgecolor="white", lw=1.5, zorder=5)
ax.add_patch(ball_c)
btx, bty, rtx, rty = [], [], [], []

def update(f):
    rod_ln.set_data([xs_m[f], xs_p[f]], [ys_m[f], ys_p[f]])
    ball_c.set_center((xb_a[f], yb_a[f]))
    btx.append(xb_a[f]); bty.append(yb_a[f])
    rtx.append(xR_a[f]); rty.append(yR_a[f])
    if len(btx)>90: btx.pop(0); bty.pop(0)
    if len(rtx)>90: rtx.pop(0); rty.pop(0)
    btr.set_data(btx, bty); rtr.set_data(rtx, rty)
    return rod_ln, ball_c, btr, rtr

ani = animation.FuncAnimation(fig, update, frames=t_eval_g.size, interval=1000/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Rod Ball Strike")
    parser.add_argument("--L", type=float, default=1.4)
    parser.add_argument("--M", type=float, default=2.0)
    parser.add_argument("--m_ball", type=float, default=0.6)
    parser.add_argument("--r_ball", type=float, default=0.12)
    parser.add_argument("--g", type=float, default=9.8)
    parser.add_argument("--e_rest", type=float, default=0.65)
    parser.add_argument("--mu_k", type=float, default=0.010)
    parser.add_argument("--xb0", type=float, default=0.7)
    parser.add_argument("--yb0", type=float, default=-1.5)
    parser.add_argument("--vbx0", type=float, default=0.0)
    parser.add_argument("--vby0", type=float, default=1.5)
    parser.add_argument("--xR0", type=float, default=0.0)
    parser.add_argument("--yR0", type=float, default=0.0)
    parser.add_argument("--theta0", type=float, default=0.0)
    parser.add_argument("--VRx0", type=float, default=0.0)
    parser.add_argument("--VRy0", type=float, default=0.0)
    parser.add_argument("--omega0", type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="rod_ball_strike.mp4")
    args = parser.parse_args()

    p = RodBallStrikeParams(
        L=args.L, M=args.M, m_ball=args.m_ball, r_ball=args.r_ball,
        g=args.g, e_rest=args.e_rest, mu_k=args.mu_k,
        xb0=args.xb0, yb0=args.yb0, vbx0=args.vbx0, vby0=args.vby0,
        xR0=args.xR0, yR0=args.yR0, theta0=args.theta0,
        VRx0=args.VRx0, VRy0=args.VRy0, omega0=args.omega0,
    )
    print(f"Simulating rod ball strike: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
