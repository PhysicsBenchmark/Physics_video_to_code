"""
Cylinder-Piston-Ball
====================
Inside a vertical cylinder (closed at the bottom), a ball and a free piston
are released from rest at height; both fall under gravity. Ball-floor and
ball-piston impacts use Newton restitution. Piston slides without friction.
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class CylinderPistonBallParams:
    g: float = 9.8
    m_b: float = 0.20
    m_p: float = 1.00
    r_b: float = 0.10
    D_cyl: float = 0.60
    t_p: float = 0.20
    H_cyl: float = 2.50
    y_b_0: float = 1.00
    y_p_bot_0: float = 2.20
    e_floor: float = 0.75
    e_bp: float = 0.55
    v_b_0: float = 0.0
    v_p_0: float = 0.0


def simulate(
    params: CylinderPistonBallParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    p = params
    g = p.g; m_b = p.m_b; m_p = p.m_p; r_b = p.r_b; t_p = p.t_p
    e_floor = p.e_floor; e_bp = p.e_bp

    def free(t, y):
        return [y[2], y[3], -g, -g]

    def ev_floor(t, y):
        return y[0] - r_b
    ev_floor.terminal = True; ev_floor.direction = -1

    def ev_bp(t, y):
        return y[1] - y[0] - r_b
    ev_bp.terminal = True; ev_bp.direction = -1

    def ev_pfloor(t, y):
        return y[1]
    ev_pfloor.terminal = True; ev_pfloor.direction = -1

    t_eval_g = np.linspace(0.0, duration, int(duration * fps) + 1)
    S = np.zeros((4, len(t_eval_g)))
    state = np.array([p.y_b_0, p.y_p_bot_0, p.v_b_0, p.v_p_0], dtype=float)
    S[:, 0] = state
    last_idx = 1
    t_cur = 0.0
    settle_v_eps = 0.05
    settle_gap_eps = 1e-3

    for _seg in range(20000):
        if t_cur >= duration - 1e-12:
            break
        yb, ypb, vb, vp = state
        if (abs(vb) < settle_v_eps and abs(vp) < settle_v_eps
                and (ypb - yb - r_b) < settle_gap_eps
                and (yb - r_b) < settle_gap_eps):
            state = np.array([r_b, 2.0 * r_b, 0.0, 0.0])
            while last_idx < len(t_eval_g):
                S[:, last_idx] = state
                last_idx += 1
            break

        sol = solve_ivp(free, (t_cur, duration), state,
                        events=[ev_floor, ev_bp, ev_pfloor],
                        dense_output=True, max_step=0.02,
                        rtol=1e-9, atol=1e-11)
        seg_end = sol.t[-1]
        while last_idx < len(t_eval_g) and t_eval_g[last_idx] <= seg_end + 1e-12:
            S[:, last_idx] = sol.sol(t_eval_g[last_idx])
            last_idx += 1
        state = sol.y[:, -1].copy()
        t_cur = seg_end
        if sol.status != 1:
            break

        t_floor = sol.t_events[0]; t_bp = sol.t_events[1]; t_pf = sol.t_events[2]
        times = []
        if len(t_floor) > 0: times.append(("floor", t_floor[-1]))
        if len(t_bp) > 0:    times.append(("bp", t_bp[-1]))
        if len(t_pf) > 0:    times.append(("pf", t_pf[-1]))
        if not times:
            break
        kind = max(times, key=lambda x: x[1])[0]

        if kind == "floor":
            state[2] = -e_floor * state[2]
        elif kind == "bp":
            vb_, vp_ = state[2], state[3]
            new_vb = ((m_b - e_bp * m_p) * vb_ + (1.0 + e_bp) * m_p * vp_) / (m_b + m_p)
            new_vp = ((m_p - e_bp * m_b) * vp_ + (1.0 + e_bp) * m_b * vb_) / (m_b + m_p)
            state[2] = new_vb; state[3] = new_vp
        elif kind == "pf":
            state = np.array([r_b, 2.0 * r_b, 0.0, 0.0])
            while last_idx < len(t_eval_g):
                S[:, last_idx] = state
                last_idx += 1
            break

    if last_idx < len(t_eval_g):
        S[:, last_idx:] = state[:, None]

    return t_eval_g, S


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: CylinderPistonBallParams,
    output_path: str,
    fps: int = 30,
) -> None:
    p = params
    yb_arr, ypb_arr = y[0], y[1]
    fig_w, fig_h = 5, 7
    x_lo = -p.D_cyl / 2.0 - 0.20
    x_hi = p.D_cyl / 2.0 + 0.20
    y_lo = -0.20
    y_hi = p.H_cyl + 0.20

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    ax.add_patch(patches.Rectangle((x_lo, y_lo), x_hi - x_lo, -y_lo,
                                   facecolor="#4a4e69", edgecolor="none", alpha=0.8, zorder=0))
    ax.axhline(0.0, color="#adb5bd", lw=2.0, zorder=1)

    wall_lw = 4.0
    ax.plot([-p.D_cyl / 2.0, -p.D_cyl / 2.0], [0.0, p.H_cyl],
            color="#adb5bd", lw=wall_lw, zorder=2, solid_capstyle="butt")
    ax.plot([p.D_cyl / 2.0, p.D_cyl / 2.0], [0.0, p.H_cyl],
            color="#adb5bd", lw=wall_lw, zorder=2, solid_capstyle="butt")
    ax.plot([-p.D_cyl / 2.0, p.D_cyl / 2.0], [0.0, 0.0],
            color="#adb5bd", lw=wall_lw, zorder=2, solid_capstyle="butt")

    piston = patches.Rectangle((-p.D_cyl / 2.0, ypb_arr[0]), p.D_cyl, p.t_p,
                               facecolor="#8a4f33", edgecolor="white",
                               lw=1.2, zorder=3)
    ax.add_patch(piston)
    handle_w = 0.12; handle_h = 0.10
    handle = patches.Rectangle((-handle_w / 2.0, ypb_arr[0] + p.t_p),
                               handle_w, handle_h,
                               facecolor="#5a3520", edgecolor="white",
                               lw=1.0, zorder=4)
    ax.add_patch(handle)
    ball = patches.Circle((0.0, yb_arr[0]), p.r_b,
                          facecolor="#e63946", edgecolor="white",
                          lw=1.2, zorder=5)
    ax.add_patch(ball)

    def update(f):
        ypb_f = ypb_arr[f]
        piston.set_xy((-p.D_cyl / 2.0, ypb_f))
        handle.set_xy((-handle_w / 2.0, ypb_f + p.t_p))
        ball.set_center((0.0, yb_arr[f]))
        return piston, handle, ball

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000 / fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: CylinderPistonBallParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""
Cylinder-Piston-Ball — auto-generated.
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

g        = {p["g"]}
m_b      = {p["m_b"]}
m_p      = {p["m_p"]}
r_b      = {p["r_b"]}
D_cyl    = {p["D_cyl"]}
t_p      = {p["t_p"]}
H_cyl    = {p["H_cyl"]}
y_b_0    = {p["y_b_0"]}
y_p_bot_0= {p["y_p_bot_0"]}
e_floor  = {p["e_floor"]}
e_bp     = {p["e_bp"]}
v_b_0    = {p["v_b_0"]}
v_p_0    = {p["v_p_0"]}
duration = {duration}
fps = 30

def free(t, y): return [y[2], y[3], -g, -g]
def ev_floor(t, y): return y[0] - r_b
ev_floor.terminal = True; ev_floor.direction = -1
def ev_bp(t, y):    return y[1] - y[0] - r_b
ev_bp.terminal = True; ev_bp.direction = -1
def ev_pfloor(t, y): return y[1]
ev_pfloor.terminal = True; ev_pfloor.direction = -1

t_eval_g = np.linspace(0.0, duration, int(duration * fps) + 1)
S = np.zeros((4, len(t_eval_g)))
state = np.array([y_b_0, y_p_bot_0, v_b_0, v_p_0], dtype=float)
S[:, 0] = state
last_idx = 1
t_cur = 0.0
settle_v_eps = 0.05
settle_gap_eps = 1e-3

for _seg in range(20000):
    if t_cur >= duration - 1e-12: break
    yb, ypb, vb, vp = state
    if (abs(vb) < settle_v_eps and abs(vp) < settle_v_eps
            and (ypb - yb - r_b) < settle_gap_eps
            and (yb - r_b) < settle_gap_eps):
        state = np.array([r_b, 2.0 * r_b, 0.0, 0.0])
        while last_idx < len(t_eval_g):
            S[:, last_idx] = state; last_idx += 1
        break
    sol = solve_ivp(free, (t_cur, duration), state,
                    events=[ev_floor, ev_bp, ev_pfloor],
                    dense_output=True, max_step=0.02, rtol=1e-9, atol=1e-11)
    seg_end = sol.t[-1]
    while last_idx < len(t_eval_g) and t_eval_g[last_idx] <= seg_end + 1e-12:
        S[:, last_idx] = sol.sol(t_eval_g[last_idx]); last_idx += 1
    state = sol.y[:, -1].copy(); t_cur = seg_end
    if sol.status != 1: break
    t_floor = sol.t_events[0]; t_bp = sol.t_events[1]; t_pf = sol.t_events[2]
    times = []
    if len(t_floor) > 0: times.append(("floor", t_floor[-1]))
    if len(t_bp) > 0:    times.append(("bp", t_bp[-1]))
    if len(t_pf) > 0:    times.append(("pf", t_pf[-1]))
    if not times: break
    kind = max(times, key=lambda x: x[1])[0]
    if kind == "floor":
        state[2] = -e_floor * state[2]
    elif kind == "bp":
        vb, vp = state[2], state[3]
        new_vb = ((m_b - e_bp*m_p)*vb + (1+e_bp)*m_p*vp) / (m_b + m_p)
        new_vp = ((m_p - e_bp*m_b)*vp + (1+e_bp)*m_b*vb) / (m_b + m_p)
        state[2] = new_vb; state[3] = new_vp
    elif kind == "pf":
        state = np.array([r_b, 2.0*r_b, 0.0, 0.0])
        while last_idx < len(t_eval_g):
            S[:, last_idx] = state; last_idx += 1
        break

if last_idx < len(t_eval_g):
    S[:, last_idx:] = state[:, None]

yb_arr  = S[0]; ypb_arr = S[1]

fig_w, fig_h = 5, 7
x_lo = -D_cyl/2.0 - 0.20; x_hi = D_cyl/2.0 + 0.20
y_lo = -0.20; y_hi = H_cyl + 0.20
fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0, 0, 1, 1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(patches.Rectangle((x_lo, y_lo), x_hi - x_lo, -y_lo, facecolor="#4a4e69", edgecolor="none", alpha=0.8, zorder=0))
ax.axhline(0.0, color="#adb5bd", lw=2.0, zorder=1)
wall_lw = 4.0
ax.plot([-D_cyl/2.0, -D_cyl/2.0], [0.0, H_cyl], color="#adb5bd", lw=wall_lw, zorder=2, solid_capstyle="butt")
ax.plot([ D_cyl/2.0,  D_cyl/2.0], [0.0, H_cyl], color="#adb5bd", lw=wall_lw, zorder=2, solid_capstyle="butt")
ax.plot([-D_cyl/2.0, D_cyl/2.0], [0.0, 0.0], color="#adb5bd", lw=wall_lw, zorder=2, solid_capstyle="butt")

piston = patches.Rectangle((-D_cyl/2.0, y_p_bot_0), D_cyl, t_p, facecolor="#8a4f33", edgecolor="white", lw=1.2, zorder=3)
ax.add_patch(piston)
handle_w = 0.12; handle_h = 0.10
handle = patches.Rectangle((-handle_w/2.0, y_p_bot_0 + t_p), handle_w, handle_h, facecolor="#5a3520", edgecolor="white", lw=1.0, zorder=4)
ax.add_patch(handle)
ball = patches.Circle((0.0, y_b_0), r_b, facecolor="#e63946", edgecolor="white", lw=1.2, zorder=5)
ax.add_patch(ball)

def update(f):
    ypb_f = ypb_arr[f]
    piston.set_xy((-D_cyl/2.0, ypb_f))
    handle.set_xy((-handle_w/2.0, ypb_f + t_p))
    ball.set_center((0.0, yb_arr[f]))
    return piston, handle, ball

ani = animation.FuncAnimation(fig, update, frames=len(t_eval_g), interval=1000/fps, blit=True)
ani.save("cylinder_piston_ball.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close(); print("Saved cylinder_piston_ball.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Cylinder-Piston-Ball")
    for k, v in asdict(CylinderPistonBallParams()).items():
        parser.add_argument(f"--{k}", type=float, default=v)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="cylinder_piston_ball.mp4")
    args = parser.parse_args()
    fields = {k: getattr(args, k) for k in asdict(CylinderPistonBallParams()).keys()}
    p = CylinderPistonBallParams(**fields)
    print(f"Simulating cylinder_piston_ball: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
