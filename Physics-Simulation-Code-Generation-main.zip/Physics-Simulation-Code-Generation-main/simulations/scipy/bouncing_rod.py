"""
Bouncing Rod Simulation
=======================
A thin rigid rod is dropped onto a flat ground with restitution + friction.
Free-flight (between contacts):
    ẍ_c = 0,  ÿ_c = -g,  θ̈ = 0     (I = m L² / 12)
Endpoint contact (y_e = 0, v_ey < 0): impulse at the contact point with
Newton restitution on the normal and a clamped Coulomb friction tangent.
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class BouncingRodParams:
    L: float = 1.4
    m: float = 1.0
    g: float = 9.8
    e_rest: float = 0.7
    mu: float = 0.20
    xc0: float = 0.0
    yc0: float = 2.6
    theta0: float = 0.349066
    vx0: float = 0.6
    vy0: float = 0.0
    omega0: float = -0.20


def simulate(
    params: BouncingRodParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    L = params.L
    m = params.m
    g = params.g
    e_rest = params.e_rest
    mu = params.mu
    I_cm = m * L * L / 12.0

    def free_flight(t, y):
        return [y[3], y[4], y[5], 0.0, -g, 0.0]

    def ev_plus(t, y):
        return y[1] + (L / 2.0) * np.sin(y[2])
    ev_plus.terminal = True
    ev_plus.direction = -1

    def ev_minus(t, y):
        return y[1] - (L / 2.0) * np.sin(y[2])
    ev_minus.terminal = True
    ev_minus.direction = -1

    def contact_step(state):
        s = state.copy()
        for _ in range(8):
            any_imp = False
            for sgn in (+1.0, -1.0):
                xc, yc, th, vx, vy, om = s
                rx = sgn * (L / 2.0) * np.cos(th)
                ry = sgn * (L / 2.0) * np.sin(th)
                ey = yc + ry
                vp_y = vy + rx * om
                if ey > 1e-9 or vp_y > -1e-12:
                    continue
                vp_x = vx - ry * om
                Jn = -(1.0 + e_rest) * vp_y / (1.0 / m + rx * rx / I_cm)
                Jt_s = -vp_x / (1.0 / m + ry * ry / I_cm)
                mt = mu * Jn
                Jt = max(-mt, min(mt, Jt_s))
                s[3] = vx + Jt / m
                s[4] = vy + Jn / m
                s[5] = om + (rx * Jn - ry * Jt) / I_cm
                s[1] = yc - ey
                any_imp = True
            if not any_imp:
                break
        return s

    t_eval_global = np.linspace(0, duration, int(duration * fps) + 1)
    xc_arr = np.zeros_like(t_eval_global)
    yc_arr = np.zeros_like(t_eval_global)
    th_arr = np.zeros_like(t_eval_global)

    state = np.array(
        [params.xc0, params.yc0, params.theta0,
         params.vx0, params.vy0, params.omega0], dtype=float
    )
    xc_arr[0], yc_arr[0], th_arr[0] = state[0], state[1], state[2]
    last_idx = 1
    t_cur = 0.0

    for _seg in range(2000):
        if t_cur >= duration - 1e-9:
            break
        sol = solve_ivp(free_flight, (t_cur, duration), state,
                        events=[ev_plus, ev_minus], dense_output=True,
                        max_step=0.02, rtol=1e-9, atol=1e-11)
        seg_end = sol.t[-1]
        while last_idx < len(t_eval_global) and t_eval_global[last_idx] <= seg_end + 1e-12:
            st = sol.sol(t_eval_global[last_idx])
            xc_arr[last_idx], yc_arr[last_idx], th_arr[last_idx] = st[0], st[1], st[2]
            last_idx += 1
        state = sol.y[:, -1].copy()
        t_cur = seg_end
        if sol.status != 1:
            break
        state = contact_step(state)
        KE = 0.5 * m * (state[3] ** 2 + state[4] ** 2) + 0.5 * I_cm * state[5] ** 2
        if KE < 0.03 and abs(state[1]) < 0.05 and abs(np.sin(state[2])) < 0.10:
            th_rest = round(state[2] / np.pi) * np.pi
            state = np.array([state[0], 0.0, th_rest, 0.0, 0.0, 0.0])
            break

    if last_idx < len(t_eval_global):
        xc_arr[last_idx:] = state[0]
        yc_arr[last_idx:] = state[1]
        th_arr[last_idx:] = state[2]

    y = np.vstack([xc_arr, yc_arr, th_arr])
    return t_eval_global, y


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: BouncingRodParams,
    output_path: str,
    fps: int = 30,
) -> None:
    L = params.L
    xc_arr, yc_arr, th_arr = y[0], y[1], y[2]
    xs_p = xc_arr + (L / 2) * np.cos(th_arr)
    ys_p = yc_arr + (L / 2) * np.sin(th_arr)
    xs_m = xc_arr - (L / 2) * np.cos(th_arr)
    ys_m = yc_arr - (L / 2) * np.sin(th_arr)

    fig_w, fig_h = 8, 5
    fig_aspect = fig_w / fig_h
    xpad, ypad = 0.5, 0.4
    y_lo = -0.4
    x_lo_d = min(xs_m.min(), xs_p.min()) - xpad
    x_hi_d = max(xs_m.max(), xs_p.max()) + xpad
    y_hi_d = max(ys_p.max(), ys_m.max(), yc_arr.max()) + ypad
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi, y_hi = x_lo_d - extra, x_hi_d + extra, y_hi_d
    else:
        extra = dx / fig_aspect - dy
        x_lo, x_hi, y_hi = x_lo_d, x_hi_d, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi)
    ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal")
    ax.axis("off")
    ax.axhspan(y_lo, 0.0, color="#4a4e69", alpha=0.55, zorder=0)
    ax.axhline(0, color="#adb5bd", lw=2, zorder=1)

    rod_ln, = ax.plot([], [], "-", color="#e63946", lw=12,
                      solid_capstyle="round", zorder=3)

    def update(f):
        rod_ln.set_data([xs_m[f], xs_p[f]], [ys_m[f], ys_p[f]])
        return (rod_ln,)

    ani = animation.FuncAnimation(fig, update, frames=t.size,
                                  interval=1000 / fps, blit=True)
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: BouncingRodParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""
Bouncing Rod — auto-generated simulation script.
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation

L       = {p["L"]}
m       = {p["m"]}
g       = {p["g"]}
e_rest  = {p["e_rest"]}
mu      = {p["mu"]}
xc0     = {p["xc0"]}
yc0     = {p["yc0"]}
theta0  = {p["theta0"]}
vx0     = {p["vx0"]}
vy0     = {p["vy0"]}
omega0  = {p["omega0"]}
duration = {duration}

I_cm = m * L * L / 12.0
fps  = 30

def free_flight(t, y):
    return [y[3], y[4], y[5], 0.0, -g, 0.0]

def ev_plus(t, y):
    return y[1] + (L/2.0)*np.sin(y[2])
ev_plus.terminal = True;  ev_plus.direction = -1
def ev_minus(t, y):
    return y[1] - (L/2.0)*np.sin(y[2])
ev_minus.terminal = True; ev_minus.direction = -1

def contact_step(state):
    s = state.copy()
    for _ in range(8):
        any_imp = False
        for sgn in (+1.0, -1.0):
            xc, yc, th, vx, vy, om = s
            rx = sgn * (L/2.0) * np.cos(th)
            ry = sgn * (L/2.0) * np.sin(th)
            ey = yc + ry
            vp_y = vy + rx * om
            if ey > 1e-9 or vp_y > -1e-12: continue
            vp_x = vx - ry * om
            Jn   = -(1.0 + e_rest) * vp_y / (1.0/m + rx*rx / I_cm)
            Jt_s = -vp_x / (1.0/m + ry*ry / I_cm)
            mt   = mu * Jn
            Jt   = max(-mt, min(mt, Jt_s))
            s[3] = vx + Jt / m
            s[4] = vy + Jn / m
            s[5] = om + (rx * Jn - ry * Jt) / I_cm
            s[1] = yc - ey
            any_imp = True
        if not any_imp: break
    return s

t_eval_global = np.linspace(0, duration, int(duration * fps) + 1)
xc_arr = np.zeros_like(t_eval_global)
yc_arr = np.zeros_like(t_eval_global)
th_arr = np.zeros_like(t_eval_global)

state = np.array([xc0, yc0, theta0, vx0, vy0, omega0], dtype=float)
xc_arr[0], yc_arr[0], th_arr[0] = state[0], state[1], state[2]
last_idx = 1
t_cur    = 0.0

for _seg in range(2000):
    if t_cur >= duration - 1e-9: break
    sol = solve_ivp(free_flight, (t_cur, duration), state,
                    events=[ev_plus, ev_minus], dense_output=True,
                    max_step=0.02, rtol=1e-9, atol=1e-11)
    seg_end = sol.t[-1]
    while last_idx < len(t_eval_global) and t_eval_global[last_idx] <= seg_end + 1e-12:
        st = sol.sol(t_eval_global[last_idx])
        xc_arr[last_idx], yc_arr[last_idx], th_arr[last_idx] = st[0], st[1], st[2]
        last_idx += 1
    state = sol.y[:, -1].copy()
    t_cur = seg_end
    if sol.status != 1: break
    state = contact_step(state)
    KE = 0.5 * m * (state[3]**2 + state[4]**2) + 0.5 * I_cm * state[5]**2
    if KE < 0.03 and abs(state[1]) < 0.05 and abs(np.sin(state[2])) < 0.10:
        th_rest = round(state[2] / np.pi) * np.pi
        state = np.array([state[0], 0.0, th_rest, 0.0, 0.0, 0.0])
        break

if last_idx < len(t_eval_global):
    xc_arr[last_idx:] = state[0]; yc_arr[last_idx:] = state[1]; th_arr[last_idx:] = state[2]

xs_p = xc_arr + (L/2)*np.cos(th_arr); ys_p = yc_arr + (L/2)*np.sin(th_arr)
xs_m = xc_arr - (L/2)*np.cos(th_arr); ys_m = yc_arr - (L/2)*np.sin(th_arr)

fig_w, fig_h = 8, 5
fig_aspect   = fig_w / fig_h
xpad, ypad   = 0.5, 0.4
y_lo         = -0.4
x_lo_d       = min(xs_m.min(), xs_p.min()) - xpad
x_hi_d       = max(xs_m.max(), xs_p.max()) + xpad
y_hi_d       = max(ys_p.max(), ys_m.max(), yc_arr.max()) + ypad
dx, dy       = x_hi_d - x_lo_d, y_hi_d - y_lo
if dx / dy < fig_aspect:
    extra  = (fig_aspect * dy - dx) / 2.0
    x_lo, x_hi, y_hi = x_lo_d - extra, x_hi_d + extra, y_hi_d
else:
    extra  = dx / fig_aspect - dy
    x_lo, x_hi, y_hi = x_lo_d, x_hi_d, y_hi_d + extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax  = fig.add_axes([0, 0, 1, 1])
ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.axhspan(y_lo, 0.0, color="#4a4e69", alpha=0.55, zorder=0)
ax.axhline(0, color="#adb5bd", lw=2, zorder=1)

rod_ln, = ax.plot([], [], "-", color="#e63946", lw=12,
                  solid_capstyle="round", zorder=3)

def update(f):
    rod_ln.set_data([xs_m[f], xs_p[f]], [ys_m[f], ys_p[f]])
    return (rod_ln,)

ani = animation.FuncAnimation(fig, update, frames=t_eval_global.size,
                              interval=1000/fps, blit=True)
ani.save("bouncing_rod.mp4",
         writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved bouncing_rod.mp4")
'''


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Bouncing Rod Simulation")
    parser.add_argument("--L", type=float, default=1.4)
    parser.add_argument("--m", type=float, default=1.0)
    parser.add_argument("--g", type=float, default=9.8)
    parser.add_argument("--e_rest", type=float, default=0.7)
    parser.add_argument("--mu", type=float, default=0.20)
    parser.add_argument("--xc0", type=float, default=0.0)
    parser.add_argument("--yc0", type=float, default=2.6)
    parser.add_argument("--theta0", type=float, default=0.349066)
    parser.add_argument("--vx0", type=float, default=0.6)
    parser.add_argument("--vy0", type=float, default=0.0)
    parser.add_argument("--omega0", type=float, default=-0.20)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="bouncing_rod.mp4")
    args = parser.parse_args()

    p = BouncingRodParams(
        L=args.L, m=args.m, g=args.g, e_rest=args.e_rest, mu=args.mu,
        xc0=args.xc0, yc0=args.yc0, theta0=args.theta0,
        vx0=args.vx0, vy0=args.vy0, omega0=args.omega0,
    )
    print(f"Simulating bouncing rod: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
