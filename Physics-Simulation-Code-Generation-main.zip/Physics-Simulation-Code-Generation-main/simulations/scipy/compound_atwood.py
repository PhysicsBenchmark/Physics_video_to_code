"""
Compound (double) Atwood machine
=================================
Fixed pulley A on the ceiling; string over A connects mass m1 (left end) to the
axle of a movable pulley B (right end). Rope over B connects mass m2 (left) to
mass m3 (right).

Constraints (massless inextensible cords; positive y = depth below ceiling):
  String A:        y1 + yB  = const   ->  ÿ1 + ÿB = 0
  Rope B:  (y2 - yB) + (y3 - yB) = const  ->  ÿ2 + ÿ3 - 2 ÿB = 0
Tension on a massless movable pulley B:  T_A = 2 T_B.
Newton II (down = +):
  m1 ÿ1 = m1 g - T_A
  m2 ÿ2 = m2 g - T_B
  m3 ÿ3 = m3 g - T_B

Solving:
  T_B = 4 g / (1/m2 + 1/m3 + 4/m1)
  T_A = 2 T_B
  ÿ1 = g - T_A/m1, ÿ2 = g - T_B/m2, ÿ3 = g - T_B/m3, ÿB = -ÿ1.

All accelerations constant -> closed-form positions.
"""

from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class CompoundAtwoodParams:
    m1: float = 3.0
    m2: float = 1.0
    m3: float = 2.0
    g: float = 9.8
    x_A: float = 2.0
    x_B: float = 2.5
    r_pulley: float = 0.50
    cube_side: float = 0.45
    x_m1: float = 1.5
    x_m2: float = 2.0
    x_m3: float = 3.0
    y1_0: float = 1.50
    y2_0: float = 5.00
    y3_0: float = 3.50
    yB_0: float = 2.50
    v1_0: float = 0.0
    v2_0: float = 0.0
    v3_0: float = 0.0
    vB_0: float = 0.0


def _accels(params: CompoundAtwoodParams):
    m1, m2, m3, g = params.m1, params.m2, params.m3, params.g
    T_B = 4.0 * g / (1.0 / m2 + 1.0 / m3 + 4.0 / m1)
    T_A = 2.0 * T_B
    a1 = g - T_A / m1
    a2 = g - T_B / m2
    a3 = g - T_B / m3
    aB = -a1
    return T_A, T_B, a1, a2, a3, aB


def simulate(
    params: CompoundAtwoodParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    T_A, T_B, a1, a2, a3, aB = _accels(params)
    cube_side = params.cube_side
    r = params.r_pulley
    y_A = r + 0.05
    y_floor = max(params.y1_0, params.y2_0, params.y3_0) + 2.5

    n_frames = int(duration * fps) + 1
    t_grid = np.linspace(0, duration, n_frames)

    y1 = params.y1_0 + params.v1_0 * t_grid + 0.5 * a1 * t_grid ** 2
    y2 = params.y2_0 + params.v2_0 * t_grid + 0.5 * a2 * t_grid ** 2
    y3 = params.y3_0 + params.v3_0 * t_grid + 0.5 * a3 * t_grid ** 2
    yB = params.yB_0 + params.vB_0 * t_grid + 0.5 * aB * t_grid ** 2

    # Physical constraints (depth coord, +y = downward):
    #   y1 >= y_A           m1 top below pulley A's tangent
    #   y2,y3 >= yB + r     cube top below pulley B's bottom rim (rope length > 0)
    #   yB >= r             pulley B top below ceiling
    #   y1,y2,y3 + cube_side <= y_floor   cubes above floor
    #   yB + r <= y_floor                 pulley B above floor
    ok = ((y1 >= y_A) & (y2 >= yB + r) & (y3 >= yB + r) & (yB >= r)
          & (y1 + cube_side <= y_floor)
          & (y2 + cube_side <= y_floor)
          & (y3 + cube_side <= y_floor)
          & (yB + r <= y_floor))
    if not ok.all():
        first_bad = int(np.argmax(~ok))
        last_good = max(first_bad - 1, 0)
        y1[first_bad:] = y1[last_good]
        y2[first_bad:] = y2[last_good]
        y3[first_bad:] = y3[last_good]
        yB[first_bad:] = yB[last_good]

    return t_grid, np.vstack([y1, y2, y3, yB])


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: CompoundAtwoodParams,
    output_path: str,
    fps: int = 30,
) -> None:
    y1, y2, y3, yB = y[0], y[1], y[2], y[3]
    cube_side = params.cube_side
    r = params.r_pulley
    x_A, x_B = params.x_A, params.x_B
    y_A = r + 0.05
    x_m1, x_m2, x_m3 = params.x_m1, params.x_m2, params.x_m3
    y_floor = max(y1.max(), y2.max(), y3.max()) + cube_side + 0.5

    fig_w, fig_h = 5.0, 8.0
    fig_aspect = fig_w / fig_h
    x_lo_d = min(x_m1, x_m2, x_m3) - cube_side / 2 - 0.4
    x_hi_d = max(x_m1, x_m2, x_m3) + cube_side / 2 + 0.4
    y_lo_d = -0.4
    y_hi_d = y_floor + 0.4
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi)
    ax.set_ylim(y_hi, y_lo)
    ax.set_aspect("equal")
    ax.axis("off")

    ax.add_patch(patches.Rectangle((x_lo, y_lo), x_hi - x_lo, -y_lo,
                                   facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.plot([x_lo, x_hi], [0, 0], color="#adb5bd", lw=2.5, zorder=2)
    ax.add_patch(patches.Rectangle((x_lo, y_floor), x_hi - x_lo, y_hi - y_floor,
                                   facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.plot([x_lo, x_hi], [y_floor, y_floor], color="#adb5bd", lw=2.5, zorder=2)

    ax.add_patch(patches.Circle((x_A, y_A), r, facecolor="#4a4e69",
                                edgecolor="white", lw=1.6, zorder=4))
    ax.plot([x_A, x_A], [0, y_A - r], color="#adb5bd", lw=2.5, zorder=3)
    ax.add_patch(patches.Arc((x_A, y_A), 2 * r, 2 * r, angle=0, theta1=180, theta2=360,
                             color="#a8dadc", lw=2.5, zorder=5))
    ax.add_patch(patches.Circle((x_A, y_A), r * 0.18, facecolor="#1a1a2e",
                                edgecolor="#adb5bd", lw=1.0, zorder=6))

    pulley_B_body = patches.Circle((x_B, yB[0]), r, facecolor="#4a4e69",
                                   edgecolor="white", lw=1.6, zorder=4)
    arc_B = patches.Arc((x_B, yB[0]), 2 * r, 2 * r, angle=0, theta1=180, theta2=360,
                        color="#a8dadc", lw=2.5, zorder=5)
    hub_B = patches.Circle((x_B, yB[0]), r * 0.18, facecolor="#1a1a2e",
                           edgecolor="#adb5bd", lw=1.0, zorder=6)
    ax.add_patch(pulley_B_body); ax.add_patch(arc_B); ax.add_patch(hub_B)

    cube1 = patches.Rectangle((x_m1 - cube_side / 2, y1[0]), cube_side, cube_side,
                              facecolor="#e63946", edgecolor="white", lw=1.5, zorder=7)
    cube2 = patches.Rectangle((x_m2 - cube_side / 2, y2[0]), cube_side, cube_side,
                              facecolor="#f4d35e", edgecolor="white", lw=1.5, zorder=7)
    cube3 = patches.Rectangle((x_m3 - cube_side / 2, y3[0]), cube_side, cube_side,
                              facecolor="#a8dadc", edgecolor="white", lw=1.5, zorder=7)
    ax.add_patch(cube1); ax.add_patch(cube2); ax.add_patch(cube3)

    str_A_left, = ax.plot([], [], color="#a8dadc", lw=2.5, zorder=5)
    str_A_right, = ax.plot([], [], color="#a8dadc", lw=2.5, zorder=5)
    rope_B_left, = ax.plot([], [], color="#a8dadc", lw=2.5, zorder=5)
    rope_B_right, = ax.plot([], [], color="#a8dadc", lw=2.5, zorder=5)

    def update(f):
        y1f, y2f, y3f, yBf = y1[f], y2[f], y3[f], yB[f]
        cube1.set_y(y1f); cube2.set_y(y2f); cube3.set_y(y3f)
        pulley_B_body.center = (x_B, yBf)
        hub_B.center = (x_B, yBf)
        arc_B.set_center((x_B, yBf))
        str_A_left.set_data([x_A - r, x_A - r], [y_A, y1f])
        str_A_right.set_data([x_A + r, x_B], [y_A, yBf - r])
        rope_B_left.set_data([x_B - r, x_B - r], [yBf, y2f])
        rope_B_right.set_data([x_B + r, x_B + r], [yBf, y3f])
        return (cube1, cube2, cube3, pulley_B_body, hub_B, arc_B,
                str_A_left, str_A_right, rope_B_left, rope_B_right)

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000 / fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: CompoundAtwoodParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""
Compound Atwood machine — auto-generated.
"""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

m1, m2, m3 = {p["m1"]}, {p["m2"]}, {p["m3"]}
g = {p["g"]}
r_pulley = {p["r_pulley"]}
cube_side = {p["cube_side"]}
x_A, x_B = {p["x_A"]}, {p["x_B"]}
x_m1, x_m2, x_m3 = {p["x_m1"]}, {p["x_m2"]}, {p["x_m3"]}
y1_0 = {p["y1_0"]}; y2_0 = {p["y2_0"]}; y3_0 = {p["y3_0"]}; yB_0 = {p["yB_0"]}
v1_0 = {p["v1_0"]}; v2_0 = {p["v2_0"]}; v3_0 = {p["v3_0"]}; vB_0 = {p["vB_0"]}
duration = {duration}
fps = 30

T_B = 4.0 * g / (1.0/m2 + 1.0/m3 + 4.0/m1)
T_A = 2.0 * T_B
a1 = g - T_A/m1
a2 = g - T_B/m2
a3 = g - T_B/m3
aB = -a1

y_floor = max(y1_0, y2_0, y3_0) + 2.5
y_A = r_pulley + 0.05

n_frames = int(duration * fps) + 1
t_grid = np.linspace(0, duration, n_frames)
y1 = y1_0 + v1_0 * t_grid + 0.5 * a1 * t_grid ** 2
y2 = y2_0 + v2_0 * t_grid + 0.5 * a2 * t_grid ** 2
y3 = y3_0 + v3_0 * t_grid + 0.5 * a3 * t_grid ** 2
yB = yB_0 + vB_0 * t_grid + 0.5 * aB * t_grid ** 2

ok = ((y1 >= y_A) & (y2 >= yB + r_pulley) & (y3 >= yB + r_pulley)
      & (yB >= r_pulley)
      & (y1 + cube_side <= y_floor)
      & (y2 + cube_side <= y_floor)
      & (y3 + cube_side <= y_floor)
      & (yB + r_pulley <= y_floor))
if not ok.all():
    first_bad = int(np.argmax(~ok))
    last_good = max(first_bad - 1, 0)
    y1[first_bad:] = y1[last_good]
    y2[first_bad:] = y2[last_good]
    y3[first_bad:] = y3[last_good]
    yB[first_bad:] = yB[last_good]

y_A = r_pulley + 0.05
y_floor_render = max(y1.max(), y2.max(), y3.max()) + cube_side + 0.5

fig_w, fig_h = 5.0, 8.0
fig_aspect = fig_w / fig_h
x_lo_d = min(x_m1, x_m2, x_m3) - cube_side/2 - 0.4
x_hi_d = max(x_m1, x_m2, x_m3) + cube_side/2 + 0.4
y_lo_d = -0.4
y_hi_d = y_floor_render + 0.4
dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
if dx/dy < fig_aspect:
    extra = (fig_aspect * dy - dx) / 2.0
    x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
else:
    extra = (dx/fig_aspect - dy) / 2.0
    x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0, 0, 1, 1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_hi, y_lo)
ax.set_aspect("equal"); ax.axis("off")

ax.add_patch(patches.Rectangle((x_lo, y_lo), x_hi - x_lo, -y_lo, facecolor="#4a4e69", edgecolor="none", zorder=0))
ax.plot([x_lo, x_hi], [0, 0], color="#adb5bd", lw=2.5, zorder=2)
ax.add_patch(patches.Rectangle((x_lo, y_floor_render), x_hi - x_lo, y_hi - y_floor_render, facecolor="#4a4e69", edgecolor="none", zorder=0))
ax.plot([x_lo, x_hi], [y_floor_render, y_floor_render], color="#adb5bd", lw=2.5, zorder=2)

ax.add_patch(patches.Circle((x_A, y_A), r_pulley, facecolor="#4a4e69", edgecolor="white", lw=1.6, zorder=4))
ax.plot([x_A, x_A], [0, y_A - r_pulley], color="#adb5bd", lw=2.5, zorder=3)
ax.add_patch(patches.Arc((x_A, y_A), 2*r_pulley, 2*r_pulley, angle=0, theta1=180, theta2=360, color="#a8dadc", lw=2.5, zorder=5))
ax.add_patch(patches.Circle((x_A, y_A), r_pulley * 0.18, facecolor="#1a1a2e", edgecolor="#adb5bd", lw=1.0, zorder=6))

pulley_B_body = patches.Circle((x_B, yB_0), r_pulley, facecolor="#4a4e69", edgecolor="white", lw=1.6, zorder=4)
arc_B = patches.Arc((x_B, yB_0), 2*r_pulley, 2*r_pulley, angle=0, theta1=180, theta2=360, color="#a8dadc", lw=2.5, zorder=5)
hub_B = patches.Circle((x_B, yB_0), r_pulley * 0.18, facecolor="#1a1a2e", edgecolor="#adb5bd", lw=1.0, zorder=6)
ax.add_patch(pulley_B_body); ax.add_patch(arc_B); ax.add_patch(hub_B)

cube1 = patches.Rectangle((x_m1 - cube_side/2, y1_0), cube_side, cube_side, facecolor="#e63946", edgecolor="white", lw=1.5, zorder=7)
cube2 = patches.Rectangle((x_m2 - cube_side/2, y2_0), cube_side, cube_side, facecolor="#f4d35e", edgecolor="white", lw=1.5, zorder=7)
cube3 = patches.Rectangle((x_m3 - cube_side/2, y3_0), cube_side, cube_side, facecolor="#a8dadc", edgecolor="white", lw=1.5, zorder=7)
ax.add_patch(cube1); ax.add_patch(cube2); ax.add_patch(cube3)

str_A_left,  = ax.plot([], [], color="#a8dadc", lw=2.5, zorder=5)
str_A_right, = ax.plot([], [], color="#a8dadc", lw=2.5, zorder=5)
rope_B_left, = ax.plot([], [], color="#a8dadc", lw=2.5, zorder=5)
rope_B_right,= ax.plot([], [], color="#a8dadc", lw=2.5, zorder=5)

def update(f):
    y1f, y2f, y3f, yBf = y1[f], y2[f], y3[f], yB[f]
    cube1.set_y(y1f); cube2.set_y(y2f); cube3.set_y(y3f)
    pulley_B_body.center = (x_B, yBf)
    hub_B.center = (x_B, yBf)
    arc_B.set_center((x_B, yBf))
    str_A_left.set_data([x_A - r_pulley, x_A - r_pulley], [y_A, y1f])
    str_A_right.set_data([x_A + r_pulley, x_B], [y_A, yBf - r_pulley])
    rope_B_left.set_data([x_B - r_pulley, x_B - r_pulley], [yBf, y2f])
    rope_B_right.set_data([x_B + r_pulley, x_B + r_pulley], [yBf, y3f])
    return cube1, cube2, cube3, pulley_B_body, hub_B, arc_B, str_A_left, str_A_right, rope_B_left, rope_B_right

ani = animation.FuncAnimation(fig, update, frames=n_frames, interval=1000/fps, blit=True)
ani.save("compound_atwood.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close(); print("Saved compound_atwood.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Compound Atwood machine")
    for k, v in asdict(CompoundAtwoodParams()).items():
        parser.add_argument(f"--{k}", type=float, default=v)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="compound_atwood.mp4")
    args = parser.parse_args()
    fields = {k: getattr(args, k) for k in asdict(CompoundAtwoodParams()).keys()}
    p = CompoundAtwoodParams(**fields)
    print(f"Simulating compound atwood: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
