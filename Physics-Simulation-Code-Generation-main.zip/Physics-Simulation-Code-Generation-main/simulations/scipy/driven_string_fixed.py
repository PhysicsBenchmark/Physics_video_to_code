"""
Driven String + Fixed End
=========================
Taut horizontal string of length L, mass density mu, tension T (so c = sqrt(T/mu)).
Left end driven sinusoidally:  u(0,t) = A sin(omega t).
Right end fixed:               u(L,t) = 0.
Damped wave equation: u_tt = c^2 u_xx - 2 gamma_w u_t.
Explicit leapfrog FDM with centred-time damping (CFL: (c dt/dx)^2 < 1).
"""

from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Circle, Rectangle
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class DrivenStringFixedParams:
    L: float = 4.0
    mu: float = 0.10
    T: float = 4.0
    A: float = 0.10
    f_drive: float = 2.0
    gamma_w: float = 1.0
    N_grid: int = 200
    n_per_frame: int = 16


def simulate(
    params: DrivenStringFixedParams,
    duration: float = 8.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    L = params.L
    mu_v = params.mu
    T = params.T
    A = params.A
    omega = 2 * np.pi * params.f_drive
    c = np.sqrt(T / mu_v)
    gamma_w = params.gamma_w
    N = int(params.N_grid)
    n_per_frame = int(params.n_per_frame)

    dx = L / N
    x_grid = np.linspace(0.0, L, N + 1)
    dt = 1.0 / (fps * n_per_frame)
    factor = (c * dt / dx) ** 2
    if factor >= 1.0:
        # Tighten n_per_frame to satisfy CFL.
        while factor >= 1.0:
            n_per_frame *= 2
            dt = 1.0 / (fps * n_per_frame)
            factor = (c * dt / dx) ** 2
    damp_n = 1.0 / (1.0 + gamma_w * dt)
    damp_p = 1.0 - gamma_w * dt

    u_curr = np.zeros(N + 1)
    u_prev = np.zeros(N + 1)
    n_frames = int(duration * fps) + 1
    U_frames = np.zeros((n_frames, N + 1))
    U_frames[0] = u_curr.copy()

    for frame in range(1, n_frames):
        for sub in range(n_per_frame):
            t_curr = (frame - 1) / fps + (sub + 1) * dt
            u_next = np.empty_like(u_curr)
            lap_int = u_curr[2:] - 2 * u_curr[1:-1] + u_curr[:-2]
            u_next[1:-1] = damp_n * (
                2 * u_curr[1:-1] - damp_p * u_prev[1:-1] + factor * lap_int
            )
            u_next[-1] = 0.0
            u_next[0] = A * np.sin(omega * t_curr)
            u_prev, u_curr = u_curr, u_next
        U_frames[frame] = u_curr.copy()

    t_eval = np.linspace(0.0, duration, n_frames)
    return t_eval, U_frames.T  # shape (N+1, n_frames)


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: DrivenStringFixedParams,
    output_path: str,
    fps: int = 30,
) -> None:
    L = params.L
    A = params.A
    N = int(params.N_grid)
    x_grid = np.linspace(0.0, L, N + 1)
    U_frames = y.T  # (n_frames, N+1)

    fig_w, fig_h = 12.0, 4.0
    fig_aspect = fig_w / fig_h
    x_lo_d = -0.40
    x_hi_d = L + 0.40
    y_lo_d = -4.5 * A
    y_hi_d = +4.5 * A
    dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_d / dy_d < fig_aspect:
        extra = (fig_aspect * dy_d - dx_d) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx_d / fig_aspect - dy_d) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")
    ax.axhline(0.0, color="#3a4357", lw=1, ls="--", zorder=0)
    ax.plot([0, 0], [y_lo, y_hi], color="#4a4e69", lw=1.5, ls=":", zorder=1)
    driver_dot = Circle((0, 0), 0.04, facecolor="#e63946",
                        edgecolor="#adb5bd", lw=1.0, zorder=5)
    ax.add_patch(driver_dot)
    ax.add_patch(Rectangle((L, y_lo), 0.12, y_hi - y_lo,
                           facecolor="#4a4e69", edgecolor="#adb5bd", lw=1.5, zorder=2))
    ax.plot([L, L], [y_lo, y_hi], color="#adb5bd", lw=2.0, zorder=3)
    anchor = Circle((L, 0), 0.05, facecolor="#e63946",
                    edgecolor="#adb5bd", lw=1.0, zorder=5)
    ax.add_patch(anchor)
    str_line, = ax.plot([], [], color="#a8dadc", lw=2.4, zorder=4)

    def update(f):
        u = U_frames[f]
        str_line.set_data(x_grid, u)
        driver_dot.center = (0, u[0])
        return str_line, driver_dot, anchor

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0 / fps, blit=False)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: DrivenStringFixedParams, duration: float = 8.0) -> str:
    p = asdict(params)
    return f'''"""
Driven String + Fixed End — auto-generated.
"""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Circle, Rectangle

L          = {p["L"]}
mu         = {p["mu"]}
T          = {p["T"]}
A          = {p["A"]}
f_drive    = {p["f_drive"]}
gamma_w    = {p["gamma_w"]}
N          = {int(p["N_grid"])}
n_per_frame_in = {int(p["n_per_frame"])}
duration   = {duration}
fps        = 30
omega      = 2 * np.pi * f_drive
c          = np.sqrt(T / mu)

dx = L / N
x_grid = np.linspace(0.0, L, N + 1)
n_per_frame = n_per_frame_in
dt = 1.0 / (fps * n_per_frame)
factor = (c * dt / dx) ** 2
while factor >= 1.0:
    n_per_frame *= 2
    dt = 1.0 / (fps * n_per_frame)
    factor = (c * dt / dx) ** 2
damp_n = 1.0 / (1.0 + gamma_w * dt)
damp_p = 1.0 - gamma_w * dt

u_curr = np.zeros(N + 1)
u_prev = np.zeros(N + 1)
n_frames = int(duration * fps) + 1
U_frames = np.zeros((n_frames, N + 1))
U_frames[0] = u_curr.copy()

for frame in range(1, n_frames):
    for sub in range(n_per_frame):
        t_curr = (frame - 1) / fps + (sub + 1) * dt
        u_next = np.empty_like(u_curr)
        lap_int = u_curr[2:] - 2 * u_curr[1:-1] + u_curr[:-2]
        u_next[1:-1] = damp_n * (2 * u_curr[1:-1] - damp_p * u_prev[1:-1] + factor * lap_int)
        u_next[-1] = 0.0
        u_next[0] = A * np.sin(omega * t_curr)
        u_prev, u_curr = u_curr, u_next
    U_frames[frame] = u_curr.copy()

fig_w, fig_h = 12.0, 4.0
fig_aspect = fig_w / fig_h
x_lo_d = -0.40; x_hi_d = L + 0.40
y_lo_d = -4.5 * A; y_hi_d = +4.5 * A
dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
if dx_d / dy_d < fig_aspect:
    extra = (fig_aspect * dy_d - dx_d) / 2.0
    x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
    y_lo, y_hi = y_lo_d, y_hi_d
else:
    extra = (dx_d / fig_aspect - dy_d) / 2.0
    x_lo, x_hi = x_lo_d, x_hi_d
    y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0, 0, 1, 1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.axhline(0.0, color="#3a4357", lw=1, ls="--", zorder=0)
ax.plot([0, 0], [y_lo, y_hi], color="#4a4e69", lw=1.5, ls=":", zorder=1)
driver_dot = Circle((0, 0), 0.04, facecolor="#e63946", edgecolor="#adb5bd", lw=1.0, zorder=5)
ax.add_patch(driver_dot)
ax.add_patch(Rectangle((L, y_lo), 0.12, y_hi - y_lo, facecolor="#4a4e69", edgecolor="#adb5bd", lw=1.5, zorder=2))
ax.plot([L, L], [y_lo, y_hi], color="#adb5bd", lw=2.0, zorder=3)
anchor = Circle((L, 0), 0.05, facecolor="#e63946", edgecolor="#adb5bd", lw=1.0, zorder=5)
ax.add_patch(anchor)
str_line, = ax.plot([], [], color="#a8dadc", lw=2.4, zorder=4)

def update(f):
    u = U_frames[f]
    str_line.set_data(x_grid, u)
    driver_dot.center = (0, u[0])
    return str_line, driver_dot, anchor

ani = animation.FuncAnimation(fig, update, frames=n_frames, interval=1000.0/fps, blit=False)
ani.save("driven_string_fixed.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close(); print("Saved driven_string_fixed.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Driven String + Fixed End")
    parser.add_argument("--L", type=float, default=4.0)
    parser.add_argument("--mu", type=float, default=0.10)
    parser.add_argument("--T", type=float, default=4.0)
    parser.add_argument("--A", type=float, default=0.10)
    parser.add_argument("--f_drive", type=float, default=2.0)
    parser.add_argument("--gamma_w", type=float, default=1.0)
    parser.add_argument("--N_grid", type=int, default=200)
    parser.add_argument("--n_per_frame", type=int, default=16)
    parser.add_argument("--duration", type=float, default=8.0)
    parser.add_argument("--output", type=str, default="driven_string_fixed.mp4")
    args = parser.parse_args()
    p = DrivenStringFixedParams(
        L=args.L, mu=args.mu, T=args.T, A=args.A,
        f_drive=args.f_drive, gamma_w=args.gamma_w,
        N_grid=args.N_grid, n_per_frame=args.n_per_frame,
    )
    print(f"Simulating driven string fixed: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
