"""
Two gears driven by a flat belt - kinematic visualization.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon, Circle
from matplotlib.collections import LineCollection
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class TwoGearBeltParams:
    N_A: int = 30
    N_B: int = 18
    R_A: float = 0.60
    addendum: float = 0.030
    dedendum: float = 0.040
    tooth_frac: float = 0.40
    r_pulley: float = 0.20
    v_max: float = 0.30
    t_ramp: float = 1.0

    def __post_init__(self):
        # Coerce sampled-float tooth counts to integers (downstream code uses
        # range(N_teeth) and N-indexed arrays).
        self.N_A = int(self.N_A)
        self.N_B = int(self.N_B)


def simulate(params: TwoGearBeltParams, duration: float = 12.0, fps: int = 30):
    p = params
    R_B = p.R_A * p.N_B / p.N_A
    n = int(duration * fps) + 1
    t_eval = np.linspace(0.0, duration, n)

    def belt_s(t):
        if t <= p.t_ramp:
            return p.v_max * t * t / (2.0 * p.t_ramp)
        return p.v_max * (t - p.t_ramp / 2.0)

    theta_B_0 = np.pi / p.N_B
    theta_A = np.array([belt_s(t) / p.r_pulley for t in t_eval])
    theta_B = theta_B_0 - (p.N_A / p.N_B) * theta_A
    y = np.vstack([theta_A, theta_B])
    return t_eval, y


def _gear_polygon(cx, cy, R, N_teeth, theta, addendum, dedendum, tooth_frac):
    r_add = R + addendum
    r_ded = R - dedendum
    pitch = 2.0 * np.pi / N_teeth
    phi = 0.5 * tooth_frac * pitch
    pts = np.empty((4 * N_teeth, 2))
    for i in range(N_teeth):
        theta_c = i * pitch + theta
        for k, (r, dphi) in enumerate(((r_ded, -phi), (r_add, -phi),
                                        (r_add, +phi), (r_ded, +phi))):
            ang = theta_c + dphi
            pts[4 * i + k, 0] = cx + r * np.cos(ang)
            pts[4 * i + k, 1] = cy + r * np.sin(ang)
    return pts


def render_video(t, y, params: TwoGearBeltParams, output_path: str, fps: int = 30):
    p = params
    R_B = p.R_A * p.N_B / p.N_A
    cA = np.array([0.0, 0.0])
    cB = np.array([p.R_A + R_B, 0.0])
    fig_w, fig_h = 7.0, 7.0
    fig_aspect = fig_w / fig_h
    x_lo_d = -p.R_A - p.addendum - 0.20
    x_hi_d = cB[0] + R_B + p.addendum + 0.20
    y_lo_d = -p.R_A - p.addendum - 0.20
    y_hi_d = +p.R_A + p.addendum + 1.30
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    y_top_off = y_hi + 0.10
    n_arc = 60
    arc_angles = np.linspace(np.pi, 2.0 * np.pi, n_arc)
    arc_pts = np.column_stack([cA[0] + p.r_pulley * np.cos(arc_angles),
                               cA[1] + p.r_pulley * np.sin(arc_angles)])
    belt_path = np.concatenate([
        [[cA[0] - p.r_pulley, y_top_off]], arc_pts,
        [[cA[0] + p.r_pulley, y_top_off]],
    ])
    seg_lens = np.linalg.norm(np.diff(belt_path, axis=0), axis=1)
    s_path = np.concatenate([[0.0], np.cumsum(seg_lens)])
    total_belt_len = s_path[-1]
    tangents = np.zeros_like(belt_path)
    tangents[1:-1] = belt_path[2:] - belt_path[:-2]
    tangents[0] = belt_path[1] - belt_path[0]
    tangents[-1] = belt_path[-1] - belt_path[-2]
    tangents /= np.linalg.norm(tangents, axis=1, keepdims=True) + 1e-12
    normals = np.column_stack([-tangents[:, 1], tangents[:, 0]])

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    theta_B_0 = np.pi / p.N_B
    gA_patch = Polygon(_gear_polygon(cA[0], cA[1], p.R_A, p.N_A, 0.0,
                                     p.addendum, p.dedendum, p.tooth_frac),
                       facecolor="#a8dadc", edgecolor="#adb5bd", lw=1.2, zorder=4)
    gB_patch = Polygon(_gear_polygon(cB[0], cB[1], R_B, p.N_B, theta_B_0,
                                     p.addendum, p.dedendum, p.tooth_frac),
                       facecolor="#a8dadc", edgecolor="#adb5bd", lw=1.2, zorder=4)
    ax.add_patch(gA_patch); ax.add_patch(gB_patch)
    ax.add_patch(Circle(cA, p.R_A - p.dedendum * 1.4, facecolor="#3a4357", edgecolor="none", zorder=4.2))
    ax.add_patch(Circle(cB, R_B - p.dedendum * 1.6, facecolor="#3a4357", edgecolor="none", zorder=4.2))
    markerA, = ax.plot([], [], color="#e63946", lw=3.0, zorder=4.5)
    markerB, = ax.plot([], [], color="#e63946", lw=3.0, zorder=4.5)
    belt_back, = ax.plot(belt_path[:, 0], belt_path[:, 1], color="#4a4e69", lw=14, solid_capstyle="butt", zorder=6)
    belt_top, = ax.plot(belt_path[:, 0], belt_path[:, 1], color="#3a4357", lw=10, solid_capstyle="butt", zorder=6.5)
    hash_lc = LineCollection([], colors="#adb5bd", linewidths=2.0, zorder=7)
    ax.add_collection(hash_lc)
    ax.add_patch(Circle(cA, p.r_pulley * 0.85, facecolor="#3a4357", edgecolor="#adb5bd", lw=1.0, zorder=8))
    ax.add_patch(Circle(cA, 0.045, facecolor="#e63946", edgecolor="#adb5bd", lw=0.8, zorder=9))
    ax.add_patch(Circle(cB, 0.045, facecolor="#e63946", edgecolor="#adb5bd", lw=0.8, zorder=9))

    hash_spacing = 0.13; hash_w = 0.045

    def belt_s(tt):
        if tt <= p.t_ramp:
            return p.v_max * tt * tt / (2.0 * p.t_ramp)
        return p.v_max * (tt - p.t_ramp / 2.0)

    def update(f):
        th_A = y[0, f]; th_B = y[1, f]
        gA_patch.set_xy(_gear_polygon(cA[0], cA[1], p.R_A, p.N_A, th_A,
                                      p.addendum, p.dedendum, p.tooth_frac))
        gB_patch.set_xy(_gear_polygon(cB[0], cB[1], R_B, p.N_B, th_B,
                                      p.addendum, p.dedendum, p.tooth_frac))
        rmA = p.R_A + p.addendum * 0.5
        markerA.set_data([cA[0], cA[0] + rmA * np.cos(th_A)],
                         [cA[1], cA[1] + rmA * np.sin(th_A)])
        rmB = R_B + p.addendum * 0.5
        markerB.set_data([cB[0], cB[0] + rmB * np.cos(th_B)],
                         [cB[1], cB[1] + rmB * np.sin(th_B)])
        s0 = belt_s(t[f]) % hash_spacing
        s_marks = np.arange(s0, total_belt_len, hash_spacing)
        if s_marks.size > 0:
            px = np.interp(s_marks, s_path, belt_path[:, 0])
            py = np.interp(s_marks, s_path, belt_path[:, 1])
            nx = np.interp(s_marks, s_path, normals[:, 0])
            ny = np.interp(s_marks, s_path, normals[:, 1])
            seg_a = np.column_stack([px - hash_w * nx, py - hash_w * ny])
            seg_b = np.column_stack([px + hash_w * nx, py + hash_w * ny])
            hash_lc.set_segments(np.stack([seg_a, seg_b], axis=1))
        else:
            hash_lc.set_segments([])
        return gA_patch, gB_patch, markerA, markerB, hash_lc

    ani = animation.FuncAnimation(fig, update, frames=len(t), interval=1000.0 / fps, blit=False)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: TwoGearBeltParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Two gear belt - auto-generated."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon, Circle
from matplotlib.collections import LineCollection

N_A={p["N_A"]}; N_B={p["N_B"]}; R_A={p["R_A"]}
R_B=R_A*N_B/N_A
addendum={p["addendum"]}; dedendum={p["dedendum"]}; tooth_frac={p["tooth_frac"]}
r_pulley={p["r_pulley"]}; v_max={p["v_max"]}; t_ramp={p["t_ramp"]}
duration={duration}; fps=30

def belt_s(t):
    if t<=t_ramp:
        return v_max*t*t/(2.0*t_ramp)
    return v_max*(t-t_ramp/2.0)
def theta_A(t): return belt_s(t)/r_pulley
theta_B_0 = np.pi/N_B
def theta_B(t): return theta_B_0 - (N_A/N_B)*theta_A(t)

def gear_polygon(cx,cy,R,N_teeth,theta=0.0):
    r_add=R+addendum; r_ded=R-dedendum
    pitch=2.0*np.pi/N_teeth
    phi=0.5*tooth_frac*pitch
    pts=np.empty((4*N_teeth,2))
    for i in range(N_teeth):
        theta_c=i*pitch+theta
        for k,(r,dphi) in enumerate(((r_ded,-phi),(r_add,-phi),(r_add,+phi),(r_ded,+phi))):
            ang=theta_c+dphi
            pts[4*i+k,0]=cx+r*np.cos(ang)
            pts[4*i+k,1]=cy+r*np.sin(ang)
    return pts

cA=np.array([0.0,0.0]); cB=np.array([R_A+R_B,0.0])
fig_w,fig_h=7.0,7.0; fa=fig_w/fig_h
x_lo_d=-R_A-addendum-0.20; x_hi_d=cB[0]+R_B+addendum+0.20
y_lo_d=-R_A-addendum-0.20; y_hi_d=+R_A+addendum+1.30
dx,dy=x_hi_d-x_lo_d,y_hi_d-y_lo_d
if dx/dy<fa:
    e=(fa*dy-dx)/2.0; x_lo,x_hi=x_lo_d-e,x_hi_d+e; y_lo,y_hi=y_lo_d,y_hi_d
else:
    e=(dx/fa-dy)/2.0; x_lo,x_hi=x_lo_d,x_hi_d; y_lo,y_hi=y_lo_d-e,y_hi_d+e

y_top_off=y_hi+0.10; n_arc=60
arc_angles=np.linspace(np.pi,2.0*np.pi,n_arc)
arc_pts=np.column_stack([cA[0]+r_pulley*np.cos(arc_angles),cA[1]+r_pulley*np.sin(arc_angles)])
belt_path=np.concatenate([[[cA[0]-r_pulley,y_top_off]],arc_pts,[[cA[0]+r_pulley,y_top_off]]])
seg_lens=np.linalg.norm(np.diff(belt_path,axis=0),axis=1)
s_path=np.concatenate([[0.0],np.cumsum(seg_lens)])
total_belt_len=s_path[-1]
tangents=np.zeros_like(belt_path)
tangents[1:-1]=belt_path[2:]-belt_path[:-2]
tangents[0]=belt_path[1]-belt_path[0]
tangents[-1]=belt_path[-1]-belt_path[-2]
tangents/=np.linalg.norm(tangents,axis=1,keepdims=True)+1e-12
normals=np.column_stack([-tangents[:,1],tangents[:,0]])

fig=plt.figure(figsize=(fig_w,fig_h),facecolor="#1a1a2e")
ax=fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi); ax.set_aspect("equal"); ax.axis("off")
gA=Polygon(gear_polygon(cA[0],cA[1],R_A,N_A),facecolor="#a8dadc",edgecolor="#adb5bd",lw=1.2,zorder=4)
gB=Polygon(gear_polygon(cB[0],cB[1],R_B,N_B,theta=theta_B_0),facecolor="#a8dadc",edgecolor="#adb5bd",lw=1.2,zorder=4)
ax.add_patch(gA); ax.add_patch(gB)
ax.add_patch(Circle(cA,R_A-dedendum*1.4,facecolor="#3a4357",edgecolor="none",zorder=4.2))
ax.add_patch(Circle(cB,R_B-dedendum*1.6,facecolor="#3a4357",edgecolor="none",zorder=4.2))
mA,=ax.plot([],[],color="#e63946",lw=3.0,zorder=4.5)
mB,=ax.plot([],[],color="#e63946",lw=3.0,zorder=4.5)
ax.plot(belt_path[:,0],belt_path[:,1],color="#4a4e69",lw=14,solid_capstyle="butt",zorder=6)
ax.plot(belt_path[:,0],belt_path[:,1],color="#3a4357",lw=10,solid_capstyle="butt",zorder=6.5)
hash_lc=LineCollection([],colors="#adb5bd",linewidths=2.0,zorder=7)
ax.add_collection(hash_lc)
ax.add_patch(Circle(cA,r_pulley*0.85,facecolor="#3a4357",edgecolor="#adb5bd",lw=1.0,zorder=8))
ax.add_patch(Circle(cA,0.045,facecolor="#e63946",edgecolor="#adb5bd",lw=0.8,zorder=9))
ax.add_patch(Circle(cB,0.045,facecolor="#e63946",edgecolor="#adb5bd",lw=0.8,zorder=9))
hash_spacing=0.13; hash_w=0.045

def update(f):
    t=f/fps
    tA=theta_A(t); tB=theta_B(t)
    gA.set_xy(gear_polygon(cA[0],cA[1],R_A,N_A,theta=tA))
    gB.set_xy(gear_polygon(cB[0],cB[1],R_B,N_B,theta=tB))
    rmA=R_A+addendum*0.5
    mA.set_data([cA[0],cA[0]+rmA*np.cos(tA)],[cA[1],cA[1]+rmA*np.sin(tA)])
    rmB=R_B+addendum*0.5
    mB.set_data([cB[0],cB[0]+rmB*np.cos(tB)],[cB[1],cB[1]+rmB*np.sin(tB)])
    s0=belt_s(t)%hash_spacing
    s_marks=np.arange(s0,total_belt_len,hash_spacing)
    if s_marks.size>0:
        px=np.interp(s_marks,s_path,belt_path[:,0])
        py=np.interp(s_marks,s_path,belt_path[:,1])
        nx=np.interp(s_marks,s_path,normals[:,0])
        ny=np.interp(s_marks,s_path,normals[:,1])
        seg_a=np.column_stack([px-hash_w*nx,py-hash_w*ny])
        seg_b=np.column_stack([px+hash_w*nx,py+hash_w*ny])
        hash_lc.set_segments(np.stack([seg_a,seg_b],axis=1))
    else:
        hash_lc.set_segments([])
    return gA,gB,mA,mB,hash_lc

n_frames=int(duration*fps)+1
ani=animation.FuncAnimation(fig,update,frames=n_frames,interval=1000/fps,blit=False)
ani.save("video.mp4",writer=animation.FFMpegWriter(fps=fps,bitrate=1800),dpi=120)
plt.close(); print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--N_A", type=int, default=30)
    parser.add_argument("--N_B", type=int, default=18)
    parser.add_argument("--R_A", type=float, default=0.60)
    parser.add_argument("--addendum", type=float, default=0.030)
    parser.add_argument("--dedendum", type=float, default=0.040)
    parser.add_argument("--tooth_frac", type=float, default=0.40)
    parser.add_argument("--r_pulley", type=float, default=0.20)
    parser.add_argument("--v_max", type=float, default=0.30)
    parser.add_argument("--t_ramp", type=float, default=1.0)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="video.mp4")
    args = parser.parse_args()
    p = TwoGearBeltParams(N_A=args.N_A, N_B=args.N_B, R_A=args.R_A,
                          addendum=args.addendum, dedendum=args.dedendum,
                          tooth_frac=args.tooth_frac, r_pulley=args.r_pulley,
                          v_max=args.v_max, t_ramp=args.t_ramp)
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
