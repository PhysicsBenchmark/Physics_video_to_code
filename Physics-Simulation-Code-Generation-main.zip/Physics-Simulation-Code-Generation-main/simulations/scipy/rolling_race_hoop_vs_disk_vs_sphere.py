"""
Rolling Race: Hoop vs Disk vs Sphere
====================================

A famous classroom demonstration. Three round bodies — a thin hoop, a solid
disk (cylinder), and a solid sphere — are released simultaneously from the
top of three identical inclined ramps and roll down without slipping. The
along-incline acceleration is

  a = g sin θ / (1 + β),     β ≡ I_cm / (m r²)

where β depends only on the body's moment-of-inertia ratio, NOT on its
mass or radius:

   hoop   (thin ring) :  I = m r²       ⇒  β = 1     ⇒  a = ½  g sin θ
   disk   (cylinder)  :  I = ½ m r²     ⇒  β = ½     ⇒  a = ⅔  g sin θ
   sphere (solid)     :  I = ⅖ m r²     ⇒  β = ⅖     ⇒  a = 5⁄7 g sin θ

So the sphere wins, the disk is second, and the hoop comes last —
independent of the radii and masses of the three bodies.

Two-phase per body:

  • on-ramp  (s_i ≤ L_ramp):  s̈_i = +g sin θ / (1 + β_i)   (constant accel.)
  • on-flat  (s_i  > L_ramp): s̈_i = -μ_r g                  (rolling resist.)
  • the body stops when v_i reaches 0.

Rolling-without-slipping fixes the rotation ω_i = −ṡ_i / r_i.

State per body i: (s_i, v_i, φ_i = -s_i / r_i).  All bodies start at rest at
the top of the ramp.

NOTE: There is intentionally no text, axis label, parameter value, or other
glyph rendered onto the frames — only the visual scene.
"""

from __future__ import annotations
import math
import random
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, field, asdict
from typing import List
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis


# Moment-of-inertia ratios β = I_cm / (m r²) for the three rolling bodies
BETA = {"hoop": 1.0, "disk": 0.5, "sphere": 0.4}


@dataclass
class RollingRaceHoopVsDiskVsSphereParams:
    """
    `setup_seed` randomises lane order, radii, masses, and palette.
    Top-level scalars fix the overall geometry and physics.
    """
    setup_seed: float = 0.0
    theta_deg: float = 14.0           # incline angle (deg)
    g: float = 9.81                    # gravitational acceleration (m/s²)
    L_ramp: float = 4.0                # ramp length along the incline (m)
    L_flat: float = 6.0                # length of the flat run-out section (m)
    mu_r_flat: float = 0.12            # rolling-resistance coefficient on the flat (dimensionless)
    lane_pitch: float = 1.6            # vertical spacing between the three lanes (m)

    # Auto-populated from setup_seed:
    shapes: List[str]   = field(default_factory=list)   # in lane order (top → bottom on screen)
    r:      List[float] = field(default_factory=list)
    m:      List[float] = field(default_factory=list)
    colors: List[str]   = field(default_factory=list)

    def __post_init__(self):
        if not self.shapes:
            self._build_layout()

    def _build_layout(self):
        rng = random.Random(int(self.setup_seed))
        # Randomly assign the three shapes to the three lanes.
        kinds = ["hoop", "disk", "sphere"]
        rng.shuffle(kinds)
        self.shapes = kinds
        # Per-body radii and masses (mass does NOT affect dynamics — included
        # to demonstrate that the finishing order is independent of m and r).
        self.r = [round(rng.uniform(0.13, 0.22), 4) for _ in range(3)]
        self.m = [round(rng.uniform(0.5, 2.0), 3) for _ in range(3)]
        palette = ["#e63946", "#f4a261", "#2a9d8f",
                   "#9d4edd", "#fcbf49", "#a8dadc"]
        rng.shuffle(palette)
        self.colors = palette[:3]


# ─────────────────────────────────────────────────────────────────────────────
# Dynamics — analytic two-phase solution sampled at frame rate
# ─────────────────────────────────────────────────────────────────────────────

def simulate(
    params: RollingRaceHoopVsDiskVsSphereParams,
    duration: float = 8.0,
    fps: int = 30,
):
    n_frames = int(duration * fps) + 1
    t_eval = np.linspace(0.0, duration, n_frames)
    sin_t = math.sin(math.radians(params.theta_deg))
    n = len(params.shapes)
    s   = np.zeros((n, n_frames))
    v   = np.zeros((n, n_frames))
    phi = np.zeros((n, n_frames))         # roll angle (rad)

    for i, shape in enumerate(params.shapes):
        beta = BETA[shape]
        a_ramp = params.g * sin_t / (1.0 + beta)
        a_flat = -params.mu_r_flat * params.g
        t_ramp_end = math.sqrt(2.0 * params.L_ramp / a_ramp)
        v_bot = a_ramp * t_ramp_end
        t_stop_after_bot = -v_bot / a_flat                # > 0

        for j, tt in enumerate(t_eval):
            if tt <= t_ramp_end:
                s_i = 0.5 * a_ramp * tt * tt
                v_i = a_ramp * tt
            else:
                t_f = tt - t_ramp_end
                if t_f <= t_stop_after_bot:
                    s_i = params.L_ramp + v_bot * t_f + 0.5 * a_flat * t_f * t_f
                    v_i = v_bot + a_flat * t_f
                else:
                    s_stop = params.L_ramp + v_bot * t_stop_after_bot \
                             + 0.5 * a_flat * t_stop_after_bot * t_stop_after_bot
                    s_i = s_stop
                    v_i = 0.0
            s[i, j]   = s_i
            v[i, j]   = v_i
            phi[i, j] = -s_i / params.r[i]

    # Stack as one matrix: rows are [s_0..s_{n-1}, v_0..v_{n-1}, phi_0..phi_{n-1}].
    return t_eval, np.vstack([s, v, phi])


# ─────────────────────────────────────────────────────────────────────────────
# Geometry helpers (path-distance → world (x, y))
# ─────────────────────────────────────────────────────────────────────────────

def _path_to_xy(s_path: float, L_ramp: float, theta: float, x_top: float,
                y_top_floor: float, r: float):
    """
    Map a body's path-distance s_path to the world centre (x, y).
    The lane's flat surface is at y = y_top_floor; the ramp top is at
    (x_top, y_top_floor + L_ramp · sin θ); the body's centre sits one radius
    above the local surface.
    """
    if s_path <= L_ramp:
        # On the incline.
        x_surf = x_top + s_path * math.cos(theta)
        y_surf = (y_top_floor + L_ramp * math.sin(theta)) - s_path * math.sin(theta)
        # Outward normal to the incline surface (pointing up & to the right):
        cx = x_surf + r * math.sin(theta)
        cy = y_surf + r * math.cos(theta)
    else:
        x_surf = x_top + L_ramp * math.cos(theta) + (s_path - L_ramp)
        y_surf = y_top_floor
        cx = x_surf
        cy = y_surf + r
    return cx, cy


# ─────────────────────────────────────────────────────────────────────────────
# Shape painters — each returns the (mutable) artists added to the axes
# ─────────────────────────────────────────────────────────────────────────────

def _add_hoop(ax, cx, cy, r, color, lw=3.0):
    """Open ring + a single radial spoke that visualises the rotation."""
    ring = patches.Circle((cx, cy), r, fill=False,
                          edgecolor=color, lw=lw, zorder=4)
    spoke, = ax.plot([cx, cx + r], [cy, cy], "-", color="white", lw=1.6, zorder=5)
    ax.add_patch(ring)
    return ring, spoke


def _add_disk(ax, cx, cy, r, color):
    """Filled disk + a diameter line as the rotation marker."""
    disk = patches.Circle((cx, cy), r, fill=True,
                          facecolor=color, edgecolor="white", lw=1.4, zorder=4)
    diameter, = ax.plot([cx - r, cx + r], [cy, cy], "-",
                        color="white", lw=1.6, zorder=5)
    ax.add_patch(disk)
    return disk, diameter


def _add_sphere(ax, cx, cy, r, color):
    """Filled circle with a smaller inner highlight + an offset dot to
    make rotation visible (the dot orbits the centre at radius r·0.6)."""
    body = patches.Circle((cx, cy), r, fill=True,
                          facecolor=color, edgecolor="white", lw=1.4, zorder=4)
    highlight = patches.Circle((cx - 0.35 * r, cy + 0.35 * r), 0.20 * r,
                               fill=True, facecolor="white", alpha=0.50,
                               edgecolor="none", zorder=5)
    dot, = ax.plot([cx + 0.6 * r], [cy], "o", color="white", ms=4, zorder=6)
    ax.add_patch(body)
    ax.add_patch(highlight)
    return body, highlight, dot


# ─────────────────────────────────────────────────────────────────────────────
# Render — pure visual, no on-frame text whatsoever
# ─────────────────────────────────────────────────────────────────────────────

def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: RollingRaceHoopVsDiskVsSphereParams,
    output_path: str,
    fps: int = 30,
) -> None:
    n = len(params.shapes)
    s_traj   = y[:n]
    phi_traj = y[2 * n: 3 * n]
    theta = math.radians(params.theta_deg)
    cosT, sinT = math.cos(theta), math.sin(theta)
    L_ramp = params.L_ramp
    L_flat = params.L_flat

    # Each lane's reference frame: x_top = 0 at the top-of-ramp (apex).
    x_top = 0.0
    lane_floor_ys = [-(i * params.lane_pitch) for i in range(n)]   # top lane has the largest y

    # Frame extent
    xlim = (x_top - 0.6, x_top + L_ramp * cosT + L_flat + 0.6)
    apex_y_max = max(lane_floor_ys) + L_ramp * sinT + max(params.r) + 0.4
    ylim = (min(lane_floor_ys) - 0.4,
            apex_y_max + 0.2)

    fig, ax = plt.subplots(figsize=(10, 5.5))
    setup_dark_axis(fig, ax, xlim, ylim, title="")

    # ── Static elements: one ramp + flat per lane ────────────────────────────
    for floor_y in lane_floor_ys:
        apex_x = x_top
        apex_y = floor_y + L_ramp * sinT
        bot_x  = x_top + L_ramp * cosT
        # Ramp wedge (filled triangle/trapezoid for solidity)
        ramp_pts = np.array([
            [apex_x,                  apex_y],
            [bot_x,                   floor_y],
            [apex_x,                  floor_y],
        ])
        ax.add_patch(patches.Polygon(
            ramp_pts, closed=True,
            facecolor="#4a4e69", edgecolor="#adb5bd",
            lw=1.2, hatch="////", zorder=1,
        ))
        # Flat run-out
        flat_pts = np.array([
            [bot_x,            floor_y],
            [bot_x + L_flat,   floor_y],
            [bot_x + L_flat,   floor_y - 0.06],
            [bot_x,            floor_y - 0.06],
        ])
        ax.add_patch(patches.Polygon(
            flat_pts, closed=True,
            facecolor="#4a4e69", edgecolor="#adb5bd",
            lw=1.0, hatch="\\\\", zorder=1,
        ))

    # ── Animated elements ────────────────────────────────────────────────────
    # For each body, build its painted artists and store enough state to
    # update them per frame.
    body_artists = []        # list of dicts per body
    for i, shape in enumerate(params.shapes):
        floor_y = lane_floor_ys[i]
        cx0, cy0 = _path_to_xy(s_traj[i, 0], L_ramp, theta, x_top, floor_y, params.r[i])
        if shape == "hoop":
            ring, spoke = _add_hoop(ax, cx0, cy0, params.r[i], params.colors[i])
            body_artists.append({
                "shape": "hoop", "ring": ring, "spoke": spoke,
                "r": params.r[i], "lane_floor_y": floor_y,
            })
        elif shape == "disk":
            disk, diameter = _add_disk(ax, cx0, cy0, params.r[i], params.colors[i])
            body_artists.append({
                "shape": "disk", "disk": disk, "diameter": diameter,
                "r": params.r[i], "lane_floor_y": floor_y,
            })
        else:  # sphere
            body, highlight, dot = _add_sphere(ax, cx0, cy0, params.r[i], params.colors[i])
            body_artists.append({
                "shape": "sphere", "body": body, "highlight": highlight,
                "dot": dot, "r": params.r[i], "lane_floor_y": floor_y,
            })

    def update(frame):
        artists = []
        for i, art in enumerate(body_artists):
            r_i  = art["r"]
            f_y  = art["lane_floor_y"]
            cx, cy = _path_to_xy(s_traj[i, frame], L_ramp, theta, x_top, f_y, r_i)
            ang = phi_traj[i, frame]   # roll angle (rad)
            cos_a, sin_a = math.cos(ang), math.sin(ang)

            if art["shape"] == "hoop":
                art["ring"].center = (cx, cy)
                # spoke from centre to (cx + r cos a, cy + r sin a)
                art["spoke"].set_data(
                    [cx, cx + r_i * cos_a], [cy, cy + r_i * sin_a]
                )
                artists += [art["ring"], art["spoke"]]
            elif art["shape"] == "disk":
                art["disk"].center = (cx, cy)
                # diameter line from (cx − r cos a, cy − r sin a) to opposite end
                art["diameter"].set_data(
                    [cx - r_i * cos_a, cx + r_i * cos_a],
                    [cy - r_i * sin_a, cy + r_i * sin_a],
                )
                artists += [art["disk"], art["diameter"]]
            else:  # sphere
                art["body"].center = (cx, cy)
                # Highlight stays at a fixed visual offset (top-left), it does
                # NOT rotate (stylised 3-D specular highlight).
                art["highlight"].center = (cx - 0.35 * r_i, cy + 0.35 * r_i)
                # Dot orbits at radius 0.6 r — the rotation indicator.
                art["dot"].set_data(
                    [cx + 0.6 * r_i * cos_a],
                    [cy + 0.6 * r_i * sin_a],
                )
                artists += [art["body"], art["highlight"], art["dot"]]
        return tuple(artists)

    ani = animation.FuncAnimation(
        fig, update, frames=len(t),
        interval=1000 / fps, blit=False,
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


# ─────────────────────────────────────────────────────────────────────────────
# Standalone (auto-generated) script
# ─────────────────────────────────────────────────────────────────────────────

def make_standalone_script(
    params: RollingRaceHoopVsDiskVsSphereParams,
    duration: float = 8.0,
) -> str:
    p = asdict(params)
    return f'''"""
Rolling Race — auto-generated simulation script.

Each body i obeys
  on the ramp:  s̈_i = +g sin θ / (1 + β_i),     β_i ∈ {{1, 1/2, 2/5}}
  on the flat:  s̈_i = -μ_r g
  rolling without slipping: φ_i = -s_i / r_i

The frame contains NO text overlays — visual only.
"""
import math
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

# ── Parameters ─────────────────────────────────────────────────────────────
theta_deg  = {p["theta_deg"]}
g          = {p["g"]}
L_ramp     = {p["L_ramp"]}
L_flat     = {p["L_flat"]}
mu_r_flat  = {p["mu_r_flat"]}
lane_pitch = {p["lane_pitch"]}

shapes  = {p["shapes"]}      # top → bottom on screen
radii   = {p["r"]}
colors  = {p["colors"]}

duration = {duration}
fps      = 30

theta = math.radians(theta_deg)
cosT, sinT = math.cos(theta), math.sin(theta)
BETA = {{"hoop": 1.0, "disk": 0.5, "sphere": 0.4}}

# ── Analytic two-phase trajectory per body ─────────────────────────────────
n = len(shapes)
n_frames = int(duration * fps) + 1
t_eval = np.linspace(0.0, duration, n_frames)
s_traj   = np.zeros((n, n_frames))
phi_traj = np.zeros((n, n_frames))
for i, shape in enumerate(shapes):
    beta = BETA[shape]
    a_ramp = g * sinT / (1.0 + beta)
    a_flat = -mu_r_flat * g
    t_ramp_end = math.sqrt(2.0 * L_ramp / a_ramp)
    v_bot = a_ramp * t_ramp_end
    t_stop = -v_bot / a_flat
    for j, tt in enumerate(t_eval):
        if tt <= t_ramp_end:
            s_i = 0.5 * a_ramp * tt * tt
        else:
            t_f = tt - t_ramp_end
            if t_f <= t_stop:
                s_i = L_ramp + v_bot * t_f + 0.5 * a_flat * t_f * t_f
            else:
                s_i = L_ramp + v_bot * t_stop + 0.5 * a_flat * t_stop * t_stop
        s_traj[i, j] = s_i
        phi_traj[i, j] = -s_i / radii[i]

# ── Geometry helper ────────────────────────────────────────────────────────
def path_to_xy(s_path, floor_y, r):
    if s_path <= L_ramp:
        x_surf = s_path * cosT
        y_surf = (floor_y + L_ramp * sinT) - s_path * sinT
        return x_surf + r * sinT, y_surf + r * cosT
    return L_ramp * cosT + (s_path - L_ramp), floor_y + r

# ── Frame & layout ─────────────────────────────────────────────────────────
lane_floor_ys = [-(i * lane_pitch) for i in range(n)]
xlim = (-0.6, L_ramp * cosT + L_flat + 0.6)
apex_y_max = max(lane_floor_ys) + L_ramp * sinT + max(radii) + 0.4
ylim = (min(lane_floor_ys) - 0.4, apex_y_max + 0.2)

fig, ax = plt.subplots(figsize=(10, 5.5), facecolor="#1a1a2e")
ax.set_facecolor("#16213e")
ax.set_xlim(xlim); ax.set_ylim(ylim)
ax.set_aspect("equal"); ax.axis("off")
# NOTE: no titles, labels, or text are drawn anywhere.

for floor_y in lane_floor_ys:
    apex_y = floor_y + L_ramp * sinT
    bot_x  = L_ramp * cosT
    ramp_pts = np.array([[0.0, apex_y], [bot_x, floor_y], [0.0, floor_y]])
    ax.add_patch(patches.Polygon(ramp_pts, closed=True,
                                  facecolor="#4a4e69", edgecolor="#adb5bd",
                                  lw=1.2, hatch="////", zorder=1))
    flat_pts = np.array([[bot_x, floor_y], [bot_x + L_flat, floor_y],
                         [bot_x + L_flat, floor_y - 0.06], [bot_x, floor_y - 0.06]])
    ax.add_patch(patches.Polygon(flat_pts, closed=True,
                                  facecolor="#4a4e69", edgecolor="#adb5bd",
                                  lw=1.0, hatch="\\\\", zorder=1))

# ── Body painters ──────────────────────────────────────────────────────────
body_arts = []
for i, shape in enumerate(shapes):
    fy = lane_floor_ys[i]; r_i = radii[i]; col = colors[i]
    cx, cy = path_to_xy(s_traj[i, 0], fy, r_i)
    if shape == "hoop":
        ring = patches.Circle((cx, cy), r_i, fill=False,
                              edgecolor=col, lw=3.0, zorder=4)
        sp, = ax.plot([cx, cx + r_i], [cy, cy], "-", color="white", lw=1.6, zorder=5)
        ax.add_patch(ring)
        body_arts.append({{"shape": "hoop", "ring": ring, "spoke": sp,
                           "r": r_i, "fy": fy}})
    elif shape == "disk":
        d = patches.Circle((cx, cy), r_i, fill=True,
                           facecolor=col, edgecolor="white", lw=1.4, zorder=4)
        di, = ax.plot([cx - r_i, cx + r_i], [cy, cy], "-",
                      color="white", lw=1.6, zorder=5)
        ax.add_patch(d)
        body_arts.append({{"shape": "disk", "disk": d, "diameter": di,
                           "r": r_i, "fy": fy}})
    else:  # sphere
        b = patches.Circle((cx, cy), r_i, fill=True,
                           facecolor=col, edgecolor="white", lw=1.4, zorder=4)
        h = patches.Circle((cx - 0.35 * r_i, cy + 0.35 * r_i), 0.20 * r_i,
                           fill=True, facecolor="white", alpha=0.50,
                           edgecolor="none", zorder=5)
        dt, = ax.plot([cx + 0.6 * r_i], [cy], "o",
                      color="white", ms=4, zorder=6)
        ax.add_patch(b); ax.add_patch(h)
        body_arts.append({{"shape": "sphere", "body": b, "highlight": h,
                           "dot": dt, "r": r_i, "fy": fy}})

def update(frame):
    artists = []
    for i, art in enumerate(body_arts):
        r_i = art["r"]; fy = art["fy"]
        cx, cy = path_to_xy(s_traj[i, frame], fy, r_i)
        ang = phi_traj[i, frame]
        cos_a, sin_a = math.cos(ang), math.sin(ang)
        if art["shape"] == "hoop":
            art["ring"].center = (cx, cy)
            art["spoke"].set_data([cx, cx + r_i * cos_a], [cy, cy + r_i * sin_a])
            artists += [art["ring"], art["spoke"]]
        elif art["shape"] == "disk":
            art["disk"].center = (cx, cy)
            art["diameter"].set_data(
                [cx - r_i * cos_a, cx + r_i * cos_a],
                [cy - r_i * sin_a, cy + r_i * sin_a],
            )
            artists += [art["disk"], art["diameter"]]
        else:
            art["body"].center = (cx, cy)
            art["highlight"].center = (cx - 0.35 * r_i, cy + 0.35 * r_i)
            art["dot"].set_data([cx + 0.6 * r_i * cos_a],
                                [cy + 0.6 * r_i * sin_a])
            artists += [art["body"], art["highlight"], art["dot"]]
    return tuple(artists)

ani = animation.FuncAnimation(fig, update, frames=n_frames,
                              interval=1000 / fps, blit=False)
ani.save("rolling_race_hoop_vs_disk_vs_sphere.mp4",
         writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved rolling_race_hoop_vs_disk_vs_sphere.mp4")
'''


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Rolling Race — Hoop vs Disk vs Sphere")
    parser.add_argument("--setup_seed", type=float, default=0.0)
    parser.add_argument("--theta_deg",  type=float, default=14.0)
    parser.add_argument("--duration",   type=float, default=8.0)
    parser.add_argument("--output",     type=str,
                        default="rolling_race_hoop_vs_disk_vs_sphere.mp4")
    args = parser.parse_args()

    p = RollingRaceHoopVsDiskVsSphereParams(
        setup_seed=args.setup_seed, theta_deg=args.theta_deg,
    )
    print(f"Layout: shapes={p.shapes}, r={p.r}, m={p.m}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
