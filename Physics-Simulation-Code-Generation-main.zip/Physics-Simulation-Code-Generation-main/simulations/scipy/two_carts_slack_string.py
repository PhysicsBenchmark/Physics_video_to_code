"""
Two carts connected by a slack inextensible string on a friction rail.
Closed-form 4-phase analytical solution.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class TwoCartsSlackStringParams:
    g: float = 9.8
    m_L: float = 1.0
    m_R: float = 0.6
    L_s: float = 1.5
    mu_f: float = 0.05
    x_L_0: float = -2.00
    x_R_0: float = -1.50
    v_L_0: float = 0.0
    v_R_0: float = 2.50
    cart_w: float = 0.30
    cart_h: float = 0.20


def _solve(p: TwoCartsSlackStringParams, duration: float, fps: int):
    a_dec = p.mu_f * p.g
    sep_0 = p.x_R_0 - p.x_L_0
    disc = p.v_R_0**2 - 2.0 * a_dec * (p.L_s - sep_0)
    if disc <= 0:
        # Right cart stops before string becomes taut; clamp gracefully.
        t_star = p.v_R_0 / a_dec * 0.99
    else:
        t_star = (p.v_R_0 - np.sqrt(disc)) / a_dec
    v_R_pre = p.v_R_0 - a_dec * t_star
    v_common = (p.m_L * 0.0 + p.m_R * v_R_pre) / (p.m_L + p.m_R)
    t_stop_common = v_common / a_dec if a_dec > 0 else 0.0
    t_total_stop = t_star + t_stop_common
    x_L_at_jerk = p.x_L_0
    x_R_at_jerk = p.x_R_0 + p.v_R_0 * t_star - 0.5 * a_dec * t_star**2

    n_frames = int(duration * fps) + 1
    t_grid = np.linspace(0.0, duration, n_frames)
    x_L = np.empty(n_frames); x_R = np.empty(n_frames)
    for i, t in enumerate(t_grid):
        if t <= t_star:
            x_L[i] = p.x_L_0
            x_R[i] = p.x_R_0 + p.v_R_0 * t - 0.5 * a_dec * t * t
        elif t <= t_total_stop:
            dt = t - t_star
            common_dx = v_common * dt - 0.5 * a_dec * dt * dt
            x_L[i] = x_L_at_jerk + common_dx
            x_R[i] = x_R_at_jerk + common_dx
        else:
            common_dx = 0.5 * v_common * t_stop_common
            x_L[i] = x_L_at_jerk + common_dx
            x_R[i] = x_R_at_jerk + common_dx
    return t_grid, np.vstack([x_L, x_R])


def simulate(params: TwoCartsSlackStringParams, duration: float = 8.0, fps: int = 30):
    return _solve(params, duration, fps)


def render_video(t, y, params: TwoCartsSlackStringParams, output_path: str, fps: int = 30):
    p = params
    x_L_arr, x_R_arr = y[0], y[1]
    fig_w, fig_h = 10.0, 4.0
    fig_aspect = fig_w / fig_h
    x_lo_d = p.x_L_0 - 0.6
    x_hi_d = x_R_arr[-1] + 0.8
    y_lo_d = -0.45; y_hi_d = p.cart_h + 0.55
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")
    ax.axhspan(y_lo, 0.0, color="#4a4e69", alpha=0.55, zorder=0)
    ax.axhline(0, color="#adb5bd", lw=2.0, zorder=1)

    cart_L = Rectangle((x_L_arr[0] - p.cart_w / 2, 0.0), p.cart_w, p.cart_h,
                       facecolor="#8ecae6", edgecolor="white", lw=1.5, zorder=4)
    cart_R = Rectangle((x_R_arr[0] - p.cart_w / 2, 0.0), p.cart_w, p.cart_h,
                       facecolor="#ffd166", edgecolor="white", lw=1.5, zorder=4)
    ax.add_patch(cart_L); ax.add_patch(cart_R)
    string_line, = ax.plot([], [], '-', color="#e9ecef", lw=1.6, zorder=3)

    def update(f):
        xL = x_L_arr[f]; xR = x_R_arr[f]
        cart_L.set_x(xL - p.cart_w / 2); cart_R.set_x(xR - p.cart_w / 2)
        xL_right = xL + p.cart_w / 2; xR_left = xR - p.cart_w / 2
        y_attach = p.cart_h / 2
        N = 40
        xs = np.linspace(xL_right, xR_left, N)
        cur_len = xR_left - xL_right
        visual_taut_len = p.L_s - p.cart_w
        slack = visual_taut_len - cur_len
        if slack <= 1e-6 or (xR_left - xL_right) <= 1e-6:
            ys = np.full_like(xs, y_attach)
        else:
            mid = 0.5 * (xL_right + xR_left)
            dip = 0.05 * np.tanh(slack / 0.20)
            u = (xs - mid) / max(0.5 * (xR_left - xL_right), 1e-6)
            ys = y_attach - dip * (1.0 - u * u)
        string_line.set_data(xs, ys)
        return cart_L, cart_R, string_line

    ani = animation.FuncAnimation(fig, update, frames=len(t), interval=1000.0 / fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: TwoCartsSlackStringParams, duration: float = 8.0) -> str:
    p = asdict(params)
    return f'''"""Two carts slack string - auto-generated."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle

g={p["g"]}; m_L={p["m_L"]}; m_R={p["m_R"]}; L_s={p["L_s"]}; mu_f={p["mu_f"]}
x_L_0={p["x_L_0"]}; x_R_0={p["x_R_0"]}; v_L_0={p["v_L_0"]}; v_R_0={p["v_R_0"]}
cart_w={p["cart_w"]}; cart_h={p["cart_h"]}; duration={duration}; fps=30

a_dec=mu_f*g
sep_0=x_R_0-x_L_0
disc=v_R_0**2 - 2.0*a_dec*(L_s-sep_0)
if disc<=0:
    t_star = (v_R_0/a_dec)*0.99
else:
    t_star=(v_R_0-np.sqrt(disc))/a_dec
v_R_pre=v_R_0-a_dec*t_star
v_common=(m_L*0.0+m_R*v_R_pre)/(m_L+m_R)
t_stop_common=v_common/a_dec if a_dec>0 else 0.0
t_total_stop=t_star+t_stop_common
x_L_at_jerk=x_L_0
x_R_at_jerk=x_R_0+v_R_0*t_star-0.5*a_dec*t_star*t_star

n_frames=int(duration*fps)+1
t_grid=np.linspace(0.0,duration,n_frames)
x_L_arr=np.empty(n_frames); x_R_arr=np.empty(n_frames)
for i,t in enumerate(t_grid):
    if t<=t_star:
        x_L_arr[i]=x_L_0; x_R_arr[i]=x_R_0+v_R_0*t-0.5*a_dec*t*t
    elif t<=t_total_stop:
        dt=t-t_star
        common_dx=v_common*dt-0.5*a_dec*dt*dt
        x_L_arr[i]=x_L_at_jerk+common_dx
        x_R_arr[i]=x_R_at_jerk+common_dx
    else:
        common_dx=0.5*v_common*t_stop_common
        x_L_arr[i]=x_L_at_jerk+common_dx
        x_R_arr[i]=x_R_at_jerk+common_dx

fig_w,fig_h=10.0,4.0; fa=fig_w/fig_h
x_lo_d=x_L_0-0.6; x_hi_d=x_R_arr[-1]+0.8
y_lo_d=-0.45; y_hi_d=cart_h+0.55
dx,dy=x_hi_d-x_lo_d,y_hi_d-y_lo_d
if dx/dy<fa:
    e=(fa*dy-dx)/2.0; x_lo,x_hi,y_lo,y_hi=x_lo_d-e,x_hi_d+e,y_lo_d,y_hi_d
else:
    e=(dx/fa-dy)/2.0; x_lo,x_hi,y_lo,y_hi=x_lo_d,x_hi_d,y_lo_d-e,y_hi_d+e

fig=plt.figure(figsize=(fig_w,fig_h),facecolor="#1a1a2e")
ax=fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.axhspan(y_lo,0.0,color="#4a4e69",alpha=0.55,zorder=0)
ax.axhline(0,color="#adb5bd",lw=2.0,zorder=1)
cart_L=Rectangle((x_L_arr[0]-cart_w/2,0.0),cart_w,cart_h,facecolor="#8ecae6",edgecolor="white",lw=1.5,zorder=4)
cart_R=Rectangle((x_R_arr[0]-cart_w/2,0.0),cart_w,cart_h,facecolor="#ffd166",edgecolor="white",lw=1.5,zorder=4)
ax.add_patch(cart_L); ax.add_patch(cart_R)
string_line,=ax.plot([],[],'-',color="#e9ecef",lw=1.6,zorder=3)

def update(f):
    xL=x_L_arr[f]; xR=x_R_arr[f]
    cart_L.set_x(xL-cart_w/2); cart_R.set_x(xR-cart_w/2)
    xL_r=xL+cart_w/2; xR_l=xR-cart_w/2; y_a=cart_h/2
    N=40
    xs=np.linspace(xL_r,xR_l,N)
    cur=xR_l-xL_r; taut_len=L_s-cart_w; slack=taut_len-cur
    if slack<=1e-6 or cur<=1e-6:
        ys=np.full_like(xs,y_a)
    else:
        mid=0.5*(xL_r+xR_l); dip=0.05*np.tanh(slack/0.20)
        u=(xs-mid)/max(0.5*cur,1e-6)
        ys=y_a-dip*(1.0-u*u)
    string_line.set_data(xs,ys)
    return cart_L,cart_R,string_line

ani=animation.FuncAnimation(fig,update,frames=n_frames,interval=1000.0/fps,blit=True)
ani.save("video.mp4",writer=animation.FFMpegWriter(fps=fps,bitrate=1800),dpi=120)
plt.close(); print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    for fld, dflt in asdict(TwoCartsSlackStringParams()).items():
        parser.add_argument(f"--{fld}", type=float, default=dflt)
    parser.add_argument("--duration", type=float, default=8.0)
    parser.add_argument("--output", type=str, default="video.mp4")
    args = parser.parse_args()
    p = TwoCartsSlackStringParams(**{k: getattr(args, k) for k in asdict(TwoCartsSlackStringParams()).keys()})
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
