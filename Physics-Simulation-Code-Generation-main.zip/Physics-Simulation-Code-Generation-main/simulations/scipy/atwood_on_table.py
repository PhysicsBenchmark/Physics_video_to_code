"""
Atwood-on-Table — Block on tabletop coupled by string over a pulley to hanging block.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle, Circle
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class AtwoodOnTableParams:
    g: float = 9.8
    m1: float = 3.0
    m2: float = 1.5
    mu_k: float = 0.30
    s1: float = 0.30
    s2: float = 0.30
    h_table: float = 1.40
    t_thick: float = 0.08
    x_table_l: float = -2.50
    x_table_r: float = 0.60
    x_1_0: float = -1.70
    y_m2_top_0: float = 1.20
    duration: float = 2.0


def simulate(params: AtwoodOnTableParams, duration: float = 2.0, fps: int = 30):
    p = params
    a = (p.m2 * p.g - p.mu_k * p.m1 * p.g) / (p.m1 + p.m2)
    drop = p.y_m2_top_0 - p.s2
    if a <= 0:
        a = 1e-6
    t_impact = float(np.sqrt(2.0 * max(drop, 1e-9) / a))
    n = int(duration * fps) + 1
    t = np.linspace(0.0, duration, n)
    s = np.where(t <= t_impact, 0.5 * a * t * t, drop)
    x1 = p.x_1_0 + s
    y_m2_top = p.y_m2_top_0 - s
    return t, np.stack([x1, y_m2_top])


def render_video(t, y, params: AtwoodOnTableParams, output_path: str, fps: int = 30):
    p = params
    x1_arr, y_m2_top_arr = y[0], y[1]
    y_m2_bot_arr = y_m2_top_arr - p.s2
    x_pulley = p.x_table_r
    y_pulley = p.h_table + p.t_thick + p.s1 / 2.0
    r_pulley = 0.07

    fig_w, fig_h = 8.0, 4.5
    fig_aspect = fig_w / fig_h
    x_lo = p.x_table_l - 0.40
    x_hi = x_pulley + 0.80
    y_lo = -0.30
    y_hi = p.h_table + 0.55
    dx, dy = x_hi - x_lo, y_hi - y_lo
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo -= extra; x_hi += extra
    else:
        extra = dx / fig_aspect - dy
        y_hi += extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    ax.axhspan(y_lo, 0.0, color="#4a4e69", alpha=0.55, zorder=0)
    ax.axhline(0, color="#adb5bd", lw=2, zorder=1)
    ax.add_patch(Rectangle((p.x_table_l, p.h_table), p.x_table_r - p.x_table_l, p.t_thick,
                           facecolor="#bb6f49", edgecolor="white", lw=1.2, zorder=2))
    leg_w = 0.10
    for lx in (p.x_table_l + 0.15, p.x_table_r - leg_w - 0.55):
        ax.add_patch(Rectangle((lx, 0.0), leg_w, p.h_table,
                               facecolor="#8a4f33", edgecolor="white", lw=0.8, zorder=2))

    ax.plot([x_pulley, x_pulley], [y_pulley + r_pulley, y_pulley + r_pulley + 0.09],
            '-', color='#bcbcbc', lw=2.5, zorder=2)
    ax.plot([x_pulley - 0.06, x_pulley + 0.06], [y_pulley + r_pulley + 0.09] * 2,
            '-', color='#bcbcbc', lw=3, zorder=2)
    ax.add_patch(Circle((x_pulley, y_pulley), r_pulley,
                        facecolor="#d4a373", edgecolor="white", lw=1.5, zorder=3))
    ax.plot([x_pulley], [y_pulley], 'o', color="white", ms=4, zorder=4)

    m1_patch = Rectangle((x1_arr[0] - p.s1/2, p.h_table + p.t_thick), p.s1, p.s1,
                         facecolor="#8ecae6", edgecolor="white", lw=1.5, zorder=4)
    ax.add_patch(m1_patch)
    m2_patch = Rectangle((x_pulley - p.s2/2, y_m2_bot_arr[0]), p.s2, p.s2,
                         facecolor="#ffb703", edgecolor="white", lw=1.5, zorder=4)
    ax.add_patch(m2_patch)

    str_h_line, = ax.plot([], [], '-', color="#e9ecef", lw=1.8, zorder=3)
    str_v_line, = ax.plot([], [], '-', color="#e9ecef", lw=1.8, zorder=3)

    def update(f):
        m1_attach_x = x1_arr[f] + p.s1 / 2.0
        str_h_line.set_data([m1_attach_x, x_pulley - r_pulley], [y_pulley, y_pulley])
        str_v_line.set_data([x_pulley, x_pulley], [y_pulley - r_pulley, y_m2_top_arr[f]])
        m1_patch.set_xy((x1_arr[f] - p.s1/2, p.h_table + p.t_thick))
        m2_patch.set_xy((x_pulley - p.s2/2, y_m2_bot_arr[f]))
        return str_h_line, str_v_line, m1_patch, m2_patch

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0/fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: AtwoodOnTableParams, duration: float = 2.0) -> str:
    p = asdict(params)
    return f'''"""Atwood on table - standalone script."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle, Circle

g        = {p["g"]}
m1       = {p["m1"]}
m2       = {p["m2"]}
mu_k     = {p["mu_k"]}
s1       = {p["s1"]}
s2       = {p["s2"]}
h_table     = {p["h_table"]}
t_thick     = {p["t_thick"]}
x_table_l   = {p["x_table_l"]}
x_table_r   = {p["x_table_r"]}
x_pulley    = x_table_r
y_pulley    = h_table + t_thick + s1 / 2.0
r_pulley    = 0.07
x_1_0       = {p["x_1_0"]}
y_m2_top_0  = {p["y_m2_top_0"]}
duration    = {duration}
fps = 30

y_m2_bot_0 = y_m2_top_0 - s2
drop = max(y_m2_bot_0, 1e-6)
a = (m2 * g - mu_k * m1 * g) / (m1 + m2)
if a <= 0:
    a = 1e-6
t_impact = np.sqrt(2.0 * drop / a)

n_frames = int(duration * fps) + 1
t_grid = np.linspace(0.0, duration, n_frames)
s_arr = np.where(t_grid <= t_impact, 0.5 * a * t_grid * t_grid, drop)
x1_arr = x_1_0 + s_arr
y_m2_top_arr = y_m2_top_0 - s_arr
y_m2_bot_arr = y_m2_top_arr - s2

fig_w, fig_h = 8.0, 4.5
fig_aspect = fig_w / fig_h
x_lo = x_table_l - 0.40
x_hi = x_pulley + 0.80
y_lo = -0.30
y_hi = h_table + 0.55
dx, dy = x_hi - x_lo, y_hi - y_lo
if dx / dy < fig_aspect:
    extra = (fig_aspect * dy - dx) / 2.0
    x_lo -= extra; x_hi += extra
else:
    extra = dx / fig_aspect - dy
    y_hi += extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0, 0, 1, 1])
ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.axhspan(y_lo, 0.0, color="#4a4e69", alpha=0.55, zorder=0)
ax.axhline(0, color="#adb5bd", lw=2, zorder=1)
ax.add_patch(Rectangle((x_table_l, h_table), x_table_r - x_table_l, t_thick,
                       facecolor="#bb6f49", edgecolor="white", lw=1.2, zorder=2))
leg_w = 0.10
for lx in (x_table_l + 0.15, x_table_r - leg_w - 0.55):
    ax.add_patch(Rectangle((lx, 0.0), leg_w, h_table,
                           facecolor="#8a4f33", edgecolor="white", lw=0.8, zorder=2))
ax.plot([x_pulley, x_pulley], [y_pulley + r_pulley, y_pulley + r_pulley + 0.09],
        '-', color='#bcbcbc', lw=2.5, zorder=2)
ax.plot([x_pulley - 0.06, x_pulley + 0.06], [y_pulley + r_pulley + 0.09] * 2,
        '-', color='#bcbcbc', lw=3, zorder=2)
ax.add_patch(Circle((x_pulley, y_pulley), r_pulley,
                    facecolor="#d4a373", edgecolor="white", lw=1.5, zorder=3))
ax.plot([x_pulley], [y_pulley], 'o', color="white", ms=4, zorder=4)

m1_patch = Rectangle((x1_arr[0] - s1/2, h_table + t_thick), s1, s1,
                     facecolor="#8ecae6", edgecolor="white", lw=1.5, zorder=4)
ax.add_patch(m1_patch)
m2_patch = Rectangle((x_pulley - s2/2, y_m2_bot_arr[0]), s2, s2,
                     facecolor="#ffb703", edgecolor="white", lw=1.5, zorder=4)
ax.add_patch(m2_patch)
str_h_line, = ax.plot([], [], '-', color="#e9ecef", lw=1.8, zorder=3)
str_v_line, = ax.plot([], [], '-', color="#e9ecef", lw=1.8, zorder=3)

def update(f):
    m1_attach_x = x1_arr[f] + s1 / 2.0
    str_h_line.set_data([m1_attach_x, x_pulley - r_pulley], [y_pulley, y_pulley])
    str_v_line.set_data([x_pulley, x_pulley], [y_pulley - r_pulley, y_m2_top_arr[f]])
    m1_patch.set_xy((x1_arr[f] - s1/2, h_table + t_thick))
    m2_patch.set_xy((x_pulley - s2/2, y_m2_bot_arr[f]))
    return str_h_line, str_v_line, m1_patch, m2_patch

ani = animation.FuncAnimation(fig, update, frames=n_frames,
                              interval=1000.0/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    for k, v in asdict(AtwoodOnTableParams()).items():
        parser.add_argument(f"--{k}", type=float, default=v)
    parser.add_argument("--output", type=str, default="video.mp4")
    args = parser.parse_args()
    p = AtwoodOnTableParams(**{k: getattr(args, k) for k in asdict(AtwoodOnTableParams())})
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
