"""
Wedge-Sphere - movable wedge with rolling sphere on slope.
Phase 1: Lagrangian + rolling-without-slip for closed-form 2x2 system.
Phase 2: independent decel under floor friction (sphere) + rolling resistance.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon, Circle
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class WedgeSphereParams:
    alpha_deg: float = 30.0
    L_wedge: float = 1.8
    M_wedge: float = 5.0
    m_sphere: float = 1.0
    R_sphere: float = 0.18
    mu_w: float = 0.02
    mu_r: float = 0.05
    g: float = 9.81


def _build(p: WedgeSphereParams):
    alpha = np.deg2rad(p.alpha_deg)
    H_wedge = p.L_wedge * np.tan(alpha)
    ca, sa = np.cos(alpha), np.sin(alpha)
    g = p.g
    M = p.M_wedge; m = p.m_sphere; R = p.R_sphere
    A_mat = np.array([[(M + m), m * ca],
                      [m * ca, (7.0 / 5.0) * m]])
    b_vec = np.array([+p.mu_w * (M + m) * g, m * g * sa])
    a_X_p1, a_s_p1 = np.linalg.solve(A_mat, b_vec)
    s_trans = max((H_wedge + R * ca - R) / sa, 0.05)
    if a_s_p1 <= 0:
        a_s_p1 = 0.5
    t_trans = np.sqrt(2.0 * s_trans / a_s_p1)
    X_w_0 = 0.0
    X_at_trans = X_w_0 + 0.5 * a_X_p1 * t_trans * t_trans
    ds_at_trans = a_s_p1 * t_trans
    dX_at_trans = a_X_p1 * t_trans
    phi_at_trans = -s_trans / R
    x_sph_at_trans = X_at_trans + s_trans * ca + R * sa
    vx_sph_trans = dX_at_trans + ds_at_trans * ca
    a_X_p2 = -np.sign(dX_at_trans) * p.mu_w * g if dX_at_trans != 0 else 0.0
    a_sph_p2 = -np.sign(vx_sph_trans) * p.mu_r * g if vx_sph_trans != 0 else 0.0
    return dict(
        alpha=alpha, H_wedge=H_wedge, ca=ca, sa=sa,
        a_X_p1=a_X_p1, a_s_p1=a_s_p1, t_trans=t_trans,
        X_w_0=X_w_0, X_at_trans=X_at_trans, dX_at_trans=dX_at_trans,
        phi_at_trans=phi_at_trans, x_sph_at_trans=x_sph_at_trans,
        vx_sph_trans=vx_sph_trans, a_X_p2=a_X_p2, a_sph_p2=a_sph_p2,
    )


def _state_at_time(t, p, info):
    R = p.R_sphere
    ca, sa = info["ca"], info["sa"]
    if t <= info["t_trans"]:
        X_w = info["X_w_0"] + 0.5 * info["a_X_p1"] * t * t
        s = 0.5 * info["a_s_p1"] * t * t
        x_s = X_w + s * ca + R * sa
        y_s = info["H_wedge"] - s * sa + R * ca
        phi_s = -s / R
        return X_w, x_s, y_s, phi_s
    dt = t - info["t_trans"]
    t_w_stop = info["t_trans"] + abs(info["dX_at_trans"]) / abs(info["a_X_p2"]) if info["a_X_p2"] != 0 else 1e9
    t_sph_stop = info["t_trans"] + abs(info["vx_sph_trans"]) / abs(info["a_sph_p2"]) if info["a_sph_p2"] != 0 else 1e9
    if t < t_w_stop:
        X_w = info["X_at_trans"] + info["dX_at_trans"] * dt + 0.5 * info["a_X_p2"] * dt * dt
    else:
        tw = t_w_stop - info["t_trans"]
        X_w = info["X_at_trans"] + info["dX_at_trans"] * tw + 0.5 * info["a_X_p2"] * tw * tw
    if t < t_sph_stop:
        x_s = info["x_sph_at_trans"] + info["vx_sph_trans"] * dt + 0.5 * info["a_sph_p2"] * dt * dt
    else:
        ts = t_sph_stop - info["t_trans"]
        x_s = info["x_sph_at_trans"] + info["vx_sph_trans"] * ts + 0.5 * info["a_sph_p2"] * ts * ts
    y_s = R
    phi_s = info["phi_at_trans"] - (x_s - info["x_sph_at_trans"]) / R
    return X_w, x_s, y_s, phi_s


def simulate(params: WedgeSphereParams, duration: float = 12.0, fps: int = 30):
    info = _build(params)
    n = int(duration * fps) + 1
    t_eval = np.linspace(0.0, duration, n)
    y = np.zeros((4, n))
    for i, t in enumerate(t_eval):
        Xw, xs, ys, phs = _state_at_time(t, params, info)
        y[0, i] = Xw; y[1, i] = xs; y[2, i] = ys; y[3, i] = phs
    return t_eval, y


def render_video(t, y, params: WedgeSphereParams, output_path: str, fps: int = 30):
    p = params
    alpha = np.deg2rad(p.alpha_deg)
    H_wedge = p.L_wedge * np.tan(alpha)
    X_w_all = y[0]; x_s_all = y[1]
    R = p.R_sphere
    x_lo_d = min(X_w_all.min() - 0.30, -0.50)
    x_hi_d = max(x_s_all.max() + R + 0.30, p.L_wedge + 0.50)
    y_lo_d = -0.40
    y_hi_d = max(H_wedge, R) + 0.30
    fig_w, fig_h = 13.0, 3.0
    fig_aspect = fig_w / fig_h
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")
    ax.add_patch(Polygon([(x_lo, y_lo), (x_hi, y_lo), (x_hi, 0.0), (x_lo, 0.0)],
                         facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.plot([x_lo, x_hi], [0.0, 0.0], color="#adb5bd", lw=2.0, zorder=1)
    wedge_patch = Polygon([(0, 0), (p.L_wedge, 0), (0, H_wedge)],
                          facecolor="#a8dadc", edgecolor="#adb5bd", lw=1.5, zorder=3)
    ax.add_patch(wedge_patch)
    sphere_patch = Circle((0, 0), R, facecolor="#e63946",
                          edgecolor="#adb5bd", lw=1.0, zorder=5)
    ax.add_patch(sphere_patch)
    spin_marker, = ax.plot([], [], color="#1a1a2e", lw=2.0, zorder=6)

    def update(f):
        X_w, x_s, y_s, phi_s = y[0, f], y[1, f], y[2, f], y[3, f]
        wedge_patch.set_xy([(X_w, 0.0), (X_w + p.L_wedge, 0.0), (X_w, H_wedge)])
        sphere_patch.set_center((x_s, y_s))
        spin_marker.set_data([x_s, x_s + R * np.cos(phi_s)],
                             [y_s, y_s + R * np.sin(phi_s)])
        return wedge_patch, sphere_patch, spin_marker

    ani = animation.FuncAnimation(fig, update, frames=len(t), interval=1000.0 / fps, blit=False)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: WedgeSphereParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Wedge sphere - auto-generated."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon, Circle

alpha=np.deg2rad({p["alpha_deg"]})
L_wedge={p["L_wedge"]}; H_wedge=L_wedge*np.tan(alpha)
M={p["M_wedge"]}; m={p["m_sphere"]}; R={p["R_sphere"]}
mu_w={p["mu_w"]}; mu_r={p["mu_r"]}; g={p["g"]}
duration={duration}; fps=30
ca,sa=np.cos(alpha),np.sin(alpha)

A_mat=np.array([[(M+m), m*ca],[m*ca, (7.0/5.0)*m]])
b_vec=np.array([+mu_w*(M+m)*g, m*g*sa])
a_X_p1,a_s_p1=np.linalg.solve(A_mat,b_vec)
s_trans=max((H_wedge+R*ca-R)/sa, 0.05)
if a_s_p1<=0: a_s_p1=0.5
t_trans=np.sqrt(2.0*s_trans/a_s_p1)
X_w_0=0.0
X_at_trans=X_w_0+0.5*a_X_p1*t_trans*t_trans
ds_at_trans=a_s_p1*t_trans; dX_at_trans=a_X_p1*t_trans
phi_at_trans=-s_trans/R
x_sph_at_trans=X_at_trans+s_trans*ca+R*sa
vx_sph_trans=dX_at_trans+ds_at_trans*ca
a_X_p2 = -np.sign(dX_at_trans)*mu_w*g if dX_at_trans!=0 else 0.0
a_sph_p2 = -np.sign(vx_sph_trans)*mu_r*g if vx_sph_trans!=0 else 0.0
t_w_stop = t_trans + abs(dX_at_trans)/abs(a_X_p2) if a_X_p2!=0 else duration+1
t_sph_stop = t_trans + abs(vx_sph_trans)/abs(a_sph_p2) if a_sph_p2!=0 else duration+1

def state_at_time(t):
    if t<=t_trans:
        X_w=X_w_0+0.5*a_X_p1*t*t; s=0.5*a_s_p1*t*t
        x_s=X_w+s*ca+R*sa; y_s=H_wedge-s*sa+R*ca; phi_s=-s/R
        return X_w,x_s,y_s,phi_s
    dt=t-t_trans
    if t<t_w_stop: X_w=X_at_trans+dX_at_trans*dt+0.5*a_X_p2*dt*dt
    else:
        tw=t_w_stop-t_trans; X_w=X_at_trans+dX_at_trans*tw+0.5*a_X_p2*tw*tw
    if t<t_sph_stop: x_s=x_sph_at_trans+vx_sph_trans*dt+0.5*a_sph_p2*dt*dt
    else:
        ts=t_sph_stop-t_trans; x_s=x_sph_at_trans+vx_sph_trans*ts+0.5*a_sph_p2*ts*ts
    y_s=R; phi_s=phi_at_trans-(x_s-x_sph_at_trans)/R
    return X_w,x_s,y_s,phi_s

ts_grid=np.linspace(0.0,duration,int(duration*fps)+1)
states=np.array([state_at_time(t) for t in ts_grid])
X_w_all=states[:,0]; x_s_all=states[:,1]
x_lo_d=min(X_w_all.min()-0.30,-0.50)
x_hi_d=max(x_s_all.max()+R+0.30, L_wedge+0.50)
y_lo_d=-0.40; y_hi_d=max(H_wedge,R)+0.30
fig_w,fig_h=13.0,3.0; fa=fig_w/fig_h
dx,dy=x_hi_d-x_lo_d,y_hi_d-y_lo_d
if dx/dy<fa:
    e=(fa*dy-dx)/2.0; x_lo,x_hi=x_lo_d-e,x_hi_d+e; y_lo,y_hi=y_lo_d,y_hi_d
else:
    e=(dx/fa-dy)/2.0; x_lo,x_hi=x_lo_d,x_hi_d; y_lo,y_hi=y_lo_d-e,y_hi_d+e

fig=plt.figure(figsize=(fig_w,fig_h),facecolor="#1a1a2e")
ax=fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi); ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(Polygon([(x_lo,y_lo),(x_hi,y_lo),(x_hi,0.0),(x_lo,0.0)],
                    facecolor="#4a4e69",edgecolor="none",zorder=0))
ax.plot([x_lo,x_hi],[0.0,0.0],color="#adb5bd",lw=2.0,zorder=1)
wedge_patch=Polygon([(0,0),(L_wedge,0),(0,H_wedge)],facecolor="#a8dadc",edgecolor="#adb5bd",lw=1.5,zorder=3)
ax.add_patch(wedge_patch)
sphere_patch=Circle((0,0),R,facecolor="#e63946",edgecolor="#adb5bd",lw=1.0,zorder=5)
ax.add_patch(sphere_patch)
spin_marker,=ax.plot([],[],color="#1a1a2e",lw=2.0,zorder=6)

def update(f):
    t=f/fps; X_w,x_s,y_s,phi_s=state_at_time(t)
    wedge_patch.set_xy([(X_w,0.0),(X_w+L_wedge,0.0),(X_w,H_wedge)])
    sphere_patch.set_center((x_s,y_s))
    spin_marker.set_data([x_s,x_s+R*np.cos(phi_s)],[y_s,y_s+R*np.sin(phi_s)])
    return wedge_patch,sphere_patch,spin_marker

n_frames=len(ts_grid)
ani=animation.FuncAnimation(fig,update,frames=n_frames,interval=1000.0/fps,blit=False)
ani.save("video.mp4",writer=animation.FFMpegWriter(fps=fps,bitrate=1800),dpi=120)
plt.close(); print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    for fld, dflt in asdict(WedgeSphereParams()).items():
        parser.add_argument(f"--{fld}", type=float, default=dflt)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="video.mp4")
    args = parser.parse_args()
    p = WedgeSphereParams(**{k: getattr(args, k) for k in asdict(WedgeSphereParams()).keys()})
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
