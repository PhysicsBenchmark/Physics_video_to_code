"""
Chain of Springs Simulation (N=3 masses, fixed)
================================================
Faithfully translated from myphysicslab/src/sims/springs/ChainOfSpringsSim.ts

Physical Layout (horizontal):
    [wall_left=0] ~s0~ [m0] ~s1~ [m1] ~s2~ [m2] ~s3~ [wall_right=4R]

Spring stretch conventions:
    s0 = x0 - 0 - R              (left wall  → mass 0)
    s1 = x1 - x0 - R             (mass 0     → mass 1)
    s2 = x2 - x1 - R             (mass 1     → mass 2)
    s3 = wall_right - x2 - R     (mass 2     → right wall)

Newton's 2nd Law (using same sign convention as DoubleSpringSim):
    dv0/dt = (-k*s0 + k*s1 - b*v0) / m
    dv1/dt = (-k*s1 + k*s2 - b*v1) / m
    dv2/dt = (-k*s2 + k*s3 - b*v2) / m

Equilibrium positions:
    x0_eq = R,  x1_eq = 2R,  x2_eq = 3R,  wall_right = 4R

State vector: [x0, v0, x1, v1, x2, v2]
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis, spring_path


@dataclass
class ChainOfSpringsParams:
    k: float = 6.0    # spring stiffness (N/m)
    m: float = 1.0    # mass of each block (kg)
    b: float = 0.1    # damping coefficient (kg/s)
    R: float = 2.0    # rest length of each spring (m)
    # Initial displacements from equilibrium
    du0: float = 0.3  # mass 0 displacement (m)
    du1: float = -0.2 # mass 1 displacement (m)
    du2: float = 0.5  # mass 2 displacement (m)


def equilibrium(p: ChainOfSpringsParams):
    """Equilibrium positions of the three masses and right wall."""
    x0_eq = p.R
    x1_eq = 2.0 * p.R
    x2_eq = 3.0 * p.R
    wall_right = 4.0 * p.R
    return x0_eq, x1_eq, x2_eq, wall_right


def ode(t: float, y: list, p: ChainOfSpringsParams):
    """
    Equations of motion for the 3-mass chain of springs.

    State: [x0, v0, x1, v1, x2, v2]

    Spring forces (same convention as DoubleSpringSim):
        stretch = (right_attachment - left_attachment) - R
        Force on RIGHT body = -k * stretch  (positive stretch → pulls body left)
        Force on LEFT body  = +k * stretch  (Newton's 3rd)
    """
    x0, v0, x1, v1, x2, v2 = y
    _, _, _, wall_right = equilibrium(p)
    R = p.R

    # Stretches (each = separation - rest_length)
    s0 = x0 - 0.0 - R           # left wall (at x=0) → mass 0
    s1 = x1 - x0 - R             # mass 0 → mass 1
    s2 = x2 - x1 - R             # mass 1 → mass 2
    s3 = wall_right - x2 - R     # mass 2 → right wall

    dv0 = (-p.k * s0 + p.k * s1 - p.b * v0) / p.m
    dv1 = (-p.k * s1 + p.k * s2 - p.b * v1) / p.m
    dv2 = (-p.k * s2 + p.k * s3 - p.b * v2) / p.m

    return [v0, dv0, v1, dv1, v2, dv2]


def simulate(
    params: ChainOfSpringsParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Integrate using RK45. Returns (t, y) with y.shape = (6, N)."""
    x0_eq, x1_eq, x2_eq, _ = equilibrium(params)

    x0_0 = x0_eq + params.du0
    x1_0 = x1_eq + params.du1
    x2_0 = x2_eq + params.du2

    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode,
        (0, duration),
        [x0_0, 0.0, x1_0, 0.0, x2_0, 0.0],
        t_eval=t_eval,
        args=(params,),
        method="RK45",
        rtol=1e-8,
        atol=1e-10,
    )
    return sol.t, sol.y


def energy(t: np.ndarray, y: np.ndarray, p: ChainOfSpringsParams):
    x0, v0, x1, v1, x2, v2 = y
    _, _, _, wall_right = equilibrium(p)
    s0 = x0 - 0.0 - p.R
    s1 = x1 - x0 - p.R
    s2 = x2 - x1 - p.R
    s3 = wall_right - x2 - p.R
    KE = 0.5 * p.m * (v0**2 + v1**2 + v2**2)
    PE = 0.5 * p.k * (s0**2 + s1**2 + s2**2 + s3**2)
    return KE, PE, KE + PE


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: ChainOfSpringsParams,
    output_path: str,
    fps: int = 30,
) -> None:
    """Render: [wall_left] ~~~~ [m0] ~~~~ [m1] ~~~~ [m2] ~~~~ [wall_right]"""
    x0_arr, x1_arr, x2_arr = y[0], y[2], y[4]
    x0_eq, x1_eq, x2_eq, wall_right = equilibrium(params)
    wall_left = 0.0

    pad = 0.4
    xlim = (wall_left - pad, wall_right + pad)
    block_h = 0.35
    bw = 0.3
    track_y = 0.0

    fig, ax = plt.subplots(figsize=(12, 3))
    setup_dark_axis(fig, ax, xlim, (-1.0, 1.0))

    # Track line
    ax.axhline(track_y - block_h / 2, color="#4a4e69", lw=1.5, zorder=1)

    # Walls
    for wx, sign in [(wall_left, 1), (wall_right, -1)]:
        rect_x = wx if sign > 0 else wx - 0.15
        ax.add_patch(
            patches.Rectangle(
                (rect_x, track_y - 0.6), 0.15, 1.2,
                facecolor="#4a4e69", edgecolor="#adb5bd", lw=1, hatch="////",
            )
        )

    # Equilibrium markers
    for xeq in [x0_eq, x1_eq, x2_eq]:
        ax.axvline(xeq, color="#4a4e69", lw=0.8, ls="--", alpha=0.4, zorder=1)

    # Animated springs
    (sp0,) = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
    (sp1,) = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
    (sp2,) = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
    (sp3,) = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)

    # Animated blocks
    block_colors = ["#e63946", "#f4d35e", "#06d6a0"]
    b0 = patches.FancyBboxPatch(
        (x0_eq - bw / 2, track_y - block_h / 2), bw, block_h,
        boxstyle="round,pad=0.02", lw=1.5, edgecolor="white", facecolor=block_colors[0],
    )
    b1 = patches.FancyBboxPatch(
        (x1_eq - bw / 2, track_y - block_h / 2), bw, block_h,
        boxstyle="round,pad=0.02", lw=1.5, edgecolor="white", facecolor=block_colors[1],
    )
    b2 = patches.FancyBboxPatch(
        (x2_eq - bw / 2, track_y - block_h / 2), bw, block_h,
        boxstyle="round,pad=0.02", lw=1.5, edgecolor="white", facecolor=block_colors[2],
    )
    ax.add_patch(b0)
    ax.add_patch(b1)
    ax.add_patch(b2)

    def init():
        for sp in (sp0, sp1, sp2, sp3):
            sp.set_data([], [])
        return sp0, sp1, sp2, sp3

    def update(frame):
        bx0 = x0_arr[frame]
        bx1 = x1_arr[frame]
        bx2 = x2_arr[frame]

        b0.set_x(bx0 - bw / 2)
        b1.set_x(bx1 - bw / 2)
        b2.set_x(bx2 - bw / 2)

        sx, sy = spring_path(wall_left + 0.15, track_y, bx0 - bw / 2, track_y, n_coils=5, coil_radius=0.18)
        sp0.set_data(sx, sy)
        sx, sy = spring_path(bx0 + bw / 2, track_y, bx1 - bw / 2, track_y, n_coils=5, coil_radius=0.18)
        sp1.set_data(sx, sy)
        sx, sy = spring_path(bx1 + bw / 2, track_y, bx2 - bw / 2, track_y, n_coils=5, coil_radius=0.18)
        sp2.set_data(sx, sy)
        sx, sy = spring_path(bx2 + bw / 2, track_y, wall_right, track_y, n_coils=5, coil_radius=0.18)
        sp3.set_data(sx, sy)

        return sp0, sp1, sp2, sp3

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), init_func=init, interval=1000 / fps, blit=False
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: ChainOfSpringsParams, duration: float = 12.0) -> str:
    p = asdict(params)
    x0_eq, x1_eq, x2_eq, wall_right = equilibrium(params)
    return f'''"""
Chain of Springs (N=3 masses) — auto-generated simulation script.
Physics (Newton's 2nd Law for each mass, horizontal, all same k/m/b):
  Stretches:
    s0 = x0 - 0   - R  (left wall -> mass 0)
    s1 = x1 - x0  - R  (mass 0   -> mass 1)
    s2 = x2 - x1  - R  (mass 1   -> mass 2)
    s3 = wr - x2  - R  (mass 2   -> right wall)
  Accelerations:
    dv0/dt = (-k*s0 + k*s1 - b*v0) / m
    dv1/dt = (-k*s1 + k*s2 - b*v1) / m
    dv2/dt = (-k*s2 + k*s3 - b*v2) / m
Layout: [wall=0] ~k~ [m0] ~k~ [m1] ~k~ [m2] ~k~ [wall={wall_right:.2f}]
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

k, m, b = {p["k"]}, {p["m"]}, {p["b"]}
R = {p["R"]}
wall_left, wall_right = 0.0, {wall_right:.4f}
x0_0 = {x0_eq:.4f} + {p["du0"]}   # mass 0 initial position
x1_0 = {x1_eq:.4f} + {p["du1"]}   # mass 1 initial position
x2_0 = {x2_eq:.4f} + {p["du2"]}   # mass 2 initial position
duration = {duration}

def ode(t, y):
    x0, v0, x1, v1, x2, v2 = y
    s0 = x0 - wall_left - R
    s1 = x1 - x0 - R
    s2 = x2 - x1 - R
    s3 = wall_right - x2 - R
    dv0 = (-k*s0 + k*s1 - b*v0) / m
    dv1 = (-k*s1 + k*s2 - b*v1) / m
    dv2 = (-k*s2 + k*s3 - b*v2) / m
    return [v0, dv0, v1, dv1, v2, dv2]

fps = 30
t_eval = np.linspace(0, duration, int(duration * fps) + 1)
sol = solve_ivp(ode, (0, duration), [x0_0, 0.0, x1_0, 0.0, x2_0, 0.0],
                t_eval=t_eval, method="RK45", rtol=1e-8, atol=1e-10)
x0a, x1a, x2a = sol.y[0], sol.y[2], sol.y[4]

bw, bh, ty = 0.3, 0.35, 0.0
fig, ax = plt.subplots(figsize=(12, 3), facecolor="#1a1a2e")
ax.set_facecolor("#16213e")
ax.set_xlim(wall_left - 0.4, wall_right + 0.4)
ax.set_ylim(-1, 1)
ax.set_aspect("equal")
ax.axis("off")
ax.axhline(ty - bh / 2, color="#4a4e69", lw=1.5, zorder=1)

for wx, flip in [(wall_left, False), (wall_right, True)]:
    rx = wx - 0.15 if flip else wx
    ax.add_patch(patches.Rectangle((rx, ty - 0.6), 0.15, 1.2,
        facecolor="#4a4e69", edgecolor="#adb5bd", lw=1, hatch="////"))

def sp_path(xa, xb, n=5, r=0.18):
    t = np.linspace(0, 1, n * 20 + 2)
    margin = 0.08
    env = np.where((t < margin) | (t > 1 - margin), 0,
                   np.sin(n * 2 * np.pi * (t - margin) / (1 - 2 * margin)))
    return xa + t * (xb - xa), ty + r * env

spl = [ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)[0] for _ in range(4)]
bps = []
for xeq, col in [({x0_eq:.4f}, "#e63946"), ({x1_eq:.4f}, "#f4d35e"), ({x2_eq:.4f}, "#06d6a0")]:
    bp = patches.FancyBboxPatch((xeq - bw / 2, ty - bh / 2), bw, bh,
        boxstyle="round,pad=0.02", lw=1.5, edgecolor="white", facecolor=col)
    ax.add_patch(bp)
    bps.append(bp)

def update(f):
    bx = [x0a[f], x1a[f], x2a[f]]
    for i, bp in enumerate(bps):
        bp.set_x(bx[i] - bw / 2)
    anchors = [wall_left + 0.15] + [bx[i] + bw / 2 for i in range(3)]
    ends    = [bx[i] - bw / 2 for i in range(3)] + [wall_right]
    for i, sp in enumerate(spl):
        sp.set_data(*sp_path(anchors[i], ends[i]))
    return spl

ani = animation.FuncAnimation(fig, update, frames=len(sol.t), interval=1000/fps, blit=False)
ani.save("chain_of_springs.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved chain_of_springs.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Chain of Springs (N=3 masses)")
    parser.add_argument("--k",    type=float, default=6.0)
    parser.add_argument("--m",    type=float, default=1.0)
    parser.add_argument("--b",    type=float, default=0.1)
    parser.add_argument("--R",    type=float, default=2.0)
    parser.add_argument("--du0",  type=float, default=0.3)
    parser.add_argument("--du1",  type=float, default=-0.2)
    parser.add_argument("--du2",  type=float, default=0.5)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output",   type=str,   default="chain_of_springs.mp4")
    args = parser.parse_args()
    p = ChainOfSpringsParams(
        k=args.k, m=args.m, b=args.b, R=args.R,
        du0=args.du0, du1=args.du1, du2=args.du2,
    )
    print(f"Simulating chain of springs: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
