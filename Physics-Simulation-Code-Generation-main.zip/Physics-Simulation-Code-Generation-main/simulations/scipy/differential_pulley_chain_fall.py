"""
Differential Pulley (Weston Block) — chain falls through; load rises slowly.
=============================================================================
Two upper pulleys of radii R (large) and r (small, with r < R) share a
common axle (a "differential" or "Weston" compound pulley).  A continuous
chain wraps over both: one branch comes off the LARGE pulley, drops down,
wraps under a single lower (movable) block, and goes back up over the
SMALL pulley.  The free end of the chain hangs from the LARGE pulley with
an effort weight m_eff attached.  The lower pulley supports the load M_load.

Kinematics (single-DOF system, generalised coordinate φ = upper-axle angle).
When the upper compound rotates by dφ:
  • Chain payed out by the LARGE pulley:  R dφ.
  • Chain taken up by the SMALL pulley:    r dφ.
  • Net chain delivered into the lower-pulley loop:  (R − r) dφ.
  • The lower pulley is supported by TWO segments, so the load rises by
        dh = (R − r) dφ / 2.
  • The effort weight falls by  R dφ.
  • Velocity ratio (effort / load):  2R / (R − r) — the *ideal* mechanical
    advantage MA = W/F = 2R / (R − r), which can be very large when R ≈ r.

Lagrangian dynamics (single DOF φ).
  Effective inertia about φ:
      I_eff = I_axle  +  (M_load + m_lp) ((R−r)/2)²  +  m_eff R².
  Generalised force from gravity + effort (positive when the load rises):
      Q_φ = m_eff g R − (M_load + m_lp) g (R − r)/2.
  Friction is modelled as a static-Coulomb torque + a viscous bearing term:
      τ_fric = − τ_f · tanh(α ω) − c_drag · ω.
  Equation of motion:
      I_eff · ω̇  =  Q_φ + τ_fric,        ω = dφ/dt.

State vector: y = [φ, ω].
"""

from __future__ import annotations
import math
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis


@dataclass
class DifferentialPulleyChainFallParams:
    R: float = 0.10               # large upper-pulley radius (m)
    r_over_R: float = 0.85        # ratio r / R (r < R)
    M_load: float = 20.0          # load mass (kg)
    m_lp: float = 0.50            # lower-pulley + hanging-block mass (kg)
    overload_factor: float = 1.8  # m_eff·R / [(M_load+m_lp)·(R−r)/2]; >1 ⇒ load rises
    I_axle: float = 0.012         # upper-axle moment of inertia (kg·m²)
    omega_target: float = 1.0     # target terminal upper-axle ω (rad/s); fixes c_drag
    tau_friction: float = 0.04    # Coulomb-friction torque magnitude at the axle (N·m)
    alpha_tanh: float = 30.0      # tanh sharpness for sgn(ω) regularisation
    g: float = 9.81
    phi0: float = 0.0
    omega0: float = 0.0
    # Auto-derived in __post_init__:
    r: float = 0.0
    m_eff: float = 0.0
    c_drag: float = 0.0

    def __post_init__(self):
        if self.r <= 0.0:
            self.r = self.r_over_R * self.R
        if self.m_eff <= 0.0:
            self.m_eff = self.overload_factor * (self.M_load + self.m_lp) \
                         * (self.R - self.r) / (2.0 * self.R)
        if self.c_drag <= 0.0:
            wt_torque  = (self.M_load + self.m_lp) * self.g * (self.R - self.r) / 2.0
            eff_torque = self.m_eff * self.g * self.R
            net_torque = max(eff_torque - wt_torque, 0.05)
            denom      = max(self.omega_target, 1e-3)
            self.c_drag = max(0.05, (net_torque - self.tau_friction) / denom)


def ode(t: float, y: list, p: DifferentialPulleyChainFallParams):
    phi, omega = y
    Q_phi = p.m_eff * p.g * p.R - (p.M_load + p.m_lp) * p.g * (p.R - p.r) / 2.0
    tau_f = -p.tau_friction * np.tanh(p.alpha_tanh * omega) - p.c_drag * omega
    I_eff = (p.I_axle
             + (p.M_load + p.m_lp) * ((p.R - p.r) / 2.0) ** 2
             + p.m_eff * p.R * p.R)
    domega = (Q_phi + tau_f) / I_eff
    return [omega, domega]


def simulate(params: DifferentialPulleyChainFallParams,
             duration: float = 12.0, fps: int = 30):
    t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode, (0.0, duration), [params.phi0, params.omega0],
        args=(params,), t_eval=t_eval,
        method="RK45", rtol=1e-9, atol=1e-11,
    )
    return sol.t, sol.y


def render_video(t: np.ndarray, y: np.ndarray,
                 params: DifferentialPulleyChainFallParams,
                 output_path: str, fps: int = 30) -> None:
    phi, omega = y[0], y[1]
    R = params.R
    r = params.r

    # ── Visual layout ──────────────────────────────────────────────────────
    y_top = 2.5
    ceiling_y = y_top + 0.30
    x_large = -R - 0.06          # large-pulley centre (left)
    x_small = +r + 0.06          # small-pulley centre (right)
    y_lower_init = 1.20
    r_lp = 0.06                  # lower pulley radius
    load_w = 0.32; load_h = 0.30
    eff_w = 0.16;  eff_h = 0.16
    y_eff_init = y_top - 0.50    # initial effort-weight top

    h_load = (R - r) / 2.0 * phi
    z_eff  = -R * phi             # effort vertical displacement (negative = downward)
    y_lower_t = y_lower_init + h_load
    y_eff_top_t = y_eff_init + z_eff
    load_top_t  = y_lower_t - r_lp - 0.05
    load_bot_t  = load_top_t - load_h
    eff_bot_t   = y_eff_top_t - eff_h

    pad_x = R + 0.30
    x_min = x_large - R - pad_x
    x_max = x_small + r + pad_x
    y_min = float(min(np.min(load_bot_t), np.min(eff_bot_t))) - 0.20
    y_max = ceiling_y + 0.50

    fig, ax = plt.subplots(figsize=(7, 9))
    setup_dark_axis(
        fig, ax,
        xlim=(x_min, x_max),
        ylim=(y_min, y_max),
    )

    # ── Static structure ───────────────────────────────────────────────────
    # Ceiling
    ax.axhline(ceiling_y, color="#4a4e69", lw=2.5, zorder=1)
    # Mounting brackets
    ax.plot([x_large, x_large], [y_top, ceiling_y], color="#4a4e69", lw=2.5, zorder=1)
    ax.plot([x_small, x_small], [y_top, ceiling_y], color="#4a4e69", lw=2.5, zorder=1)
    # Common axle line
    ax.plot([x_large, x_small], [y_top, y_top], color="#adb5bd", lw=2.5, zorder=2)

    # Upper compound pulleys (rim circles)
    large_pulley = patches.Circle((x_large, y_top), R, facecolor="none",
                                  edgecolor="#a8dadc", lw=2.0, zorder=3)
    small_pulley = patches.Circle((x_small, y_top), r, facecolor="none",
                                  edgecolor="#a8dadc", lw=2.0, zorder=3)
    ax.add_patch(large_pulley); ax.add_patch(small_pulley)

    # Tangent points (chain endpoints on the upper pulleys — fixed in world frame)
    eff_top_x   = x_large - R                       # effort rope hangs from far-left of large
    chain_L_top = (x_large + R, y_top)              # right rim of large → down to lower-pulley left
    chain_R_top = (x_small - r, y_top)              # left rim of small → down to lower-pulley right

    # ── Animated artists ───────────────────────────────────────────────────
    spoke_large, = ax.plot([], [], "-", color="#e63946", lw=2.0, zorder=4)
    spoke_small, = ax.plot([], [], "-", color="#e63946", lw=2.0, zorder=4)
    spoke_lower, = ax.plot([], [], "-", color="#e63946", lw=1.5, zorder=4)

    lower_pulley = patches.Circle((0, y_lower_init), r_lp, facecolor="none",
                                  edgecolor="#a8dadc", lw=2.0, zorder=3)
    ax.add_patch(lower_pulley)

    chain_left,  = ax.plot([], [], "-", color="#ffd166", lw=2.2, zorder=2)
    chain_right, = ax.plot([], [], "-", color="#ffd166", lw=2.2, zorder=2)
    chain_under_x = np.linspace(-r_lp, +r_lp, 30)
    chain_under,  = ax.plot([], [], "-", color="#ffd166", lw=2.2, zorder=2)

    eff_rope, = ax.plot([], [], "-", color="#ffd166", lw=2.0, zorder=2)
    eff_block = patches.FancyBboxPatch(
        (eff_top_x - eff_w / 2, 0), eff_w, eff_h,
        boxstyle="round,pad=0.005", facecolor="#f4a261",
        edgecolor="white", lw=1.2, zorder=4,
    )
    ax.add_patch(eff_block)

    load_chain_top, = ax.plot([], [], "-", color="#ffd166", lw=2.0, zorder=2)
    load_block = patches.FancyBboxPatch(
        (-load_w / 2, 0), load_w, load_h,
        boxstyle="round,pad=0.005", facecolor="#e63946",
        edgecolor="white", lw=1.5, zorder=4,
    )
    ax.add_patch(load_block)

    def update(frame: int):
        ph = float(phi[frame])
        om = float(omega[frame])
        # Upper compound spokes (both rotate at φ)
        sx_l = x_large + R * math.cos(ph); sy_l = y_top + R * math.sin(ph)
        sx_s = x_small + r * math.cos(ph); sy_s = y_top + r * math.sin(ph)
        spoke_large.set_data([x_large, sx_l], [y_top, sy_l])
        spoke_small.set_data([x_small, sx_s], [y_top, sy_s])

        # Lower-pulley pose
        y_lp = y_lower_init + (R - r) / 2.0 * ph
        lower_pulley.center = (0, y_lp)
        # Lower pulley rotates opposite to upper compound: ω_lp = −(R+r)/(2·r_lp)·ω
        ph_lp = -ph * (R + r) / (2.0 * r_lp)
        spoke_lower.set_data(
            [0, r_lp * math.cos(ph_lp)],
            [y_lp, y_lp + r_lp * math.sin(ph_lp)],
        )

        # Chain segments (upper-pulley tangent points → lower-pulley top sides)
        chain_left.set_data ([chain_L_top[0], -r_lp], [chain_L_top[1], y_lp])
        chain_right.set_data([chain_R_top[0], +r_lp], [chain_R_top[1], y_lp])
        # Half-circle chain wrap under the lower pulley
        theta = np.linspace(math.pi, 2.0 * math.pi, 30)
        chain_under.set_data(r_lp * np.cos(theta), y_lp + r_lp * np.sin(theta))

        # Effort weight + rope
        y_eff_top = y_eff_init + z_eff[frame]
        eff_rope.set_data([eff_top_x, eff_top_x], [y_top, y_eff_top])
        eff_block.set_y(y_eff_top - eff_h)

        # Load block + chain
        load_chain_top.set_data([0, 0], [y_lp - r_lp, y_lp - r_lp - 0.05])
        load_block.set_y(y_lp - r_lp - 0.05 - load_h)

        return [spoke_large, spoke_small, spoke_lower, lower_pulley,
                chain_left, chain_right, chain_under, eff_rope, eff_block,
                load_chain_top, load_block]

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), interval=1000 / fps, blit=False,
    )
    ani.save(output_path,
             writer=animation.FFMpegWriter(fps=fps, bitrate=1800),
             dpi=120)
    plt.close(fig)


def make_standalone_script(params: DifferentialPulleyChainFallParams,
                           duration: float = 12.0) -> str:
    p = asdict(params)
    p["r"]      = params.r
    p["m_eff"]  = params.m_eff
    p["c_drag"] = params.c_drag
    return f'''"""
Differential Pulley (Weston Block) — auto-generated standalone simulation.

Single-DOF Lagrangian:
  I_eff omega_dot = Q_phi - tau_friction · tanh(alpha · omega) - c_drag · omega
  Q_phi  = m_eff·g·R − (M_load+m_lp)·g·(R−r)/2
  I_eff  = I_axle + (M_load+m_lp)·((R−r)/2)² + m_eff·R²
  Constraint: load rises by dh = (R−r)/2 · dphi;  effort falls by R · dphi.
  Mechanical advantage: MA = 2R / (R − r).
"""
import math
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

# ── Parameters ──────────────────────────────────────────────────────────────
R           = {p["R"]}
r           = {p["r"]}
M_load      = {p["M_load"]}
m_lp        = {p["m_lp"]}
m_eff       = {p["m_eff"]}
I_axle      = {p["I_axle"]}
tau_friction= {p["tau_friction"]}
alpha_tanh  = {p["alpha_tanh"]}
c_drag      = {p["c_drag"]}
g           = {p["g"]}
phi0        = {p["phi0"]}
omega0      = {p["omega0"]}
duration    = {duration}
fps         = 30
I_eff = I_axle + (M_load + m_lp) * ((R - r) / 2.0) ** 2 + m_eff * R * R

def ode(t, y):
    phi, omega = y
    Q_phi = m_eff * g * R - (M_load + m_lp) * g * (R - r) / 2.0
    tau_f = -tau_friction * np.tanh(alpha_tanh * omega) - c_drag * omega
    return [omega, (Q_phi + tau_f) / I_eff]

t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
sol = solve_ivp(ode, (0.0, duration), [phi0, omega0],
                t_eval=t_eval, method="RK45", rtol=1e-9, atol=1e-11)
t = sol.t; phi = sol.y[0]; omega = sol.y[1]

# ── Visual layout (mirrors render_video) ────────────────────────────────────
y_top = 2.5; ceiling_y = y_top + 0.30
x_large = -R - 0.06; x_small = +r + 0.06
y_lower_init = 1.20; r_lp = 0.06
load_w = 0.32; load_h = 0.30
eff_w  = 0.16; eff_h  = 0.16
y_eff_init = y_top - 0.50
h_load   = (R - r) / 2.0 * phi
z_eff    = -R * phi
y_lower_t = y_lower_init + h_load
y_eff_top_t = y_eff_init + z_eff
load_top_t = y_lower_t - r_lp - 0.05
load_bot_t = load_top_t - load_h
eff_bot_t  = y_eff_top_t - eff_h
pad_x = R + 0.30
x_min = x_large - R - pad_x
x_max = x_small + r + pad_x
y_min = float(min(np.min(load_bot_t), np.min(eff_bot_t))) - 0.20
y_max = ceiling_y + 0.50

fig, ax = plt.subplots(figsize=(7, 9), facecolor="#1a1a2e")
ax.set_facecolor("#16213e")
ax.set_xlim(x_min, x_max); ax.set_ylim(y_min, y_max)
ax.set_aspect("equal"); ax.axis("off")

ax.axhline(ceiling_y, color="#4a4e69", lw=2.5, zorder=1)
ax.plot([x_large, x_large], [y_top, ceiling_y], color="#4a4e69", lw=2.5, zorder=1)
ax.plot([x_small, x_small], [y_top, ceiling_y], color="#4a4e69", lw=2.5, zorder=1)
ax.plot([x_large, x_small], [y_top, y_top], color="#adb5bd", lw=2.5, zorder=2)

ax.add_patch(patches.Circle((x_large, y_top), R, facecolor="none",
                             edgecolor="#a8dadc", lw=2.0, zorder=3))
ax.add_patch(patches.Circle((x_small, y_top), r, facecolor="none",
                             edgecolor="#a8dadc", lw=2.0, zorder=3))

eff_top_x   = x_large - R
chain_L_top = (x_large + R, y_top)
chain_R_top = (x_small - r, y_top)

spoke_large, = ax.plot([], [], "-", color="#e63946", lw=2.0, zorder=4)
spoke_small, = ax.plot([], [], "-", color="#e63946", lw=2.0, zorder=4)
spoke_lower, = ax.plot([], [], "-", color="#e63946", lw=1.5, zorder=4)
lower_pulley = patches.Circle((0, y_lower_init), r_lp, facecolor="none",
                               edgecolor="#a8dadc", lw=2.0, zorder=3)
ax.add_patch(lower_pulley)
chain_left,  = ax.plot([], [], "-", color="#ffd166", lw=2.2, zorder=2)
chain_right, = ax.plot([], [], "-", color="#ffd166", lw=2.2, zorder=2)
chain_under, = ax.plot([], [], "-", color="#ffd166", lw=2.2, zorder=2)
eff_rope,    = ax.plot([], [], "-", color="#ffd166", lw=2.0, zorder=2)
eff_block = patches.FancyBboxPatch((eff_top_x - eff_w/2, 0), eff_w, eff_h,
    boxstyle="round,pad=0.005", facecolor="#f4a261", edgecolor="white", lw=1.2, zorder=4)
ax.add_patch(eff_block)
load_chain_top, = ax.plot([], [], "-", color="#ffd166", lw=2.0, zorder=2)
load_block = patches.FancyBboxPatch((-load_w/2, 0), load_w, load_h,
    boxstyle="round,pad=0.005", facecolor="#e63946", edgecolor="white", lw=1.5, zorder=4)
ax.add_patch(load_block)

def update(frame):
    ph = float(phi[frame])
    spoke_large.set_data([x_large, x_large + R * math.cos(ph)],
                         [y_top,  y_top   + R * math.sin(ph)])
    spoke_small.set_data([x_small, x_small + r * math.cos(ph)],
                         [y_top,  y_top   + r * math.sin(ph)])
    y_lp = y_lower_init + (R - r) / 2.0 * ph
    lower_pulley.center = (0, y_lp)
    ph_lp = -ph * (R + r) / (2.0 * r_lp)
    spoke_lower.set_data([0, r_lp * math.cos(ph_lp)],
                         [y_lp, y_lp + r_lp * math.sin(ph_lp)])
    chain_left.set_data([chain_L_top[0], -r_lp], [chain_L_top[1], y_lp])
    chain_right.set_data([chain_R_top[0], +r_lp], [chain_R_top[1], y_lp])
    theta = np.linspace(math.pi, 2.0 * math.pi, 30)
    chain_under.set_data(r_lp * np.cos(theta), y_lp + r_lp * np.sin(theta))
    y_eff_top = y_eff_init + z_eff[frame]
    eff_rope.set_data([eff_top_x, eff_top_x], [y_top, y_eff_top])
    eff_block.set_y(y_eff_top - eff_h)
    load_chain_top.set_data([0, 0], [y_lp - r_lp, y_lp - r_lp - 0.05])
    load_block.set_y(y_lp - r_lp - 0.05 - load_h)
    return [spoke_large, spoke_small, spoke_lower, lower_pulley,
            chain_left, chain_right, chain_under, eff_rope, eff_block,
            load_chain_top, load_block]

ani = animation.FuncAnimation(fig, update, frames=len(t),
                              interval=1000 / fps, blit=False)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close(); print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Differential Pulley (Weston block)")
    ap.add_argument("--R",         type=float, default=0.10)
    ap.add_argument("--r_over_R",  type=float, default=0.85)
    ap.add_argument("--M_load",    type=float, default=20.0)
    ap.add_argument("--m_lp",      type=float, default=0.50)
    ap.add_argument("--overload_factor", type=float, default=1.8)
    ap.add_argument("--omega_target",    type=float, default=1.0)
    ap.add_argument("--duration", type=float, default=12.0)
    ap.add_argument("--output",   type=str,   default="differential_pulley_chain_fall.mp4")
    args = ap.parse_args()

    p = DifferentialPulleyChainFallParams(
        R=args.R, r_over_R=args.r_over_R, M_load=args.M_load, m_lp=args.m_lp,
        overload_factor=args.overload_factor, omega_target=args.omega_target,
    )
    print(f"R={p.R:.3f} r={p.r:.3f} (r/R={p.r/p.R:.3f}) MA={2*p.R/(p.R-p.r):.2f}")
    print(f"M_load={p.M_load:.2f} kg  m_eff={p.m_eff:.3f} kg  c_drag={p.c_drag:.3f}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
