"""
Moveable Double Pendulum Simulation
======================================
Faithfully translated from myphysicslab/src/sims/pendulum/MoveableDoublePendulumSim.ts

Physical Law: Double pendulum hanging from a sinusoidally-driven anchor point.
The anchor moves vertically only (no horizontal driving):
    y_anchor(t) = A_drive * sin(omega_drive * t)
    ddy0 = -A_drive * omega_drive^2 * sin(omega_drive * t)
    ddx0 = 0

State vector: [theta1, omega1, theta2, omega2]
(Anchor is analytically driven — not an ODE state variable.)

Equations of motion (verbatim from MoveableDoublePendulumSim.ts evaluate(),
using b = b2 = damping, ddx0 = 0):

    ddth1 = -[ 2*b*dth1
               + ddx0*L1*(2*m1+m2)*cos(th1)
               - ddx0*L1*m2*cos(th1-2*th2)
               + 2*ddy0*L1*m1*sin(th1) + 2*g*L1*m1*sin(th1)
               + ddy0*L1*m2*sin(th1) + g*L1*m2*sin(th1)
               + ddy0*L1*m2*sin(th1-2*th2) + g*L1*m2*sin(th1-2*th2)
               + 2*dth2^2*L1*L2*m2*sin(th1-th2)
               + dth1^2*L1^2*m2*sin(2*(th1-th2))
             ] / (L1^2 * (2*m1 + m2 - m2*cos(2*(th1-th2))))

    ddth2 = -[ 2*b*dth1*L2*m2*cos(th1-th2)
               - b*(dth1-dth2)*L1*m2*cos(2*(th1-th2))
               + L1*(2*b*dth1*m1 - 2*b*dth2*m1 + b*dth1*m2 - b*dth2*m2
               + ddx0*L2*m2*(m1+m2)*cos(2*th1-th2)
               - ddx0*L2*m2*(m1+m2)*cos(th2)
               + 2*dth1^2*L1*L2*(m1+m2)*m2*sin(th1-th2)
               + dth2^2*L2^2*m2^2*sin(2*(th1-th2))
               + ddy0*L2*m2*(m1+m2)*sin(2*th1-th2)
               + g*L2*m2*(m1+m2)*sin(2*th1-th2)
               - ddy0*L2*m2*(m1+m2)*sin(th2)
               - g*L2*m2*(m1+m2)*sin(th2))
             ] / (L1*L2^2*m2*(-2*m1 - m2 + m2*cos(2*(th1-th2))))
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from dataclasses import dataclass, asdict
import sys, os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from .draw_utils import setup_dark_axis


@dataclass
class MoveableDoublePendulumParams:
    L1: float          = 1.0    # length of rod 1 (m)
    L2: float          = 1.0    # length of rod 2 (m)
    m1: float          = 1.5    # mass of bob 1 (kg)
    m2: float          = 1.0    # mass of bob 2 (kg)
    g: float           = 9.8    # gravitational acceleration (m/s²)
    b: float           = 0.2    # damping coefficient
    theta1_0: float    = 0.5    # initial angle of rod 1 (rad)
    omega1_0: float    = 0.0    # initial angular velocity of rod 1 (rad/s)
    theta2_0: float    = 0.3    # initial angle of rod 2 (rad)
    omega2_0: float    = 0.0    # initial angular velocity of rod 2 (rad/s)
    A_drive: float     = 0.3    # amplitude of anchor vertical oscillation (m)
    omega_drive: float = 2.5    # angular frequency of anchor oscillation (rad/s)


def ode(t: float, y: list, p: MoveableDoublePendulumParams):
    """
    Exact translation of MoveableDoublePendulumSim.ts evaluate() for
    purely vertical sinusoidal driving (ddx0=0):

    change[W1P] = -( 2*b*dth1
        + ddx0*L1*(2*m1+m2)*cos(th1) - ddx0*L1*m2*cos(th1-2*th2)
        + 2*ddy0*L1*m1*sin(th1) + 2*g*L1*m1*sin(th1)
        + ddy0*L1*m2*sin(th1) + g*L1*m2*sin(th1)
        + ddy0*L1*m2*sin(th1-2*th2) + g*L1*m2*sin(th1-2*th2)
        + 2*dth2^2*L1*L2*m2*sin(th1-th2)
        + dth1^2*L1^2*m2*sin(2*(th1-th2))
      ) / (L1^2*(2*m1 + m2 - m2*cos(2*(th1-th2))))

    change[W2P] = -( 2*b*dth1*L2*m2*cos(th1-th2)
        - b*(dth1-dth2)*L1*m2*cos(2*(th1-th2))
        + L1*(2*b*(dth1-dth2)*m1 + b*(dth1-dth2)*m2
        + ddx0*L2*m2*(m1+m2)*cos(2*th1-th2)
        - ddx0*L2*m2*(m1+m2)*cos(th2)
        + 2*dth1^2*L1*L2*(m1+m2)*m2*sin(th1-th2)
        + dth2^2*L2^2*m2^2*sin(2*(th1-th2))
        + ddy0*L2*m2*(m1+m2)*sin(2*th1-th2)
        + g*L2*m2*(m1+m2)*sin(2*th1-th2)
        - ddy0*L2*m2*(m1+m2)*sin(th2)
        - g*L2*m2*(m1+m2)*sin(th2))
      ) / (L1*L2^2*m2*(-2*m1 - m2 + m2*cos(2*(th1-th2))))
    """
    th1, dth1, th2, dth2 = y
    L1, L2, m1, m2, g, b = p.L1, p.L2, p.m1, p.m2, p.g, p.b

    # Anchor accelerations (vertical driving only)
    ddx0 = 0.0
    ddy0 = -p.A_drive * p.omega_drive**2 * np.sin(p.omega_drive * t)

    diff = th1 - th2

    # --- ddth1 ---
    denom1 = L1 * L1 * (2*m1 + m2 - m2*np.cos(2*diff))

    numer1 = (2*b*dth1
              + ddx0*L1*(2*m1 + m2)*np.cos(th1)
              - ddx0*L1*m2*np.cos(th1 - 2*th2)
              + 2*ddy0*L1*m1*np.sin(th1) + 2*g*L1*m1*np.sin(th1)
              + ddy0*L1*m2*np.sin(th1) + g*L1*m2*np.sin(th1)
              + ddy0*L1*m2*np.sin(th1 - 2*th2) + g*L1*m2*np.sin(th1 - 2*th2)
              + 2*dth2*dth2*L1*L2*m2*np.sin(diff)
              + dth1*dth1*L1*L1*m2*np.sin(2*diff))
    ddth1 = -numer1 / denom1

    # --- ddth2 ---
    # denominator from TS: L1*L2^2*m2*(-2*m1 - m2 + m2*cos(2*(th1-th2)))
    denom2 = L1*L2*L2*m2*(-2*m1 - m2 + m2*np.cos(2*diff))

    numer2 = (2*b*dth1*L2*m2*np.cos(diff)
              - b*(dth1 - dth2)*L1*m2*np.cos(2*diff)
              + L1*(2*b*dth1*m1 - 2*b*dth2*m1 + b*dth1*m2 - b*dth2*m2
                    + ddx0*L2*m2*(m1 + m2)*np.cos(2*th1 - th2)
                    - ddx0*L2*m2*(m1 + m2)*np.cos(th2)
                    + 2*dth1*dth1*L1*L2*m1*m2*np.sin(diff)
                    + 2*dth1*dth1*L1*L2*m2*m2*np.sin(diff)
                    + dth2*dth2*L2*L2*m2*m2*np.sin(2*diff)
                    + ddy0*L2*m1*m2*np.sin(2*th1 - th2)
                    + g*L2*m1*m2*np.sin(2*th1 - th2)
                    + ddy0*L2*m2*m2*np.sin(2*th1 - th2)
                    + g*L2*m2*m2*np.sin(2*th1 - th2)
                    - ddy0*L2*m1*m2*np.sin(th2)
                    - g*L2*m1*m2*np.sin(th2)
                    - ddy0*L2*m2*m2*np.sin(th2)
                    - g*L2*m2*m2*np.sin(th2)))
    ddth2 = -numer2 / denom2

    return [dth1, ddth1, dth2, ddth2]


def simulate(
    params: MoveableDoublePendulumParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Integrate using RK45. Returns (t, y) with y.shape = (4, N)."""
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode,
        (0, duration),
        [params.theta1_0, params.omega1_0, params.theta2_0, params.omega2_0],
        t_eval=t_eval,
        args=(params,),
        method="RK45",
        rtol=1e-8,
        atol=1e-10,
    )
    return sol.t, sol.y


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: MoveableDoublePendulumParams,
    output_path: str,
    fps: int = 30,
    trail_len: int = 150,
) -> None:
    """Render animated moveable double pendulum. Anchor oscillates vertically."""
    th1, _, th2, _ = y
    L1, L2 = params.L1, params.L2

    # Anchor position over time
    anchor_y = params.A_drive * np.sin(params.omega_drive * t)
    anchor_x = np.zeros_like(anchor_y)

    # Bob positions
    x1 = anchor_x + L1 * np.sin(th1)
    y1 = anchor_y - L1 * np.cos(th1)
    x2 = x1 + L2 * np.sin(th2)
    y2 = y1 - L2 * np.cos(th2)

    total_L = L1 + L2
    pad = (total_L + params.A_drive) * 0.2
    lim = total_L + params.A_drive + pad
    xlim = (-lim, lim)
    ylim = (-lim * 1.1, lim * 0.4)

    fig, ax = plt.subplots(figsize=(8, 6))
    setup_dark_axis(fig, ax, xlim, ylim)

    # World-origin crosshair
    ax.plot([0], [0], "+", color="#ffffff", ms=8, alpha=0.4, zorder=2)

    (anchor_dot,) = ax.plot([], [], "s", color="#f4d35e", ms=10, zorder=5)
    (rod1,)       = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
    (rod2,)       = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
    (bob1,)       = ax.plot([], [], "o", color="#f4d35e", ms=11, zorder=4)
    (bob2,)       = ax.plot([], [], "o", color="#e63946", ms=11, zorder=4)
    (trail,)      = ax.plot([], [], "-", color="#e63946", alpha=0.4, lw=1.0, zorder=2)

    tx: list = []
    ty: list = []

    def init():
        for obj in [anchor_dot, rod1, rod2, bob1, bob2, trail]:
            obj.set_data([], [])
        return anchor_dot, rod1, rod2, bob1, bob2, trail

    def update(frame):
        ax_x = anchor_x[frame]
        ay_y = anchor_y[frame]

        anchor_dot.set_data([ax_x], [ay_y])
        rod1.set_data([ax_x, x1[frame]], [ay_y, y1[frame]])
        rod2.set_data([x1[frame], x2[frame]], [y1[frame], y2[frame]])
        bob1.set_data([x1[frame]], [y1[frame]])
        bob2.set_data([x2[frame]], [y2[frame]])

        tx.append(x2[frame])
        ty.append(y2[frame])
        if len(tx) > trail_len:
            tx.pop(0)
            ty.pop(0)
        trail.set_data(tx, ty)
        return anchor_dot, rod1, rod2, bob1, bob2, trail

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), init_func=init, interval=1000 / fps, blit=True
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=100)
    plt.close(fig)


def make_standalone_script(params: MoveableDoublePendulumParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""
Moveable Double Pendulum — auto-generated simulation script.
Physics: Double pendulum with sinusoidally driven anchor (vertical only).
    ddy0 = -A_drive * omega_drive^2 * sin(omega_drive * t)
    ddx0 = 0
ODEs verbatim from MoveableDoublePendulumSim.ts evaluate().
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation

L1, L2       = {p["L1"]}, {p["L2"]}
m1, m2       = {p["m1"]}, {p["m2"]}
g            = {p["g"]}
b            = {p["b"]}
theta1_0     = {p["theta1_0"]:.6f}
omega1_0     = {p["omega1_0"]:.6f}
theta2_0     = {p["theta2_0"]:.6f}
omega2_0     = {p["omega2_0"]:.6f}
A_drive      = {p["A_drive"]}
omega_drive  = {p["omega_drive"]}
duration     = {duration}

def ode(t, y):
    th1, dth1, th2, dth2 = y
    ddx0 = 0.0
    ddy0 = -A_drive * omega_drive**2 * np.sin(omega_drive * t)
    diff = th1 - th2
    denom1 = L1*L1*(2*m1 + m2 - m2*np.cos(2*diff))
    numer1 = (2*b*dth1
              + 2*ddy0*L1*m1*np.sin(th1) + 2*g*L1*m1*np.sin(th1)
              + ddy0*L1*m2*np.sin(th1) + g*L1*m2*np.sin(th1)
              + ddy0*L1*m2*np.sin(th1-2*th2) + g*L1*m2*np.sin(th1-2*th2)
              + 2*dth2**2*L1*L2*m2*np.sin(diff)
              + dth1**2*L1*L1*m2*np.sin(2*diff))
    ddth1 = -numer1 / denom1
    denom2 = L1*L2*L2*m2*(-2*m1 - m2 + m2*np.cos(2*diff))
    numer2 = (2*b*dth1*L2*m2*np.cos(diff)
              - b*(dth1-dth2)*L1*m2*np.cos(2*diff)
              + L1*(2*b*dth1*m1 - 2*b*dth2*m1 + b*dth1*m2 - b*dth2*m2
                    + 2*dth1**2*L1*L2*(m1+m2)*m2*np.sin(diff)
                    + dth2**2*L2*L2*m2*m2*np.sin(2*diff)
                    + (ddy0+g)*L2*m2*(m1+m2)*np.sin(2*th1-th2)
                    - (ddy0+g)*L2*m2*(m1+m2)*np.sin(th2)))
    ddth2 = -numer2 / denom2
    return [dth1, ddth1, dth2, ddth2]

fps    = 30
t_eval = np.linspace(0, duration, int(duration*fps)+1)
sol    = solve_ivp(ode, (0, duration),
                   [theta1_0, omega1_0, theta2_0, omega2_0],
                   t_eval=t_eval, method="RK45", rtol=1e-8, atol=1e-10)
th1, th2   = sol.y[0], sol.y[2]
anchor_y   = A_drive * np.sin(omega_drive * sol.t)
x1 = np.sin(th1)*L1;       y1 = anchor_y - np.cos(th1)*L1
x2 = x1+np.sin(th2)*L2;    y2 = y1-np.cos(th2)*L2

lim = (L1+L2+A_drive)*1.2
fig, ax = plt.subplots(figsize=(8,6), facecolor="#1a1a2e")
ax.set_facecolor("#16213e"); ax.set_xlim(-lim,lim); ax.set_ylim(-lim*1.1,lim*0.4)
ax.set_aspect("equal"); ax.axis("off")
ax.plot([0],[0],"+",color="white",ms=8,alpha=0.4,zorder=2)
anchor_dot, = ax.plot([],[],"s",color="#f4d35e",ms=10,zorder=5)
rod1,  = ax.plot([],[],"-",color="#a8dadc",lw=2.5,zorder=3)
rod2,  = ax.plot([],[],"-",color="#a8dadc",lw=2.5,zorder=3)
bob1,  = ax.plot([],[],"o",color="#f4d35e",ms=11,zorder=4)
bob2,  = ax.plot([],[],"o",color="#e63946",ms=11,zorder=4)
trail, = ax.plot([],[],"-",color="#e63946",alpha=0.4,lw=1.0,zorder=2)
tx, ty = [], []

def update(f):
    ay = anchor_y[f]
    anchor_dot.set_data([0],[ay])
    rod1.set_data([0,x1[f]],[ay,y1[f]])
    rod2.set_data([x1[f],x2[f]],[y1[f],y2[f]])
    bob1.set_data([x1[f]],[y1[f]]); bob2.set_data([x2[f]],[y2[f]])
    tx.append(x2[f]); ty.append(y2[f])
    if len(tx)>150: tx.pop(0); ty.pop(0)
    trail.set_data(tx,ty)
    return anchor_dot,rod1,rod2,bob1,bob2,trail

ani = animation.FuncAnimation(fig, update, frames=len(sol.t), interval=1000/fps, blit=True)
ani.save("moveable_double_pendulum.mp4", writer=animation.FFMpegWriter(fps=fps,bitrate=1800), dpi=100)
plt.close(); print("Saved moveable_double_pendulum.mp4")
'''


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Moveable Double Pendulum Simulation")
    parser.add_argument("--L1",          type=float, default=1.0)
    parser.add_argument("--L2",          type=float, default=1.0)
    parser.add_argument("--m1",          type=float, default=1.5)
    parser.add_argument("--m2",          type=float, default=1.0)
    parser.add_argument("--g",           type=float, default=9.8)
    parser.add_argument("--b",           type=float, default=0.2)
    parser.add_argument("--theta1_0",    type=float, default=0.5)
    parser.add_argument("--theta2_0",    type=float, default=0.3)
    parser.add_argument("--A_drive",     type=float, default=0.3)
    parser.add_argument("--omega_drive", type=float, default=2.5)
    parser.add_argument("--duration",    type=float, default=12.0)
    parser.add_argument("--output",      type=str,   default="moveable_double_pendulum.mp4")
    args = parser.parse_args()

    p = MoveableDoublePendulumParams(
        L1=args.L1, L2=args.L2, m1=args.m1, m2=args.m2, g=args.g, b=args.b,
        theta1_0=args.theta1_0, theta2_0=args.theta2_0,
        A_drive=args.A_drive, omega_drive=args.omega_drive,
    )
    print(f"Simulating moveable double pendulum: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")


if __name__ == "__main__":
    main()
