"""
Wheel Belt Drop - 7-phase wheel falls onto conveyor, slips/rolls, falls to floor, bounces.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle, Circle, Polygon
from matplotlib.collections import LineCollection
from matplotlib.lines import Line2D
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class WheelBeltDropParams:
    g: float = 9.8
    m: float = 0.6
    r_w: float = 0.10
    v_belt: float = 2.5
    belt_y: float = 1.0
    belt_x_left: float = -1.50
    belt_x_right: float = 1.00
    X_0: float = -0.80
    Y_0: float = 1.80
    mu_belt: float = 0.40
    mu_g: float = 0.30
    e_g: float = 0.30
    floor_y: float = 0.0


def _build(p: WheelBeltDropParams):
    g = p.g
    fall1_dist = max(p.Y_0 - (p.belt_y + p.r_w), 0.05)
    t1_dur = np.sqrt(2.0 * fall1_dist / g)
    vy_at_belt = -g * t1_dur
    s_0 = -p.v_belt
    a_vx_3 = -p.mu_belt * g * np.sign(s_0)
    a_om_3 = -2.0 * p.mu_belt * g / p.r_w * np.sign(s_0)
    t3_dur = abs(s_0) / (3.0 * p.mu_belt * g) if p.mu_belt > 0 else 0
    v_x_star = a_vx_3 * t3_dur
    om_star = a_om_3 * t3_dur
    dx3 = 0.5 * a_vx_3 * t3_dur ** 2
    dth3 = 0.5 * a_om_3 * t3_dur ** 2
    x_at_phase4 = p.X_0 + dx3
    remain_belt = p.belt_x_right - x_at_phase4
    t4_dur = max(0.0, remain_belt / v_x_star) if v_x_star > 0 else 0.0
    x_at_phase5 = x_at_phase4 + v_x_star * t4_dur
    dth4 = om_star * t4_dur
    fall5_dist = max(p.belt_y - p.floor_y, 0.05)
    t5_dur = np.sqrt(2.0 * fall5_dist / g)
    vy_at_floor = -g * t5_dur
    x_at_phase6 = x_at_phase5 + v_x_star * t5_dur
    dth5 = om_star * t5_dur

    t1_end = t1_dur
    t2_end = t1_end
    t3_end = t2_end + t3_dur
    t4_end = t3_end + t4_dur
    t5_end = t4_end + t5_dur

    return dict(
        a_vx_3=a_vx_3, a_om_3=a_om_3, v_x_star=v_x_star, om_star=om_star,
        x_at_phase4=x_at_phase4, x_at_phase5=x_at_phase5,
        x_at_phase6=x_at_phase6, dth3=dth3, dth4=dth4, dth5=dth5,
        vy_at_floor=vy_at_floor, fall1_dist=fall1_dist,
        t1_end=t1_end, t2_end=t2_end, t3_end=t3_end, t4_end=t4_end, t5_end=t5_end,
        I_w=0.5 * p.m * p.r_w * p.r_w,
    )


def _build_schedule(p, info):
    g = p.g; m = p.m; r_w = p.r_w
    mu_g = p.mu_g; e_g = p.e_g

    def routh_bounce(vx, vy, om):
        v_s = vx + om * r_w
        Jn = -(1.0 + e_g) * m * vy
        Jt_st = -m * v_s / 3.0
        cone = mu_g * abs(Jn)
        if abs(Jt_st) <= cone:
            Jt = Jt_st
        else:
            Jt = -np.sign(v_s) * cone
        vx_p = vx + Jt / m
        vy_p = -e_g * vy
        om_p = om + 2.0 * Jt / (m * r_w)
        return vx_p, vy_p, om_p

    schedule = []
    vx_b, vy_b, om_b = info["v_x_star"], info["vy_at_floor"], info["om_star"]
    x_b = info["x_at_phase6"]; y_b = p.floor_y + r_w
    th_b = info["dth3"] + info["dth4"] + info["dth5"]
    t_b = info["t5_end"]
    v_y_settle_thresh = 0.30
    for _ in range(12):
        vxp, vyp, omp = routh_bounce(vx_b, vy_b, om_b)
        if vyp < v_y_settle_thresh:
            vx_b, vy_b, om_b = vxp, 0.0, omp
            break
        t_flight = 2.0 * vyp / g
        schedule.append(dict(kind="flight", t0=t_b, dur=t_flight,
                             vx0=vxp, vy0=vyp, om0=omp, x0=x_b, y0=y_b,
                             th0=th_b))
        x_b = x_b + vxp * t_flight
        th_b = th_b + omp * t_flight
        t_b = t_b + t_flight
        vx_b, vy_b, om_b = vxp, -vyp, omp

    s_g = vx_b + om_b * r_w
    if abs(s_g) > 1e-9:
        sgn = np.sign(s_g)
        a_vx7 = -mu_g * g * sgn
        a_om7 = -2.0 * mu_g * g / r_w * sgn
        t7_dur = abs(s_g) / (3.0 * mu_g * g)
        vx_after_slip = vx_b + a_vx7 * t7_dur
        om_after_slip = om_b + a_om7 * t7_dur
        x_after_slip = x_b + vx_b * t7_dur + 0.5 * a_vx7 * t7_dur**2
        th_after_slip = th_b + om_b * t7_dur + 0.5 * a_om7 * t7_dur**2
        schedule.append(dict(kind="ground_slide", t0=t_b, dur=t7_dur,
                             x0=x_b, y0=y_b, th0=th_b,
                             vx0=vx_b, om0=om_b, a_vx=a_vx7, a_om=a_om7))
        t_settle = t_b + t7_dur
        vx_settle, om_settle = vx_after_slip, om_after_slip
        x_settle, th_settle = x_after_slip, th_after_slip
    else:
        t_settle = t_b
        vx_settle, om_settle = vx_b, om_b
        x_settle, th_settle = x_b, th_b
    schedule.append(dict(kind="ground_roll", t0=t_settle, dur=1e9,
                         x0=x_settle, y0=y_b, th0=th_settle,
                         vx0=vx_settle, om0=om_settle))
    return schedule


def _state_at(t, p, info, schedule):
    g = p.g; r_w = p.r_w
    if t <= info["t1_end"]:
        return (p.X_0, p.Y_0 - 0.5 * g * t * t, 0.0, -g * t, 0.0, 0.0)
    if t <= info["t3_end"]:
        dt = t - info["t2_end"]
        return (p.X_0 + 0.5 * info["a_vx_3"] * dt * dt,
                p.belt_y + r_w,
                info["a_vx_3"] * dt, 0.0,
                info["a_om_3"] * dt,
                0.5 * info["a_om_3"] * dt * dt)
    if t <= info["t4_end"]:
        dt = t - info["t3_end"]
        return (info["x_at_phase4"] + info["v_x_star"] * dt,
                p.belt_y + r_w,
                info["v_x_star"], 0.0,
                info["om_star"],
                info["dth3"] + info["om_star"] * dt)
    if t <= info["t5_end"]:
        dt = t - info["t4_end"]
        return (info["x_at_phase5"] + info["v_x_star"] * dt,
                (p.belt_y + r_w) - 0.5 * g * dt * dt,
                info["v_x_star"], -g * dt,
                info["om_star"],
                info["dth3"] + info["dth4"] + info["om_star"] * dt)
    for seg in schedule:
        t0, dur = seg["t0"], seg["dur"]
        if t <= t0 + dur + 1e-12:
            dt = t - t0
            if seg["kind"] == "flight":
                return (seg["x0"] + seg["vx0"] * dt,
                        seg["y0"] + seg["vy0"] * dt - 0.5 * g * dt * dt,
                        seg["vx0"], seg["vy0"] - g * dt,
                        seg["om0"], seg["th0"] + seg["om0"] * dt)
            if seg["kind"] == "ground_slide":
                return (seg["x0"] + seg["vx0"] * dt + 0.5 * seg["a_vx"] * dt * dt,
                        seg["y0"], seg["vx0"] + seg["a_vx"] * dt, 0.0,
                        seg["om0"] + seg["a_om"] * dt,
                        seg["th0"] + seg["om0"] * dt + 0.5 * seg["a_om"] * dt * dt)
            if seg["kind"] == "ground_roll":
                return (seg["x0"] + seg["vx0"] * dt, seg["y0"],
                        seg["vx0"], 0.0, seg["om0"], seg["th0"] + seg["om0"] * dt)
    seg = schedule[-1]
    dt = t - seg["t0"]
    return (seg["x0"] + seg["vx0"] * dt, seg["y0"], seg["vx0"], 0.0,
            seg["om0"], seg["th0"] + seg["om0"] * dt)


def simulate(params: WheelBeltDropParams, duration: float = 12.0, fps: int = 30):
    info = _build(params)
    schedule = _build_schedule(params, info)
    n = int(duration * fps) + 1
    t_eval = np.linspace(0.0, duration, n)
    y = np.zeros((6, n))
    for i, t in enumerate(t_eval):
        x, yc, vx, vy, om, th = _state_at(t, params, info, schedule)
        y[:, i] = [x, yc, vx, vy, om, th]
    return t_eval, y


def render_video(t, y, params: WheelBeltDropParams, output_path: str, fps: int = 30):
    p = params
    xs, ys, ths = y[0], y[1], y[5]
    fig_w, fig_h = 11.0, 6.0
    fig_aspect = fig_w / fig_h
    x_lo_d = min(p.belt_x_left - 0.30, xs.min() - 0.20)
    x_hi_d = max(p.belt_x_right + 0.30, xs.max() + 0.20)
    y_lo_d = p.floor_y - 0.25
    y_hi_d = max(p.Y_0 + 0.20, p.belt_y + 0.30)
    dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_d / dy_d < fig_aspect:
        extra = (fig_aspect * dy_d - dx_d) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx_d / fig_aspect - dy_d) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")
    ax.add_patch(Polygon([(x_lo, y_lo), (x_hi, y_lo), (x_hi, p.floor_y), (x_lo, p.floor_y)],
                         facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.plot([x_lo, x_hi], [p.floor_y, p.floor_y], color="#adb5bd", lw=2.0, zorder=1)
    belt_thick = 0.06
    ax.add_patch(Rectangle((p.belt_x_left, p.belt_y),
                           p.belt_x_right - p.belt_x_left, belt_thick,
                           facecolor="#3a4357", edgecolor="#adb5bd", lw=1.2, zorder=2))
    hash_lc = LineCollection([], colors="#adb5bd", linewidths=2.0, zorder=4)
    ax.add_collection(hash_lc)
    wheel_patch = Circle((xs[0], ys[0]), p.r_w,
                         facecolor="#80c0ff", edgecolor="#ffffff", lw=1.5, zorder=5)
    ax.add_patch(wheel_patch)
    spin_markers = []
    for k in range(4):
        ang0 = ths[0] + k * (np.pi / 2.0)
        line = Line2D([xs[0], xs[0] + p.r_w * np.cos(ang0)],
                      [ys[0], ys[0] + p.r_w * np.sin(ang0)],
                      color="#e63946", lw=2.8, zorder=6)
        ax.add_line(line)
        spin_markers.append(line)

    hash_spacing = 0.30; hash_w = 0.03

    def update(f):
        cx, cy, th = xs[f], ys[f], ths[f]
        wheel_patch.set_center((cx, cy))
        for k, line in enumerate(spin_markers):
            ang = th + k * (np.pi / 2.0)
            line.set_data([cx, cx + p.r_w * np.cos(ang)],
                          [cy, cy + p.r_w * np.sin(ang)])
        s0 = (p.v_belt * t[f]) % hash_spacing
        span = p.belt_x_right - p.belt_x_left
        n_marks = int(np.ceil(span / hash_spacing)) + 1
        segs = []
        y_top = p.belt_y + belt_thick
        for k in range(n_marks):
            x_m = p.belt_x_left + s0 + k * hash_spacing
            if p.belt_x_left <= x_m <= p.belt_x_right:
                segs.append([(x_m, y_top - hash_w), (x_m, y_top + hash_w)])
        hash_lc.set_segments(segs)
        return (wheel_patch, *spin_markers, hash_lc)

    ani = animation.FuncAnimation(fig, update, frames=len(t), interval=1000.0 / fps, blit=False)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: WheelBeltDropParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Wheel belt drop - auto-generated."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Rectangle, Circle, Polygon
from matplotlib.collections import LineCollection
from matplotlib.lines import Line2D

g={p["g"]}; m={p["m"]}; r_w={p["r_w"]}; v_belt={p["v_belt"]}
belt_y={p["belt_y"]}; belt_x_left={p["belt_x_left"]}; belt_x_right={p["belt_x_right"]}
X_0={p["X_0"]}; Y_0={p["Y_0"]}
mu_belt={p["mu_belt"]}; mu_g={p["mu_g"]}; e_g={p["e_g"]}
floor_y={p["floor_y"]}; duration={duration}; fps=30
I_w=0.5*m*r_w*r_w

fall1_dist=max(Y_0-(belt_y+r_w),0.05)
t1_dur=np.sqrt(2.0*fall1_dist/g)
vy_at_belt=-g*t1_dur
s_0=-v_belt
a_vx_3=-mu_belt*g*np.sign(s_0)
a_om_3=-2.0*mu_belt*g/r_w*np.sign(s_0)
t3_dur=abs(s_0)/(3.0*mu_belt*g) if mu_belt>0 else 0
v_x_star=a_vx_3*t3_dur
om_star=a_om_3*t3_dur
dx3=0.5*a_vx_3*t3_dur**2
dth3=0.5*a_om_3*t3_dur**2
x_at_phase4=X_0+dx3
remain_belt=belt_x_right-x_at_phase4
t4_dur=max(0.0,remain_belt/v_x_star) if v_x_star>0 else 0.0
x_at_phase5=x_at_phase4+v_x_star*t4_dur
dth4=om_star*t4_dur
fall5_dist=max(belt_y-floor_y,0.05)
t5_dur=np.sqrt(2.0*fall5_dist/g)
vy_at_floor=-g*t5_dur
x_at_phase6=x_at_phase5+v_x_star*t5_dur
dth5=om_star*t5_dur

t1_end=t1_dur; t2_end=t1_end
t3_end=t2_end+t3_dur; t4_end=t3_end+t4_dur; t5_end=t4_end+t5_dur

def routh_bounce(vx,vy,om):
    v_s=vx+om*r_w
    Jn=-(1.0+e_g)*m*vy
    Jt_st=-m*v_s/3.0
    cone=mu_g*abs(Jn)
    if abs(Jt_st)<=cone:
        Jt=Jt_st
    else:
        Jt=-np.sign(v_s)*cone
    vx_p=vx+Jt/m; vy_p=-e_g*vy; om_p=om+2.0*Jt/(m*r_w)
    return vx_p,vy_p,om_p

schedule=[]
vx_b,vy_b,om_b=v_x_star,vy_at_floor,om_star
x_b,y_b=x_at_phase6,floor_y+r_w
th_b=dth3+dth4+dth5
t_b=t5_end
v_y_settle_thresh=0.30
for _ in range(12):
    vxp,vyp,omp=routh_bounce(vx_b,vy_b,om_b)
    if vyp<v_y_settle_thresh:
        vx_b,vy_b,om_b=vxp,0.0,omp; break
    t_flight=2.0*vyp/g
    schedule.append(dict(kind="flight",t0=t_b,dur=t_flight,
                         vx0=vxp,vy0=vyp,om0=omp,x0=x_b,y0=y_b,th0=th_b))
    x_b=x_b+vxp*t_flight; th_b=th_b+omp*t_flight
    t_b=t_b+t_flight
    vx_b,vy_b,om_b=vxp,-vyp,omp

s_g=vx_b+om_b*r_w
if abs(s_g)>1e-9:
    sgn=np.sign(s_g)
    a_vx7=-mu_g*g*sgn; a_om7=-2.0*mu_g*g/r_w*sgn
    t7_dur=abs(s_g)/(3.0*mu_g*g)
    vx_after_slip=vx_b+a_vx7*t7_dur
    om_after_slip=om_b+a_om7*t7_dur
    x_after_slip=x_b+vx_b*t7_dur+0.5*a_vx7*t7_dur**2
    th_after_slip=th_b+om_b*t7_dur+0.5*a_om7*t7_dur**2
    schedule.append(dict(kind="ground_slide",t0=t_b,dur=t7_dur,
                         x0=x_b,y0=y_b,th0=th_b,
                         vx0=vx_b,om0=om_b,a_vx=a_vx7,a_om=a_om7))
    t_settle=t_b+t7_dur
    vx_settle,om_settle=vx_after_slip,om_after_slip
    x_settle,th_settle=x_after_slip,th_after_slip
else:
    t_settle=t_b
    vx_settle,om_settle=vx_b,om_b
    x_settle,th_settle=x_b,th_b
schedule.append(dict(kind="ground_roll",t0=t_settle,dur=1e9,
                     x0=x_settle,y0=y_b,th0=th_settle,
                     vx0=vx_settle,om0=om_settle))

def state_at(t):
    if t<=t1_end:
        return (X_0, Y_0-0.5*g*t*t, 0.0, -g*t, 0.0, 0.0)
    if t<=t3_end:
        dt=t-t2_end
        return (X_0+0.5*a_vx_3*dt*dt, belt_y+r_w,
                a_vx_3*dt, 0.0, a_om_3*dt, 0.5*a_om_3*dt*dt)
    if t<=t4_end:
        dt=t-t3_end
        return (x_at_phase4+v_x_star*dt, belt_y+r_w,
                v_x_star, 0.0, om_star, dth3+om_star*dt)
    if t<=t5_end:
        dt=t-t4_end
        return (x_at_phase5+v_x_star*dt, (belt_y+r_w)-0.5*g*dt*dt,
                v_x_star, -g*dt, om_star, dth3+dth4+om_star*dt)
    for seg in schedule:
        t0,dur=seg["t0"],seg["dur"]
        if t<=t0+dur+1e-12:
            dt=t-t0
            if seg["kind"]=="flight":
                return (seg["x0"]+seg["vx0"]*dt,
                        seg["y0"]+seg["vy0"]*dt-0.5*g*dt*dt,
                        seg["vx0"], seg["vy0"]-g*dt,
                        seg["om0"], seg["th0"]+seg["om0"]*dt)
            if seg["kind"]=="ground_slide":
                return (seg["x0"]+seg["vx0"]*dt+0.5*seg["a_vx"]*dt*dt,
                        seg["y0"], seg["vx0"]+seg["a_vx"]*dt, 0.0,
                        seg["om0"]+seg["a_om"]*dt,
                        seg["th0"]+seg["om0"]*dt+0.5*seg["a_om"]*dt*dt)
            if seg["kind"]=="ground_roll":
                return (seg["x0"]+seg["vx0"]*dt, seg["y0"],
                        seg["vx0"], 0.0, seg["om0"], seg["th0"]+seg["om0"]*dt)
    seg=schedule[-1]; dt=t-seg["t0"]
    return (seg["x0"]+seg["vx0"]*dt, seg["y0"], seg["vx0"], 0.0,
            seg["om0"], seg["th0"]+seg["om0"]*dt)

n_frames=int(duration*fps)+1
t_grid=np.linspace(0.0,duration,n_frames)
xs=np.empty(n_frames); ys=np.empty(n_frames)
ths=np.empty(n_frames)
for i,t in enumerate(t_grid):
    x,yc,_,_,_,th=state_at(t)
    xs[i]=x; ys[i]=yc; ths[i]=th

fig_w,fig_h=11.0,6.0; fa=fig_w/fig_h
x_lo_d=min(belt_x_left-0.30,xs.min()-0.20)
x_hi_d=max(belt_x_right+0.30,xs.max()+0.20)
y_lo_d=floor_y-0.25
y_hi_d=max(Y_0+0.20,belt_y+0.30)
dx_d,dy_d=x_hi_d-x_lo_d,y_hi_d-y_lo_d
if dx_d/dy_d<fa:
    e=(fa*dy_d-dx_d)/2.0; x_lo,x_hi=x_lo_d-e,x_hi_d+e; y_lo,y_hi=y_lo_d,y_hi_d
else:
    e=(dx_d/fa-dy_d)/2.0; x_lo,x_hi=x_lo_d,x_hi_d; y_lo,y_hi=y_lo_d-e,y_hi_d+e

fig=plt.figure(figsize=(fig_w,fig_h),facecolor="#1a1a2e")
ax=fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi); ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(Polygon([(x_lo,y_lo),(x_hi,y_lo),(x_hi,floor_y),(x_lo,floor_y)],
                     facecolor="#4a4e69",edgecolor="none",zorder=0))
ax.plot([x_lo,x_hi],[floor_y,floor_y],color="#adb5bd",lw=2.0,zorder=1)
belt_thick=0.06
ax.add_patch(Rectangle((belt_x_left,belt_y),belt_x_right-belt_x_left,belt_thick,
                       facecolor="#3a4357",edgecolor="#adb5bd",lw=1.2,zorder=2))
hash_lc=LineCollection([],colors="#adb5bd",linewidths=2.0,zorder=4)
ax.add_collection(hash_lc)
wheel_patch=Circle((xs[0],ys[0]),r_w,facecolor="#80c0ff",edgecolor="#ffffff",lw=1.5,zorder=5)
ax.add_patch(wheel_patch)
spin_markers=[]
for k in range(4):
    ang0=ths[0]+k*(np.pi/2.0)
    line=Line2D([xs[0],xs[0]+r_w*np.cos(ang0)],[ys[0],ys[0]+r_w*np.sin(ang0)],
                color="#e63946",lw=2.8,zorder=6)
    ax.add_line(line); spin_markers.append(line)
hash_spacing=0.30; hash_w=0.03

def update(f):
    cx,cy,th=xs[f],ys[f],ths[f]
    wheel_patch.set_center((cx,cy))
    for k,line in enumerate(spin_markers):
        ang=th+k*(np.pi/2.0)
        line.set_data([cx,cx+r_w*np.cos(ang)],[cy,cy+r_w*np.sin(ang)])
    t=f/fps
    s0=(v_belt*t)%hash_spacing
    span=belt_x_right-belt_x_left
    n_marks=int(np.ceil(span/hash_spacing))+1
    segs=[]
    y_top=belt_y+belt_thick
    for k in range(n_marks):
        x_m=belt_x_left+s0+k*hash_spacing
        if belt_x_left<=x_m<=belt_x_right:
            segs.append([(x_m,y_top-hash_w),(x_m,y_top+hash_w)])
    hash_lc.set_segments(segs)
    return (wheel_patch,*spin_markers,hash_lc)

ani=animation.FuncAnimation(fig,update,frames=n_frames,interval=1000.0/fps,blit=False)
ani.save("video.mp4",writer=animation.FFMpegWriter(fps=fps,bitrate=1800),dpi=120)
plt.close(); print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    for fld, dflt in asdict(WheelBeltDropParams()).items():
        parser.add_argument(f"--{fld}", type=float, default=dflt)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="video.mp4")
    args = parser.parse_args()
    p = WheelBeltDropParams(**{k: getattr(args, k) for k in asdict(WheelBeltDropParams()).keys()})
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
