"""
Three-Body Gravity (2-D Plane)
================================
Three point masses interact through Newtonian gravitation in 2-D.  Initial
conditions are arranged so that the centre of mass starts at rest at the
origin (so the COM stays stationary throughout). The third body's IC is set
from the first two via momentum and centre-of-mass constraints.
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from dataclasses import dataclass, asdict


@dataclass
class ThreeBodyGravityParams:
    G: float = 1.0
    m1: float = 1.0
    m2: float = 1.5
    m3: float = 0.7
    eps: float = 0.05
    r1x_0: float = 1.00
    r1y_0: float = 0.00
    r2x_0: float = -0.50
    r2y_0: float = 0.70
    v1x_0: float = 0.10
    v1y_0: float = 0.40
    v2x_0: float = -0.30
    v2y_0: float = -0.20


def simulate(
    params: ThreeBodyGravityParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Returns (t_eval, y) with y.shape=(12, n_frames): r1,r2,r3,v1,v2,v3 (each 2-D)."""
    G = params.G
    m1 = params.m1
    m2 = params.m2
    m3 = params.m3
    eps = params.eps
    r1_0 = np.array([params.r1x_0, params.r1y_0])
    r2_0 = np.array([params.r2x_0, params.r2y_0])
    r3_0 = -(m1 * r1_0 + m2 * r2_0) / m3
    v1_0 = np.array([params.v1x_0, params.v1y_0])
    v2_0 = np.array([params.v2x_0, params.v2y_0])
    v3_0 = -(m1 * v1_0 + m2 * v2_0) / m3
    masses = np.array([m1, m2, m3])

    def three_body(t, s):
        p = s[0:6].reshape(3, 2)
        v = s[6:12].reshape(3, 2)
        a = np.zeros((3, 2))
        eps2 = eps * eps
        for i in range(3):
            for j in range(3):
                if i == j:
                    continue
                d = p[j] - p[i]
                inv_r3 = (d[0] * d[0] + d[1] * d[1] + eps2) ** (-1.5)
                a[i] += G * masses[j] * d * inv_r3
        return np.concatenate([v.flatten(), a.flatten()])

    t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
    y0 = np.concatenate([r1_0, r2_0, r3_0, v1_0, v2_0, v3_0])
    sol = solve_ivp(three_body, (0.0, duration), y0, t_eval=t_eval,
                    method="DOP853", rtol=1e-11, atol=1e-13)
    return sol.t, sol.y


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: ThreeBodyGravityParams,
    output_path: str,
    fps: int = 30,
) -> None:
    x1_arr, y1_arr = y[0], y[1]
    x2_arr, y2_arr = y[2], y[3]
    x3_arr, y3_arr = y[4], y[5]

    all_x = np.concatenate([x1_arr, x2_arr, x3_arr])
    all_y = np.concatenate([y1_arr, y2_arr, y3_arr])
    pad = 0.30
    x_lo, x_hi = all_x.min() - pad, all_x.max() + pad
    y_lo, y_hi = all_y.min() - pad, all_y.max() + pad
    fig_w, fig_h = 7.0, 5.5
    fig_aspect = fig_w / fig_h
    dx, dy = x_hi - x_lo, y_hi - y_lo
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo -= extra; x_hi += extra
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        y_lo -= extra; y_hi += extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#0b0b1f")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#0b0b1f")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    rng = np.random.default_rng(13)
    star_x = rng.uniform(x_lo, x_hi, size=160)
    star_y = rng.uniform(y_lo, y_hi, size=160)
    star_s = rng.uniform(0.5, 3.5, size=160) ** 2
    star_a = rng.uniform(0.30, 0.85, size=160)
    ax.scatter(star_x, star_y, s=star_s, c="white", alpha=star_a,
               zorder=0, edgecolors='none')
    ax.plot([0.0], [0.0], '+', color="#e0e0e0", markersize=11,
            markeredgewidth=1.0, zorder=1)

    trail_len = 80
    trail1, = ax.plot([], [], '-', color="#80c0ff", lw=1.4, alpha=0.75, zorder=2)
    trail2, = ax.plot([], [], '-', color="#ffd166", lw=1.4, alpha=0.75, zorder=2)
    trail3, = ax.plot([], [], '-', color="#ef476f", lw=1.4, alpha=0.75, zorder=2)
    m1, m2, m3 = params.m1, params.m2, params.m3
    m_max = max(m1, m2, m3)
    size1 = 18.0 * (m1 / m_max) ** (1.0 / 3.0)
    size2 = 18.0 * (m2 / m_max) ** (1.0 / 3.0)
    size3 = 18.0 * (m3 / m_max) ** (1.0 / 3.0)
    body1, = ax.plot([], [], 'o', color="#80c0ff", markersize=size1,
                     markeredgecolor="white", markeredgewidth=1.0, zorder=4)
    body2, = ax.plot([], [], 'o', color="#ffd166", markersize=size2,
                     markeredgecolor="white", markeredgewidth=1.0, zorder=4)
    body3, = ax.plot([], [], 'o', color="#ef476f", markersize=size3,
                     markeredgecolor="white", markeredgewidth=1.0, zorder=4)

    def update(f):
        s = max(0, f - trail_len)
        trail1.set_data(x1_arr[s:f + 1], y1_arr[s:f + 1])
        trail2.set_data(x2_arr[s:f + 1], y2_arr[s:f + 1])
        trail3.set_data(x3_arr[s:f + 1], y3_arr[s:f + 1])
        body1.set_data([x1_arr[f]], [y1_arr[f]])
        body2.set_data([x2_arr[f]], [y2_arr[f]])
        body3.set_data([x3_arr[f]], [y3_arr[f]])
        return trail1, trail2, trail3, body1, body2, body3

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0 / fps, blit=True)
    writer = animation.FFMpegWriter(fps=fps, bitrate=2400)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: ThreeBodyGravityParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Three-Body Gravity — auto-generated."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation

G = {p["G"]}
m1 = {p["m1"]}
m2 = {p["m2"]}
m3 = {p["m3"]}
eps = {p["eps"]}
duration = {duration}
fps = 30

r1_0 = np.array([{p["r1x_0"]}, {p["r1y_0"]}])
r2_0 = np.array([{p["r2x_0"]}, {p["r2y_0"]}])
r3_0 = -(m1*r1_0 + m2*r2_0)/m3
v1_0 = np.array([{p["v1x_0"]}, {p["v1y_0"]}])
v2_0 = np.array([{p["v2x_0"]}, {p["v2y_0"]}])
v3_0 = -(m1*v1_0 + m2*v2_0)/m3
masses = np.array([m1, m2, m3])

def three_body(t, s):
    p = s[0:6].reshape(3, 2)
    v = s[6:12].reshape(3, 2)
    a = np.zeros((3, 2))
    eps2 = eps*eps
    for i in range(3):
        for j in range(3):
            if i == j: continue
            d = p[j] - p[i]
            inv_r3 = (d[0]*d[0] + d[1]*d[1] + eps2) ** (-1.5)
            a[i] += G * masses[j] * d * inv_r3
    return np.concatenate([v.flatten(), a.flatten()])

t_eval = np.linspace(0.0, duration, int(duration*fps)+1)
y0 = np.concatenate([r1_0, r2_0, r3_0, v1_0, v2_0, v3_0])
sol = solve_ivp(three_body, (0.0, duration), y0, t_eval=t_eval,
                method="DOP853", rtol=1e-11, atol=1e-13)
x1_arr, y1_arr = sol.y[0], sol.y[1]
x2_arr, y2_arr = sol.y[2], sol.y[3]
x3_arr, y3_arr = sol.y[4], sol.y[5]

all_x = np.concatenate([x1_arr, x2_arr, x3_arr])
all_y = np.concatenate([y1_arr, y2_arr, y3_arr])
pad = 0.30
x_lo, x_hi = all_x.min()-pad, all_x.max()+pad
y_lo, y_hi = all_y.min()-pad, all_y.max()+pad
fig_w, fig_h = 7.0, 5.5
fig_aspect = fig_w/fig_h
dx, dy = x_hi-x_lo, y_hi-y_lo
if dx/dy < fig_aspect:
    extra = (fig_aspect*dy - dx)/2.0
    x_lo -= extra; x_hi += extra
else:
    extra = (dx/fig_aspect - dy)/2.0
    y_lo -= extra; y_hi += extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#0b0b1f")
ax = fig.add_axes([0,0,1,1]); ax.set_facecolor("#0b0b1f")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")

rng = np.random.default_rng(13)
star_x = rng.uniform(x_lo, x_hi, size=160)
star_y = rng.uniform(y_lo, y_hi, size=160)
star_s = rng.uniform(0.5, 3.5, size=160)**2
star_a = rng.uniform(0.30, 0.85, size=160)
ax.scatter(star_x, star_y, s=star_s, c="white", alpha=star_a, zorder=0, edgecolors='none')
ax.plot([0.0], [0.0], '+', color="#e0e0e0", markersize=11, markeredgewidth=1.0, zorder=1)

trail_len = 80
trail1, = ax.plot([], [], '-', color="#80c0ff", lw=1.4, alpha=0.75, zorder=2)
trail2, = ax.plot([], [], '-', color="#ffd166", lw=1.4, alpha=0.75, zorder=2)
trail3, = ax.plot([], [], '-', color="#ef476f", lw=1.4, alpha=0.75, zorder=2)
m_max = max(m1, m2, m3)
size1 = 18.0 * (m1/m_max)**(1.0/3.0)
size2 = 18.0 * (m2/m_max)**(1.0/3.0)
size3 = 18.0 * (m3/m_max)**(1.0/3.0)
body1, = ax.plot([], [], 'o', color="#80c0ff", markersize=size1, markeredgecolor="white", markeredgewidth=1.0, zorder=4)
body2, = ax.plot([], [], 'o', color="#ffd166", markersize=size2, markeredgecolor="white", markeredgewidth=1.0, zorder=4)
body3, = ax.plot([], [], 'o', color="#ef476f", markersize=size3, markeredgecolor="white", markeredgewidth=1.0, zorder=4)

def update(f):
    s = max(0, f - trail_len)
    trail1.set_data(x1_arr[s:f+1], y1_arr[s:f+1])
    trail2.set_data(x2_arr[s:f+1], y2_arr[s:f+1])
    trail3.set_data(x3_arr[s:f+1], y3_arr[s:f+1])
    body1.set_data([x1_arr[f]], [y1_arr[f]])
    body2.set_data([x2_arr[f]], [y2_arr[f]])
    body3.set_data([x3_arr[f]], [y3_arr[f]])
    return trail1, trail2, trail3, body1, body2, body3

ani = animation.FuncAnimation(fig, update, frames=len(t_eval), interval=1000.0/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=2400), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Three-Body Gravity")
    parser.add_argument("--G", type=float, default=1.0)
    parser.add_argument("--m1", type=float, default=1.0)
    parser.add_argument("--m2", type=float, default=1.5)
    parser.add_argument("--m3", type=float, default=0.7)
    parser.add_argument("--eps", type=float, default=0.05)
    parser.add_argument("--r1x_0", type=float, default=1.00)
    parser.add_argument("--r1y_0", type=float, default=0.00)
    parser.add_argument("--r2x_0", type=float, default=-0.50)
    parser.add_argument("--r2y_0", type=float, default=0.70)
    parser.add_argument("--v1x_0", type=float, default=0.10)
    parser.add_argument("--v1y_0", type=float, default=0.40)
    parser.add_argument("--v2x_0", type=float, default=-0.30)
    parser.add_argument("--v2y_0", type=float, default=-0.20)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="three_body_gravity.mp4")
    args = parser.parse_args()
    p = ThreeBodyGravityParams(
        G=args.G, m1=args.m1, m2=args.m2, m3=args.m3, eps=args.eps,
        r1x_0=args.r1x_0, r1y_0=args.r1y_0,
        r2x_0=args.r2x_0, r2y_0=args.r2y_0,
        v1x_0=args.v1x_0, v1y_0=args.v1y_0,
        v2x_0=args.v2x_0, v2y_0=args.v2y_0,
    )
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
