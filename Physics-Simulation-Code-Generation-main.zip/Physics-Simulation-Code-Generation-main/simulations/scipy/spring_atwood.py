"""
Spring Atwood — Compound Atwood with a vertical spring replacing the left mass.

Layout (positive y = downward; ceiling at 0, floor at y_floor):
- Fixed pulley A at (x_A, y_A); string over A connects spring-top (left) to
  axle of movable pulley B (right).
- Spring's bottom anchored to floor; T_A = k (L_s - L_0) where L_s = y_floor - y_se.
- Rope over B connects mass m_2 (left) to mass m_3 (right).
Constraints reduce dynamics to (y_2, y_3, v_2, v_3); pulley B follows
y_B = (y_2+y_3)/2 + C_pulley.
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict


@dataclass
class SpringAtwoodParams:
    g: float = 9.8
    m_2: float = 1.0
    m_3: float = 1.02
    k: float = 28.3
    L_0: float = 0.8
    y_floor: float = 4.5
    y_se_0: float = 2.5
    y_B_0: float = 2.5
    ROPE_HALF: float = 10.0


def simulate(
    params: SpringAtwoodParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Returns (t, y) where y.shape = (4, N): [y_2, y_3, v_2, v_3]."""
    g, m_2, m_3 = params.g, params.m_2, params.m_3
    k, L_0 = params.k, params.L_0
    y_floor = params.y_floor
    y_se_0 = params.y_se_0
    y_B_0 = params.y_B_0
    ROPE_HALF = params.ROPE_HALF

    y_2_0 = y_B_0 + ROPE_HALF
    y_3_0 = y_B_0 + ROPE_HALF

    const_A = y_se_0 + y_B_0
    C_pulley = y_B_0 - 0.5 * (y_2_0 + y_3_0)

    def ode(t, y):
        y2, y3, v2, v3 = y
        y_B = 0.5 * (y2 + y3) + C_pulley
        y_se = const_A - y_B
        L_s = y_floor - y_se
        T_A = k * (L_s - L_0)
        T_B = 0.5 * T_A
        a2 = g - T_B / m_2
        a3 = g - T_B / m_3
        return [v2, v3, a2, a3]

    # Stop conditions: any mass touches pulley B from below, OR any mass touches
    # the floor, OR the spring would compress past zero length. Each is a terminal
    # event with direction=-1 (gap shrinking to zero from above).
    MASS_TOP_OFFSET = 0.6   # mass-top sits 0.6 below pulley centre when in contact
    def event_m2_pulley(t, y):
        y2, y3, _, _ = y
        y_B = 0.5 * (y2 + y3) + C_pulley
        return y2 - (y_B + MASS_TOP_OFFSET)
    event_m2_pulley.terminal = True; event_m2_pulley.direction = -1

    def event_m3_pulley(t, y):
        y2, y3, _, _ = y
        y_B = 0.5 * (y2 + y3) + C_pulley
        return y3 - (y_B + MASS_TOP_OFFSET)
    event_m3_pulley.terminal = True; event_m3_pulley.direction = -1

    # Mass hits the floor (mass body extends 0.6 below its top y; floor is y_floor;
    # since +y is downward, "hits" means y2 + 0.6 → y_floor).
    MASS_BOT_OFFSET = 0.6
    def event_m2_floor(t, y):
        return y_floor - (y[0] + MASS_BOT_OFFSET)
    event_m2_floor.terminal = True; event_m2_floor.direction = -1

    def event_m3_floor(t, y):
        return y_floor - (y[1] + MASS_BOT_OFFSET)
    event_m3_floor.terminal = True; event_m3_floor.direction = -1

    # Spring would compress past zero length (y_se hits the floor from above).
    def event_spring_min(t, y):
        y_B = 0.5 * (y[0] + y[1]) + C_pulley
        y_se = const_A - y_B
        return y_floor - y_se
    event_spring_min.terminal = True; event_spring_min.direction = -1

    events = [event_m2_pulley, event_m3_pulley,
              event_m2_floor, event_m3_floor, event_spring_min]

    t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode, (0.0, duration), [y_2_0, y_3_0, 0.0, 0.0],
        t_eval=t_eval, method="RK45", rtol=1e-9, atol=1e-11,
        events=events, dense_output=True,
    )

    if sol.status == 1:
        t_freeze = sol.t[-1]
        state_freeze = sol.y[:, -1]
        y2_arr = np.where(t_eval <= t_freeze,
                          sol.sol(np.minimum(t_eval, t_freeze))[0], state_freeze[0])
        y3_arr = np.where(t_eval <= t_freeze,
                          sol.sol(np.minimum(t_eval, t_freeze))[1], state_freeze[1])
        v2_arr = np.where(t_eval <= t_freeze,
                          sol.sol(np.minimum(t_eval, t_freeze))[2], 0.0)
        v3_arr = np.where(t_eval <= t_freeze,
                          sol.sol(np.minimum(t_eval, t_freeze))[3], 0.0)
    else:
        y2_arr, y3_arr, v2_arr, v3_arr = sol.y

    return t_eval, np.vstack([y2_arr, y3_arr, v2_arr, v3_arr])


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: SpringAtwoodParams,
    output_path: str,
    fps: int = 30,
) -> None:
    g = params.g
    L_0 = params.L_0
    y_floor = params.y_floor
    y_se_0 = params.y_se_0
    y_B_0 = params.y_B_0
    ROPE_HALF = params.ROPE_HALF

    y_2_0 = y_B_0 + ROPE_HALF
    y_3_0 = y_B_0 + ROPE_HALF
    const_A = y_se_0 + y_B_0
    C_pulley = y_B_0 - 0.5 * (y_2_0 + y_3_0)

    y2_arr, y3_arr = y[0], y[1]
    yB_arr = 0.5 * (y2_arr + y3_arr) + C_pulley
    yse_arr = const_A - yB_arr

    # Geometry
    r_A = 0.55
    r_B = 0.55
    x_A = 1.50
    y_A = r_A + 0.05
    x_B = x_A + r_A
    mass_side = 0.80
    x_spring = x_A - r_A
    x_m2 = x_B - r_B
    x_m3 = x_B + r_B

    fig_w, fig_h = 5.0, 8.0
    fig_aspect = fig_w / fig_h
    x_lo_d = min(x_spring, x_m2 - mass_side / 2.0) - 0.4
    x_hi_d = max(x_m3 + mass_side / 2.0, x_A + r_A) + 0.4
    y_lo_d = -0.4
    y_hi_d = max(y2_arr.max(), y3_arr.max()) + mass_side + 0.5
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi)
    ax.set_ylim(y_hi, y_lo)
    ax.set_aspect("equal")
    ax.axis("off")

    ax.add_patch(patches.Rectangle((x_lo, y_lo), x_hi - x_lo, -y_lo,
                                   facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.plot([x_lo, x_hi], [0, 0], color="#adb5bd", lw=2.2, zorder=1)
    ax.add_patch(patches.Rectangle((x_spring - 0.20, y_floor - 0.05),
                                   0.40, 0.10, facecolor="#adb5bd",
                                   edgecolor="none", zorder=2))

    ax.plot([x_A, x_A], [0, y_A - r_A], color="#adb5bd", lw=2.5, zorder=2)
    ax.add_patch(patches.Circle((x_A, y_A), r_A,
                                facecolor="#4a4e69", edgecolor="white",
                                lw=1.6, zorder=4))
    arc_A = patches.Arc((x_A, y_A), 2 * r_A, 2 * r_A, angle=0, theta1=180, theta2=360,
                        color="#a8dadc", lw=2.5, zorder=5)
    ax.add_patch(arc_A)
    ax.add_patch(patches.Circle((x_A, y_A), r_A * 0.18,
                                facecolor="#1a1a2e", edgecolor="#adb5bd",
                                lw=1.0, zorder=6))

    pulley_B_body = patches.Circle((x_B, y_B_0), r_B,
                                   facecolor="#4a4e69", edgecolor="white",
                                   lw=1.6, zorder=4)
    arc_B = patches.Arc((x_B, y_B_0), 2 * r_B, 2 * r_B, angle=0, theta1=180, theta2=360,
                        color="#a8dadc", lw=2.5, zorder=5)
    hub_B = patches.Circle((x_B, y_B_0), r_B * 0.18,
                           facecolor="#1a1a2e", edgecolor="#adb5bd",
                           lw=1.0, zorder=6)
    ax.add_patch(pulley_B_body); ax.add_patch(arc_B); ax.add_patch(hub_B)

    m2_patch = patches.Rectangle((0, 0), mass_side, mass_side,
                                 facecolor="#e63946", edgecolor="white",
                                 lw=1.5, zorder=7)
    m3_patch = patches.Rectangle((0, 0), mass_side, mass_side,
                                 facecolor="#f4d35e", edgecolor="white",
                                 lw=1.5, zorder=7)
    ax.add_patch(m2_patch); ax.add_patch(m3_patch)

    str_A_left, = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=5)
    str_A_right, = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=5)
    rope_B_left, = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=5)
    rope_B_right, = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=5)
    spring_line, = ax.plot([], [], "-", color="#f4d35e", lw=2.4, zorder=4)

    def spring_path_fn(x_top, y_top, x_bot, y_bot, n=10, r=0.10):
        s = np.linspace(0.0, 1.0, n * 20 + 2)
        pad = 0.08
        env = np.where((s < pad) | (s > 1.0 - pad), 0.0,
                       np.sin(n * 2.0 * np.pi * (s - pad) / (1.0 - 2.0 * pad)))
        xs = x_top + s * (x_bot - x_top) + r * env
        ys = y_top + s * (y_bot - y_top)
        return xs, ys

    def update(f):
        y_se = yse_arr[f]; y_B = yB_arr[f]
        y_2 = y2_arr[f]; y_3 = y3_arr[f]
        pulley_B_body.center = (x_B, y_B)
        hub_B.center = (x_B, y_B)
        arc_B.set_center((x_B, y_B))
        str_A_left.set_data([x_spring, x_spring], [y_A, y_se])
        str_A_right.set_data([x_B, x_B], [y_A, y_B - r_B])
        rope_B_left.set_data([x_m2, x_m2], [y_B, y_2])
        rope_B_right.set_data([x_m3, x_m3], [y_B, y_3])
        sx, sy = spring_path_fn(x_spring, y_se, x_spring, y_floor)
        spring_line.set_data(sx, sy)
        m2_patch.set_xy((x_m2 - mass_side / 2.0, y_2))
        m3_patch.set_xy((x_m3 - mass_side / 2.0, y_3))
        return (pulley_B_body, hub_B, arc_B,
                str_A_left, str_A_right, rope_B_left, rope_B_right,
                spring_line, m2_patch, m3_patch)

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000 / fps, blit=True)
    ani.save(output_path,
             writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(
    params: SpringAtwoodParams,
    duration: float = 12.0,
) -> str:
    p = asdict(params)
    return f'''"""Spring Atwood — auto-generated."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

g       = {p["g"]}
m_2     = {p["m_2"]}
m_3     = {p["m_3"]}
k       = {p["k"]}
L_0     = {p["L_0"]}
y_floor = {p["y_floor"]}
y_se_0  = {p["y_se_0"]}
y_B_0   = {p["y_B_0"]}
ROPE_HALF = {p["ROPE_HALF"]}
duration = {duration}

r_A = 0.55; r_B = 0.55
x_A = 1.50; y_A = r_A + 0.05
x_B = x_A + r_A
mass_side = 0.80
x_spring = x_A - r_A
x_m2 = x_B - r_B
x_m3 = x_B + r_B

y_2_0 = y_B_0 + ROPE_HALF
y_3_0 = y_B_0 + ROPE_HALF
const_A = y_se_0 + y_B_0
C_pulley = y_B_0 - 0.5*(y_2_0 + y_3_0)

def ode(t, y):
    y2, y3, v2, v3 = y
    y_B = 0.5*(y2+y3) + C_pulley
    y_se = const_A - y_B
    L_s = y_floor - y_se
    T_A = k*(L_s - L_0); T_B = 0.5*T_A
    return [v2, v3, g - T_B/m_2, g - T_B/m_3]

MASS_OFFSET = 0.6
def ev_m2_p(t, y):
    y_B = 0.5*(y[0]+y[1]) + C_pulley
    return y[0] - (y_B + MASS_OFFSET)
ev_m2_p.terminal=True; ev_m2_p.direction=-1
def ev_m3_p(t, y):
    y_B = 0.5*(y[0]+y[1]) + C_pulley
    return y[1] - (y_B + MASS_OFFSET)
ev_m3_p.terminal=True; ev_m3_p.direction=-1
def ev_m2_f(t, y): return y_floor - (y[0] + MASS_OFFSET)
ev_m2_f.terminal=True; ev_m2_f.direction=-1
def ev_m3_f(t, y): return y_floor - (y[1] + MASS_OFFSET)
ev_m3_f.terminal=True; ev_m3_f.direction=-1
def ev_spring_min(t, y):
    y_B = 0.5*(y[0]+y[1]) + C_pulley
    return y_floor - (const_A - y_B)
ev_spring_min.terminal=True; ev_spring_min.direction=-1

fps = 30
t_eval = np.linspace(0, duration, int(duration*fps)+1)
sol = solve_ivp(ode, (0,duration), [y_2_0,y_3_0,0.0,0.0], t_eval=t_eval,
                method="RK45", rtol=1e-9, atol=1e-11,
                events=[ev_m2_p, ev_m3_p, ev_m2_f, ev_m3_f, ev_spring_min],
                dense_output=True)
if sol.status == 1:
    t_f = sol.t[-1]; sf = sol.y[:,-1]
    y2_a = np.where(t_eval<=t_f, sol.sol(np.minimum(t_eval,t_f))[0], sf[0])
    y3_a = np.where(t_eval<=t_f, sol.sol(np.minimum(t_eval,t_f))[1], sf[1])
else:
    y2_a, y3_a = sol.y[0], sol.y[1]
yB_a = 0.5*(y2_a+y3_a) + C_pulley
yse_a = const_A - yB_a

fig_w, fig_h = 5.0, 8.0; fa = fig_w/fig_h
xlo_d = min(x_spring, x_m2 - mass_side/2.0) - 0.4
xhi_d = max(x_m3 + mass_side/2.0, x_A + r_A) + 0.4
ylo_d = -0.4
yhi_d = max(y2_a.max(), y3_a.max()) + mass_side + 0.5
dx, dy = xhi_d-xlo_d, yhi_d-ylo_d
if dx/dy < fa:
    e=(fa*dy-dx)/2.0; xlo, xhi, ylo, yhi = xlo_d-e, xhi_d+e, ylo_d, yhi_d
else:
    e=(dx/fa-dy)/2.0; xlo, xhi, ylo, yhi = xlo_d, xhi_d, ylo_d-e, yhi_d+e

fig = plt.figure(figsize=(fig_w,fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1])
ax.set_facecolor("#16213e")
ax.set_xlim(xlo,xhi); ax.set_ylim(yhi,ylo)
ax.set_aspect("equal"); ax.axis("off")

ax.add_patch(patches.Rectangle((xlo,ylo), xhi-xlo, -ylo, facecolor="#4a4e69", edgecolor="none", zorder=0))
ax.plot([xlo,xhi], [0,0], color="#adb5bd", lw=2.2, zorder=1)
ax.add_patch(patches.Rectangle((x_spring-0.20, y_floor-0.05), 0.40, 0.10,
                               facecolor="#adb5bd", edgecolor="none", zorder=2))

ax.plot([x_A,x_A], [0,y_A-r_A], color="#adb5bd", lw=2.5, zorder=2)
ax.add_patch(patches.Circle((x_A,y_A), r_A, facecolor="#4a4e69", edgecolor="white", lw=1.6, zorder=4))
arc_A = patches.Arc((x_A,y_A), 2*r_A, 2*r_A, angle=0, theta1=180, theta2=360, color="#a8dadc", lw=2.5, zorder=5)
ax.add_patch(arc_A)
ax.add_patch(patches.Circle((x_A,y_A), r_A*0.18, facecolor="#1a1a2e", edgecolor="#adb5bd", lw=1.0, zorder=6))

pBb = patches.Circle((x_B,y_B_0), r_B, facecolor="#4a4e69", edgecolor="white", lw=1.6, zorder=4)
arc_B = patches.Arc((x_B,y_B_0), 2*r_B, 2*r_B, angle=0, theta1=180, theta2=360, color="#a8dadc", lw=2.5, zorder=5)
hub_B = patches.Circle((x_B,y_B_0), r_B*0.18, facecolor="#1a1a2e", edgecolor="#adb5bd", lw=1.0, zorder=6)
ax.add_patch(pBb); ax.add_patch(arc_B); ax.add_patch(hub_B)

m2_p = patches.Rectangle((0,0), mass_side, mass_side, facecolor="#e63946", edgecolor="white", lw=1.5, zorder=7)
m3_p = patches.Rectangle((0,0), mass_side, mass_side, facecolor="#f4d35e", edgecolor="white", lw=1.5, zorder=7)
ax.add_patch(m2_p); ax.add_patch(m3_p)

sAL, = ax.plot([],[], "-", color="#a8dadc", lw=2.5, zorder=5)
sAR, = ax.plot([],[], "-", color="#a8dadc", lw=2.5, zorder=5)
rBL, = ax.plot([],[], "-", color="#a8dadc", lw=2.5, zorder=5)
rBR, = ax.plot([],[], "-", color="#a8dadc", lw=2.5, zorder=5)
sp_l, = ax.plot([],[], "-", color="#f4d35e", lw=2.4, zorder=4)

def sp_path(xt, yt, xb, yb, n=10, r=0.10):
    s = np.linspace(0,1, n*20+2)
    pad = 0.08
    env = np.where((s<pad)|(s>1-pad), 0.0, np.sin(n*2*np.pi*(s-pad)/(1-2*pad)))
    return xt + s*(xb-xt) + r*env, yt + s*(yb-yt)

def update(f):
    y_se = yse_a[f]; y_B = yB_a[f]
    y_2 = y2_a[f]; y_3 = y3_a[f]
    pBb.center = (x_B, y_B); hub_B.center = (x_B, y_B); arc_B.set_center((x_B, y_B))
    sAL.set_data([x_spring,x_spring], [y_A, y_se])
    sAR.set_data([x_B,x_B], [y_A, y_B-r_B])
    rBL.set_data([x_m2,x_m2], [y_B, y_2])
    rBR.set_data([x_m3,x_m3], [y_B, y_3])
    sx, sy = sp_path(x_spring, y_se, x_spring, y_floor)
    sp_l.set_data(sx, sy)
    m2_p.set_xy((x_m2-mass_side/2.0, y_2))
    m3_p.set_xy((x_m3-mass_side/2.0, y_3))
    return (pBb, hub_B, arc_B, sAL, sAR, rBL, rBR, sp_l, m2_p, m3_p)

ani = animation.FuncAnimation(fig, update, frames=len(t_eval), interval=1000/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Spring Atwood")
    parser.add_argument("--g", type=float, default=9.8)
    parser.add_argument("--m_2", type=float, default=1.0)
    parser.add_argument("--m_3", type=float, default=1.02)
    parser.add_argument("--k", type=float, default=28.3)
    parser.add_argument("--L_0", type=float, default=0.8)
    parser.add_argument("--y_floor", type=float, default=4.5)
    parser.add_argument("--y_se_0", type=float, default=2.5)
    parser.add_argument("--y_B_0", type=float, default=2.5)
    parser.add_argument("--ROPE_HALF", type=float, default=10.0)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="spring_atwood.mp4")
    args = parser.parse_args()

    p = SpringAtwoodParams(
        g=args.g, m_2=args.m_2, m_3=args.m_3, k=args.k, L_0=args.L_0,
        y_floor=args.y_floor, y_se_0=args.y_se_0, y_B_0=args.y_B_0,
        ROPE_HALF=args.ROPE_HALF,
    )
    print(f"Simulating spring atwood: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
