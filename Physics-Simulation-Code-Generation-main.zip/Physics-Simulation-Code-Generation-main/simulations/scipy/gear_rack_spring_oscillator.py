"""
Gear-Rack-Spring Oscillator.

A circular gear meshes (no slip) with a horizontal rack attached via two
springs to side walls. Equivalent SHO via reflected gear inertia.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon, Circle, Rectangle
from matplotlib.collections import LineCollection
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class GearRackSpringOscillatorParams:
    g: float = 9.8
    m_g: float = 0.50
    R_g: float = 0.20
    m_r: float = 1.00
    k_L: float = 25.0
    k_R: float = 25.0
    x_left_wall: float = -2.50
    x_right_wall: float = 2.50
    L_L: float = 1.50
    L_R: float = 1.50
    gamma: float = 0.30
    v_0: float = 1.5
    x_rack_0: float = 0.0
    rack_length: float = 2.0
    rack_height: float = 0.18
    y_floor: float = 0.0
    N_g: int = 20


def _trajectory(p: GearRackSpringOscillatorParams, duration: float, fps: int):
    I_g = 0.5 * p.m_g * p.R_g**2
    m_eff = p.m_r + I_g / p.R_g**2
    k_eff = p.k_L + p.k_R
    omega_n = np.sqrt(k_eff / m_eff)
    zeta = p.gamma / (2.0 * np.sqrt(k_eff * m_eff))
    omega_d = omega_n * np.sqrt(max(1.0 - zeta**2, 1e-12))
    A_const = p.x_rack_0 - 0.0
    B_const = (p.v_0 + zeta * omega_n * A_const) / omega_d

    t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
    env = np.exp(-zeta * omega_n * t_eval)
    cos_w = np.cos(omega_d * t_eval); sin_w = np.sin(omega_d * t_eval)
    x_arr = env * (A_const * cos_w + B_const * sin_w)
    th_arr = +(x_arr - p.x_rack_0) / p.R_g
    return t_eval, x_arr, th_arr


def simulate(params: GearRackSpringOscillatorParams, duration: float = 12.0, fps: int = 30):
    t, x, th = _trajectory(params, duration, fps)
    return t, np.vstack([x, th])


def render_video(t, y, params: GearRackSpringOscillatorParams, output_path: str, fps: int = 30):
    p = params
    x_arr, th_arr = y[0], y[1]
    R_g = p.R_g; N_g = int(p.N_g)
    pitch_p = 2.0 * np.pi * R_g / N_g
    addendum = 0.020; dedendum = 0.020; tooth_frac = 0.50

    def gear_polygon(cx, cy, R, N, theta=0.0):
        r_add = R + addendum
        r_ded = R - dedendum
        pitch = 2.0 * np.pi / N
        phi = 0.5 * tooth_frac * pitch
        pts = np.empty((4 * N, 2))
        for i in range(N):
            theta_c = i * pitch + theta
            for k, (r, dphi) in enumerate(((r_ded, -phi), (r_add, -phi),
                                            (r_add, +phi), (r_ded, +phi))):
                ang = theta_c + dphi
                pts[4 * i + k, 0] = cx + r * np.cos(ang)
                pts[4 * i + k, 1] = cy + r * np.sin(ang)
        return pts

    rack_tooth_h = 0.020
    rack_tooth_half = 0.5 * (tooth_frac * pitch_p) / 2.0
    N_rack = int(np.ceil(p.rack_length / pitch_p)) + 4
    phase_offset = 0.5 * pitch_p
    rack_length = p.rack_length; rack_height = p.rack_height; y_floor = p.y_floor

    def rack_polygon(xc):
        half = rack_length / 2.0
        y_bot = y_floor; y_top = y_floor + rack_height
        bottom = np.array([[xc - half, y_bot], [xc + half, y_bot]])
        profile = [[xc - half, y_top]]
        for k in range(N_rack):
            x_crest_center = xc + (k - N_rack / 2.0) * pitch_p + phase_offset
            x_l = x_crest_center - rack_tooth_half
            x_r = x_crest_center + rack_tooth_half
            if x_r < xc - half or x_l > xc + half:
                continue
            x_l_c = max(x_l, xc - half); x_r_c = min(x_r, xc + half)
            profile.append([x_l_c, y_top])
            profile.append([x_l_c, y_top + rack_tooth_h])
            profile.append([x_r_c, y_top + rack_tooth_h])
            profile.append([x_r_c, y_top])
        profile.append([xc + half, y_top])
        top = np.array(profile[::-1])
        return np.vstack([bottom, top])

    def spring_path(x1, x2, yc, n=10, r=0.06):
        if abs(x2 - x1) < 1e-6:
            return np.array([[x1, yc], [x2, yc]])
        t = np.linspace(0.0, 1.0, n * 20 + 2)
        lead = 0.08
        env_t = (t - lead) / (1.0 - 2.0 * lead)
        env = np.where((t < lead) | (t > 1.0 - lead), 0.0,
                       np.sin(n * 2.0 * np.pi * env_t))
        xs = x1 + t * (x2 - x1); ys = yc + r * env
        return np.column_stack([xs, ys])

    gear_cx = 0.0
    gear_cy = y_floor + rack_height + R_g
    x_lo = p.x_left_wall - 0.20; x_hi = p.x_right_wall + 0.20
    y_lo = y_floor - 0.45; y_hi = gear_cy + R_g + addendum + 0.30
    fig_w, fig_h = 10.0, 5.0
    fig_aspect = fig_w / fig_h
    dx = x_hi - x_lo; dy = y_hi - y_lo
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo -= extra; x_hi += extra
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        y_lo -= extra; y_hi += extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")
    ax.add_patch(Rectangle((x_lo, y_lo), x_hi - x_lo, y_floor - y_lo,
                           facecolor="#0f1626", edgecolor="none", zorder=1))
    ax.plot([x_lo, x_hi], [y_floor, y_floor], color="#4a4e69", lw=2.0, zorder=1.5)
    wall_w = 0.12
    wall_h_top = gear_cy + R_g + 0.05
    ax.add_patch(Rectangle((p.x_left_wall - wall_w, y_floor), wall_w,
                           wall_h_top - y_floor, facecolor="#4a4e69",
                           edgecolor="#adb5bd", lw=1.0, hatch="////", zorder=2))
    ax.add_patch(Rectangle((p.x_right_wall, y_floor), wall_w,
                           wall_h_top - y_floor, facecolor="#4a4e69",
                           edgecolor="#adb5bd", lw=1.0, hatch="////", zorder=2))
    gear_patch = Polygon(gear_polygon(gear_cx, gear_cy, R_g, N_g),
                         facecolor="#a8dadc", edgecolor="#adb5bd",
                         lw=1.2, zorder=4)
    ax.add_patch(gear_patch)
    ax.add_patch(Circle((gear_cx, gear_cy), R_g - dedendum * 1.4,
                        facecolor="#3a4357", edgecolor="none", zorder=4.2))
    spokes = [ax.plot([], [], color="#e63946", lw=2.6, zorder=4.5)[0] for _ in range(4)]
    ax.add_patch(Circle((gear_cx, gear_cy), 0.035, facecolor="#e63946",
                        edgecolor="#adb5bd", lw=0.8, zorder=4.8))
    rack_patch = Polygon(rack_polygon(p.x_rack_0), facecolor="#a8dadc",
                         edgecolor="#adb5bd", lw=1.2, zorder=3)
    ax.add_patch(rack_patch)
    rack_hatch_lc = LineCollection([], colors="#4a4e69", linewidths=1.2, zorder=3.2)
    ax.add_collection(rack_hatch_lc)
    y_spring = y_floor + rack_height * 0.5
    spring_L_line, = ax.plot([], [], color="#a8dadc", lw=2.0, zorder=2.5)
    spring_R_line, = ax.plot([], [], color="#a8dadc", lw=2.0, zorder=2.5)

    def update(f):
        xc = x_arr[f]; th = th_arr[f]
        gear_patch.set_xy(gear_polygon(gear_cx, gear_cy, R_g, N_g, theta=th))
        for i, sp in enumerate(spokes):
            ang = th + i * (np.pi / 2.0)
            sp.set_data([gear_cx, gear_cx + (R_g - dedendum * 1.5) * np.cos(ang)],
                        [gear_cy, gear_cy + (R_g - dedendum * 1.5) * np.sin(ang)])
        rack_patch.set_xy(rack_polygon(xc))
        half = rack_length / 2.0
        n_ticks = 11
        tick_xs = np.linspace(xc - half + 0.10, xc + half - 0.10, n_ticks)
        tick_y0 = y_floor + 0.005; tick_y1 = y_floor + rack_height * 0.45
        rack_hatch_lc.set_segments([[(tx, tick_y0), (tx, tick_y1)] for tx in tick_xs])
        sL = spring_path(p.x_left_wall, xc - half, y_spring, n=10, r=0.07)
        sR = spring_path(xc + half, p.x_right_wall, y_spring, n=10, r=0.07)
        spring_L_line.set_data(sL[:, 0], sL[:, 1])
        spring_R_line.set_data(sR[:, 0], sR[:, 1])
        return (gear_patch, rack_patch, rack_hatch_lc,
                spring_L_line, spring_R_line, *spokes)

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0 / fps, blit=False)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: GearRackSpringOscillatorParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Gear-rack-spring oscillator standalone script."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.patches import Polygon, Circle, Rectangle
from matplotlib.collections import LineCollection

g = {p["g"]}
m_g = {p["m_g"]}
R_g = {p["R_g"]}
m_r = {p["m_r"]}
k_L = {p["k_L"]}
k_R = {p["k_R"]}
x_left_wall = {p["x_left_wall"]}
x_right_wall = {p["x_right_wall"]}
L_L = {p["L_L"]}
L_R = {p["L_R"]}
gamma = {p["gamma"]}
v_0 = {p["v_0"]}
x_rack_0 = {p["x_rack_0"]}
rack_length = {p["rack_length"]}
rack_height = {p["rack_height"]}
y_floor = {p["y_floor"]}
N_g = {int(p["N_g"])}
duration = {duration}
fps = 30

I_g = 0.5*m_g*R_g**2
m_eff = m_r + I_g/R_g**2
k_eff = k_L + k_R
omega_n = np.sqrt(k_eff/m_eff)
zeta = gamma/(2.0*np.sqrt(k_eff*m_eff))
omega_d = omega_n*np.sqrt(max(1.0-zeta**2, 1e-12))
A_const = x_rack_0 - 0.0
B_const = (v_0 + zeta*omega_n*A_const)/omega_d

t_eval = np.linspace(0.0, duration, int(duration*fps)+1)
env = np.exp(-zeta*omega_n*t_eval)
cos_w = np.cos(omega_d*t_eval); sin_w = np.sin(omega_d*t_eval)
x_arr = env*(A_const*cos_w + B_const*sin_w)
th_arr = +(x_arr - x_rack_0)/R_g

pitch_p = 2.0*np.pi*R_g/N_g
addendum = 0.020; dedendum = 0.020; tooth_frac = 0.50

def gear_polygon(cx, cy, R, N, theta=0.0):
    r_add = R+addendum; r_ded = R-dedendum
    pitch = 2.0*np.pi/N
    phi = 0.5*tooth_frac*pitch
    pts = np.empty((4*N, 2))
    for i in range(N):
        theta_c = i*pitch + theta
        for k, (r, dphi) in enumerate(((r_ded,-phi),(r_add,-phi),(r_add,+phi),(r_ded,+phi))):
            ang = theta_c+dphi
            pts[4*i+k,0] = cx + r*np.cos(ang)
            pts[4*i+k,1] = cy + r*np.sin(ang)
    return pts

rack_tooth_h = 0.020
rack_tooth_half = 0.5*(tooth_frac*pitch_p)/2.0
N_rack = int(np.ceil(rack_length/pitch_p)) + 4
phase_offset = 0.5*pitch_p

def rack_polygon(xc):
    half = rack_length/2.0
    y_bot = y_floor; y_top = y_floor + rack_height
    bottom = np.array([[xc-half, y_bot],[xc+half, y_bot]])
    profile = [[xc-half, y_top]]
    for k in range(N_rack):
        x_crest_center = xc + (k - N_rack/2.0)*pitch_p + phase_offset
        x_l = x_crest_center - rack_tooth_half
        x_r = x_crest_center + rack_tooth_half
        if x_r < xc-half or x_l > xc+half: continue
        x_l_c = max(x_l, xc-half); x_r_c = min(x_r, xc+half)
        profile.append([x_l_c, y_top])
        profile.append([x_l_c, y_top+rack_tooth_h])
        profile.append([x_r_c, y_top+rack_tooth_h])
        profile.append([x_r_c, y_top])
    profile.append([xc+half, y_top])
    top = np.array(profile[::-1])
    return np.vstack([bottom, top])

def spring_path(x1, x2, yc, n=10, r=0.06):
    if abs(x2-x1) < 1e-6:
        return np.array([[x1,yc],[x2,yc]])
    t = np.linspace(0.0,1.0, n*20+2)
    lead = 0.08
    env_t = (t-lead)/(1.0-2.0*lead)
    env = np.where((t<lead)|(t>1.0-lead), 0.0, np.sin(n*2.0*np.pi*env_t))
    xs = x1 + t*(x2-x1); ys = yc + r*env
    return np.column_stack([xs, ys])

gear_cx = 0.0
gear_cy = y_floor + rack_height + R_g
x_lo = x_left_wall - 0.20; x_hi = x_right_wall + 0.20
y_lo = y_floor - 0.45; y_hi = gear_cy + R_g + addendum + 0.30
fig_w, fig_h = 10.0, 5.0
fig_aspect = fig_w/fig_h
dx = x_hi-x_lo; dy = y_hi-y_lo
if dx/dy < fig_aspect:
    extra = (fig_aspect*dy-dx)/2.0
    x_lo -= extra; x_hi += extra
else:
    extra = (dx/fig_aspect-dy)/2.0
    y_lo -= extra; y_hi += extra

fig = plt.figure(figsize=(fig_w,fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(Rectangle((x_lo,y_lo), x_hi-x_lo, y_floor-y_lo,
                       facecolor="#0f1626", edgecolor="none", zorder=1))
ax.plot([x_lo,x_hi],[y_floor,y_floor], color="#4a4e69", lw=2.0, zorder=1.5)
wall_w = 0.12
wall_h_top = gear_cy + R_g + 0.05
ax.add_patch(Rectangle((x_left_wall-wall_w, y_floor), wall_w, wall_h_top-y_floor,
                       facecolor="#4a4e69", edgecolor="#adb5bd", lw=1.0,
                       hatch="////", zorder=2))
ax.add_patch(Rectangle((x_right_wall, y_floor), wall_w, wall_h_top-y_floor,
                       facecolor="#4a4e69", edgecolor="#adb5bd", lw=1.0,
                       hatch="////", zorder=2))
gear_patch = Polygon(gear_polygon(gear_cx, gear_cy, R_g, N_g),
                     facecolor="#a8dadc", edgecolor="#adb5bd", lw=1.2, zorder=4)
ax.add_patch(gear_patch)
ax.add_patch(Circle((gear_cx, gear_cy), R_g - dedendum*1.4,
                    facecolor="#3a4357", edgecolor="none", zorder=4.2))
spokes = [ax.plot([],[], color="#e63946", lw=2.6, zorder=4.5)[0] for _ in range(4)]
ax.add_patch(Circle((gear_cx, gear_cy), 0.035, facecolor="#e63946",
                    edgecolor="#adb5bd", lw=0.8, zorder=4.8))
rack_patch = Polygon(rack_polygon(x_rack_0), facecolor="#a8dadc",
                     edgecolor="#adb5bd", lw=1.2, zorder=3)
ax.add_patch(rack_patch)
rack_hatch_lc = LineCollection([], colors="#4a4e69", linewidths=1.2, zorder=3.2)
ax.add_collection(rack_hatch_lc)
y_spring = y_floor + rack_height*0.5
spring_L_line, = ax.plot([],[], color="#a8dadc", lw=2.0, zorder=2.5)
spring_R_line, = ax.plot([],[], color="#a8dadc", lw=2.0, zorder=2.5)

def update(f):
    xc = x_arr[f]; th = th_arr[f]
    gear_patch.set_xy(gear_polygon(gear_cx, gear_cy, R_g, N_g, theta=th))
    for i, sp in enumerate(spokes):
        ang = th + i*(np.pi/2.0)
        sp.set_data([gear_cx, gear_cx + (R_g - dedendum*1.5)*np.cos(ang)],
                    [gear_cy, gear_cy + (R_g - dedendum*1.5)*np.sin(ang)])
    rack_patch.set_xy(rack_polygon(xc))
    half = rack_length/2.0
    n_ticks = 11
    tick_xs = np.linspace(xc-half+0.10, xc+half-0.10, n_ticks)
    tick_y0 = y_floor + 0.005; tick_y1 = y_floor + rack_height*0.45
    rack_hatch_lc.set_segments([[(tx,tick_y0),(tx,tick_y1)] for tx in tick_xs])
    sL = spring_path(x_left_wall, xc-half, y_spring, n=10, r=0.07)
    sR = spring_path(xc+half, x_right_wall, y_spring, n=10, r=0.07)
    spring_L_line.set_data(sL[:,0], sL[:,1])
    spring_R_line.set_data(sR[:,0], sR[:,1])
    return (gear_patch, rack_patch, rack_hatch_lc,
            spring_L_line, spring_R_line, *spokes)

ani = animation.FuncAnimation(fig, update, frames=len(t_eval),
                              interval=1000.0/fps, blit=False)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    for fld, dflt in [("g",9.8),("m_g",0.50),("R_g",0.20),("m_r",1.00),
                       ("k_L",25.0),("k_R",25.0),("x_left_wall",-2.50),
                       ("x_right_wall",2.50),("L_L",1.50),("L_R",1.50),
                       ("gamma",0.30),("v_0",1.5),("x_rack_0",0.0),
                       ("rack_length",2.0),("rack_height",0.18),("y_floor",0.0)]:
        parser.add_argument(f"--{fld}", type=float, default=dflt)
    parser.add_argument("--N_g", type=int, default=20)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="gear_rack_spring_oscillator.mp4")
    args = parser.parse_args()
    p = GearRackSpringOscillatorParams(
        g=args.g, m_g=args.m_g, R_g=args.R_g, m_r=args.m_r,
        k_L=args.k_L, k_R=args.k_R, x_left_wall=args.x_left_wall,
        x_right_wall=args.x_right_wall, L_L=args.L_L, L_R=args.L_R,
        gamma=args.gamma, v_0=args.v_0, x_rack_0=args.x_rack_0,
        rack_length=args.rack_length, rack_height=args.rack_height,
        y_floor=args.y_floor, N_g=args.N_g)
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
