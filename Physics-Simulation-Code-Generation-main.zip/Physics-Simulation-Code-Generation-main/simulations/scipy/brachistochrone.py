"""
Brachistochrone Simulation
==========================
Faithfully translated from myphysicslab/src/sims/roller/BrachistoSim.ts

Physical Law: Euler-Lagrange equations for a ball constrained to a cycloid curve.

The brachistochrone (Greek: shortest time) is the curve of fastest descent between
two points under gravity alone.  It is a cycloid:

    x(theta) = r*(theta - sin(theta))
    y(theta) = r*(1 - cos(theta))      [y measured downward from start]

Parametric tangent:
    dx/dtheta = r*(1 - cos(theta))
    dy/dtheta = r*sin(theta)

Arc-length element:
    ds/dtheta = sqrt((dx/dtheta)^2 + (dy/dtheta)^2)
              = r*sqrt(2*(1-cos(theta)))
              = 2*r*sin(theta/2)          [for theta in [0, 2*pi]]

Derivation (Lagrangian in theta, with theta as generalised coordinate):
    ds/dtheta = S1 = 2*r*sin(theta/2)
    d(S1)/dtheta = S2 = r*cos(theta/2)

    Lagrange: S1^2 * alpha + S1 * S2 * omega^2 = -g*(dy/dtheta) - (b/m)*S1*omega

    Solving for alpha:
        alpha = [-g*(dy/dtheta) - (b/m)*S1*omega - S1*S2*omega^2] / S1^2

    where dy/dtheta = r*sin(theta)  (positive = downward = gravity-driven)

State vector: [theta, omega]  where omega = dtheta/dt
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from dataclasses import dataclass, asdict
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from .draw_utils import setup_dark_axis


@dataclass
class BrachistochroneParams:
    r: float      = 2.0    # cycloid radius (m)
    m: float      = 1.0    # ball mass (kg)
    b: float      = 0.05   # linear damping coefficient
    g: float      = 9.8    # gravitational acceleration (m/s^2)
    theta0: float = 0.1    # initial cycloid parameter (rad)
    omega0: float = 0.0    # initial dtheta/dt (rad/s)


def _cycloid(theta: np.ndarray, r: float):
    """Return (x, y) on the cycloid; y positive downward."""
    x = r * (theta - np.sin(theta))
    y = r * (1.0 - np.cos(theta))
    return x, y


def ode(t: float, y: list, p: BrachistochroneParams):
    """
    ODE for a ball rolling on a cycloid track.
    Derived from the Lagrangian with theta as the generalised coordinate.

    dtheta/dt = omega
    domega/dt = alpha = [-g*(dy/dtheta) - (b/m)*S1*omega - S1*S2*omega^2] / S1^2
    """
    theta, omega = y

    # Guard against theta = 0 (start of cycloid) where S1 -> 0
    half_theta = 0.5 * theta
    sin_h = np.sin(half_theta)
    cos_h = np.cos(half_theta)

    S1 = 2.0 * p.r * sin_h          # ds/dtheta
    S2 = p.r * cos_h                 # d(S1)/dtheta

    dydtheta = p.r * np.sin(theta)   # y measured downward: dy/dθ > 0 for θ∈(0,π)

    # Lagrangian gives:  S1² θ̈ + S1·S2·θ̇² = +g·(dy/dθ)   when y is downward-positive
    # (the +sign drives the ball toward the bottom cusp at θ=π, away from θ=0).
    S1_sq = S1 * S1
    if S1_sq < 1e-14:
        # Numerical guard only — should almost never trigger since we integrate
        # away from θ=0. Use the isochronous-cycloid limiting frequency:
        # in the canonical u = 4r(1 − cos(θ/2)) coordinate, ü = −(g/4r)(u−4r).
        alpha = p.g / (2.0 * p.r)    # finite positive push
    else:
        drag  = (p.b / p.m) * S1 * omega
        alpha = (p.g * dydtheta - drag - S1 * S2 * omega * omega) / S1_sq

    return [omega, alpha]


def simulate(
    params: BrachistochroneParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Integrate the ODE using RK45.
    Returns (t, y) where y.shape = (2, N): [theta, omega] at each time step.
    """
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode,
        (0, duration),
        [params.theta0, params.omega0],
        t_eval=t_eval,
        args=(params,),
        method="RK45",
        rtol=1e-8,
        atol=1e-10,
        dense_output=False,
    )
    return sol.t, sol.y


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: BrachistochroneParams,
    output_path: str,
    fps: int = 30,
    trail_len: int = 60,
) -> None:
    """Render an MP4 video of the ball rolling along the cycloid."""
    theta = y[0]
    x_ball, y_ball_down = _cycloid(theta, params.r)
    # Flip so that the ball moves rightward and downward in screen coordinates.
    # Use y-screen = -y_down (y_down is already "down"), giving a natural view.
    y_ball = -y_ball_down

    # Static track: theta from 0 to 2*pi (full arch)
    th_track = np.linspace(0, 2.0 * np.pi, 600)
    x_track, y_track_down = _cycloid(th_track, params.r)
    y_track = -y_track_down

    pad_x = params.r * 0.3
    pad_y = params.r * 0.3
    xlim = (x_track.min() - pad_x, x_track.max() + pad_x)
    ylim = (y_track.min() - pad_y, y_track.max() + pad_y)

    fig, ax = plt.subplots(figsize=(8, 5))
    setup_dark_axis(fig, ax, xlim, ylim)

    # Static track
    ax.plot(x_track, y_track, "-", color="#a8dadc", lw=2.0, zorder=2, alpha=0.7)
    # Mark start and end points
    ax.plot(x_track[0],  y_track[0],  "o", color="#f4d35e", ms=8, zorder=6)
    ax.plot(x_track[-1], y_track[-1], "o", color="#f4d35e", ms=8, zorder=6)

    # Animated elements
    (ball,)  = ax.plot([], [], "o", color="#e63946", ms=12, zorder=5)
    (trail,) = ax.plot([], [], "-", color="#e63946", alpha=0.4, lw=1.5, zorder=4)

    trail_x: list = []
    trail_y: list = []

    def init():
        ball.set_data([], [])
        trail.set_data([], [])
        return ball, trail

    def update(frame):
        bx = x_ball[frame]
        by = y_ball[frame]
        ball.set_data([bx], [by])
        trail_x.append(bx)
        trail_y.append(by)
        if len(trail_x) > trail_len:
            trail_x.pop(0)
            trail_y.pop(0)
        trail.set_data(trail_x, trail_y)
        return ball, trail

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), init_func=init, interval=1000 / fps, blit=True
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: BrachistochroneParams, duration: float = 12.0) -> str:
    """Return a self-contained Python script string with parameter values embedded."""
    p = asdict(params)
    return f'''"""
Brachistochrone (Cycloid) — auto-generated simulation script.
Physics:  domega/dt = [-g*(dy/dtheta) - (b/m)*S1*omega - S1*S2*omega^2] / S1^2
Track:    x=r*(theta-sin(theta)),  y=-r*(1-cos(theta))  [screen coords]
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation

# ── Physical parameters ─────────────────────────────────────────────────────
r      = {p["r"]}      # cycloid radius (m)
m      = {p["m"]}      # ball mass (kg)
b      = {p["b"]}      # damping coefficient
g      = {p["g"]}      # gravitational acceleration (m/s^2)
theta0 = {p["theta0"]:.6f}  # initial cycloid parameter (rad)
omega0 = {p["omega0"]:.6f}  # initial angular rate (rad/s)
duration = {duration}

# ── Cycloid helpers ───────────────────────────────────────────────────────────
def cycloid(theta):
    x = r * (theta - np.sin(theta))
    y = r * (1.0 - np.cos(theta))
    return x, y

# ── ODE system ───────────────────────────────────────────────────────────────
# Lagrangian with theta as generalised coord, y measured *downward*-positive:
#   S1² · θ̈ + S1·S2·θ̇² = +g·(dy/dθ) − (b/m)·S1·θ̇.
# Sign is +g·(dy/dθ) so the ball is pushed away from the upper cusp (θ=0)
# toward the bottom of the cycloid arch (θ=π).
def ode(t, state):
    theta, omega = state
    half = 0.5 * theta
    S1 = 2.0 * r * np.sin(half)
    S2 = r * np.cos(half)
    dydth = r * np.sin(theta)
    S1_sq = S1 * S1
    if S1_sq < 1e-14:
        alpha = g / (2.0 * r)
    else:
        drag  = (b / m) * S1 * omega
        alpha = (g * dydth - drag - S1 * S2 * omega * omega) / S1_sq
    return [omega, alpha]

# ── Integrate ────────────────────────────────────────────────────────────────
fps    = 30
t_eval = np.linspace(0, duration, int(duration * fps) + 1)
sol    = solve_ivp(ode, (0, duration), [theta0, omega0],
                   t_eval=t_eval, method="RK45", rtol=1e-8, atol=1e-10)
t, theta_arr = sol.t, sol.y[0]
x_ball, y_down = cycloid(theta_arr)
y_ball = -y_down   # screen coords: up is positive

# ── Static track ─────────────────────────────────────────────────────────────
th_tr  = np.linspace(0, 2*np.pi, 600)
x_tr, y_tr_d = cycloid(th_tr)
y_tr   = -y_tr_d

# ── Animate ──────────────────────────────────────────────────────────────────
pad = r * 0.3
fig, ax = plt.subplots(figsize=(8, 5), facecolor="#1a1a2e")
ax.set_facecolor("#16213e")
ax.set_xlim(x_tr.min() - pad, x_tr.max() + pad)
ax.set_ylim(y_tr.min() - pad, y_tr.max() + pad)
ax.set_aspect("equal"); ax.axis("off")
ax.plot(x_tr, y_tr, "-", color="#a8dadc", lw=2.0, alpha=0.7)

ball,  = ax.plot([], [], "o", color="#e63946", ms=12, zorder=5)
trail, = ax.plot([], [], "-", color="#e63946", alpha=0.4, lw=1.5)
tx, ty = [], []

def update(frame):
    ball.set_data([x_ball[frame]], [y_ball[frame]])
    tx.append(x_ball[frame]); ty.append(y_ball[frame])
    if len(tx) > 60: tx.pop(0); ty.pop(0)
    trail.set_data(tx, ty)
    return ball, trail

ani = animation.FuncAnimation(fig, update, frames=len(t), interval=1000/fps, blit=True)
writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
ani.save("brachistochrone.mp4", writer=writer, dpi=120)
plt.close()
print("Saved brachistochrone.mp4")
'''


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Brachistochrone (Cycloid) Simulation")
    parser.add_argument("--r",        type=float, default=2.0)
    parser.add_argument("--m",        type=float, default=1.0)
    parser.add_argument("--b",        type=float, default=0.05)
    parser.add_argument("--g",        type=float, default=9.8)
    parser.add_argument("--theta0",   type=float, default=0.1)
    parser.add_argument("--omega0",   type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output",   type=str,   default="brachistochrone.mp4")
    args = parser.parse_args()

    p = BrachistochroneParams(
        r=args.r, m=args.m, b=args.b, g=args.g,
        theta0=args.theta0, omega0=args.omega0,
    )
    print(f"Simulating brachistochrone: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
