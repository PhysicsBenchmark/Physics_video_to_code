"""
Cart-Pendulum Simulation
========================
Faithfully translated from myphysicslab/src/sims/pendulum/CartPendulumSim.ts

Physical Law: Lagrangian Mechanics for constrained system
    Generalized coordinates: x (cart displacement from spring equilibrium), h (pendulum angle)

Lagrangian L = T - V:
    T = ½M ẋ² + ½m[(ẋ + Lḣcos(h))² + (Lḣsin(h))²]
    V = ½kx² - mgL cos(h)

Euler-Lagrange equations give (verbatim from CartPendulumSim.ts evaluate()):

    ẍ = (m ḣ² L sin(h) + m g sin(h)cos(h) - kx - d_c ẋ + b ḣ cos(h)/L)
        / (M + m sin²(h))

    ḧ = (-m ḣ² L sin(h)cos(h) + kx cos(h) - (M+m) g sin(h)
         + d_c ẋ cos(h) - (m+M) b ḣ/(mL))
        / (L (M + m sin²(h)))

State vector: [x, h, v=ẋ, w=ḣ]
Note: x=0 is the spring equilibrium (spring force = -kx).
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis, spring_path


@dataclass
class CartPendulumParams:
    M: float = 1.0          # cart mass (kg)
    m: float = 1.0          # pendulum bob mass (kg)
    L: float = 1.0          # pendulum rod length (m)
    k: float = 6.0          # spring stiffness (N/m)  [TS default]
    g: float = 9.8          # gravity (m/s²)
    d_c: float = 0.0        # cart damping coefficient (kg/s)
    b: float = 0.0          # pendulum damping coefficient (kg·m²/s)
    x0: float = 1.0         # initial cart displacement from equilibrium (m)
    h0: float = 0.0         # initial pendulum angle (rad)
    v0: float = 0.0         # initial cart velocity (m/s)
    w0: float = 0.0         # initial pendulum angular velocity (rad/s)


def ode(t: float, y: list, p: CartPendulumParams):
    """
    Exact translation of CartPendulumSim.ts evaluate() method.

    change[X]  = vars[XP]        →  ẋ = v
    change[H]  = vars[HP]        →  ḣ = w
    change[XP] = numer / (M + m*sin²(h))
    change[HP] = numer / (L*(M + m*sin²(h)))
    """
    x, h, v, w = y
    M, m, L, k, g = p.M, p.m, p.L, p.k, p.g
    d_c, b = p.d_c, p.b

    sh = np.sin(h)
    csh = np.cos(h)
    denom = M + m * sh * sh

    numer_v = (
        m * w * w * L * sh
        + m * g * sh * csh
        - k * x
        - d_c * v
        + b * w * csh / L
    )
    dv = numer_v / denom

    numer_w = (
        -m * w * w * L * sh * csh
        + k * x * csh
        - (M + m) * g * sh
        + d_c * v * csh
        - (m + M) * b * w / (m * L)
    )
    dw = numer_w / (L * denom)

    return [v, w, dv, dw]


def simulate(
    params: CartPendulumParams,
    duration: float = 15.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Integrate using RK45. Returns (t, y) with y.shape = (4, N)."""
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode,
        (0, duration),
        [params.x0, params.h0, params.v0, params.w0],
        t_eval=t_eval,
        args=(params,),
        method="RK45",
        rtol=1e-9,
        atol=1e-11,
    )
    return sol.t, sol.y


def energy(t: np.ndarray, y: np.ndarray, p: CartPendulumParams):
    x, h, v, w = y
    # Velocities of cart and pendulum bob
    vbob_x = v + p.L * w * np.cos(h)
    vbob_y = p.L * w * np.sin(h)
    KE = 0.5 * p.M * v**2 + 0.5 * p.m * (vbob_x**2 + vbob_y**2)
    PE = 0.5 * p.k * x**2 - p.m * p.g * p.L * np.cos(h)
    return KE, PE, KE + PE


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: CartPendulumParams,
    output_path: str,
    fps: int = 30,
) -> None:
    """Render cart-pendulum animation: track + spring + cart + pendulum."""
    x, h = y[0], y[1]

    # Visual layout
    cart_w, cart_h = 0.6, 0.3
    track_y = 0.0
    cart_center_y = track_y + cart_h / 2
    # Wall (spring fixed point) position
    wall_x = -3.0
    # Cart equilibrium at x=0 in physics coords, map to x_vis = x (direct)

    total_L = params.L
    x_max = max(3.5, np.max(np.abs(x)) + 1.2)

    xlim = (wall_x - 0.3, x_max)
    ylim = (-total_L * 1.3, total_L * 0.4 + cart_h)

    fig, ax = plt.subplots(figsize=(8, 5))
    setup_dark_axis(fig, ax, xlim, ylim)

    # Static track
    ax.axhline(track_y, color="#4a4e69", lw=1.5, zorder=1)
    # Wall
    wall_rect = patches.Rectangle(
        (wall_x - 0.15, track_y - 0.6), 0.15, 1.2,
        facecolor="#4a4e69", edgecolor="#adb5bd", lw=1, hatch="////",
    )
    ax.add_patch(wall_rect)

    # Animated: spring, cart, rod, bob
    (spring_line,) = ax.plot([], [], "-", color="#a8dadc", lw=2, zorder=2)
    cart_patch = patches.FancyBboxPatch(
        (-cart_w / 2, cart_center_y - cart_h / 2),
        cart_w, cart_h,
        boxstyle="round,pad=0.02",
        linewidth=1.5, edgecolor="white", facecolor="#457b9d",
    )
    ax.add_patch(cart_patch)
    wheel1 = plt.Circle((-cart_w / 3, track_y), 0.07, color="#a8dadc", zorder=3)
    wheel2 = plt.Circle(( cart_w / 3, track_y), 0.07, color="#a8dadc", zorder=3)
    ax.add_patch(wheel1)
    ax.add_patch(wheel2)
    (rod,) = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
    (bob,) = ax.plot([], [], "o", color="#e63946", ms=14, zorder=4)

    def init():
        spring_line.set_data([], [])
        rod.set_data([], [])
        bob.set_data([], [])
        return spring_line, rod, bob

    def update(frame):
        cx = x[frame]
        cy = cart_center_y
        # Update cart position
        cart_patch.set_x(cx - cart_w / 2)
        wheel1.center = (cx - cart_w / 3, track_y)
        wheel2.center = (cx + cart_w / 3, track_y)
        # Spring from wall to cart left edge
        sx, sy = spring_path(wall_x, cy, cx - cart_w / 2, cy, n_coils=6, coil_radius=0.12)
        spring_line.set_data(sx, sy)
        # Pendulum
        bx = cx + params.L * np.sin(h[frame])
        by = cy - params.L * np.cos(h[frame])
        rod.set_data([cx, bx], [cy, by])
        bob.set_data([bx], [by])
        return spring_line, rod, bob

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), init_func=init, interval=1000 / fps, blit=False
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: CartPendulumParams, duration: float = 15.0) -> str:
    p = asdict(params)
    return f'''"""
Cart-Pendulum — auto-generated simulation script.
Physics (Lagrangian mechanics):
  ẍ = (mẇ²L sin(h) + mg sin(h)cos(h) - kx - d_c ẋ + b ẇ cos(h)/L)
      / (M + m sin²(h))
  ḧ = (-mẇ²L sin(h)cos(h) + kx cos(h) - (M+m)g sin(h) + d_c ẋ cos(h) - (m+M)b ẇ/(mL))
      / (L(M + m sin²(h)))
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

M, m, L = {p["M"]}, {p["m"]}, {p["L"]}  # masses (kg), rod length (m)
k       = {p["k"]}                        # spring stiffness (N/m)
g       = {p["g"]}                        # gravity (m/s²)
d_c     = {p["d_c"]}                      # cart damping
b       = {p["b"]}                        # pendulum damping
x0, h0  = {p["x0"]:.6f}, {p["h0"]:.6f}   # initial conditions
v0, w0  = {p["v0"]:.6f}, {p["w0"]:.6f}
duration = {duration}

def ode(t, y):
    x, h, v, w = y
    sh, csh = np.sin(h), np.cos(h)
    denom = M + m*sh*sh
    dv = (m*w*w*L*sh + m*g*sh*csh - k*x - d_c*v + b*w*csh/L) / denom
    dw = (-m*w*w*L*sh*csh + k*x*csh - (M+m)*g*sh + d_c*v*csh - (m+M)*b*w/(m*L)) / (L*denom)
    return [v, w, dv, dw]

fps = 30
t_eval = np.linspace(0, duration, int(duration*fps)+1)
sol = solve_ivp(ode,(0,duration),[x0,h0,v0,w0],t_eval=t_eval,method="RK45",rtol=1e-9,atol=1e-11)
x_arr, h_arr = sol.y[0], sol.y[1]

cart_w, cart_h = 0.6, 0.3
track_y, wall_x = 0.0, -3.0
cy = cart_h/2
fig, ax = plt.subplots(figsize=(8,5),facecolor="#1a1a2e")
ax.set_facecolor("#16213e"); ax.set_xlim(wall_x-0.3, max(3.5,np.max(np.abs(x_arr))+1.2))
ax.set_ylim(-L*1.3, L*0.4+cart_h); ax.set_aspect("equal"); ax.axis("off")
ax.axhline(track_y,color="#4a4e69",lw=1.5,zorder=1)
ax.add_patch(patches.Rectangle((wall_x-0.15,track_y-0.6),0.15,1.2,
    facecolor="#4a4e69",edgecolor="#adb5bd",lw=1,hatch="////"))

def spring_path_fn(x1,x2,n=6,r=0.12):
    t=np.linspace(0,1,n*20+2); m2=(1-2*0.08)
    env=np.where((t<0.08)|(t>0.92),0,np.sin(n*2*np.pi*(t-0.08)/m2))
    return x1+t*(x2-x1)+r*env*0, np.full_like(t,cy)

sp,   = ax.plot([],[],"-",color="#a8dadc",lw=2,zorder=2)
cpatch = patches.FancyBboxPatch((-cart_w/2,cy-cart_h/2),cart_w,cart_h,
    boxstyle="round,pad=0.02",lw=1.5,edgecolor="white",facecolor="#457b9d")
ax.add_patch(cpatch)
w1=plt.Circle((-cart_w/3,track_y),0.07,color="#a8dadc",zorder=3)
w2=plt.Circle(( cart_w/3,track_y),0.07,color="#a8dadc",zorder=3)
ax.add_patch(w1); ax.add_patch(w2)
rod, = ax.plot([],[],"-",color="#a8dadc",lw=2.5,zorder=3)
bob, = ax.plot([],[],  "o",color="#e63946",ms=14,zorder=4)

def update(f):
    cx=x_arr[f]
    cpatch.set_x(cx-cart_w/2)
    w1.center=(cx-cart_w/3,track_y); w2.center=(cx+cart_w/3,track_y)
    spx,spy=spring_path_fn(wall_x, cx-cart_w/2)
    sp.set_data(spx,spy)
    bx=cx+L*np.sin(h_arr[f]); by=cy-L*np.cos(h_arr[f])
    rod.set_data([cx,bx],[cy,by]); bob.set_data([bx],[by])
    return sp,rod,bob

ani=animation.FuncAnimation(fig,update,frames=len(sol.t),interval=1000/fps,blit=False)
ani.save("cart_pendulum.mp4",writer=animation.FFMpegWriter(fps=fps,bitrate=1800),dpi=120)
plt.close(); print("Saved cart_pendulum.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Cart-Pendulum Simulation")
    parser.add_argument("--M",  type=float, default=1.0)
    parser.add_argument("--m",  type=float, default=1.0)
    parser.add_argument("--L",  type=float, default=1.0)
    parser.add_argument("--k",  type=float, default=6.0)
    parser.add_argument("--g",  type=float, default=9.8)
    parser.add_argument("--d_c",type=float, default=0.0)
    parser.add_argument("--b",  type=float, default=0.0)
    parser.add_argument("--x0", type=float, default=1.0)
    parser.add_argument("--h0", type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=15.0)
    parser.add_argument("--output",   type=str,   default="cart_pendulum.mp4")
    args = parser.parse_args()
    p = CartPendulumParams(
        M=args.M, m=args.m, L=args.L, k=args.k, g=args.g,
        d_c=args.d_c, b=args.b, x0=args.x0, h0=args.h0,
    )
    print(f"Simulating cart-pendulum: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
