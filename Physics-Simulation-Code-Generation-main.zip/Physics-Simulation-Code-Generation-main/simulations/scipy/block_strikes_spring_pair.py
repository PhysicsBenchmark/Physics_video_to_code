"""
Block Strikes Spring Pair — block 1 collides with block 2; spring couples 2 to 3.
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class BlockStrikesSpringPairParams:
    g: float = 9.8
    m1: float = 0.50
    m2: float = 0.50
    m3: float = 0.50
    s: float = 0.18
    k: float = 80.0
    L0: float = 0.50
    v0: float = 3.0
    e_rest: float = 0.70
    mu_floor: float = 0.10
    x1_0: float = -1.50
    x2_0: float = 0.10
    x3_0: float = 0.60
    duration: float = 12.0
    fps: int = 30


def _run_sim(p):
    g = p.g; m1 = p.m1; m2 = p.m2; m3 = p.m3; s = p.s; k = p.k
    L0 = p.L0; v0 = p.v0; e_rest = p.e_rest; mu_floor = p.mu_floor
    duration = p.duration; fps = int(p.fps)
    V_EPS = 1e-2
    F_STATIC = (mu_floor * m1 * g, mu_floor * m2 * g, mu_floor * m3 * g)

    def friction_accel(v, F_other, m, F_stat):
        return (F_other - F_stat * np.tanh(v / V_EPS)) / m

    def phase1_rhs(t, y):
        x1, x2, x3, v1, v2, v3 = y
        dv1 = friction_accel(v1, 0.0, m1, F_STATIC[0])
        return [v1, 0.0, 0.0, dv1, 0.0, 0.0]

    def phase3_rhs(t, y):
        x1, x2, x3, v1, v2, v3 = y
        dxs = (x3 - x2) - L0
        F_spring_on_2 = +k * dxs
        F_spring_on_3 = -k * dxs
        dv1 = friction_accel(v1, 0.0, m1, F_STATIC[0])
        dv2 = friction_accel(v2, F_spring_on_2, m2, F_STATIC[1])
        dv3 = friction_accel(v3, F_spring_on_3, m3, F_STATIC[2])
        return [v1, v2, v3, dv1, dv2, dv3]

    def make_contact_event(direction=+1):
        def ev(t, y):
            return (y[0] + s / 2.0) - (y[1] - s / 2.0)
        ev.terminal = True; ev.direction = direction
        return ev

    t_eval_g = np.linspace(0.0, duration, int(duration * fps) + 1)
    S = np.zeros((6, len(t_eval_g)))
    state = np.array([p.x1_0, p.x2_0, p.x3_0, v0, 0.0, 0.0])
    S[:, 0] = state; last_idx = 1; t_cur = 0.0

    contact_ev = make_contact_event(direction=+1)
    sol1 = solve_ivp(phase1_rhs, (0.0, duration), state,
                     events=[contact_ev], dense_output=True,
                     method="RK45", rtol=1e-9, atol=1e-11, max_step=5e-3)
    seg_end = sol1.t[-1]
    while last_idx < len(t_eval_g) and t_eval_g[last_idx] <= seg_end + 1e-12:
        S[:, last_idx] = sol1.sol(t_eval_g[last_idx]); last_idx += 1
    state = sol1.y[:, -1].copy()
    t_cur = seg_end

    if len(sol1.t_events[0]) > 0:
        v1_pre = state[3]
        v1_post = ((m1 - e_rest * m2) / (m1 + m2)) * v1_pre
        v2_post = ((1.0 + e_rest) * m1 / (m1 + m2)) * v1_pre
        state[3] = v1_post; state[4] = v2_post

    for _seg in range(50):
        if t_cur >= duration - 1e-12: break
        sol = solve_ivp(phase3_rhs, (t_cur, duration), state,
                        events=[make_contact_event(direction=+1)], dense_output=True,
                        method="RK45", rtol=1e-9, atol=1e-11, max_step=5e-3)
        seg_end = sol.t[-1]
        while last_idx < len(t_eval_g) and t_eval_g[last_idx] <= seg_end + 1e-12:
            S[:, last_idx] = sol.sol(t_eval_g[last_idx]); last_idx += 1
        state = sol.y[:, -1].copy(); t_cur = seg_end
        if sol.status != 1: break
        if state[3] - state[4] > 0.0:
            v1_pre, v2_pre = state[3], state[4]
            state[3] = ((m1 - e_rest * m2) * v1_pre + (1.0 + e_rest) * m2 * v2_pre) / (m1 + m2)
            state[4] = ((m2 - e_rest * m1) * v2_pre + (1.0 + e_rest) * m1 * v1_pre) / (m1 + m2)
        else:
            t_cur += 1e-9

    if last_idx < len(t_eval_g):
        S[:, last_idx:] = state[:, None]
    return t_eval_g, S


def simulate(params: BlockStrikesSpringPairParams,
             duration: float = 12.0, fps: int = 30):
    if duration is not None: params.duration = duration
    t, S = _run_sim(params)
    return t, S


def render_video(t, y, params: BlockStrikesSpringPairParams,
                 output_path: str, fps: int = 30):
    p = params
    s = p.s
    x1_arr, x2_arr, x3_arr = y[0], y[1], y[2]

    pad = 0.30
    x_lo_d = float(min(x1_arr.min(), x2_arr.min(), x3_arr.min())) - s/2.0 - pad
    x_hi_d = float(max(x1_arr.max(), x2_arr.max(), x3_arr.max())) + s/2.0 + pad
    y_lo_d = -0.30; y_hi_d = s + 0.40
    fig_w, fig_h = 9, 5
    fig_aspect = fig_w / fig_h
    dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_d / dy_d < fig_aspect:
        extra = (fig_aspect * dy_d - dx_d) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx_d / fig_aspect - dy_d) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")
    ax.add_patch(patches.Rectangle((x_lo, y_lo), x_hi - x_lo, -y_lo,
                                    facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.plot([x_lo, x_hi], [0, 0], color="#adb5bd", lw=2.0, zorder=1)

    b1 = patches.Rectangle((x1_arr[0] - s/2, 0), s, s,
                           facecolor="#e63946", edgecolor="white", lw=1.5, zorder=4)
    b2 = patches.Rectangle((x2_arr[0] - s/2, 0), s, s,
                           facecolor="#8ecae6", edgecolor="white", lw=1.5, zorder=4)
    b3 = patches.Rectangle((x3_arr[0] - s/2, 0), s, s,
                           facecolor="#ffd166", edgecolor="white", lw=1.5, zorder=4)
    ax.add_patch(b1); ax.add_patch(b2); ax.add_patch(b3)

    N_COILS = 12; COIL_W = 0.045; N_PTS = 4 * N_COILS + 2

    def coil_xy(p1, p2):
        x1_, y1_ = p1; x2_, y2_ = p2
        dx, dy = x2_ - x1_, y2_ - y1_
        L = np.hypot(dx, dy)
        if L < 1e-9: return np.array([x1_, x2_]), np.array([y1_, y2_])
        ux, uy = dx / L, dy / L; nx, ny = -uy, ux
        margin = 0.05
        t_par = np.linspace(0.0, 1.0, N_PTS)
        envelope = np.where((t_par < margin) | (t_par > 1.0 - margin), 0.0,
                            np.sin(N_COILS * 2.0 * np.pi *
                                   (t_par - margin) / (1.0 - 2.0 * margin)))
        xs = x1_ + t_par * dx + COIL_W * envelope * nx
        ys = y1_ + t_par * dy + COIL_W * envelope * ny
        return xs, ys

    y_mid = s / 2.0
    xs0, ys0 = coil_xy((x2_arr[0] + s/2.0, y_mid), (x3_arr[0] - s/2.0, y_mid))
    spring_line, = ax.plot(xs0, ys0, color="#a8dadc", lw=2.2, zorder=3)

    def update(f):
        b1.set_x(x1_arr[f] - s/2.0)
        b2.set_x(x2_arr[f] - s/2.0)
        b3.set_x(x3_arr[f] - s/2.0)
        xs, ys = coil_xy((x2_arr[f] + s/2.0, y_mid), (x3_arr[f] - s/2.0, y_mid))
        spring_line.set_data(xs, ys)
        return (b1, b2, b3, spring_line)

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0/fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: BlockStrikesSpringPairParams,
                           duration: float = 12.0) -> str:
    p = asdict(params)
    p["duration"] = duration
    return f'''"""Block strikes spring pair - standalone script."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

g = {p["g"]}; m1 = {p["m1"]}; m2 = {p["m2"]}; m3 = {p["m3"]}
s = {p["s"]}; k = {p["k"]}; L0 = {p["L0"]}; v0 = {p["v0"]}
e_rest = {p["e_rest"]}; mu_floor = {p["mu_floor"]}
x1_0 = {p["x1_0"]}; x2_0 = {p["x2_0"]}; x3_0 = {p["x3_0"]}
duration = {p["duration"]}; fps = {p["fps"]}
V_EPS = 1e-2
F_STATIC = (mu_floor * m1 * g, mu_floor * m2 * g, mu_floor * m3 * g)


def friction_accel(v, F_other, m, F_stat):
    return (F_other - F_stat * np.tanh(v / V_EPS)) / m


def phase1_rhs(t, y):
    x1, x2, x3, v1, v2, v3 = y
    dv1 = friction_accel(v1, 0.0, m1, F_STATIC[0])
    return [v1, 0.0, 0.0, dv1, 0.0, 0.0]


def phase3_rhs(t, y):
    x1, x2, x3, v1, v2, v3 = y
    dxs = (x3 - x2) - L0
    F_s2 = +k * dxs; F_s3 = -k * dxs
    dv1 = friction_accel(v1, 0.0, m1, F_STATIC[0])
    dv2 = friction_accel(v2, F_s2, m2, F_STATIC[1])
    dv3 = friction_accel(v3, F_s3, m3, F_STATIC[2])
    return [v1, v2, v3, dv1, dv2, dv3]


def make_contact_event(direction=+1):
    def ev(t, y):
        return (y[0] + s / 2.0) - (y[1] - s / 2.0)
    ev.terminal = True; ev.direction = direction
    return ev


t_eval_g = np.linspace(0.0, duration, int(duration * fps) + 1)
S = np.zeros((6, len(t_eval_g)))
state = np.array([x1_0, x2_0, x3_0, v0, 0.0, 0.0])
S[:, 0] = state; last_idx = 1; t_cur = 0.0

contact_ev = make_contact_event(direction=+1)
sol1 = solve_ivp(phase1_rhs, (0.0, duration), state,
                 events=[contact_ev], dense_output=True,
                 method="RK45", rtol=1e-9, atol=1e-11, max_step=5e-3)
seg_end = sol1.t[-1]
while last_idx < len(t_eval_g) and t_eval_g[last_idx] <= seg_end + 1e-12:
    S[:, last_idx] = sol1.sol(t_eval_g[last_idx]); last_idx += 1
state = sol1.y[:, -1].copy()
t_cur = seg_end

if len(sol1.t_events[0]) > 0:
    v1_pre = state[3]
    v1_post = ((m1 - e_rest * m2) / (m1 + m2)) * v1_pre
    v2_post = ((1.0 + e_rest) * m1 / (m1 + m2)) * v1_pre
    state[3] = v1_post; state[4] = v2_post

for _seg in range(50):
    if t_cur >= duration - 1e-12: break
    sol = solve_ivp(phase3_rhs, (t_cur, duration), state,
                    events=[make_contact_event(direction=+1)], dense_output=True,
                    method="RK45", rtol=1e-9, atol=1e-11, max_step=5e-3)
    seg_end = sol.t[-1]
    while last_idx < len(t_eval_g) and t_eval_g[last_idx] <= seg_end + 1e-12:
        S[:, last_idx] = sol.sol(t_eval_g[last_idx]); last_idx += 1
    state = sol.y[:, -1].copy(); t_cur = seg_end
    if sol.status != 1: break
    if state[3] - state[4] > 0.0:
        v1_pre, v2_pre = state[3], state[4]
        state[3] = ((m1 - e_rest * m2) * v1_pre + (1.0 + e_rest) * m2 * v2_pre) / (m1 + m2)
        state[4] = ((m2 - e_rest * m1) * v2_pre + (1.0 + e_rest) * m1 * v1_pre) / (m1 + m2)
    else:
        t_cur += 1e-9

if last_idx < len(t_eval_g):
    S[:, last_idx:] = state[:, None]
x1_arr, x2_arr, x3_arr = S[0], S[1], S[2]

pad = 0.30
x_lo_d = float(min(x1_arr.min(), x2_arr.min(), x3_arr.min())) - s/2.0 - pad
x_hi_d = float(max(x1_arr.max(), x2_arr.max(), x3_arr.max())) + s/2.0 + pad
y_lo_d = -0.30; y_hi_d = s + 0.40
fig_w, fig_h = 9, 5
fig_aspect = fig_w / fig_h
dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
if dx_d / dy_d < fig_aspect:
    extra = (fig_aspect * dy_d - dx_d) / 2.0
    x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
    y_lo, y_hi = y_lo_d, y_hi_d
else:
    extra = (dx_d / fig_aspect - dy_d) / 2.0
    x_lo, x_hi = x_lo_d, x_hi_d
    y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0, 0, 1, 1])
ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(patches.Rectangle((x_lo, y_lo), x_hi - x_lo, -y_lo,
                                facecolor="#4a4e69", edgecolor="none", zorder=0))
ax.plot([x_lo, x_hi], [0, 0], color="#adb5bd", lw=2.0, zorder=1)

b1 = patches.Rectangle((x1_arr[0] - s/2, 0), s, s,
                       facecolor="#e63946", edgecolor="white", lw=1.5, zorder=4)
b2 = patches.Rectangle((x2_arr[0] - s/2, 0), s, s,
                       facecolor="#8ecae6", edgecolor="white", lw=1.5, zorder=4)
b3 = patches.Rectangle((x3_arr[0] - s/2, 0), s, s,
                       facecolor="#ffd166", edgecolor="white", lw=1.5, zorder=4)
ax.add_patch(b1); ax.add_patch(b2); ax.add_patch(b3)

N_COILS = 12; COIL_W = 0.045; N_PTS = 4 * N_COILS + 2


def coil_xy(p1, p2):
    x1_, y1_ = p1; x2_, y2_ = p2
    dx, dy = x2_ - x1_, y2_ - y1_
    L = np.hypot(dx, dy)
    if L < 1e-9: return np.array([x1_, x2_]), np.array([y1_, y2_])
    ux, uy = dx / L, dy / L; nx, ny = -uy, ux
    margin = 0.05
    t_par = np.linspace(0.0, 1.0, N_PTS)
    envelope = np.where((t_par < margin) | (t_par > 1.0 - margin), 0.0,
                        np.sin(N_COILS * 2.0 * np.pi *
                               (t_par - margin) / (1.0 - 2.0 * margin)))
    xs = x1_ + t_par * dx + COIL_W * envelope * nx
    ys = y1_ + t_par * dy + COIL_W * envelope * ny
    return xs, ys


y_mid = s / 2.0
xs0, ys0 = coil_xy((x2_arr[0] + s/2.0, y_mid), (x3_arr[0] - s/2.0, y_mid))
spring_line, = ax.plot(xs0, ys0, color="#a8dadc", lw=2.2, zorder=3)


def update(f):
    b1.set_x(x1_arr[f] - s/2.0)
    b2.set_x(x2_arr[f] - s/2.0)
    b3.set_x(x3_arr[f] - s/2.0)
    xs, ys = coil_xy((x2_arr[f] + s/2.0, y_mid), (x3_arr[f] - s/2.0, y_mid))
    spring_line.set_data(xs, ys)
    return (b1, b2, b3, spring_line)


ani = animation.FuncAnimation(fig, update, frames=len(t_eval_g),
                              interval=1000.0/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    p = BlockStrikesSpringPairParams()
    t, y = simulate(p, duration=p.duration)
    render_video(t, y, p, "video.mp4")
