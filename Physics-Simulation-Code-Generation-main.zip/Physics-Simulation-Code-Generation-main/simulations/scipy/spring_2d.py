"""
2D Spring Simulation
====================
Faithfully translated from myphysicslab/src/sims/springs/Spring2DSim.ts

Physical Law: Newton's Second Law with spring force, gravity, and viscous damping
    F_net = m·a

Forces on the bob:
    Spring force (vector):
        xx = x - ax,  yy = y - ay
        len = sqrt(xx^2 + yy^2)
        L = len - R   (stretch from rest length)
        th = atan(xx / yy)
        Fx = -k * L * sin(th) = -k * L * xx / len
        Fy = -k * L * (-yy/len) * (-1)  →  see TS: Fy contribution from cos
          = k * L * cos(th) - m*g - b*vy  ... wait, TS: Vy' = -g + (k/m)*L*cos(th) - (b/m)*Vy
    cos(th) = -yy / len,  sin(th) = xx / len

Equations of Motion (from Spring2DSim.ts evaluate()):
    Ux' = Vx
    Uy' = Vy
    Vx' = -(k/m) * L * sin(th) - (b/m) * Vx
    Vy' = -g + (k/m) * L * cos(th) - (b/m) * Vy

where:
    xx = x - ax,  yy = y - ay
    len = sqrt(xx^2 + yy^2)
    L = len - R
    sin(th) = xx / len
    cos(th) = -yy / len

State vector: [x, y, vx, vy]  (bob position and velocity)
Anchor is fixed at (ax, ay).
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from .draw_utils import setup_dark_axis, spring_path


@dataclass
class Spring2DParams:
    k: float = 3.0      # spring stiffness (N/m)
    m: float = 0.5      # bob mass (kg)
    b: float = 0.1      # damping coefficient (kg/s)
    g: float = 9.8      # gravitational acceleration (m/s^2)
    R: float = 1.5      # spring rest length (m)
    ax: float = 0.0     # anchor x position (m)
    ay: float = 3.0     # anchor y position (m)
    x0: float = 1.5     # initial bob x position (m)
    y0: float = 1.0     # initial bob y position (m)
    vx0: float = 0.0    # initial bob x velocity (m/s)
    vy0: float = 0.0    # initial bob y velocity (m/s)


def ode(t: float, y: list, p: Spring2DParams):
    """
    Exact translation of Spring2DSim.ts evaluate():
        change[UX] = vars[VX]
        change[UY] = vars[VY]
        change[VX] = (Fx - b*Vx) / m     where Fx = -k*L*sin(th)
        change[VY] = -g + (Fy - b*Vy)/m  where Fy = k*L*cos(th)
    with:
        xx = Ux - Tx,  yy = Uy - Ty
        len = sqrt(xx^2 + yy^2)
        L = len - R
        sin(th) = xx/len,  cos(th) = -yy/len
    """
    x, y_pos, vx, vy = y
    xx = x - p.ax
    yy = y_pos - p.ay
    dist = np.hypot(xx, yy)
    if dist < 1e-10:
        return [vx, vy, 0.0, -p.g]
    stretch = dist - p.R
    sin_th = xx / dist      # sin(th) = xx/len
    cos_th = -yy / dist     # cos(th) = -yy/len
    # Spring force components: Fx = -k*L*sin(th),  Fy = k*L*cos(th)
    Fx = -p.k * stretch * sin_th
    Fy = p.k * stretch * cos_th
    dx = vx
    dy = vy
    dvx = (Fx - p.b * vx) / p.m
    dvy = -p.g + (Fy - p.b * vy) / p.m
    return [dx, dy, dvx, dvy]


def simulate(
    params: Spring2DParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Integrate using RK45. Returns (t, y) with y.shape = (4, N)."""
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode,
        (0, duration),
        [params.x0, params.y0, params.vx0, params.vy0],
        t_eval=t_eval,
        args=(params,),
        method="RK45",
        rtol=1e-8,
        atol=1e-10,
    )
    return sol.t, sol.y


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: Spring2DParams,
    output_path: str,
    fps: int = 30,
) -> None:
    """
    Render 2D spring-bob system:
      [anchor square] ~~~spring~~~ [bob circle]
    """
    x_arr = y[0]
    y_arr = y[1]

    # Determine view bounds from trajectory + anchor
    all_x = np.concatenate([[params.ax], x_arr])
    all_y = np.concatenate([[params.ay], y_arr])
    margin = max(params.R * 1.5, 1.5)
    xlim = (all_x.min() - margin, all_x.max() + margin)
    ylim = (all_y.min() - margin, all_y.max() + margin)

    bob_r = 0.18   # visual radius for bob circle

    fig, ax = plt.subplots(figsize=(8, 6))
    setup_dark_axis(fig, ax, xlim, ylim)

    # Static: anchor square
    anchor_sz = 0.2
    anchor_patch = patches.Rectangle(
        (params.ax - anchor_sz / 2, params.ay - anchor_sz / 2),
        anchor_sz, anchor_sz,
        facecolor="#4a4e69", edgecolor="#adb5bd", lw=1.5, zorder=4,
    )
    ax.add_patch(anchor_patch)

    # Animated elements
    (spring_line,) = ax.plot([], [], "-", color="#a8dadc", lw=2.5, zorder=3)
    bob_circle = plt.Circle(
        (params.x0, params.y0), bob_r,
        facecolor="#e63946", edgecolor="white", linewidth=1.5, zorder=5,
    )
    ax.add_patch(bob_circle)

    def init():
        spring_line.set_data([], [])
        return (spring_line,)

    def update(frame):
        bx = x_arr[frame]
        by = y_arr[frame]
        bob_circle.set_center((bx, by))
        sx, sy = spring_path(
            params.ax, params.ay, bx, by,
            n_coils=8, coil_radius=0.12,
        )
        spring_line.set_data(sx, sy)
        return (spring_line, bob_circle)

    ani = animation.FuncAnimation(
        fig, update, frames=len(t), init_func=init, interval=1000 / fps, blit=False
    )
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=100)
    plt.close(fig)


def make_standalone_script(params: Spring2DParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""
2D Spring — auto-generated simulation script.
Physics (Spring2DSim.ts):
    Vx' = -(k/m)*L*sin(th) - (b/m)*Vx
    Vy' = -g + (k/m)*L*cos(th) - (b/m)*Vy
    where L = dist - R,  sin(th) = xx/dist,  cos(th) = -yy/dist
Parameters: k={p["k"]} N/m, m={p["m"]} kg, b={p["b"]} kg/s, g={p["g"]} m/s^2
  R={p["R"]} m (rest length), anchor=({p["ax"]},{p["ay"]})
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

k, m, b, g = {p["k"]}, {p["m"]}, {p["b"]}, {p["g"]}
R = {p["R"]}
ax_pt, ay_pt = {p["ax"]}, {p["ay"]}
x0, y0, vx0, vy0 = {p["x0"]:.6f}, {p["y0"]:.6f}, {p["vx0"]:.6f}, {p["vy0"]:.6f}
duration = {duration}

def ode(t, y):
    x, yp, vx, vy = y
    xx, yy = x - ax_pt, yp - ay_pt
    dist = np.hypot(xx, yy)
    if dist < 1e-10:
        return [vx, vy, 0.0, -g]
    stretch = dist - R
    Fx = -k * stretch * xx / dist
    Fy =  k * stretch * (-yy) / dist
    return [vx, vy,
            (Fx - b*vx) / m,
            -g + (Fy - b*vy) / m]

fps = 30
t_eval = np.linspace(0, duration, int(duration*fps)+1)
sol = solve_ivp(ode, (0, duration), [x0, y0, vx0, vy0],
                t_eval=t_eval, method="RK45", rtol=1e-8, atol=1e-10)
x_arr, y_arr = sol.y[0], sol.y[1]

all_x = np.concatenate([[ax_pt], x_arr])
all_y = np.concatenate([[ay_pt], y_arr])
mg = 1.5
xlim = (all_x.min()-mg, all_x.max()+mg)
ylim = (all_y.min()-mg, all_y.max()+mg)

fig, ax2 = plt.subplots(figsize=(8,6),facecolor="#1a1a2e")
ax2.set_facecolor("#16213e"); ax2.set_xlim(xlim); ax2.set_ylim(ylim)
ax2.set_aspect("equal"); ax2.axis("off")

anch_sz = 0.2
ax2.add_patch(patches.Rectangle((ax_pt-anch_sz/2, ay_pt-anch_sz/2), anch_sz, anch_sz,
    facecolor="#4a4e69", edgecolor="#adb5bd", lw=1.5, zorder=4))
sp, = ax2.plot([],[],"-",color="#a8dadc",lw=2.5,zorder=3)
bob = plt.Circle((x0,y0),0.18,facecolor="#e63946",edgecolor="white",lw=1.5,zorder=5)
ax2.add_patch(bob)

def spring_path_fn(x1,y1,x2,y2,n=8,r=0.12):
    dx,dy = x2-x1, y2-y1
    L = np.hypot(dx,dy)
    if L < 1e-10: return np.array([x1,x2]), np.array([y1,y2])
    ux,uy = dx/L, dy/L; nx,ny = -uy, ux
    n_pts = n*20+2; t = np.linspace(0,1,n_pts); mg2=0.08
    env = np.where((t<mg2)|(t>1-mg2),0,np.sin(n*2*np.pi*(t-mg2)/(1-2*mg2)))
    return x1+t*dx+r*env*nx, y1+t*dy+r*env*ny

def update(f):
    bx,by = x_arr[f],y_arr[f]; bob.set_center((bx,by))
    sx,sy=spring_path_fn(ax_pt,ay_pt,bx,by); sp.set_data(sx,sy)
    return (sp, bob)

ani=animation.FuncAnimation(fig,update,frames=len(sol.t),interval=1000/fps,blit=False)
ani.save("spring_2d.mp4",writer=animation.FFMpegWriter(fps=fps,bitrate=1800),dpi=100)
plt.close(); print("Saved spring_2d.mp4")
'''


def main():
    import argparse
    parser = argparse.ArgumentParser(description="2D Spring Simulation")
    parser.add_argument("--k",   type=float, default=3.0)
    parser.add_argument("--m",   type=float, default=0.5)
    parser.add_argument("--b",   type=float, default=0.1)
    parser.add_argument("--g",   type=float, default=9.8)
    parser.add_argument("--R",   type=float, default=1.5)
    parser.add_argument("--ax",  type=float, default=0.0)
    parser.add_argument("--ay",  type=float, default=3.0)
    parser.add_argument("--x0",  type=float, default=1.5)
    parser.add_argument("--y0",  type=float, default=1.0)
    parser.add_argument("--vx0", type=float, default=0.0)
    parser.add_argument("--vy0", type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output",   type=str,   default="spring_2d.mp4")
    args = parser.parse_args()
    p = Spring2DParams(
        k=args.k, m=args.m, b=args.b, g=args.g, R=args.R,
        ax=args.ax, ay=args.ay,
        x0=args.x0, y0=args.y0, vx0=args.vx0, vy0=args.vy0,
    )
    print(f"Simulating 2D spring: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")


if __name__ == "__main__":
    main()
