"""
Wave Pulse on a Ring-Loaded String
===================================
A taut string of length L, tension T, linear mass density mu connects a fixed
wall at x=0 to a ring of mass m_ring at x=L on a frictionless rod.  A right-
travelling Gaussian pulse is placed at x_pulse.

Continuum equations:
    d^2 y / d t^2 = c^2 d^2 y / d x^2,        c^2 = T/mu        (interior)
    y(0, t) = 0                                                  (rigid wall)
    m_ring * y_tt(L, t) = -T * y_x|_L                            (Newton II for the ring)

Numerical method: explicit leapfrog (CFL-stable; second-order in space and
time), with effective boundary mass m_eff = m_ring + (1/2)*mu*dx on the right
node.
"""
from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict


@dataclass
class StringRingWaveParams:
    L: float = 4.0
    T: float = 4.0
    mu: float = 1.0
    m_ring: float = 0.05
    A: float = 0.30
    x_pulse: float = 1.0
    sigma: float = 0.30


def simulate(
    params: StringRingWaveParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Returns (t_eval, Y) with Y.shape = (N+1, n_frames):
    transverse string displacement at each grid node and frame.
    """
    L = params.L
    T = params.T
    mu = params.mu
    m_ring = params.m_ring
    A = params.A
    x_pulse = params.x_pulse
    sigma = params.sigma

    c = (T / mu) ** 0.5
    N = 200
    dx = L / N
    x_grid = np.linspace(0, L, N + 1)

    n_per_frame = 4
    dt = 1.0 / (fps * n_per_frame)
    factor_int = (c * dt / dx) ** 2
    m_eff = m_ring + 0.5 * mu * dx
    factor_ring = T * dt * dt / (m_eff * dx)
    if factor_int >= 1.0:
        # Fall back to smaller dt by increasing n_per_frame
        n_per_frame = max(int(np.ceil(c * (1.0 / fps) / dx)) + 2, 4)
        dt = 1.0 / (fps * n_per_frame)
        factor_int = (c * dt / dx) ** 2
        factor_ring = T * dt * dt / (m_eff * dx)

    y_prev = A * np.exp(-((x_grid - x_pulse) ** 2) / (2 * sigma ** 2))
    y_prev[0] = 0.0
    dy_dx_init = -A * (x_grid - x_pulse) / sigma ** 2 \
                 * np.exp(-((x_grid - x_pulse) ** 2) / (2 * sigma ** 2))
    v_init = -c * dy_dx_init
    v_init[0] = 0.0

    a_init = np.zeros(N + 1)
    a_init[1:-1] = c**2 * (y_prev[2:] - 2 * y_prev[1:-1] + y_prev[:-2]) / dx ** 2
    a_init[-1] = T * (y_prev[-2] - y_prev[-1]) / (m_eff * dx)
    y_curr = y_prev + dt * v_init + 0.5 * dt * dt * a_init
    y_curr[0] = 0.0

    n_frames = int(duration * fps) + 1
    Y_frames = np.zeros((N + 1, n_frames))
    Y_frames[:, 0] = y_prev

    for frame in range(1, n_frames):
        for _ in range(n_per_frame):
            y_next = np.empty_like(y_curr)
            y_next[1:-1] = (2 * y_curr[1:-1] - y_prev[1:-1]
                            + factor_int * (y_curr[2:] - 2 * y_curr[1:-1] + y_curr[:-2]))
            y_next[0] = 0.0
            y_next[-1] = (2 * y_curr[-1] - y_prev[-1]
                          + factor_ring * (y_curr[-2] - y_curr[-1]))
            y_prev, y_curr = y_curr, y_next
        Y_frames[:, frame] = y_curr

    t_eval = np.linspace(0, duration, n_frames)
    return t_eval, Y_frames


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: StringRingWaveParams,
    output_path: str,
    fps: int = 30,
) -> None:
    L = params.L
    N = y.shape[0] - 1
    dx = L / N
    x_grid = np.linspace(0, L, N + 1)
    n_frames = y.shape[1]

    fig_w, fig_h = 10, 4
    fig_aspect = fig_w / fig_h
    x_lo_d, x_hi_d = -0.35, L + 0.35
    y_lo_d, y_hi_d = -0.65, 0.65
    dx_v, dy_v = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_v / dy_v < fig_aspect:
        extra = (fig_aspect * dy_v - dx_v) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
    else:
        extra = (dx_v / fig_aspect - dy_v) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi)
    ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal")
    ax.axis("off")

    wall_patch = patches.Rectangle((x_lo, y_lo), -x_lo, y_hi - y_lo,
                                   facecolor="#4a4e69", edgecolor="none", zorder=0)
    ax.add_patch(wall_patch)
    ax.plot([0, 0], [y_lo, y_hi], color="#adb5bd", lw=2.5, zorder=1)
    ax.axhline(0, color="#3a4357", lw=1, ls="--", zorder=1)

    r_x, r_y = 0.22, 0.11
    back_arc = patches.Arc((L, 0), 2*r_x, 2*r_y, theta1=0, theta2=180,
                           edgecolor="#e63946", lw=11, zorder=2)
    ax.add_patch(back_arc)
    ax.plot([L, L], [y_lo, y_hi], color="#adb5bd", lw=16,
            solid_capstyle="butt", zorder=3)
    front_arc = patches.Arc((L, 0), 2*r_x, 2*r_y, theta1=180, theta2=360,
                            edgecolor="#e63946", lw=11, zorder=5)
    ax.add_patch(front_arc)

    n_cut = int(round(r_x / dx))
    n_inside = (N + 1) - n_cut
    str_x_plot = x_grid[:n_inside]
    str_ln, = ax.plot([], [], "-", color="#a8dadc", lw=2.4, zorder=4)

    def update(f):
        yy = y[-1, f]
        str_y = y[:n_inside, f].copy()
        str_y[-1] = yy
        str_ln.set_data(str_x_plot, str_y)
        back_arc.set_center((L, yy))
        front_arc.set_center((L, yy))
        return str_ln, back_arc, front_arc

    ani = animation.FuncAnimation(fig, update, frames=n_frames,
                                  interval=1000 / fps, blit=True)
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: StringRingWaveParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Wave Pulse on a Ring-Loaded String — auto-generated script."""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

L = {p["L"]}
T = {p["T"]}
mu = {p["mu"]}
m_ring = {p["m_ring"]}
A = {p["A"]}
x_pulse = {p["x_pulse"]}
sigma = {p["sigma"]}
duration = {duration}

c = (T / mu) ** 0.5
N = 200
dx = L / N
x_grid = np.linspace(0, L, N + 1)

fps = 30
n_per_frame = 4
dt = 1.0 / (fps * n_per_frame)
factor_int = (c * dt / dx) ** 2
m_eff = m_ring + 0.5 * mu * dx
factor_ring = T * dt * dt / (m_eff * dx)
if factor_int >= 1.0:
    n_per_frame = int(np.ceil(c / (fps * dx))) + 2
    dt = 1.0 / (fps * n_per_frame)
    factor_int = (c * dt / dx) ** 2
    factor_ring = T * dt * dt / (m_eff * dx)

y_prev = A * np.exp(-((x_grid - x_pulse) ** 2) / (2 * sigma ** 2))
y_prev[0] = 0.0
dy_dx_init = -A * (x_grid - x_pulse) / sigma ** 2 * np.exp(-((x_grid - x_pulse) ** 2) / (2 * sigma ** 2))
v_init = -c * dy_dx_init
v_init[0] = 0.0

a_init = np.zeros(N + 1)
a_init[1:-1] = c**2 * (y_prev[2:] - 2 * y_prev[1:-1] + y_prev[:-2]) / dx ** 2
a_init[-1] = T * (y_prev[-2] - y_prev[-1]) / (m_eff * dx)
y_curr = y_prev + dt * v_init + 0.5 * dt * dt * a_init
y_curr[0] = 0.0

n_frames = int(duration * fps) + 1
Y_frames = np.zeros((n_frames, N + 1))
Y_frames[0] = y_prev

for frame in range(1, n_frames):
    for _ in range(n_per_frame):
        y_next = np.empty_like(y_curr)
        y_next[1:-1] = (2 * y_curr[1:-1] - y_prev[1:-1]
                        + factor_int * (y_curr[2:] - 2 * y_curr[1:-1] + y_curr[:-2]))
        y_next[0] = 0.0
        y_next[-1] = (2 * y_curr[-1] - y_prev[-1]
                      + factor_ring * (y_curr[-2] - y_curr[-1]))
        y_prev, y_curr = y_curr, y_next
    Y_frames[frame] = y_curr

fig_w, fig_h = 10, 4
fig_aspect = fig_w / fig_h
x_lo_d, x_hi_d = -0.35, L + 0.35
y_lo_d, y_hi_d = -0.65, 0.65
dx_v, dy_v = x_hi_d - x_lo_d, y_hi_d - y_lo_d
if dx_v / dy_v < fig_aspect:
    extra = (fig_aspect * dy_v - dx_v) / 2.0
    x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
else:
    extra = (dx_v / fig_aspect - dy_v) / 2.0
    x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0, 0, 1, 1])
ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")

wall_patch = patches.Rectangle((x_lo, y_lo), -x_lo, y_hi - y_lo,
                               facecolor="#4a4e69", edgecolor="none", zorder=0)
ax.add_patch(wall_patch)
ax.plot([0, 0], [y_lo, y_hi], color="#adb5bd", lw=2.5, zorder=1)
ax.axhline(0, color="#3a4357", lw=1, ls="--", zorder=1)

r_x, r_y = 0.22, 0.11
back_arc = patches.Arc((L, 0), 2*r_x, 2*r_y, theta1=0, theta2=180,
                       edgecolor="#e63946", lw=11, zorder=2)
ax.add_patch(back_arc)
ax.plot([L, L], [y_lo, y_hi], color="#adb5bd", lw=16, solid_capstyle="butt", zorder=3)
front_arc = patches.Arc((L, 0), 2*r_x, 2*r_y, theta1=180, theta2=360,
                        edgecolor="#e63946", lw=11, zorder=5)
ax.add_patch(front_arc)

n_cut = int(round(r_x / dx))
n_inside = (N + 1) - n_cut
str_x_plot = x_grid[:n_inside]
str_ln, = ax.plot([], [], "-", color="#a8dadc", lw=2.4, zorder=4)

def update(f):
    yy = Y_frames[f, -1]
    str_y = Y_frames[f, :n_inside].copy()
    str_y[-1] = yy
    str_ln.set_data(str_x_plot, str_y)
    back_arc.set_center((L, yy))
    front_arc.set_center((L, yy))
    return str_ln, back_arc, front_arc

ani = animation.FuncAnimation(fig, update, frames=n_frames, interval=1000/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="String Ring Wave Simulation")
    parser.add_argument("--L", type=float, default=4.0)
    parser.add_argument("--T", type=float, default=4.0)
    parser.add_argument("--mu", type=float, default=1.0)
    parser.add_argument("--m_ring", type=float, default=0.05)
    parser.add_argument("--A", type=float, default=0.30)
    parser.add_argument("--x_pulse", type=float, default=1.0)
    parser.add_argument("--sigma", type=float, default=0.30)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="string_ring_wave.mp4")
    args = parser.parse_args()
    p = StringRingWaveParams(L=args.L, T=args.T, mu=args.mu, m_ring=args.m_ring,
                             A=args.A, x_pulse=args.x_pulse, sigma=args.sigma)
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
