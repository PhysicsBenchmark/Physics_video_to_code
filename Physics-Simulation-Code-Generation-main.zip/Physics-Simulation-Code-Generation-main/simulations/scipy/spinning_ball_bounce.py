"""
Spinning Ball Bounce — solid ball bounces on a floor with backspin.

Free flight: ballistic (gravity only). At each ground impact: Routh
friction-cone contact model with normal restitution e_n and Coulomb friction
mu. Solid sphere I = (2/5) m R^2. State: (x, y, vx, vy, omega, theta).
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from matplotlib.lines import Line2D
from dataclasses import dataclass, asdict


@dataclass
class SpinningBallBounceParams:
    R: float = 0.15
    m: float = 0.4
    g: float = 9.81
    e_n: float = 0.55
    mu: float = 0.5
    x0: float = -2.0
    y0: float = 1.2
    vx0: float = 3.0
    vy0: float = 0.0
    omega0: float = 80.0
    theta0: float = 0.0


def _ode(t, s, p):
    return [s[2], s[3], 0.0, -p.g, 0.0, s[4]]


def _bounce_event(t, s, p):
    return s[1] - p.R
_bounce_event.terminal = True
_bounce_event.direction = -1.0


def _apply_bounce(state, p: SpinningBallBounceParams):
    x, y, vx, vy, om, th = state
    I_b = (2.0 / 5.0) * p.m * p.R * p.R
    vs = vx + om * p.R
    Jn = -(1.0 + p.e_n) * p.m * vy
    Jt_stick = -(2.0 / 7.0) * p.m * vs
    cone = p.mu * Jn
    if abs(Jt_stick) <= cone:
        Jt = Jt_stick
    else:
        Jt = -np.sign(vs) * cone
    return [x, p.R, vx + Jt / p.m, -p.e_n * vy, om + p.R * Jt / I_b, th]


def simulate(
    params: SpinningBallBounceParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Returns (t, y) where y.shape = (6, N): [x, y, vx, vy, omega, theta]."""
    I_b = (2.0 / 5.0) * params.m * params.R * params.R
    t_grid = np.linspace(0.0, duration, int(duration * fps) + 1)
    state = [params.x0, params.y0, params.vx0, params.vy0,
             params.omega0, params.theta0]
    t_now = 0.0

    ts, xs, ys, vxs, vys, oms, ths = [], [], [], [], [], [], []
    max_bounces = 200
    b_count = 0

    while t_now < duration - 1e-9 and b_count < max_bounces:
        sub_eval = t_grid[(t_grid >= t_now - 1e-12) & (t_grid <= duration + 1e-12)]
        if sub_eval.size == 0 or sub_eval[0] > t_now + 1e-12:
            sub_eval = np.concatenate(([t_now], sub_eval))
        else:
            sub_eval = sub_eval.copy()
            sub_eval[0] = t_now

        sol = solve_ivp(_ode, (t_now, duration), state,
                        args=(params,), t_eval=sub_eval,
                        events=_bounce_event,
                        method="RK45", rtol=1e-9, atol=1e-11, max_step=0.05)

        for i, ti in enumerate(sol.t):
            if ts and abs(ti - ts[-1]) < 1e-9:
                continue
            on_grid = np.any(np.isclose(t_grid, ti, atol=1e-7))
            if not on_grid:
                continue
            ts.append(ti)
            xs.append(sol.y[0, i]); ys.append(sol.y[1, i])
            vxs.append(sol.y[2, i]); vys.append(sol.y[3, i])
            oms.append(sol.y[4, i]); ths.append(sol.y[5, i])

        if sol.t_events[0].size > 0:
            te = sol.t_events[0][0]
            ye = sol.y_events[0][0]
            v_rebound = -params.e_n * ye[3]
            v_min = params.g / fps
            if v_rebound < v_min:
                # Settle: roll/slide on floor
                x_s, _, vx_s, _, om_s, th_s = ye
                vs0 = vx_s + om_s * params.R
                if abs(vs0) < 1e-6:
                    a_x = 0.0; a_om = 0.0; t_stop = duration
                else:
                    sgn = np.sign(vs0)
                    a_x = -sgn * params.mu * params.g
                    a_om = -sgn * params.mu * params.m * params.g * params.R / I_b
                    t_stop = te + abs(vs0) / ((7.0 / 2.0) * params.mu * params.g)
                for ti in t_grid:
                    if ti < te or any(abs(ti - tj) < 1e-9 for tj in ts):
                        continue
                    if ti <= t_stop:
                        dt_ = ti - te
                        vxf = vx_s + a_x * dt_
                        omf = om_s + a_om * dt_
                        xf = x_s + vx_s * dt_ + 0.5 * a_x * dt_ * dt_
                        thf = th_s + om_s * dt_ + 0.5 * a_om * dt_ * dt_
                    else:
                        dt_stop = t_stop - te
                        vxf = vx_s + a_x * dt_stop
                        omf = om_s + a_om * dt_stop
                        xf_stop = x_s + vx_s * dt_stop + 0.5 * a_x * dt_stop * dt_stop
                        thf_stop = th_s + om_s * dt_stop + 0.5 * a_om * dt_stop * dt_stop
                        dt2 = ti - t_stop
                        xf = xf_stop + vxf * dt2
                        thf = thf_stop + omf * dt2
                    ts.append(ti); xs.append(xf); ys.append(params.R)
                    vxs.append(vxf); vys.append(0.0)
                    oms.append(omf); ths.append(thf)
                t_now = duration
                break

            new_state = _apply_bounce(ye, params)
            b_count += 1
            t_now = te
            state = new_state
        else:
            t_now = duration
            state = [sol.y[i, -1] for i in range(6)]
            break

    if len(ts) < len(t_grid):
        last_x = xs[-1] if xs else params.x0
        last_y = ys[-1] if ys else params.y0
        last_vx = vxs[-1] if vxs else params.vx0
        last_vy = vys[-1] if vys else params.vy0
        last_om = oms[-1] if oms else params.omega0
        last_th = ths[-1] if ths else params.theta0
        for ti in t_grid:
            if not any(abs(ti - tj) < 1e-7 for tj in ts):
                dt = ti - (ts[-1] if ts else 0.0)
                ts.append(ti)
                xs.append(last_x + last_vx * dt)
                ys.append(last_y)
                vxs.append(last_vx); vys.append(last_vy)
                oms.append(last_om)
                ths.append(last_th + last_om * dt)

    order = np.argsort(ts)
    ts = np.array(ts)[order]
    xs = np.array(xs)[order]
    ys = np.array(ys)[order]
    vxs = np.array(vxs)[order]
    vys = np.array(vys)[order]
    oms = np.array(oms)[order]
    ths = np.array(ths)[order]

    keep = np.concatenate(([True], np.diff(ts) > 1e-9))
    ts, xs, ys, vxs, vys, oms, ths = (a[keep] for a in (ts, xs, ys, vxs, vys, oms, ths))

    # Resample onto the intended grid
    def nearest_indices(target, source):
        idx = np.searchsorted(source, target)
        idx = np.clip(idx, 1, len(source) - 1)
        left = source[idx - 1]; right = source[idx]
        idx -= (target - left) < (right - target)
        return idx
    ix = nearest_indices(t_grid, ts)
    xs, ys, vxs, vys, oms, ths = (a[ix] for a in (xs, ys, vxs, vys, oms, ths))

    y_out = np.vstack([xs, ys, vxs, vys, oms, ths])
    return t_grid, y_out


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: SpinningBallBounceParams,
    output_path: str,
    fps: int = 30,
) -> None:
    xs, ys, _, _, _, ths = y[0], y[1], y[2], y[3], y[4], y[5]
    R = params.R

    fig_w, fig_h = 9.0, 4.0
    fig_aspect = fig_w / fig_h
    x_lo_d = min(-3.0, xs.min() - 0.3)
    x_hi_d = max(3.0, xs.max() + 0.3)
    y_lo_d = -0.3
    y_hi_d = max(2.0, ys.max() + 0.2)
    dx, dy = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d - extra, x_hi_d + extra, y_lo_d, y_hi_d
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        x_lo, x_hi, y_lo, y_hi = x_lo_d, x_hi_d, y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    floor = patches.Rectangle((x_lo, y_lo), x_hi - x_lo, -y_lo,
                              facecolor="#4a4e69", edgecolor="none", zorder=0)
    ax.add_patch(floor)
    ax.plot([x_lo, x_hi], [0, 0], color="#adb5bd", lw=2.5, zorder=1)

    trail_len = 30
    trail_line, = ax.plot([], [], color="#e63946", lw=1.5, alpha=0.35, zorder=2)
    ball = patches.Circle((xs[0], ys[0]), R, facecolor="#e63946",
                          edgecolor="#adb5bd", lw=1.0, zorder=4)
    ax.add_patch(ball)
    spin_marker = Line2D([xs[0], xs[0] + R * np.cos(ths[0])],
                         [ys[0], ys[0] + R * np.sin(ths[0])],
                         color="#1a1a2e", lw=2.0, zorder=5)
    ax.add_line(spin_marker)

    def update(f):
        cx, cy, th = xs[f], ys[f], ths[f]
        ball.set_center((cx, cy))
        spin_marker.set_data([cx, cx + R * np.cos(th)],
                             [cy, cy + R * np.sin(th)])
        lo = max(0, f - trail_len)
        trail_line.set_data(xs[lo:f + 1], ys[lo:f + 1])
        return ball, spin_marker, trail_line

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000 / fps, blit=True)
    ani.save(output_path,
             writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(
    params: SpinningBallBounceParams,
    duration: float = 12.0,
) -> str:
    p = asdict(params)
    return f'''"""Spinning ball bounce — auto-generated."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from matplotlib.lines import Line2D

R       = {p["R"]}
m       = {p["m"]}
g       = {p["g"]}
e_n     = {p["e_n"]}
mu      = {p["mu"]}
x0, y0  = {p["x0"]}, {p["y0"]}
vx0, vy0= {p["vx0"]}, {p["vy0"]}
omega0  = {p["omega0"]}
theta0  = {p["theta0"]}
duration = {duration}
fps = 30
I_b = (2.0/5.0)*m*R*R

def ode(t, s):
    x,y,vx,vy,om,th = s
    return [vx, vy, 0.0, -g, 0.0, om]

def bounce_event(t, s):
    return s[1] - R
bounce_event.terminal = True
bounce_event.direction = -1.0

def apply_bounce(state):
    x,y,vx,vy,om,th = state
    vs = vx + om*R
    Jn = -(1.0+e_n)*m*vy
    Jt_stick = -(2.0/7.0)*m*vs
    cone = mu*Jn
    if abs(Jt_stick) <= cone:
        Jt = Jt_stick
    else:
        Jt = -np.sign(vs)*cone
    return [x, R, vx+Jt/m, -e_n*vy, om+R*Jt/I_b, th]

t_grid = np.linspace(0.0, duration, int(duration*fps)+1)
state = [x0,y0,vx0,vy0,omega0,theta0]
t_now = 0.0
ts=[]; xs=[]; ys=[]; vxs=[]; vys=[]; oms=[]; ths=[]
b_count = 0; max_bounces=200
while t_now < duration - 1e-9 and b_count < max_bounces:
    sub = t_grid[(t_grid>=t_now-1e-12)&(t_grid<=duration+1e-12)]
    if sub.size==0 or sub[0] > t_now+1e-12:
        sub = np.concatenate(([t_now], sub))
    else:
        sub = sub.copy(); sub[0] = t_now
    sol = solve_ivp(ode,(t_now,duration), state, t_eval=sub,
                    events=bounce_event, method="RK45",
                    rtol=1e-9, atol=1e-11, max_step=0.05)
    for i, ti in enumerate(sol.t):
        if ts and abs(ti-ts[-1]) < 1e-9: continue
        if not np.any(np.isclose(t_grid, ti, atol=1e-7)): continue
        ts.append(ti); xs.append(sol.y[0,i]); ys.append(sol.y[1,i])
        vxs.append(sol.y[2,i]); vys.append(sol.y[3,i])
        oms.append(sol.y[4,i]); ths.append(sol.y[5,i])
    if sol.t_events[0].size > 0:
        te = sol.t_events[0][0]; ye = sol.y_events[0][0]
        v_reb = -e_n*ye[3]; v_min = g/fps
        if v_reb < v_min:
            x_s,_,vx_s,_,om_s,th_s = ye
            vs0 = vx_s + om_s*R
            if abs(vs0) < 1e-6:
                a_x=0.0; a_om=0.0; t_stop=duration
            else:
                sgn = np.sign(vs0)
                a_x = -sgn*mu*g
                a_om = -sgn*mu*m*g*R/I_b
                t_stop = te + abs(vs0)/((7.0/2.0)*mu*g)
            for ti in t_grid:
                if ti < te or any(abs(ti-tj)<1e-9 for tj in ts): continue
                if ti <= t_stop:
                    dt_ = ti-te
                    vxf = vx_s + a_x*dt_; omf = om_s + a_om*dt_
                    xf = x_s + vx_s*dt_ + 0.5*a_x*dt_*dt_
                    thf = th_s + om_s*dt_ + 0.5*a_om*dt_*dt_
                else:
                    dts = t_stop-te
                    vxf = vx_s + a_x*dts; omf = om_s + a_om*dts
                    xf_stop = x_s + vx_s*dts + 0.5*a_x*dts*dts
                    th_stop = th_s + om_s*dts + 0.5*a_om*dts*dts
                    dt2 = ti-t_stop
                    xf = xf_stop + vxf*dt2; thf = th_stop + omf*dt2
                ts.append(ti); xs.append(xf); ys.append(R)
                vxs.append(vxf); vys.append(0.0); oms.append(omf); ths.append(thf)
            t_now = duration; break
        state = apply_bounce(ye); b_count += 1; t_now = te
    else:
        t_now = duration
        state = [sol.y[i,-1] for i in range(6)]; break

if len(ts) < len(t_grid):
    lx = xs[-1] if xs else x0; ly = ys[-1] if ys else y0
    lvx = vxs[-1] if vxs else vx0; lvy = vys[-1] if vys else vy0
    lom = oms[-1] if oms else omega0; lth = ths[-1] if ths else theta0
    for ti in t_grid:
        if not any(abs(ti-tj)<1e-7 for tj in ts):
            dt = ti - (ts[-1] if ts else 0.0)
            ts.append(ti); xs.append(lx + lvx*dt); ys.append(ly)
            vxs.append(lvx); vys.append(lvy); oms.append(lom)
            ths.append(lth + lom*dt)

order = np.argsort(ts)
ts = np.array(ts)[order]; xs=np.array(xs)[order]; ys=np.array(ys)[order]
vxs=np.array(vxs)[order]; vys=np.array(vys)[order]
oms=np.array(oms)[order]; ths=np.array(ths)[order]
keep = np.concatenate(([True], np.diff(ts)>1e-9))
ts, xs, ys, vxs, vys, oms, ths = (a[keep] for a in (ts,xs,ys,vxs,vys,oms,ths))

def near(target, src):
    idx = np.searchsorted(src, target); idx = np.clip(idx,1,len(src)-1)
    L = src[idx-1]; Rr = src[idx]
    idx -= (target-L) < (Rr-target)
    return idx
ix = near(t_grid, ts)
xs, ys, vxs, vys, oms, ths = (a[ix] for a in (xs,ys,vxs,vys,oms,ths))

fig_w, fig_h = 9.0, 4.0; fa = fig_w/fig_h
xlo_d = min(-3.0, xs.min()-0.3); xhi_d = max(3.0, xs.max()+0.3)
ylo_d = -0.3; yhi_d = max(2.0, ys.max()+0.2)
dx, dy = xhi_d-xlo_d, yhi_d-ylo_d
if dx/dy < fa:
    e=(fa*dy-dx)/2.0; xlo, xhi, ylo, yhi = xlo_d-e, xhi_d+e, ylo_d, yhi_d
else:
    e=(dx/fa-dy)/2.0; xlo, xhi, ylo, yhi = xlo_d, xhi_d, ylo_d-e, yhi_d+e

fig = plt.figure(figsize=(fig_w,fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1])
ax.set_facecolor("#16213e")
ax.set_xlim(xlo, xhi); ax.set_ylim(ylo, yhi)
ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(patches.Rectangle((xlo, ylo), xhi-xlo, -ylo,
              facecolor="#4a4e69", edgecolor="none", zorder=0))
ax.plot([xlo, xhi], [0,0], color="#adb5bd", lw=2.5, zorder=1)

trail_line, = ax.plot([],[], color="#e63946", lw=1.5, alpha=0.35, zorder=2)
ball = patches.Circle((xs[0], ys[0]), R, facecolor="#e63946",
                      edgecolor="#adb5bd", lw=1.0, zorder=4)
ax.add_patch(ball)
spin = Line2D([xs[0], xs[0]+R*np.cos(ths[0])],
              [ys[0], ys[0]+R*np.sin(ths[0])],
              color="#1a1a2e", lw=2.0, zorder=5)
ax.add_line(spin)

def update(f):
    cx, cy, th = xs[f], ys[f], ths[f]
    ball.set_center((cx, cy))
    spin.set_data([cx, cx+R*np.cos(th)], [cy, cy+R*np.sin(th)])
    lo = max(0, f-30)
    trail_line.set_data(xs[lo:f+1], ys[lo:f+1])
    return ball, spin, trail_line

ani = animation.FuncAnimation(fig, update, frames=len(ts),
                              interval=1000/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Spinning Ball Bounce")
    parser.add_argument("--R", type=float, default=0.15)
    parser.add_argument("--m", type=float, default=0.4)
    parser.add_argument("--g", type=float, default=9.81)
    parser.add_argument("--e_n", type=float, default=0.55)
    parser.add_argument("--mu", type=float, default=0.5)
    parser.add_argument("--x0", type=float, default=-2.0)
    parser.add_argument("--y0", type=float, default=1.2)
    parser.add_argument("--vx0", type=float, default=3.0)
    parser.add_argument("--vy0", type=float, default=0.0)
    parser.add_argument("--omega0", type=float, default=80.0)
    parser.add_argument("--theta0", type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="spinning_ball_bounce.mp4")
    args = parser.parse_args()

    p = SpinningBallBounceParams(
        R=args.R, m=args.m, g=args.g, e_n=args.e_n, mu=args.mu,
        x0=args.x0, y0=args.y0, vx0=args.vx0, vy0=args.vy0,
        omega0=args.omega0, theta0=args.theta0,
    )
    print(f"Simulating spinning ball bounce: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
