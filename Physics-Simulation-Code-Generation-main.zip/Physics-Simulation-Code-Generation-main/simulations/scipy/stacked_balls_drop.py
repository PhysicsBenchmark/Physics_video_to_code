"""
Stacked Balls Drop
====================
Two balls stacked vertically released from rest above a flat floor; the lower
(heavy) ball strikes the floor, bounces, and immediately collides with the
falling upper (light) ball — the textbook "stacked-ball amplification" demo.
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict


@dataclass
class StackedBallsDropParams:
    g: float = 9.8
    M: float = 2.0
    R: float = 0.15
    m: float = 0.20
    r: float = 0.07
    e_floor: float = 0.90
    e_b: float = 0.95
    y_lower_0: float = 0.80
    v_lower_0: float = 0.0
    v_upper_0: float = 0.0


def simulate(
    params: StackedBallsDropParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Hybrid event-based integration.  Returns (t_eval, S) with S.shape=(4, n_frames):
    S[0]=y_lower, S[1]=y_upper, S[2]=v_lower, S[3]=v_upper.
    """
    g = params.g
    M = params.M
    R = params.R
    m = params.m
    r = params.r
    e_floor = params.e_floor
    e_b = params.e_b
    y_lower_0 = params.y_lower_0
    y_upper_0 = y_lower_0 + R + r + 1e-3
    v_lower_0 = params.v_lower_0
    v_upper_0 = params.v_upper_0

    def free(t, y):
        return [y[2], y[3], -g, -g]

    def ev_floor(t, y):
        return y[0] - R
    ev_floor.terminal = True
    ev_floor.direction = -1

    def ev_ball(t, y):
        return y[1] - y[0] - (R + r)
    ev_ball.terminal = True
    ev_ball.direction = -1

    t_eval_g = np.linspace(0.0, duration, int(duration * fps) + 1)
    S = np.zeros((4, len(t_eval_g)))
    state = np.array([y_lower_0, y_upper_0, v_lower_0, v_upper_0], dtype=float)
    S[:, 0] = state
    last_idx = 1
    t_cur = 0.0

    MAX_SEGMENTS = 200
    for _seg in range(MAX_SEGMENTS):
        if t_cur >= duration - 1e-12:
            break
        sol = solve_ivp(free, (t_cur, duration), state,
                        events=[ev_floor, ev_ball],
                        dense_output=True, max_step=0.02,
                        rtol=1e-9, atol=1e-11)
        seg_end = sol.t[-1]
        while last_idx < len(t_eval_g) and t_eval_g[last_idx] <= seg_end + 1e-12:
            S[:, last_idx] = sol.sol(t_eval_g[last_idx])
            last_idx += 1
        state = sol.y[:, -1].copy()
        t_cur = seg_end
        if sol.status != 1:
            break
        t_floor = sol.t_events[0]
        t_ball = sol.t_events[1]
        if len(t_floor) == 0 and len(t_ball) == 0:
            break
        for _resolve in range(10):
            applied = False
            if state[0] - R < 1e-9 and state[2] < 0:
                state[2] = -e_floor * state[2]
                state[0] = max(state[0], R + 1e-12)
                applied = True
            gap = state[1] - state[0] - (R + r)
            if gap < 1e-9 and (state[3] - state[2]) < 0:
                vl, vu = state[2], state[3]
                state[2] = ((M - e_b * m) * vl + (1.0 + e_b) * m * vu) / (M + m)
                state[3] = ((m - e_b * M) * vu + (1.0 + e_b) * M * vl) / (M + m)
                state[1] = max(state[1], state[0] + R + r + 1e-12)
                applied = True
            if not applied:
                break

    if last_idx < len(t_eval_g):
        S[:, last_idx:] = state[:, None]
    return t_eval_g, S


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: StackedBallsDropParams,
    output_path: str,
    fps: int = 30,
) -> None:
    R = params.R
    r = params.r
    y_lower_0 = params.y_lower_0
    y_upper_0 = y_lower_0 + R + r + 1e-3
    yl_arr = y[0]
    yu_arr = y[1]

    fig_w, fig_h = 4, 7
    x_lo, x_hi = -0.40, 0.40
    y_lo = -0.10
    y_hi = max(2.8, y_upper_0 + 0.30)
    fig_aspect = fig_w / fig_h
    dx, dy = x_hi - x_lo, y_hi - y_lo
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi = x_lo - extra, x_hi + extra
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        y_lo, y_hi = y_lo - extra, y_hi + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi)
    ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal")
    ax.axis("off")

    floor_band = patches.Rectangle((x_lo, y_lo), x_hi - x_lo, -y_lo,
                                   facecolor="#4a4e69", edgecolor="none",
                                   alpha=0.8, zorder=0)
    ax.add_patch(floor_band)
    ax.axhline(0.0, color="#adb5bd", lw=2.0, zorder=1)

    lower_ball = patches.Circle((0.0, y_lower_0), R,
                                facecolor="#8ecae6", edgecolor="white",
                                lw=1.5, zorder=3)
    ax.add_patch(lower_ball)
    upper_ball = patches.Circle((0.0, y_upper_0), r,
                                facecolor="#e63946", edgecolor="white",
                                lw=1.5, zorder=4)
    ax.add_patch(upper_ball)

    def update(f):
        lower_ball.set_center((0.0, yl_arr[f]))
        upper_ball.set_center((0.0, yu_arr[f]))
        return lower_ball, upper_ball

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000 / fps, blit=True)
    writer = animation.FFMpegWriter(fps=fps, bitrate=1800)
    ani.save(output_path, writer=writer, dpi=120)
    plt.close(fig)


def make_standalone_script(params: StackedBallsDropParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Stacked Balls Drop — auto-generated."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

g = {p["g"]}
M = {p["M"]}
R = {p["R"]}
m = {p["m"]}
r = {p["r"]}
e_floor = {p["e_floor"]}
e_b = {p["e_b"]}
y_lower_0 = {p["y_lower_0"]}
y_upper_0 = y_lower_0 + R + r + 1e-3
v_lower_0 = {p["v_lower_0"]}
v_upper_0 = {p["v_upper_0"]}
duration = {duration}
fps = 30

def free(t, y):
    return [y[2], y[3], -g, -g]

def ev_floor(t, y):
    return y[0] - R
ev_floor.terminal = True; ev_floor.direction = -1

def ev_ball(t, y):
    return y[1] - y[0] - (R + r)
ev_ball.terminal = True; ev_ball.direction = -1

t_eval_g = np.linspace(0.0, duration, int(duration * fps) + 1)
S = np.zeros((4, len(t_eval_g)))
state = np.array([y_lower_0, y_upper_0, v_lower_0, v_upper_0], dtype=float)
S[:, 0] = state
last_idx = 1
t_cur = 0.0
MAX_SEGMENTS = 200

for _seg in range(MAX_SEGMENTS):
    if t_cur >= duration - 1e-12:
        break
    sol = solve_ivp(free, (t_cur, duration), state, events=[ev_floor, ev_ball],
                    dense_output=True, max_step=0.02, rtol=1e-9, atol=1e-11)
    seg_end = sol.t[-1]
    while last_idx < len(t_eval_g) and t_eval_g[last_idx] <= seg_end + 1e-12:
        S[:, last_idx] = sol.sol(t_eval_g[last_idx])
        last_idx += 1
    state = sol.y[:, -1].copy()
    t_cur = seg_end
    if sol.status != 1:
        break
    t_floor = sol.t_events[0]
    t_ball = sol.t_events[1]
    if len(t_floor) == 0 and len(t_ball) == 0:
        break
    for _resolve in range(10):
        applied = False
        if state[0] - R < 1e-9 and state[2] < 0:
            state[2] = -e_floor * state[2]
            state[0] = max(state[0], R + 1e-12)
            applied = True
        gap = state[1] - state[0] - (R + r)
        if gap < 1e-9 and (state[3] - state[2]) < 0:
            vl, vu = state[2], state[3]
            state[2] = ((M - e_b*m) * vl + (1.0+e_b)*m*vu)/(M+m)
            state[3] = ((m - e_b*M) * vu + (1.0+e_b)*M*vl)/(M+m)
            state[1] = max(state[1], state[0]+R+r+1e-12)
            applied = True
        if not applied:
            break

if last_idx < len(t_eval_g):
    S[:, last_idx:] = state[:, None]

yl_arr = S[0]; yu_arr = S[1]
fig_w, fig_h = 4, 7
x_lo, x_hi = -0.40, 0.40
y_lo = -0.10
y_hi = max(2.8, y_upper_0 + 0.30)
fig_aspect = fig_w/fig_h
dx, dy = x_hi-x_lo, y_hi-y_lo
if dx/dy < fig_aspect:
    extra = (fig_aspect*dy - dx)/2.0
    x_lo, x_hi = x_lo-extra, x_hi+extra
else:
    extra = (dx/fig_aspect - dy)/2.0
    y_lo, y_hi = y_lo-extra, y_hi+extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")
floor_band = patches.Rectangle((x_lo, y_lo), x_hi-x_lo, -y_lo, facecolor="#4a4e69", edgecolor="none", alpha=0.8, zorder=0)
ax.add_patch(floor_band)
ax.axhline(0.0, color="#adb5bd", lw=2.0, zorder=1)
lower_ball = patches.Circle((0.0, y_lower_0), R, facecolor="#8ecae6", edgecolor="white", lw=1.5, zorder=3)
ax.add_patch(lower_ball)
upper_ball = patches.Circle((0.0, y_upper_0), r, facecolor="#e63946", edgecolor="white", lw=1.5, zorder=4)
ax.add_patch(upper_ball)

def update(f):
    lower_ball.set_center((0.0, yl_arr[f]))
    upper_ball.set_center((0.0, yu_arr[f]))
    return lower_ball, upper_ball

ani = animation.FuncAnimation(fig, update, frames=len(t_eval_g), interval=1000/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Stacked Balls Drop")
    parser.add_argument("--g", type=float, default=9.8)
    parser.add_argument("--M", type=float, default=2.0)
    parser.add_argument("--R", type=float, default=0.15)
    parser.add_argument("--m", type=float, default=0.20)
    parser.add_argument("--r", type=float, default=0.07)
    parser.add_argument("--e_floor", type=float, default=0.90)
    parser.add_argument("--e_b", type=float, default=0.95)
    parser.add_argument("--y_lower_0", type=float, default=0.80)
    parser.add_argument("--v_lower_0", type=float, default=0.0)
    parser.add_argument("--v_upper_0", type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="stacked_balls_drop.mp4")
    args = parser.parse_args()
    p = StackedBallsDropParams(
        g=args.g, M=args.M, R=args.R, m=args.m, r=args.r,
        e_floor=args.e_floor, e_b=args.e_b,
        y_lower_0=args.y_lower_0, v_lower_0=args.v_lower_0, v_upper_0=args.v_upper_0,
    )
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
