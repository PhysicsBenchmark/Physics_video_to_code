"""
Pendulum on a string — slack / projectile / re-taut hybrid dynamics.

A point bob hangs from a hinge by a massless inextensible STRING (T >= 0).
When centripetal demand m L theta_dot^2 exceeds the radial-gravity component,
the string goes slack and the bob enters projectile motion until |r| = L
again, at which point an inelastic constraint jerk kills the radial velocity.
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis


@dataclass
class PendulumSlackRevolutionParams:
    g: float = 9.8
    L: float = 1.0
    m: float = 0.5
    v_0: float = 5.5
    damping_b: float = 0.0


def _integrate(p: PendulumSlackRevolutionParams, duration: float, fps: int):
    g, L, m, v_0, damping_b = p.g, p.L, p.m, p.v_0, p.damping_b

    def taut_ode(t, y):
        th, om = y
        return [om, -(g / L) * np.sin(th) - (damping_b / (m * L * L)) * om]

    def ev_slack(t, y):
        th, om = y
        return m * L * om * om + m * g * np.cos(th)
    ev_slack.terminal = True
    ev_slack.direction = -1

    def free_flight(t, y):
        return [y[2], y[3], 0.0, -g]

    def ev_retaut(t, y):
        x, y_, _, _ = y
        return x * x + y_ * y_ - L * L
    ev_retaut.terminal = True
    ev_retaut.direction = +1

    t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
    N = t_eval.size
    bob_x = np.zeros(N); bob_y = np.zeros(N); phase = np.zeros(N, dtype=np.int8)

    theta = 0.0
    omega = v_0 / L
    state_p1 = np.array([theta, omega], dtype=float)
    bob_x[0] = L * np.sin(theta); bob_y[0] = -L * np.cos(theta); phase[0] = 1
    last_idx = 1
    t_cur = 0.0
    in_taut = True

    for _seg in range(2000):
        if t_cur >= duration - 1e-12:
            break
        if in_taut:
            sol = solve_ivp(taut_ode, (t_cur, duration), state_p1,
                            events=ev_slack, dense_output=True,
                            rtol=1e-9, atol=1e-11, max_step=0.02)
            seg_end = sol.t[-1]
            while last_idx < N and t_eval[last_idx] <= seg_end + 1e-12:
                th = sol.sol(t_eval[last_idx])[0]
                bob_x[last_idx] = L * np.sin(th)
                bob_y[last_idx] = -L * np.cos(th)
                phase[last_idx] = 1
                last_idx += 1
            state_p1 = sol.y[:, -1].copy()
            t_cur = seg_end
            if sol.status != 1:
                break
            th_s, om_s = state_p1
            x_s = L * np.sin(th_s); y_s = -L * np.cos(th_s)
            vx_s = L * om_s * np.cos(th_s); vy_s = L * om_s * np.sin(th_s)
            state_p2 = np.array([x_s, y_s, vx_s, vy_s], dtype=float)
            in_taut = False
        else:
            sol = solve_ivp(free_flight, (t_cur, duration), state_p2,
                            events=ev_retaut, dense_output=True,
                            rtol=1e-9, atol=1e-11, max_step=0.02)
            seg_end = sol.t[-1]
            while last_idx < N and t_eval[last_idx] <= seg_end + 1e-12:
                st = sol.sol(t_eval[last_idx])
                bob_x[last_idx] = st[0]; bob_y[last_idx] = st[1]
                phase[last_idx] = 2
                last_idx += 1
            state_p2 = sol.y[:, -1].copy()
            t_cur = seg_end
            if sol.status != 1:
                break
            x_r, y_r, vx_r, vy_r = state_p2
            rn = np.hypot(x_r, y_r)
            rhx, rhy = x_r / rn, y_r / rn
            v_rad = vx_r * rhx + vy_r * rhy
            x_r = L * rhx; y_r = L * rhy
            vx_post = vx_r - v_rad * rhx
            vy_post = vy_r - v_rad * rhy
            theta_new = np.arctan2(x_r, -y_r)
            omega_new = (vx_post * np.cos(theta_new) + vy_post * np.sin(theta_new)) / L
            state_p1 = np.array([theta_new, omega_new], dtype=float)
            in_taut = True

    if last_idx < N:
        bob_x[last_idx:] = bob_x[last_idx - 1]
        bob_y[last_idx:] = bob_y[last_idx - 1]
        phase[last_idx:] = phase[last_idx - 1]

    return t_eval, np.vstack([bob_x, bob_y, phase.astype(float)])


def simulate(params: PendulumSlackRevolutionParams, duration: float = 12.0, fps: int = 30):
    return _integrate(params, duration, fps)


def render_video(t, y, params: PendulumSlackRevolutionParams, output_path: str, fps: int = 30):
    L = params.L
    bob_x, bob_y, phase = y[0], y[1], y[2].astype(int)

    x_lo, x_hi = -(L + 0.20), L + 0.20
    y_lo, y_hi = -(L + 0.20), L + 0.30
    fig_w, fig_h = 6.0, 6.0
    fig_aspect = fig_w / fig_h
    dx = x_hi - x_lo; dy = y_hi - y_lo
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo -= extra; x_hi += extra
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        y_lo -= extra; y_hi += extra

    fig = plt.figure(figsize=(fig_w, fig_h))
    ax = fig.add_axes([0, 0, 1, 1])
    setup_dark_axis(fig, ax, (x_lo, x_hi), (y_lo, y_hi))

    ax.plot([0], [0], "o", color="white", ms=6, zorder=6)
    string_ln, = ax.plot([], [], "-", color="#cbd5e1", lw=1.6, zorder=3)
    bob = patches.Circle((0, 0), 0.04, facecolor="#e63946",
                         edgecolor="white", lw=1.2, zorder=5)
    ax.add_patch(bob)
    trail, = ax.plot([], [], "-", color="#e63946", alpha=0.45, lw=1.4, zorder=2)
    tx, ty = [], []

    def slack_curve(xb, yb, n=24):
        chord = np.hypot(xb, yb)
        if chord < 1e-9 or chord >= L - 1e-6:
            return np.array([0.0, xb]), np.array([0.0, yb])
        s = np.linspace(0.0, 1.0, n)
        base_x = s * xb; base_y = s * yb
        ux, uy = xb / chord, yb / chord
        px, py = -uy, ux
        if py > 0:
            px, py = -px, -py
        extra = L / chord - 1.0
        sag = chord * np.sqrt(max(0.0, extra * 3.0 / 8.0))
        bow = 4.0 * sag * s * (1.0 - s)
        return base_x + bow * px, base_y + bow * py

    def update(f):
        xb, yb = bob_x[f], bob_y[f]
        bob.center = (xb, yb)
        if phase[f] == 1:
            string_ln.set_data([0.0, xb], [0.0, yb])
        else:
            sx, sy = slack_curve(xb, yb)
            string_ln.set_data(sx, sy)
        tx.append(xb); ty.append(yb)
        if len(tx) > 120:
            tx.pop(0); ty.pop(0)
        trail.set_data(tx, ty)
        return string_ln, bob, trail

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0 / fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: PendulumSlackRevolutionParams, duration: float = 12.0) -> str:
    p = asdict(params)
    return f'''"""Pendulum slack revolution standalone script."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

g = {p["g"]}
L = {p["L"]}
m = {p["m"]}
v_0 = {p["v_0"]}
damping_b = {p["damping_b"]}
duration = {duration}
fps = 30

def taut_ode(t, y):
    th, om = y
    return [om, -(g/L)*np.sin(th) - (damping_b/(m*L*L))*om]
def ev_slack(t, y):
    th, om = y
    return m*L*om*om + m*g*np.cos(th)
ev_slack.terminal = True; ev_slack.direction = -1
def free_flight(t, y):
    return [y[2], y[3], 0.0, -g]
def ev_retaut(t, y):
    x, y_, _, _ = y
    return x*x + y_*y_ - L*L
ev_retaut.terminal = True; ev_retaut.direction = +1

t_eval = np.linspace(0.0, duration, int(duration*fps)+1)
N = t_eval.size
bob_x = np.zeros(N); bob_y = np.zeros(N); phase = np.zeros(N, dtype=np.int8)

theta = 0.0; omega = v_0/L
state_p1 = np.array([theta, omega], dtype=float)
bob_x[0] = L*np.sin(theta); bob_y[0] = -L*np.cos(theta); phase[0] = 1
last_idx = 1; t_cur = 0.0; in_taut = True

for _seg in range(2000):
    if t_cur >= duration - 1e-12:
        break
    if in_taut:
        sol = solve_ivp(taut_ode, (t_cur, duration), state_p1, events=ev_slack,
                        dense_output=True, rtol=1e-9, atol=1e-11, max_step=0.02)
        seg_end = sol.t[-1]
        while last_idx < N and t_eval[last_idx] <= seg_end + 1e-12:
            th = sol.sol(t_eval[last_idx])[0]
            bob_x[last_idx] = L*np.sin(th); bob_y[last_idx] = -L*np.cos(th)
            phase[last_idx] = 1; last_idx += 1
        state_p1 = sol.y[:, -1].copy(); t_cur = seg_end
        if sol.status != 1:
            break
        th_s, om_s = state_p1
        x_s = L*np.sin(th_s); y_s = -L*np.cos(th_s)
        vx_s = L*om_s*np.cos(th_s); vy_s = L*om_s*np.sin(th_s)
        state_p2 = np.array([x_s, y_s, vx_s, vy_s], dtype=float)
        in_taut = False
    else:
        sol = solve_ivp(free_flight, (t_cur, duration), state_p2, events=ev_retaut,
                        dense_output=True, rtol=1e-9, atol=1e-11, max_step=0.02)
        seg_end = sol.t[-1]
        while last_idx < N and t_eval[last_idx] <= seg_end + 1e-12:
            st = sol.sol(t_eval[last_idx])
            bob_x[last_idx] = st[0]; bob_y[last_idx] = st[1]
            phase[last_idx] = 2; last_idx += 1
        state_p2 = sol.y[:, -1].copy(); t_cur = seg_end
        if sol.status != 1:
            break
        x_r, y_r, vx_r, vy_r = state_p2
        rn = np.hypot(x_r, y_r)
        rhx, rhy = x_r/rn, y_r/rn
        v_rad = vx_r*rhx + vy_r*rhy
        x_r = L*rhx; y_r = L*rhy
        vx_post = vx_r - v_rad*rhx; vy_post = vy_r - v_rad*rhy
        theta_new = np.arctan2(x_r, -y_r)
        omega_new = (vx_post*np.cos(theta_new) + vy_post*np.sin(theta_new))/L
        state_p1 = np.array([theta_new, omega_new], dtype=float)
        in_taut = True

if last_idx < N:
    bob_x[last_idx:] = bob_x[last_idx-1]
    bob_y[last_idx:] = bob_y[last_idx-1]
    phase[last_idx:] = phase[last_idx-1]

x_lo, x_hi = -(L+0.20), L+0.20
y_lo, y_hi = -(L+0.20), L+0.30
fig_w, fig_h = 6.0, 6.0
fig_aspect = fig_w/fig_h
dx = x_hi - x_lo; dy = y_hi - y_lo
if dx/dy < fig_aspect:
    extra = (fig_aspect*dy - dx)/2.0
    x_lo -= extra; x_hi += extra
else:
    extra = (dx/fig_aspect - dy)/2.0
    y_lo -= extra; y_hi += extra

fig = plt.figure(figsize=(fig_w,fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1]); ax.set_facecolor("#16213e")
ax.set_xlim(x_lo,x_hi); ax.set_ylim(y_lo,y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.plot([0],[0],"o",color="white",ms=6,zorder=6)
string_ln, = ax.plot([],[],"-",color="#cbd5e1",lw=1.6,zorder=3)
bob = patches.Circle((0,0), 0.04, facecolor="#e63946", edgecolor="white", lw=1.2, zorder=5)
ax.add_patch(bob)
trail, = ax.plot([],[],"-",color="#e63946", alpha=0.45, lw=1.4, zorder=2)
tx, ty = [], []

def slack_curve(xb, yb, n=24):
    chord = np.hypot(xb, yb)
    if chord < 1e-9 or chord >= L - 1e-6:
        return np.array([0.0, xb]), np.array([0.0, yb])
    s = np.linspace(0.0, 1.0, n)
    base_x = s*xb; base_y = s*yb
    ux, uy = xb/chord, yb/chord
    px, py = -uy, ux
    if py > 0: px, py = -px, -py
    extra = L/chord - 1.0
    sag = chord*np.sqrt(max(0.0, extra*3.0/8.0))
    bow = 4.0*sag*s*(1.0-s)
    return base_x + bow*px, base_y + bow*py

def update(f):
    xb, yb = bob_x[f], bob_y[f]
    bob.center = (xb, yb)
    if phase[f] == 1:
        string_ln.set_data([0.0, xb],[0.0, yb])
    else:
        sx, sy = slack_curve(xb, yb)
        string_ln.set_data(sx, sy)
    tx.append(xb); ty.append(yb)
    if len(tx) > 120:
        tx.pop(0); ty.pop(0)
    trail.set_data(tx, ty)
    return string_ln, bob, trail

ani = animation.FuncAnimation(fig, update, frames=N, interval=1000.0/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--g", type=float, default=9.8)
    parser.add_argument("--L", type=float, default=1.0)
    parser.add_argument("--m", type=float, default=0.5)
    parser.add_argument("--v_0", type=float, default=5.5)
    parser.add_argument("--damping_b", type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="pendulum_slack_revolution.mp4")
    args = parser.parse_args()
    p = PendulumSlackRevolutionParams(g=args.g, L=args.L, m=args.m,
                                      v_0=args.v_0, damping_b=args.damping_b)
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
