"""
Slab on Two Vertical Springs, Struck by a Falling Block (perfectly inelastic).

Pre-impact: slab in static equilibrium (3-DOF rigid, at rest); block free-falls.
Impact at body-frame x=+L_slab/4 on the slab top: linear & angular momentum
applied to the COMBINED system. Post-impact: 3-DOF Newton-Euler ODE on
(X_com, Y_com, theta) with two vertical-spring forces at the slab ends, gravity,
and viscous damping.
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from matplotlib.transforms import Affine2D
from dataclasses import dataclass, asdict


@dataclass
class SlabSpringsBlockDropParams:
    g: float = 9.8
    M_slab: float = 1.0
    L_slab: float = 1.50
    m_b: float = 0.30
    block_size: float = 0.18
    slab_thickness: float = 0.10
    k: float = 30.0
    L_0: float = 0.60
    gamma_y: float = 0.20
    gamma_theta: float = 0.06
    H_drop: float = 1.00


def _derived(p: SlabSpringsBlockDropParams):
    M_total = p.M_slab + p.m_b
    block_offset_from_centre = p.L_slab / 4.0
    d_block = p.M_slab * block_offset_from_centre / M_total
    d_slab = p.m_b * block_offset_from_centre / M_total
    I_slab = (1.0 / 12.0) * p.M_slab * p.L_slab ** 2
    I_total = I_slab + p.M_slab * d_slab ** 2 + p.m_b * d_block ** 2
    a_arm = -(p.L_slab / 2.0 + d_slab)
    b_arm = +(p.L_slab / 2.0 - d_slab)
    b_block_arm = +d_block
    Y_s_eq = p.L_0 - p.M_slab * p.g / (2.0 * p.k)
    return dict(M_total=M_total, d_block=d_block, d_slab=d_slab,
                I_total=I_total, a_arm=a_arm, b_arm=b_arm,
                b_block_arm=b_block_arm, Y_s_eq=Y_s_eq,
                X_anchor_L=-p.L_slab / 2.0, X_anchor_R=+p.L_slab / 2.0,
                block_offset_from_centre=block_offset_from_centre)


def simulate(
    params: SlabSpringsBlockDropParams,
    duration: float = 12.0,
    fps: int = 30,
) -> tuple[np.ndarray, np.ndarray]:
    """Returns (t, y) where y.shape = (5, N): [X_com, Y_com, theta, y_block, sticky]."""
    p = params
    d = _derived(p)
    Y_s_eq = d["Y_s_eq"]; M_total = d["M_total"]
    a_arm = d["a_arm"]; b_arm = d["b_arm"]
    b_block_arm = d["b_block_arm"]
    d_slab = d["d_slab"]
    I_total = d["I_total"]

    H_drop = p.H_drop
    y_block_0 = Y_s_eq + p.slab_thickness / 2.0 + H_drop
    v_impact = np.sqrt(2.0 * p.g * H_drop)
    t_impact = v_impact / p.g

    v_com_y_after = p.m_b * (-v_impact) / M_total
    omega_after = (b_block_arm * p.m_b * (-v_impact)) / I_total
    X_com0 = 0.0 + d_slab
    Y_com0 = Y_s_eq

    def combined_rhs(t, s):
        X, Y, th, vX, vY, om = s
        c, sn = np.cos(th), np.sin(th)
        yL = Y + a_arm * sn
        yR = Y + b_arm * sn
        FLy = p.k * (p.L_0 - yL)
        FRy = p.k * (p.L_0 - yR)
        aX = 0.0
        aY = (FLy + FRy - M_total * p.g - p.gamma_y * vY) / M_total
        rxL, ryL = a_arm * c, a_arm * sn
        rxR, ryR = b_arm * c, b_arm * sn
        tau = (rxL * FLy) + (rxR * FRy) - p.gamma_theta * om
        aTh = tau / I_total
        return [vX, vY, om, aX, aY, aTh]

    t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
    N = len(t_eval)

    y_block_arr = np.full(N, np.nan)
    X_arr = np.full(N, np.nan)
    Y_arr = np.full(N, np.nan)
    th_arr = np.full(N, np.nan)
    sticky = np.zeros(N, dtype=float)

    for i, t in enumerate(t_eval):
        if t <= t_impact:
            y_b = y_block_0 - 0.5 * p.g * t * t
            y_block_arr[i] = y_b
            X_arr[i] = 0.0
            Y_arr[i] = Y_s_eq
            th_arr[i] = 0.0
            sticky[i] = 0.0
        else:
            sticky[i] = 1.0

    post_idx = np.where(t_eval > t_impact)[0]
    if post_idx.size > 0:
        t_post = t_eval[post_idx]
        t_post_local = np.concatenate(([t_impact], t_post))
        s0 = [X_com0, Y_com0, 0.0, 0.0, v_com_y_after, omega_after]
        sol = solve_ivp(combined_rhs, (t_impact, duration), s0,
                        t_eval=t_post_local, method="RK45",
                        rtol=1e-9, atol=1e-11, max_step=0.005)
        Xs = sol.y[0][1:]
        Ys = sol.y[1][1:]
        ths = sol.y[2][1:]
        for j, idx in enumerate(post_idx):
            X_arr[idx] = Xs[j]
            Y_arr[idx] = Ys[j]
            th_arr[idx] = ths[j]
            y_anchor_above = (p.slab_thickness / 2.0 + p.block_size / 2.0)
            y_block_arr[idx] = (Ys[j]
                                + b_block_arm * np.sin(ths[j])
                                + y_anchor_above * np.cos(ths[j]))

    return t_eval, np.vstack([X_arr, Y_arr, th_arr, y_block_arr, sticky])


def render_video(
    t: np.ndarray,
    y: np.ndarray,
    params: SlabSpringsBlockDropParams,
    output_path: str,
    fps: int = 30,
) -> None:
    p = params
    d = _derived(p)
    a_arm = d["a_arm"]; b_arm = d["b_arm"]
    d_slab = d["d_slab"]
    b_block_arm = d["b_block_arm"]
    Y_s_eq = d["Y_s_eq"]
    X_anchor_L = d["X_anchor_L"]; X_anchor_R = d["X_anchor_R"]
    block_offset_from_centre = d["block_offset_from_centre"]
    H_drop = p.H_drop
    y_block_0 = Y_s_eq + p.slab_thickness / 2.0 + H_drop

    X_arr, Y_arr, th_arr, y_block_arr, sticky_f = y[0], y[1], y[2], y[3], y[4]
    sticky = sticky_f > 0.5

    fig_w, fig_h = 8, 5
    fig_aspect = fig_w / fig_h
    x_lo_d, x_hi_d = -1.20, +1.20
    y_lo_d = -0.20
    y_hi_d = max(1.6, y_block_0 + 0.20)
    dx_d, dy_d = x_hi_d - x_lo_d, y_hi_d - y_lo_d
    if dx_d / dy_d < fig_aspect:
        extra = (fig_aspect * dy_d - dx_d) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx_d / fig_aspect - dy_d) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")

    ax.add_patch(patches.Rectangle((x_lo, y_lo), x_hi - x_lo, -y_lo,
                                   facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.axhline(0.0, color="#adb5bd", lw=2.0, zorder=1)
    for xa in (X_anchor_L, X_anchor_R):
        ax.add_patch(patches.Rectangle((xa - 0.06, -0.025), 0.12, 0.025,
                                       facecolor="#adb5bd", edgecolor="none",
                                       zorder=2))

    slab_patch = patches.Rectangle((-p.L_slab / 2.0, -p.slab_thickness / 2.0),
                                   p.L_slab, p.slab_thickness,
                                   facecolor="#f4d35e", edgecolor="white",
                                   lw=1.5, zorder=4)
    ax.add_patch(slab_patch)
    block_patch = patches.Rectangle((-p.block_size / 2.0, -p.block_size / 2.0),
                                    p.block_size, p.block_size,
                                    facecolor="#e63946", edgecolor="white",
                                    lw=1.5, zorder=5)
    ax.add_patch(block_patch)

    spring_L_line, = ax.plot([], [], color="#a8dadc", lw=2.5, zorder=3)
    spring_R_line, = ax.plot([], [], color="#a8dadc", lw=2.5, zorder=3)

    def spring_zigzag(p0, p1, n_coils=8, amp=0.06, n_pts=200):
        x0, y0 = p0; x1, y1 = p1
        dx, dy = x1 - x0, y1 - y0
        L = np.hypot(dx, dy)
        if L < 1e-9:
            return np.array([x0, x1]), np.array([y0, y1])
        ux, uy = dx / L, dy / L
        nx, ny = -uy, ux
        lead = min(0.06, 0.25 * L)
        s = np.linspace(0.0, 1.0, n_pts)
        arc = s * L
        middle = (arc >= lead) & (arc <= L - lead)
        seg_len = max(L - 2 * lead, 1e-6)
        phase = np.zeros_like(arc)
        phase[middle] = (arc[middle] - lead) / seg_len
        env = np.where(middle, amp * np.sin(2.0 * np.pi * n_coils * phase), 0.0)
        xs = x0 + ux * arc + nx * env
        ys = y0 + uy * arc + ny * env
        return xs, ys

    x_block = block_offset_from_centre

    def update(f):
        th = th_arr[f]
        Xc = X_arr[f]
        Yc = Y_arr[f]
        c, sn = np.cos(th), np.sin(th)

        if sticky[f]:
            slab_com_x = Xc - d_slab * c
            slab_com_y = Yc - d_slab * sn
        else:
            slab_com_x = 0.0
            slab_com_y = Y_s_eq

        tr_slab = (Affine2D().rotate(th)
                              .translate(slab_com_x, slab_com_y)
                              + ax.transData)
        slab_patch.set_transform(tr_slab)

        y_top_offset = p.slab_thickness / 2.0 + p.block_size / 2.0
        if sticky[f]:
            xL = Xc + a_arm * c; yL = Yc + a_arm * sn
            xR = Xc + b_arm * c; yR = Yc + b_arm * sn
            bx = Xc + b_block_arm * c - y_top_offset * sn
            by = Yc + b_block_arm * sn + y_top_offset * c
            tr_block = (Affine2D().rotate(th)
                                  .translate(bx, by)
                                  + ax.transData)
            block_patch.set_transform(tr_block)
        else:
            xL = -p.L_slab / 2.0; yL = Y_s_eq
            xR = +p.L_slab / 2.0; yR = Y_s_eq
            bx = x_block
            by = y_block_arr[f]
            tr_block = (Affine2D().translate(bx, by) + ax.transData)
            block_patch.set_transform(tr_block)

        sxL, syL = spring_zigzag((X_anchor_L, 0.0), (xL, yL))
        sxR, syR = spring_zigzag((X_anchor_R, 0.0), (xR, yR))
        spring_L_line.set_data(sxL, syL)
        spring_R_line.set_data(sxR, syR)
        return slab_patch, block_patch, spring_L_line, spring_R_line

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000 / fps, blit=False)
    ani.save(output_path,
             writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(
    params: SlabSpringsBlockDropParams,
    duration: float = 12.0,
) -> str:
    p = asdict(params)
    return f'''"""Slab on two vertical springs + falling block — auto-generated."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from matplotlib.transforms import Affine2D

g            = {p["g"]}
M_slab       = {p["M_slab"]}
L_slab       = {p["L_slab"]}
m_b          = {p["m_b"]}
block_size   = {p["block_size"]}
slab_thick   = {p["slab_thickness"]}
k            = {p["k"]}
L_0          = {p["L_0"]}
gamma_y      = {p["gamma_y"]}
gamma_theta  = {p["gamma_theta"]}
H_drop       = {p["H_drop"]}
duration     = {duration}
fps          = 30

X_anchor_L = -L_slab/2.0
X_anchor_R = +L_slab/2.0
M_total = M_slab + m_b
block_off = L_slab/4.0
d_block = M_slab*block_off/M_total
d_slab = m_b*block_off/M_total
I_slab = (1.0/12.0)*M_slab*L_slab**2
I_total = I_slab + M_slab*d_slab**2 + m_b*d_block**2
a_arm = -(L_slab/2.0 + d_slab)
b_arm = +(L_slab/2.0 - d_slab)
b_block_arm = +d_block
Y_s_eq = L_0 - M_slab*g/(2.0*k)

y_block_0 = Y_s_eq + slab_thick/2.0 + H_drop
v_impact = np.sqrt(2.0*g*H_drop)
t_impact = v_impact/g
v_com_y_after = m_b*(-v_impact)/M_total
omega_after = (b_block_arm*m_b*(-v_impact))/I_total
X_com0 = d_slab; Y_com0 = Y_s_eq

def rhs(t, s):
    X, Y, th, vX, vY, om = s
    c, sn = np.cos(th), np.sin(th)
    yL = Y + a_arm*sn; yR = Y + b_arm*sn
    FLy = k*(L_0 - yL); FRy = k*(L_0 - yR)
    aY = (FLy + FRy - M_total*g - gamma_y*vY)/M_total
    rxL = a_arm*c; rxR = b_arm*c
    tau = rxL*FLy + rxR*FRy - gamma_theta*om
    return [vX, vY, om, 0.0, aY, tau/I_total]

t_eval = np.linspace(0.0, duration, int(duration*fps)+1)
N = len(t_eval)
y_block_arr = np.full(N, np.nan)
X_arr = np.full(N, np.nan); Y_arr = np.full(N, np.nan); th_arr = np.full(N, np.nan)
sticky = np.zeros(N, dtype=bool)
for i, t in enumerate(t_eval):
    if t <= t_impact:
        y_block_arr[i] = y_block_0 - 0.5*g*t*t
        X_arr[i] = 0.0; Y_arr[i] = Y_s_eq; th_arr[i] = 0.0
    else:
        sticky[i] = True
post = np.where(t_eval > t_impact)[0]
if post.size > 0:
    t_post = t_eval[post]
    t_post_local = np.concatenate(([t_impact], t_post))
    sol = solve_ivp(rhs, (t_impact, duration),
                    [X_com0, Y_com0, 0.0, 0.0, v_com_y_after, omega_after],
                    t_eval=t_post_local, method="RK45",
                    rtol=1e-9, atol=1e-11, max_step=0.005)
    Xs = sol.y[0][1:]; Ys = sol.y[1][1:]; ths = sol.y[2][1:]
    for j, idx in enumerate(post):
        X_arr[idx] = Xs[j]; Y_arr[idx] = Ys[j]; th_arr[idx] = ths[j]
        y_anchor_above = slab_thick/2.0 + block_size/2.0
        y_block_arr[idx] = Ys[j] + b_block_arm*np.sin(ths[j]) + y_anchor_above*np.cos(ths[j])

fig_w, fig_h = 8, 5; fa = fig_w/fig_h
x_lo_d, x_hi_d = -1.20, +1.20
y_lo_d = -0.20
y_hi_d = max(1.6, y_block_0 + 0.20)
dx, dy = x_hi_d-x_lo_d, y_hi_d-y_lo_d
if dx/dy < fa:
    e = (fa*dy-dx)/2.0; xlo, xhi, ylo, yhi = x_lo_d-e, x_hi_d+e, y_lo_d, y_hi_d
else:
    e = (dx/fa-dy)/2.0; xlo, xhi, ylo, yhi = x_lo_d, x_hi_d, y_lo_d-e, y_hi_d+e

fig = plt.figure(figsize=(fig_w,fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0,0,1,1])
ax.set_facecolor("#16213e")
ax.set_xlim(xlo, xhi); ax.set_ylim(ylo, yhi)
ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(patches.Rectangle((xlo, ylo), xhi-xlo, -ylo,
              facecolor="#4a4e69", edgecolor="none", zorder=0))
ax.axhline(0.0, color="#adb5bd", lw=2.0, zorder=1)
for xa in (X_anchor_L, X_anchor_R):
    ax.add_patch(patches.Rectangle((xa-0.06, -0.025), 0.12, 0.025,
                  facecolor="#adb5bd", edgecolor="none", zorder=2))

slab_p = patches.Rectangle((-L_slab/2.0, -slab_thick/2.0), L_slab, slab_thick,
              facecolor="#f4d35e", edgecolor="white", lw=1.5, zorder=4)
ax.add_patch(slab_p)
block_p = patches.Rectangle((-block_size/2.0, -block_size/2.0), block_size, block_size,
              facecolor="#e63946", edgecolor="white", lw=1.5, zorder=5)
ax.add_patch(block_p)
sL, = ax.plot([],[], color="#a8dadc", lw=2.5, zorder=3)
sR, = ax.plot([],[], color="#a8dadc", lw=2.5, zorder=3)

def spzz(p0, p1, n_coils=8, amp=0.06, n_pts=200):
    x0, y0 = p0; x1, y1 = p1
    dx, dy = x1-x0, y1-y0; L = np.hypot(dx, dy)
    if L < 1e-9: return np.array([x0,x1]), np.array([y0,y1])
    ux, uy = dx/L, dy/L; nx, ny = -uy, ux
    lead = min(0.06, 0.25*L)
    s = np.linspace(0,1, n_pts); arc = s*L
    middle = (arc>=lead) & (arc<=L-lead)
    seg = max(L - 2*lead, 1e-6)
    phase = np.zeros_like(arc); phase[middle] = (arc[middle]-lead)/seg
    env = np.where(middle, amp*np.sin(2*np.pi*n_coils*phase), 0.0)
    return x0+ux*arc+nx*env, y0+uy*arc+ny*env

x_block_lab = block_off

def update(f):
    th = th_arr[f]; Xc = X_arr[f]; Yc = Y_arr[f]
    c, sn = np.cos(th), np.sin(th)
    if sticky[f]:
        sx = Xc - d_slab*c; sy = Yc - d_slab*sn
    else:
        sx = 0.0; sy = Y_s_eq
    tr = (Affine2D().rotate(th).translate(sx, sy)) + ax.transData
    slab_p.set_transform(tr)
    y_off = slab_thick/2.0 + block_size/2.0
    if sticky[f]:
        xL = Xc + a_arm*c; yL = Yc + a_arm*sn
        xR = Xc + b_arm*c; yR = Yc + b_arm*sn
        bx = Xc + b_block_arm*c - y_off*sn
        by = Yc + b_block_arm*sn + y_off*c
        tb = (Affine2D().rotate(th).translate(bx, by)) + ax.transData
        block_p.set_transform(tb)
    else:
        xL = -L_slab/2.0; yL = Y_s_eq
        xR = +L_slab/2.0; yR = Y_s_eq
        tb = (Affine2D().translate(x_block_lab, y_block_arr[f])) + ax.transData
        block_p.set_transform(tb)
    sxL, syL = spzz((X_anchor_L, 0.0), (xL, yL))
    sxR, syR = spzz((X_anchor_R, 0.0), (xR, yR))
    sL.set_data(sxL, syL); sR.set_data(sxR, syR)
    return slab_p, block_p, sL, sR

ani = animation.FuncAnimation(fig, update, frames=N, interval=1000/fps, blit=False)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Slab on Springs + Block Drop")
    parser.add_argument("--g", type=float, default=9.8)
    parser.add_argument("--M_slab", type=float, default=1.0)
    parser.add_argument("--L_slab", type=float, default=1.50)
    parser.add_argument("--m_b", type=float, default=0.30)
    parser.add_argument("--block_size", type=float, default=0.18)
    parser.add_argument("--slab_thickness", type=float, default=0.10)
    parser.add_argument("--k", type=float, default=30.0)
    parser.add_argument("--L_0", type=float, default=0.60)
    parser.add_argument("--gamma_y", type=float, default=0.20)
    parser.add_argument("--gamma_theta", type=float, default=0.06)
    parser.add_argument("--H_drop", type=float, default=1.00)
    parser.add_argument("--duration", type=float, default=12.0)
    parser.add_argument("--output", type=str, default="slab_springs_block_drop.mp4")
    args = parser.parse_args()

    p = SlabSpringsBlockDropParams(
        g=args.g, M_slab=args.M_slab, L_slab=args.L_slab, m_b=args.m_b,
        block_size=args.block_size, slab_thickness=args.slab_thickness,
        k=args.k, L_0=args.L_0,
        gamma_y=args.gamma_y, gamma_theta=args.gamma_theta,
        H_drop=args.H_drop,
    )
    print(f"Simulating slab springs block drop: {asdict(p)}")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
