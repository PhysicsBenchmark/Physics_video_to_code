"""
Shared drawing utilities for physics simulation visualizations.
"""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches


def spring_path(x1, y1, x2, y2, n_coils=8, coil_radius=0.1):
    """
    Generate (xs, ys) arrays for a coil-spring visualization between two points.
    Uses a sine-wave profile perpendicular to the spring axis.
    """
    dx, dy = x2 - x1, y2 - y1
    length = np.hypot(dx, dy)
    if length < 1e-10:
        return np.array([x1, x2]), np.array([y1, y2])

    # Unit tangent and perpendicular normal
    ux, uy = dx / length, dy / length
    nx, ny = -uy, ux

    n_pts = n_coils * 20 + 2
    t = np.linspace(0, 1, n_pts)

    # Keep 8% on each end as straight connectors
    margin = 0.08
    envelope = np.where(
        (t < margin) | (t > 1 - margin),
        0.0,
        np.sin(n_coils * 2 * np.pi * (t - margin) / (1 - 2 * margin)),
    )

    xs = x1 + t * dx + coil_radius * envelope * nx
    ys = y1 + t * dy + coil_radius * envelope * ny
    return xs, ys


def setup_dark_axis(fig, ax, xlim, ylim, title=""):
    """Configure axis with the same dark theme as myphysicslab."""
    fig.patch.set_facecolor("#1a1a2e")
    ax.set_facecolor("#16213e")
    ax.set_xlim(xlim)
    ax.set_ylim(ylim)
    ax.set_aspect("equal")
    ax.axis("off")
    if title:
        ax.set_title(title, color="white", fontsize=10, pad=4)


def draw_wall(ax, x_center, y_center, width=0.15, height=0.8, color="#4a4e69"):
    """Draw a hatched wall rectangle."""
    rect = patches.FancyBboxPatch(
        (x_center - width / 2, y_center - height / 2),
        width,
        height,
        boxstyle="square,pad=0",
        linewidth=1,
        edgecolor="#adb5bd",
        facecolor=color,
        hatch="////",
    )
    ax.add_patch(rect)


def draw_block(ax, x_center, y_center, width=0.3, height=0.3, color="#e63946"):
    """Draw a block (square/rectangle)."""
    rect = patches.FancyBboxPatch(
        (x_center - width / 2, y_center - height / 2),
        width,
        height,
        boxstyle="round,pad=0.02",
        linewidth=1.5,
        edgecolor="white",
        facecolor=color,
    )
    ax.add_patch(rect)
    return rect


def draw_cart(ax, x_center, y_center=0.0, width=0.6, height=0.3, color="#457b9d"):
    """Draw a cart with wheels."""
    body = patches.FancyBboxPatch(
        (x_center - width / 2, y_center),
        width,
        height,
        boxstyle="round,pad=0.02",
        linewidth=1.5,
        edgecolor="white",
        facecolor=color,
    )
    ax.add_patch(body)
    # Wheels
    wheel_r = 0.07
    for wx in [x_center - width / 3, x_center + width / 3]:
        wheel = plt.Circle((wx, y_center), wheel_r, color="#a8dadc", zorder=3)
        ax.add_patch(wheel)
