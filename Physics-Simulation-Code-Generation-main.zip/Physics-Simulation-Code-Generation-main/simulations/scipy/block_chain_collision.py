"""
Block Chain Collision — Newton's-cradle-style chain of cubes on a frictional floor.
Striker enters from right, propagates momentum through 5 stationary blocks.
"""
from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))


@dataclass
class BlockChainCollisionParams:
    # N_static: number of stationary blocks in the chain (sampled uniformly in [3, 8]
    # by drawing a float in [3, 9) and floor()ing). N_blocks = N_static + 1 (chain +
    # striker) is derived in __post_init__.
    N_static: int = 5
    m: float = 0.5
    v_incoming: float = -3.0
    block_size: float = 0.20
    gap: float = 0.05
    e_rest: float = 0.95
    mu_k: float = 0.15
    g: float = 9.81
    x6_init: float = 2.5
    duration: float = 12.0
    fps: int = 30
    N_blocks: int = 0  # derived

    def __post_init__(self):
        # Coerce a possibly-float-sampled N_static to an integer in [3, 8] and derive
        # the total block count.
        self.N_static = int(self.N_static)
        self.N_blocks = self.N_static + 1


def _run_sim(p):
    N_BLOCKS = int(p.N_blocks); N_STATIC = int(p.N_static)
    m = p.m; e_rest = p.e_rest; mu_k = p.mu_k; g = p.g
    block_size = p.block_size; gap = p.gap
    V_EPS = 1e-4; GAP_EPS = 1e-9

    total_static_width = N_STATIC * block_size + (N_STATIC - 1) * gap
    left_edge_first = -total_static_width / 2.0
    x_static = np.array([left_edge_first + block_size / 2.0 + i * (block_size + gap)
                          for i in range(N_STATIC)])
    x0 = np.concatenate([x_static, [p.x6_init]])
    v0 = np.zeros(N_BLOCKS); v0[-1] = p.v_incoming
    state0 = np.concatenate([x0, v0])
    masses = np.full(N_BLOCKS, m)

    def rhs(t, y):
        v = y[N_BLOCKS:]
        dxdt = v.copy()
        dvdt = np.zeros(N_BLOCKS)
        moving = np.abs(v) > V_EPS
        dvdt[moving] = -mu_k * g * np.sign(v[moving])
        return np.concatenate([dxdt, dvdt])

    def make_event(i):
        def ev(t, y):
            return (y[i + 1] - y[i]) - block_size
        ev.terminal = True; ev.direction = -1.0
        return ev
    events = [make_event(i) for i in range(N_BLOCKS - 1)]

    def apply_collision(state, i, j, e):
        v = state[N_BLOCKS:]
        mi, mj = masses[i], masses[j]
        vi, vj = v[i], v[j]
        new_vi = ((1.0 - e) * mi * vi + (1.0 + e) * mj * vj) / (mi + mj)
        new_vj = ((1.0 + e) * mi * vi + (1.0 - e) * mj * vj) / (mi + mj)
        state[N_BLOCKS + i] = new_vi
        state[N_BLOCKS + j] = new_vj
        return state

    fps = int(p.fps)
    duration = p.duration
    t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
    times = [0.0]; states = [state0.copy()]
    t_now = 0.0; y_now = state0.copy()
    n_collisions = 0
    MAX_COLLISIONS = 5000

    while t_now < duration and n_collisions < MAX_COLLISIONS:
        sub_eval = t_eval[t_eval > t_now + 1e-12]
        if sub_eval.size == 0: sub_eval = None
        sol = solve_ivp(rhs, (t_now, duration), y_now, t_eval=sub_eval,
                        events=events, method="RK45", rtol=1e-9, atol=1e-11, max_step=0.01)
        sol_t = np.atleast_1d(np.asarray(sol.t)).ravel()
        if sol_t.size > 0:
            sol_y = np.asarray(sol.y)
            for k in range(sol_t.size):
                times.append(sol_t[k]); states.append(sol_y[:, k].copy())
        if sol.status == 1:
            ev_t = None; ev_pair = -1
            for i, te in enumerate(sol.t_events):
                if te.size > 0:
                    t_cand = te[-1]
                    if ev_t is None or t_cand < ev_t - 1e-15:
                        ev_t = t_cand; ev_pair = i
            y_at_event = sol.y_events[ev_pair][-1].copy()
            v_i = y_at_event[N_BLOCKS + ev_pair]
            v_j = y_at_event[N_BLOCKS + ev_pair + 1]
            if v_i - v_j > 0:
                y_at_event = apply_collision(y_at_event, ev_pair, ev_pair + 1, e_rest)
                n_collisions += 1
            else:
                y_at_event[ev_pair + 1] += 2 * GAP_EPS
            times.append(ev_t); states.append(y_at_event.copy())
            t_now = ev_t; y_now = y_at_event
        else:
            t_now = duration
            break

    t_arr = np.array(times); s_arr = np.array(states)
    order = np.argsort(t_arr, kind="stable")
    t_arr = t_arr[order]; s_arr = s_arr[order]
    unique_times = []; last_idx = []
    for k in range(t_arr.size):
        if k + 1 < t_arr.size and abs(t_arr[k+1] - t_arr[k]) < 1e-12:
            continue
        unique_times.append(t_arr[k]); last_idx.append(k)
    unique_times = np.array(unique_times); last_idx = np.array(last_idx)
    s_unique = s_arr[last_idx]

    def sample(comp_idx):
        return np.interp(t_eval, unique_times, s_unique[:, comp_idx])
    frame_x = np.stack([sample(i) for i in range(N_BLOCKS)], axis=1)
    return t_eval, frame_x


def simulate(params: BlockChainCollisionParams, duration: float = 12.0, fps: int = 30):
    if duration is not None: params.duration = duration
    t, frame_x = _run_sim(params)
    # frame_x shape (T, N); pack as (N, T)
    y = frame_x.T
    return t, y


def render_video(t, y, params: BlockChainCollisionParams,
                 output_path: str, fps: int = 30):
    p = params
    N_BLOCKS = int(p.N_blocks)
    block_size = p.block_size
    frame_x = y.T  # (T, N)

    x_lo_d = float(np.min(frame_x) - block_size)
    x_hi_d = float(np.max(frame_x) + block_size)
    x_lo_d = min(x_lo_d, -3.0); x_hi_d = max(x_hi_d, 3.0)
    y_lo_d, y_hi_d = -0.3, 0.6
    fig_w, fig_h = 8, 4
    fig_aspect = fig_w / fig_h
    dx = x_hi_d - x_lo_d; dy = y_hi_d - y_lo_d
    if dx / dy < fig_aspect:
        extra = (fig_aspect * dy - dx) / 2.0
        x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
        y_lo, y_hi = y_lo_d, y_hi_d
    else:
        extra = (dx / fig_aspect - dy) / 2.0
        x_lo, x_hi = x_lo_d, x_hi_d
        y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

    fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("#16213e")
    ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
    ax.set_aspect("equal"); ax.axis("off")
    ax.add_patch(patches.Rectangle((x_lo, y_lo), x_hi - x_lo, -y_lo,
                                    facecolor="#4a4e69", edgecolor="none", zorder=0))
    ax.plot([x_lo, x_hi], [0.0, 0.0], color="#adb5bd", lw=2.0, zorder=1)

    block_patches = []
    for i in range(N_BLOCKS):
        color = "#e63946" if i == N_BLOCKS - 1 else "#a8dadc"
        rect = patches.Rectangle((frame_x[0, i] - block_size/2.0, 0.0),
                                  block_size, block_size,
                                  facecolor=color, edgecolor="#1d3557", lw=1.0, zorder=3)
        ax.add_patch(rect); block_patches.append(rect)

    def update(f):
        for i, rect in enumerate(block_patches):
            rect.set_xy((frame_x[f, i] - block_size/2.0, 0.0))
        return tuple(block_patches)

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000.0/fps, blit=True)
    ani.save(output_path, writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
    plt.close(fig)


def make_standalone_script(params: BlockChainCollisionParams,
                           duration: float = 12.0) -> str:
    p = asdict(params)
    p["duration"] = duration
    return f'''"""Block chain collision - standalone script."""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

N_BLOCKS = {p["N_blocks"]}; N_STATIC = {p["N_static"]}
m = {p["m"]}; v_incoming = {p["v_incoming"]}; block_size = {p["block_size"]}
gap = {p["gap"]}; e_rest = {p["e_rest"]}; mu_k = {p["mu_k"]}; g = {p["g"]}
duration = {p["duration"]}; fps = {p["fps"]}; x6_init = {p["x6_init"]}
V_EPS = 1e-4; GAP_EPS = 1e-9

total_static_width = N_STATIC * block_size + (N_STATIC - 1) * gap
left_edge_first = -total_static_width / 2.0
x_static = np.array([left_edge_first + block_size / 2.0 + i * (block_size + gap)
                      for i in range(N_STATIC)])
x0 = np.concatenate([x_static, [x6_init]])
v0 = np.zeros(N_BLOCKS); v0[-1] = v_incoming
state0 = np.concatenate([x0, v0])
masses = np.full(N_BLOCKS, m)


def rhs(t, y):
    v = y[N_BLOCKS:]
    dxdt = v.copy()
    dvdt = np.zeros(N_BLOCKS)
    moving = np.abs(v) > V_EPS
    dvdt[moving] = -mu_k * g * np.sign(v[moving])
    return np.concatenate([dxdt, dvdt])


def make_event(i):
    def ev(t, y):
        return (y[i + 1] - y[i]) - block_size
    ev.terminal = True; ev.direction = -1.0
    return ev


events = [make_event(i) for i in range(N_BLOCKS - 1)]


def apply_collision(state, i, j, e):
    v = state[N_BLOCKS:]
    mi, mj = masses[i], masses[j]
    vi, vj = v[i], v[j]
    new_vi = ((1.0 - e) * mi * vi + (1.0 + e) * mj * vj) / (mi + mj)
    new_vj = ((1.0 + e) * mi * vi + (1.0 - e) * mj * vj) / (mi + mj)
    state[N_BLOCKS + i] = new_vi
    state[N_BLOCKS + j] = new_vj
    return state


t_eval = np.linspace(0.0, duration, int(duration * fps) + 1)
times = [0.0]; states = [state0.copy()]
t_now = 0.0; y_now = state0.copy()
n_collisions = 0
MAX_COLLISIONS = 5000

while t_now < duration and n_collisions < MAX_COLLISIONS:
    sub_eval = t_eval[t_eval > t_now + 1e-12]
    if sub_eval.size == 0: sub_eval = None
    sol = solve_ivp(rhs, (t_now, duration), y_now, t_eval=sub_eval,
                    events=events, method="RK45", rtol=1e-9, atol=1e-11, max_step=0.01)
    sol_t = np.atleast_1d(np.asarray(sol.t)).ravel()
    if sol_t.size > 0:
        sol_y = np.asarray(sol.y)
        for k in range(sol_t.size):
            times.append(sol_t[k]); states.append(sol_y[:, k].copy())
    if sol.status == 1:
        ev_t = None; ev_pair = -1
        for i, te in enumerate(sol.t_events):
            if te.size > 0:
                t_cand = te[-1]
                if ev_t is None or t_cand < ev_t - 1e-15:
                    ev_t = t_cand; ev_pair = i
        y_at_event = sol.y_events[ev_pair][-1].copy()
        v_i = y_at_event[N_BLOCKS + ev_pair]
        v_j = y_at_event[N_BLOCKS + ev_pair + 1]
        if v_i - v_j > 0:
            y_at_event = apply_collision(y_at_event, ev_pair, ev_pair + 1, e_rest)
            n_collisions += 1
        else:
            y_at_event[ev_pair + 1] += 2 * GAP_EPS
        times.append(ev_t); states.append(y_at_event.copy())
        t_now = ev_t; y_now = y_at_event
    else:
        t_now = duration
        break

t_arr = np.array(times); s_arr = np.array(states)
order = np.argsort(t_arr, kind="stable")
t_arr = t_arr[order]; s_arr = s_arr[order]
unique_times = []; last_idx = []
for k in range(t_arr.size):
    if k + 1 < t_arr.size and abs(t_arr[k+1] - t_arr[k]) < 1e-12:
        continue
    unique_times.append(t_arr[k]); last_idx.append(k)
unique_times = np.array(unique_times); last_idx = np.array(last_idx)
s_unique = s_arr[last_idx]


def sample(comp_idx):
    return np.interp(t_eval, unique_times, s_unique[:, comp_idx])


frame_x = np.stack([sample(i) for i in range(N_BLOCKS)], axis=1)

x_lo_d = float(np.min(frame_x) - block_size)
x_hi_d = float(np.max(frame_x) + block_size)
x_lo_d = min(x_lo_d, -3.0); x_hi_d = max(x_hi_d, 3.0)
y_lo_d, y_hi_d = -0.3, 0.6
fig_w, fig_h = 8, 4
fig_aspect = fig_w / fig_h
dx = x_hi_d - x_lo_d; dy = y_hi_d - y_lo_d
if dx / dy < fig_aspect:
    extra = (fig_aspect * dy - dx) / 2.0
    x_lo, x_hi = x_lo_d - extra, x_hi_d + extra
    y_lo, y_hi = y_lo_d, y_hi_d
else:
    extra = (dx / fig_aspect - dy) / 2.0
    x_lo, x_hi = x_lo_d, x_hi_d
    y_lo, y_hi = y_lo_d - extra, y_hi_d + extra

fig = plt.figure(figsize=(fig_w, fig_h), facecolor="#1a1a2e")
ax = fig.add_axes([0, 0, 1, 1])
ax.set_facecolor("#16213e")
ax.set_xlim(x_lo, x_hi); ax.set_ylim(y_lo, y_hi)
ax.set_aspect("equal"); ax.axis("off")
ax.add_patch(patches.Rectangle((x_lo, y_lo), x_hi - x_lo, -y_lo,
                                facecolor="#4a4e69", edgecolor="none", zorder=0))
ax.plot([x_lo, x_hi], [0.0, 0.0], color="#adb5bd", lw=2.0, zorder=1)

block_patches = []
for i in range(N_BLOCKS):
    color = "#e63946" if i == N_BLOCKS - 1 else "#a8dadc"
    rect = patches.Rectangle((frame_x[0, i] - block_size/2.0, 0.0),
                              block_size, block_size,
                              facecolor=color, edgecolor="#1d3557", lw=1.0, zorder=3)
    ax.add_patch(rect); block_patches.append(rect)


def update(f):
    for i, rect in enumerate(block_patches):
        rect.set_xy((frame_x[f, i] - block_size/2.0, 0.0))
    return tuple(block_patches)


ani = animation.FuncAnimation(fig, update, frames=len(t_eval),
                              interval=1000.0/fps, blit=True)
ani.save("video.mp4", writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    p = BlockChainCollisionParams()
    t, y = simulate(p, duration=p.duration)
    render_video(t, y, p, "video.mp4")
