"""
U-Tube Fluid Oscillation on an Accelerating Cart
=================================================
A vertical U-tube with two arms (cross-sections A_1, A_2) and a horizontal bottom
segment (cross-section A_b) is rigidly mounted on a cart that oscillates
horizontally. The fluid (density ρ) responds to (a) gravity (hydrostatic pressure
drives the level back to equality), (b) the inertial pseudo-force in the cart's
non-inertial frame (acts horizontally on the bottom segment), and (c) viscous
damping.

Generalised coordinate
----------------------
ξ = displacement of the LEFT-arm fluid level above its equilibrium height h_0.
Volume conservation A_1·h_L + A_2·h_R = const gives h_R = h_0 - (A_1/A_2)·ξ.

Equation of motion (linearised about ξ = 0)
-------------------------------------------
    m_eff · ξ̈ + b · ξ̇ + k · ξ = ρ · A_1 · D · a_cart(t)

with
    m_eff = ρ · [ A_1 · h_0 + A_1² · h_0 / A_2 + A_1² · D / A_b ]
        (total kinetic energy contributions from both arms and the bottom segment
         under continuity v_L=ξ̇, v_R=-(A_1/A_2)·ξ̇, v_b=-(A_1/A_b)·ξ̇)
    k     = ρ · g · A_1 · (A_1 + A_2) / A_2
        (∂²PE/∂ξ²; both columns store gravitational PE as their heights change)
    F_drive(t) = ρ · A_1 · D · a_cart(t)
        (generalised force from the inertial pseudo-force on the bottom segment;
         the vertical arms feel no horizontal pseudo-force component along ξ)

Cart kinematics:  x_cart(t) = X_amp · sin(ω·t),  a_cart(t) = -X_amp·ω²·sin(ω·t).

Natural frequency:  ω_n = sqrt(k / m_eff).
For uniform tube (A_1 = A_2 = A_b = A):  ω_n = sqrt(2g / L_total) where
L_total = 2h_0 + D — the well-known "U-tube oscillation" period.

State vector:  [ξ, ξ̇]
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis


@dataclass
class UTubeFluidOscillationParams:
    A1: float    = 1.0e-3   # left  arm cross-sectional area  (m²)
    A2: float    = 1.0e-3   # right arm cross-sectional area  (m²)
    h0: float    = 0.30     # equilibrium fluid column height in each arm (m)
    L_arm: float = 0.60     # arm length (cap before fluid spills, m)
    D: float     = 0.30     # horizontal distance between arm centres (m)
    rho: float   = 1000.0   # fluid mass density (kg/m³)
    g: float     = 9.81     # gravitational acceleration (m/s²)
    b_damping: float = 0.5  # viscous damping coefficient on ξ  (kg/s)
    X_amp: float       = 0.10   # cart oscillation amplitude (m)
    omega_drive: float = 4.0    # cart angular frequency (rad/s)
    xi0: float    = 0.0   # initial fluid displacement (m)
    xi_dot0: float = 0.0  # initial fluid velocity     (m/s)


def _cart_motion(t, p):
    """Sinusoidal cart kinematics; returns (x, v, a)."""
    s = np.sin(p.omega_drive * t)
    c = np.cos(p.omega_drive * t)
    x =  p.X_amp * s
    v =  p.X_amp * p.omega_drive * c
    a = -p.X_amp * p.omega_drive ** 2 * s
    return x, v, a


def _derived(p):
    """Linearised m_eff, k, drive coefficient, A_b."""
    A_b = max(p.A1, p.A2)         # bottom segment area = larger of the two arms
    m_eff = p.rho * (p.A1 * p.h0 + p.A1 ** 2 * p.h0 / p.A2 + p.A1 ** 2 * p.D / A_b)
    k_restore = p.rho * p.g * p.A1 * (p.A1 + p.A2) / p.A2
    drive_coeff = p.rho * p.A1 * p.D
    return m_eff, k_restore, drive_coeff, A_b


def ode(t, y, p: UTubeFluidOscillationParams):
    """Linearised damped-driven harmonic oscillator for ξ."""
    xi, xi_dot = y
    _, _, a_cart = _cart_motion(t, p)
    m_eff, k, drive_coeff, _ = _derived(p)
    F_drive = drive_coeff * a_cart
    xi_ddot = (F_drive - p.b_damping * xi_dot - k * xi) / m_eff
    return [xi_dot, xi_ddot]


def simulate(params: UTubeFluidOscillationParams,
             duration: float = 4.5, fps: int = 30):
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode, (0, duration), [params.xi0, params.xi_dot0],
        t_eval=t_eval, args=(params,),
        method="RK45", rtol=1e-9, atol=1e-11,
    )
    return sol.t, sol.y


def render_video(t, y, params: UTubeFluidOscillationParams,
                 output_path: str, fps: int = 30):
    """Side-view: cart with wheels translates sinusoidally; mounted U-tube has
    fluid columns whose heights respond to cart acceleration."""
    p   = params
    xi  = y[0]

    # Fluid column heights from ξ and volume conservation
    h_L_arr = p.h0 + xi
    h_R_arr = p.h0 - (p.A1 / p.A2) * xi
    h_L_clip = np.clip(h_L_arr, 0.0, p.L_arm)
    h_R_clip = np.clip(h_R_arr, 0.0, p.L_arm)

    # Cart positions through the run
    x_cart_arr = np.array([_cart_motion(ti, p)[0] for ti in t])

    # Cart geometry
    cart_w, cart_h = 1.30, 0.16
    wheel_r = 0.07

    # U-tube visual radii (scaled so the largest of the two arms ~ 0.05 m wide
    # for clear visibility; tube width on screen is proportional to √A).
    a_max = max(p.A1, p.A2)
    visual_scale = 0.05 / np.sqrt(a_max)
    visual_r1 = max(0.020, 0.5 * visual_scale * np.sqrt(p.A1))
    visual_r2 = max(0.020, 0.5 * visual_scale * np.sqrt(p.A2))

    # Bottom-pipe vertical thickness (visual only)
    pipe_th = 0.05

    # Frame extents
    margin_x = 0.6
    x_min = -p.X_amp - cart_w / 2 - margin_x
    x_max = +p.X_amp + cart_w / 2 + margin_x
    y_min = -0.18
    y_max = cart_h + pipe_th + p.L_arm + 0.18

    fig, ax = plt.subplots(figsize=(10, 5))
    setup_dark_axis(fig, ax, (x_min, x_max), (y_min, y_max))

    # Static: track + zero-line marker
    ax.axhline(0, color="#4a4e69", lw=1.5, zorder=0)
    ax.axvline(0, color="#444", lw=0.6, ls="--", alpha=0.4, zorder=0)

    # Cart body + wheels
    cart_rect = patches.FancyBboxPatch(
        (x_cart_arr[0] - cart_w / 2, 0), cart_w, cart_h,
        boxstyle="round,pad=0.02", lw=1.5,
        edgecolor="white", facecolor="#457b9d", zorder=2,
    )
    ax.add_patch(cart_rect)
    wheel_l = patches.Circle((x_cart_arr[0] - cart_w / 3, -wheel_r),
                              wheel_r, color="#a8dadc", zorder=3)
    wheel_r_ = patches.Circle((x_cart_arr[0] + cart_w / 3, -wheel_r),
                                wheel_r, color="#a8dadc", zorder=3)
    ax.add_patch(wheel_l); ax.add_patch(wheel_r_)

    # U-tube glass body (light-coloured patches representing empty tube interior)
    tube_face   = "#1f2c3e"
    tube_edge   = "#a8b5c5"
    fluid_face  = "#48c9b0"

    tube_left   = patches.Rectangle((0, 0), 0, 0,
                                    facecolor=tube_face, edgecolor=tube_edge,
                                    lw=1.4, zorder=2)
    tube_right  = patches.Rectangle((0, 0), 0, 0,
                                    facecolor=tube_face, edgecolor=tube_edge,
                                    lw=1.4, zorder=2)
    tube_bottom = patches.Rectangle((0, 0), 0, 0,
                                    facecolor=tube_face, edgecolor=tube_edge,
                                    lw=1.4, zorder=2)
    ax.add_patch(tube_left); ax.add_patch(tube_right); ax.add_patch(tube_bottom)

    # Fluid (drawn over the tube interior; heights animated)
    fluid_left   = patches.Rectangle((0, 0), 0, 0, facecolor=fluid_face,
                                     edgecolor="none", alpha=0.95, zorder=3)
    fluid_right  = patches.Rectangle((0, 0), 0, 0, facecolor=fluid_face,
                                     edgecolor="none", alpha=0.95, zorder=3)
    fluid_bottom = patches.Rectangle((0, 0), 0, 0, facecolor=fluid_face,
                                     edgecolor="none", alpha=0.95, zorder=3)
    ax.add_patch(fluid_left); ax.add_patch(fluid_right); ax.add_patch(fluid_bottom)

    def update(frame):
        x_c = x_cart_arr[frame]
        h_L = h_L_clip[frame]
        h_R = h_R_clip[frame]

        # Cart
        cart_rect.set_x(x_c - cart_w / 2)
        wheel_l.center  = (x_c - cart_w / 3, -wheel_r)
        wheel_r_.center = (x_c + cart_w / 3, -wheel_r)

        # U-tube geometry on the cart
        x_L_c = x_c - p.D / 2
        x_R_c = x_c + p.D / 2
        x_LL  = x_L_c - visual_r1; x_LR = x_L_c + visual_r1
        x_RL  = x_R_c - visual_r2; x_RR = x_R_c + visual_r2
        y_pb  = cart_h
        y_pt  = y_pb + pipe_th
        y_at  = y_pt + p.L_arm

        # Tube interior (light fill) = empty tube
        tube_left.set_xy((x_LL, y_pt));   tube_left.set_width(2 * visual_r1);  tube_left.set_height(p.L_arm)
        tube_right.set_xy((x_RL, y_pt));  tube_right.set_width(2 * visual_r2); tube_right.set_height(p.L_arm)
        tube_bottom.set_xy((x_LL, y_pb)); tube_bottom.set_width(x_RR - x_LL);  tube_bottom.set_height(pipe_th)

        # Fluid fills (overlay onto tube interior)
        fluid_left.set_xy((x_LL, y_pt));   fluid_left.set_width(2 * visual_r1); fluid_left.set_height(h_L)
        fluid_right.set_xy((x_RL, y_pt));  fluid_right.set_width(2 * visual_r2); fluid_right.set_height(h_R)
        fluid_bottom.set_xy((x_LL, y_pb)); fluid_bottom.set_width(x_RR - x_LL);  fluid_bottom.set_height(pipe_th)

        return [cart_rect, wheel_l, wheel_r_,
                tube_left, tube_right, tube_bottom,
                fluid_left, fluid_right, fluid_bottom]

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000 / fps, blit=False)
    ani.save(output_path,
             writer=animation.FFMpegWriter(fps=fps, bitrate=1800),
             dpi=120)
    plt.close(fig)


def make_standalone_script(params: UTubeFluidOscillationParams,
                           duration: float = 4.5) -> str:
    p = asdict(params)
    return f'''"""
U-Tube Fluid Oscillation on an Accelerating Cart — auto-generated script.

Physics (linearised about ξ=0, with volume conservation A_1·h_L+A_2·h_R=const):
    m_eff · ξ̈ + b · ξ̇ + k · ξ = ρ · A_1 · D · a_cart(t)
    m_eff = ρ·[A_1·h_0 + A_1²·h_0/A_2 + A_1²·D/A_b]
    k     = ρ·g·A_1·(A_1+A_2)/A_2
    a_cart(t) = -X_amp·ω²·sin(ω·t)   (cart kinematic drive)
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

A1, A2     = {p["A1"]}, {p["A2"]}
h0, L_arm  = {p["h0"]}, {p["L_arm"]}
D, rho, g  = {p["D"]}, {p["rho"]}, {p["g"]}
b_damping  = {p["b_damping"]}
X_amp, omega_drive = {p["X_amp"]}, {p["omega_drive"]}
xi0, xi_dot0 = {p["xi0"]}, {p["xi_dot0"]}
duration, fps = {duration}, 30

A_b = max(A1, A2)
m_eff       = rho * (A1 * h0 + A1**2 * h0 / A2 + A1**2 * D / A_b)
k_restore   = rho * g * A1 * (A1 + A2) / A2
drive_coeff = rho * A1 * D


def cart_motion(t):
    s = np.sin(omega_drive * t); c = np.cos(omega_drive * t)
    return X_amp * s, X_amp * omega_drive * c, -X_amp * omega_drive ** 2 * s


def ode(t, y):
    xi, xi_dot = y
    _, _, a_cart = cart_motion(t)
    F_drive = drive_coeff * a_cart
    return [xi_dot, (F_drive - b_damping * xi_dot - k_restore * xi) / m_eff]


t_eval = np.linspace(0, duration, int(duration * fps) + 1)
sol = solve_ivp(ode, (0, duration), [xi0, xi_dot0], t_eval=t_eval,
                method="RK45", rtol=1e-9, atol=1e-11)
xi_arr = sol.y[0]
h_L = np.clip(h0 + xi_arr,           0.0, L_arm)
h_R = np.clip(h0 - (A1 / A2) * xi_arr, 0.0, L_arm)
x_cart_arr = np.array([cart_motion(ti)[0] for ti in sol.t])

cart_w, cart_h = 1.30, 0.16
wheel_r = 0.07
a_max = max(A1, A2)
visual_scale = 0.05 / np.sqrt(a_max)
vr1 = max(0.020, 0.5 * visual_scale * np.sqrt(A1))
vr2 = max(0.020, 0.5 * visual_scale * np.sqrt(A2))
pipe_th = 0.05

margin_x = 0.6
x_min = -X_amp - cart_w / 2 - margin_x
x_max = +X_amp + cart_w / 2 + margin_x
y_min = -0.18
y_max = cart_h + pipe_th + L_arm + 0.18

fig, ax = plt.subplots(figsize=(10, 5), facecolor="#1a1a2e")
ax.set_facecolor("#16213e")
ax.set_xlim(x_min, x_max); ax.set_ylim(y_min, y_max)
ax.set_aspect("equal"); ax.axis("off")
ax.axhline(0, color="#4a4e69", lw=1.5, zorder=0)
ax.axvline(0, color="#444", lw=0.6, ls="--", alpha=0.4, zorder=0)

cart_rect = patches.FancyBboxPatch(
    (x_cart_arr[0] - cart_w / 2, 0), cart_w, cart_h,
    boxstyle="round,pad=0.02", lw=1.5,
    edgecolor="white", facecolor="#457b9d", zorder=2)
ax.add_patch(cart_rect)
wheel_l  = patches.Circle((x_cart_arr[0] - cart_w / 3, -wheel_r),
                           wheel_r, color="#a8dadc", zorder=3)
wheel_r_ = patches.Circle((x_cart_arr[0] + cart_w / 3, -wheel_r),
                           wheel_r, color="#a8dadc", zorder=3)
ax.add_patch(wheel_l); ax.add_patch(wheel_r_)

tube_face, tube_edge, fluid_face = "#1f2c3e", "#a8b5c5", "#48c9b0"
tube_L = patches.Rectangle((0, 0), 0, 0, facecolor=tube_face, edgecolor=tube_edge, lw=1.4, zorder=2)
tube_R = patches.Rectangle((0, 0), 0, 0, facecolor=tube_face, edgecolor=tube_edge, lw=1.4, zorder=2)
tube_B = patches.Rectangle((0, 0), 0, 0, facecolor=tube_face, edgecolor=tube_edge, lw=1.4, zorder=2)
ax.add_patch(tube_L); ax.add_patch(tube_R); ax.add_patch(tube_B)
fluid_L = patches.Rectangle((0, 0), 0, 0, facecolor=fluid_face, edgecolor="none", alpha=0.95, zorder=3)
fluid_R = patches.Rectangle((0, 0), 0, 0, facecolor=fluid_face, edgecolor="none", alpha=0.95, zorder=3)
fluid_B = patches.Rectangle((0, 0), 0, 0, facecolor=fluid_face, edgecolor="none", alpha=0.95, zorder=3)
ax.add_patch(fluid_L); ax.add_patch(fluid_R); ax.add_patch(fluid_B)


def update(frame):
    x_c = x_cart_arr[frame]
    cart_rect.set_x(x_c - cart_w / 2)
    wheel_l.center  = (x_c - cart_w / 3, -wheel_r)
    wheel_r_.center = (x_c + cart_w / 3, -wheel_r)
    x_L_c = x_c - D / 2; x_R_c = x_c + D / 2
    x_LL = x_L_c - vr1; x_LR = x_L_c + vr1
    x_RL = x_R_c - vr2; x_RR = x_R_c + vr2
    y_pb = cart_h; y_pt = y_pb + pipe_th
    tube_L.set_xy((x_LL, y_pt));   tube_L.set_width(2 * vr1);    tube_L.set_height(L_arm)
    tube_R.set_xy((x_RL, y_pt));   tube_R.set_width(2 * vr2);    tube_R.set_height(L_arm)
    tube_B.set_xy((x_LL, y_pb));   tube_B.set_width(x_RR - x_LL); tube_B.set_height(pipe_th)
    fluid_L.set_xy((x_LL, y_pt));  fluid_L.set_width(2 * vr1);   fluid_L.set_height(h_L[frame])
    fluid_R.set_xy((x_RL, y_pt));  fluid_R.set_width(2 * vr2);   fluid_R.set_height(h_R[frame])
    fluid_B.set_xy((x_LL, y_pb));  fluid_B.set_width(x_RR - x_LL); fluid_B.set_height(pipe_th)
    return [cart_rect, wheel_l, wheel_r_, tube_L, tube_R, tube_B, fluid_L, fluid_R, fluid_B]


ani = animation.FuncAnimation(fig, update, frames=len(sol.t),
                              interval=1000 / fps, blit=False)
ani.save("video.mp4",
         writer=animation.FFMpegWriter(fps=fps, bitrate=1800), dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="U-Tube Fluid Oscillation on accelerating cart")
    parser.add_argument("--A1", type=float, default=1.0e-3)
    parser.add_argument("--A2", type=float, default=1.0e-3)
    parser.add_argument("--h0", type=float, default=0.30)
    parser.add_argument("--L_arm", type=float, default=0.60)
    parser.add_argument("--D",  type=float, default=0.30)
    parser.add_argument("--b_damping",  type=float, default=0.5)
    parser.add_argument("--X_amp",      type=float, default=0.10)
    parser.add_argument("--omega_drive", type=float, default=4.0)
    parser.add_argument("--duration",   type=float, default=4.5)
    parser.add_argument("--output",     type=str,   default="u_tube.mp4")
    args = parser.parse_args()
    p = UTubeFluidOscillationParams(
        A1=args.A1, A2=args.A2, h0=args.h0, L_arm=args.L_arm, D=args.D,
        b_damping=args.b_damping, X_amp=args.X_amp, omega_drive=args.omega_drive,
    )
    print(f"Params: {asdict(p)}")
    m_eff, k, drv, A_b = _derived(p)
    print(f"  m_eff = {m_eff:.5f} kg, k = {k:.4f} N/m,  ω_n = {np.sqrt(k/m_eff):.3f} rad/s "
          f"({np.sqrt(k/m_eff) / (2*np.pi):.3f} Hz),  T_n = {2*np.pi/np.sqrt(k/m_eff):.3f} s")
    print(f"  Static tilt at peak a (= X_amp·ω²): Δh_eq = {p.D * p.X_amp * p.omega_drive**2 / p.g:.4f} m")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
