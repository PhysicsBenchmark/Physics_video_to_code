"""
Sand Onto Moving Cart — Variable-Mass Newton's 2nd Law
=======================================================
A frictionless cart of mass M moves with initial velocity v_0 along a horizontal
track.  A vertical stream of sand falls onto the cart at a constant mass-flow rate
ṁ (kg/s).  The sand has zero horizontal velocity, so as it lands and joins the cart
it must be accelerated to the cart's velocity, slowing the cart by horizontal
momentum conservation:

    p_0 = M·v_0 = (M + m(t))·v(t)
    →   v(t) = M·v_0 / (M + ṁ·t)

The position grows logarithmically:
    x(t) = (M·v_0 / ṁ)·ln((M + ṁ·t)/M) + x_0

This is the canonical "raindrops on a sled" / "sand on a cart" demonstration of
the Meshchersky variable-mass equation:

    F_ext = m(t)·dv/dt + (dm/dt)·(v - v_added)

With F_ext = 0 (frictionless track, vertical gravity only) and v_added = 0
(sand has no horizontal velocity), this reduces to:

    (M + ṁ·t)·dv/dt = -ṁ·v

Energy bookkeeping: total kinetic energy strictly decreases —
    ΔKE = ½(M + ṁ·t)·v² - ½M·v_0²  =  -½(M·v_0²)·(ṁ·t)/(M + ṁ·t).
The lost KE goes into the inelastic capture of each sand grain (heat).

State vector: [x, v, m_sand]
"""

from __future__ import annotations
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches
from dataclasses import dataclass, asdict
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from .draw_utils import setup_dark_axis


@dataclass
class SandOntoMovingCartParams:
    M:    float = 2.0      # initial cart mass (kg)
    v0:   float = 1.5      # initial cart velocity (m/s)
    mdot: float = 0.4      # sand mass-flow rate (kg/s)
    x0:   float = 0.0      # initial cart position (m)
    g:    float = 9.81     # gravity (visualization only — vertical sand fall)


def ode(t, y, p: SandOntoMovingCartParams):
    """Variable-mass Newton's 2nd Law:
         (M + m_sand)·dv/dt = -ṁ·v   (sand has v_added = 0).
       State: [x, v, m_sand]."""
    x, v, m_sand = y
    M_total = p.M + m_sand
    dx = v
    dv = -p.mdot * v / M_total
    dm = p.mdot
    return [dx, dv, dm]


def simulate(params: SandOntoMovingCartParams,
             duration: float = 4.5, fps: int = 30):
    t_eval = np.linspace(0, duration, int(duration * fps) + 1)
    sol = solve_ivp(
        ode, (0, duration), [params.x0, params.v0, 0.0],
        t_eval=t_eval, args=(params,),
        method="RK45", rtol=1e-9, atol=1e-11,
    )
    return sol.t, sol.y


def render_video(t, y, params: SandOntoMovingCartParams,
                 output_path: str, fps: int = 30):
    """Side-view rendering: cart moves right along a horizontal track; a hopper
    floats above the cart (translates with it); a vertical sand stream falls from
    the hopper to the growing pile on the cart's top."""
    x_arr = y[0]; m_arr = y[2]

    cart_length, cart_height = 1.0, 0.4
    wheel_r = 0.08
    hopper_y_top, hopper_y_bottom = 2.0, 1.7
    hopper_w_top, hopper_w_bottom = 0.5, 0.16

    x_min = min(min(x_arr) - 1.5, -1.0)
    x_max = max(max(x_arr) + 1.5, 4.0)

    fig, ax = plt.subplots(figsize=(11, 4))
    setup_dark_axis(fig, ax, (x_min, x_max), (-0.3, 2.3))
    ax.axhline(0, color="#4a4e69", lw=2, zorder=1)

    cart_rect = patches.FancyBboxPatch(
        (x_arr[0] - cart_length / 2, 0), cart_length, cart_height,
        boxstyle="round,pad=0.02", lw=1.5,
        edgecolor="white", facecolor="#457b9d", zorder=4,
    )
    ax.add_patch(cart_rect)
    wheel_l = patches.Circle((x_arr[0] - cart_length / 3, -wheel_r),
                              wheel_r, color="#a8dadc", zorder=5)
    wheel_r_ = patches.Circle((x_arr[0] + cart_length / 3, -wheel_r),
                                wheel_r, color="#a8dadc", zorder=5)
    ax.add_patch(wheel_l); ax.add_patch(wheel_r_)

    pile = patches.Polygon([(0, 0), (0, 0), (0, 0)],
                           facecolor="#f4a261", edgecolor="white", lw=1, zorder=4)
    ax.add_patch(pile)

    hopper = patches.Polygon([(0, 0), (0, 0), (0, 0), (0, 0)],
                              facecolor="#6c757d", edgecolor="white", lw=1, zorder=3)
    ax.add_patch(hopper)

    n_p = 18
    phases = np.linspace(0, 1, n_p, endpoint=False)
    jitter = np.random.RandomState(42).uniform(-0.04, 0.04, n_p)
    particles = []
    for _ in range(n_p):
        c = patches.Circle((0, 0), 0.018, color="#f4a261", zorder=6)
        ax.add_patch(c); particles.append(c)

    rho_visual = 2.0          # visual surface mass density (kg per metre of cart length)
    g = params.g

    def update(frame):
        x_c = x_arr[frame]; m_s = m_arr[frame]; t_now = t[frame]

        cart_rect.set_x(x_c - cart_length / 2)
        wheel_l.center  = (x_c - cart_length / 3, -wheel_r)
        wheel_r_.center = (x_c + cart_length / 3, -wheel_r)

        pile_h = min(m_s / (rho_visual * cart_length), 1.0)
        pile_top = cart_height + pile_h
        pile.set_xy([
            (x_c - cart_length / 2 + 0.05, cart_height),
            (x_c + cart_length / 2 - 0.05, cart_height),
            (x_c, pile_top),
        ])

        hopper.set_xy([
            (x_c - hopper_w_top / 2, hopper_y_top),
            (x_c + hopper_w_top / 2, hopper_y_top),
            (x_c + hopper_w_bottom / 2, hopper_y_bottom),
            (x_c - hopper_w_bottom / 2, hopper_y_bottom),
        ])

        fall_dist = max(hopper_y_bottom - pile_top, 0.05)
        fall_t    = np.sqrt(2 * fall_dist / g)
        for i, cp in enumerate(particles):
            phase = (t_now / fall_t + phases[i]) % 1.0
            y_p = hopper_y_bottom - 0.5 * g * (phase * fall_t) ** 2
            y_p = max(y_p, pile_top)
            cp.center = (x_c + jitter[i], y_p)

        return [cart_rect, wheel_l, wheel_r_, pile, hopper] + particles

    ani = animation.FuncAnimation(fig, update, frames=len(t),
                                  interval=1000 / fps, blit=False)
    ani.save(output_path,
             writer=animation.FFMpegWriter(fps=fps, bitrate=1800),
             dpi=120)
    plt.close(fig)


def make_standalone_script(params: SandOntoMovingCartParams,
                           duration: float = 4.5) -> str:
    p = asdict(params)
    return f'''"""
Sand Onto Moving Cart — auto-generated standalone simulation script.

Physics (variable-mass / Meshchersky equation):
    F_ext = m(t)·dv/dt + (dm/dt)·(v - v_added)

With F_ext = 0 (frictionless track) and v_added = 0 (sand has no horizontal
velocity), this reduces to:
    (M + ṁ·t)·dv/dt = -ṁ·v
    ⇒  v(t) = M·v_0 / (M + ṁ·t)
    ⇒  x(t) = (M·v_0/ṁ)·ln((M + ṁ·t)/M) + x_0

Equivalently: total horizontal momentum (M + m(t))·v(t) = M·v_0 is conserved.

Parameters: M={p["M"]:.4f} kg, v0={p["v0"]:.4f} m/s, ṁ={p["mdot"]:.4f} kg/s
"""
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as patches

M, v0, mdot, x0_init, g = {p["M"]}, {p["v0"]}, {p["mdot"]}, {p["x0"]}, {p["g"]}
duration = {duration}
fps = 30


def ode(t, y):
    x, v, m_s = y
    return [v, -mdot * v / (M + m_s), mdot]


t_eval = np.linspace(0, duration, int(duration * fps) + 1)
sol = solve_ivp(ode, (0, duration), [x0_init, v0, 0.0], t_eval=t_eval,
                method="RK45", rtol=1e-9, atol=1e-11)
x_arr, v_arr, m_arr = sol.y[0], sol.y[1], sol.y[2]


cart_length, cart_height = 1.0, 0.4
wheel_r = 0.08
hopper_y_top, hopper_y_bottom = 2.0, 1.7
htop, hbot = 0.5, 0.16

x_min = min(min(x_arr) - 1.5, -1.0)
x_max = max(max(x_arr) + 1.5, 4.0)

fig, ax = plt.subplots(figsize=(11, 4), facecolor="#1a1a2e")
ax.set_facecolor("#16213e")
ax.set_xlim(x_min, x_max); ax.set_ylim(-0.3, 2.3)
ax.set_aspect("equal"); ax.axis("off")
ax.axhline(0, color="#4a4e69", lw=2, zorder=1)

cart_rect = patches.FancyBboxPatch(
    (x_arr[0] - cart_length / 2, 0), cart_length, cart_height,
    boxstyle="round,pad=0.02", lw=1.5,
    edgecolor="white", facecolor="#457b9d", zorder=4)
ax.add_patch(cart_rect)
wheel_l  = patches.Circle((x_arr[0] - cart_length / 3, -wheel_r),
                           wheel_r, color="#a8dadc", zorder=5)
wheel_r_ = patches.Circle((x_arr[0] + cart_length / 3, -wheel_r),
                           wheel_r, color="#a8dadc", zorder=5)
ax.add_patch(wheel_l); ax.add_patch(wheel_r_)

pile = patches.Polygon([(0, 0), (0, 0), (0, 0)],
                       facecolor="#f4a261", edgecolor="white", lw=1, zorder=4)
ax.add_patch(pile)
hopper = patches.Polygon([(0, 0), (0, 0), (0, 0), (0, 0)],
                          facecolor="#6c757d", edgecolor="white", lw=1, zorder=3)
ax.add_patch(hopper)

n_p = 18
phases = np.linspace(0, 1, n_p, endpoint=False)
jitter = np.random.RandomState(42).uniform(-0.04, 0.04, n_p)
particles = []
for _ in range(n_p):
    c = patches.Circle((0, 0), 0.018, color="#f4a261", zorder=6)
    ax.add_patch(c); particles.append(c)

rho_v = 2.0


def update(frame):
    x_c = x_arr[frame]; m_s = m_arr[frame]; t_now = sol.t[frame]
    cart_rect.set_x(x_c - cart_length / 2)
    wheel_l.center  = (x_c - cart_length / 3, -wheel_r)
    wheel_r_.center = (x_c + cart_length / 3, -wheel_r)

    pile_h = min(m_s / (rho_v * cart_length), 1.0)
    pile_top = cart_height + pile_h
    pile.set_xy([
        (x_c - cart_length / 2 + 0.05, cart_height),
        (x_c + cart_length / 2 - 0.05, cart_height),
        (x_c, pile_top),
    ])
    hopper.set_xy([
        (x_c - htop / 2, hopper_y_top),
        (x_c + htop / 2, hopper_y_top),
        (x_c + hbot / 2, hopper_y_bottom),
        (x_c - hbot / 2, hopper_y_bottom),
    ])

    fall_dist = max(hopper_y_bottom - pile_top, 0.05)
    fall_t    = np.sqrt(2 * fall_dist / g)
    for i, cp in enumerate(particles):
        phase = (t_now / fall_t + phases[i]) % 1.0
        y_p = hopper_y_bottom - 0.5 * g * (phase * fall_t) ** 2
        y_p = max(y_p, pile_top)
        cp.center = (x_c + jitter[i], y_p)

    return [cart_rect, wheel_l, wheel_r_, pile, hopper] + particles


ani = animation.FuncAnimation(fig, update, frames=len(sol.t),
                              interval=1000 / fps, blit=False)
ani.save("video.mp4",
         writer=animation.FFMpegWriter(fps=fps, bitrate=1800),
         dpi=120)
plt.close()
print("Saved video.mp4")
'''


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Sand Onto Moving Cart")
    parser.add_argument("--M",        type=float, default=2.0)
    parser.add_argument("--v0",       type=float, default=1.5)
    parser.add_argument("--mdot",     type=float, default=0.4)
    parser.add_argument("--x0",       type=float, default=0.0)
    parser.add_argument("--duration", type=float, default=4.5)
    parser.add_argument("--output",   type=str,   default="sand_onto_cart.mp4")
    args = parser.parse_args()
    p = SandOntoMovingCartParams(M=args.M, v0=args.v0,
                                 mdot=args.mdot, x0=args.x0)
    print(f"Sand onto moving cart: {asdict(p)}")
    M, v0, mdot, x0 = p.M, p.v0, p.mdot, p.x0
    M_f = M + mdot * args.duration
    print(f"  τ = M/ṁ        = {M / mdot:.4f} s")
    print(f"  v_final         = {M * v0 / M_f:.4f} m/s   "
          f"({100 * (M * v0 / M_f) / v0:.1f}% of v0)")
    print(f"  m_sand_final    = {mdot * args.duration:.4f} kg")
    print(f"  x_final         = {(M * v0 / mdot) * np.log(M_f / M) + x0:.4f} m")
    print(f"  KE_initial      = {0.5 * M * v0 * v0:.4f} J")
    print(f"  KE_final        = {0.5 * M_f * (M * v0 / M_f) ** 2:.4f} J")
    t, y = simulate(p, duration=args.duration)
    render_video(t, y, p, args.output)
    print(f"Saved {args.output}")
