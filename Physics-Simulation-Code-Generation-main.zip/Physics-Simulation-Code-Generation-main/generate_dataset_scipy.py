"""
Scipy Physics Simulation Dataset Generator
======================================
Generates a dataset of (video.mp4, simulation_code.py, cot.json) tuples
for training multimodal LLMs to perform physics-grounded code generation.

Usage:
    python generate_dataset_scipy.py                    # all simulations, default scipy config
    python generate_dataset_scipy.py --sims simple_pendulum double_pendulum
    python generate_dataset_scipy.py --n 50 --out ./dataset_scipy
    python generate_dataset_scipy.py --seed 42

Output structure:
    dataset_scipy/
    ├── simple_pendulum/
    │   ├── 000/ {video.mp4, simulation_code.py, cot.json, params.json}
    │   ├── 001/ ...
    │   └── manifest.json
    ├── double_pendulum/
    │   └── ...
    └── global_manifest.json
"""

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np

# ── Import simulation modules ─────────────────────────────────────────────────
sys.path.insert(0, str(Path(__file__).parent))
from simulations.scipy.simple_pendulum import (
    SimplePendulumParams, simulate as sim_simple, render_video as render_simple,
    make_standalone_script as code_simple,
)
from simulations.scipy.double_pendulum import (
    DoublePendulumParams, simulate as sim_double, render_video as render_double,
    make_standalone_script as code_double,
)
from simulations.scipy.cart_pendulum import (
    CartPendulumParams, simulate as sim_cart, render_video as render_cart,
    make_standalone_script as code_cart,
)
from simulations.scipy.single_spring import (
    SingleSpringParams, simulate as sim_spring1, render_video as render_spring1,
    make_standalone_script as code_spring1,
)
from simulations.scipy.double_spring import (
    DoubleSpringParams, simulate as sim_spring2, render_video as render_spring2,
    make_standalone_script as code_spring2,
)
from simulations.scipy.moveable_pendulum import (
    MoveablePendulumParams, simulate as sim_moveable, render_video as render_moveable,
    make_standalone_script as code_moveable,
)
from simulations.scipy.rigid_double_pendulum import (
    RigidDoublePendulumParams, simulate as sim_rigid_dp, render_video as render_rigid_dp,
    make_standalone_script as code_rigid_dp,
)
from simulations.scipy.moveable_double_pendulum import (
    MoveableDoublePendulumParams, simulate as sim_moveable_dp, render_video as render_moveable_dp,
    make_standalone_script as code_moveable_dp,
)
from simulations.scipy.spring_2d import (
    Spring2DParams, simulate as sim_spring2d, render_video as render_spring2d,
    make_standalone_script as code_spring2d,
)
from simulations.scipy.double_2d_spring import (
    Double2DSpringParams, simulate as sim_double2d, render_video as render_double2d,
    make_standalone_script as code_double2d,
)
from simulations.scipy.dangle_stick import (
    DangleStickParams, simulate as sim_dangle, render_video as render_dangle,
    make_standalone_script as code_dangle,
)
from simulations.scipy.chain_of_springs import (
    ChainOfSpringsParams, simulate as sim_chain, render_video as render_chain,
    make_standalone_script as code_chain,
)
from simulations.scipy.molecule_2 import (
    Molecule2Params, simulate as sim_molecule, render_video as render_molecule,
    make_standalone_script as code_molecule,
)
from simulations.scipy.roller_single import (
    RollerSingleParams, simulate as sim_roller1, render_video as render_roller1,
    make_standalone_script as code_roller1,
)
from simulations.scipy.brachistochrone import (
    BrachistochroneParams, simulate as sim_brachio, render_video as render_brachio,
    make_standalone_script as code_brachio,
)
from simulations.scipy.lagrange_roller import (
    LagrangeRollerParams, simulate as sim_lagrange, render_video as render_lagrange,
    make_standalone_script as code_lagrange,
)
from simulations.scipy.magnet_wheel import (
    MagnetWheelParams, simulate as sim_magnet, render_video as render_magnet,
    make_standalone_script as code_magnet,
)
from simulations.scipy.robot_speed import (
    RobotSpeedParams, simulate as sim_robot, render_video as render_robot,
    make_standalone_script as code_robot,
)
from simulations.scipy.complex_collision_plane import (
    ComplexCollisionPlaneParams, simulate as sim_ccp, render_video as render_ccp,
    make_standalone_script as code_ccp,
)
from simulations.scipy.ballistic_pendulum import (
    BallisticPendulumParams, simulate as sim_ballistic, render_video as render_ballistic,
    make_standalone_script as code_ballistic,
)
from simulations.scipy.sand_onto_moving_cart import (
    SandOntoMovingCartParams, simulate as sim_sand, render_video as render_sand,
    make_standalone_script as code_sand,
)
from simulations.scipy.accelerating_cart_sliding_mass import (
    AcceleratingCartSlidingMassParams,
    simulate as sim_accm, render_video as render_accm,
    make_standalone_script as code_accm,
)
from simulations.scipy.watt_straight_line_linkage import (
    WattStraightLineLinkageParams,
    simulate as sim_watt, render_video as render_watt,
    make_standalone_script as code_watt,
)
from simulations.scipy.rolling_race_hoop_vs_disk_vs_sphere import (
    RollingRaceHoopVsDiskVsSphereParams,
    simulate as sim_race, render_video as render_race,
    make_standalone_script as code_race,
)
from simulations.scipy.spool_pull_direction_2d import (
    SpoolPullDirection2DParams,
    simulate as sim_spool, render_video as render_spool,
    make_standalone_script as code_spool,
)
from simulations.scipy.u_tube_fluid_oscillation import (
    UTubeFluidOscillationParams,
    simulate as sim_utube, render_video as render_utube,
    make_standalone_script as code_utube,
)
from simulations.scipy.differential_pulley_chain_fall import (
    DifferentialPulleyChainFallParams,
    simulate as sim_dpcf, render_video as render_dpcf,
    make_standalone_script as code_dpcf,
)
from simulations.scipy.spinning_ball_on_moving_belt import (
    SpinningBallOnMovingBeltParams,
    simulate as sim_sbb, render_video as render_sbb,
    make_standalone_script as code_sbb,
)
from cot_generator_scipy import generate_cot


# ── Registry: maps sim name → (ParamClass, simulate_fn, render_fn, code_fn) ──
from simulations.scipy.accelerating_beaker_water import (
    AcceleratingBeakerWaterParams,
    simulate as sim_accelerating_beaker_water, render_video as render_accelerating_beaker_water,
    make_standalone_script as code_accelerating_beaker_water,
)
from simulations.scipy.atwood_on_table import (
    AtwoodOnTableParams,
    simulate as sim_atwood_on_table, render_video as render_atwood_on_table,
    make_standalone_script as code_atwood_on_table,
)
from simulations.scipy.ball_wrapping_pole import (
    BallWrappingPoleParams,
    simulate as sim_ball_wrapping_pole, render_video as render_ball_wrapping_pole,
    make_standalone_script as code_ball_wrapping_pole,
)
from simulations.scipy.balls_in_basin import (
    BallsInBasinParams,
    simulate as sim_balls_in_basin, render_video as render_balls_in_basin,
    make_standalone_script as code_balls_in_basin,
)
from simulations.scipy.belt_gear_rack_train import (
    BeltGearRackTrainParams,
    simulate as sim_belt_gear_rack_train, render_video as render_belt_gear_rack_train,
    make_standalone_script as code_belt_gear_rack_train,
)
from simulations.scipy.billiards_break import (
    BilliardsBreakParams,
    simulate as sim_billiards_break, render_video as render_billiards_break,
    make_standalone_script as code_billiards_break,
)
from simulations.scipy.block_belt_spring_stickslip import (
    BlockBeltSpringStickslipParams,
    simulate as sim_block_belt_spring_stickslip, render_video as render_block_belt_spring_stickslip,
    make_standalone_script as code_block_belt_spring_stickslip,
)
from simulations.scipy.block_chain_collision import (
    BlockChainCollisionParams,
    simulate as sim_block_chain_collision, render_video as render_block_chain_collision,
    make_standalone_script as code_block_chain_collision,
)
from simulations.scipy.block_on_sphere_basin import (
    BlockOnSphereBasinParams,
    simulate as sim_block_on_sphere_basin, render_video as render_block_on_sphere_basin,
    make_standalone_script as code_block_on_sphere_basin,
)
from simulations.scipy.block_strikes_spring_pair import (
    BlockStrikesSpringPairParams,
    simulate as sim_block_strikes_spring_pair, render_video as render_block_strikes_spring_pair,
    make_standalone_script as code_block_strikes_spring_pair,
)
from simulations.scipy.bouncing_rod import (
    BouncingRodParams,
    simulate as sim_bouncing_rod, render_video as render_bouncing_rod,
    make_standalone_script as code_bouncing_rod,
)
from simulations.scipy.brachistochrone_race import (
    BrachistochroneRaceParams,
    simulate as sim_brachistochrone_race, render_video as render_brachistochrone_race,
    make_standalone_script as code_brachistochrone_race,
)
from simulations.scipy.cart_two_metronomes import (
    CartTwoMetronomesParams,
    simulate as sim_cart_two_metronomes, render_video as render_cart_two_metronomes,
    make_standalone_script as code_cart_two_metronomes,
)
from simulations.scipy.colliding_blocks import (
    CollidingBlocksParams,
    simulate as sim_colliding_blocks, render_video as render_colliding_blocks,
    make_standalone_script as code_colliding_blocks,
)
from simulations.scipy.compound_atwood import (
    CompoundAtwoodParams,
    simulate as sim_compound_atwood, render_video as render_compound_atwood,
    make_standalone_script as code_compound_atwood,
)
from simulations.scipy.conveyor_belt_drop import (
    ConveyorBeltDropParams,
    simulate as sim_conveyor_belt_drop, render_video as render_conveyor_belt_drop,
    make_standalone_script as code_conveyor_belt_drop,
)
from simulations.scipy.cylinder_piston_ball import (
    CylinderPistonBallParams,
    simulate as sim_cylinder_piston_ball, render_video as render_cylinder_piston_ball,
    make_standalone_script as code_cylinder_piston_ball,
)
from simulations.scipy.discs_friction_coupling import (
    DiscsFrictionCouplingParams,
    simulate as sim_discs_friction_coupling, render_video as render_discs_friction_coupling,
    make_standalone_script as code_discs_friction_coupling,
)
from simulations.scipy.disk_spinoff import (
    DiskSpinoffParams,
    simulate as sim_disk_spinoff, render_video as render_disk_spinoff,
    make_standalone_script as code_disk_spinoff,
)
from simulations.scipy.driven_string_fixed import (
    DrivenStringFixedParams,
    simulate as sim_driven_string_fixed, render_video as render_driven_string_fixed,
    make_standalone_script as code_driven_string_fixed,
)
from simulations.scipy.driven_string_ring import (
    DrivenStringRingParams,
    simulate as sim_driven_string_ring, render_video as render_driven_string_ring,
    make_standalone_script as code_driven_string_ring,
)
from simulations.scipy.falling_spring import (
    FallingSpringParams,
    simulate as sim_falling_spring, render_video as render_falling_spring,
    make_standalone_script as code_falling_spring,
)
from simulations.scipy.gear_rack_spring_oscillator import (
    GearRackSpringOscillatorParams,
    simulate as sim_gear_rack_spring_oscillator, render_video as render_gear_rack_spring_oscillator,
    make_standalone_script as code_gear_rack_spring_oscillator,
)
from simulations.scipy.half_cylinder_drop import (
    HalfCylinderDropParams,
    simulate as sim_half_cylinder_drop, render_video as render_half_cylinder_drop,
    make_standalone_script as code_half_cylinder_drop,
)
from simulations.scipy.hammer_projectile_bounce import (
    HammerProjectileBounceParams,
    simulate as sim_hammer_projectile_bounce, render_video as render_hammer_projectile_bounce,
    make_standalone_script as code_hammer_projectile_bounce,
)
from simulations.scipy.hemisphere_roll_off import (
    HemisphereRollOffParams,
    simulate as sim_hemisphere_roll_off, render_video as render_hemisphere_roll_off,
    make_standalone_script as code_hemisphere_roll_off,
)
from simulations.scipy.pendulum_block_strike import (
    PendulumBlockStrikeParams,
    simulate as sim_pendulum_block_strike, render_video as render_pendulum_block_strike,
    make_standalone_script as code_pendulum_block_strike,
)
from simulations.scipy.pendulum_slack_revolution import (
    PendulumSlackRevolutionParams,
    simulate as sim_pendulum_slack_revolution, render_video as render_pendulum_slack_revolution,
    make_standalone_script as code_pendulum_slack_revolution,
)
from simulations.scipy.projectile_bounce import (
    ProjectileBounceParams,
    simulate as sim_projectile_bounce, render_video as render_projectile_bounce,
    make_standalone_script as code_projectile_bounce,
)
from simulations.scipy.ring_pendulum import (
    RingPendulumParams,
    simulate as sim_ring_pendulum, render_video as render_ring_pendulum,
    make_standalone_script as code_ring_pendulum,
)
from simulations.scipy.ring_sticky_collision import (
    RingStickyCollisionParams,
    simulate as sim_ring_sticky_collision, render_video as render_ring_sticky_collision,
    make_standalone_script as code_ring_sticky_collision,
)
from simulations.scipy.rod_ball_strike import (
    RodBallStrikeParams,
    simulate as sim_rod_ball_strike, render_video as render_rod_ball_strike,
    make_standalone_script as code_rod_ball_strike,
)
from simulations.scipy.semicircular_track import (
    SemicircularTrackParams,
    simulate as sim_semicircular_track, render_video as render_semicircular_track,
    make_standalone_script as code_semicircular_track,
)
from simulations.scipy.slab_springs_block_drop import (
    SlabSpringsBlockDropParams,
    simulate as sim_slab_springs_block_drop, render_video as render_slab_springs_block_drop,
    make_standalone_script as code_slab_springs_block_drop,
)
from simulations.scipy.sliding_block_step_topple import (
    SlidingBlockStepToppleParams,
    simulate as sim_sliding_block_step_topple, render_video as render_sliding_block_step_topple,
    make_standalone_script as code_sliding_block_step_topple,
)
from simulations.scipy.spinning_ball_bounce import (
    SpinningBallBounceParams,
    simulate as sim_spinning_ball_bounce, render_video as render_spinning_ball_bounce,
    make_standalone_script as code_spinning_ball_bounce,
)
from simulations.scipy.spinning_disc_block_spring import (
    SpinningDiscBlockSpringParams,
    simulate as sim_spinning_disc_block_spring, render_video as render_spinning_disc_block_spring,
    make_standalone_script as code_spinning_disc_block_spring,
)
from simulations.scipy.spring_atwood import (
    SpringAtwoodParams,
    simulate as sim_spring_atwood, render_video as render_spring_atwood,
    make_standalone_script as code_spring_atwood,
)
from simulations.scipy.spring_mass_string_fixed import (
    SpringMassStringFixedParams,
    simulate as sim_spring_mass_string_fixed, render_video as render_spring_mass_string_fixed,
    make_standalone_script as code_spring_mass_string_fixed,
)
from simulations.scipy.spring_mass_string_ring import (
    SpringMassStringRingParams,
    simulate as sim_spring_mass_string_ring, render_video as render_spring_mass_string_ring,
    make_standalone_script as code_spring_mass_string_ring,
)
from simulations.scipy.springs_two_slabs_compound import (
    SpringsTwoSlabsCompoundParams,
    simulate as sim_springs_two_slabs_compound, render_video as render_springs_two_slabs_compound,
    make_standalone_script as code_springs_two_slabs_compound,
)
from simulations.scipy.stacked_balls_drop import (
    StackedBallsDropParams,
    simulate as sim_stacked_balls_drop, render_video as render_stacked_balls_drop,
    make_standalone_script as code_stacked_balls_drop,
)
from simulations.scipy.string_block_wave import (
    StringBlockWaveParams,
    simulate as sim_string_block_wave, render_video as render_string_block_wave,
    make_standalone_script as code_string_block_wave,
)
from simulations.scipy.string_ring_wave import (
    StringRingWaveParams,
    simulate as sim_string_ring_wave, render_video as render_string_ring_wave,
    make_standalone_script as code_string_ring_wave,
)
from simulations.scipy.three_body_gravity import (
    ThreeBodyGravityParams,
    simulate as sim_three_body_gravity, render_video as render_three_body_gravity,
    make_standalone_script as code_three_body_gravity,
)
from simulations.scipy.three_gear_chain import (
    ThreeGearChainParams,
    simulate as sim_three_gear_chain, render_video as render_three_gear_chain,
    make_standalone_script as code_three_gear_chain,
)
from simulations.scipy.three_gear_middle_drive import (
    ThreeGearMiddleDriveParams,
    simulate as sim_three_gear_middle_drive, render_video as render_three_gear_middle_drive,
    make_standalone_script as code_three_gear_middle_drive,
)
from simulations.scipy.tilting_wedge_cylinder import (
    TiltingWedgeCylinderParams,
    simulate as sim_tilting_wedge_cylinder, render_video as render_tilting_wedge_cylinder,
    make_standalone_script as code_tilting_wedge_cylinder,
)
from simulations.scipy.toppling_cylinder_wedge import (
    TopplingCylinderWedgeParams,
    simulate as sim_toppling_cylinder_wedge, render_video as render_toppling_cylinder_wedge,
    make_standalone_script as code_toppling_cylinder_wedge,
)
from simulations.scipy.two_body_gravity import (
    TwoBodyGravityParams,
    simulate as sim_two_body_gravity, render_video as render_two_body_gravity,
    make_standalone_script as code_two_body_gravity,
)
from simulations.scipy.two_carts_slack_string import (
    TwoCartsSlackStringParams,
    simulate as sim_two_carts_slack_string, render_video as render_two_carts_slack_string,
    make_standalone_script as code_two_carts_slack_string,
)
from simulations.scipy.two_conveyor_drop import (
    TwoConveyorDropParams,
    simulate as sim_two_conveyor_drop, render_video as render_two_conveyor_drop,
    make_standalone_script as code_two_conveyor_drop,
)
from simulations.scipy.two_gear_belt import (
    TwoGearBeltParams,
    simulate as sim_two_gear_belt, render_video as render_two_gear_belt,
    make_standalone_script as code_two_gear_belt,
)
from simulations.scipy.wave_interference import (
    WaveInterferenceParams,
    simulate as sim_wave_interference, render_video as render_wave_interference,
    make_standalone_script as code_wave_interference,
)
from simulations.scipy.wedge_block import (
    WedgeBlockParams,
    simulate as sim_wedge_block, render_video as render_wedge_block,
    make_standalone_script as code_wedge_block,
)
from simulations.scipy.wedge_sphere import (
    WedgeSphereParams,
    simulate as sim_wedge_sphere, render_video as render_wedge_sphere,
    make_standalone_script as code_wedge_sphere,
)
from simulations.scipy.wheel_belt_drop import (
    WheelBeltDropParams,
    simulate as sim_wheel_belt_drop, render_video as render_wheel_belt_drop,
    make_standalone_script as code_wheel_belt_drop,
)
from simulations.scipy.wheel_down_stairs import (
    WheelDownStairsParams,
    simulate as sim_wheel_down_stairs, render_video as render_wheel_down_stairs,
    make_standalone_script as code_wheel_down_stairs,
)
from simulations.scipy.wheel_wall_bounce import (
    WheelWallBounceParams,
    simulate as sim_wheel_wall_bounce, render_video as render_wheel_wall_bounce,
    make_standalone_script as code_wheel_wall_bounce,
)


REGISTRY: dict[str, tuple] = {
    # ── Pendulum ──────────────────────────────────────────────────────────────
    "simple_pendulum":          (SimplePendulumParams,         sim_simple,      render_simple,      code_simple),
    "double_pendulum":          (DoublePendulumParams,         sim_double,      render_double,      code_double),
    "cart_pendulum":            (CartPendulumParams,           sim_cart,        render_cart,        code_cart),
    "moveable_pendulum":        (MoveablePendulumParams,       sim_moveable,    render_moveable,    code_moveable),
    "rigid_double_pendulum":    (RigidDoublePendulumParams,    sim_rigid_dp,    render_rigid_dp,    code_rigid_dp),
    "moveable_double_pendulum": (MoveableDoublePendulumParams, sim_moveable_dp, render_moveable_dp, code_moveable_dp),
    # ── Springs ───────────────────────────────────────────────────────────────
    "single_spring":    (SingleSpringParams,    sim_spring1,  render_spring1,  code_spring1),
    "double_spring":    (DoubleSpringParams,    sim_spring2,  render_spring2,  code_spring2),
    "spring_2d":        (Spring2DParams,        sim_spring2d, render_spring2d, code_spring2d),
    "double_2d_spring": (Double2DSpringParams,  sim_double2d, render_double2d, code_double2d),
    "dangle_stick":     (DangleStickParams,     sim_dangle,   render_dangle,   code_dangle),
    "chain_of_springs": (ChainOfSpringsParams,  sim_chain,    render_chain,    code_chain),
    "molecule_2":       (Molecule2Params,       sim_molecule, render_molecule, code_molecule),
    # ── Roller ────────────────────────────────────────────────────────────────
    "roller_single":    (RollerSingleParams,    sim_roller1,  render_roller1,  code_roller1),
    "brachistochrone":  (BrachistochroneParams, sim_brachio,  render_brachio,  code_brachio),
    "lagrange_roller":  (LagrangeRollerParams,  sim_lagrange, render_lagrange, code_lagrange),
    # ── Misc ──────────────────────────────────────────────────────────────────
    "magnet_wheel": (MagnetWheelParams, sim_magnet, render_magnet, code_magnet),
    "robot_speed":  (RobotSpeedParams,  sim_robot,  render_robot,  code_robot),
    # ── Multi-body 1-D collisions ────────────────────────────────────────────
    "complex_collision_plane": (ComplexCollisionPlaneParams, sim_ccp, render_ccp, code_ccp),
    # ── Inelastic-collision + pendulum demo ──────────────────────────────────
    "ballistic_pendulum": (BallisticPendulumParams, sim_ballistic, render_ballistic, code_ballistic),
    # ── Variable-mass Newton II ──────────────────────────────────────────────
    "sand_onto_moving_cart": (SandOntoMovingCartParams, sim_sand, render_sand, code_sand),
    # ── Coulomb friction + CoM dynamics in a driven multi-body cart ──────────
    "accelerating_cart_sliding_mass": (AcceleratingCartSlidingMassParams, sim_accm, render_accm, code_accm),
    # ── Planar 4-bar mechanism with closed-form loop closure ─────────────────
    "watt_straight_line_linkage": (WattStraightLineLinkageParams, sim_watt, render_watt, code_watt),
    # ── Spool-pull-direction (planar rolling under torque sign) ──────────────
    "spool_pull_direction_2d": (SpoolPullDirection2DParams, sim_spool, render_spool, code_spool),
    # ── U-tube fluid oscillation on accelerating cart ────────────────────────
    "u_tube_fluid_oscillation": (UTubeFluidOscillationParams, sim_utube, render_utube, code_utube),
    # ── Rolling-race demo: hoop vs disk vs sphere on three identical ramps ──
    "rolling_race_hoop_vs_disk_vs_sphere": (RollingRaceHoopVsDiskVsSphereParams, sim_race, render_race, code_race),
    # ── Differential pulley (Weston block) — high mechanical advantage ───────
    "differential_pulley_chain_fall": (DifferentialPulleyChainFallParams, sim_dpcf, render_dpcf, code_dpcf),
    # ── Spinning ball on a moving belt — Coulomb friction slip-to-roll demo ──
    "spinning_ball_on_moving_belt": (SpinningBallOnMovingBeltParams, sim_sbb, render_sbb, code_sbb),    "accelerating_beaker_water": (AcceleratingBeakerWaterParams, sim_accelerating_beaker_water, render_accelerating_beaker_water, code_accelerating_beaker_water),
    "atwood_on_table": (AtwoodOnTableParams, sim_atwood_on_table, render_atwood_on_table, code_atwood_on_table),
    "ball_wrapping_pole": (BallWrappingPoleParams, sim_ball_wrapping_pole, render_ball_wrapping_pole, code_ball_wrapping_pole),
    "balls_in_basin": (BallsInBasinParams, sim_balls_in_basin, render_balls_in_basin, code_balls_in_basin),
    "belt_gear_rack_train": (BeltGearRackTrainParams, sim_belt_gear_rack_train, render_belt_gear_rack_train, code_belt_gear_rack_train),
    "billiards_break": (BilliardsBreakParams, sim_billiards_break, render_billiards_break, code_billiards_break),
    "block_belt_spring_stickslip": (BlockBeltSpringStickslipParams, sim_block_belt_spring_stickslip, render_block_belt_spring_stickslip, code_block_belt_spring_stickslip),
    "block_chain_collision": (BlockChainCollisionParams, sim_block_chain_collision, render_block_chain_collision, code_block_chain_collision),
    "block_on_sphere_basin": (BlockOnSphereBasinParams, sim_block_on_sphere_basin, render_block_on_sphere_basin, code_block_on_sphere_basin),
    "block_strikes_spring_pair": (BlockStrikesSpringPairParams, sim_block_strikes_spring_pair, render_block_strikes_spring_pair, code_block_strikes_spring_pair),
    "bouncing_rod": (BouncingRodParams, sim_bouncing_rod, render_bouncing_rod, code_bouncing_rod),
    "brachistochrone_race": (BrachistochroneRaceParams, sim_brachistochrone_race, render_brachistochrone_race, code_brachistochrone_race),
    "cart_two_metronomes": (CartTwoMetronomesParams, sim_cart_two_metronomes, render_cart_two_metronomes, code_cart_two_metronomes),
    "colliding_blocks": (CollidingBlocksParams, sim_colliding_blocks, render_colliding_blocks, code_colliding_blocks),
    "compound_atwood": (CompoundAtwoodParams, sim_compound_atwood, render_compound_atwood, code_compound_atwood),
    "conveyor_belt_drop": (ConveyorBeltDropParams, sim_conveyor_belt_drop, render_conveyor_belt_drop, code_conveyor_belt_drop),
    "cylinder_piston_ball": (CylinderPistonBallParams, sim_cylinder_piston_ball, render_cylinder_piston_ball, code_cylinder_piston_ball),
    "discs_friction_coupling": (DiscsFrictionCouplingParams, sim_discs_friction_coupling, render_discs_friction_coupling, code_discs_friction_coupling),
    "disk_spinoff": (DiskSpinoffParams, sim_disk_spinoff, render_disk_spinoff, code_disk_spinoff),
    "driven_string_fixed": (DrivenStringFixedParams, sim_driven_string_fixed, render_driven_string_fixed, code_driven_string_fixed),
    "driven_string_ring": (DrivenStringRingParams, sim_driven_string_ring, render_driven_string_ring, code_driven_string_ring),
    "falling_spring": (FallingSpringParams, sim_falling_spring, render_falling_spring, code_falling_spring),
    "gear_rack_spring_oscillator": (GearRackSpringOscillatorParams, sim_gear_rack_spring_oscillator, render_gear_rack_spring_oscillator, code_gear_rack_spring_oscillator),
    "half_cylinder_drop": (HalfCylinderDropParams, sim_half_cylinder_drop, render_half_cylinder_drop, code_half_cylinder_drop),
    "hammer_projectile_bounce": (HammerProjectileBounceParams, sim_hammer_projectile_bounce, render_hammer_projectile_bounce, code_hammer_projectile_bounce),
    "hemisphere_roll_off": (HemisphereRollOffParams, sim_hemisphere_roll_off, render_hemisphere_roll_off, code_hemisphere_roll_off),
    "pendulum_block_strike": (PendulumBlockStrikeParams, sim_pendulum_block_strike, render_pendulum_block_strike, code_pendulum_block_strike),
    "pendulum_slack_revolution": (PendulumSlackRevolutionParams, sim_pendulum_slack_revolution, render_pendulum_slack_revolution, code_pendulum_slack_revolution),
    "projectile_bounce": (ProjectileBounceParams, sim_projectile_bounce, render_projectile_bounce, code_projectile_bounce),
    "ring_pendulum": (RingPendulumParams, sim_ring_pendulum, render_ring_pendulum, code_ring_pendulum),
    "ring_sticky_collision": (RingStickyCollisionParams, sim_ring_sticky_collision, render_ring_sticky_collision, code_ring_sticky_collision),
    "rod_ball_strike": (RodBallStrikeParams, sim_rod_ball_strike, render_rod_ball_strike, code_rod_ball_strike),
    "semicircular_track": (SemicircularTrackParams, sim_semicircular_track, render_semicircular_track, code_semicircular_track),
    "slab_springs_block_drop": (SlabSpringsBlockDropParams, sim_slab_springs_block_drop, render_slab_springs_block_drop, code_slab_springs_block_drop),
    "sliding_block_step_topple": (SlidingBlockStepToppleParams, sim_sliding_block_step_topple, render_sliding_block_step_topple, code_sliding_block_step_topple),
    "spinning_ball_bounce": (SpinningBallBounceParams, sim_spinning_ball_bounce, render_spinning_ball_bounce, code_spinning_ball_bounce),
    "spinning_disc_block_spring": (SpinningDiscBlockSpringParams, sim_spinning_disc_block_spring, render_spinning_disc_block_spring, code_spinning_disc_block_spring),
    "spring_atwood": (SpringAtwoodParams, sim_spring_atwood, render_spring_atwood, code_spring_atwood),
    "spring_mass_string_fixed": (SpringMassStringFixedParams, sim_spring_mass_string_fixed, render_spring_mass_string_fixed, code_spring_mass_string_fixed),
    "spring_mass_string_ring": (SpringMassStringRingParams, sim_spring_mass_string_ring, render_spring_mass_string_ring, code_spring_mass_string_ring),
    "springs_two_slabs_compound": (SpringsTwoSlabsCompoundParams, sim_springs_two_slabs_compound, render_springs_two_slabs_compound, code_springs_two_slabs_compound),
    "stacked_balls_drop": (StackedBallsDropParams, sim_stacked_balls_drop, render_stacked_balls_drop, code_stacked_balls_drop),
    "string_block_wave": (StringBlockWaveParams, sim_string_block_wave, render_string_block_wave, code_string_block_wave),
    "string_ring_wave": (StringRingWaveParams, sim_string_ring_wave, render_string_ring_wave, code_string_ring_wave),
    "three_body_gravity": (ThreeBodyGravityParams, sim_three_body_gravity, render_three_body_gravity, code_three_body_gravity),
    "three_gear_chain": (ThreeGearChainParams, sim_three_gear_chain, render_three_gear_chain, code_three_gear_chain),
    "three_gear_middle_drive": (ThreeGearMiddleDriveParams, sim_three_gear_middle_drive, render_three_gear_middle_drive, code_three_gear_middle_drive),
    "tilting_wedge_cylinder": (TiltingWedgeCylinderParams, sim_tilting_wedge_cylinder, render_tilting_wedge_cylinder, code_tilting_wedge_cylinder),
    "toppling_cylinder_wedge": (TopplingCylinderWedgeParams, sim_toppling_cylinder_wedge, render_toppling_cylinder_wedge, code_toppling_cylinder_wedge),
    "two_body_gravity": (TwoBodyGravityParams, sim_two_body_gravity, render_two_body_gravity, code_two_body_gravity),
    "two_carts_slack_string": (TwoCartsSlackStringParams, sim_two_carts_slack_string, render_two_carts_slack_string, code_two_carts_slack_string),
    "two_conveyor_drop": (TwoConveyorDropParams, sim_two_conveyor_drop, render_two_conveyor_drop, code_two_conveyor_drop),
    "two_gear_belt": (TwoGearBeltParams, sim_two_gear_belt, render_two_gear_belt, code_two_gear_belt),
    "wave_interference": (WaveInterferenceParams, sim_wave_interference, render_wave_interference, code_wave_interference),
    "wedge_block": (WedgeBlockParams, sim_wedge_block, render_wedge_block, code_wedge_block),
    "wedge_sphere": (WedgeSphereParams, sim_wedge_sphere, render_wedge_sphere, code_wedge_sphere),
    "wheel_belt_drop": (WheelBeltDropParams, sim_wheel_belt_drop, render_wheel_belt_drop, code_wheel_belt_drop),
    "wheel_down_stairs": (WheelDownStairsParams, sim_wheel_down_stairs, render_wheel_down_stairs, code_wheel_down_stairs),
    "wheel_wall_bounce": (WheelWallBounceParams, sim_wheel_wall_bounce, render_wheel_wall_bounce, code_wheel_wall_bounce),

}


# ─────────────────────────────────────────────────────────────────────────────
# Parameter sampling
# ─────────────────────────────────────────────────────────────────────────────

def sample_params(cfg: dict, rng: np.random.Generator) -> dict[str, Any]:
    """Sample one parameter set from a simulation's config entry."""
    sampled: dict[str, Any] = {}
    for key, spec in cfg.items():
        if key.startswith("_") or key == "n_samples":
            continue
        if "fixed" in spec:
            sampled[key] = spec["fixed"]
        elif spec.get("type") == "uniform":
            sampled[key] = float(rng.uniform(spec["min"], spec["max"]))
        else:
            sampled[key] = spec.get("default", 0.0)
    return sampled


def dict_to_params(sim_name: str, d: dict[str, Any]):
    """Convert a raw dict to the appropriate dataclass."""
    ParamClass = REGISTRY[sim_name][0]
    # Filter only the fields the dataclass accepts
    import dataclasses
    fields = {f.name for f in dataclasses.fields(ParamClass)}
    return ParamClass(**{k: v for k, v in d.items() if k in fields})


def run_simulation_code(sample_dir: Path) -> None:
    """Execute simulation_code.py and normalize its MP4 output to video.mp4."""
    video_path = sample_dir / "video.mp4"
    if video_path.exists():
        video_path.unlink()

    subprocess.run([sys.executable, "simulation_code.py"], cwd=sample_dir, check=True)

    if video_path.exists():
        return

    candidates = sorted(
        sample_dir.glob("*.mp4"),
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )
    if not candidates:
        raise FileNotFoundError(f"No MP4 produced by {sample_dir / 'simulation_code.py'}")

    candidates[0].rename(video_path)
    for extra in sample_dir.glob("*.mp4"):
        if extra.name != "video.mp4":
            extra.unlink()


# ─────────────────────────────────────────────────────────────────────────────
# Per-sample generation
# ─────────────────────────────────────────────────────────────────────────────

def generate_sample(
    sim_name: str,
    params_dict: dict[str, Any],
    sample_dir: Path,
    duration: float,
    fps: int,
) -> dict:
    """
    Generate one (video, code, cot) tuple.
    Returns a manifest entry dict.
    """
    import dataclasses
    sample_dir.mkdir(parents=True, exist_ok=True)
    _, _simulate_fn, _render_fn, code_fn = REGISTRY[sim_name]

    params = dict_to_params(sim_name, params_dict)
    # Use the dataclass's full state (including any auto-populated fields from
    # __post_init__) so cot.json and params.json reflect exactly what was simulated.
    full_params_dict = dataclasses.asdict(params)

    # 1. Write simulation_code.py
    code_str = code_fn(params, duration=duration)
    code_path = sample_dir / "simulation_code.py"
    code_path.write_text(code_str, encoding="utf-8")

    # 2. Write cot.json
    cot = generate_cot(sim_name, full_params_dict)
    cot_path = sample_dir / "cot.json"
    with open(cot_path, "w", encoding="utf-8") as f:
        json.dump(cot, f, indent=2, ensure_ascii=False)

    # 3. Write params.json
    params_path = sample_dir / "params.json"
    with open(params_path, "w", encoding="utf-8") as f:
        json.dump(full_params_dict, f, indent=2)

    # 4. Render video by executing the standalone code (writes video.mp4)
    run_simulation_code(sample_dir)

    return {
        "sample_dir": str(sample_dir),
        "simulation": sim_name,
        "params": full_params_dict,
        "files": {
            "video":  "video.mp4",
            "code":   "simulation_code.py",
            "cot":    "cot.json",
            "params": "params.json",
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# Main pipeline
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Scipy Physics Simulation Dataset Generator")
    parser.add_argument("--config", type=str, default="configs/parameter_ranges_scipy.json",
                        help="Path to parameter ranges config file")
    parser.add_argument("--sims", nargs="+", default=list(REGISTRY.keys()),
                        help="Which simulations to generate (default: all)")
    parser.add_argument("--n", type=int, default=None,
                        help="Number of samples per simulation (overrides config)")
    parser.add_argument("--out", type=str, default="dataset_scipy",
                        help="Output directory")
    parser.add_argument("--seed", type=int, default=42,
                        help="Random seed for reproducibility")
    parser.add_argument("--skip", type=int, default=0,
                        help="Skip first N samples (to continue from an existing run)")
    parser.add_argument("--duration", type=float, default=None,
                        help="Simulation duration in seconds (overrides config)")
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--dry-run", action="store_true",
                        help="Print planned samples without generating")
    args = parser.parse_args()

    # Load config
    config_path = Path(__file__).parent / args.config
    with open(config_path, "r") as f:
        cfg = json.load(f)

    n_samples = args.n or cfg.get("n_samples", 75)
    duration  = args.duration or cfg.get("duration_seconds", 12)
    fps       = args.fps

    out_dir = Path(args.out)
    skip    = args.skip

    global_manifest = []

    for sim_name in args.sims:
        if sim_name not in REGISTRY:
            print(f"[WARN] Unknown simulation {sim_name!r}, skipping.")
            continue
        if sim_name not in cfg:
            print(f"[WARN] No config entry for {sim_name!r}, skipping.")
            continue

        sim_cfg = cfg[sim_name]
        sim_n   = n_samples if args.n is not None else sim_cfg.get("n_samples", n_samples)
        sim_dir = out_dir / sim_name

        # Per-simulation RNG: deterministic regardless of which --sims are selected
        sim_seed = args.seed ^ (hash(sim_name) & 0xFFFF_FFFF)
        rng = np.random.default_rng(sim_seed)
        # Fast-forward past already-generated samples
        for _ in range(skip):
            sample_params(sim_cfg, rng)

        print(f"\n{'='*60}")
        print(f"  Simulation: {sim_name}  ({sim_n} samples, idx {skip}–{skip+sim_n-1})")
        print(f"  Output:     {sim_dir}")
        print(f"{'='*60}")

        if args.dry_run:
            for i in range(skip, skip + sim_n):
                p = sample_params(sim_cfg, rng)
                print(f"  [{i:03d}] {p}")
            continue

        sim_manifest = []
        start_time = time.time()

        for i in range(skip, skip + sim_n):
            params_dict = sample_params(sim_cfg, rng)
            sample_dir  = sim_dir / f"{i:03d}"

            print(f"  [{i+1:3d}/{skip+sim_n}] {sample_dir.name}", end="  ", flush=True)
            t0 = time.time()

            try:
                entry = generate_sample(sim_name, params_dict, sample_dir, duration, fps)
                sim_manifest.append(entry)
                global_manifest.append(entry)
                elapsed = time.time() - t0
                print(f"OK  ({elapsed:.1f}s)")
            except Exception as e:
                print(f"FAILED: {e}")
                import traceback
                traceback.print_exc()

        # Per-simulation manifest
        manifest_path = sim_dir / "manifest.json"
        with open(manifest_path, "w") as f:
            json.dump(sim_manifest, f, indent=2)

        total = time.time() - start_time
        print(f"  Done: {len(sim_manifest)}/{sim_n} samples in {total:.1f}s")

    # Global manifest
    if not args.dry_run:
        global_path = out_dir / "global_manifest.json"
        with open(global_path, "w") as f:
            json.dump(global_manifest, f, indent=2)
        print(f"\n✓ Dataset complete: {len(global_manifest)} total samples → {out_dir}/")
        print(f"  Global manifest: {global_path}")


if __name__ == "__main__":
    main()
