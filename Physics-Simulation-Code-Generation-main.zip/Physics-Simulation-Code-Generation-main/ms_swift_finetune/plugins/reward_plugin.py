# reward_plugin.py — physics-CoT-and-code rewards for ms-swift GRPO/DAPO/GSPO.
#
# Reward functions registered:
#   format        : 0/1 for the <cot>...</cot><code>...</code> structure
#   cot_json      : 0/1 for parsable JSON inside <cot>
#   cot_keys      : fraction of ground-truth top-level CoT keys present
#   cot_rouge     : ROUGE-{1,2,L} F1 between generated CoT body and gt_cot
#   code_rouge    : ROUGE-{1,2,L} F1 between generated <code> body and `solution`
#
# All rewards are continuous in [0, 1] except format/cot_json which are {0, 1}.
# Pair them with a positive weight in --reward_weights on the CLI.
import json
import re
from collections import Counter
from typing import List

from swift.rewards import ORM, orms
from swift.utils import get_logger

logger = get_logger()


# ----------------------- regex extractors -----------------------

_COT_RE = re.compile(r"<cot>\s*(.*?)\s*</cot>", flags=re.DOTALL | re.IGNORECASE)
_CODE_RE = re.compile(r"<code>\s*(.*?)\s*</code>", flags=re.DOTALL | re.IGNORECASE)
# Strip an optional ```python ... ``` fence inside <code>...</code>, since
# the Qwen3-VL chat template often wraps code blocks even when not asked.
_FENCE_RE = re.compile(r"^\s*```(?:python|py)?\s*\n?(.*?)\n?```\s*$", flags=re.DOTALL)
_WORD_RE = re.compile(r"\w+", flags=re.UNICODE)
_PY_TOK_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*|[0-9]+\.?[0-9]*|[^\sA-Za-z0-9_]", flags=re.UNICODE)


def extract_cot(text: str) -> str:
    m = _COT_RE.search(text or "")
    return m.group(1).strip() if m else ""


def extract_code(text: str) -> str:
    m = _CODE_RE.search(text or "")
    if not m:
        return ""
    body = m.group(1).strip()
    fence = _FENCE_RE.match(body)
    return fence.group(1).strip() if fence else body


def _align(x, n, fill=""):
    if not isinstance(x, list):
        x = [x] * n
    if len(x) < n:
        x = x + [fill] * (n - len(x))
    return x


# ----------------------- token-level scoring helpers -----------------------

def tokenize_words(s: str) -> List[str]:
    return _WORD_RE.findall(s.lower())


def tokenize_code(s: str) -> List[str]:
    # Code-aware tokenizer: identifier/number/operator splits beat whitespace.
    return _PY_TOK_RE.findall(s)


def lcs_length(a: List[str], b: List[str]) -> int:
    n, m = len(a), len(b)
    if n == 0 or m == 0:
        return 0
    prev = [0] * (m + 1)
    for i in range(1, n + 1):
        curr = [0] * (m + 1)
        ai = a[i - 1]
        for j in range(1, m + 1):
            if ai == b[j - 1]:
                curr[j] = prev[j - 1] + 1
            else:
                curr[j] = prev[j] if prev[j] >= curr[j - 1] else curr[j - 1]
        prev = curr
    return prev[m]


def _ngrams(tokens: List[str], n: int) -> Counter:
    return Counter(tuple(tokens[i:i + n]) for i in range(max(0, len(tokens) - n + 1)))


def rouge_n_f(ref: List[str], hyp: List[str], n: int) -> float:
    if len(ref) < n or len(hyp) < n:
        return 0.0
    rg, hg = _ngrams(ref, n), _ngrams(hyp, n)
    overlap = sum((rg & hg).values())
    if overlap == 0:
        return 0.0
    p = overlap / max(sum(hg.values()), 1)
    r = overlap / max(sum(rg.values()), 1)
    return 0.0 if (p + r) == 0 else 2 * p * r / (p + r)


def rouge_l_f(ref: List[str], hyp: List[str]) -> float:
    if not ref or not hyp:
        return 0.0
    lcs = lcs_length(ref, hyp)
    if lcs == 0:
        return 0.0
    p = lcs / len(hyp)
    r = lcs / len(ref)
    return 2 * p * r / (p + r)


def mean_rouge(ref_str: str, hyp_str: str, *, code: bool = False) -> float:
    tok = tokenize_code if code else tokenize_words
    ref = tok(ref_str or "")
    hyp = tok(hyp_str or "")
    if not ref or not hyp:
        return 0.0
    return (rouge_n_f(ref, hyp, 1) + rouge_n_f(ref, hyp, 2) + rouge_l_f(ref, hyp)) / 3.0


# ----------------------- reward functions -----------------------

class FormatReward(ORM):
    """1.0 if completion has exactly one non-empty <cot>...</cot> followed by
    one non-empty <code>...</code>, in that order; else 0.0."""

    def __call__(self, completions: List[str], **kwargs) -> List[float]:
        out = []
        for c in completions or []:
            c = (c or "").strip()
            cots = _COT_RE.findall(c)
            codes = _CODE_RE.findall(c)
            cot_ok = len(cots) == 1 and bool(cots[0].strip())
            code_ok = len(codes) == 1 and bool(codes[0].strip())
            if cot_ok and code_ok:
                cm = _COT_RE.search(c)
                em = _CODE_RE.search(c)
                if cm.start() < em.start():
                    out.append(1.0)
                    continue
            out.append(0.0)
        return out


orms["format"] = FormatReward


class CotJsonReward(ORM):
    """1.0 if the body of <cot>...</cot> parses as JSON (object); else 0.0."""

    def __call__(self, completions: List[str], **kwargs) -> List[float]:
        out = []
        for c in completions or []:
            body = extract_cot(c)
            if not body:
                out.append(0.0)
                continue
            try:
                obj = json.loads(body)
                out.append(1.0 if isinstance(obj, dict) else 0.0)
            except Exception:
                out.append(0.0)
        return out


orms["cot_json"] = CotJsonReward


class CotKeysReward(ORM):
    """Fraction of ground-truth top-level CoT keys that appear as keys in the
    generated CoT JSON. Continuous in [0, 1].

    If the generated CoT does not parse, falls back to a substring search
    over the raw <cot> body so partial credit still flows.
    """

    def __call__(self, completions: List[str], gt_cot=None, **kwargs) -> List[float]:
        if not completions:
            return []
        if gt_cot is None:
            return [0.0] * len(completions)
        gt_cot = _align(gt_cot, len(completions))

        out = []
        for c, gt in zip(completions, gt_cot):
            try:
                gt_keys = list(json.loads(gt or "{}").keys())
            except Exception:
                gt_keys = []
            if not gt_keys:
                out.append(0.0)
                continue
            body = extract_cot(c)
            gen_keys = []
            try:
                obj = json.loads(body or "{}")
                if isinstance(obj, dict):
                    gen_keys = list(obj.keys())
            except Exception:
                pass
            if gen_keys:
                gen_set = set(gen_keys)
                hits = sum(1 for k in gt_keys if k in gen_set)
            else:
                # Fallback: count "<key>": occurrences in the raw body.
                hits = 0
                for k in gt_keys:
                    if re.search(rf'"{re.escape(k)}"\s*:', body):
                        hits += 1
            out.append(hits / len(gt_keys))
        return out


orms["cot_keys"] = CotKeysReward


class CotRougeReward(ORM):
    """Mean of ROUGE-1/2/L F1 between the body of <cot>...</cot> and `gt_cot`.
    Continuous in [0, 1]."""

    def __call__(self, completions: List[str], gt_cot=None, **kwargs) -> List[float]:
        if not completions:
            return []
        if gt_cot is None:
            return [0.0] * len(completions)
        gt_cot = _align(gt_cot, len(completions))
        return [mean_rouge(gt or "", extract_cot(c)) for c, gt in zip(completions, gt_cot)]


orms["cot_rouge"] = CotRougeReward


class CodeRougeReward(ORM):
    """Mean of ROUGE-1/2/L F1 between the body of <code>...</code> and the
    ground-truth python code in `solution`. Tokenized at the python-token
    granularity so identifiers, numbers, and operators each count.
    Continuous in [0, 1]."""

    def __call__(self, completions: List[str], solution=None, **kwargs) -> List[float]:
        if not completions:
            return []
        if solution is None:
            return [0.0] * len(completions)
        solution = _align(solution, len(completions))
        return [mean_rouge(sol or "", extract_code(c), code=True)
                for c, sol in zip(completions, solution)]


orms["code_rouge"] = CodeRougeReward
