# randlora_tuner.py — registers a `randlora` tuner_type in ms-swift.
#
# RandLoRA (Albert et al., 2025) is shipped with PEFT >= 0.18 as
# RandLoraConfig / RandLoraModel. ms-swift's built-in tuner_type list does
# not include it, so we register a custom Tuner via the tuner_plugin
# `tuners_map`. ms-swift loads this file when passed via
# `--external_plugins /path/to/randlora_tuner.py`.
#
# Usage on the CLI:
#   --tuner_type randlora \
#   --external_plugins .../randlora_tuner.py \
#   --lora_rank 32 --lora_alpha 64 --target_modules all-linear
#
# Tunable hyperparameters (read from env so we don't have to fork ms-swift's
# argument dataclass):
#   RANDLORA_PROJECTION_PRNG_KEY   default 0     — PRNG seed for the random basis
#   RANDLORA_RANDLORA_DROPOUT      default 0.0   — dropout on the adapter path
#   RANDLORA_SPARSE                default false — use sparse random basis
#   RANDLORA_VERY_SPARSE           default false — use very-sparse random basis
#   RANDLORA_SAVE_PROJECTION       default false — persist random basis in ckpt
#
# `save_projection=False` is critical: with PEFT's default True, PyTorch's
# state_dict serializes the (shared) basis once per adapted linear,
# ballooning the checkpoint to tens of GB (e.g. ~44 GB for Qwen3-VL-4B).
# With False, only the trainable lambda/gamma matrices are saved (~tens of
# MB) and the basis is regenerated deterministically from
# `projection_prng_key` on load.
import os
from typing import TYPE_CHECKING

import torch
from peft import PeftModel, RandLoraConfig, get_peft_model

from swift.tuner_plugin.base import PeftTuner
from swift.tuner_plugin.mapping import tuners_map
from swift.utils import get_logger, get_multimodal_target_regex

if TYPE_CHECKING:
    from swift.arguments import SftArguments

logger = get_logger()


def _envbool(name: str, default: bool = False) -> bool:
    return os.getenv(name, str(default)).lower() in ("1", "true", "yes")


def _envint(name: str, default: int) -> int:
    return int(os.getenv(name, str(default)))


def _envfloat(name: str, default: float) -> float:
    return float(os.getenv(name, str(default)))


def _resolve_target(args: "SftArguments", model: torch.nn.Module):
    """Mirror ms-swift's LoRA target resolution so vit/aligner stay frozen
    when the user passes `--freeze_vit true --freeze_aligner true`."""
    if args.target_modules and args.target_modules != ["all-linear"]:
        return args.target_modules
    if model.model_meta.is_multimodal:
        return get_multimodal_target_regex(
            model,
            freeze_llm=getattr(args, "freeze_llm", False),
            freeze_vit=getattr(args, "freeze_vit", True),
            freeze_aligner=getattr(args, "freeze_aligner", True),
        )
    return "all-linear"


class RandLoraTuner(PeftTuner):
    """ms-swift Tuner shim around peft.RandLoraConfig."""

    @staticmethod
    def prepare_model(args: "SftArguments", model: torch.nn.Module) -> torch.nn.Module:
        target = _resolve_target(args, model)
        config = RandLoraConfig(
            task_type="CAUSAL_LM",
            r=args.lora_rank,
            randlora_alpha=args.lora_alpha,
            randlora_dropout=_envfloat("RANDLORA_RANDLORA_DROPOUT", args.lora_dropout),
            target_modules=target,
            projection_prng_key=_envint("RANDLORA_PROJECTION_PRNG_KEY", 0),
            save_projection=_envbool("RANDLORA_SAVE_PROJECTION", False),
            sparse=_envbool("RANDLORA_SPARSE", False),
            very_sparse=_envbool("RANDLORA_VERY_SPARSE", False),
        )
        logger.info(f"randlora_config: {config}")
        model = get_peft_model(model, config)
        # Freeze vit/aligner explicitly — get_peft_model only freezes the
        # base linear weights it is wrapping; non-targeted multimodal
        # modules retain their original requires_grad.
        for n, p in model.named_parameters():
            if "randlora" in n.lower() or "lora_" in n.lower():
                p.requires_grad = True
        return model

    @staticmethod
    def from_pretrained(model: torch.nn.Module, model_id: str, **kwargs) -> torch.nn.Module:
        return PeftModel.from_pretrained(model, model_id, **kwargs)


tuners_map["randlora"] = RandLoraTuner
logger.info("Registered tuner_type 'randlora' (PEFT RandLoraConfig).")
