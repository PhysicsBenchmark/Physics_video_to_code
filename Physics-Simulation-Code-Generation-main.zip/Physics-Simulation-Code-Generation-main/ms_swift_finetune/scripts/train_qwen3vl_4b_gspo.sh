#!/usr/bin/env bash
# GSPO — Qwen3-VL-4B-Instruct on physics-sim CoT+code dataset.
#
# GSPO (https://arxiv.org/abs/2507.18071) is GRPO with sequence-level
# importance sampling and tight clipping. Reference hyperparameters from
# the paper: epsilon=3e-4, epsilon_high=4e-4, steps_per_generation=4,
# beta=0 (no KL regularization).
source "$(dirname "${BASH_SOURCE[0]}")/_common.sh"

OUT_DIR="${OUT_DIR:-${OUT_ROOT}/qwen3vl_4b_gspo}"
RUN_NAME="${RUN_NAME:-qwen3vl_4b_gspo}"
export WANDB_NAME="${WANDB_NAME:-${RUN_NAME}}"

NPROC_PER_NODE=${NPROC_PER_NODE} \
swift rlhf \
  --rlhf_type grpo \
  --model "${MODEL_PATH}" \
  --model_type "${MODEL_TYPE}" \
  --template "${TEMPLATE}" \
  --dataset "${GRPO_TRAIN}" \
  --val_dataset "${GRPO_VAL}" \
  --split_dataset_ratio 0 \
  --tuner_type lora \
  --tuner_backend peft \
  --lora_rank 16 \
  --lora_alpha 32 \
  --lora_dropout 0.05 \
  --target_modules all-linear \
  --freeze_vit true \
  --freeze_aligner true \
  --torch_dtype bfloat16 \
  --attn_impl flash_attention_2 \
  --max_length 30000 \
  --truncation_strategy left \
  --lazy_tokenize true \
  --dataset_num_proc 1 \
  --dataloader_num_workers 4 \
  --gradient_checkpointing true \
  --vit_gradient_checkpointing true \
  --num_train_epochs 2 \
  --per_device_train_batch_size 1 \
  --per_device_eval_batch_size 8 \
  --gradient_accumulation_steps 8 \
  --learning_rate 1e-6 \
  --lr_scheduler_type cosine \
  --warmup_ratio 0.05 \
  --weight_decay 0.01 \
  --adam_beta1 0.9 \
  --adam_beta2 0.95 \
  --max_grad_norm 0.5 \
  --optim adamw_torch_fused \
  --bf16 true \
  --use_vllm true \
  --vllm_mode colocate \
  --vllm_gpu_memory_utilization 0.55 \
  --vllm_tensor_parallel_size 1 \
  --vllm_max_lora_rank 16 \
  --vllm_enable_prefix_caching true \
  --num_generations 8 \
  --num_generations_eval 8 \
  --steps_per_generation 8 \
  --max_completion_length 4096 \
  --temperature 0.9 \
  --top_p 0.95 \
  --top_k 40 \
  --beta 0.0 \
  --epsilon 3e-4 \
  --epsilon_high 4e-4 \
  --advantage_estimator grpo \
  --scale_rewards group \
  --importance_sampling_level sequence \
  --external_plugins "${REWARD_PLUGIN}" \
  --reward_funcs format cot_keys cot_rouge code_rouge soft_overlong \
  --reward_weights 0.10 0.25 0.30 0.40 0.10 \
  --soft_max_length 4096 \
  --soft_cache_length 512 \
  --log_completions true \
  --wandb_log_unique_prompts true \
  --eval_strategy steps \
  --eval_steps 100 \
  --resume_from_checkpoint last \
  --save_strategy steps \
  --save_steps 50 \
  --save_total_limit 2 \
  --logging_steps 5 \
  --report_to wandb \
  --output_dir "${OUT_DIR}" \
  "$@"
