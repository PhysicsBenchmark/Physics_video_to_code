#!/usr/bin/env bash
# RandLoRA SFT — Qwen3-VL-4B-Instruct on physics-sim CoT+code dataset.
#
# RandLoRA is provided by PEFT >= 0.18 (RandLoraConfig/RandLoraModel) and
# registered into ms-swift's tuner_type registry by
# plugins/randlora_tuner.py. lora_rank/lora_alpha map to RandLoRA's r and
# randlora_alpha. With RandLoRA, smaller r => more trainable parameters
# (inverse relationship vs LoRA), so r=32 is a sensible default.
source "$(dirname "${BASH_SOURCE[0]}")/_common.sh"

OUT_DIR="${OUT_DIR:-${OUT_ROOT}/qwen3vl_4b_randlora_sft}"
RUN_NAME="${RUN_NAME:-qwen3vl_4b_randlora_sft}"

export WANDB_NAME="${WANDB_NAME:-${RUN_NAME}}"
# RandLoRA hyperparameters (consumed inside randlora_tuner.py via env).
export RANDLORA_PROJECTION_PRNG_KEY="${RANDLORA_PROJECTION_PRNG_KEY:-0}"
export RANDLORA_RANDLORA_DROPOUT="${RANDLORA_RANDLORA_DROPOUT:-0.05}"
export RANDLORA_SPARSE="${RANDLORA_SPARSE:-false}"
export RANDLORA_VERY_SPARSE="${RANDLORA_VERY_SPARSE:-false}"

NPROC_PER_NODE=${NPROC_PER_NODE} \
swift sft \
  --model "${MODEL_PATH}" \
  --model_type "${MODEL_TYPE}" \
  --template "${TEMPLATE}" \
  --dataset "${SFT_TRAIN}" \
  --val_dataset "${SFT_VAL}" \
  --split_dataset_ratio 0 \
  --tuner_type randlora \
  --external_plugins "${RANDLORA_PLUGIN}" \
  --torch_dtype bfloat16 \
  --attn_impl flash_attention_2 \
  --num_train_epochs 2 \
  --per_device_train_batch_size 1 \
  --per_device_eval_batch_size 1 \
  --gradient_accumulation_steps 16 \
  --learning_rate 5e-5 \
  --lr_scheduler_type cosine \
  --warmup_ratio 0.05 \
  --weight_decay 0.1 \
  --adam_beta1 0.9 \
  --adam_beta2 0.95 \
  --optim adamw_torch_fused \
  --lora_rank 32 \
  --lora_alpha 640 \
  --lora_dropout 0.05 \
  --target_modules all-linear \
  --freeze_vit true \
  --freeze_aligner true \
  --max_length 30000 \
  --truncation_strategy delete \
  --lazy_tokenize true \
  --dataset_num_proc 2 \
  --dataloader_num_workers 4 \
  --gradient_checkpointing true \
  --vit_gradient_checkpointing true \
  --eval_strategy steps \
  --eval_steps 100 \
  --resume_from_checkpoint last \
  --save_strategy steps \
  --save_steps 50 \
  --save_total_limit 2 \
  --logging_steps 5 \
  --bf16 true \
  --report_to wandb \
  --output_dir "${OUT_DIR}" \
  "$@"
