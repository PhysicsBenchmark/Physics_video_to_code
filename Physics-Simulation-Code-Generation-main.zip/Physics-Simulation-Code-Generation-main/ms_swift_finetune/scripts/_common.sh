# Sourced by every training script. Centralizes paths and shared defaults
# so individual scripts only need to set algorithm-specific knobs.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

export MODEL_PATH="${MODEL_PATH:-/scr/sourajak/Qwen/Qwen3-VL-4B-Instruct}"
export MODEL_TYPE="${MODEL_TYPE:-qwen3_vl}"
export TEMPLATE="${TEMPLATE:-qwen3_vl}"

export DATA_DIR="${DATA_DIR:-${ROOT}/data}"
export SFT_TRAIN="${SFT_TRAIN:-${DATA_DIR}/physics_sft_train.jsonl}"
export SFT_VAL="${SFT_VAL:-${DATA_DIR}/physics_sft_val.jsonl}"
export GRPO_TRAIN="${GRPO_TRAIN:-${DATA_DIR}/physics_grpo_train.jsonl}"
export GRPO_VAL="${GRPO_VAL:-${DATA_DIR}/physics_grpo_val.jsonl}"

export PLUGIN_DIR="${PLUGIN_DIR:-${ROOT}/plugins}"
export REWARD_PLUGIN="${REWARD_PLUGIN:-${PLUGIN_DIR}/reward_plugin.py}"
export RANDLORA_PLUGIN="${RANDLORA_PLUGIN:-${PLUGIN_DIR}/randlora_tuner.py}"

export OUT_ROOT="${OUT_ROOT:-${ROOT}/outputs}"

# wandb
export WANDB_PROJECT="${WANDB_PROJECT:-physics-sim-qwen3vl-4b}"
export WANDB_DIR="${WANDB_DIR:-/scr/sourajak/wandb}"
mkdir -p "${WANDB_DIR}"

# GPU layout — override with `CUDA_VISIBLE_DEVICES=0,1 NPROC_PER_NODE=2 ...`
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1}"
export NPROC_PER_NODE="${NPROC_PER_NODE:-$(echo "${CUDA_VISIBLE_DEVICES}" | awk -F, '{print NF}')}"

# Pick a free rendezvous port by default so concurrent jobs do not collide.
port_in_use() {
  local p="$1"
  if command -v ss >/dev/null 2>&1; then
    ss -ltnH "sport = :${p}" 2>/dev/null | grep -q .
  elif command -v lsof >/dev/null 2>&1; then
    lsof -iTCP:"${p}" -sTCP:LISTEN -Pn >/dev/null 2>&1
  else
    return 1
  fi
}

if [ -z "${MASTER_PORT:-}" ]; then
  for _ in $(seq 1 50); do
    candidate_port=$((20000 + RANDOM % 20000))
    if ! port_in_use "${candidate_port}"; then
      MASTER_PORT="${candidate_port}"
      break
    fi
  done
  MASTER_PORT="${MASTER_PORT:-29501}"
fi
export MASTER_PORT
