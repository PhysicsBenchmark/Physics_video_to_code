#!/usr/bin/env bash
# LoRA SFT — Qwen3-VL-4B-Instruct on physics-sim CoT+code dataset.
#
# Reproduces the conventions of the existing Qwen2.5-Omni LoRA SFT recipe
# but targets the Qwen3-VL template/model and the new physics dataset.
source "$(dirname "${BASH_SOURCE[0]}")/_common.sh"

OUT_DIR="${OUT_DIR:-${OUT_ROOT}/qwen3vl_4b_lora_sft}"
RUN_NAME="${RUN_NAME:-qwen3vl_4b_lora_sft}"

export WANDB_NAME="${WANDB_NAME:-${RUN_NAME}}"

NPROC_PER_NODE=${NPROC_PER_NODE} \
swift sft \
  --model "${MODEL_PATH}" \
  --model_type "${MODEL_TYPE}" \
  --template "${TEMPLATE}" \
  --dataset "${SFT_TRAIN}" \
  --val_dataset "${SFT_VAL}" \
  --split_dataset_ratio 0 \
  --tuner_type lora \
  --tuner_backend peft \
  --torch_dtype bfloat16 \
  --attn_impl flash_attention_2 \
  --num_train_epochs 2 \
  --per_device_train_batch_size 1 \
  --per_device_eval_batch_size 1 \
  --gradient_accumulation_steps 16 \
  --learning_rate 1e-4 \
  --lr_scheduler_type cosine \
  --warmup_ratio 0.05 \
  --weight_decay 0.1 \
  --adam_beta1 0.9 \
  --adam_beta2 0.95 \
  --optim adamw_torch_fused \
  --lora_rank 16 \
  --lora_alpha 32 \
  --lora_dropout 0.05 \
  --target_modules all-linear \
  --freeze_vit true \
  --freeze_aligner true \
  --max_length 30000 \
  --truncation_strategy delete \
  --lazy_tokenize true \
  --dataset_num_proc 2 \
  --dataloader_num_workers 4 \
  --gradient_checkpointing true \
  --vit_gradient_checkpointing true \
  --eval_strategy steps \
  --eval_steps 100 \
  --resume_from_checkpoint last \
  --save_strategy steps \
  --save_steps 50 \
  --save_total_limit 2 \
  --logging_steps 5 \
  --bf16 true \
  --report_to wandb \
  --output_dir "${OUT_DIR}" \
  "$@"
