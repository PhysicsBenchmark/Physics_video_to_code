# physics-sim Qwen3-VL-4B fine-tuning (ms-swift)

LoRA / RandLoRA SFT and GRPO / DAPO / GSPO RL fine-tuning of
`Qwen/Qwen3-VL-4B-Instruct` on
`/scr/sourajak/physics_video/physics_sim_dataset/dataset` (2,600 video / CoT
/ python-sim triples across 26 simulation types). All runs report to
[wandb](https://wandb.ai/) and use the conda env `swift`.

```
ms_swift_finetune/
├── data/
│   ├── build_dataset.py         # walk dataset/ → ms-swift JSONLs
│   ├── physics_sft_train.jsonl  # 2,548 SFT rows (system + user + assistant)
│   ├── physics_sft_val.jsonl    # 52 SFT rows
│   ├── physics_grpo_train.jsonl # 2,548 GRPO rows (+ solution/gt_cot)
│   └── physics_grpo_val.jsonl   # 52 GRPO rows
├── plugins/
│   ├── reward_plugin.py         # format / cot_json / cot_keys / cot_rouge / code_rouge
│   └── randlora_tuner.py        # registers `tuner_type randlora` (PEFT RandLoraConfig)
├── scripts/
│   ├── _common.sh               # shared paths + GPU layout
│   ├── train_qwen3vl_4b_lora_sft.sh
│   ├── train_qwen3vl_4b_randlora_sft.sh
│   ├── train_qwen3vl_4b_grpo.sh
│   ├── train_qwen3vl_4b_dapo.sh
│   └── train_qwen3vl_4b_gspo.sh
└── outputs/                     # checkpoints + wandb run dirs land here
```

## Prompt design

User prompt (every row):

```
<video>
Watch the video and reason about the physics, then write a Python
simulation that reproduces the observed motion.

Output STRICTLY in this format with no extra prose outside the tags:

<cot>
{
  // a JSON object whose top-level keys are drawn from this canonical
  // schema (use the subset that applies to the depicted system, in
  // this order):
  //   simulation, category, physical_observation, physical_law,
  //   modeling_assumptions, ode_system, event_schedule,
  //   derivation_steps, physical_constants_derived, numerical_method,
  //   code_validation, expected_behavior, parameters
  // ...
}
</cot>
<code>
# ... a self-contained Python script ...
</code>
```

The dataset's per-sample `cot.json` uses one of three sub-schemas (12, 11
or 10 of the union keys); the assistant target preserves whatever keys are
in the ground truth, in the canonical order above. The `cot_keys` reward
scores the model on its match against the per-sample ground-truth key set,
not the union — so it never penalizes the model for omitting a key the
ground truth itself didn't have.

## 0. One-time setup

```bash
conda activate swift           # /home/sourajak/miniconda3/envs/swift
wandb login                    # already done if WANDB_API_KEY is exported
```

Dataset rebuild (only when source data changes):

```bash
cd /scr/sourajak/physics_video/ms_swift_finetune
python data/build_dataset.py
```

## 1. LoRA SFT

```bash
cd /scr/sourajak/physics_video/ms_swift_finetune
CUDA_VISIBLE_DEVICES=0,1 NPROC_PER_NODE=2 \
  scripts/train_qwen3vl_4b_lora_sft.sh
```

## 2. RandLoRA SFT

```bash
CUDA_VISIBLE_DEVICES=0,1 NPROC_PER_NODE=2 \
  scripts/train_qwen3vl_4b_randlora_sft.sh
```

The script passes `--external_plugins plugins/randlora_tuner.py` so
`--tuner_type randlora` resolves to PEFT's `RandLoraConfig`.
RandLoRA-specific knobs (sparse / very-sparse bases, projection PRNG key,
dropout) are read from env vars exported in the script — edit those to
override.

## 3. GRPO

```bash
CUDA_VISIBLE_DEVICES=0,1 NPROC_PER_NODE=2 \
  scripts/train_qwen3vl_4b_grpo.sh
```

Reward weights are tunable on the CLI (the script feeds them in this
order):

| reward         | source                       | weight |
| -------------- | ---------------------------- | -----: |
| `format`       | `plugins/reward_plugin.py`   |   0.10 |
| `cot_keys`     | `plugins/reward_plugin.py`   |   0.25 |
| `cot_rouge`    | `plugins/reward_plugin.py`   |   0.30 |
| `code_rouge`   | `plugins/reward_plugin.py`   |   0.40 |
| `soft_overlong`| ms-swift built-in            |   0.10 |

Override with extra args, e.g.
`scripts/train_qwen3vl_4b_grpo.sh --reward_weights 0.05 0.30 0.30 0.45 0.10`.

## 4. DAPO

```bash
CUDA_VISIBLE_DEVICES=0,1 NPROC_PER_NODE=2 \
  scripts/train_qwen3vl_4b_dapo.sh
```

Same reward stack as GRPO, plus DAPO's algorithmic deltas
(`--dynamic_sample`, `--overlong_filter`, decoupled clipping with
`--epsilon_high`, `--loss_type dapo`).

## 5. GSPO

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 NPROC_PER_NODE=8 \
  scripts/train_qwen3vl_4b_gspo.sh
```

Sequence-level importance sampling (`--importance_sampling_level
sequence`), tight clipping (`epsilon=3e-4`, `epsilon_high=4e-4`), zero KL
(`beta=0`), `steps_per_generation=4` per the GSPO paper.

## Notes / knobs

- `_common.sh` centralizes `MODEL_PATH`, dataset paths, plugin paths,
  GPU layout, and wandb env. Override any of them inline:
  `MODEL_PATH=... scripts/train_qwen3vl_4b_lora_sft.sh`.
- All RL scripts colocate vLLM with the trainer (`vllm_mode colocate`,
  `vllm_gpu_memory_utilization 0.55`). Bump up to `0.7+` if you have spare
  HBM, drop to `0.4` if OOM at sampling time.
- Videos are 12 s / ~1 MB on average — no clipping or downsampling
  required. Default ms-swift video decoding via `decord` works as-is.
- `--max_length 30000` covers the longest CoT-JSON + ~200-line python
  code answer comfortably; raise if you start seeing
  `truncation_strategy=delete` skip warnings during SFT.
