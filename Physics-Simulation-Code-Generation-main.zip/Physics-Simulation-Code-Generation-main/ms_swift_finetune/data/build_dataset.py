#!/usr/bin/env python3
"""Build ms-swift-format JSONLs from /scr/sourajak/physics_video/physics_sim_dataset/dataset.

For every sample directory ``<sim>/<id>/`` that contains ``video.mp4``,
``cot.json``, ``simulation_code.py``, ``params.json`` we emit:

  - SFT row (assistant target = CoT JSON + python code)
  - GRPO row (no assistant target; ``solution`` = python code; ``gt_cot`` =
    CoT JSON dump; reward funcs in plugins/reward_plugin.py consume both)

Both row shapes use absolute video paths so ms-swift's video decoder can
locate them regardless of cwd.

The user prompt names every required CoT key explicitly so the model is
trained / RL'd to emit a CoT JSON whose top-level keys match the ground
truth one-for-one.
"""
from __future__ import annotations

import argparse
import json
import os
import random
from pathlib import Path
from typing import Dict, List, Tuple

DATASET_ROOT = "/scr/sourajak/physics_video/physics_sim_dataset/dataset"

# Union of every top-level key seen across the corpus. The prompt
# advertises this canonical ordering; each sample's assistant target
# only contains the subset of keys present in its own cot.json (since
# different simulations use different sub-schemas). The cot_keys
# reward in plugins/reward_plugin.py credits the model for exactly
# matching the per-sample ground-truth key set, not this superset.
COT_KEYS = [
    "simulation",
    "category",
    "physical_observation",
    "physical_law",
    "modeling_assumptions",
    "ode_system",
    "event_schedule",
    "derivation_steps",
    "physical_constants_derived",
    "numerical_method",
    "code_validation",
    "expected_behavior",
    "parameters",
]

SYSTEM_TEXT = (
    "You are a physics-aware multimodal assistant. Given a short video of a "
    "physical phenomenon you derive the governing physics and produce a "
    "self-contained Python simulation that reproduces the motion seen in the "
    "video."
)

USER_INSTRUCTION = (
    "<video>\n"
    "Watch the video and reason about the physics, then write a Python "
    "simulation that reproduces the observed motion.\n\n"
    "Output STRICTLY in this format with no extra prose outside the tags:\n\n"
    "<cot>\n"
    "{\n"
    "  // a JSON object whose top-level keys are drawn from this canonical\n"
    "  // schema (use the subset that applies to the depicted system, in\n"
    "  // this order):\n"
    "  //   simulation, category, physical_observation, physical_law,\n"
    "  //   modeling_assumptions, ode_system, event_schedule,\n"
    "  //   derivation_steps, physical_constants_derived, numerical_method,\n"
    "  //   code_validation, expected_behavior, parameters\n"
    "  // Each value matches the structure of the ground-truth CoT\n"
    "  // (string, list, or nested object as appropriate).\n"
    "}\n"
    "</cot>\n"
    "<code>\n"
    "# A self-contained, runnable Python script that reproduces the\n"
    "# physical scenario in the video. Use only standard scientific\n"
    "# Python libraries (numpy, scipy, matplotlib).\n"
    "</code>"
)


def iter_samples(root: str):
    for sim in sorted(os.listdir(root)):
        sdir = os.path.join(root, sim)
        if not os.path.isdir(sdir):
            continue
        for inst in sorted(os.listdir(sdir)):
            idir = os.path.join(sdir, inst)
            if not os.path.isdir(idir):
                continue
            video = os.path.join(idir, "video.mp4")
            cot = os.path.join(idir, "cot.json")
            code = os.path.join(idir, "simulation_code.py")
            params = os.path.join(idir, "params.json")
            if all(os.path.isfile(p) for p in (video, cot, code, params)):
                yield sim, inst, video, cot, code, params


def load_cot(path: str) -> Dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_code(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read().rstrip() + "\n"


def assistant_target(cot_obj: Dict, code_str: str) -> str:
    # Emit ground-truth CoT keys in the canonical order the prompt
    # asks the model to follow.
    ordered = {k: cot_obj.get(k) for k in COT_KEYS if k in cot_obj}
    # Preserve any extra keys at the end (none expected, but harmless).
    extras = {k: v for k, v in cot_obj.items() if k not in ordered}
    ordered.update(extras)
    cot_json = json.dumps(ordered, ensure_ascii=False, indent=2)
    return f"<cot>\n{cot_json}\n</cot>\n<code>\n{code_str.rstrip()}\n</code>"


def make_sft_row(video: str, cot_obj: Dict, code_str: str) -> Dict:
    return {
        "messages": [
            {"role": "system", "content": SYSTEM_TEXT},
            {"role": "user", "content": USER_INSTRUCTION},
            {"role": "assistant", "content": assistant_target(cot_obj, code_str)},
        ],
        "videos": [video],
    }


def make_grpo_row(video: str, cot_obj: Dict, code_str: str, simulation: str) -> Dict:
    # gt_cot is consumed by the cot_rouge / cot_keys reward functions.
    # solution is consumed by code_rouge.
    ordered = {k: cot_obj.get(k) for k in COT_KEYS if k in cot_obj}
    return {
        "messages": [
            {"role": "system", "content": SYSTEM_TEXT},
            {"role": "user", "content": USER_INSTRUCTION},
        ],
        "videos": [video],
        "solution": code_str.rstrip(),
        "gt_cot": json.dumps(ordered, ensure_ascii=False),
        "simulation": simulation,
    }


def split_train_val(rows: List[Dict], val_frac: float, seed: int) -> Tuple[List[Dict], List[Dict]]:
    rng = random.Random(seed)
    idxs = list(range(len(rows)))
    rng.shuffle(idxs)
    n_val = max(1, int(round(val_frac * len(rows))))
    val_set = set(idxs[:n_val])
    train, val = [], []
    for i, r in enumerate(rows):
        (val if i in val_set else train).append(r)
    return train, val


def write_jsonl(path: str, rows: List[Dict]) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", default=DATASET_ROOT)
    p.add_argument("--out_dir", default="/scr/sourajak/physics_video/ms_swift_finetune/data")
    p.add_argument("--val_frac", type=float, default=0.02)
    p.add_argument("--seed", type=int, default=42)
    args = p.parse_args()

    sft_rows: List[Dict] = []
    grpo_rows: List[Dict] = []
    skipped = 0
    per_sim = {}
    for sim, inst, video, cot_path, code_path, _ in iter_samples(args.root):
        try:
            cot_obj = load_cot(cot_path)
            code_str = load_code(code_path)
        except Exception as e:
            print(f"[skip] {sim}/{inst}: {e}")
            skipped += 1
            continue
        sft_rows.append(make_sft_row(video, cot_obj, code_str))
        grpo_rows.append(make_grpo_row(video, cot_obj, code_str, sim))
        per_sim[sim] = per_sim.get(sim, 0) + 1

    sft_train, sft_val = split_train_val(sft_rows, args.val_frac, args.seed)
    grpo_train, grpo_val = split_train_val(grpo_rows, args.val_frac, args.seed)

    out = args.out_dir
    write_jsonl(os.path.join(out, "physics_sft_train.jsonl"), sft_train)
    write_jsonl(os.path.join(out, "physics_sft_val.jsonl"), sft_val)
    write_jsonl(os.path.join(out, "physics_grpo_train.jsonl"), grpo_train)
    write_jsonl(os.path.join(out, "physics_grpo_val.jsonl"), grpo_val)

    print(f"sft  : train={len(sft_train)} val={len(sft_val)}")
    print(f"grpo : train={len(grpo_train)} val={len(grpo_val)}")
    print(f"skipped: {skipped}")
    print("per simulation:")
    for k, v in sorted(per_sim.items()):
        print(f"  {k}: {v}")


if __name__ == "__main__":
    main()
