#!/usr/bin/env python3
"""Generate MuJoCo/Sim2Reason dataset samples.

Output: dataset_mujoco/{experiment}/{sample_id:03d}/ with exactly
video.mp4, simulation_code.py, cot.json, and params.json.
"""

from __future__ import annotations

import argparse
import importlib
import json
import sys
import time
import traceback
from pathlib import Path

BASE_DIR = Path(__file__).parent
DATASET_DIR = BASE_DIR / "dataset_mujoco"
SIM_PKG = "simulations.mujoco"
CONFIG_PATH = BASE_DIR / "configs" / "parameter_ranges_mujoco.json"

EXPERIMENTS = [
    'advanced_collision',
    'advanced_hybrid',
    'advanced_inclined_plane_friction',
    'basic_collision',
    'basic_inclined_plane_friction',
    'basic_pulley',
    'difficult_electro_magnetic',
    'difficult_orbital_motion',
    'difficult_pulley',
    'difficult_rocket',
    'difficult_spring_mass',
    'intermediate_collision',
    'intermediate_hybrid',
    'intermediate_inclined_plane_friction',
    'intermediate_pulley',
    'rigid_body_rotation',
    'rotation',
    'spring_block_systems'
]


def generate_experiment(exp_name: str, n_samples: int, seed: int, duration: float, fps: int, resume: bool, run_video: bool) -> list[dict]:
    sys.path.insert(0, str(BASE_DIR))
    mod = importlib.import_module(f"{SIM_PKG}.{exp_name}")
    exp_dir = DATASET_DIR / exp_name
    manifest = []
    for i in range(n_samples):
        sample_seed = seed + i
        out_dir = exp_dir / f"{i:03d}"
        if resume and all((out_dir / name).exists() for name in ("simulation_code.py", "cot.json", "params.json", "video.mp4")):
            continue
        entry = mod.generate_sample(seed=sample_seed, out_dir=str(out_dir), duration=duration, fps=fps, run_video=run_video)
        manifest.append(entry)
    return manifest


def main() -> None:
    global DATASET_DIR

    parser = argparse.ArgumentParser(description="Generate MuJoCo/Sim2Reason dataset samples")
    parser.add_argument("--config", type=str, default=str(CONFIG_PATH),
                        help="Engine-specific MuJoCo config JSON")
    parser.add_argument("--experiments", nargs="*", default=None, help="Experiment module names to run")
    parser.add_argument("--n-samples", "--n", dest="n_samples", type=int, default=75)
    parser.add_argument("--out", type=str, default=str(DATASET_DIR))
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--duration", type=float, default=10.0)
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--no-run-video", action="store_true", help="Write code/COT/params but do not execute simulation_code.py")
    args = parser.parse_args()

    cfg = {}
    config_path = Path(args.config)
    if config_path.exists():
        cfg = json.loads(config_path.read_text(encoding="utf-8"))

    DATASET_DIR = Path(args.out)
    if args.n_samples == 75:
        args.n_samples = int(cfg.get("n_samples", args.n_samples))
    if args.duration == 10.0:
        args.duration = float(cfg.get("duration_seconds", args.duration))
    if args.fps == 30:
        args.fps = int(cfg.get("fps", args.fps))

    experiments = args.experiments or EXPERIMENTS
    manifest = []
    errors = 0
    start = time.time()

    for exp in experiments:
        if exp not in EXPERIMENTS:
            print(f"[WARN] Unknown MuJoCo experiment {exp!r}, skipping")
            continue
        print(f"\n{'=' * 60}\n  MuJoCo experiment: {exp}\n  Output: {DATASET_DIR / exp}\n{'=' * 60}")
        try:
            entries = generate_experiment(exp, args.n_samples, args.seed, args.duration, args.fps, args.resume, not args.no_run_video)
            manifest.extend(entries)
            print(f"  Done: {len(entries)} generated")
        except Exception as exc:
            errors += 1
            print(f"  FAILED: {exc}")
            traceback.print_exc()

    if manifest:
        DATASET_DIR.mkdir(parents=True, exist_ok=True)
        (DATASET_DIR / "global_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"\nMuJoCo dataset complete: {len(manifest)} generated, {errors} failed in {time.time() - start:.1f}s")
    if errors:
        sys.exit(1)


if __name__ == "__main__":
    main()
