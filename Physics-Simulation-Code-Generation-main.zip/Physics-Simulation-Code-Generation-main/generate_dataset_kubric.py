#!/usr/bin/env python3
"""
generate_dataset_kubric.py — GPU-sharded dataset generator for kubric_3d experiments.

Each experiment generates 200 samples (randomised parameters).
Output:  physics_sim_dataset/dataset_kubric/{experiment}/{sample_id:03d}/
           video.mp4, params.json, cot.json, simulation_code.py

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Usage
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Single-GPU (sequential):
  python generate_dataset_kubric.py

# 4 GPUs — auto-launch one subprocess per GPU:
  python generate_dataset_kubric.py --launch --total-gpus 4

# Manual shard (run each in a separate terminal or via nohup):
  EGL_DEVICE_ID=0 python generate_dataset_kubric.py --total-gpus 4 --gpu-id 0
  EGL_DEVICE_ID=1 python generate_dataset_kubric.py --total-gpus 4 --gpu-id 1
  EGL_DEVICE_ID=2 python generate_dataset_kubric.py --total-gpus 4 --gpu-id 2
  EGL_DEVICE_ID=3 python generate_dataset_kubric.py --total-gpus 4 --gpu-id 3

# Run only specific experiments:
  python generate_dataset_kubric.py --experiments bouncing_balls_arena domino_chain

# Resume (skip already-complete samples):
  python generate_dataset_kubric.py --resume
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

from __future__ import annotations
import os, sys, argparse, subprocess, importlib, time, traceback
import json
import fcntl
from pathlib import Path

if "PYOPENGL_PLATFORM" not in os.environ and not os.environ.get("DISPLAY"):
    os.environ["PYOPENGL_PLATFORM"] = "egl"

# ── all 50 experiment module names ────────────────────────────────────────────
EXPERIMENTS = [
    # Rigid body — free dynamics
    "bouncing_balls_arena",
    "block_tower_projectile",
    "domino_chain",
    "billiard_break_3d",
    "avalanche_slope",
    "ball_pit_drop",
    "spinning_top_precession",
    "jenga_pull",
    "funnel_sorting",
    # Rigid body — constrained / inclined
    "ramp_slide_friction",
    "projectile_parabola",
    "ramp_jump_landing",
    "sphere_bowl_oscillation",
    "staircase_bounce",
    "wedge_collision",
    "rolling_cylinder_slope",
    "newton_cradle_3d",
    "wrecking_ball_pendulum",
    "tumbling_dice",
    # Articulated / jointed
    "pendulum_3d_single",
    "double_pendulum_3d_chaotic",
    "conical_pendulum",
    "atwood_machine",
    "seesaw_imbalance",
    "hinged_door_slam",
    "robot_arm_collapse",
    "ragdoll_free_fall",
    "trebuchet_throw",
    "lever_catapult",
    # Rope / soft
    "rope_pendulum_swing",
    # Mixed / complex
    "multi_physics_arena",
    "bowling_strike",
    "marble_run_ramps",
    "stacked_discs_topple",
    "coin_spin_topple",
    "object_collision_mid_air",
    "scissor_collapse",
    # Real-life teaching scenes
    "rolling_vs_sliding_blocks",
    "compound_pulley_lift",
    "two_car_collision_3d",
    "toppling_bookshelf_row",
    "stacked_blocks_earthquake",
    "rolling_ball_loop_track",
    "mass_spring_collision_chain",
    "gyroscope_on_stand",
    "coin_toss_spin_land",
    "granular_hourglass_3d",
    "arch_collapse_keystone",
    "bridge_truss_load_failure",
    "seesaw_with_falling_mass",
    # Advanced robust real-life teaching scenes
    "spinning_rod_balloon_tether",
    "balloon_tether_wall_pull",
    "stick_support_catapult_release",
    "elastic_coupled_cart_collision",
    "crank_push_friction_stop",
    "double_pendulum_impact_transfer",
    "carried_pendulum_inertia",
    "turntable_mirror_blocks",
    "wind_balanced_falling_panel",
    "fan_push_stationary_block",
    "moving_cart_hits_stationary_cart",
    "moving_cart_hits_moving_cart",
    "plasticine_ball_inelastic_drop",
    "oblique_projectile_hits_slope",
    "rolling_ball_up_slope",
    "accelerating_panel_spins_objects",
    "center_vs_offset_seesaw",
    "spring_compress_vs_stretch",
    "concave_bowl_spin_orbit",
    "springboard_rebound_ball",
    "vertical_fall_spinning_panel",
    "rod_spin_hits_balloon",
    "block_wall_hit_by_tethered_mass",
    "offset_load_turntable",
    "ramp_to_spring_projectile",
]

BASE_DIR    = Path(__file__).parent
DATASET_DIR = BASE_DIR / "dataset_kubric"
SIM_PKG     = "simulations.kubric_3d"
CONFIG_PATH = BASE_DIR / "configs" / "parameter_ranges_kubric.json"
RENDER_LOCK_PATH = Path("/tmp/physics_dataset_kubric_render.lock")


# ── per-experiment generation ─────────────────────────────────────────────────

def run_simulation_code(sample_dir: Path) -> None:
    """Regenerate video.mp4 by executing the sample's standalone script."""
    video_path = sample_dir / "video.mp4"
    if video_path.exists():
        video_path.unlink()

    env = os.environ.copy()
    if "PYOPENGL_PLATFORM" not in env and not env.get("DISPLAY"):
        env["PYOPENGL_PLATFORM"] = "egl"
    env.pop("KUBRIC_METADATA_ONLY", None)
    # EGL_DEVICE_ID caused pyrender/PyOpenGL hangs in child standalone renders
    # during --launch sharding. Keep sharding at the worker level, but let the
    # standalone render process choose its EGL device normally.
    env.pop("EGL_DEVICE_ID", None)
    timeout_s = float(env.get("KUBRIC_RENDER_TIMEOUT", "180"))

    # Pyrender/EGL is not reliable when many worker processes initialize GL
    # contexts simultaneously. Serialize just the standalone render step; scene
    # parameter/COT/code generation remains sharded.
    RENDER_LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(RENDER_LOCK_PATH, "w", encoding="utf-8") as lock_f:
        fcntl.flock(lock_f, fcntl.LOCK_EX)
        result = subprocess.run(
            [sys.executable, "simulation_code.py"],
            cwd=sample_dir,
            env=env,
            text=True,
            capture_output=True,
            timeout=timeout_s,
        )
        fcntl.flock(lock_f, fcntl.LOCK_UN)

    if result.stdout:
        print(result.stdout, end="")
    if result.stderr:
        print(result.stderr, end="", file=sys.stderr)
    if result.returncode != 0:
        raise subprocess.CalledProcessError(
            result.returncode,
            [sys.executable, "simulation_code.py"],
            output=result.stdout,
            stderr=result.stderr,
        )

    if video_path.exists():
        return

    candidates = sorted(
        sample_dir.glob("*.mp4"),
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )
    if not candidates:
        raise FileNotFoundError(f"No MP4 produced by {sample_dir / 'simulation_code.py'}")

    candidates[0].rename(video_path)
    for extra in sample_dir.glob("*.mp4"):
        if extra.name != "video.mp4":
            extra.unlink()


def generate_experiment(exp_name: str, n_samples: int = 200,
                        resume: bool = False, gpu_id: int = 0):
    sys.path.insert(0, str(BASE_DIR))
    try:
        mod = importlib.import_module(f"{SIM_PKG}.{exp_name}")
    except ModuleNotFoundError as e:
        print(f"  [SKIP] {exp_name}: module not found — {e}")
        return 0, 1

    exp_dir = DATASET_DIR / exp_name
    ok = err = 0

    for i in range(n_samples):
        out_dir = exp_dir / f"{i:03d}"
        if resume and (out_dir / "video.mp4").exists():
            ok += 1
            continue
        try:
            old_metadata_only = os.environ.get("KUBRIC_METADATA_ONLY")
            os.environ["KUBRIC_METADATA_ONLY"] = "1"
            try:
                mod.generate_sample(seed=i, out_dir=str(out_dir))
            finally:
                if old_metadata_only is None:
                    os.environ.pop("KUBRIC_METADATA_ONLY", None)
                else:
                    os.environ["KUBRIC_METADATA_ONLY"] = old_metadata_only
            run_simulation_code(out_dir)
            ok += 1
        except Exception:
            err += 1
            print(f"  [ERR] {exp_name}/{i:03d}:")
            traceback.print_exc()

    print(f"  [GPU {gpu_id}] {exp_name}: {ok} OK, {err} errors")
    return ok, err


# ── entry point ───────────────────────────────────────────────────────────────

def main():
    global DATASET_DIR

    ap = argparse.ArgumentParser(
        description="Generate kubric_3d dataset samples (GPU-sharded)")
    ap.add_argument("--config", type=str, default=str(CONFIG_PATH),
                    help="Engine-specific Kubric config JSON")
    ap.add_argument("--out", type=str, default=str(DATASET_DIR),
                    help="Output directory")
    ap.add_argument("--total-gpus",   type=int, default=1,
                    help="total number of GPUs / workers")
    ap.add_argument("--gpu-id",       type=int, default=0,
                    help="index of THIS worker (0-indexed)")
    ap.add_argument("--n-samples",    type=int, default=200,
                    help="samples per experiment")
    ap.add_argument("--launch",       action="store_true",
                    help="auto-launch one subprocess per GPU")
    ap.add_argument("--resume",       action="store_true",
                    help="skip samples whose video.mp4 already exists")
    ap.add_argument("--experiments",  nargs="*", default=None,
                    help="run only these experiments (space-separated)")
    args = ap.parse_args()

    cfg = {}
    config_path = Path(args.config)
    if config_path.exists():
        cfg = json.loads(config_path.read_text(encoding="utf-8"))

    DATASET_DIR = Path(args.out)
    if args.n_samples == 200:
        args.n_samples = int(cfg.get("n_samples", args.n_samples))

    experiments = args.experiments or EXPERIMENTS

    # ── auto-launch mode: spawn one subprocess per GPU ────────────────────────
    if args.launch:
        procs = []
        for gid in range(args.total_gpus):
            env      = os.environ.copy()
            env["EGL_DEVICE_ID"] = str(gid)
            cmd = [
                sys.executable, __file__,
                "--config", str(config_path),
                "--out", str(DATASET_DIR),
                "--total-gpus", str(args.total_gpus),
                "--gpu-id",     str(gid),
                "--n-samples",  str(args.n_samples),
            ]
            if args.resume:
                cmd.append("--resume")
            if args.experiments:
                cmd += ["--experiments"] + args.experiments
            print(f"Launching GPU {gid}: {' '.join(cmd)}")
            procs.append(subprocess.Popen(cmd, env=env))
        for pr in procs:
            pr.wait()
        return

    # ── single-worker mode ────────────────────────────────────────────────────
    my_exps = [e for i, e in enumerate(experiments)
               if i % args.total_gpus == args.gpu_id]

    print(f"[GPU {args.gpu_id}/{args.total_gpus}] "
          f"Running {len(my_exps)} experiments × {args.n_samples} samples")

    t0 = time.time()
    total_errors = 0
    for exp in my_exps:
        print(f"\n── {exp} ──")
        _, err = generate_experiment(exp, n_samples=args.n_samples,
                                     resume=args.resume, gpu_id=args.gpu_id)
        total_errors += err

    elapsed = time.time() - t0
    print(f"\n[GPU {args.gpu_id}] Done in {elapsed/60:.1f} min")
    if total_errors:
        sys.exit(1)


if __name__ == "__main__":
    main()
