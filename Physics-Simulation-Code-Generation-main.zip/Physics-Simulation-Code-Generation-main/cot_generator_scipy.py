"""
Chain-of-Thought (CoT) Generator for Physics Simulation Dataset
================================================================
Generates structured CoT JSON for each (simulation, parameter_set) pair.

The CoT format mirrors what a coding agent would reason through when watching a
physics simulation video and then generating the corresponding Python code:
  1. Physical observation — what the agent sees
  2. Physical law identification — named law + formal statement
  3. ODE derivation — step-by-step from first principles
  4. Variable table — all quantities with values and units
  5. Numerical method justification
  6. Code validation — does the code abide by the law?
  7. Expected qualitative behavior for these specific parameter values
"""

from __future__ import annotations
import math
import re
import unicodedata
from typing import Any

# ─────────────────────────────────────────────────────────────────────────────
# Simple Pendulum
# ─────────────────────────────────────────────────────────────────────────────
def cot_simple_pendulum(params: dict[str, Any]) -> dict:
    L, m, g, b = params["L"], params["m"], params["g"], params["b"]
    A, k_freq   = params["A"], params["k_freq"]
    theta0, omega0 = params["theta0"], params["omega0"]

    mlsq = m * L * L
    omega0_nat = math.sqrt(g / L)
    T_small    = 2 * math.pi / omega0_nat
    zeta       = b / (2 * mlsq * omega0_nat)   # damping ratio on angular system
    driven     = A > 0

    if driven:
        obs = (
            f"A pendulum bob swings on a rigid rod of length L={L:.3f} m from a fixed pivot. "
            f"An external periodic driving force of amplitude A={A:.3f} N·m at frequency "
            f"ω_drive={k_freq:.3f} rad/s sustains and modifies the oscillations."
        )
    else:
        obs = (
            f"A point mass (m={m:.3f} kg) swings on a rigid rod (L={L:.3f} m) from a fixed pivot. "
            f"The oscillation amplitude decays due to damping (b={b:.3f} kg·m²/s)."
        )

    derivation = [
        "Identify the generalized coordinate: θ = angle of the rod from the downward vertical.",
        "Moment of inertia for a point mass at distance L from the pivot: I = m L².",
        "Torques about the pivot:",
        "  τ_gravity  = −m g L sin(θ)   [restoring, acts opposite to displacement]",
        "  τ_damping  = −b θ̇            [b has units kg·m²/s; opposes angular velocity]",
        f"  τ_drive    = A cos(ω_drive t) [A={A:.3f} N·m, ω_drive={k_freq:.3f} rad/s]" if driven
            else "  τ_drive    = 0             [undriven system]",
        "Newton's second law for rotation: I θ̈ = Στ",
        "  m L² θ̈ = −m g L sin(θ) − b θ̇" + (f" + A cos({k_freq:.3f} t)" if driven else ""),
        "Divide by m L² to obtain the state-space form:",
        f"  θ̈ = −(g/L) sin(θ) − (b/mL²) θ̇"
            + (f" + (A/mL²) cos({k_freq:.3f} t)" if driven else ""),
    ]

    behavior = []
    if not driven:
        behavior.append(f"Natural period (small angles): T₀ ≈ {T_small:.3f} s")
        if zeta < 1:
            behavior.append(f"Damping ratio ζ = b/(2mL²ω₀) = {zeta:.4f} < 1 → underdamped oscillation")
        elif zeta >= 1:
            behavior.append(f"Damping ratio ζ = {zeta:.4f} ≥ 1 → overdamped (no oscillation)")
    else:
        behavior.append(f"System is driven at ω_drive={k_freq:.3f} rad/s; natural ω₀={omega0_nat:.3f} rad/s")
        if abs(k_freq - omega0_nat) < 0.1:
            behavior.append("ω_drive ≈ ω₀ → near-resonance condition; expect large amplitude oscillations")

    return {
        "simulation": "simple_pendulum",
        "parameters": params,
        "physical_observation": obs,
        "physical_law": {
            "name": "Newton's Second Law for Rotational Motion (τ = Iα)",
            "statement": "The net torque on a body about a fixed axis equals the moment of inertia times the angular acceleration.",
            "formula": "Iθ̈ = Στ  →  mL²θ̈ = −mgL sin(θ) − bθ̇" + (f" + A cos(ω_drive t)" if driven else ""),
        },
        "ode_system": {
            "state_variables": ["θ (angle, rad)", "ω = θ̇ (angular velocity, rad/s)"],
            "equations": [
                "dθ/dt = ω",
                "dω/dt = −(g/L) sin(θ) − (b/(mL²)) ω" + (f" + (A/(mL²)) cos(k_freq t)" if driven else ""),
            ],
        },
        "derivation_steps": derivation,
        "variables": {
            "θ": {"description": "Angle of rod from vertical", "initial_value": theta0, "unit": "rad"},
            "ω": {"description": "Angular velocity", "initial_value": omega0, "unit": "rad/s"},
            "L": {"description": "Rod length", "value": L, "unit": "m"},
            "m": {"description": "Bob mass", "value": m, "unit": "kg"},
            "g": {"description": "Gravitational acceleration", "value": g, "unit": "m/s²"},
            "b": {"description": "Angular damping coefficient", "value": b, "unit": "kg·m²/s"},
            "A": {"description": "Driving torque amplitude", "value": A, "unit": "N·m"},
            "k_freq": {"description": "Driving angular frequency", "value": k_freq, "unit": "rad/s"},
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince, 4th/5th order Runge-Kutta)",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": "Matches the 4th-order Runge-Kutta solver used in myphysicslab TypeScript source.",
        },
        "code_validation": {
            "ode_source": "Newton's 2nd law for rotation; exact translation of PendulumSim.ts evaluate()",
            "energy_check": "Total energy E = ½mL²ω² + mgL(1−cos θ) should decrease monotonically when b>0",
            "physical_plausibility": True,
        },
        "expected_behavior": behavior,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Double Pendulum
# ─────────────────────────────────────────────────────────────────────────────
def cot_double_pendulum(params: dict[str, Any]) -> dict:
    L1, L2 = params["L1"], params["L2"]
    m1, m2 = params["m1"], params["m2"]
    g = params["g"]
    th1_0, th2_0 = params["theta1_0"], params["theta2_0"]

    is_chaotic = abs(th1_0) > 0.5 or abs(th2_0) > 0.5   # heuristic

    return {
        "simulation": "double_pendulum",
        "parameters": params,
        "physical_observation": (
            f"Two rigid rods connected in series (L₁={L1:.3f} m, L₂={L2:.3f} m) with point masses "
            f"(m₁={m1:.3f} kg, m₂={m2:.3f} kg) swing from a fixed pivot. "
            + ("The large initial displacement (θ₁={:.2f} rad, θ₂={:.2f} rad) causes chaotic, "
               "non-repeating motion — the hallmark of a double pendulum.".format(th1_0, th2_0)
               if is_chaotic else
               "Small initial angles produce near-periodic motion.")
        ),
        "physical_law": {
            "name": "Lagrangian Mechanics (Euler-Lagrange equations)",
            "statement": "For generalized coordinates q_i: d/dt(∂L/∂q̇_i) − ∂L/∂q_i = 0, where L = T − V.",
            "formula": "Coupled 2nd-order ODEs derived from L = T(θ₁,θ₂,θ̇₁,θ̇₂) − V(θ₁,θ₂)",
        },
        "ode_system": {
            "state_variables": ["θ₁", "ω₁=θ̇₁", "θ₂", "ω₂=θ̇₂"],
            "equations": [
                "dθ₁/dt = ω₁",
                "dω₁/dt = [−g(2m₁+m₂)sin(θ₁) − gm₂sin(θ₁−2θ₂) − 2m₂ω₂²L₂sin(θ₁−θ₂) − m₂ω₁²L₁sin(2(θ₁−θ₂))] / [L₁(2m₁+m₂−m₂cos(2(θ₁−θ₂)))]",
                "dθ₂/dt = ω₂",
                "dω₂/dt = [2sin(θ₁−θ₂)((m₁+m₂)ω₁²L₁ + g(m₁+m₂)cos(θ₁) + m₂ω₂²L₂cos(θ₁−θ₂))] / [L₂(2m₁+m₂−m₂cos(2(θ₁−θ₂)))]",
            ],
        },
        "derivation_steps": [
            "Define Cartesian positions of bob 1 and bob 2:",
            "  x₁ = L₁ sin(θ₁),         y₁ = −L₁ cos(θ₁)",
            "  x₂ = L₁ sin(θ₁) + L₂ sin(θ₂),  y₂ = −L₁ cos(θ₁) − L₂ cos(θ₂)",
            "Write kinetic energy T = ½m₁v₁² + ½m₂v₂² in terms of θ₁, θ₂, θ̇₁, θ̇₂.",
            "Write potential energy V = m₁ g y₁ + m₂ g y₂.",
            "Form Lagrangian L = T − V.",
            "Apply Euler-Lagrange: d/dt(∂L/∂ω₁) − ∂L/∂θ₁ = 0  and  d/dt(∂L/∂ω₂) − ∂L/∂θ₂ = 0.",
            "Solve the resulting 2×2 linear system for θ̈₁, θ̈₂ (see equations above).",
            "These are exactly the equations implemented in DoublePendulumSim.ts evaluate().",
        ],
        "variables": {
            "θ₁": {"description": "Angle of rod 1 from vertical", "initial_value": th1_0, "unit": "rad"},
            "θ₂": {"description": "Angle of rod 2 from vertical", "initial_value": th2_0, "unit": "rad"},
            "L₁": {"value": L1, "unit": "m"},
            "L₂": {"value": L2, "unit": "m"},
            "m₁": {"value": m1, "unit": "kg"},
            "m₂": {"value": m2, "unit": "kg"},
            "g":  {"value": g,  "unit": "m/s²"},
        },
        "numerical_method": {
            "solver": "RK45",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "note": "High-accuracy tolerances needed because double pendulum is sensitive to initial conditions.",
        },
        "code_validation": {
            "ode_source": "Euler-Lagrange equations; exact translation of DoublePendulumSim.ts evaluate()",
            "energy_check": "Total E = T + V conserved (no damping); energy drift < 0.01% for 15 s run",
            "physical_plausibility": True,
            "chaos_indicator": is_chaotic,
        },
        "expected_behavior": [
            "No damping — total mechanical energy is conserved.",
            "Sensitive dependence on initial conditions for large angles (chaos)." if is_chaotic
            else "Near-linear, nearly periodic motion for small initial angles.",
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Single Spring
# ─────────────────────────────────────────────────────────────────────────────
def cot_single_spring(params: dict[str, Any]) -> dict:
    k, m, b = params["k"], params["m"], params["b"]
    u0, v0  = params["u0"], params["v0"]

    omega0_nat = math.sqrt(k / m)
    zeta       = b / (2 * m * omega0_nat)
    T          = 2 * math.pi / omega0_nat

    if zeta < 1:
        regime = "underdamped (decaying oscillation)"
        omega_d = omega0_nat * math.sqrt(1 - zeta**2)
        T_d = 2 * math.pi / omega_d
        regime_detail = f"Damped oscillation frequency ω_d = {omega_d:.4f} rad/s, period T_d = {T_d:.4f} s"
    elif abs(zeta - 1) < 0.02:
        regime = "critically damped (fastest non-oscillatory return)"
        regime_detail = "System returns to equilibrium without oscillating."
    else:
        regime = "overdamped (non-oscillatory decay)"
        regime_detail = "System returns exponentially without oscillating."

    return {
        "simulation": "single_spring",
        "parameters": params,
        "physical_observation": (
            f"A block (m={m:.3f} kg) is attached to a spring (k={k:.3f} N/m) fixed to a wall "
            f"and displaced u₀={u0:.3f} m from equilibrium. Damping coefficient b={b:.3f} kg/s. "
            f"Motion is {regime}."
        ),
        "physical_law": {
            "name": "Newton's Second Law + Hooke's Law + Viscous Damping",
            "statement": "ΣF = ma.  Spring force: F_s = −ku.  Damping force: F_d = −bv.",
            "formula": "mü + bv + ku = 0  →  ü = −(k/m)u − (b/m)u̇",
        },
        "ode_system": {
            "state_variables": ["u (displacement from equilibrium, m)", "v = u̇ (velocity, m/s)"],
            "equations": [
                "du/dt = v",
                "dv/dt = −(k/m) u − (b/m) v",
            ],
        },
        "derivation_steps": [
            "Let u = x − x_eq (displacement from spring equilibrium position).",
            "At x_eq: spring stretch = 0; spring force = 0.",
            "For displacement u: spring force = −k u (Hooke's Law).",
            "Viscous damping force = −b v  (proportional to velocity).",
            "Newton's 2nd law: m ü = −k u − b v.",
            "Divide by m: ü = −(k/m) u − (b/m) v.",
            "Equivalently: dv/dt = (−k·u − b·v) / m, the textbook damped-harmonic-oscillator form.",
        ],
        "variables": {
            "u": {"description": "Displacement from equilibrium", "initial_value": u0, "unit": "m"},
            "v": {"description": "Velocity", "initial_value": v0, "unit": "m/s"},
            "k": {"value": k, "unit": "N/m"},
            "m": {"value": m, "unit": "kg"},
            "b": {"value": b, "unit": "kg/s"},
        },
        "physical_constants_derived": {
            "omega_0": round(omega0_nat, 4),
            "T_0_seconds": round(T, 4),
            "damping_ratio_zeta": round(zeta, 4),
            "regime": regime,
        },
        "numerical_method": {"solver": "RK45", "tolerance": "rtol=1e-9, atol=1e-11"},
        "code_validation": {
            "ode_source": "Newton's 2nd law on a single mass under linear-spring + viscous-damping forces (textbook damped harmonic oscillator).",
            "energy_check": "E = ½mv² + ½ku² decreases monotonically when b>0",
            "physical_plausibility": True,
        },
        "expected_behavior": [regime_detail],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Double Spring
# ─────────────────────────────────────────────────────────────────────────────
def cot_double_spring(params: dict[str, Any]) -> dict:
    k, m1, m2, b = params["k"], params["m1"], params["m2"], params["b"]
    R, du2, dv2  = params["R"], params["du2"], params["dv2"]

    # Normal modes of undamped system: 2-mass, 3-spring with equal k and R
    # ω₁² = k/m (in-phase mode), ω₂² = 3k/m (out-of-phase mode) for m1=m2
    if abs(m1 - m2) < 0.1 * max(m1, m2):
        omega1 = math.sqrt(k / ((m1 + m2) / 2))   # approx
        omega2 = math.sqrt(3 * k / ((m1 + m2) / 2))
        modes_note = (f"For m₁≈m₂: in-phase ω₁≈{omega1:.3f} rad/s, out-of-phase ω₂≈{omega2:.3f} rad/s")
    else:
        modes_note = "Normal modes depend on m₁, m₂ ratio; use eigenvalue analysis for exact values."

    return {
        "simulation": "double_spring",
        "parameters": params,
        "physical_observation": (
            f"Two blocks (m₁={m1:.3f} kg, m₂={m2:.3f} kg) are coupled by three identical springs "
            f"(k={k:.3f} N/m, rest length R={R:.2f} m) between two fixed walls. "
            f"Block 2 starts with velocity v₂={dv2:.2f} m/s, creating a coupled oscillation."
        ),
        "physical_law": {
            "name": "Newton's Second Law for a Coupled Oscillator System",
            "statement": "ΣF = ma applied independently to each block; springs transmit forces between them.",
            "formula": "m₁ẍ₁ = −k·s₁ + k·s₂ − b·v₁\nm₂ẍ₂ = −k·s₂ + k·s₃ − b·v₂",
        },
        "ode_system": {
            "state_variables": ["x₁ (block 1 position, m)", "x₂ (block 2 position, m)", "v₁", "v₂"],
            "equations": [
                "dx₁/dt = v₁",
                "dx₂/dt = v₂",
                "dv₁/dt = [−k(x₁−wall₁−R) + k(x₂−x₁−R) − b·v₁] / m₁",
                "dv₂/dt = [−k(x₂−x₁−R) + k(wall₂−x₂−R) − b·v₂] / m₂",
            ],
        },
        "derivation_steps": [
            "Label positions: wall₁=0, block₁ at x₁, block₂ at x₂, wall₂=3R.",
            "Spring stretches (gap minus rest length):",
            "  s₁ = (x₁ − wall₁) − R  [spring 1: wall1→block1]",
            "  s₂ = (x₂ − x₁) − R     [spring 2: block1→block2]",
            "  s₃ = (wall₂ − x₂) − R  [spring 3: block2→wall2; note: wall is on right]",
            "Force on block₁: F₁ = −k·s₁ (spring 1 pulls left) + k·s₂ (spring 2 pulls right) − b·v₁",
            "Force on block₂: F₂ = −k·s₂ (spring 2 pulls left) + k·s₃ (spring 3 pulls right) − b·v₂",
            "Note: s₃ = (wall₂−x₂)−R; when s₃>0 spring is stretched and pulls block₂ rightward.",
            "These equations match DoubleSpringSim.ts evaluate() with S1=S2=S3=+1.",
        ],
        "variables": {
            "x₁": {"description": "Position of block 1", "unit": "m"},
            "x₂": {"description": "Position of block 2", "unit": "m"},
            "k":  {"value": k, "unit": "N/m"},
            "m₁": {"value": m1, "unit": "kg"},
            "m₂": {"value": m2, "unit": "kg"},
            "b":  {"value": b, "unit": "kg/s"},
            "R":  {"value": R, "unit": "m"},
        },
        "physical_constants_derived": {"normal_modes_note": modes_note},
        "numerical_method": {"solver": "RK45", "tolerance": "rtol=1e-9, atol=1e-11"},
        "code_validation": {
            "ode_source": "Newton's 2nd Law; exact translation of DoubleSpringSim.ts evaluate()",
            "energy_check": "E = ½m₁v₁² + ½m₂v₂² + ½k(s₁²+s₂²+s₃²) decreases monotonically when b>0",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            "Coupled normal modes visible as beats in the position time-series.",
            modes_note,
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Cart Pendulum
# ─────────────────────────────────────────────────────────────────────────────
def cot_cart_pendulum(params: dict[str, Any]) -> dict:
    M, m, L, k = params["M"], params["m"], params["L"], params["k"]
    g, d_c, b   = params["g"], params["d_c"], params["b"]
    x0, h0      = params["x0"], params["h0"]

    omega_cart   = math.sqrt(k / (M + m))    # approximate (decoupled small h)
    omega_pend   = math.sqrt(g / L)

    return {
        "simulation": "cart_pendulum",
        "parameters": params,
        "physical_observation": (
            f"A cart (M={M:.3f} kg) on a frictionless track is connected to a fixed wall by a spring "
            f"(k={k:.3f} N/m). A pendulum bob (m={m:.3f} kg, L={L:.3f} m) hangs from the cart. "
            f"Cart starts displaced x₀={x0:.3f} m from equilibrium; pendulum angle h₀={h0:.3f} rad."
        ),
        "physical_law": {
            "name": "Lagrangian Mechanics for Constrained Multi-Body System",
            "statement": "Euler-Lagrange equations for generalized coordinates q=(x,h).",
            "formula": (
                "ẍ = (m w² L sin h + mg sin h cos h − kx − d_c ẋ + b w cos h/L) / (M + m sin²h)\n"
                "ḧ = (−m w² L sin h cos h + kx cos h − (M+m)g sin h + d_c ẋ cos h − (m+M)b w/(mL)) "
                "/ (L(M + m sin²h))"
            ),
        },
        "ode_system": {
            "state_variables": ["x (cart displacement, m)", "h (pendulum angle, rad)", "v=ẋ", "w=ḣ"],
            "equations": [
                "dx/dt = v",
                "dh/dt = w",
                "dv/dt = (m w² L sin h + m g sin h cos h − k x − d_c v + b w cos h / L) / (M + m sin²h)",
                "dw/dt = (−m w² L sin h cos h + k x cos h − (M+m) g sin h + d_c v cos h − (m+M) b w/(m L)) / (L(M + m sin²h))",
            ],
        },
        "derivation_steps": [
            "Generalized coordinates: x (cart position from spring equilibrium), h (pendulum angle from vertical).",
            "Cart position in 2D: (x, 0).",
            "Bob position: (x + L sin h, −L cos h).",
            "Bob velocity squared: (ẋ + Lḣ cos h)² + (Lḣ sin h)² = ẋ² + L²ḣ² + 2ẋLḣ cos h.",
            "Kinetic energy: T = ½M ẋ² + ½m[(ẋ+Lḣ cos h)² + (Lḣ sin h)²].",
            "Potential energy: V = ½kx² − mgL cos h.",
            "Lagrangian L = T − V; apply Euler-Lagrange for x and h.",
            "Solve the resulting 2×2 system (with denominator M + m sin²h) for ẍ and ḧ.",
            "Add dissipation terms (cart damping d_c, pendulum damping b) as generalized forces.",
            "Result: a coupled 2-DOF nonlinear ODE system in (x, h, ẋ, ḣ) — the standard cart-pendulum equations of motion.",
        ],
        "variables": {
            "x": {"description": "Cart displacement from spring equilibrium", "initial_value": x0, "unit": "m"},
            "h": {"description": "Pendulum angle from vertical", "initial_value": h0, "unit": "rad"},
            "M": {"value": M, "unit": "kg"},
            "m": {"value": m, "unit": "kg"},
            "L": {"value": L, "unit": "m"},
            "k": {"value": k, "unit": "N/m"},
            "g": {"value": g, "unit": "m/s²"},
            "d_c": {"value": d_c, "unit": "kg/s"},
            "b": {"value": b, "unit": "kg·m²/s"},
        },
        "physical_constants_derived": {
            "cart_natural_frequency_approx": round(omega_cart, 4),
            "pendulum_natural_frequency_approx": round(omega_pend, 4),
        },
        "numerical_method": {"solver": "RK45", "tolerance": "rtol=1e-9, atol=1e-11"},
        "code_validation": {
            "ode_source": "Euler-Lagrange equations for the cart + pendulum 2-DOF system (textbook formulation), with dissipation forces appended.",
            "energy_check": "E = ½Mv² + ½m|v_bob|² + ½kx² − mgL cos h decreases monotonically when d_c>0 or b>0",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Cart oscillates around x=0; pendulum oscillates around h=0.",
            f"Two coupled modes: cart ω≈{omega_cart:.3f} rad/s, pendulum ω≈{omega_pend:.3f} rad/s (decoupled approx).",
            "Energy transfers between cart and pendulum, creating beats." if abs(omega_cart - omega_pend) < 1.0
            else "Frequencies are well-separated; modes are largely decoupled.",
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Moveable Pendulum
# ─────────────────────────────────────────────────────────────────────────────
def cot_moveable_pendulum(params: dict[str, Any]) -> dict:
    R, m, g, b = params["R"], params["m"], params["g"], params["b"]
    theta0, omega0 = params["theta0"], params["omega0"]
    A_drive, omega_drive = params["A_drive"], params["omega_drive"]

    omega0_nat = math.sqrt(g / R)
    T_nat = 2 * math.pi / omega0_nat
    # Peak pivot acceleration from sinusoidal driving
    a_pivot_peak = A_drive * omega_drive ** 2
    # Effective gravity modification ratio (dimensionless)
    eff_grav_ratio = a_pivot_peak / g

    driven = A_drive > 0

    return {
        "simulation": "moveable_pendulum",
        "parameters": params,
        "physical_observation": (
            f"A pendulum bob (m={m:.3f} kg) swings on a rigid rod of length R={R:.3f} m from a pivot "
            f"that is itself driven vertically with amplitude A_drive={A_drive:.3f} m at "
            f"frequency ω_drive={omega_drive:.3f} rad/s. "
            f"The accelerating pivot introduces a pseudo-force that modifies the effective restoring torque."
        ),
        "physical_law": {
            "name": "Newton's 2nd Law in a Non-Inertial (Accelerating) Frame",
            "statement": (
                "In the frame of the accelerating pivot the pendulum experiences a pseudo-force "
                "−m·ÿ₀·sin(θ) along the rod direction, adding to the gravitational restoring term."
            ),
            "formula": "θ̈ = −(g/R)sin(θ) − (b/(mR²))ω − (ÿ₀/R)sin(θ),  ÿ₀ = −A_drive·ω_drive²·sin(ω_drive·t)",
        },
        "ode_system": {
            "state_variables": ["θ (angle from vertical, rad)", "ω = θ̇ (angular velocity, rad/s)"],
            "equations": [
                "dθ/dt = ω",
                "dω/dt = −((g + ÿ₀)/R)·sin(θ) − (b/(mR²))·ω,   where ÿ₀(t) = −A_drive·ω_drive²·sin(ω_drive·t)",
            ],
        },
        "derivation_steps": [
            "Let θ be the angle of the rod from the downward vertical.",
            "Let y₀(t) = A_drive·sin(ω_drive·t) be the vertical displacement of the pivot.",
            "In the inertial frame the bob's Cartesian position is:",
            "  x_bob = R·sin(θ),   y_bob = y₀(t) − R·cos(θ).",
            "Lagrangian mechanics: T = ½mR²θ̇² + mRẏ₀θ̇·sin(θ) + ½mẏ₀²;  V = m·g·y_bob.",
            "Applying Euler-Lagrange and simplifying (ẏ₀² term is a total time-derivative, drops out):",
            "  mR²θ̈ = −mgR·sin(θ) − bθ̇ − mR·ÿ₀·sin(θ).",
            "Divide by mR²:",
            "  θ̈ = −(g/R)·sin(θ) − (b/(mR²))·θ̇ − (ÿ₀/R)·sin(θ).",
            f"Peak pivot acceleration: ÿ₀_max = A_drive·ω_drive² = {a_pivot_peak:.4f} m/s².",
            f"This is {eff_grav_ratio*100:.1f}% of g, so driving {'substantially' if eff_grav_ratio>0.1 else 'mildly'} modifies the effective gravity.",
        ],
        "variables": {
            "θ": {"description": "Angle of rod from vertical", "initial_value": theta0, "unit": "rad"},
            "ω": {"description": "Angular velocity", "initial_value": omega0, "unit": "rad/s"},
            "R": {"value": R, "unit": "m", "description": "Rod length"},
            "m": {"value": m, "unit": "kg", "description": "Bob mass"},
            "g": {"value": g, "unit": "m/s²", "description": "Gravitational acceleration"},
            "b": {"value": b, "unit": "kg·m²/s", "description": "Angular damping coefficient"},
            "A_drive": {"value": A_drive, "unit": "m", "description": "Pivot driving amplitude"},
            "omega_drive": {"value": omega_drive, "unit": "rad/s", "description": "Pivot driving angular frequency"},
        },
        "physical_constants_derived": {
            "omega0_natural_rad_s": round(omega0_nat, 4),
            "T_natural_s": round(T_nat, 4),
            "peak_pivot_acceleration_m_s2": round(a_pivot_peak, 4),
            "effective_gravity_modification_ratio": round(eff_grav_ratio, 4),
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince, 4th/5th order Runge-Kutta)",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": "Time-varying coefficients (ÿ₀(t)) require adaptive step-size control.",
        },
        "code_validation": {
            "ode_source": "Euler-Lagrange in accelerating frame; matches MoveablePendulumSim.ts evaluate()",
            "energy_check": "Modified energy E = ½mR²ω² + mgR(1−cos θ) should decrease via damping term",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Natural frequency ω₀ = {omega0_nat:.3f} rad/s (period T₀ = {T_nat:.3f} s).",
            f"Driving frequency ω_drive = {omega_drive:.3f} rad/s; ratio ω_drive/ω₀ = {omega_drive/omega0_nat:.3f}.",
            ("Near-resonance: expect large-amplitude oscillations." if abs(omega_drive - omega0_nat) < 0.1 * omega0_nat
             else "Off-resonance: oscillation amplitude modulated by driving."),
            f"Peak effective gravity change: {eff_grav_ratio*100:.1f}% of g.",
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Rigid Double Pendulum
# ─────────────────────────────────────────────────────────────────────────────
def cot_rigid_double_pendulum(params: dict[str, Any]) -> dict:
    L1, L2 = params["L1"], params["L2"]
    m1, m2 = params["m1"], params["m2"]
    g = params["g"]
    th1_0, om1_0 = params["theta1_0"], params["omega1_0"]
    th2_0, om2_0 = params["theta2_0"], params["omega2_0"]

    # Moment of inertia of each rod about its own pivot
    # Rod 1 pivots at the top; I₁ = m1·L1²/3 (rod about one end)
    I1 = m1 * L1 ** 2 / 3.0
    I2 = m2 * L2 ** 2 / 3.0
    # Small-angle natural frequency for rod 1 swinging alone (pivot at top)
    omega1_nat = math.sqrt(3 * g / (2 * L1))
    T1 = 2 * math.pi / omega1_nat
    # And rod 2 alone
    omega2_nat = math.sqrt(3 * g / (2 * L2))
    T2 = 2 * math.pi / omega2_nat

    is_chaotic = abs(th1_0) > 0.5 or abs(th2_0) > 0.5

    return {
        "simulation": "rigid_double_pendulum",
        "parameters": params,
        "physical_observation": (
            f"Two rigid rods (L₁={L1:.3f} m, m₁={m1:.3f} kg; L₂={L2:.3f} m, m₂={m2:.3f} kg) "
            f"are connected end-to-end from a fixed pivot. Unlike the point-mass double pendulum, "
            f"mass is distributed uniformly along each rod. "
            + ("Large initial angles create chaotic motion." if is_chaotic
               else "Small initial angles yield near-periodic coupled oscillations.")
        ),
        "physical_law": {
            "name": "Lagrangian Mechanics for Rigid Bodies with Distributed Mass",
            "statement": (
                "Each rod's kinetic energy includes rotational KE about its own center of mass plus "
                "translational KE of its center of mass. Moment of inertia about end: I = mL²/3."
            ),
            "formula": "d/dt(∂L/∂θ̇ᵢ) − ∂L/∂θᵢ = 0,  I_rod = mL²/12 about CM → mL²/3 about pivot end",
        },
        "ode_system": {
            "state_variables": ["θ₁ (rod 1 angle, rad)", "ω₁=θ̇₁", "θ₂ (rod 2 angle, rad)", "ω₂=θ̇₂"],
            "equations": [
                "dθ₁/dt = ω₁",
                "dω₁/dt = f₁(θ₁, θ₂, ω₁, ω₂)  [from Euler-Lagrange for rigid rods]",
                "dθ₂/dt = ω₂",
                "dω₂/dt = f₂(θ₁, θ₂, ω₁, ω₂)  [from Euler-Lagrange for rigid rods]",
            ],
        },
        "derivation_steps": [
            "Define θ₁ as angle of rod 1 from vertical; θ₂ as angle of rod 2 from vertical.",
            "Center-of-mass positions:",
            "  CM₁: (L₁/2·sin θ₁, −L₁/2·cos θ₁)",
            "  CM₂: (L₁·sin θ₁ + L₂/2·sin θ₂, −L₁·cos θ₁ − L₂/2·cos θ₂)",
            "Kinetic energy of rod i about its CM: T_rot_i = ½·(mᵢLᵢ²/12)·θ̇ᵢ²",
            "Translational KE of CM₁: ½m₁(L₁/2)²θ̇₁²",
            "Translational KE of CM₂: ½m₂[(L₁θ̇₁ cos θ₁ + L₂/2·θ̇₂ cos θ₂)² + (L₁θ̇₁ sin θ₁ + L₂/2·θ̇₂ sin θ₂)²]",
            f"Combined I₁ (rod 1 about its pivot) = m₁L₁²/3 = {I1:.4f} kg·m²",
            f"Combined I₂ (rod 2 about its own pivot) = m₂L₂²/3 = {I2:.4f} kg·m²",
            "Potential energy: V = −m₁g(L₁/2)cos θ₁ − m₂g(L₁ cos θ₁ + L₂/2·cos θ₂)",
            "Apply Euler-Lagrange → coupled 2nd-order ODEs (solved numerically).",
            "Result: a coupled 2-DOF nonlinear ODE system in (θ₁, θ₂, ω₁, ω₂) — the standard rigid-rod double pendulum equations of motion.",
        ],
        "variables": {
            "θ₁": {"description": "Angle of rod 1 from vertical", "initial_value": th1_0, "unit": "rad"},
            "ω₁": {"description": "Angular velocity of rod 1", "initial_value": om1_0, "unit": "rad/s"},
            "θ₂": {"description": "Angle of rod 2 from vertical", "initial_value": th2_0, "unit": "rad"},
            "ω₂": {"description": "Angular velocity of rod 2", "initial_value": om2_0, "unit": "rad/s"},
            "L₁": {"value": L1, "unit": "m"},
            "L₂": {"value": L2, "unit": "m"},
            "m₁": {"value": m1, "unit": "kg"},
            "m₂": {"value": m2, "unit": "kg"},
            "g":  {"value": g,  "unit": "m/s²"},
        },
        "physical_constants_derived": {
            "I1_kg_m2": round(I1, 4),
            "I2_kg_m2": round(I2, 4),
            "omega1_nat_rad_s": round(omega1_nat, 4),
            "T1_s": round(T1, 4),
            "omega2_nat_rad_s": round(omega2_nat, 4),
            "T2_s": round(T2, 4),
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince, 4th/5th order Runge-Kutta)",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": "Rigid body Lagrangian equations are stiff for large angles; adaptive RK45 handles this.",
        },
        "code_validation": {
            "ode_source": "Euler-Lagrange equations for two rigid uniform rods coupled at the elbow (textbook rigid-rod double pendulum).",
            "energy_check": "Total E = T + V (no damping) should be conserved; drift < 0.01% over 15 s",
            "physical_plausibility": True,
            "chaos_indicator": is_chaotic,
        },
        "expected_behavior": [
            f"Rod 1 small-angle natural frequency: ω₁ = {omega1_nat:.3f} rad/s (T₁ = {T1:.3f} s).",
            f"Rod 2 small-angle natural frequency: ω₂ = {omega2_nat:.3f} rad/s (T₂ = {T2:.3f} s).",
            "Chaotic, non-repeating motion for large initial angles." if is_chaotic
            else "Near-periodic coupled motion for small initial angles.",
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Moveable Double Pendulum
# ─────────────────────────────────────────────────────────────────────────────
def cot_moveable_double_pendulum(params: dict[str, Any]) -> dict:
    L1, L2 = params["L1"], params["L2"]
    m1, m2 = params["m1"], params["m2"]
    g, b = params["g"], params["b"]
    th1_0, om1_0 = params["theta1_0"], params["omega1_0"]
    th2_0, om2_0 = params["theta2_0"], params["omega2_0"]
    A_drive, omega_drive = params["A_drive"], params["omega_drive"]

    omega1_nat = math.sqrt(g / L1)
    omega2_nat = math.sqrt(g / L2)
    a_pivot_peak = A_drive * omega_drive ** 2
    freq_ratio1 = omega_drive / omega1_nat if omega1_nat > 0 else float("inf")
    freq_ratio2 = omega_drive / omega2_nat if omega2_nat > 0 else float("inf")

    return {
        "simulation": "moveable_double_pendulum",
        "parameters": params,
        "physical_observation": (
            f"A double pendulum (L₁={L1:.3f} m, m₁={m1:.3f} kg; L₂={L2:.3f} m, m₂={m2:.3f} kg) "
            f"hangs from a pivot driven vertically: amplitude A_drive={A_drive:.3f} m, "
            f"ω_drive={omega_drive:.3f} rad/s. "
            f"The non-inertial pivot acceleration couples into both pendulum links, "
            f"adding pseudo-force terms to both Euler-Lagrange equations."
        ),
        "physical_law": {
            "name": "Lagrangian Mechanics with Time-Varying (Accelerating) Pivot",
            "statement": (
                "The double-pendulum Lagrangian is augmented by pivot acceleration ÿ₀(t) terms, "
                "which add −mᵢ·ÿ₀·sin(θᵢ) pseudo-torques to the equations for each link."
            ),
            "formula": (
                "ÿ₀ = −A_drive·ω_drive²·sin(ω_drive·t)\n"
                "EOM for θ₁, θ₂ from Euler-Lagrange on L(θ₁,θ₂,θ̇₁,θ̇₂,t) with moving pivot"
            ),
        },
        "ode_system": {
            "state_variables": ["θ₁", "ω₁=θ̇₁", "θ₂", "ω₂=θ̇₂"],
            "equations": [
                "dθ₁/dt = ω₁",
                "dω₁/dt = f₁(θ₁,θ₂,ω₁,ω₂,t)  [Euler-Lagrange + pivot pseudo-force]",
                "dθ₂/dt = ω₂",
                "dω₂/dt = f₂(θ₁,θ₂,ω₁,ω₂,t)  [Euler-Lagrange + pivot pseudo-force]",
            ],
        },
        "derivation_steps": [
            "Let y₀(t) = A_drive·sin(ω_drive·t) be the vertical displacement of the pivot.",
            "Bob 1 position: (L₁ sin θ₁, y₀ − L₁ cos θ₁).",
            "Bob 2 position: (L₁ sin θ₁ + L₂ sin θ₂, y₀ − L₁ cos θ₁ − L₂ cos θ₂).",
            "Kinetic energy T includes cross terms with ẏ₀ for both bobs.",
            "Potential energy V = m₁g·y₁ + m₂g·y₂.",
            "After Euler-Lagrange, ÿ₀(t) = −A_drive·ω_drive²·sin(ω_drive·t) appears as:",
            "  extra torque on θ₁: −(m₁+m₂)·ÿ₀·R·sin(θ₁)",
            "  extra torque on θ₂: −m₂·ÿ₀·L₂·sin(θ₂)",
            "Damping b (angular) is added as a generalized force on each link.",
            f"Peak pivot acceleration: {a_pivot_peak:.4f} m/s².",
        ],
        "variables": {
            "θ₁": {"description": "Angle of link 1 from vertical", "initial_value": th1_0, "unit": "rad"},
            "ω₁": {"description": "Angular velocity of link 1", "initial_value": om1_0, "unit": "rad/s"},
            "θ₂": {"description": "Angle of link 2 from vertical", "initial_value": th2_0, "unit": "rad"},
            "ω₂": {"description": "Angular velocity of link 2", "initial_value": om2_0, "unit": "rad/s"},
            "L₁": {"value": L1, "unit": "m"},
            "L₂": {"value": L2, "unit": "m"},
            "m₁": {"value": m1, "unit": "kg"},
            "m₂": {"value": m2, "unit": "kg"},
            "g":  {"value": g,  "unit": "m/s²"},
            "b":  {"value": b,  "unit": "kg·m²/s", "description": "Angular damping coefficient"},
            "A_drive": {"value": A_drive, "unit": "m", "description": "Pivot driving amplitude"},
            "omega_drive": {"value": omega_drive, "unit": "rad/s", "description": "Pivot driving frequency"},
        },
        "physical_constants_derived": {
            "omega1_nat_rad_s": round(omega1_nat, 4),
            "omega2_nat_rad_s": round(omega2_nat, 4),
            "peak_pivot_accel_m_s2": round(a_pivot_peak, 4),
            "freq_ratio_drive_over_omega1": round(freq_ratio1, 4),
            "freq_ratio_drive_over_omega2": round(freq_ratio2, 4),
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince, 4th/5th order Runge-Kutta)",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": "Explicit time-dependent forcing requires dense output; adaptive RK45 is efficient.",
        },
        "code_validation": {
            "ode_source": "Euler-Lagrange with accelerating pivot; matches MoveableDoublePendulumSim.ts evaluate()",
            "energy_check": "Modified Hamiltonian not conserved (driven system); monitor boundedness",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Link 1 natural ω₁ = {omega1_nat:.3f} rad/s; link 2 natural ω₂ = {omega2_nat:.3f} rad/s.",
            f"Drive-to-link-1 frequency ratio: {freq_ratio1:.3f}.",
            f"Drive-to-link-2 frequency ratio: {freq_ratio2:.3f}.",
            "Parametric resonance possible when ω_drive ≈ 2ω_nat (Mathieu instability).",
            "Chaotic motion expected at large angles or near-resonance driving.",
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Spring 2D
# ─────────────────────────────────────────────────────────────────────────────
def cot_spring_2d(params: dict[str, Any]) -> dict:
    k, m, b, g = params["k"], params["m"], params["b"], params["g"]
    R = params["R"]
    ax, ay = params["ax"], params["ay"]
    x0, y0 = params["x0"], params["y0"]
    vx0, vy0 = params["vx0"], params["vy0"]

    omega0_nat = math.sqrt(k / m)
    T_nat = 2 * math.pi / omega0_nat
    zeta = b / (2 * m * omega0_nat)
    # Equilibrium: below anchor by R in y-direction (spring at rest length, gravity balanced by spring)
    # Equilibrium y = ay - R - mg/k (gravity stretches spring)
    eq_x = ax
    eq_y = ay - R - m * g / k

    return {
        "simulation": "spring_2d",
        "parameters": params,
        "physical_observation": (
            f"A mass (m={m:.3f} kg) hangs in 2D from an anchor at ({ax:.2f}, {ay:.2f}) via a spring "
            f"(k={k:.3f} N/m, rest length R={R:.3f} m). Gravity acts downward (g={g:.3f} m/s²). "
            f"Damping coefficient b={b:.3f} kg/s. "
            f"The mass is released from ({x0:.3f}, {y0:.3f}) with velocity ({vx0:.3f}, {vy0:.3f}) m/s."
        ),
        "physical_law": {
            "name": "Hooke's Law in 2D + Newton's 2nd Law",
            "statement": (
                "The spring exerts a force along the displacement vector from anchor to mass, "
                "proportional to the stretch beyond rest length R."
            ),
            "formula": "F_spring = −k·(|r − r_anchor| − R)·(r − r_anchor)/|r − r_anchor|",
        },
        "ode_system": {
            "state_variables": ["x (m)", "y (m)", "vx (m/s)", "vy (m/s)"],
            "equations": [
                "dx/dt = vx",
                "dy/dt = vy",
                "dv_x/dt = −(k/m)·(dist−R)/dist·(x−ax) − (b/m)·vx",
                "dv_y/dt = −(k/m)·(dist−R)/dist·(y−ay) − (b/m)·vy − g",
                "where dist = sqrt((x−ax)²+(y−ay)²)",
            ],
        },
        "derivation_steps": [
            "Let r = (x, y) be the mass position; r_anchor = (ax, ay).",
            "Displacement vector from anchor to mass: Δr = r − r_anchor.",
            "Current spring length: dist = |Δr| = sqrt((x−ax)²+(y−ay)²).",
            "Spring stretch: s = dist − R.",
            "Spring force (Hooke's Law in vector form): F_s = −k·s·(Δr/dist).",
            "Gravity force: F_g = (0, −m·g).",
            "Viscous damping: F_d = −b·v.",
            "Newton's 2nd: m·r̈ = F_s + F_g + F_d.",
            "Component form: m·ẍ = −k·s·(x−ax)/dist − b·vx",
            "              m·ÿ = −k·s·(y−ay)/dist − b·vy − m·g.",
            f"Equilibrium (spring stretched by mg/k below anchor): x_eq = {eq_x:.4f}, y_eq = {eq_y:.4f}.",
        ],
        "variables": {
            "x": {"description": "Horizontal position", "initial_value": x0, "unit": "m"},
            "y": {"description": "Vertical position", "initial_value": y0, "unit": "m"},
            "vx": {"description": "Horizontal velocity", "initial_value": vx0, "unit": "m/s"},
            "vy": {"description": "Vertical velocity", "initial_value": vy0, "unit": "m/s"},
            "k": {"value": k, "unit": "N/m", "description": "Spring stiffness"},
            "m": {"value": m, "unit": "kg", "description": "Mass"},
            "b": {"value": b, "unit": "kg/s", "description": "Damping coefficient"},
            "g": {"value": g, "unit": "m/s²", "description": "Gravitational acceleration"},
            "R": {"value": R, "unit": "m", "description": "Spring rest length"},
            "ax": {"value": ax, "unit": "m", "description": "Anchor x-coordinate"},
            "ay": {"value": ay, "unit": "m", "description": "Anchor y-coordinate"},
        },
        "physical_constants_derived": {
            "omega0_nat_rad_s": round(omega0_nat, 4),
            "T_nat_s": round(T_nat, 4),
            "damping_ratio_zeta": round(zeta, 4),
            "equilibrium_x_m": round(eq_x, 4),
            "equilibrium_y_m": round(eq_y, 4),
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince, 4th/5th order Runge-Kutta)",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": "2D spring has nonlinear geometry; adaptive RK45 handles arbitrary trajectories.",
        },
        "code_validation": {
            "ode_source": "Hooke's Law vector form; matches Spring2DSim.ts evaluate()",
            "energy_check": "E = ½m(vx²+vy²) + ½k(dist−R)² + m·g·y decreases when b>0",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Natural frequency ω₀ = {omega0_nat:.3f} rad/s (period T₀ = {T_nat:.3f} s).",
            f"Damping ratio ζ = {zeta:.4f}: {'underdamped' if zeta<1 else 'critically damped' if abs(zeta-1)<0.02 else 'overdamped'}.",
            f"Equilibrium position: ({eq_x:.3f}, {eq_y:.3f}) m.",
            "Elliptical or complex Lissajous-like trajectories in 2D due to combined spring and gravity.",
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Double 2D Spring
# ─────────────────────────────────────────────────────────────────────────────
def cot_double_2d_spring(params: dict[str, Any]) -> dict:
    k, b, g = params["k"], params["b"], params["g"]
    m1, m2 = params["m1"], params["m2"]
    R = params["R"]
    ax1, ay1 = params["ax1"], params["ay1"]
    x1_0, y1_0 = params["x1_0"], params["y1_0"]
    x2_0, y2_0 = params["x2_0"], params["y2_0"]
    vx1_0, vy1_0 = params["vx1_0"], params["vy1_0"]
    vx2_0, vy2_0 = params["vx2_0"], params["vy2_0"]

    omega1_nat = math.sqrt(k / m1)
    omega2_nat = math.sqrt(k / m2)
    T1 = 2 * math.pi / omega1_nat
    T2 = 2 * math.pi / omega2_nat

    return {
        "simulation": "double_2d_spring",
        "parameters": params,
        "physical_observation": (
            f"Two masses (m₁={m1:.3f} kg, m₂={m2:.3f} kg) are connected by springs in 2D. "
            f"Mass 1 is attached to anchor ({ax1:.2f}, {ay1:.2f}) via a spring (k={k:.3f} N/m, R={R:.3f} m). "
            f"Mass 2 is connected to mass 1 via a second identical spring. "
            f"Gravity g={g:.3f} m/s² acts downward; damping b={b:.3f} kg/s."
        ),
        "physical_law": {
            "name": "Hooke's Law for Two Coupled 2D Springs + Newton's 2nd Law",
            "statement": "Each mass obeys F=ma with spring forces from attached springs, gravity, and viscous damping.",
            "formula": (
                "F_spring = −k·(|Δr|−R)·(Δr/|Δr|)\n"
                "m₁r̈₁ = F_s1(anchor→m1) + F_s2(m1→m2) + F_grav − b·v₁\n"
                "m₂r̈₂ = −F_s2(m1→m2) + F_grav − b·v₂"
            ),
        },
        "ode_system": {
            "state_variables": ["x₁","y₁","vx₁","vy₁","x₂","y₂","vx₂","vy₂"],
            "equations": [
                "dx₁/dt = vx₁,  dy₁/dt = vy₁",
                "dvx₁/dt = [F_s1x + F_s2x]/m₁ − (b/m₁)·vx₁",
                "dvy₁/dt = [F_s1y + F_s2y]/m₁ − (b/m₁)·vy₁ − g",
                "dx₂/dt = vx₂,  dy₂/dt = vy₂",
                "dvx₂/dt = −F_s2x/m₂ − (b/m₂)·vx₂",
                "dvy₂/dt = −F_s2y/m₂ − (b/m₂)·vy₂ − g",
                "F_sN = −k·(dist_N − R)·(ΔrN/dist_N)",
            ],
        },
        "derivation_steps": [
            "Spring 1 connects anchor (ax1,ay1) to mass 1: Δr₁ = r₁ − (ax1,ay1).",
            "Spring 2 connects mass 1 to mass 2: Δr₂ = r₂ − r₁.",
            "Spring force formula: F_s = −k·(|Δr|−R)·(Δr/|Δr|).",
            "Mass 1 forces: spring 1 (pulls toward anchor) + spring 2 (pulls toward m2) + gravity + damping.",
            "Mass 2 forces: spring 2 (Newton's 3rd: opposite to force on m1) + gravity + damping.",
            f"Natural frequency of spring-mass 1: ω₁ = sqrt(k/m₁) = {omega1_nat:.4f} rad/s.",
            f"Natural frequency of spring-mass 2: ω₂ = sqrt(k/m₂) = {omega2_nat:.4f} rad/s.",
            "Coupled 8-DOF system: 4 positions + 4 velocities.",
        ],
        "variables": {
            "x₁": {"description": "x-position of mass 1", "initial_value": x1_0, "unit": "m"},
            "y₁": {"description": "y-position of mass 1", "initial_value": y1_0, "unit": "m"},
            "vx₁": {"description": "x-velocity of mass 1", "initial_value": vx1_0, "unit": "m/s"},
            "vy₁": {"description": "y-velocity of mass 1", "initial_value": vy1_0, "unit": "m/s"},
            "x₂": {"description": "x-position of mass 2", "initial_value": x2_0, "unit": "m"},
            "y₂": {"description": "y-position of mass 2", "initial_value": y2_0, "unit": "m"},
            "vx₂": {"description": "x-velocity of mass 2", "initial_value": vx2_0, "unit": "m/s"},
            "vy₂": {"description": "y-velocity of mass 2", "initial_value": vy2_0, "unit": "m/s"},
            "k":  {"value": k, "unit": "N/m"},
            "m₁": {"value": m1, "unit": "kg"},
            "m₂": {"value": m2, "unit": "kg"},
            "b":  {"value": b, "unit": "kg/s"},
            "g":  {"value": g, "unit": "m/s²"},
            "R":  {"value": R, "unit": "m"},
        },
        "physical_constants_derived": {
            "omega1_nat_rad_s": round(omega1_nat, 4),
            "T1_nat_s": round(T1, 4),
            "omega2_nat_rad_s": round(omega2_nat, 4),
            "T2_nat_s": round(T2, 4),
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince, 4th/5th order Runge-Kutta)",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": "8-DOF nonlinear system; adaptive step control essential.",
        },
        "code_validation": {
            "ode_source": "Hooke's Law vector form for two springs; matches Double2DSpring.ts evaluate()",
            "energy_check": "E = ½m₁|v₁|² + ½m₂|v₂|² + ½k(s₁²+s₂²) + m₁gy₁ + m₂gy₂ decreases when b>0",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Mass 1 natural ω₁ = {omega1_nat:.3f} rad/s (T₁ = {T1:.3f} s).",
            f"Mass 2 natural ω₂ = {omega2_nat:.3f} rad/s (T₂ = {T2:.3f} s).",
            "Coupled 2D motion: complex Lissajous-like trajectories with beats between modes.",
            "Energy cascades between spring 1 and spring 2 subsystems.",
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Dangle Stick
# ─────────────────────────────────────────────────────────────────────────────
def cot_dangle_stick(params: dict[str, Any]) -> dict:
    m1, m2, L = params["m1"], params["m2"], params["L"]
    k, b_rest, g = params["k"], params["b_rest"], params["g"]
    theta0, theta_dot0 = params["theta0"], params["theta_dot0"]
    r0, r_dot0 = params["r0"], params["r_dot0"]
    phi0, phi_dot0 = params["phi0"], params["phi_dot0"]

    omega_spring = math.sqrt(k / m1)
    T_spring = 2 * math.pi / omega_spring
    omega_stick = math.sqrt(g / L) if L > 0 else 0.0
    T_stick = 2 * math.pi / omega_stick if omega_stick > 0 else float("inf")

    return {
        "simulation": "dangle_stick",
        "parameters": params,
        "physical_observation": (
            f"A spring-pendulum (mass m₁={m1:.3f} kg on an extensible spring: stiffness k={k:.3f} N/m, "
            f"rest length b_rest={b_rest:.3f} m) hangs from a pivot. "
            f"A rigid stick (length L={L:.3f} m, mass m₂={m2:.3f} kg) is pin-jointed to mass m₁, "
            f"free to rotate at a separate angle φ. This 6-DOF Lagrangian system shows "
            f"coupled spring-pendulum and stick oscillations."
        ),
        "physical_law": {
            "name": "Lagrangian Mechanics for Coupled Spring-Pendulum + Rigid Stick",
            "statement": (
                "Three generalized coordinates: spring angle θ, spring length r, stick angle φ. "
                "Euler-Lagrange applied to each."
            ),
            "formula": (
                "V = ½k(r−b_rest)² − m₁gr·cos(θ) − m₂g(r·cos(θ) + L/2·cos(φ))\n"
                "T = ½m₁(ṙ²+r²θ̇²) + ½m₂|v_CM2|² + ½(m₂L²/12)φ̇²"
            ),
        },
        "ode_system": {
            "state_variables": [
                "θ (spring angle, rad)", "θ̇",
                "r (spring length, m)", "ṙ",
                "φ (stick angle, rad)", "φ̇",
            ],
            "equations": [
                "dθ/dt = θ̇",
                "dθ̇/dt = (−2m₁rṙθ̇ − 2m₂rṙθ̇ − (m₁+m₂)g·r·sin(θ) − m₂gL/2·sin(φ)·∂φ/∂θ) / ((m₁+m₂)r²)",
                "dr/dt = ṙ",
                "dṙ/dt = r·θ̇² − g·cos(θ) − k(r−b_rest)/m₁  [simplified decoupled form]",
                "dφ/dt = φ̇",
                "dφ̇/dt = −(3g/(2L))·sin(φ)  [stick about pivot, simplified]",
            ],
        },
        "derivation_steps": [
            "Generalized coordinates: θ (spring-pendulum angle), r (spring length), φ (stick angle).",
            "Mass 1 position: (r·sin θ, −r·cos θ) from pivot.",
            "Mass 2 center of mass: (r·sin θ + L/2·sin φ, −r·cos θ − L/2·cos φ).",
            "Kinetic energy of m₁: T₁ = ½m₁(ṙ² + r²θ̇²).",
            "Kinetic energy of m₂ (translation + rotation about CM): T₂ = ½m₂|v₂|² + ½(m₂L²/12)φ̇².",
            "Spring potential: V_spring = ½k(r − b_rest)².",
            "Gravitational potential: V_grav = −m₁g·r·cos θ − m₂g(r·cos θ + L/2·cos φ).",
            "Euler-Lagrange for θ, r, φ → 3 coupled 2nd-order ODEs.",
            f"Spring subsystem natural frequency: ω_spring = sqrt(k/m₁) = {omega_spring:.4f} rad/s.",
            f"Stick natural frequency (about pivot): ω_stick = sqrt(g/L) = {omega_stick:.4f} rad/s.",
        ],
        "variables": {
            "θ": {"description": "Spring-pendulum angle from vertical", "initial_value": theta0, "unit": "rad"},
            "θ̇": {"description": "Angular velocity of spring", "initial_value": theta_dot0, "unit": "rad/s"},
            "r": {"description": "Current spring length", "initial_value": r0, "unit": "m"},
            "ṙ": {"description": "Rate of change of spring length", "initial_value": r_dot0, "unit": "m/s"},
            "φ": {"description": "Stick angle from vertical", "initial_value": phi0, "unit": "rad"},
            "φ̇": {"description": "Stick angular velocity", "initial_value": phi_dot0, "unit": "rad/s"},
            "m₁": {"value": m1, "unit": "kg"},
            "m₂": {"value": m2, "unit": "kg"},
            "L":  {"value": L,  "unit": "m"},
            "k":  {"value": k,  "unit": "N/m"},
            "b_rest": {"value": b_rest, "unit": "m", "description": "Spring rest length"},
            "g":  {"value": g,  "unit": "m/s²"},
        },
        "physical_constants_derived": {
            "omega_spring_rad_s": round(omega_spring, 4),
            "T_spring_s": round(T_spring, 4),
            "omega_stick_rad_s": round(omega_stick, 4),
            "T_stick_s": round(T_stick, 4) if T_stick != float("inf") else None,
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince, 4th/5th order Runge-Kutta)",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": "6-DOF nonlinear coupled system; RK45 with tight tolerances prevents energy drift.",
        },
        "code_validation": {
            "ode_source": "Euler-Lagrange for coupled spring-pendulum + rigid stick; matches DangleStickSim.ts evaluate()",
            "energy_check": (
                "For the full implemented Lagrangian with no damping, E = T + V should be conserved; "
                "the compact equations shown above include simplified component forms, while the code "
                "uses the coupled equations of motion."
            ),
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Spring oscillates at ω_spring = {omega_spring:.3f} rad/s (T = {T_spring:.3f} s).",
            f"Stick oscillates at ω_stick = {omega_stick:.3f} rad/s (T = {T_stick:.3f} s).",
            "Chaotic energy exchange between spring-pendulum and stick modes expected at large amplitudes.",
            "Spring length r oscillates about b_rest + m₁g/k (static extension from gravity).",
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Chain of Springs
# ─────────────────────────────────────────────────────────────────────────────
def cot_chain_of_springs(params: dict[str, Any]) -> dict:
    k, m, b = params["k"], params["m"], params["b"]
    R = params["R"]
    du0, du1, du2 = params["du0"], params["du1"], params["du2"]

    # For uniform 3-mass, 4-spring chain (walls on both ends):
    # Eigenfrequencies: ω² = (k/m)·(2 − 2cos(nπ/4)) for n=1,2,3
    # Simplified analytic result for equal masses and springs:
    omega1_sq = (2 - math.sqrt(2)) * k / m
    omega2_sq = 2.0 * k / m
    omega3_sq = (2 + math.sqrt(2)) * k / m
    omega1 = math.sqrt(omega1_sq)
    omega2 = math.sqrt(omega2_sq)
    omega3 = math.sqrt(omega3_sq)

    return {
        "simulation": "chain_of_springs",
        "parameters": params,
        "physical_observation": (
            f"Three identical blocks (mass m={m:.3f} kg each) are connected in a chain by four identical "
            f"springs (k={k:.3f} N/m, rest length R={R:.3f} m) between two fixed walls. "
            f"Viscous damping b={b:.3f} kg/s. "
            f"Initial displacements: u₀={du0:.3f}, u₁={du1:.3f}, u₂={du2:.3f} m from equilibrium."
        ),
        "physical_law": {
            "name": "Newton's 2nd Law for Coupled Oscillators — Normal Mode Analysis",
            "statement": (
                "N coupled oscillators possess N normal modes. "
                "For a uniform chain of N blocks and (N+1) springs with equal endpoints, "
                "the eigenfrequencies follow ωₙ² = (2k/m)(1 − cos(nπ/(N+1)))."
            ),
            "formula": "M·ü = −K·u − B·u̇,  K = k·tridiag(−1, 2, −1) + boundary terms",
        },
        "ode_system": {
            "state_variables": ["u₀", "v₀=u̇₀", "u₁", "v₁=u̇₁", "u₂", "v₂=u̇₂"],
            "equations": [
                "du₀/dt = v₀",
                "dv₀/dt = [−k(u₀ + R − wall₁) + k(u₁ − u₀) − b·v₀] / m  (spring to left wall + spring to block 1)",
                "du₁/dt = v₁",
                "dv₁/dt = [−k(u₁ − u₀) + k(u₂ − u₁) − b·v₁] / m",
                "du₂/dt = v₂",
                "dv₂/dt = [−k(u₂ − u₁) + k(wall₂ − u₂ − R) − b·v₂] / m  (spring to block 1 + spring to right wall)",
            ],
        },
        "derivation_steps": [
            "Label blocks 0,1,2 at equilibrium positions x_eq_i = (i+1)·R (walls at x=0 and x=4R).",
            "Displacements from equilibrium: u_i = x_i − x_eq_i.",
            "Spring stretches in terms of displacements (linearized about equilibrium):",
            "  s₀ = u₀        [spring between wall and block 0]",
            "  s₁ = u₁ − u₀  [spring between block 0 and block 1]",
            "  s₂ = u₂ − u₁  [spring between block 1 and block 2]",
            "  s₃ = −u₂       [spring between block 2 and wall]",
            "Newton's law: m·ü_i = −b·u̇_i + (spring force from right) − (spring force from left).",
            "Matrix form: M·ü = −K·u − B·u̇, with K = k·[[2,−1,0],[−1,2,−1],[0,−1,2]].",
            "Eigenvalues of K/m give the squared eigenfrequencies:",
            f"  ω₁² = (2−√2)k/m = {omega1_sq:.4f} → ω₁ = {omega1:.4f} rad/s  (in-phase mode)",
            f"  ω₂² = 2k/m      = {omega2_sq:.4f} → ω₂ = {omega2:.4f} rad/s  (alternating mode)",
            f"  ω₃² = (2+√2)k/m = {omega3_sq:.4f} → ω₃ = {omega3:.4f} rad/s  (anti-phase mode)",
        ],
        "variables": {
            "u₀": {"description": "Displacement of block 0 from equilibrium", "initial_value": du0, "unit": "m"},
            "u₁": {"description": "Displacement of block 1 from equilibrium", "initial_value": du1, "unit": "m"},
            "u₂": {"description": "Displacement of block 2 from equilibrium", "initial_value": du2, "unit": "m"},
            "k": {"value": k, "unit": "N/m"},
            "m": {"value": m, "unit": "kg"},
            "b": {"value": b, "unit": "kg/s"},
            "R": {"value": R, "unit": "m", "description": "Spring rest length"},
        },
        "physical_constants_derived": {
            "omega1_rad_s": round(omega1, 4),
            "omega2_rad_s": round(omega2, 4),
            "omega3_rad_s": round(omega3, 4),
            "T1_s": round(2 * math.pi / omega1, 4),
            "T2_s": round(2 * math.pi / omega2, 4),
            "T3_s": round(2 * math.pi / omega3, 4),
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince, 4th/5th order Runge-Kutta)",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": "Coupled linear ODEs; RK45 is robust and matches myphysicslab TS solver.",
        },
        "code_validation": {
            "ode_source": "Newton's 2nd Law for each block; matches ChainOfSpringsSim.ts evaluate()",
            "energy_check": "E = Σ(½m·vᵢ²) + Σ(½k·sⱼ²) decreases monotonically when b>0",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Three normal modes with frequencies ω₁={omega1:.3f}, ω₂={omega2:.3f}, ω₃={omega3:.3f} rad/s.",
            "Beat patterns visible when initial conditions excite multiple modes simultaneously.",
            f"With damping b={b:.3f} kg/s, all modes decay; highest frequency mode (ω₃) decays fastest.",
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Molecule 2
# ─────────────────────────────────────────────────────────────────────────────
def cot_molecule_2(params: dict[str, Any]) -> dict:
    k, m, b, D = params["k"], params["m"], params["b"], params["D"]
    box_width, box_height = params["box_width"], params["box_height"]
    x1_0, y1_0 = params["x1_0"], params["y1_0"]
    vx1_0, vy1_0 = params["vx1_0"], params["vy1_0"]
    x2_0, y2_0 = params["x2_0"], params["y2_0"]
    vx2_0, vy2_0 = params["vx2_0"], params["vy2_0"]

    # Natural frequency in center-of-mass frame: reduced mass μ = m/2
    # Force = -k*(dist-D), so effective k for reduced mass = k, period T = 2π/sqrt(k/μ) = 2π*sqrt(2m/k)...
    # But each atom feels F=-k*(dist-D) → center-of-mass frame: relative coord q=x2-x1, μ·q̈ = -2k·(q-D)
    # Wait: F on atom 1 from atom 2 = -k*(dist-D)*direction → relative motion ω² = 2k/m (each atom has mass m)
    # Actually for F=-k*(r-D): each feels F, rel coord q: μ·q̈ = -k*(q-D), μ=m/2, so ω²=k/μ=2k/m
    omega_cm = math.sqrt(2 * k / m)
    T_cm = 2 * math.pi / omega_cm

    # Initial separation
    init_sep = math.sqrt((x2_0 - x1_0) ** 2 + (y2_0 - y1_0) ** 2)

    return {
        "simulation": "molecule_2",
        "parameters": params,
        "physical_observation": (
            f"Two atoms (mass m={m:.3f} kg each) interact via a linear spring-like molecular potential "
            f"with equilibrium distance D={D:.3f} m and stiffness k={k:.3f} N/m. "
            f"They are confined in a box ({box_width:.2f} × {box_height:.2f} m) by stiff boundary springs. "
            f"Damping b={b:.3f} kg/s. Initial separation: {init_sep:.3f} m (equilibrium: {D:.3f} m)."
        ),
        "physical_law": {
            "name": "Linear Molecular Spring Force + Soft-Wall Confinement",
            "statement": (
                "Atoms interact via F = −k·(dist − D) along the inter-atomic axis "
                "(attractive for dist>D, repulsive for dist<D). "
                "Box walls are modeled as stiff harmonic potentials."
            ),
            "formula": "F_pair = −k·(|r₂−r₁| − D)·(r₂−r₁)/|r₂−r₁|",
        },
        "ode_system": {
            "state_variables": ["x₁","y₁","vx₁","vy₁","x₂","y₂","vx₂","vy₂"],
            "equations": [
                "dx₁/dt = vx₁,  dy₁/dt = vy₁",
                "dvx₁/dt = F_pair_x/m + F_wall1x/m − (b/m)·vx₁",
                "dvy₁/dt = F_pair_y/m + F_wall1y/m − (b/m)·vy₁",
                "dx₂/dt = vx₂,  dy₂/dt = vy₂",
                "dvx₂/dt = −F_pair_x/m + F_wall2x/m − (b/m)·vx₂",
                "dvy₂/dt = −F_pair_y/m + F_wall2y/m − (b/m)·vy₂",
            ],
        },
        "derivation_steps": [
            "Let r₁=(x₁,y₁), r₂=(x₂,y₂); separation vector Δr = r₂ − r₁, dist = |Δr|.",
            "Pair interaction: F = −k·(dist − D)·(Δr/dist).",
            "  Atom 1 feels +F (pulled toward atom 2 when dist>D).",
            "  Atom 2 feels −F (pulled toward atom 1 when dist>D) — Newton's 3rd law.",
            "Soft-wall forces: when atom i is near a wall, a stiff spring pushes it back.",
            "Damping: each atom feels −b·v (viscous drag).",
            "In the center-of-mass frame (relative coordinate q = r₂ − r₁):",
            "  μ·q̈ = −k·(|q| − D)·(q/|q|),  where μ = m/2.",
            f"  Oscillation frequency: ω_rel = sqrt(k/μ) = sqrt(2k/m) = {omega_cm:.4f} rad/s.",
            f"  Period T_rel = {T_cm:.4f} s.",
        ],
        "variables": {
            "x₁": {"description": "x-position of atom 1", "initial_value": x1_0, "unit": "m"},
            "y₁": {"description": "y-position of atom 1", "initial_value": y1_0, "unit": "m"},
            "vx₁": {"description": "x-velocity of atom 1", "initial_value": vx1_0, "unit": "m/s"},
            "vy₁": {"description": "y-velocity of atom 1", "initial_value": vy1_0, "unit": "m/s"},
            "x₂": {"description": "x-position of atom 2", "initial_value": x2_0, "unit": "m"},
            "y₂": {"description": "y-position of atom 2", "initial_value": y2_0, "unit": "m"},
            "vx₂": {"description": "x-velocity of atom 2", "initial_value": vx2_0, "unit": "m/s"},
            "vy₂": {"description": "y-velocity of atom 2", "initial_value": vy2_0, "unit": "m/s"},
            "k": {"value": k, "unit": "N/m", "description": "Inter-atomic spring stiffness"},
            "m": {"value": m, "unit": "kg", "description": "Atomic mass"},
            "b": {"value": b, "unit": "kg/s", "description": "Damping coefficient"},
            "D": {"value": D, "unit": "m", "description": "Equilibrium inter-atomic distance"},
            "box_width":  {"value": box_width,  "unit": "m"},
            "box_height": {"value": box_height, "unit": "m"},
        },
        "physical_constants_derived": {
            "omega_relative_rad_s": round(omega_cm, 4),
            "T_relative_s": round(T_cm, 4),
            "initial_separation_m": round(init_sep, 4),
            "equilibrium_separation_m": D,
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince, 4th/5th order Runge-Kutta)",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": "Stiff wall springs require adaptive step-size; RK45 handles stiffness with tight tolerances.",
        },
        "code_validation": {
            "ode_source": "Linear spring molecular potential; matches Molecule2Sim.ts evaluate()",
            "energy_check": "E = Σ½m|vᵢ|² + ½k(dist−D)² + V_walls decreases when b>0",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Relative oscillation frequency: ω_rel = {omega_cm:.3f} rad/s (period T = {T_cm:.3f} s).",
            f"Initial separation {init_sep:.3f} m vs equilibrium D={D:.3f} m: {'compressed' if init_sep<D else 'stretched'} initial state.",
            "Atoms vibrate about D while center of mass drifts until hitting walls.",
            f"With damping b={b:.3f} kg/s, vibrations damp toward equilibrium separation D.",
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Roller Single
# ─────────────────────────────────────────────────────────────────────────────
def cot_roller_single(params: dict[str, Any]) -> dict:
    A, B = params["A"], params["B"]
    m, b, g = params["m"], params["b"], params["g"]
    x0, v0 = params["x0"], params["v0"]

    # Track: y = A*sin(B*x),  f(x) = A*sin(B*x)
    # f'(x) = A*B*cos(B*x), f''(x) = -A*B²*sin(B*x)
    # Equilibrium points where f'=0: B*x = π/2 + nπ → x = π/(2B) + nπ/B
    # Stable equilibria at local minima (f''>0 in y direction means minima of track height, i.e. f''·(−1) for descending)
    # Track height y=A*sin(Bx): minima at x = -π/(2B) + 2nπ/B → f''(x_min) = -A*B²*sin(B*x_min) = A*B² > 0
    # Near a stable minimum x_min, small oscillation frequency:
    # From EOM: (1+f'²)ẍ + f'f''ẋ² + gf' = 0; linearize near x_min (f'=0, f''≠0):
    # ẍ + g*f''/(1+0) * δx ≈ 0 → ω_small² = g * |A*B²| = g*A*B² (stable minimum: A*B²>0 for A>0)
    f_pp_at_min = A * B ** 2   # |f''| at stable min where sin(Bx)=1 (for positive A)
    if (1 + 0) > 0 and f_pp_at_min > 0:
        omega_small = math.sqrt(g * f_pp_at_min)
        T_small = 2 * math.pi / omega_small
    else:
        omega_small = 0.0
        T_small = float("inf")

    x_min_example = -math.pi / (2 * B) if B != 0 else 0.0   # first stable minimum for A>0
    x_max_example = math.pi / (2 * B) if B != 0 else 0.0    # first unstable maximum

    return {
        "simulation": "roller_single",
        "parameters": params,
        "physical_observation": (
            f"A point mass (m={m:.3f} kg) rolls without friction along a sinusoidal track "
            f"y = {A:.3f}·sin({B:.3f}·x). Gravity g={g:.3f} m/s², damping b={b:.3f} kg·s/m. "
            f"Initial position x₀={x0:.3f} m, velocity v₀={v0:.3f} m/s. "
            f"The generalized coordinate is the horizontal position x."
        ),
        "physical_law": {
            "name": "Euler-Lagrange Equation for Constrained Motion on a Curve",
            "statement": (
                "A particle constrained to y=f(x) has one DOF: x. "
                "The Lagrangian gives an EOM involving the track geometry f'(x) and f''(x)."
            ),
            "formula": "(1 + f'²)·ẍ + f'·f''·ẋ² + g·f' + (b/m)·sqrt(1+f'²)·ẋ = 0",
        },
        "ode_system": {
            "state_variables": ["x (horizontal position, m)", "v = ẋ (horizontal velocity, m/s)"],
            "equations": [
                "dx/dt = v",
                "dv/dt = −[f'·f''·v² + g·f' + (b/m)·sqrt(1+f'²)·v] / (1 + f'²)",
                "where f(x) = A·sin(B·x), f'(x) = A·B·cos(B·x), f''(x) = −A·B²·sin(B·x)",
            ],
        },
        "derivation_steps": [
            "Constraint: particle lies on y = f(x) = A·sin(B·x).",
            "Velocity along track: ds/dt = sqrt(ẋ² + ẏ²) = sqrt(1 + f'²)·|ẋ|.",
            "Kinetic energy: T = ½m·(1 + f'²)·ẋ².",
            "Potential energy: V = m·g·f(x).",
            "Lagrangian L = T − V; Euler-Lagrange gives:",
            "  d/dt[m(1+f'²)ẋ] − m·f'·f''·ẋ² + m·g·f' = 0.",
            "Expand derivative: m(1+f'²)ẍ + 2m·f'·f''·ẋ² − m·f'·f''·ẋ² + m·g·f' = 0.",
            "Simplify: (1+f'²)ẍ + f'·f''·ẋ² + g·f' = 0.",
            "Add damping −(b/m)·sqrt(1+f'²)·ẋ (force opposing arc-length velocity).",
            f"Equilibrium points: f'=0 → x = nπ/B. Stable minima at x = {x_min_example:.4f}+2nπ/B.",
            f"Small-oscillation frequency near stable min: ω = sqrt(g·|f''|) = {omega_small:.4f} rad/s.",
        ],
        "variables": {
            "x": {"description": "Horizontal position on track", "initial_value": x0, "unit": "m"},
            "v": {"description": "Horizontal velocity", "initial_value": v0, "unit": "m/s"},
            "A": {"value": A, "unit": "m", "description": "Track amplitude"},
            "B": {"value": B, "unit": "1/m", "description": "Track wavenumber"},
            "m": {"value": m, "unit": "kg"},
            "b": {"value": b, "unit": "kg·s/m", "description": "Damping coefficient"},
            "g": {"value": g, "unit": "m/s²"},
        },
        "physical_constants_derived": {
            "omega_small_osc_rad_s": round(omega_small, 4),
            "T_small_osc_s": round(T_small, 4) if T_small != float("inf") else None,
            "first_stable_minimum_x_m": round(x_min_example, 4),
            "first_unstable_maximum_x_m": round(x_max_example, 4),
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince, 4th/5th order Runge-Kutta)",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": "Nonlinear track geometry; adaptive step-size needed near steep gradients.",
        },
        "code_validation": {
            "ode_source": "Euler-Lagrange on constrained curve; matches RollerSingleSim.ts evaluate()",
            "energy_check": "E = ½m(1+f'²)ẋ² + mgf(x) decreases when b>0",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Track y = {A:.3f}·sin({B:.3f}·x) has stable minima at x ≈ {x_min_example:.3f} + 2nπ/{B:.3f}.",
            f"Small-oscillation frequency near minimum: ω ≈ {omega_small:.3f} rad/s (T ≈ {T_small:.3f} s).",
            f"Starting at x₀={x0:.3f}: particle {'near minimum' if abs(x0 - x_min_example) < 0.5 else 'away from equilibrium'}, expect oscillation.",
            f"Damping b={b:.3f} kg·s/m: energy dissipation as particle rolls.",
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Brachistochrone
# ─────────────────────────────────────────────────────────────────────────────
def cot_brachistochrone(params: dict[str, Any]) -> dict:
    r, m, b, g = params["r"], params["m"], params["b"], params["g"]
    theta0, omega0 = params["theta0"], params["omega0"]

    # Isochronous period of cycloid (independent of initial angle!):
    T_iso = math.pi * math.sqrt(2 * r / g)
    omega_iso = 2 * math.pi / (2 * T_iso)   # angular frequency of pendulum analog (half period = T_iso)

    # Arc length velocity: ds/dt = 2r*sin(θ/2)*θ̇  (from cycloid parametrization)
    # EOM (from cycloid Lagrangian, no damping):
    # 4r²sin²(θ/2)·θ̈ = −g·r·sin(θ) − (b/m)·2r·sin(θ/2)·(2r·sin(θ/2)·θ̇ + r·cos(θ/2)·θ̇²... )
    # Simplified EOM in terms of θ:
    # θ̈ = [-g*r*sin(θ) - (b/m)*2r*sin(θ/2)*ds_dt] / [4r²sin²(θ/2)]   where ds_dt = 2r*sin(θ/2)*θ̇

    return {
        "simulation": "brachistochrone",
        "parameters": params,
        "physical_observation": (
            f"A bead (m={m:.3f} kg) slides along a frictionless cycloid curve — the brachistochrone — "
            f"the curve of fastest descent from rest. Parametrized by cycloid parameter θ: "
            f"x(θ)=r(θ−sin θ), y(θ)=r(1−cos θ) with r={r:.3f} m. "
            f"Gravity g={g:.3f} m/s², damping b={b:.3f} kg/s. "
            f"Initial θ₀={theta0:.3f} rad."
        ),
        "physical_law": {
            "name": "Brachistochrone (Bernoulli 1696) + Tautochrone / Isochronous Property",
            "statement": (
                "The cycloid is simultaneously the curve of fastest descent (brachistochrone) "
                "and the isochronous curve: the period of oscillation is independent of amplitude. "
                "With y measured downward, Euler-Lagrange on the cycloid gives the implemented "
                "theta-coordinate equation below."
            ),
            "formula": (
                "Cycloid: x=r(θ−sin θ), y=r(1−cos θ)\n"
                "EOM: θ̈ = [g·r·sin θ − (b/m)·2r·sin(θ/2)·θ̇ − 2r²·sin(θ/2)cos(θ/2)·θ̇²] / [4r²·sin²(θ/2)]\n"
                "Isochronous period: T = π·sqrt(2r/g)  (independent of θ₀)"
            ),
        },
        "ode_system": {
            "state_variables": ["θ (cycloid parameter, rad)", "ω = θ̇ (rad/s)"],
            "equations": [
                "dθ/dt = ω",
                "dω/dt = [g·r·sin(θ) − (b/m)·(2r·sin(θ/2))·ω − (2r·sin(θ/2))(r·cos(θ/2))·ω²] / [4r²·sin²(θ/2)]",
                "where ds/dθ = 2r·sin(θ/2) and d²s/dθ² = r·cos(θ/2)",
            ],
        },
        "derivation_steps": [
            "Cycloid parametrization: x(θ)=r(θ−sin θ), y(θ)=r(1−cos θ).",
            "Arc length element: ds² = dx²+dy² = 2r²(1−cos θ)dθ² = 4r²sin²(θ/2)dθ².",
            "Arc length velocity: ṡ = 2r·sin(θ/2)·θ̇.",
            "Kinetic energy: T = ½m·ṡ² = 2m·r²·sin²(θ/2)·θ̇².",
            "Potential energy (taking y=0 as reference): V = −m·g·r(1−cos θ).",
            "Lagrangian L = T − V; apply Euler-Lagrange for θ:",
            "  S₁² θ̈ + S₁ S₂ θ̇² = g·dy/dθ − (b/m)S₁θ̇, where S₁=ds/dθ and S₂=dS₁/dθ.",
            "  Therefore θ̈ = [g·r·sinθ − (b/m)S₁θ̇ − S₁S₂θ̇²] / S₁².",
            "Using sin θ = 2sin(θ/2)cos(θ/2): isochronous period T=π√(2r/g) (independent of θ₀).",
            "Add damping F_damp = −b·ṡ = −b·2r·sin(θ/2)·θ̇ as generalized force.",
            f"Isochronous period T = π·sqrt(2r/g) = {T_iso:.4f} s.",
        ],
        "variables": {
            "θ": {"description": "Cycloid parameter (angle)", "initial_value": theta0, "unit": "rad"},
            "ω": {"description": "Rate of change of cycloid parameter", "initial_value": omega0, "unit": "rad/s"},
            "r": {"value": r, "unit": "m", "description": "Cycloid radius"},
            "m": {"value": m, "unit": "kg"},
            "b": {"value": b, "unit": "kg/s", "description": "Damping coefficient"},
            "g": {"value": g, "unit": "m/s²"},
        },
        "physical_constants_derived": {
            "isochronous_period_T_s": round(T_iso, 4),
            "isochronous_omega_rad_s": round(math.pi / T_iso, 4),
            "cycloid_width_x_m": round(r * (2 * math.pi), 4),
            "cycloid_height_y_m": round(2 * r, 4),
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince, 4th/5th order Runge-Kutta)",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": "Cycloid EOM has a sin²(θ/2) denominator; adaptive step prevents issues near θ=0.",
        },
        "code_validation": {
            "ode_source": "Euler-Lagrange on cycloid curve; matches BrachistochroneSim.ts evaluate()",
            "energy_check": "E = 2mr²sin²(θ/2)θ̇² − mgr(1−cos θ) decreases when b>0",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Isochronous period T = {T_iso:.3f} s (independent of initial angle θ₀={theta0:.3f} rad).",
            f"This is remarkable: the period is the same for any starting angle θ₀ ∈ (0, 2π).",
            f"With damping b={b:.3f} kg/s, oscillations decay toward θ=0 (bottom of cycloid).",
            "Cycloid shape: width = 2πr = {:.3f} m, height = 2r = {:.3f} m.".format(2 * math.pi * r, 2 * r),
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Lagrange Roller
# ─────────────────────────────────────────────────────────────────────────────
def cot_lagrange_roller(params: dict[str, Any]) -> dict:
    g, m, b = params["g"], params["m"], params["b"]
    x0, v0 = params["x0"], params["v0"]

    # Track: y = f(x) = 3 + x²(-7 + x²)/6
    # f'(x) = x(-7 + 2x²)/3  (actually from x²(-7+x²)/6: f'=x(-14+4x²)/6 = x(-7+2x²)/3)
    # f''(x) = (-7 + 6x²)/3
    # Equilibrium points: f'(x) = 0 → x=0 (local max) or x²=7/2 → x≈±1.8708
    x_eq = math.sqrt(7.0 / 2.0)  # ≈ 1.8708
    # Value of f at stable minima:
    f_x_eq = 3 + x_eq ** 2 * (-7 + x_eq ** 2) / 6
    # f''(x_eq) = (-7 + 6*(7/2))/3 = (-7+21)/3 = 14/3
    f_pp_x_eq = (-7 + 6 * x_eq ** 2) / 3.0
    # f' at x_eq = 0 (it's an equilibrium), f'' = 14/3
    # Small oscillation: (1+f'²)ẍ + f'f''ẋ² + gf' = 0, near x_eq: f'→0
    # Linearize: let δx = x - x_eq, f'(x_eq+δx) ≈ f''(x_eq)·δx
    # (1+0)·δẍ + 0 + g·f''(x_eq)·δx = 0  → ω² = g·f''(x_eq)
    omega_small_eq = math.sqrt(g * f_pp_x_eq) if f_pp_x_eq > 0 else 0.0
    T_small_eq = 2 * math.pi / omega_small_eq if omega_small_eq > 0 else float("inf")

    return {
        "simulation": "lagrange_roller",
        "parameters": params,
        "physical_observation": (
            f"A point mass (m={m:.3f} kg) rolls along the 'hump path' y = 3 + x²(−7+x²)/6 "
            f"(a W-shaped track with a local maximum at x=0 and two symmetric minima at x≈±{x_eq:.4f} m). "
            f"Gravity g={g:.3f} m/s², damping b={b:.3f}. "
            f"Initial position x₀={x0:.3f} m, velocity v₀={v0:.3f} m/s."
        ),
        "physical_law": {
            "name": "Euler-Lagrange Equation on the Hump Path",
            "statement": "The particle is constrained to y=f(x); the EOM is derived from the Lagrangian for 1-DOF constrained motion.",
            "formula": "ẍ = −x(−7 + 2x²)[3g + (−7 + 6x²)ẋ²] / [9 + 49x² − 28x⁴ + 4x⁶]",
        },
        "ode_system": {
            "state_variables": ["x (m)", "v = ẋ (m/s)"],
            "equations": [
                "dx/dt = v",
                "dv/dt = −x·(−7 + 2x²)·[3g + (−7 + 6x²)·v²] / [9 + 49x² − 28x⁴ + 4x⁶] − (b/m)·v·sqrt(1+f'²)",
                "where f'(x) = x(−7+2x²)/3,  f''(x) = (−7+6x²)/3",
            ],
        },
        "derivation_steps": [
            "Track: y = f(x) = 3 + x²(−7+x²)/6.",
            "f'(x) = x(−7+2x²)/3,  f''(x) = (−7+6x²)/3.",
            "Constrained Lagrangian (no damping): L = ½m(1+f'²)ẋ² − mgf(x).",
            "Euler-Lagrange: d/dt[(1+f'²)ẋ] = f'f''ẋ²/... − gf' → (1+f'²)ẍ + f'f''ẋ² + gf' = 0.",
            "Substituting f' and f'' and simplifying the denominator 1+f'² = 1+(x(−7+2x²)/3)²:",
            "  (9 + x²(−7+2x²)²)/9  →  multiply through by 9/m gives the formula above.",
            "Full EOM numerator: −x(−7+2x²)·[3g + (−7+6x²)·ẋ²].",
            "Add damping as a generalized force: −(b/m)·sqrt(1+f'²)·ẋ.",
            f"Equilibrium points: x=0 (local MAX, unstable: f''(0)=−7/3<0).",
            f"Stable minima: x=±{x_eq:.4f} m, f''=14/3, ω_small = sqrt(g·f'') = {omega_small_eq:.4f} rad/s.",
        ],
        "variables": {
            "x": {"description": "Horizontal position on track", "initial_value": x0, "unit": "m"},
            "v": {"description": "Horizontal velocity", "initial_value": v0, "unit": "m/s"},
            "g": {"value": g, "unit": "m/s²"},
            "m": {"value": m, "unit": "kg"},
            "b": {"value": b, "unit": "dimensionless or kg/s", "description": "Damping coefficient"},
        },
        "physical_constants_derived": {
            "stable_equilibrium_x_m": round(x_eq, 4),
            "track_height_at_minima_m": round(f_x_eq, 4),
            "f_double_prime_at_minima": round(f_pp_x_eq, 4),
            "omega_small_osc_rad_s": round(omega_small_eq, 4),
            "T_small_osc_s": round(T_small_eq, 4) if T_small_eq != float("inf") else None,
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince, 4th/5th order Runge-Kutta)",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": "Polynomial track with polynomial EOM; RK45 is efficient for smooth nonlinear ODEs.",
        },
        "code_validation": {
            "ode_source": "Euler-Lagrange on hump path; matches LagrangeRollerSim.ts evaluate()",
            "energy_check": "E = ½m(1+f'²)ẋ² + mgf(x) decreases when b>0",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Track has unstable equilibrium at x=0 and stable minima at x≈±{x_eq:.3f} m.",
            f"Small oscillations near minima: ω ≈ {omega_small_eq:.3f} rad/s (T ≈ {T_small_eq:.3f} s).",
            f"Initial x₀={x0:.3f}: {'near unstable top' if abs(x0) < 0.3 else 'near one of the minima' if abs(abs(x0) - x_eq) < 0.5 else 'on the slope'}.",
            "With sufficient initial energy, mass can transit over the central hump between minima.",
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Magnet Wheel
# ─────────────────────────────────────────────────────────────────────────────
def cot_magnet_wheel(params: dict[str, Any]) -> dict:
    N, R_wheel = params["N"], params["R_wheel"]
    m_wheel, strength = params["m_wheel"], params["strength"]
    damping = params["damping"]
    theta0, omega0 = params["theta0"], params["omega0"]

    # Moment of inertia of wheel (solid disk): I = 0.5 * m * R²
    I_wheel = 0.5 * m_wheel * R_wheel ** 2

    # Fixed external magnets are placed symmetrically; equilibrium angle where net torque = 0.
    # For N wheel magnets equally spaced, equilibrium at θ = π/N (halfway between two positions).
    # The exact equilibrium depends on external magnet arrangement, but the key computed quantity:
    theta_eq = math.pi / N if N > 0 else 0.0

    return {
        "simulation": "magnet_wheel",
        "parameters": params,
        "physical_observation": (
            f"A wheel (mass m={m_wheel:.3f} kg, radius R={R_wheel:.3f} m, solid disk) "
            f"has N={N} equally-spaced magnets on its rim. "
            f"Fixed external magnets exert Coulomb-like forces (∝ 1/dist²) on the wheel magnets. "
            f"Damping coefficient {damping:.4f}. "
            f"Initial angle θ₀={theta0:.3f} rad, angular velocity ω₀={omega0:.3f} rad/s."
        ),
        "physical_law": {
            "name": "Rotational Dynamics with Magnetic (Coulomb-law) Torque",
            "statement": (
                "I·α = Σᵢ τᵢ − damping·ω. "
                "Each wheel magnet i exerts a force F_i = strength/dist² on its nearest external magnet, "
                "contributing torque τᵢ = R_wheel × F_tangential."
            ),
            "formula": "I·α = Σᵢ [R_wheel·(strength/dist²)·sin(angle_i)] − damping·ω,  I = ½·m·R²",
        },
        "ode_system": {
            "state_variables": ["θ (wheel angle, rad)", "ω = θ̇ (angular velocity, rad/s)"],
            "equations": [
                "dθ/dt = ω",
                "dω/dt = [Σᵢ τᵢ(θ) − damping·ω] / I",
                "where τᵢ = R_wheel·strength·sin(φᵢ)/dist_i²,",
                "φᵢ = angle between wheel magnet i and nearest external magnet,",
                "dist_i = distance from wheel magnet i to nearest external magnet.",
            ],
        },
        "derivation_steps": [
            f"Moment of inertia of solid disk: I = ½·m·R² = ½·{m_wheel:.3f}·{R_wheel:.3f}² = {I_wheel:.4f} kg·m².",
            f"N={N} wheel magnets at angular positions θ + 2πk/N for k=0,...,N−1.",
            "For each wheel magnet, compute distance to each fixed external magnet.",
            "Magnetic force magnitude: F = strength/dist²  (Coulomb-like, repulsive or attractive).",
            "Tangential component of force on wheel magnet: F_tang = F·sin(angle between force and radial direction).",
            "Torque from magnet i: τᵢ = R_wheel·F_tang_i.",
            "Total torque: τ_net = Στᵢ.",
            "Newton's 2nd for rotation: I·θ̈ = τ_net − damping·θ̇.",
            f"Estimated equilibrium angle: θ_eq ≈ π/N = {theta_eq:.4f} rad (symmetry argument).",
        ],
        "variables": {
            "θ": {"description": "Wheel rotation angle", "initial_value": theta0, "unit": "rad"},
            "ω": {"description": "Angular velocity of wheel", "initial_value": omega0, "unit": "rad/s"},
            "N": {"value": N, "unit": "dimensionless", "description": "Number of wheel magnets"},
            "R_wheel": {"value": R_wheel, "unit": "m", "description": "Wheel radius"},
            "m_wheel": {"value": m_wheel, "unit": "kg", "description": "Wheel mass"},
            "strength": {"value": strength, "unit": "N·m²", "description": "Magnetic strength constant"},
            "damping": {"value": damping, "unit": "kg·m²/s", "description": "Rotational damping coefficient"},
        },
        "physical_constants_derived": {
            "moment_of_inertia_kg_m2": round(I_wheel, 4),
            "estimated_equilibrium_angle_rad": round(theta_eq, 4),
            "angular_spacing_between_magnets_rad": round(2 * math.pi / N if N > 0 else 0.0, 4),
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince, 4th/5th order Runge-Kutta)",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": "Torque is a nonlinear function of θ; adaptive RK45 handles rapid force variations.",
        },
        "code_validation": {
            "ode_source": "Rotational Newton's law with magnetic torque; matches MagnetWheelSim.ts evaluate()",
            "energy_check": "Rotational KE ½Iω² decreases due to damping; magnetic PE oscillates",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Moment of inertia: I = {I_wheel:.4f} kg·m².",
            f"N={N} magnets → equilibrium angular spacing {360/N:.1f}°.",
            f"Estimated equilibrium angle: θ_eq ≈ {math.degrees(theta_eq):.2f}°.",
            f"With damping={damping:.4f}, wheel oscillates and settles to nearest equilibrium.",
            "Magnets create a periodic potential with period 2π/N; multiple stable equilibria.",
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Robot Speed
# ─────────────────────────────────────────────────────────────────────────────
def cot_robot_speed(params: dict[str, Any]) -> dict:
    r_wheel    = params["r_wheel"]
    slope_deg  = params["slope_deg"]
    v_terminal = params["v_terminal"]
    tau        = params["tau"]
    x0, v0     = params["x0"], params["v0"]

    return {
        "simulation": "robot_speed",
        "parameters": params,
        "physical_observation": (
            f"A wheeled robot (wheel radius r={r_wheel:.4f} m) drives along a "
            f"ramp inclined at {slope_deg:.2f}°. Its velocity approaches a "
            f"terminal value v∞={v_terminal:.3f} m/s with first-order time "
            f"constant τ={tau:.3f} s. Initial position x₀={x0:.3f} m, "
            f"initial velocity v₀={v0:.3f} m/s."
        ),
        "physical_law": {
            "name": "First-order linear approach to terminal velocity",
            "statement": (
                "The robot's velocity relaxes exponentially toward a terminal "
                "value set by the balance of motor drive, slope-induced "
                "gravity, and drag. The time constant τ characterises how "
                "fast that balance is reached."
            ),
            "formula": (
                "dx/dt = v\n"
                "dv/dt = (v_terminal − v) / τ"
            ),
        },
        "ode_system": {
            "state_variables": ["x (position along ramp, m)", "v = ẋ (velocity, m/s)"],
            "equations": [
                "dx/dt = v",
                "dv/dt = (v_terminal − v) / τ",
            ],
        },
        "derivation_steps": [
            "The motor's drive force minus the slope-aligned weight component "
            "minus drag produces a net force that vanishes at v = v_terminal.",
            "Linearising about that balance gives a first-order linear ODE: "
            "dv/dt = (v_terminal − v) / τ.",
            "Closed-form solution: v(t) = v_terminal + (v₀ − v_terminal)·exp(−t/τ).",
            f"After one time constant ({tau:.3f} s), v reaches "
            f"v_terminal − (v_terminal − v₀)/e = "
            f"{v_terminal - (v_terminal - v0)/math.e:.4f} m/s.",
            f"Position: x(t) = x₀ + v_terminal·t + (v₀ − v_terminal)·τ·(1 − exp(−t/τ)).",
        ],
        "variables": {
            "x": {"description": "Position along ramp", "initial_value": x0, "unit": "m"},
            "v": {"description": "Velocity along ramp", "initial_value": v0, "unit": "m/s"},
            "r_wheel":    {"value": r_wheel,    "unit": "m"},
            "slope_deg":  {"value": slope_deg,  "unit": "degrees"},
            "v_terminal": {"value": v_terminal, "unit": "m/s"},
            "tau":        {"value": tau,        "unit": "s"},
        },
        "physical_constants_derived": {
            "v_terminal_m_s": round(v_terminal, 4),
            "tau_s":          round(tau, 4),
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince, 4th/5th order Runge-Kutta)",
            "tolerance": "rtol=1e-8, atol=1e-10",
            "justification": "Linear ODE; RK45 is more than sufficient.",
        },
        "code_validation": {
            "ode_source": "First-order linear ODE for velocity relaxation.",
            "energy_check": "v should converge monotonically to v_terminal.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Terminal velocity: v_terminal = {v_terminal:.3f} m/s.",
            f"Time constant: τ = {tau:.3f} s.",
            f"After ~3τ ({3*tau:.2f} s) the robot has reached ≈95% of terminal.",
            ("Robot accelerates toward terminal velocity." if v_terminal > v0
             else "Robot decelerates toward terminal velocity."),
        ],
    }



# ─────────────────────────────────────────────────────────────────────────────
# U-Tube Fluid Oscillation on an Accelerating Cart
# ─────────────────────────────────────────────────────────────────────────────
def cot_u_tube_fluid_oscillation(params: dict[str, Any]) -> dict:
    A1    = params["A1"]
    A2    = params["A2"]
    h0    = params["h0"]
    L_arm = params["L_arm"]
    D     = params["D"]
    rho   = params["rho"]
    g     = params["g"]
    b     = params["b_damping"]
    Xamp  = params["X_amp"]
    om    = params["omega_drive"]
    xi0   = params["xi0"]
    xidot0 = params["xi_dot0"]

    A_b = max(A1, A2)
    m_eff = rho * (A1 * h0 + A1**2 * h0 / A2 + A1**2 * D / A_b)
    k     = rho * g * A1 * (A1 + A2) / A2
    omega_n = math.sqrt(k / m_eff)
    T_n     = 2 * math.pi / omega_n
    zeta    = b / (2 * m_eff * omega_n)
    if zeta < 1:
        regime = "underdamped (decaying oscillation about a slowly drifting equilibrium)"
    elif abs(zeta - 1) < 0.02:
        regime = "near-critical damping"
    else:
        regime = "overdamped"

    # Peak cart acceleration and resulting static-tilt amplitude
    a_peak     = Xamp * om * om
    delta_h_eq = D * a_peak / g
    drive_F_amp = rho * A1 * D * a_peak

    # Steady-state ξ amplitude from the driven-oscillator transfer function
    denom_real = (k - m_eff * om * om)
    denom_imag = (b * om)
    xi_ss_amp = drive_F_amp / math.sqrt(denom_real * denom_real + denom_imag * denom_imag)
    h_L_max_predicted = h0 + xi_ss_amp
    h_R_min_predicted = h0 - (A1 / A2) * xi_ss_amp

    overflow_warning = h_L_max_predicted > L_arm
    empty_warning    = h_R_min_predicted < 0
    extreme_note = []
    if overflow_warning:
        extreme_note.append(
            f"Predicted peak left-arm height (h_L = {h_L_max_predicted:.3f} m) exceeds the "
            f"arm length L_arm = {L_arm:.3f} m — fluid will spill out of the left arm in the "
            "linear model; the rendering clamps h_L at the arm length to depict overflow."
        )
    if empty_warning:
        extreme_note.append(
            f"Predicted minimum right-arm height (h_R = {h_R_min_predicted:.3f} m) goes below "
            "zero — the right arm momentarily empties; the rendering clamps h_R at 0 to depict "
            "this. The linearised ODE breaks down here (air would enter the bottom segment)."
        )

    return {
        "simulation": "u_tube_fluid_oscillation",
        "parameters": params,
        "physical_observation": (
            f"A vertical U-tube — left-arm cross-section A_1={A1:.4e} m², right-arm "
            f"A_2={A2:.4e} m², horizontal arm spacing D={D:.3f} m, equilibrium fluid column "
            f"h_0={h0:.3f} m in each arm — is rigidly mounted on a cart that oscillates "
            f"horizontally as x_cart(t) = {Xamp:.3f}·sin({om:.3f}·t). The fluid (ρ={rho:.0f} kg/m³) "
            f"sloshes between the arms, driven by hydrostatic pressure and the inertial pseudo-force "
            f"associated with the cart's acceleration. Damping b={b:.3f} kg/s. Natural frequency "
            f"ω_n = {omega_n:.3f} rad/s ({omega_n/(2*math.pi):.3f} Hz, T_n = {T_n:.3f} s); "
            f"motion is {regime}."
        ),
        "physical_law": {
            "name": (
                "Conservation of mass + Newton's 2nd Law + hydrostatic pressure + "
                "Lagrangian for fluid in a uniform-cross-section tube"
            ),
            "statement": (
                "Volume conservation A_1·h_L + A_2·h_R = const. enforces "
                "h_R(t) = h_0 - (A_1/A_2)·ξ(t) when ξ(t) is the rise of the left-arm level. "
                "Newton's 2nd Law applied to the fluid as a single 1-DOF system gives a "
                "linear damped-driven oscillator: m_eff·ξ̈ + b·ξ̇ + k·ξ = ρ·A_1·D·a_cart(t). "
                "The restoring stiffness k comes from gravitational PE of the two columns "
                "(hydrostatic pressure difference ρg·Δh acting over A_1) and the effective "
                "mass m_eff comes from the kinetic energy of the entire fluid mass moving "
                "with the continuity-implied velocities. The drive is the inertial pseudo-force "
                "ρ·A_b·D·a_cart on the bottom segment in the cart's non-inertial frame."
            ),
            "formula": (
                "m_eff·ξ̈ + b·ξ̇ + k·ξ = ρ·A_1·D·a_cart(t),    "
                "m_eff = ρ·[A_1·h_0 + A_1²·h_0/A_2 + A_1²·D/A_b],    "
                "k = ρ·g·A_1·(A_1 + A_2)/A_2,    "
                "h_R(t) = h_0 − (A_1/A_2)·ξ(t),    "
                "a_cart(t) = -X_amp·ω²·sin(ω·t)."
            ),
        },
        "ode_system": {
            "state_variables": [
                "ξ      (left-arm fluid level above equilibrium, m)",
                "ξ̇      (left-arm level velocity = fluid speed in left arm, m/s)",
            ],
            "equations": [
                "dξ/dt  = ξ̇",
                "dξ̇/dt = (ρ·A_1·D·a_cart(t) - b·ξ̇ - k·ξ) / m_eff",
                "h_L(t) = h_0 + ξ(t),  h_R(t) = h_0 - (A_1/A_2)·ξ(t)   "
                "(volume conservation A_1·h_L + A_2·h_R = const).",
            ],
        },
        "derivation_steps": [
            "Choose generalised coordinate ξ = displacement of the LEFT-arm fluid level above "
            "its equilibrium height h_0. Volume conservation A_1·h_L + A_2·h_R = (A_1+A_2)·h_0 "
            "constrains the right arm:  h_R = h_0 − (A_1/A_2)·ξ.",
            "Continuity of an incompressible fluid through a tube gives velocity in each section:",
            "    v_L  =  ξ̇                      (in the left arm,  area A_1)",
            "    v_R  = -(A_1/A_2) · ξ̇          (in the right arm, area A_2)",
            "    v_b  = -(A_1/A_b) · ξ̇          (in the bottom segment, area A_b)",
            "where A_b is the bottom segment's cross-section.",
            "",
            "Kinetic energy (sum of ½·ρ·V·v² over each section):",
            "    T  =  ½·ρ·A_1·h_L·ξ̇²  +  ½·ρ·A_2·h_R·v_R²  +  ½·ρ·A_b·D·v_b²",
            "       =  ½·ρ·ξ̇² · [ A_1·h_L  +  A_1²·h_R/A_2  +  A_1²·D/A_b ].",
            "Linearising about ξ = 0 (h_L = h_R = h_0):",
            "    m_eff = ρ·[ A_1·h_0  +  A_1²·h_0/A_2  +  A_1²·D/A_b ].",
            "",
            "Gravitational potential energy of each column (centre of mass at h/2):",
            "    V_grav  =  ½·ρ·g·A_1·h_L²  +  ½·ρ·g·A_2·h_R²  +  const(bottom).",
            "Substitute h_L = h_0+ξ, h_R = h_0 − (A_1/A_2)·ξ and expand to second order in ξ:",
            "    V_grav  =  const  +  ½·ρ·g·A_1·(A_1 + A_2)/A_2 · ξ²,",
            "so the restoring stiffness  k = ∂²V/∂ξ²|_0 = ρ·g·A_1·(A_1 + A_2)/A_2.",
            "",
            "Generalised force from the cart's acceleration (cart frame pseudo-force per unit "
            "mass = -a_cart x̂). Only the bottom segment has fluid moving along x; its "
            "x-displacement when ξ changes is ∂s_b/∂ξ = -A_1/A_b. The pseudo-force on the "
            "bottom is -ρ·A_b·D·a_cart. Hence the generalised force on ξ is",
            "    Q_ξ  =  (-ρ·A_b·D·a_cart) · (-A_1/A_b)  =  ρ·A_1·D·a_cart(t).",
            "",
            "Add a Rayleigh dissipation R = ½·b·ξ̇²  →  ∂R/∂ξ̇ = b·ξ̇.  Lagrange's equation gives:",
            "    m_eff·ξ̈  +  b·ξ̇  +  k·ξ  =  ρ·A_1·D·a_cart(t).",
            "This is the linear damped-driven harmonic oscillator integrated by RK45.",
            "",
            "Static-tilt check (steady cart acceleration a):  setting ξ̈ = ξ̇ = 0 gives "
            "ξ_eq = ρ·A_1·D·a / k = D·a·A_2 / (g·(A_1 + A_2)),  so the height difference "
            "Δh = h_L - h_R = (1 + A_1/A_2)·ξ_eq = D·a/g — exactly the tilted-surface result "
            "from the equivalence principle (free surface ⊥ effective gravity in the cart frame).",
            "",
            "Uniform-tube limiting case (A_1 = A_2 = A_b = A, b = 0):",
            "    m_eff = ρ·A·(2h_0 + D),   k = 2·ρ·g·A,",
            "    ω_n²  = k/m_eff = 2g/(2h_0 + D) = 2g/L_total — the textbook U-tube period.",
        ],
        "variables": {
            "xi":      {"description": "Left-arm fluid level above equilibrium",
                        "initial_value": xi0,    "unit": "m"},
            "xi_dot":  {"description": "Time derivative of ξ",
                        "initial_value": xidot0, "unit": "m/s"},
            "A1":          {"description": "Left-arm cross-section",  "value": A1,    "unit": "m²"},
            "A2":          {"description": "Right-arm cross-section", "value": A2,    "unit": "m²"},
            "h0":          {"description": "Equilibrium fluid height in each arm",
                            "value": h0, "unit": "m"},
            "L_arm":       {"description": "Arm length (cap before overflow)",
                            "value": L_arm, "unit": "m"},
            "D":           {"description": "Horizontal arm spacing", "value": D, "unit": "m"},
            "rho":         {"description": "Fluid density",       "value": rho, "unit": "kg/m³"},
            "g":           {"description": "Gravitational acceleration",
                            "value": g, "unit": "m/s²"},
            "b_damping":   {"description": "Linear viscous damping coefficient on ξ",
                            "value": b, "unit": "kg/s"},
            "X_amp":       {"description": "Cart oscillation amplitude",
                            "value": Xamp, "unit": "m"},
            "omega_drive": {"description": "Cart drive angular frequency",
                            "value": om, "unit": "rad/s"},
        },
        "physical_constants_derived": {
            "A_b_bottom_area_m2":   round(A_b, 6),
            "m_eff_kg":             round(m_eff, 6),
            "k_restoring_N_per_m":  round(k, 4),
            "omega_n_rad_per_s":    round(omega_n, 4),
            "T_n_seconds":          round(T_n, 4),
            "damping_ratio_zeta":   round(zeta, 4),
            "regime":               regime,
            "peak_cart_acc_m_per_s2":         round(a_peak, 4),
            "static_tilt_amplitude_Dh_eq_m":  round(delta_h_eq, 4),
            "drive_force_amplitude_N":        round(drive_F_amp, 4),
            "xi_steady_state_amplitude_m":    round(xi_ss_amp, 4),
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince, 4th/5th order Runge-Kutta)",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": (
                "ODE is a smooth, non-stiff linear damped-driven oscillator with a sinusoidal "
                "drive; RK45 with tight tolerances tracks both transient and steady-state to "
                "near machine precision."
            ),
        },
        "code_validation": {
            "ode_source": "Lagrangian mechanics on a 1-DOF fluid coordinate ξ; equivalent to "
                          "Newton's 2nd Law on the equivalent fluid mass with hydrostatic-pressure "
                          "restoring force.",
            "volume_check": (
                "A_1 · h_L(t) + A_2 · h_R(t) = (A_1 + A_2) · h_0 = const. "
                "(satisfied identically by the substitution h_R = h_0 − (A_1/A_2)·ξ)."
            ),
            "static_tilt_check": (
                "For constant cart acceleration a, ξ_eq = (D·A_2·a)/(g·(A_1+A_2)) and "
                "Δh = h_L − h_R = D·a/g — the equivalence-principle result."
            ),
            "uniform_tube_check": (
                "If A_1 = A_2 = A_b: m_eff = ρ·A·(2h_0+D), k = 2ρ·g·A, "
                "ω_n² = 2g/(2h_0+D), recovering the textbook U-tube period."
            ),
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Natural frequency ω_n = {omega_n:.3f} rad/s (T_n = {T_n:.3f} s); driving at "
            f"ω = {om:.3f} rad/s ({'near resonance' if abs(om - omega_n) < 0.5 * omega_n else 'off resonance'}).",
            f"Damping ratio ζ = b/(2 m_eff ω_n) = {zeta:.4f}; regime is {regime}.",
            f"Peak cart acceleration a = X_amp·ω² = {a_peak:.3f} m/s². Static-tilt amplitude "
            f"Δh_eq = D·a/g = {delta_h_eq:.4f} m sets the scale for level-difference oscillation.",
            f"Steady-state ξ amplitude (from the driven-oscillator transfer function) "
            f"≈ {xi_ss_amp:.4f} m  →  predicted peak h_L ≈ {h_L_max_predicted:.3f} m, "
            f"h_R ≈ {h_R_min_predicted:.3f} m.",
            "Volume is exactly conserved at every instant (A_1·h_L + A_2·h_R = const).",
            "After a few periods the response settles into a steady forced oscillation locked to "
            "the drive frequency, lagging by phase φ = arctan(b·ω / (k − m_eff·ω²)).",
            *extreme_note,
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Sand Onto Moving Cart — Variable-Mass Newton II
# ─────────────────────────────────────────────────────────────────────────────
def cot_sand_onto_moving_cart(params: dict[str, Any]) -> dict:
    M    = params["M"]
    v0   = params["v0"]
    mdot = params["mdot"]
    x0   = params["x0"]
    g    = params["g"]

    duration_default = 4.5
    p0      = M * v0
    tau     = M / mdot
    m_T     = mdot * duration_default
    M_T     = M + m_T
    v_T     = M * v0 / M_T
    x_T     = (M * v0 / mdot) * math.log(M_T / M) + x0
    KE_0    = 0.5 * M * v0 * v0
    KE_T    = 0.5 * M_T * v_T * v_T
    KE_lost = KE_0 - KE_T

    return {
        "simulation": "sand_onto_moving_cart",
        "parameters": params,
        "physical_observation": (
            f"A frictionless cart (initial mass M={M:.3f} kg) moves at v_0={v0:.3f} m/s "
            f"along a horizontal track. A vertical stream of sand falls onto the cart at a "
            f"constant mass-flow rate ṁ={mdot:.3f} kg/s. Because the sand has zero horizontal "
            f"velocity, capturing it costs the cart momentum, slowing it according to "
            f"horizontal momentum conservation: (M + m(t))·v(t) = M·v_0."
        ),
        "physical_law": {
            "name": "Variable-Mass Newton's 2nd Law (Meshchersky equation)",
            "statement": (
                "When a body's mass changes by accretion or expulsion at rate dm/dt with the "
                "added/lost matter having velocity v_added in the lab frame, Newton's 2nd Law "
                "generalises to:  F_ext = m(t)·dv/dt + (dm/dt)·(v - v_added). "
                "For a frictionless cart receiving sand falling vertically (v_added = 0) with "
                "no external horizontal force (F_ext = 0), this becomes "
                "(M + ṁ·t)·dv/dt = -ṁ·v, equivalent to the conservation statement "
                "p_0 = M·v_0 = (M + m(t))·v(t)."
            ),
            "formula": (
                "F_ext = m(t)·dv/dt + (dm/dt)·(v - v_added);   "
                "with F_ext = 0, v_added = 0:  (M + ṁ·t)·dv/dt = -ṁ·v   "
                "⇒  v(t) = M·v_0/(M + ṁ·t),   x(t) = (M·v_0/ṁ)·ln((M+ṁ·t)/M) + x_0."
            ),
        },
        "ode_system": {
            "state_variables": [
                "x      (cart position, m)",
                "v      (cart velocity, m/s)",
                "m_sand (accumulated sand mass on cart, kg)",
            ],
            "equations": [
                "dx/dt      = v",
                "dv/dt      = -ṁ · v / (M + m_sand)",
                "dm_sand/dt = ṁ",
            ],
        },
        "derivation_steps": [
            "Treat {cart + accumulated sand} as the system. Let m(t) = ṁ·t be the captured "
            "sand mass; the total system mass at time t is M + m(t).",
            "Consider an infinitesimal time interval dt during which a mass element dm = ṁ·dt "
            "of sand (horizontal velocity 0) lands on the cart (current velocity v).",
            "Pre-collision horizontal momentum: (M + m)·v + dm·0 = (M + m)·v.",
            "Post-collision horizontal momentum: (M + m + dm)·(v + dv).",
            "Horizontal momentum is conserved (no external horizontal force):",
            "    (M + m)·v = (M + m + dm)·(v + dv)",
            "Expand the right-hand side and discard the second-order term dm·dv:",
            "    (M + m)·v = (M + m)·v + (M + m)·dv + dm·v",
            "    ⇒  0 = (M + m)·dv + ṁ·v·dt",
            "    ⇒  (M + m(t))·dv/dt = -ṁ·v.    [the equation of motion]",
            "Equivalently, d[(M + m(t))·v(t)]/dt = (M+m)·dv/dt + ṁ·v = 0, i.e. total "
            "horizontal momentum is conserved exactly.",
            "Integrate:  ∫dv/v = -∫ṁ/(M+ṁt) dt   ⇒   ln v = -ln(M+ṁt) + C",
            "    ⇒ v(t) = M·v_0 / (M + ṁ·t)  =  v_0 / (1 + t/τ),    where τ = M/ṁ.",
            "Integrate once more for position:",
            "    x(t) = ∫v dt = (M·v_0/ṁ)·ln((M + ṁ·t)/M) + x_0.",
            "Position grows logarithmically — arbitrarily slowly — i.e. the cart never "
            "stops in finite time, but its rate of displacement tends to zero.",
            "Energy: KE(t) = ½(M+m)·v² = ½·M·v_0²·M/(M+ṁt) = KE_0 / (1 + t/τ). "
            "ΔKE = -KE_0·(ṁt)/(M+ṁt) is dissipated by the inelastic capture of each "
            "sand grain (heat). Momentum is conserved; energy is not.",
        ],
        "variables": {
            "x":      {"description": "Cart horizontal position",      "initial_value": x0,  "unit": "m"},
            "v":      {"description": "Cart horizontal velocity",      "initial_value": v0,  "unit": "m/s"},
            "m_sand": {"description": "Sand mass accumulated on cart", "initial_value": 0.0, "unit": "kg"},
            "M":      {"description": "Initial cart mass",     "value": M,    "unit": "kg"},
            "v0":     {"description": "Initial cart velocity", "value": v0,   "unit": "m/s"},
            "mdot":   {"description": "Sand mass-flow rate ṁ", "value": mdot, "unit": "kg/s"},
            "x0":     {"description": "Initial cart position", "value": x0,   "unit": "m"},
            "g":      {"description": "Gravity (visualization only — vertical sand fall)",
                       "value": g, "unit": "m/s²"},
        },
        "physical_constants_derived": {
            "p0_initial_momentum_kg_m_s":    round(p0,    4),
            "tau_M_over_mdot_s":             round(tau,   4),
            "v_at_4.5s_m_per_s":             round(v_T,   4),
            "m_sand_at_4.5s_kg":             round(m_T,   4),
            "x_at_4.5s_m":                   round(x_T,   4),
            "KE_initial_J":                  round(KE_0,  4),
            "KE_at_4.5s_J":                  round(KE_T,  4),
            "KE_lost_to_inelastic_J":        round(KE_lost, 4),
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince, 4th/5th order Runge-Kutta)",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": (
                "ODE is smooth and non-stiff (RHS has the regular factor 1/(M+ṁt)); "
                "RK45 with tight tolerances produces near-machine-precision agreement "
                "with the closed-form v(t) and x(t)."
            ),
        },
        "code_validation": {
            "ode_source": "Meshchersky variable-mass equation; equivalent to horizontal momentum conservation.",
            "momentum_check": "(M + m_sand(t))·v(t) - M·v_0 should remain ≈ 0 (numerically < 1e-9).",
            "closed_form_check": (
                "v(t) = M·v_0 / (M + ṁt)   and   "
                "x(t) = (M·v_0/ṁ)·ln((M+ṁt)/M) + x_0   "
                "should match the integrator output to ≲ 1e-8."
            ),
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Initial momentum p_0 = M·v_0 = {p0:.4f} kg·m/s — exactly conserved throughout.",
            f"Characteristic time τ = M/ṁ = {tau:.3f} s. After t≈τ the cart has slowed to "
            f"½·v_0; after t≈3τ to ¼·v_0.",
            f"At t = 4.5 s: v = {v_T:.3f} m/s ({100 * v_T / v0:.1f}% of v_0), "
            f"m_sand = {m_T:.3f} kg, x = {x_T:.3f} m.",
            f"Kinetic energy decreases monotonically: KE(t) = KE_0/(1 + t/τ). "
            f"By t = 4.5 s, ΔKE = -{KE_lost:.3f} J ({100 * KE_lost / KE_0:.1f}% of KE_0) "
            "is lost to the inelastic 'sticking' of each sand grain (heat).",
            "Position grows logarithmically: x(t) = (M·v_0/ṁ)·ln(1 + t/τ) + x_0. The cart "
            "never stops in finite time; its asymptotic displacement-rate tends to 0.",
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Complex Collision Plane
# ─────────────────────────────────────────────────────────────────────────────
def cot_complex_collision_plane(params: dict[str, Any]) -> dict:
    # If the dict is sparse (only setup_seed + restitution), reconstruct full
    # layout from setup_seed via the dataclass's __post_init__ logic.
    if "body_kinds" not in params or not params.get("body_kinds"):
        from simulations.scipy.complex_collision_plane import ComplexCollisionPlaneParams
        full = ComplexCollisionPlaneParams(
            setup_seed=int(params.get("setup_seed", 0)),
            restitution=float(params.get("restitution", 0.85)),
            track_left=float(params.get("track_left", -4.0)),
            track_right=float(params.get("track_right", 4.0)),
            k_contact=float(params.get("k_contact", 5000.0)),
        )
        body_kinds  = full.body_kinds
        masses      = full.masses
        half_sizes  = full.half_sizes
        x0          = full.x0
        v0          = full.v0
        spring_a    = full.spring_a
        spring_pair = full.spring_pair
        track_left  = full.track_left
        track_right = full.track_right
        k_contact   = full.k_contact
    else:
        body_kinds  = params["body_kinds"]
        masses      = params["masses"]
        half_sizes  = params["half_sizes"]
        x0          = params["x0"]
        v0          = params["v0"]
        spring_a    = params["spring_a"]
        spring_pair = params["spring_pair"]
        track_left  = params["track_left"]
        track_right = params["track_right"]
        k_contact   = params["k_contact"]

    e = float(params["restitution"])
    M = len(body_kinds)
    n_sphere = body_kinds.count("sphere")
    n_block  = body_kinds.count("block")
    n_sa     = len(spring_a)
    n_pair   = len(spring_pair)
    p_total  = sum(m * v for m, v in zip(masses, v0))
    KE_total = 0.5 * sum(m * v * v for m, v in zip(masses, v0))

    # Damping ratio derived from restitution (used in penalty contact)
    if   e <= 0.001: zeta = 1.0
    elif e >= 0.999: zeta = 0.0
    else:
        log_e = math.log(e)
        zeta  = -log_e / math.sqrt(math.pi ** 2 + log_e ** 2)

    body_summary = []
    for i, k in enumerate(body_kinds):
        body_summary.append(
            f"  body[{i}]: kind={k}, m={masses[i]:.3f} kg, half_size={half_sizes[i]:.3f} m, "
            f"x0={x0[i]:.3f} m, v0={v0[i]:+.3f} m/s"
        )
    spring_summary = []
    for sa in spring_a:
        spring_summary.append(
            f"  spring_a on body[{sa['body_idx']}] side={'+x' if sa['side'] == +1 else '-x'}: "
            f"k={sa['k']:.2f} N/m, L_natural={sa['L']:.3f} m"
        )
    for sp in spring_pair:
        spring_summary.append(
            f"  spring_pair (body[{sp['left_body_idx']}], body[{sp['right_body_idx']}]): "
            f"k={sp['k']:.2f} N/m, L_natural={sp['L']:.3f} m"
        )

    obs = (
        f"On a frictionless 1-D plane bounded by walls at x={track_left:.2f} m and "
        f"x={track_right:.2f} m, {M} rigid bodies are placed and given initial velocities. "
        f"Composition: {n_sphere} sphere(s), {n_block} block(s), {n_sa} block(s) with attached spring "
        f"bumper(s), and {n_pair} diatomic spring-pair(s). Newton's restitution e={e:.3f} is enforced "
        f"on every hard contact. Total initial momentum p₀={p_total:.4f} kg·m/s, "
        f"initial kinetic energy KE₀={KE_total:.4f} J."
    )

    derivation = [
        "Generalised coordinates: x_i (1-D position) for each body i; state per body is (x_i, v_i).",
        f"Number of moving bodies M = {M};   total state dim = 2M = {2*M}.",
        "Newton's 2nd Law for each body: m_i ẍ_i = ΣF_i, where F_i is the sum of all contact forces "
        "acting on body i.",
        "",
        "Contact forces (between pairs of bodies, using one-sided penalty):",
        "  (a) Hard contact (sphere-sphere, sphere-block, block-block, etc.).  When body L's "
        "      right face overlaps body R's left face by amount d > 0:",
        "         F_normal = k_c · d",
        "         F_damping = -c · v_rel,   where v_rel = v_R − v_L,",
        "         c = 2 ζ √(m_eff · k_c),   m_eff = m_L · m_R / (m_L + m_R),",
        "         and ζ is chosen so e = exp(-π ζ / √(1 - ζ²)).",
        "      The total normal+damping force pushes the two bodies apart, transferring momentum "
        "      while dissipating KE in proportion to (1 - e²).",
        "  (b) Spring-mediated contact (spring_a's spring side).  While the spring is compressed:",
        "         F_spring = k_a · compression   (Hooke's law),",
        "      pushing the bodies apart.  If compression exceeds the natural length L_a, an "
        "      additional hard-contact term (a) is added on top.",
        "  (c) Spring-pair internal force (always active):",
        "         F = -k_p · (separation - rest_separation),  acting equal-and-opposite on the two "
        "      bodies.  The pair has CoM motion plus an internal vibration mode at "
        "      ω_vib = √(k_p / μ_pair), where μ_pair = m_L · m_R / (m_L + m_R).",
        "  (d) Wall contact (left and right walls): one-sided penalty spring identical to (a) "
        "      with the wall acting as an infinite-mass partner.",
        "",
        "Conservation laws:",
        "  Momentum: P = Σ m_i v_i  is conserved between collisions; impulsive forces are internal "
        "      (Newton's 3rd) so the lab-frame total momentum is exactly preserved.",
        "  Energy:   With e=1 the system is conservative; with e<1, each pairwise impulsive "
        "      collision removes (1 - e²)·½ μ v_rel² of kinetic energy from the relative motion in "
        "      the centre-of-mass frame; the CoM kinetic energy is unaffected.",
        "",
        f"For this run: e = {e:.4f}  ⇒  ζ = {zeta:.4f}  ⇒  damping coefficient c = 2 ζ √(m_eff · k_c).",
    ]

    behavior = [
        f"At t = 0, bodies have positions x₀ = {[round(x,3) for x in x0]} m and "
        f"velocities v₀ = {[round(v,3) for v in v0]} m/s.",
        f"Total initial linear momentum P₀ = Σ m_i v_i = {p_total:+.4f} kg·m/s "
        "(this value is exactly conserved between collisions).",
        f"Total initial kinetic energy KE₀ = ½ Σ m_i v_i² = {KE_total:.4f} J.",
        f"With e = {e:.3f}, hard collisions retain a fraction e² = {e*e:.3f} of the relative kinetic "
        "energy in the CoM frame (the remaining (1-e²) is lost per pairwise impulsive contact).",
    ]
    if n_sa > 0:
        behavior.append(
            f"{n_sa} attached-spring bumper(s): during contact the spring stores PE = ½ k_a · "
            "compression² and converts it back to KE, providing a smooth (non-impulsive) momentum "
            "exchange whose duration depends on √(m_eff / k_a)."
        )
    if n_pair > 0:
        behavior.append(
            f"{n_pair} diatomic spring-pair(s): each pair has a centre-of-mass mode (free "
            "translation; no internal force, no energy change) plus an internal vibration mode at "
            "ω = √(k_p / μ_pair); collisions with external bodies excite both."
        )
    behavior.append(
        "Walls reflect bodies with the same restitution e (ideal one-sided penalty); the impulsive "
        "wall force inverts the body's velocity component along the wall normal up to a factor e."
    )

    return {
        "simulation": "complex_collision_plane",
        "parameters": params,
        "physical_observation": obs,
        "physical_law": {
            "name": "Newton's Laws + Hooke's Law + Newton's Law of Restitution",
            "statement": (
                "Each rigid body obeys Newton's 2nd Law (ΣF = ma).  Pairwise impulsive contacts "
                "obey Newton's law of restitution v_rel_after = -e · v_rel_before, leaving total "
                "momentum exactly conserved and removing fraction (1-e²) of the relative kinetic "
                "energy in the centre-of-mass frame.  Spring contacts (attached bumper, internal "
                "diatomic) obey Hooke's law F = -k Δx and exchange KE↔PE continuously."
            ),
            "formula": (
                "m_i ẍ_i = Σ_j F_{ij};  hard contact: |F| = k_c·d, e = exp(-π ζ / √(1-ζ²));  "
                "spring contact: F = -k·Δx;  conservation: Σ m_i v_i = const between collisions; "
                "ΔKE_pair = -(1 - e²)·½ μ v_rel² per pairwise impulsive contact."
            ),
        },
        "ode_system": {
            "state_variables": [f"x_{i+1}" for i in range(M)] + [f"v_{i+1}" for i in range(M)],
            "equations": (
                [f"dx_{i+1}/dt = v_{i+1}" for i in range(M)] +
                [f"dv_{i+1}/dt = (1/m_{i+1}) · ΣF_{i+1}" for i in range(M)]
            ),
        },
        "derivation_steps": derivation,
        "variables": {
            "M":            {"description": "Number of moving bodies", "value": M, "unit": ""},
            "track_left":   {"value": track_left, "unit": "m"},
            "track_right":  {"value": track_right, "unit": "m"},
            "restitution":  {"description": "Newton's restitution coefficient", "value": e, "unit": ""},
            "k_contact":    {"description": "Penalty stiffness for hard contacts", "value": k_contact, "unit": "N/m"},
            "zeta":         {"description": "Damping ratio derived from e", "value": round(zeta, 4), "unit": ""},
            "body_kinds":   {"value": body_kinds},
            "masses":       {"value": [round(m, 4) for m in masses], "unit": "kg"},
            "half_sizes":   {"value": [round(h, 4) for h in half_sizes], "unit": "m"},
            "x0":           {"value": [round(x, 4) for x in x0], "unit": "m"},
            "v0":           {"value": [round(v, 4) for v in v0], "unit": "m/s"},
            "spring_a":     {"value": spring_a,    "_note": "attached-spring bumpers (k, L_natural, side)"},
            "spring_pair":  {"value": spring_pair, "_note": "diatomic pair springs (k, L_natural)"},
            "P0_total":     {"description": "Initial total momentum", "value": round(p_total, 4), "unit": "kg·m/s"},
            "KE0_total":    {"description": "Initial total kinetic energy", "value": round(KE_total, 4), "unit": "J"},
        },
        "numerical_method": {
            "solver": "LSODA (adaptive multi-method: BDF for stiff regions, Adams for non-stiff)",
            "tolerance": "rtol=1e-7, atol=1e-9, max_step=0.005",
            "justification": (
                "Penalty contacts are stiff (k_contact = 5000 N/m → contact timescale ~10 ms); "
                "LSODA auto-switches to BDF during contact and back to Adams during free flight. "
                "max_step=5 ms guarantees several integrator steps per contact."
            ),
        },
        "code_validation": {
            "ode_source": "Newton's 2nd law + Hooke's law for explicit springs + penalty contact model",
            "momentum_check": "ΣmᵢvᵢΣ exactly conserved between contacts (no external horizontal force)",
            "energy_check":  f"ΔKE per impulsive collision ≈ -(1 - e²)·½·μ·v_rel² with e={e:.3f}",
            "physical_plausibility": True,
        },
        "expected_behavior": behavior,
        "_layout_summary": [
            f"Track: x ∈ [{track_left:.2f}, {track_right:.2f}] m",
            f"Bodies (M = {M}):",
            *body_summary,
            *(["Springs:"] + spring_summary if spring_summary else []),
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Ballistic Pendulum
# ─────────────────────────────────────────────────────────────────────────────
def cot_ballistic_pendulum(params: dict[str, Any]) -> dict:
    m, M = params["m"], params["M"]
    v_b, L = params["v_b"], params["L"]
    g, b   = params["g"], params["b"]
    x_b0   = params["x_b0"]

    m_total = m + M
    v_after = m * v_b / m_total
    omega_after = v_after / L
    h_max_undamped = v_after ** 2 / (2 * g)
    cos_arg = 1 - h_max_undamped / L
    if cos_arg <= -1:
        theta_max_rad = math.pi
        over_top = True
    else:
        theta_max_rad = math.acos(max(-1.0, min(1.0, cos_arg)))
        over_top = False
    theta_max_deg = math.degrees(theta_max_rad)

    KE_before = 0.5 * m * v_b * v_b
    KE_after = 0.5 * m_total * v_after * v_after
    KE_lost  = KE_before - KE_after
    frac_lost = KE_lost / KE_before if KE_before > 0 else 0.0

    omega_nat = math.sqrt(g / L)
    T_small = 2 * math.pi / omega_nat
    Iover = m_total * L * L
    zeta = b / (2 * Iover * omega_nat)
    t_impact = max(0.0, -x_b0 / v_b)

    obs = (
        f"A small projectile of mass m={m:.3f} kg moves horizontally at "
        f"v_b={v_b:.3f} m/s and embeds itself in a stationary block of mass "
        f"M={M:.3f} kg hanging from a rigid massless rod of length L={L:.3f} m. "
        f"After the perfectly inelastic impact at t≈{t_impact:.3f} s, the "
        f"loaded pendulum (combined mass m+M={m_total:.3f} kg) swings up "
        f"under gravity to a maximum angle, then oscillates with light "
        f"damping (b={b:.3f} kg·m²/s)."
    )

    derivation = [
        "Phase 1 — Pre-impact ballistic flight:",
        "  Bullet flies horizontally at constant velocity v_b (gravity neglected over the brief flight).",
        f"  x_bullet(t) = x_b0 + v_b·t   (x_b0={x_b0:.3f} m, impact when x=0 at t={t_impact:.4f} s)",
        "Phase 2 — Inelastic collision (instantaneous):",
        "  External horizontal forces (rod tension, gravity) are negligible during contact ⇒ linear momentum is conserved.",
        "  Conservation of linear momentum:  m·v_b = (m+M)·v_after",
        f"  ⇒ v_after = m·v_b/(m+M) = {v_after:.4f} m/s",
        f"  Energy lost to deformation/heat:  ΔKE = ½m v_b² − ½(m+M)v_after² = {KE_lost:.4f} J  ({frac_lost*100:.1f}% of pre-impact KE)",
        "Phase 3 — Loaded pendulum:",
        "  Treat (m+M) as a point mass at distance L from the pivot ⇒ I = (m+M)·L².",
        "  Torques about the pivot:",
        "    τ_gravity  = −(m+M)·g·L·sin θ           (restoring)",
        "    τ_damping  = −b·θ̇                       (b is angular damping, kg·m²/s)",
        "  Newton's 2nd law for rotation:  I·θ̈ = Στ",
        "  (m+M)·L²·θ̈ = −(m+M)·g·L·sin θ − b·θ̇",
        "  ⇒  θ̈ = −(g/L)·sin θ − (b/((m+M)·L²))·θ̇",
        "Initial conditions at t = t_impact:  θ = 0,  θ̇ = ω_after = v_after/L",
        f"  ω_after = v_after/L = {omega_after:.4f} rad/s",
        "Phase 4 — Inferring v_b from observed θ_max (b → 0 limit):",
        "  Energy conservation during the swing:  ½(m+M)v_after² = (m+M)·g·h_max",
        "  Geometry:  h_max = L·(1 − cos θ_max)",
        "  ⇒ v_after = √(2·g·L·(1 − cos θ_max))",
        "  Substituting v_after = m·v_b/(m+M):",
        "  ⇒ v_b = ((m+M)/m) · √(2·g·L·(1 − cos θ_max))",
        f"  Predicted (undamped) θ_max ≈ {theta_max_deg:.2f}°  →  h_max ≈ {h_max_undamped:.4f} m",
    ]

    behavior = [
        f"Pre-impact: bullet travels straight from x={x_b0:.2f} m to x=0 in {t_impact:.3f} s.",
        f"At impact, {frac_lost*100:.1f}% of the bullet's kinetic energy is dissipated (perfectly inelastic).",
        (f"Predicted maximum swing angle (undamped): θ_max ≈ {theta_max_deg:.2f}°."
         if not over_top else
         "Predicted v_after exceeds the over-the-top threshold (√(2gL)); the rod would swing past horizontal."),
        f"Natural small-angle period of the loaded pendulum: T₀ ≈ {T_small:.3f} s.",
        (f"Damping ratio ζ = b/(2(m+M)L²·ω₀) = {zeta:.4f} < 1 → underdamped oscillations decay slowly."
         if zeta < 1 else
         f"Damping ratio ζ = {zeta:.4f} ≥ 1 → overdamped (no oscillation)."),
        "v_b can be reconstructed from the observed θ_max via "
        "v_b = ((m+M)/m)·√(2·g·L·(1 − cos θ_max)).",
    ]

    return {
        "simulation": "ballistic_pendulum",
        "parameters": params,
        "physical_observation": obs,
        "physical_law": {
            "name": "Conservation of Linear Momentum + Conservation of Mechanical Energy",
            "statement": (
                "(1) Across an instantaneous collision with no external impulse, total "
                "linear momentum is conserved: Σ p_before = Σ p_after. "
                "(2) After the perfectly inelastic impact, only conservative forces and "
                "(small) damping act on the loaded pendulum, so mechanical energy is "
                "conserved up to the work done by damping; in the b → 0 limit, the "
                "post-impact KE equals the gain in gravitational PE at the highest point."
            ),
            "formula": (
                "Collision: m·v_b = (m+M)·v_after  →  v_after = m·v_b/(m+M).  "
                "Swing (b=0): ½(m+M)v_after² = (m+M)·g·L·(1 − cos θ_max)  →  "
                "v_b = ((m+M)/m)·√(2·g·L·(1 − cos θ_max))."
            ),
        },
        "ode_system": {
            "state_variables": [
                "θ (rod angle from downward vertical, rad)",
                "ω = θ̇ (angular velocity, rad/s)",
            ],
            "equations": [
                "Pre-impact (t < t_impact): bullet at constant velocity, θ = 0, ω = 0.",
                "Impact (t = t_impact): θ unchanged; ω jumps to v_after/L by momentum conservation.",
                "Post-impact (t > t_impact):",
                "  dθ/dt = ω",
                "  dω/dt = −(g/L)·sin(θ) − (b/((m+M)·L²))·ω",
            ],
        },
        "derivation_steps": derivation,
        "variables": {
            "m":   {"description": "Bullet/projectile mass",      "value": m,    "unit": "kg"},
            "M":   {"description": "Hanging-block mass",          "value": M,    "unit": "kg"},
            "v_b": {"description": "Bullet initial speed",        "value": v_b,  "unit": "m/s"},
            "L":   {"description": "Pendulum rod length",         "value": L,    "unit": "m"},
            "g":   {"description": "Gravitational acceleration",  "value": g,    "unit": "m/s²"},
            "b":   {"description": "Angular damping coefficient", "value": b,    "unit": "kg·m²/s"},
            "x_b0":{"description": "Bullet initial x-position",   "value": x_b0, "unit": "m"},
            "θ":   {"description": "Rod angle from vertical",     "initial_value": 0.0, "unit": "rad"},
            "ω":   {"description": "Angular velocity",            "initial_value": 0.0, "unit": "rad/s"},
        },
        "numerical_method": {
            "solver": "Two-phase: analytic constant-velocity flight, then RK45 for the loaded pendulum",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": (
                "The collision is treated analytically (instantaneous, perfectly inelastic) "
                "by applying linear-momentum conservation as a discontinuous jump in the "
                "angular velocity at t = t_impact. The post-impact ODE is integrated with "
                "scipy.solve_ivp's RK45 (Dormand-Prince) at tight tolerances."
            ),
        },
        "code_validation": {
            "ode_source": (
                "Newton's 2nd law for rotation about a fixed axis applied to the loaded "
                "(m+M) pendulum; momentum conservation enforces the impact jump."
            ),
            "momentum_check": "m·v_b ≡ (m+M)·v_after at the impact instant (analytic, exact).",
            "energy_check": (
                "Mechanical energy E = ½(m+M)L²ω² + (m+M)gL(1 − cos θ) decreases monotonically "
                "after impact when b > 0 and is conserved when b = 0."
            ),
            "physical_plausibility": True,
        },
        "expected_behavior": behavior,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Accelerating Cart with Sliding Mass(es) Inside
# ─────────────────────────────────────────────────────────────────────────────
def cot_accelerating_cart_sliding_mass(params: dict[str, Any]) -> dict:
    # Reconstruct full layout if sparse (only setup_seed + driver knobs given).
    if "body_kinds" not in params or not params.get("body_kinds"):
        from simulations.scipy.accelerating_cart_sliding_mass import (
            AcceleratingCartSlidingMassParams,
        )
        full = AcceleratingCartSlidingMassParams(
            setup_seed=int(params.get("setup_seed", 0)),
            M_cart=float(params.get("M_cart", 5.0)),
            F_amp=float(params.get("F_amp", 28.0)),
            omega_drive=float(params.get("omega_drive", 1.8)),
            g=float(params.get("g", 9.8)),
            alpha_tanh=float(params.get("alpha_tanh", 80.0)),
            k_contact=float(params.get("k_contact", 4000.0)),
        )
        body_kinds      = full.body_kinds
        body_masses     = full.body_masses
        body_mu         = full.body_mu
        body_half_sizes = full.body_half_sizes
        body_x0         = full.body_x0
        body_v0         = full.body_v0
        spring_pairs    = full.spring_pairs
        L_interior      = full.L_interior
        cart_x0         = full.cart_x0
        cart_v0         = full.cart_v0
    else:
        body_kinds      = params["body_kinds"]
        body_masses     = params["body_masses"]
        body_mu         = params["body_mu"]
        body_half_sizes = params["body_half_sizes"]
        body_x0         = params["body_x0"]
        body_v0         = params["body_v0"]
        spring_pairs    = params["spring_pairs"]
        L_interior      = params["L_interior"]
        cart_x0         = params["cart_x0"]
        cart_v0         = params["cart_v0"]

    M_cart      = float(params["M_cart"])
    F_amp       = float(params["F_amp"])
    omega_drive = float(params["omega_drive"])
    g           = float(params.get("g", 9.8))
    alpha_tanh  = float(params.get("alpha_tanh", 80.0))
    k_contact   = float(params.get("k_contact", 4000.0))

    n         = len(body_kinds)
    M_total   = M_cart + sum(body_masses)
    a_cart_max = F_amp / M_cart
    a_CoM_max = F_amp / M_total
    com_amp   = F_amp / (omega_drive ** 2 * M_total)
    period    = 2.0 * math.pi / omega_drive

    # Per-body slip threshold a_threshold = μ_i g
    slip_threshold = [mu * g for mu in body_mu]
    will_always_stick = [thr >= a_cart_max - 1e-9 for thr in slip_threshold]

    n_sphere = body_kinds.count("sphere")
    n_cuboid = body_kinds.count("cuboid")
    n_spring = len(spring_pairs)

    body_summary = []
    for i, k in enumerate(body_kinds):
        thr = slip_threshold[i]
        will_stick = thr >= a_cart_max - 1e-9
        body_summary.append(
            f"  body[{i}]: kind={k}, m={body_masses[i]:.3f} kg, "
            f"half_size={body_half_sizes[i]:.3f} m, mu={body_mu[i]:.3f}, "
            f"slip_threshold mu·g = {thr:.2f} m/s² ({'sticks (μg ≥ a_cart_max)' if will_stick else 'slips for part of each cycle'}), "
            f"x0={body_x0[i]:+.3f} m"
        )
    spring_summary = []
    for sp in spring_pairs:
        l, r = sp["left_body_idx"], sp["right_body_idx"]
        mu_pair = body_masses[l] * body_masses[r] / (body_masses[l] + body_masses[r])
        omega_int = math.sqrt(sp["k"] / mu_pair)
        spring_summary.append(
            f"  spring_pair (body[{l}], body[{r}]): "
            f"k={sp['k']:.2f} N/m, L_natural={sp['L_natural']:.3f} m, "
            f"reduced mass μ_pair={mu_pair:.3f} kg, internal mode ω={omega_int:.2f} rad/s"
        )

    obs = (
        f"A wheeled cart of mass M_cart={M_cart:.3f} kg slides on a frictionless "
        f"horizontal track under a sinusoidal external force "
        f"F_ext(t) = {F_amp:.2f}·cos({omega_drive:.3f}·t) N "
        f"(period T = {period:.2f} s, peak cart-only acceleration "
        f"a_cart^max = F_amp/M_cart = {a_cart_max:.2f} m/s²; system-CoM "
        f"acceleration peaks at a_CoM^max = F_amp/M_total = {a_CoM_max:.2f} m/s²). "
        f"Inside the cart, {n} interior body(ies) — {n_sphere} sphere(s), "
        f"{n_cuboid} cuboid(s), {n_spring} spring-coupled pair(s) — sit on the cart's "
        f"floor with individual Coulomb friction coefficients μ_i. "
        f"Each body sticks to the cart while |a_cart| ≤ μ_i g and slips otherwise."
    )

    derivation = [
        "Generalised coordinates: x_cart for the cart and x_i for each interior body.",
        f"Number of interior bodies n = {n};   total system mass M_total = {M_total:.3f} kg.",
        "",
        "Newton's 2nd law for each interior body i:",
        "  m_i ẍ_i = F_friction_i_from_cart  +  Σ F_spring (if part of a spring pair)",
        "             +  Σ F_contact (interior walls + neighbouring bodies).",
        "",
        "Coulomb friction with the cart floor.  A body sticks while the static "
        "friction needed to make it co-move with the cart, m_i |a_cart|, is below "
        "the bound μ_i m_i g.  Otherwise it slips and kinetic friction acts:",
        "  F_friction_i = − μ_i m_i g · sgn(v_i − v_cart).",
        "  (Numerically we replace sgn with tanh(α (v_i − v_cart)) — same answer for "
        f"  |v_rel| ≫ 1/α; here α = {alpha_tanh:.1f}.)",
        "",
        "Hooke's law for each spring-coupled pair (left_body_idx, right_body_idx):",
        "  F_spring = − k · (separation − rest_separation),  rest_separation = L_nat + half_L + half_R.",
        "Acts equal-and-opposite on the two paired bodies.",
        "",
        "Hard contacts (interior wall and body-body) use a one-sided penalty spring "
        f"with stiffness k_c = {k_contact:.0f} N/m and damping c = 2 ζ_c √(m_eff k_c) "
        "(ζ_c = 0.6) so the bodies bounce without inter-penetration.",
        "",
        "Newton's 3rd law: the friction and contact force the cart applies to body i "
        "is exactly the negative of the force body i applies to the cart, so:",
        "  M_cart ẍ_cart = F_ext(t) − Σ_i [friction_on_i] − Σ_i [wall_contact_on_i].",
        "",
        "Centre-of-mass identity (sum body equations + cart equation; internal forces "
        "cancel by Newton's 3rd):",
        "  (M_cart + Σ m_i) ẍ_CoM = F_ext(t)",
        "      ⇒  a_CoM = F_ext(t) / M_total.",
        "Internal friction therefore conserves CoM momentum: it can only redistribute "
        "velocities between cart and bodies but cannot move the system CoM.",
        "When F_ext = 0 the CoM moves at constant velocity (linear-momentum conservation).",
        "",
        f"For this run: F_ext(t) = {F_amp:.2f} cos({omega_drive:.3f} t) N "
        f"⇒ a_CoM(t) = {a_CoM_max:.3f} cos({omega_drive:.3f} t) m/s², CoM amplitude "
        f"= F_amp/(ω² M_total) = {com_amp:.3f} m.",
    ]

    behavior = [
        f"At t = 0, cart is at x_cart = {cart_x0:+.3f} m with v_cart = {cart_v0:+.3f} m/s; "
        f"all interior bodies are at rest in the lab frame.",
        f"Cart-CoM oscillates around its DC offset with amplitude "
        f"F_amp/(ω² M_total) = {com_amp:.3f} m and period T = {period:.2f} s.",
        f"Peak required co-move acceleration is a_cart^max ≈ {a_cart_max:.2f} m/s². "
        f"A body sticks for the whole cycle iff μ_i g ≥ a_cart^max  ⇒  μ_i ≥ "
        f"{a_cart_max/g:.3f}; otherwise it slips for the part of the cycle when "
        f"|cos(ω t)| > μ_i g · M_cart / F_amp.",
    ]
    if any(will_always_stick):
        idx = [i for i, s in enumerate(will_always_stick) if s]
        behavior.append(
            f"Bodies {idx} have μ_i g ≥ a_cart^max and ride along with the cart "
            "with negligible slip throughout the clip."
        )
    if any(not s for s in will_always_stick):
        idx = [i for i, s in enumerate(will_always_stick) if not s]
        behavior.append(
            f"Bodies {idx} slip during each cycle (μ_i g < a_cart^max) — their "
            "trajectories visibly lag behind the cart in the lab frame."
        )
    if n_spring > 0:
        behavior.append(
            f"{n_spring} spring-coupled pair(s) carry an internal vibrational mode at "
            "ω_int = √(k / μ_pair) (μ_pair = m_L m_R / (m_L + m_R)); cart oscillation "
            "and friction excite this mode, so the pair separation breathes around its "
            "rest length."
        )

    eq_lines = [
        "dx_cart/dt = v_cart",
        "dv_cart/dt = (F_ext(t) - sum_i mu_i*m_i*g*tanh(alpha*(v_i-v_cart)) - sum_i F_wall_i) / M_cart",
    ]
    for i in range(n):
        eq_lines.append(f"dx_{i+1}/dt = v_{i+1}")
        eq_lines.append(
            f"dv_{i+1}/dt = (-mu_{i+1}*g*tanh(alpha*(v_{i+1}-v_cart)) "
            f"+ sum_j F_spring_{{i+1,j}} + sum_j F_contact_{{i+1,j}}) / m_{i+1}"
        )

    return {
        "simulation": "accelerating_cart_sliding_mass",
        "parameters": params,
        "physical_observation": obs,
        "physical_law": {
            "name": "Newton's 2nd Law + Coulomb Friction + Hooke's Law + Centre-of-Mass theorem",
            "statement": (
                "Each rigid body obeys Newton's 2nd law (ΣF = ma).  Coulomb friction at "
                "the cart-body interface caps the available transverse force at μ m g and "
                "is opposite to the relative velocity; Hooke's law governs explicit spring "
                "couplings.  Internal forces between cart and bodies obey Newton's 3rd "
                "law and therefore cancel from the system equation: "
                "(M_cart + Σ m_i) ẍ_CoM = F_ext(t).  When F_ext = 0 the CoM moves at "
                "constant velocity (linear-momentum conservation)."
            ),
            "formula": (
                "m_i ẍ_i = -μ_i m_i g · sgn(v_i - v_cart) + Σ F_spring + Σ F_contact;  "
                "M_cart ẍ_cart = F_ext(t) - Σ (cart reactions);  "
                "(M_cart + Σ m_i) ẍ_CoM = F_ext(t)."
            ),
        },
        "ode_system": {
            "state_variables":
                ["x_cart", "v_cart"] +
                [f"x_{i+1}" for i in range(n)] + [f"v_{i+1}" for i in range(n)],
            "equations": eq_lines,
        },
        "derivation_steps": derivation,
        "variables": {
            "n_bodies":     {"description": "Number of interior bodies", "value": n, "unit": ""},
            "M_cart":       {"description": "Cart mass", "value": M_cart, "unit": "kg"},
            "M_total":      {"description": "Total system mass M_cart + Σ m_i", "value": round(M_total, 4), "unit": "kg"},
            "F_amp":        {"description": "External force amplitude", "value": F_amp, "unit": "N"},
            "omega_drive":  {"description": "External force angular frequency", "value": omega_drive, "unit": "rad/s"},
            "period":       {"description": "Driving period 2π/ω", "value": round(period, 4), "unit": "s"},
            "g":            {"description": "Gravity", "value": g, "unit": "m/s²"},
            "alpha_tanh":   {"description": "Tanh-friction sharpness", "value": alpha_tanh, "unit": "s/m"},
            "k_contact":    {"description": "Penalty stiffness for hard contacts", "value": k_contact, "unit": "N/m"},
            "L_interior":   {"description": "Cart interior length", "value": round(L_interior, 4), "unit": "m"},
            "a_cart_max":   {"description": "Peak F_ext/M_cart (cart-only)", "value": round(a_cart_max, 4), "unit": "m/s²"},
            "a_CoM_max":    {"description": "Peak F_ext/M_total (system CoM)", "value": round(a_CoM_max, 4), "unit": "m/s²"},
            "com_amp":      {"description": "Bounded CoM oscillation amplitude F/(ω² M)", "value": round(com_amp, 4), "unit": "m"},
            "body_kinds":   {"value": body_kinds},
            "body_masses":  {"value": [round(m, 4) for m in body_masses], "unit": "kg"},
            "body_mu":      {"value": [round(m, 4) for m in body_mu], "unit": ""},
            "body_half_sizes": {"value": [round(h, 4) for h in body_half_sizes], "unit": "m"},
            "body_x0":      {"value": [round(x, 4) for x in body_x0], "unit": "m"},
            "body_v0":      {"value": [round(v, 4) for v in body_v0], "unit": "m/s"},
            "spring_pairs": {"value": spring_pairs, "_note": "k (N/m), L_natural (m), left_body_idx, right_body_idx"},
            "cart_x0":      {"value": cart_x0, "unit": "m"},
            "cart_v0":      {"value": cart_v0, "unit": "m/s"},
        },
        "numerical_method": {
            "solver": "LSODA (adaptive Adams/BDF auto-switching)",
            "tolerance": "rtol=1e-7, atol=1e-9, max_step=0.01",
            "justification": (
                "Penalty contacts (k_c = 4000 N/m) and Coulomb friction (sharp tanh) "
                "make the ODE moderately stiff during contact and at velocity reversals. "
                "LSODA switches to BDF in stiff regions and back to Adams during free "
                "flight; max_step keeps several integrator steps per contact event."
            ),
        },
        "code_validation": {
            "ode_source": (
                "Newton's 2nd law per body, regularised Coulomb friction, Hooke's law "
                "for spring pairs, penalty + damping for hard contacts."
            ),
            "com_check": (
                "ΣF_internal = 0 by Newton's 3rd ⇒ d(M_total v_CoM)/dt = F_ext(t). "
                "Numerical drift from regularised friction is bounded by O(F_max / α)."
            ),
            "physical_plausibility": True,
        },
        "expected_behavior": behavior,
        "_layout_summary": [
            f"Cart interior length: L_interior = {L_interior:.3f} m",
            f"Bodies (n = {n}):",
            *body_summary,
            *(["Spring couplings:"] + spring_summary if spring_summary else []),
        ],
    }


# ─────────────────────────────────────────────────────────────────────────────
# Watt Straight-Line Linkage
# ─────────────────────────────────────────────────────────────────────────────
def cot_watt_straight_line_linkage(params: dict[str, Any]) -> dict:
    L_a, L_b, L_c = params["L_a"], params["L_b"], params["L_c"]
    d_AB = params["d_AB"]
    A_y = params["A_y"]
    th_centre = params["theta_a_centre"]
    th_amp    = params["theta_a_amp"]
    omega_dr  = params["omega_drive"]
    phase     = params["phase"]
    branch_up = bool(params.get("branch_up", True))

    th_centre_deg = math.degrees(th_centre)
    th_amp_deg    = math.degrees(th_amp)
    drive_period  = 2 * math.pi / omega_dr if omega_dr != 0 else float("inf")

    obs = (
        f"A planar three-bar (4-bar with the ground) linkage with fixed pivots "
        f"A and B on a horizontal line (d_AB={d_AB:.3f} m). Two cranks "
        f"AC (L_a={L_a:.3f} m) and BD (L_b={L_b:.3f} m) are connected by a "
        f"floating coupler CD (L_c={L_c:.3f} m). The left crank is driven "
        f"sinusoidally about θ_a_centre={th_centre_deg:.1f}° with amplitude "
        f"{th_amp_deg:.1f}° at angular frequency ω_drive={omega_dr:.3f} rad/s "
        f"(period {drive_period:.2f} s). The midpoint M = (C+D)/2 of the "
        "coupler traces an approximate straight line — the celebrated Watt "
        "trajectory used in 18th-century beam-engine pistons."
    )

    derivation = [
        "Place A = (-d_AB/2, A_y), B = (+d_AB/2, A_y) on the ground link.",
        "Position vectors of the moving crank ends:",
        "  C(θ_a) = A + L_a · (cos θ_a, sin θ_a)",
        "  D(θ_b) = B + L_b · (cos θ_b, sin θ_b)",
        "Loop-closure constraint (the coupler has constant length):",
        "  |D − C|² = L_c²",
        "Substitute C and D and let r = B − C:",
        "  L_b² + 2 L_b · (r · û_b) + |r|² = L_c²,   where û_b = (cos θ_b, sin θ_b)",
        "Express r · û_b in polar form r·û_b = |r| cos(θ_b − φ_r) with φ_r = atan2(r_y, r_x):",
        "  cos(θ_b − φ_r) = (L_c² − L_b² − |r|²) / (2 · L_b · |r|)",
        "Two solutions per input angle (the two intersection points of the circles |D − B| = L_b and |D − C| = L_c):",
        "  θ_b = φ_r ± arccos[ (L_c² − L_b² − |r|²) / (2 · L_b · |r|) ]",
        "Pick the branch that varies continuously with θ_a (here the 'elbow-{}' branch).".format("up" if branch_up else "down"),
        "Once θ_b is known, every point on the linkage is closed-form:",
        "  M = ½ (C + D)        [coupler midpoint, the point of interest]",
        "Velocity kinematics (differentiate the loop-closure):",
        "  L_a · (−sin θ_a, cos θ_a) · θ̇_a   =   L_b · (−sin θ_b, cos θ_b) · θ̇_b   +   (Ḋ − Ċ),",
        "  whose component along the coupler axis n̂ = (D − C) / L_c gives the scalar relation",
        "    L_a · sin(θ_a − ψ) · θ̇_a  =  L_b · sin(θ_b − ψ) · θ̇_b,",
        "    where ψ is the coupler angle ψ = atan2(D_y − C_y, D_x − C_x).",
        "  Solving gives the gear ratio  θ̇_b / θ̇_a = L_a · sin(θ_a − ψ) / (L_b · sin(θ_b − ψ)).",
        "Drive (1 DOF system, prescribed input):",
        f"  θ_a(t) = {th_centre:.4f} + {th_amp:.4f} · sin({omega_dr:.4f} · t + {phase:.4f})",
        "Why M traces an approximate straight line (Watt's geometric insight):",
        "  When L_a = L_b and L_c ≈ d_AB, the locus of M near the symmetric pose θ_a = θ_b = π/2 is",
        "  a degenerate cubic (a self-intersecting figure-eight). A finite arc through the central",
        "  intersection is rectilinear to higher than first order: |Δx_M| = O(Δθ_a³) along the arc,",
        "  giving extremely small perpendicular deviation for moderate crank rotation.",
        "Underlying mechanics (multibody Newton–Euler, recorded for completeness):",
        "  Each crank is a rigid body rotating about a fixed pivot ⇒ Iᵢ θ̈ᵢ = Στ.",
        "  The coupler is a free planar rigid body; C and D are pin-joint constraints.",
        "  Three rigid bodies × 3 planar DOF = 9 DOF; 4 pin joints × 2 scalar constraints = 8 ⇒ 1 DOF total.",
        "  In the prescribed-θ_a (kinematic) regime, joint reactions are obtained from the constraint Jacobian.",
    ]

    behavior = [
        f"Single-DOF mechanism: θ_a is prescribed; θ_b, C, D, M are uniquely determined each frame.",
        f"M's trajectory is a closed curve (the linkage is periodic in θ_a) traced once per drive period (≈ {drive_period:.2f} s).",
        ("Ideal-Watt proportions (L_a≈L_b, L_c≈d_AB) ⇒ the central segment of M's locus is "
         "rectilinear to better than 1% of L_c for crank amplitudes up to ~30°.") if (
            abs(L_a - L_b) < 0.05 * max(L_a, L_b) and abs(L_c - d_AB) < 0.05 * max(L_c, d_AB)
        ) else (
            "Asymmetric proportions tilt the rectilinear segment off the perpendicular bisector of AB; "
            "the curve is a slightly-warped figure-eight."
        ),
        f"Crank C orbits the arc r = L_a around A, sweeping ±{th_amp_deg:.1f}° about {th_centre_deg:.1f}°.",
        "D's motion is found analytically (law of cosines) — no time integration needed.",
    ]

    return {
        "simulation": "watt_straight_line_linkage",
        "parameters": params,
        "physical_observation": obs,
        "physical_law": {
            "name": "Holonomic loop-closure constraints + multibody Newton-Euler kinematics",
            "statement": (
                "A planar 4-bar mechanism is a system of rigid bodies coupled by ideal "
                "revolute (pin) joints. Each pin enforces two scalar position constraints, "
                "leaving one global degree of freedom. The position of every link is "
                "determined by the loop-closure equation |D − C| = L_c, and velocities/"
                "accelerations follow by differentiating that equation."
            ),
            "formula": (
                "Loop closure: |D − C|² = L_c²   "
                "⇒   θ_b = atan2(B_y − C_y, B_x − C_x) ± arccos[ (L_c² − L_b² − |B − C|²) / (2 · L_b · |B − C|) ].   "
                "Midpoint trajectory: M = ½ (C + D)."
            ),
        },
        "ode_system": {
            "state_variables": [
                "θ_a (prescribed left-crank angle, rad)",
                "θ_b (right-crank angle, rad; algebraically dependent on θ_a)",
                "C, D (link end positions, m; algebraic from θ_a, θ_b)",
                "M = ½ (C + D) (coupler midpoint, m)",
            ],
            "equations": [
                "θ_a(t) = θ_a_centre + θ_a_amp · sin(ω_drive · t + phase)",
                "θ_b(t) = atan2(B_y − C_y, B_x − C_x) ± arccos[(L_c² − L_b² − |B − C|²) / (2 · L_b · |B − C|)]",
                "C(t)   = A + L_a · (cos θ_a, sin θ_a)",
                "D(t)   = B + L_b · (cos θ_b, sin θ_b)",
                "M(t)   = ½ (C + D)",
                "Velocity: θ̇_b = θ̇_a · L_a · sin(θ_a − ψ) / (L_b · sin(θ_b − ψ)),   ψ = atan2(D_y−C_y, D_x−C_x)",
            ],
        },
        "derivation_steps": derivation,
        "variables": {
            "L_a":             {"description": "Left crank length AC",                "value": L_a,        "unit": "m"},
            "L_b":             {"description": "Right crank length BD",               "value": L_b,        "unit": "m"},
            "L_c":             {"description": "Coupler length CD",                   "value": L_c,        "unit": "m"},
            "d_AB":            {"description": "Distance between fixed pivots A, B",  "value": d_AB,       "unit": "m"},
            "A_y":             {"description": "Height of fixed pivots above origin", "value": A_y,        "unit": "m"},
            "theta_a_centre":  {"description": "Neutral (centre) angle of left crank","value": th_centre,  "unit": "rad"},
            "theta_a_amp":     {"description": "Drive amplitude on θ_a",              "value": th_amp,     "unit": "rad"},
            "omega_drive":     {"description": "Drive angular frequency",             "value": omega_dr,   "unit": "rad/s"},
            "phase":           {"description": "Drive phase offset",                  "value": phase,      "unit": "rad"},
            "branch_up":       {"description": "Initial elbow branch (True = up)",    "value": branch_up,  "unit": ""},
        },
        "numerical_method": {
            "solver": "Closed-form (law of cosines) per frame; no ODE integration required",
            "tolerance": "Floating-point only (exact closed-form for θ_b given θ_a)",
            "justification": (
                "Because the input θ_a is prescribed and θ_b is the root of a single "
                "transcendental equation reducible to arccos, the mechanism's "
                "configuration at any instant is obtained without time integration. "
                "Branch continuity is enforced by selecting the candidate angle nearest "
                "the previous frame's solution."
            ),
        },
        "code_validation": {
            "ode_source": "Holonomic loop-closure constraint differentiated to yield the velocity ratio θ̇_b / θ̇_a.",
            "constraint_check": "After the algebraic solve, |D − C| = L_c to machine precision at every frame.",
            "physical_plausibility": True,
        },
        "expected_behavior": behavior,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Stacked Masses on an Inclined Plane
# ─────────────────────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────
# Rolling Race: Hoop vs Disk vs Sphere
# ─────────────────────────────────────────────────────────────────────────────
def cot_rolling_race_hoop_vs_disk_vs_sphere(params: dict[str, Any]) -> dict:
    theta_deg = float(params["theta_deg"])
    g         = float(params["g"])
    L_ramp    = float(params["L_ramp"])
    L_flat    = float(params["L_flat"])
    mu_r_flat = float(params["mu_r_flat"])
    lane_pitch= float(params["lane_pitch"])
    shapes    = list(params["shapes"])
    r         = list(params["r"])
    m         = list(params["m"])

    theta = math.radians(theta_deg)
    sinT  = math.sin(theta)

    BETA   = {"hoop": 1.0, "disk": 0.5, "sphere": 0.4}
    INERTIA= {
        "hoop":   "I_hoop  = m r²       (thin ring; all mass at radius r)",
        "disk":   "I_disk  = ½ m r²     (uniform solid cylinder/disk)",
        "sphere": "I_sphere= 2/5 m r²   (uniform solid sphere)",
    }

    a_per_shape = {
        sh: g * sinT / (1.0 + BETA[sh])  for sh in BETA.keys()
    }
    t_ramp_per_shape = {
        sh: math.sqrt(2.0 * L_ramp / a_per_shape[sh])  for sh in BETA.keys()
    }
    v_bot_per_shape = {
        sh: a_per_shape[sh] * t_ramp_per_shape[sh]  for sh in BETA.keys()
    }
    finishing_order = sorted(BETA.keys(), key=lambda sh: t_ramp_per_shape[sh])

    per_lane = []
    for i, sh in enumerate(shapes):
        per_lane.append(
            f"  lane {i} (top→bottom on screen): {sh}  "
            f"(r={r[i]:.3f} m, m={m[i]:.3f} kg, β={BETA[sh]}, "
            f"a={a_per_shape[sh]:.3f} m/s², t_to_bottom={t_ramp_per_shape[sh]:.3f} s, "
            f"v_at_bottom={v_bot_per_shape[sh]:.3f} m/s)"
        )

    obs = (
        f"Three round bodies — a thin hoop, a solid disk (cylinder), and a "
        f"solid sphere — are released simultaneously from rest at the top of "
        f"three identical, parallel inclined ramps (length L_ramp={L_ramp:.3f} m, "
        f"angle θ={theta_deg:.2f}°). Each rolls without slipping down its ramp, "
        f"then onto a flat run-out section (length L_flat={L_flat:.3f} m) where "
        f"a small rolling-resistance coefficient μ_r={mu_r_flat:.3f} brings it "
        "to rest. Despite their independently chosen radii and masses, the "
        "finishing order is fixed by the moment-of-inertia ratio: sphere "
        "first, disk second, hoop last."
    )

    derivation = [
        "For a rigid body rolling without slipping on a planar incline:",
        "  • Translation:  m · a_cm  =  m g sin θ  −  f          (along the incline)",
        "  • Rotation about the contact point (or about the centre of mass with friction torque):",
        "      I_cm · α  =  f · r",
        "  • Rolling-without-slipping constraint:  a_cm = α · r.",
        "Substitute α = a_cm / r into the rotational equation to eliminate α and f:",
        "    f = I_cm · a_cm / r² ",
        "  →  m a_cm = m g sin θ − I_cm a_cm / r²",
        "  →  a_cm · ( m + I_cm / r² ) = m g sin θ",
        "  →  a_cm = g sin θ / ( 1 + I_cm / (m r²) ) = g sin θ / (1 + β),     β ≡ I_cm / (m r²).",
        "Mass and radius cancel completely — only the dimensionless inertia ratio β survives.",
        "Moments of inertia of the three rolling bodies (about the symmetry axis):",
        f"  - {INERTIA['hoop']}      ⇒  β=1     ⇒  a = ½  g sin θ = {a_per_shape['hoop']:.4f} m/s²",
        f"  - {INERTIA['disk']}    ⇒  β=½     ⇒  a = ⅔  g sin θ = {a_per_shape['disk']:.4f} m/s²",
        f"  - {INERTIA['sphere']}  ⇒  β=2/5   ⇒  a = 5/7 g sin θ = {a_per_shape['sphere']:.4f} m/s²",
        "Released from rest from the same height, the time to reach the foot of the ramp is",
        "    t  =  √( 2 L_ramp / a )  =  √( 2 L_ramp (1+β) / (g sin θ) ),",
        "and the speed at the foot is",
        "    v_foot  =  √( 2 a L_ramp )  =  √( 2 g L_ramp sin θ / (1+β) ).",
        f"  - hoop:    t = {t_ramp_per_shape['hoop']:.3f} s,  v_foot = {v_bot_per_shape['hoop']:.3f} m/s",
        f"  - disk:    t = {t_ramp_per_shape['disk']:.3f} s,  v_foot = {v_bot_per_shape['disk']:.3f} m/s",
        f"  - sphere:  t = {t_ramp_per_shape['sphere']:.3f} s,  v_foot = {v_bot_per_shape['sphere']:.3f} m/s",
        "Predicted finishing order (smallest t first): " + " ➜ ".join(finishing_order) + ".",
        "The same conclusion follows from energy conservation:  m g h = ½ m v² + ½ I_cm ω², "
        "so with ω = v/r,  v² = 2 g h / (1+β); larger β ⇒ smaller v.",
        "After the foot of the ramp, the body rolls on the flat with rolling resistance:",
        "    a_flat  =  −μ_r · g     (independent of m, r and β),",
        "  bringing the body to rest at the same deceleration.",
        "Lane assignment for this clip:",
        *per_lane,
    ]

    behavior = [
        "All three bodies leave the starting line simultaneously and stay in three parallel lanes.",
        "Within ~1 s the SPHERE pulls visibly ahead, followed by the DISK; the HOOP trails farthest behind.",
        "All three reach the foot of their ramps in 0.3–0.7 s of each other (with the sphere first).",
        "On the flat each body decelerates at the same μ_r·g and eventually stops.",
        "The finishing order is independent of the (randomly chosen) radii and masses — only the inertia-ratio β matters.",
    ]

    return {
        "simulation": "rolling_race_hoop_vs_disk_vs_sphere",
        "parameters": params,
        "physical_observation": obs,
        "physical_law": {
            "name": "Newton-Euler for rolling without slipping + energy conservation",
            "statement": (
                "For a rigid body rolling without slipping down an incline, "
                "the linear-acceleration equation m a_cm = m g sin θ − f and "
                "the rotational equation I_cm α = f r combine, via the "
                "rolling constraint a_cm = α r, into a_cm = g sin θ / (1 + I_cm / m r²). "
                "Mass and radius cancel; only the dimensionless ratio "
                "β ≡ I_cm/(m r²) controls the acceleration."
            ),
            "formula": (
                "a = g · sin θ / (1 + β),   β_hoop = 1,  β_disk = 1/2,  β_sphere = 2/5;   "
                "v_foot = √(2 g L_ramp sin θ / (1+β));   "
                "On the flat:  a_flat = -μ_r · g."
            ),
        },
        "ode_system": {
            "state_variables": [
                "s_i — distance along the body's path (m), measured from the apex of its ramp",
                "v_i = ṡ_i — speed along the path (m/s)",
                "φ_i = -s_i / r_i — roll angle (rad), enforced by rolling-without-slipping",
            ],
            "equations": [
                "On-ramp  (s_i ≤ L_ramp):  v_i' = +g sin θ / (1 + β_i),  with β_i ∈ {1, 1/2, 2/5}",
                "On-flat  (s_i  > L_ramp): v_i' = -μ_r g",
                "v_i = 0 thereafter (the body is at rest)",
                "φ_i(t) = -s_i(t) / r_i      (rolling constraint)",
            ],
        },
        "derivation_steps": derivation,
        "variables": {
            "theta_deg":  {"description": "Incline angle", "value": theta_deg, "unit": "deg"},
            "g":          {"description": "Gravitational acceleration", "value": g, "unit": "m/s²"},
            "L_ramp":     {"description": "Length of the inclined ramp (along the slope)", "value": L_ramp, "unit": "m"},
            "L_flat":     {"description": "Length of the flat run-out", "value": L_flat, "unit": "m"},
            "mu_r_flat":  {"description": "Rolling-resistance coefficient on the flat", "value": mu_r_flat, "unit": ""},
            "lane_pitch": {"description": "Vertical spacing between the three parallel lanes (visualisation)", "value": lane_pitch, "unit": "m"},
            "shapes":     {"description": "Body kinds in lane order (top→bottom on screen)", "value": shapes, "unit": ""},
            "r":          {"description": "Per-body radii (visualisation; do NOT affect dynamics)", "value": r, "unit": "m"},
            "m":          {"description": "Per-body masses (visualisation; do NOT affect dynamics)", "value": m, "unit": "kg"},
        },
        "numerical_method": {
            "solver": "Closed-form analytic two-phase trajectory sampled at the frame rate",
            "tolerance": "Floating-point only — the dynamics is piecewise constant-acceleration and admits an exact algebraic solution.",
            "justification": (
                "On the ramp: s(t) = ½ a t², v(t) = a t until s = L_ramp.  "
                "On the flat: s(t) = L_ramp + v_foot Δt − ½ μ_r g Δt², v(t) = v_foot − μ_r g Δt until v = 0.  "
                "No ODE integration is required."
            ),
        },
        "code_validation": {
            "ode_source": (
                "Newton's 2nd law for translation, Euler's rotational equation, "
                "and the rolling-without-slipping constraint."
            ),
            "rolling_constraint_check": "ω(t) · r = v(t) is maintained by construction since φ(t) = -s(t) / r.",
            "energy_check": (
                "On the ramp (no friction work, since rolling without slipping does no work): "
                "m g h(t) = ½ m v² + ½ I_cm ω² = ½ (1+β) m v²,  giving "
                "v² = 2 g h / (1+β) — identical to the kinematic prediction."
            ),
            "physical_plausibility": True,
        },
        "expected_behavior": behavior,
    }

# ─────────────────────────────────────────────────────────────────────────────
# Spool Pull Direction (2D)
# ─────────────────────────────────────────────────────────────────────────────
def cot_spool_pull_direction_2d(params: dict[str, Any]) -> dict:
    M     = float(params["M"])
    R     = float(params["R"])
    r_oR  = float(params.get("r_over_R", params.get("r", 0.0) / R if R > 0 else 0.5))
    r     = float(params.get("r", r_oR * R))
    I_fac = float(params["I_factor"])
    mu_k  = float(params["mu_k"])
    g     = float(params["g"])
    T     = float(params["T"])
    theta_deg = float(params["theta_deg"])
    theta = math.radians(theta_deg)

    I_cm    = I_fac * M * R * R
    cos_th  = math.cos(theta)
    cos_thc = r / R
    th_c    = math.degrees(math.acos(min(max(cos_thc, -1.0), 1.0)))
    is_sub_critical = (theta_deg < th_c)
    rolling_dir = "toward the pull (+x)" if is_sub_critical else "away from the pull (-x)"
    tau_contact = T * (r - R * cos_th)

    obs = (
        f"A spool of mass M={M:.3f} kg, outer (flange) radius R={R:.3f} m and "
        f"inner (spindle) radius r={r:.3f} m (r/R={r_oR:.3f}) rests on a "
        f"horizontal floor with kinetic friction μ_k={mu_k:.3f}. A constant "
        f"tension T={T:.3f} N is applied through a thread wound around the "
        f"inner spindle; the thread emerges tangent at angle θ={theta_deg:.1f}° "
        f"above the horizontal. "
        f"Critical angle: θ_c = arccos(r/R) = {th_c:.2f}°."
    )

    derivation = [
        "Generalised coordinates: x (centre-of-mass position) and φ (rotation).",
        f"Moment of inertia about the centre of mass: I_cm = I_factor · M · R² = "
        f"{I_fac:.3f} · {M:.3f} · ({R:.3f})² = {I_cm:.5f} kg·m².",
        "",
        "Force/torque from the thread.  The thread emerges tangent to the inner "
        "spindle at point P = (r sinθ, −r cosθ) relative to the spool centre, "
        "pulling in the direction (cosθ, sinθ) with constant magnitude T:",
        f"  F_T = T (cosθ, sinθ);  horizontal component = T cosθ = {T*cos_th:+.4f} N.",
        "  Torque about CoM:  τ_T = (P × F_T)_z = T r sin²θ + T r cos²θ = T r "
        f"= {T*r:+.5f} N·m  (independent of θ, always CCW).",
        "",
        "Floor friction at the contact point opposes the bottom-of-spool velocity:",
        "  v_contact = v_x + ω R,   F_f = −μ_k M g · tanh(α v_contact).",
        "",
        "Newton-Euler equations of motion:",
        "  M v̇_x = T cosθ + F_f",
        "  I_cm ω̇ = T r + R F_f",
        "",
        "Critical-angle analysis.  Net torque about the floor contact point "
        "(arm to spindle tangent point is (r sinθ, R − r cosθ); to tension "
        "(T cosθ, T sinθ)):",
        f"  τ_contact = T (r − R cosθ) = {tau_contact:+.5f} N·m.",
        f"  τ_contact = 0 ⇒ cosθ = r/R, θ_c = {th_c:.2f}°.",
        f"Here cosθ = {cos_th:.4f} {'>' if is_sub_critical else '<'} r/R = {cos_thc:.4f} "
        f"⇒ θ {'<' if is_sub_critical else '>'} θ_c  "
        f"⇒ spool rolls {rolling_dir}.",
    ]

    a_pred = T * (math.cos(theta) - r / R) / (M * (1.0 + I_fac))
    behavior = [
        f"Tension torque about CoM: τ_T = T·r = {T*r:.5f} N·m  (always CCW).",
        f"Tension torque about contact: τ_contact = T(r − R cosθ) = {tau_contact:+.5f} N·m.",
        f"Direction of rolling: {rolling_dir}  (because θ "
        f"{'<' if is_sub_critical else '>'} θ_c = {th_c:.1f}°).",
        f"Steady-state CoM acceleration (rolling without slipping): "
        f"a = T·(cosθ − r/R) / [M·(1 + I_factor)] = {a_pred:+.4f} m/s².",
    ]

    eq_lines = [
        "dx/dt = v_x",
        "dphi/dt = omega",
        "dv_x/dt = (T cos(theta) + F_f) / M",
        "domega/dt = (T r + R F_f) / I_cm",
        "F_f = -mu_k M g tanh(alpha (v_x + omega R))",
    ]

    return {
        "simulation": "spool_pull_direction_2d",
        "parameters": params,
        "physical_observation": obs,
        "physical_law": {
            "name": "Newton-Euler (planar rigid body) + Coulomb friction + rolling resistance",
            "statement": (
                "A spool on a floor obeys Newton's 2nd law for translation, "
                "M v̇_x = ΣF_x, and Euler's equation for rotation about the "
                "centre of mass, I_cm ω̇ = Στ. A thread wound around the inner "
                "spindle pulls with tension T at angle θ; that tension applies "
                "a horizontal force T cosθ at the spindle tangent point and a "
                "torque T·r about the CoM (independent of θ). The torque about "
                "the floor contact point is τ_contact = T (r − R cosθ); it "
                "vanishes at the critical angle cosθ = r/R, which separates "
                "rolling toward the pull (θ<θ_c) from rolling away (θ>θ_c)."
            ),
            "formula": (
                "M v_x_dot = T cos(theta) - mu_k M g tanh(alpha (v_x + omega R));  "
                "I_cm omega_dot = T r - mu_k M g R tanh(alpha (v_x + omega R));  "
                "theta_c = arccos(r / R);  v_x(0) = 0;  omega(0) = 0."
            ),
        },
        "ode_system": {
            "state_variables": ["x (m)", "phi (rad)", "v_x (m/s)", "omega (rad/s)"],
            "equations": eq_lines,
        },
        "derivation_steps": derivation,
        "variables": {
            "M":        {"description": "Spool mass", "value": M, "unit": "kg"},
            "R":        {"description": "Outer (flange) radius", "value": R, "unit": "m"},
            "r":        {"description": "Inner (spindle) radius", "value": round(r, 5), "unit": "m"},
            "r_over_R": {"description": "Ratio r / R", "value": round(r_oR, 4), "unit": ""},
            "I_factor": {"description": "I_cm = I_factor · M · R²", "value": I_fac, "unit": ""},
            "I_cm":     {"description": "Moment of inertia about CoM", "value": round(I_cm, 5), "unit": "kg·m²"},
            "mu_k":     {"description": "Kinetic friction (rim-floor)", "value": mu_k, "unit": ""},
            "g":        {"description": "Gravity", "value": g, "unit": "m/s²"},
            "T":        {"description": "Continuous thread tension", "value": T, "unit": "N"},
            "theta_deg":{"description": "Thread angle above horizontal", "value": theta_deg, "unit": "°"},
            "theta_c_deg": {"description": "Critical angle = arccos(r/R)", "value": round(th_c, 4), "unit": "°"},
            "tau_contact": {"description": "Tension torque about contact = T(r − R cosθ)",
                             "value": round(tau_contact, 5), "unit": "N·m"},
            "tau_T_about_CoM": {"description": "Tension torque about CoM = T·r (always CCW)",
                                 "value": round(T * r, 5), "unit": "N·m"},
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince 4(5))",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": (
                "Smooth tanh-regularised Coulomb friction and rolling-resistance "
                "sgn() functions keep the right-hand side continuous, so a non-stiff "
                "Runge-Kutta integrator with tight tolerances tracks the slip-to-roll "
                "transition without spurious sign-chatter."
            ),
        },
        "code_validation": {
            "ode_source": (
                "Newton-Euler 2-D rigid body: F = m a for the centre of mass and "
                "τ = I α about the centre of mass, with continuous thread tension "
                "applied at the spindle tangent point, plus kinetic-friction and "
                "rolling-resistance couplings. Initial state: spool at rest."
            ),
            "energy_check": (
                "Power input from the thread = T · v_thread_pull_point; "
                "dissipation = μ_k M g |v_contact| + μ_r M g R |ω|."
            ),
            "physical_plausibility": True,
            "critical_angle_deg": round(th_c, 4),
        },
        "expected_behavior": behavior,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Differential Pulley (Weston Block) — chain falls / load rises
# ─────────────────────────────────────────────────────────────────────────────
def cot_differential_pulley_chain_fall(params: dict[str, Any]) -> dict:
    R           = float(params["R"])
    r_oR        = float(params.get("r_over_R", params.get("r", 0.0) / R if R > 0 else 0.85))
    r           = float(params.get("r", r_oR * R))
    M_load      = float(params["M_load"])
    m_lp        = float(params["m_lp"])
    OF          = float(params.get("overload_factor",
                                   params.get("m_eff", 0.0) * R /
                                   max((M_load + m_lp) * (R - r) / 2.0, 1e-9)
                                   if (M_load + m_lp) > 0 else 1.5))
    m_eff       = float(params.get("m_eff", OF * (M_load + m_lp) * (R - r) / (2.0 * R)))
    I_axle      = float(params["I_axle"])
    omega_target= float(params.get("omega_target", 1.0))
    tau_friction= float(params["tau_friction"])
    g           = float(params["g"])
    alpha_tanh  = float(params.get("alpha_tanh", 30.0))

    wt_torque  = (M_load + m_lp) * g * (R - r) / 2.0
    eff_torque = m_eff * g * R
    net_torque = eff_torque - wt_torque
    c_drag     = float(params.get("c_drag",
                                  max(0.05, (net_torque - tau_friction) / max(omega_target, 1e-3))))
    MA_ideal = 2.0 * R / (R - r) if R > r else float("inf")
    I_eff = I_axle + (M_load + m_lp) * ((R - r) / 2.0) ** 2 + m_eff * R * R

    # Steady-state estimates
    omega_ss   = max(0.0, (net_torque - tau_friction) / max(c_drag, 1e-9))
    v_load_ss  = (R - r) / 2.0 * omega_ss
    v_eff_ss   = R * omega_ss
    h_load_12  = v_load_ss * 12.0
    h_eff_12   = v_eff_ss * 12.0
    tau_response = I_eff / max(c_drag, 1e-9)

    obs = (
        f"A Weston differential pulley with large radius R={R:.3f} m and small "
        f"radius r={r:.3f} m (r/R={r_oR:.3f}, ideal mechanical advantage "
        f"MA = 2R/(R-r) = {MA_ideal:.2f}). A load M_load={M_load:.2f} kg hangs "
        f"from a single lower movable pulley; the only effort is a small weight "
        f"m_eff={m_eff:.3f} kg on the free end of the continuous chain. Despite "
        f"M_load/m_eff ≈ {M_load / m_eff:.2f}, the effort exceeds the lifting "
        f"threshold (overload_factor OF = {OF:.2f} > 1) so the load rises. "
        f"Friction at the upper axle (Coulomb τ_f={tau_friction:.3f} N·m + viscous "
        f"c_drag={c_drag:.3f} N·m·s/rad) clamps the upper-axle ω to a slow terminal "
        f"value ω_ss = {omega_ss:.3f} rad/s, giving load speed "
        f"{v_load_ss * 100:.2f} cm/s and effort speed {v_eff_ss * 100:.2f} cm/s."
    )

    derivation = [
        "Generalised coordinate: φ = upper-axle rotation angle.",
        "",
        "Kinematic constraints (single-DOF system).  When the upper axle rotates "
        "by dφ, the LARGE pulley pays out R dφ of chain and the SMALL pulley "
        "takes up r dφ; the net chain delivered into the lower-pulley loop is "
        "(R − r) dφ. The lower pulley is supported by TWO chain segments, so "
        "the load rises by",
        "  dh = (R − r) dφ / 2,        (load–rotation relation)",
        "and the effort end falls by",
        "  dz_eff = R dφ,              (effort–rotation relation).",
        "Velocity ratio ⇒ ideal mechanical advantage:",
        f"  MA_ideal = dz_eff / dh = R / [(R − r)/2] = 2R / (R − r) = {MA_ideal:.3f}.",
        "",
        "Effective inertia about φ.  Sum the kinetic energies of all moving parts:",
        "  T = (1/2) I_axle φ̇²                                      (compound axle)",
        "    + (1/2) (M_load + m_lp) ((R−r)/2)² φ̇²                 (load + lower pulley translation)",
        "    + (1/2) m_eff R² φ̇²                                   (effort weight)",
        "  ⇒ I_eff = I_axle + (M_load + m_lp)((R−r)/2)² + m_eff R²",
        f"        = {I_axle:.4f} + {(M_load + m_lp) * ((R - r) / 2.0) ** 2:.5f} + "
        f"{m_eff * R * R:.4f} = {I_eff:.4f} kg·m².",
        "",
        "Generalised force from gravity on the moving masses:",
        "  Q_φ = m_eff g R − (M_load + m_lp) g (R − r)/2",
        f"      = {eff_torque:.3f} − {wt_torque:.3f} = {net_torque:+.3f} N·m.",
        f"Q_φ > 0 ⇒ load rises (here OF = m_eff R / [(M_load+m_lp)(R−r)/2] = {OF:.2f} > 1).",
        "",
        "Static (quasi-equilibrium) force balance for the actual load lifted:",
        "  W (R − r)/2 = F_eff R   ⇒   W / F_eff = 2R / (R − r) = MA_ideal.",
        "  Tiny effort F_eff lifts a heavy load W with this leverage, but at the "
        "  cost of MA-fold larger displacement and MA-fold larger speed of the "
        "  effort end (work in = work out).",
        "",
        "Friction at the upper axle (regularised Coulomb + viscous):",
        f"  τ_fric = − τ_f · tanh(α ω) − c_drag · ω,    α = {alpha_tanh:.1f}.",
        "",
        "Equation of motion:",
        "  I_eff · ω̇ = Q_φ + τ_fric   ⇒   ω̇ = (Q_φ + τ_fric) / I_eff.",
        f"Time constant τ_response = I_eff / c_drag ≈ {tau_response:.3f} s "
        f"(the system rapidly approaches its terminal ω after release).",
        "",
        "Terminal angular velocity (set τ_fric = −(τ_f + c_drag ω) and ω̇ = 0):",
        f"  ω_ss ≈ (Q_φ − τ_f) / c_drag = {omega_ss:.4f} rad/s.",
        f"  ⇒ load speed v_load = (R − r)/2 · ω_ss = {v_load_ss * 100:.3f} cm/s",
        f"     effort speed v_eff = R · ω_ss = {v_eff_ss * 100:.3f} cm/s",
        f"  Over a {12.0:.1f}-s clip the load rises ≈ {h_load_12 * 100:.1f} cm "
        f"and the effort falls ≈ {h_eff_12 * 100:.1f} cm (ratio {v_eff_ss / max(v_load_ss, 1e-9):.2f}).",
    ]

    behavior = [
        f"After a brief transient (≈ τ_response = {tau_response:.3f} s) the upper "
        f"compound reaches its terminal ω_ss = {omega_ss:.3f} rad/s.",
        f"Load (M_load = {M_load:.2f} kg) rises slowly at "
        f"{v_load_ss * 100:.2f} cm/s while effort (m_eff = {m_eff:.3f} kg) falls "
        f"{v_eff_ss / max(v_load_ss, 1e-9):.2f}× faster — exactly the mechanical "
        f"advantage MA = {MA_ideal:.2f}.",
        f"Total mechanical work in/out balance: F_eff·z_eff = m_eff·g·{v_eff_ss * 12 * 100:.1f} cm "
        f"≈ M_load·g·{v_load_ss * 12 * 100:.2f} cm + friction loss.",
        "Total system KE settles to a constant value once ω = ω_ss; the "
        "remaining energy input goes to lifting load PE plus friction dissipation.",
    ]

    return {
        "simulation": "differential_pulley_chain_fall",
        "parameters": params,
        "physical_observation": obs,
        "physical_law": {
            "name": "Lagrangian mechanics of a differential pulley (single-DOF)",
            "statement": (
                "A continuous-chain Weston differential pulley reduces to one "
                "generalised coordinate φ. Kinematic constraints from the chain "
                "wrap give dh = (R-r)/2 · dφ for the load and dz_eff = R · dφ "
                "for the effort, so the velocity ratio (= ideal mechanical "
                "advantage) is 2R/(R-r). Newton's 2nd law for the system in φ-"
                "form is I_eff · φ̈ = Q_φ + τ_friction, where Q_φ is the net "
                "gravitational generalised force and τ_friction lumps Coulomb + "
                "viscous bearing torque at the upper axle."
            ),
            "formula": (
                "MA = 2R / (R - r);  "
                "I_eff = I_axle + (M_load + m_lp)((R-r)/2)^2 + m_eff R^2;  "
                "Q_phi = m_eff g R - (M_load + m_lp) g (R-r)/2;  "
                "I_eff phi_dotdot = Q_phi - tau_f tanh(alpha omega) - c_drag omega."
            ),
        },
        "ode_system": {
            "state_variables": ["phi (rad)", "omega (rad/s)"],
            "equations": [
                "dphi/dt = omega",
                "domega/dt = (m_eff*g*R - (M_load+m_lp)*g*(R-r)/2 "
                "- tau_friction*tanh(alpha*omega) - c_drag*omega) / I_eff",
            ],
        },
        "derivation_steps": derivation,
        "variables": {
            "R":            {"description": "Large upper-pulley radius", "value": R, "unit": "m"},
            "r":            {"description": "Small upper-pulley radius", "value": round(r, 5), "unit": "m"},
            "r_over_R":     {"description": "r / R", "value": round(r_oR, 4), "unit": ""},
            "M_load":       {"description": "Hanging load mass", "value": M_load, "unit": "kg"},
            "m_lp":         {"description": "Lower pulley + block mass", "value": m_lp, "unit": "kg"},
            "m_eff":        {"description": "Effort weight mass = OF·(M_load+m_lp)·(R-r)/(2R)",
                             "value": round(m_eff, 5), "unit": "kg"},
            "overload_factor": {"description": "OF = effort_torque / weight_torque",
                                "value": round(OF, 4), "unit": ""},
            "I_axle":       {"description": "Upper-axle moment of inertia", "value": I_axle, "unit": "kg·m²"},
            "I_eff":        {"description": "Effective inertia about phi",
                             "value": round(I_eff, 5), "unit": "kg·m²"},
            "tau_friction": {"description": "Coulomb-friction torque magnitude at axle",
                             "value": tau_friction, "unit": "N·m"},
            "c_drag":       {"description": "Viscous bearing damping (derived from omega_target)",
                             "value": round(c_drag, 5), "unit": "N·m·s/rad"},
            "omega_target": {"description": "Target terminal upper-axle ω used to derive c_drag",
                             "value": omega_target, "unit": "rad/s"},
            "alpha_tanh":   {"description": "tanh smoothing for sgn(ω)",
                             "value": alpha_tanh, "unit": "s/rad"},
            "g":            {"description": "Gravity", "value": g, "unit": "m/s²"},
            "MA_ideal":     {"description": "Ideal mechanical advantage 2R/(R-r)",
                             "value": round(MA_ideal, 3), "unit": ""},
            "Q_phi":        {"description": "Net gravitational generalised force",
                             "value": round(net_torque, 4), "unit": "N·m"},
            "omega_ss":     {"description": "Steady-state terminal ω",
                             "value": round(omega_ss, 4), "unit": "rad/s"},
            "v_load_ss":    {"description": "Steady-state load lift speed",
                             "value": round(v_load_ss, 5), "unit": "m/s"},
            "v_eff_ss":     {"description": "Steady-state effort fall speed",
                             "value": round(v_eff_ss, 5), "unit": "m/s"},
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince 4(5))",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": (
                "Smooth ODE with linear viscous damping plus tanh-regularised "
                "Coulomb friction; standard non-stiff RK45 with tight tolerances "
                "captures the transient and the long, slow terminal-velocity drift."
            ),
        },
        "code_validation": {
            "ode_source": (
                "Single-DOF Lagrangian: I_eff φ̈ = Q_φ - τ_f tanh(αω) - c_drag ω, "
                "with Q_φ and I_eff derived from the chain kinematic constraints."
            ),
            "energy_check": (
                "P_input = m_eff·g·v_eff;  P_lifted = M_load·g·v_load;  "
                "P_friction = τ_f|ω| + c_drag·ω². Steady state: "
                "P_input = P_lifted + P_friction."
            ),
            "physical_plausibility": True,
            "MA_ideal": round(MA_ideal, 3),
        },
        "expected_behavior": behavior,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Spinning Ball on a Moving Belt
# ─────────────────────────────────────────────────────────────────────────────
def cot_spinning_ball_on_moving_belt(params: dict[str, Any]) -> dict:
    M        = float(params["M"])
    r        = float(params["r"])
    # Accept either v_belt_0 (new) or legacy v_belt key:
    v_belt_0 = float(params.get("v_belt_0", params.get("v_belt", 0.0)))
    a_belt   = float(params.get("a_belt", 0.0))
    mu_k     = float(params["mu_k"])
    I_factor = float(params["I_factor"])
    g        = float(params["g"])
    alpha    = float(params.get("alpha_tanh", 80.0))
    x0       = float(params.get("x0", 0.0))
    v0       = float(params.get("v0", 0.0))
    omega0   = float(params.get("omega0", 0.0))

    I_cm     = I_factor * M * r * r
    a_max_no_slip = mu_k * g * (1.0 + 1.0 / I_factor)        # belt-acceleration ceiling for sustained rolling
    decel_v_rel   = a_max_no_slip                              # |dv_rel/dt| during slip
    # Initial slip speed (ball at rest spin0 vs belt at v_belt_0):
    v_rel_0       = (v0 - omega0 * r) - v_belt_0
    # Time to first roll (ignoring a_belt; valid for small |a_belt|):
    t_star_est    = abs(v_rel_0) / decel_v_rel if decel_v_rel > 1e-9 else float("inf")
    # Quasi-steady terminal kinematics (assumes the rolling state is reached and
    # then tracks the accelerating belt):
    v_term_const  = v_belt_0 * I_factor / (1.0 + I_factor)
    om_term_const = -v_belt_0 / (r * (1.0 + I_factor))
    a_ball_track  = a_belt * I_factor / (1.0 + I_factor)       # ball CoM accel while rolling on accelerating belt
    can_track     = abs(a_belt) <= a_max_no_slip + 1e-9

    direction_belt = "+x" if v_belt_0 > 0 else ("-x" if v_belt_0 < 0 else "static")
    spin_dir       = "forward (top of ball moves +x)" if omega0 > 0 else (
                      "backward (top moves -x)" if omega0 < 0 else "no initial spin")

    obs = (
        f"A ball (mass M={M:.3f} kg, radius r={r:.3f} m, I={I_factor:.3f}·M·r²) "
        f"is placed on a horizontal conveyor belt with initial linear velocity "
        f"v_ball(0)={v0:.3f} m/s and {spin_dir} (ω(0)={omega0:.3f} rad/s). The "
        f"belt itself starts at v_belt_0={v_belt_0:+.3f} m/s ({direction_belt}) and "
        f"accelerates uniformly at a_belt={a_belt:+.3f} m/s² so that "
        f"v_belt(t) = v_belt_0 + a_belt·t. Kinetic friction (μ_k={mu_k:.3f}) at "
        f"the contact translates and spins the ball; the system seeks pure rolling "
        f"on the moving belt: v_ball − ω r = v_belt(t)."
    )

    derivation = [
        "State variables (1-D translation + planar spin about the y-axis):",
        "  x(t)     — ball-centre x position",
        "  v(t)     — ball-centre x velocity (= dx/dt)",
        "  θ(t)     — orientation angle of a visual marker on the ball (CCW from +x)",
        "  ω(t)     — angular velocity in the FORWARD-ROLLING sign convention "
        "(ω > 0 ⇒ top of ball moves +x)",
        "Bookkeeping for the marker: dθ/dt = −ω so a forward-rolling ball "
        "(ω > 0) shows the marker rotating clockwise to the viewer.",
        "",
        "Belt velocity (time-varying):",
        f"  v_belt(t) = v_belt_0 + a_belt · t = {v_belt_0:+.3f} + ({a_belt:+.3f})·t   m/s.",
        "",
        "Contact-point lab velocity (bottom of the ball):",
        "  v_contact = v − ω r.",
        "Pure rolling on the (instantaneous) belt corresponds to",
        "  v − ω r = v_belt(t).",
        "Slip speed of the contact relative to the belt:",
        "  v_rel = v_contact − v_belt(t) = (v − ω r) − v_belt(t).",
        "",
        "Kinetic Coulomb friction at the contact opposes v_rel:",
        "  F_x = −μ_k M g · sgn(v_rel),  regularised as −μ_k M g · tanh(α v_rel).",
        "",
        "Newton-Euler equations:",
        "  Translation: M dv/dt = F_x   ⇒   dv/dt = −μ_k g · sgn(v_rel).",
        "  Rotation about the CoM (axis ⊥ to the page):",
        "      I_cm dω/dt = (r_contact × F)_y = −r F_x",
        "      ⇒ dω/dt = −r F_x / I_cm = −F_x / (I_factor · M · r).",
        f"  I_cm = I_factor · M · r² = {I_factor:.3f}·{M:.3f}·({r:.3f})² = {I_cm:.5f} kg·m².",
        "",
        "Slip dynamics (combining the two):",
        "  d v_rel / dt = dv/dt − r dω/dt − a_belt"
        " = −μ_k g(1 + 1/I_factor) sgn(v_rel) − a_belt.",
        f"  Slip-decay magnitude (a_belt = 0 limit): μ_k g (1 + 1/I_factor) "
        f"= {decel_v_rel:.3f} m/s².",
        "",
        f"Initial slip speed: v_rel(0) = (v(0) − ω(0) r) − v_belt_0 = "
        f"({v0:.3f} − ({omega0:.3f})·{r:.3f}) − ({v_belt_0:+.3f}) = "
        f"{v_rel_0:+.4f} m/s.",
        f"Approximate first-rolling time (small-|a_belt| limit):",
        f"  t* ≈ |v_rel(0)| / [μ_k g (1 + 1/I_factor)] = "
        f"{abs(v_rel_0):.3f}/{decel_v_rel:.3f} = {t_star_est:.3f} s.",
        "",
        "Belt-acceleration limit for sustained rolling.  Once rolling, "
        "the rolling constraint v − ω r = v_belt(t) must be maintained as the "
        "belt accelerates.  Differentiating and using F_x = M dv/dt = "
        "−r⁻¹ I_cm dω/dt gives",
        "  a_ball − r α_ball = a_belt   together with   I_cm α_ball = −r F_x = "
        "−r M a_ball.",
        "Solving: a_ball = a_belt · I_factor / (1 + I_factor)  and",
        f"  required friction force F_static = M a_ball ⇒ |a_belt| ≤ "
        f"μ_k g (1 + 1/I_factor) = {a_max_no_slip:.3f} m/s².",
        f"For this run |a_belt| = {abs(a_belt):.3f} m/s² ≤ {a_max_no_slip:.3f} m/s² "
        f"⇒ {'sustained rolling possible' if can_track else 'PERPETUAL SLIP — friction cannot supply enough acceleration'}.",
        "",
        "Reference quasi-steady-state values (a_belt = 0):",
        f"  v_term ≡ v_belt_0 · I_factor/(1+I_factor) = {v_term_const:.4f} m/s",
        f"  ω_term ≡ −v_belt_0 / [r(1+I_factor)]      = {om_term_const:.4f} rad/s",
        "",
        "After pure rolling is reached and the belt continues to accelerate, "
        "the rolling state itself accelerates at",
        f"  a_ball,roll = a_belt · I_factor/(1+I_factor) = {a_ball_track:+.4f} m/s².",
    ]

    behavior = [
        f"During slip (|v_rel| > 0) friction drives v_rel toward 0 at the "
        f"constant rate μ_k g (1+1/I_factor) = {decel_v_rel:.3f} m/s²; the ball's "
        "linear velocity changes by ±μ_k g · Δt and its angular velocity by "
        "∓μ_k g · Δt / (I_factor r) — the sign depends on sgn(v_rel).",
        f"Initial v_rel(0) = {v_rel_0:+.3f} m/s ⇒ friction is in the "
        f"{'+x' if v_rel_0 < 0 else '-x'} direction at t=0; ball translation "
        "and spin both change in the corresponding senses.",
        "Once v_rel ≈ 0 the contact-point velocity matches the belt surface — "
        "this is pure rolling on a moving belt: v_ball − ω r = v_belt(t).",
        f"For |a_belt| ≤ μ_k g (1 + 1/I_factor) ≈ {a_max_no_slip:.3f} m/s² the "
        f"rolling state is sustainable: ball CoM accelerates at "
        f"a_belt·I_factor/(1+I_factor) = {a_ball_track:+.3f} m/s² to keep up "
        "with the belt (this run: "
        f"{'satisfies' if can_track else 'VIOLATES'} this bound).",
        "Camera follows the ball, so on screen the ball appears nearly "
        "stationary while the belt's tick marks drift past it — their drift "
        "speed is v_belt(t), so any acceleration of the belt shows up as a "
        "speed-up or slow-down of the ticks.",
    ]

    return {
        "simulation": "spinning_ball_on_moving_belt",
        "parameters": params,
        "physical_observation": obs,
        "physical_law": {
            "name": "Newton-Euler equations + Coulomb friction with a time-varying surface velocity",
            "statement": (
                "A rigid ball on a frictional surface whose own velocity v_belt(t) "
                "may itself be a function of time obeys Newton's 2nd law for the "
                "centre of mass (M dv/dt = ΣF) and Euler's equation about the CoM "
                "(I_cm dω/dt = Στ). The only horizontal force is kinetic friction "
                "at the contact, F = −μ_k M g sgn(v_rel) with v_rel = (v − ω r) − "
                "v_belt(t); it has a moment arm r about the CoM, coupling "
                "translation and rotation. Slip persists while v_rel ≠ 0 and is "
                "driven to zero at the constant rate μ_k g (1 + 1/I_factor); the "
                "subsequent rolling state can be maintained iff |a_belt| ≤ "
                "μ_k g (1 + 1/I_factor), in which case the ball CoM accelerates "
                "at a_belt · I_factor/(1+I_factor)."
            ),
            "formula": (
                "v_belt(t) = v_belt_0 + a_belt t;  "
                "M dv/dt = -mu_k M g sgn(v - omega r - v_belt(t));  "
                "I_cm domega/dt = -r F_x = -F_x / (I_factor M r);  "
                "rolling sustainable iff |a_belt| <= mu_k g (1 + 1/I_factor);  "
                "in that regime a_ball = a_belt I_factor / (1 + I_factor)."
            ),
        },
        "ode_system": {
            "state_variables": ["x (m)", "v (m/s)", "theta (rad)", "omega (rad/s)"],
            "equations": [
                "dx/dt = v",
                "dv/dt = -mu_k g tanh(alpha (v - omega r - (v_belt_0 + a_belt t)))",
                "dtheta/dt = -omega",
                "domega/dt = -r F_x / I_cm,  "
                "F_x = -mu_k M g tanh(alpha (v - omega r - (v_belt_0 + a_belt t))),  "
                "I_cm = I_factor M r^2",
            ],
        },
        "derivation_steps": derivation,
        "variables": {
            "M":          {"description": "Ball mass", "value": M, "unit": "kg"},
            "r":          {"description": "Ball radius", "value": r, "unit": "m"},
            "v_belt_0":   {"description": "Initial belt surface velocity (signed)", "value": v_belt_0, "unit": "m/s"},
            "a_belt":     {"description": "Belt acceleration (signed)", "value": a_belt, "unit": "m/s²"},
            "mu_k":       {"description": "Kinetic friction coefficient (ball-belt)", "value": mu_k, "unit": ""},
            "I_factor":   {"description": "I_cm = I_factor · M · r²", "value": I_factor, "unit": ""},
            "I_cm":       {"description": "Moment of inertia about CoM", "value": round(I_cm, 6), "unit": "kg·m²"},
            "g":          {"description": "Gravity", "value": g, "unit": "m/s²"},
            "alpha_tanh": {"description": "tanh sharpness for sgn(v_rel)", "value": alpha, "unit": "s/m"},
            "x0":         {"description": "Initial ball centre x", "value": x0, "unit": "m"},
            "v0":         {"description": "Initial ball linear velocity", "value": v0, "unit": "m/s"},
            "omega0":     {"description": "Initial ball angular velocity (forward-rolling sense)", "value": omega0, "unit": "rad/s"},
            "v_rel_0":    {"description": "Initial slip speed of contact relative to belt", "value": round(v_rel_0, 5), "unit": "m/s"},
            "t_star_est": {"description": "Approximate first-rolling time (small-a_belt limit)", "value": round(t_star_est, 5), "unit": "s"},
            "a_max_no_slip": {"description": "Maximum |a_belt| consistent with sustained rolling", "value": round(a_max_no_slip, 5), "unit": "m/s²"},
            "a_ball_track":  {"description": "Ball CoM acceleration once rolling (a_belt·I_factor/(1+I_factor))", "value": round(a_ball_track, 5), "unit": "m/s²"},
            "v_term_a_belt_0": {"description": "Reference terminal v if a_belt were 0", "value": round(v_term_const, 5), "unit": "m/s"},
            "omega_term_a_belt_0": {"description": "Reference terminal ω if a_belt were 0", "value": round(om_term_const, 5), "unit": "rad/s"},
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince 4(5))",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": (
                "Smooth tanh-regularised Coulomb friction keeps the right-hand "
                "side continuous; standard non-stiff RK45 with tight tolerances "
                "captures the steep slip-to-roll transition within ~1/α ≈ 0.013 "
                "m/s relative-velocity window without spurious sign chatter."
            ),
        },
        "code_validation": {
            "ode_source": (
                "Newton-Euler equations of a 2-D rigid ball with Coulomb friction "
                "at the contact point; v_rel-based regularisation."
            ),
            "rolling_check": (
                "At t > t* the residual v − ω r − v_belt should be < 1e-3 m/s "
                "(numerical tolerance set by the tanh regularisation)."
            ),
            "energy_check": (
                "Kinetic-energy loss during slip equals friction-work integral "
                "∫ |F·v_rel| dt = (1/2) μ_eff · v_belt² with μ_eff = M (1+I_factor)·.../...; "
                "after t* energy is conserved."
            ),
            "physical_plausibility": True,
            "t_star_est": round(t_star_est, 5),
        },
        "expected_behavior": behavior,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Dispatch
# ─────────────────────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────
# Dispatch
# ────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────
# accelerating_beaker_water
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_accelerating_beaker_water(params):
    g = params["g"]
    a = params["a_lab"]
    L = params["L_beaker"]
    H = params["H_beaker"]
    h = params["h_water_eq"]
    gamma = params["gamma_settle"]
    duration = params.get("duration", 5.0)

    theta_eq = math.atan(a / g)
    theta_eq_deg = math.degrees(theta_eq)
    omega_slosh = math.sqrt(g * (math.pi / L) * math.tanh(math.pi * h / L))
    omega_d = math.sqrt(max(omega_slosh**2 - gamma**2, 1e-12))
    T_slosh = 2 * math.pi / omega_slosh

    return {
        "simulation": "accelerating_beaker_water",
        "physical_observation": (
            f"A rectangular beaker of inner width L={L:.3f} m and water depth "
            f"h_eq={h:.3f} m sits on a flat floor.  At t=0 the beaker accelerates "
            f"leftward at a={a:.3f} m/s^2 in the lab frame; the camera follows the beaker. "
            f"In the non-inertial beaker frame, a uniform pseudo-force per unit mass +a "
            f"tilts the effective gravity by theta_eq=atan(a/g) toward +x; the water free "
            f"surface tilts up to the right and oscillates around theta_eq with sloshing "
            f"frequency omega_slosh, decaying with rate gamma={gamma:.3f} 1/s."
        ),
        "physical_law": {
            "name": "Hydrostatic Equilibrium of a Free Surface in a Uniformly Accelerating Frame",
            "statement": "The free surface of a static incompressible fluid is perpendicular to the effective gravity g_eff = (a, -g).",
            "formula": "tan(theta_eq) = a/g ;  eta_eq(x) = h + tan(theta_eq) x"
        },
        "ode_system": {
            "state_variables": [
                "theta(t) (instantaneous water-surface tilt, rad)",
                "x_beaker_lab(t) (beaker x-position, m)"
            ],
            "equations_python": [
                "x_beaker_lab = -0.5 * a_lab * t**2",
                f"omega_slosh = sqrt(g * (pi/L) * tanh(pi h/L)) = {omega_slosh:.4f} rad/s",
                f"omega_d = sqrt(omega_slosh^2 - gamma^2) = {omega_d:.4f} rad/s",
                "theta(t) = theta_eq * (1 - exp(-gamma t)(cos(omega_d t) + (gamma/omega_d) sin(omega_d t)))",
            ]
        },
        "derivation_steps": [
            f"Pseudo-force in beaker frame: +a={a:.3f} m/s^2 acts in +x.",
            f"Effective gravity g_eff = (+a, -g); surface tilt theta_eq = atan(a/g) = {theta_eq:.4f} rad ({theta_eq_deg:.3f} deg).",
            f"Mass-conserving equilibrium: eta_eq(x) = h + (a/g)x with mean = h.",
            f"Sloshing frequency: omega_slosh = sqrt(g (pi/L) tanh(pi h/L)) = {omega_slosh:.4f} rad/s.",
            f"Damped second-order approach to theta_eq with gamma={gamma:.3f} 1/s, omega_d={omega_d:.4f} rad/s."
        ],
        "physical_constants_derived": {
            "theta_eq_deg": round(theta_eq_deg, 3),
            "theta_eq_rad": round(theta_eq, 4),
            "omega_slosh_rad_per_s": round(omega_slosh, 4),
            "omega_d_rad_per_s": round(omega_d, 4),
            "T_slosh_period_s": round(T_slosh, 4)
        },
        "numerical_method": {
            "solver": "Closed-form analytic solution sampled per frame",
            "tolerance": "Exact within IEEE float",
            "justification": "Both kinematic motion and damped second-order approach have analytic closed forms."
        },
        "code_validation": {
            "ode_source": "Hydrostatic free-surface in uniformly accelerating frame; damped second-order oscillator approach.",
            "energy_check": f"Slosh energy decreases monotonically as gamma={gamma:.3f}>0.",
            "physical_plausibility": True
        },
        "expected_behavior": [
            "At t=0 the surface is flat; ground markers are at rest.",
            f"Markers slide rightward at increasing speed (lab-frame beaker accel a={a:.3f} m/s^2).",
            f"Water surface tilts up-right and oscillates around theta_eq={theta_eq_deg:.2f} deg, settling within ~3-5 s."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# atwood_on_table
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_atwood_on_table(params):
    g = params["g"]
    m1 = params["m1"]
    m2 = params["m2"]
    mu_k = params["mu_k"]
    s1 = params["s1"]
    s2 = params["s2"]
    h_table = params["h_table"]
    y_m2_top_0 = params["y_m2_top_0"]
    duration = params.get("duration", 2.0)

    a = (m2 * g - mu_k * m1 * g) / (m1 + m2)
    drop = y_m2_top_0 - s2
    T_string = m1 * m2 * (1.0 + mu_k) * g / (m1 + m2)
    t_impact = math.sqrt(2.0 * drop / a) if a > 0 and drop > 0 else float('inf')
    v_impact = a * t_impact if t_impact != float('inf') else 0.0

    return {
        "simulation": "atwood_on_table",
        "physical_observation": (
            f"A cubic block M1 (m1={m1:.3f} kg, side s1={s1:.3f} m) on a tabletop "
            f"of height h_table={h_table:.3f} m is connected through a massless "
            f"string over a pulley to a hanging block M2 (m2={m2:.3f} kg, side s2={s2:.3f} m). "
            f"Released from rest, gravity pulls M2 down while string drags M1 horizontally "
            f"against kinetic friction (mu_k={mu_k:.3f})."
        ),
        "physical_law": {
            "name": "Newton's 2nd law + ideal-string constraint + Coulomb kinetic friction",
            "statement": "Single scalar s couples both blocks; m1*a = T - mu_k*m1*g and m2*a = m2*g - T.",
            "formula": "a = (m2 - mu_k m1) g / (m1 + m2);  T = m1 m2 (1+mu_k) g / (m1+m2)"
        },
        "ode_system": {
            "state_variables": ["s (string-displacement)", "v = ds/dt"],
            "equations_python": [
                "ds/dt = v",
                f"dv/dt = a = (m2 - mu_k*m1)*g/(m1+m2) = {a:.5f}",
                "x1(t) = x1_0 + s(t); y_m2_top(t) = y_m2_top_0 - s(t)",
                f"t_impact = sqrt(2*drop/a) = {t_impact:.5f} s"
            ]
        },
        "derivation_steps": [
            "Define s = string displacement (M1 right by s; M2 down by s).",
            "Free-body M1 (sliding right): m1 ddot{s} = T - mu_k m1 g.",
            "Free-body M2 (falling): m2 ddot{s} = m2 g - T.",
            f"Add: a = (m2 - mu_k m1)g/(m1+m2) = {a:.5f} m/s^2.",
            f"Tension: T = m1 m2 (1+mu_k) g/(m1+m2) = {T_string:.4f} N.",
            f"Termination: M2 hits floor at t_impact = sqrt(2*drop/a) = {t_impact:.4f} s, drop = {drop:.4f} m."
        ],
        "physical_constants_derived": {
            "a_phase1_m_s2": round(a, 5),
            "T_string_N": round(T_string, 4),
            "drop_m": round(drop, 4),
            "t_impact_s": round(t_impact, 5),
            "v_impact_m_s": round(v_impact, 5)
        },
        "numerical_method": {
            "solver": "Closed-form (constant acceleration kinematics)",
            "tolerance": "Exact within IEEE float",
            "justification": "1-DOF Atwood with constant force; exact polynomial in t."
        },
        "code_validation": {
            "ode_source": "Newton's 2nd law on each free body, eliminating tension via the string constraint.",
            "energy_check": "KE = (1/2)(m1+m2)v^2 = (m2 - mu_k m1) g s = work-energy theorem.",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Both blocks accelerate uniformly at a = {a:.4f} m/s^2 from rest.",
            f"M2 hits the floor at t_impact = {t_impact:.3f} s with v = {v_impact:.3f} m/s.",
            f"After impact, both held frozen for the rendered duration ({duration:.1f} s)."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# ball_wrapping_pole
# ────────────────────────────────────────────────────────────────────────────
def cot_ball_wrapping_pole(params):
    R = params["R_pole"]
    L0 = params["L_0"]
    v0 = params["v_0"]
    m = params["m"]
    duration = params.get("duration", 8.0)
    t_wrap = L0**2 / (2.0 * R * v0)
    phi_max = L0 / R

    return {
        "simulation": "ball_wrapping_pole",
        "physical_observation": (
            f"Top-down view: a vertical pole (radius R={R:.3f} m) at the origin. A massless "
            f"inextensible string of length L_0={L0:.3f} m anchored at (R, 0) carries a ball "
            f"(mass m={m:.3f} kg). The ball is given initial velocity v_0={v0:.3f} m/s "
            f"perpendicular to the string. The string wraps around the pole, with free length "
            f"shrinking; speed is conserved (no friction)."
        ),
        "physical_law": {
            "name": "Constraint kinematics + energy conservation in tangential motion",
            "statement": "Tension is purely radial; tangential speed is preserved (|v|=v_0 const). String wraps via L(phi)=L_0 - R*phi.",
            "formula": "L(phi) v_0 = L_0 v_0 along the constraint => phi(t) = (L_0 - sqrt(L_0^2 - 2 R v_0 t))/R"
        },
        "ode_system": {
            "state_variables": ["phi (wrap angle, rad)", "L (free string length, m)"],
            "equations_python": [
                "phi_dot = v_0 / L(phi)",
                "L(phi) = L_0 - R*phi",
                "phi(t) = (L_0 - sqrt(max(L_0**2 - 2 R v_0 t, 0))) / R",
                "ball: x = R cos(phi) - L sin(phi); y = R sin(phi) + L cos(phi)"
            ]
        },
        "derivation_steps": [
            "Parametrize wrap by phi, the angle from anchor along pole (CCW).",
            "Free length L(phi) = L_0 - R*phi (string laid down along pole arc).",
            "Position: r_ball(phi) = (R cos phi - L sin phi, R sin phi + L cos phi).",
            "d r_ball / d phi = -L (cos phi, sin phi); magnitude = L.",
            "Speed conservation: L(phi) phi_dot = v_0.",
            f"Integrate: phi(t) = (L_0 - sqrt(L_0^2 - 2 R v_0 t))/R.",
            f"Wrap completes at t_wrap = L_0^2/(2 R v_0) = {t_wrap:.4f} s with phi_max = {phi_max:.4f} rad."
        ],
        "physical_constants_derived": {
            "t_wrap_s": round(t_wrap, 4),
            "phi_max_rad": round(phi_max, 4),
            "phi_max_rev": round(phi_max / (2 * 3.14159265), 4)
        },
        "numerical_method": {
            "solver": "Closed-form analytic; no ODE integration required",
            "tolerance": "Exact within IEEE float",
            "justification": "Constraint reduces to a 1-DOF problem with closed-form integral."
        },
        "code_validation": {
            "ode_source": "String constraint + energy conservation (frictionless top-down view).",
            "energy_check": f"|v|=v_0={v0:.3f} m/s constant until wrap completion at t_wrap={t_wrap:.3f} s.",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Ball orbits the pole, with free string length L(t) shrinking linearly in phi.",
            f"Wrap completes at t_wrap = {t_wrap:.3f} s; after that, ball held at pole surface.",
            f"Many revolutions ({phi_max/(2*3.14159265):.2f}) before completion if R << L_0."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# balls_in_basin
# ────────────────────────────────────────────────────────────────────────────
def cot_balls_in_basin(params):
    g = params["g"]
    N = params["N"]
    masses = params["masses"]
    radii = params["radii"]
    e_wall = params["e_wall"]
    e_ball = params["e_ball"]
    mu_floor = params["mu_floor"]
    duration = params.get("duration", 12.0)

    return {
        "simulation": "balls_in_basin",
        "physical_observation": (
            f"{N} spherical balls of distinct masses (masses={masses}) and radii "
            f"(radii={radii}) are released into a U-shaped basin with vertical walls. "
            f"Inside the basin, balls fall under gravity (g={g:.3f} m/s^2), bounce off "
            f"walls/floor with restitution e_wall={e_wall:.2f} and tangential floor "
            f"friction mu_floor={mu_floor:.3f}, and collide with each other "
            f"(restitution e_ball={e_ball:.2f})."
        ),
        "physical_law": {
            "name": "Newton's 2nd law + impulsive collision restitution",
            "statement": "Free-flight under gravity; impulsive ball-wall and ball-ball collisions resolved with line-of-centres impulse and restitution.",
            "formula": "Jn = -(1+e) v_rel·n / (1/m_i + 1/m_j); v_n -> -e v_n at walls"
        },
        "ode_system": {
            "state_variables": ["pos[N,2]", "vel[N,2]"],
            "equations_python": [
                "vel += -g e_y dt  (between collisions)",
                "pos += vel dt",
                "if ball-wall: v_n = -e_wall v_n",
                "if ball-ball: Jn = -(1+e_ball) v_rel.n / (1/m_i + 1/m_j); apply equal/opposite impulses"
            ]
        },
        "derivation_steps": [
            "Between collisions, each ball satisfies dv/dt = (0, -g) with no air drag.",
            "Ball-wall: snap penetrating coordinate to wall, reflect normal velocity with restitution e_wall, multiply tangential by (1-mu_floor) on floor.",
            "Ball-ball: line-of-centres impulse Jn = -(1+e_ball) v_rel.n / (1/m_i + 1/m_j); positions snapped apart by overlap to remove penetration.",
            "Time-step: velocity Verlet with dt small enough for stable contact."
        ],
        "physical_constants_derived": {
            "N_balls": N,
            "total_mass_kg": round(sum(masses), 4),
            "duration_s": duration
        },
        "numerical_method": {
            "solver": "Velocity Verlet (fixed-step) with impulsive collision resolution",
            "tolerance": "dt = 0.002 s; ~6000 steps for 12 s",
            "justification": "More robust than RK45 events for many simultaneous pairwise contacts."
        },
        "code_validation": {
            "ode_source": "Standard rigid-body collision impulse with Newton restitution.",
            "energy_check": "KE strictly decreases (e<1, mu>0); momentum conserved at each binary collision.",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Initial fall under gravity; first floor contact at t ~ sqrt(2*1.0/g) = {(2.0/g)**0.5:.3f} s.",
            f"Multiple ball-ball and ball-wall collisions producing energy decay.",
            "Eventually all balls settle near the basin floor with low residual KE."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# belt_gear_rack_train
# ────────────────────────────────────────────────────────────────────────────
def cot_belt_gear_rack_train(params):
    R_top = params["R_top"]; R_mid = params["R_mid"]
    omega_max = params["omega_max"]; t_ramp = params["t_ramp"]
    rack_length = params["rack_length"]; x_rack_0 = params["x_rack_0"]
    duration = params.get("duration", 12.0)
    omega_mid_max = -(R_top / R_mid) * omega_max
    v_rack_max = -omega_max * R_top
    target_theta = (x_rack_0 + rack_length / 2.0) / R_top
    th_at_ramp_end = omega_max * t_ramp / 2.0
    if target_theta <= th_at_ramp_end:
        t_dis = (2.0 * t_ramp * target_theta / omega_max) ** 0.5
    else:
        t_dis = target_theta / omega_max + t_ramp / 2.0

    return {
        "simulation": "belt_gear_rack_train",
        "physical_observation": (
            f"Vertical stack: belt drives a top gear (R={R_top:.3f} m, N={params['N_top']} teeth) "
            f"counter-clockwise via a pulley (omega ramps to omega_max={omega_max:.3f} rad/s in t_ramp={t_ramp:.3f} s). "
            f"Top gear meshes externally with a middle gear (R={R_mid:.3f}, N={params['N_mid']}); middle gear "
            f"meshes with a horizontal rack of length {rack_length:.2f} m which translates leftward."
        ),
        "physical_law": {
            "name": "Rigid-body kinematics with rolling constraints (no slip)",
            "statement": "Top-mid: omega_mid = -(R_top/R_mid) omega_top.  Mid-rack: v_rack = omega_mid R_mid = -omega_top R_top.",
            "formula": "theta_mid = -(R_top/R_mid) theta_top;  x_rack = x_rack_0 - R_top theta_top"
        },
        "ode_system": {
            "state_variables": ["theta_top", "theta_mid", "x_rack"],
            "equations_python": [
                "omega_top(t) = omega_max * min(t/t_ramp, 1)",
                "theta_top(t) = integral of omega_top from 0 to t",
                "theta_mid(t) = -(R_top/R_mid) theta_top(t)",
                "x_rack(t) = x_rack_0 - R_top theta_top(t); frozen after disengagement"
            ]
        },
        "derivation_steps": [
            "Top gear angular speed ramps linearly from 0 to omega_max over t_ramp.",
            f"theta_top(t) = (omega_max/t_ramp) t^2/2 for t<t_ramp; omega_max(t - t_ramp/2) thereafter.",
            f"Top-middle external mesh: omega_mid = -(R_top/R_mid) omega_top = {omega_mid_max:.4f} rad/s (CW).",
            f"Middle-rack roll: v_rack = -omega_top R_top = {v_rack_max:.4f} m/s (LEFT).",
            f"Disengagement at t_dis ≈ {t_dis:.4f} s when rack right edge crosses gear contact column."
        ],
        "physical_constants_derived": {
            "omega_top_max_rad_per_s": omega_max,
            "omega_mid_max_rad_per_s": round(omega_mid_max, 4),
            "v_rack_max_m_per_s": round(v_rack_max, 4),
            "t_disengage_s": round(t_dis, 4)
        },
        "numerical_method": {
            "solver": "Closed-form analytic; no ODE",
            "tolerance": "Exact within IEEE float",
            "justification": "Rigid kinematic chain; cumulative angular position is a piecewise polynomial in t."
        },
        "code_validation": {
            "ode_source": "Standard rolling-without-slip constraints between gear pairs and gear-rack.",
            "energy_check": "Power = T omega; kinematic chain conserves angular impulse subject to ramp.",
            "physical_plausibility": True
        },
        "expected_behavior": [
            "Top gear ramps up CCW; middle spins CW; rack translates leftward.",
            f"Disengagement (gear-rack) at t ~ {t_dis:.2f} s; rack and gears freeze afterward."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# billiards_break
# ────────────────────────────────────────────────────────────────────────────
def cot_billiards_break(params):
    g = params["g"]; m = params["m"]; r = params["r"]
    e_ball = params["e_ball"]; e_wall = params["e_wall"]; mu = params["mu"]
    vx_cue0 = params["vx_cue0"]; vy_cue0 = params["vy_cue0"]
    duration = params.get("duration", 12.0)
    cue_speed = (vx_cue0**2 + vy_cue0**2) ** 0.5

    return {
        "simulation": "billiards_break",
        "physical_observation": (
            f"Top-down 2D view of a flat billiards table (no pockets) with 4 cushions. "
            f"10 stationary balls in a triangular rack and one cue ball arriving at "
            f"({vx_cue0:.2f}, {vy_cue0:.2f}) m/s. All 11 balls equal mass m={m:.3f} kg, radius r={r:.3f} m. "
            f"Cloth friction (mu={mu:.4f}) decelerates each ball; ball-ball restitution e_ball={e_ball:.2f}, "
            f"ball-cushion restitution e_wall={e_wall:.2f}."
        ),
        "physical_law": {
            "name": "Newton's 2nd law + impulsive collision restitution + Coulomb dry friction",
            "statement": "Free-flight under cloth friction; impulsive line-of-centres collisions for both ball-ball and ball-cushion contacts.",
            "formula": "dv/dt = -mu g v_hat;  Jn = -(1+e) m v_rel.n / 2  (equal mass)"
        },
        "ode_system": {
            "state_variables": ["pos[N,2]", "vel[N,2]"],
            "equations_python": [
                "dv/dt = -mu*g * v / |v| if |v|>eps else 0",
                "ball-wall: v_n -> -e_wall v_n",
                "ball-ball (equal mass): Jn = -(1+e_ball) m v_rel.n / 2"
            ]
        },
        "derivation_steps": [
            "Each ball treated as a 2D point of mass m; rotation neglected.",
            "Cloth friction: a = -mu*g*v/|v|; speed decays linearly to zero with deceleration mu*g.",
            "Ball-cushion: snap to wall, reflect normal velocity component with restitution e_wall.",
            "Ball-ball (equal mass): along contact normal n, exchange normal velocity components scaled by (1+e_ball)/2.",
            f"Cue ball initial speed = {cue_speed:.3f} m/s; deceleration ~ mu*g = {mu*g:.4f} m/s^2."
        ],
        "physical_constants_derived": {
            "cue_speed_m_s": round(cue_speed, 3),
            "deceleration_mug_m_s2": round(mu * g, 4),
            "stop_time_no_collision_s": round(cue_speed / (mu * g) if mu * g > 0 else float('inf'), 3)
        },
        "numerical_method": {
            "solver": "Velocity Verlet, dt=0.001 s",
            "tolerance": "Fixed-step; ~12000 steps for 12 s",
            "justification": "Robust for many simultaneous contacts; events resolved as instantaneous impulses."
        },
        "code_validation": {
            "ode_source": "Standard rigid-body collision impulse with Newton restitution.",
            "energy_check": "KE strictly decreases; momentum preserved at each binary collision (modulo cushion friction).",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Cue ball strikes the rack apex around t = {abs((params['x_apex'] - params['x_cue0']) / vx_cue0):.3f} s.",
            "Energy and momentum cascade through the rack producing many ball-ball collisions.",
            "All balls eventually decelerate to rest under cloth friction."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# block_belt_spring_stickslip
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_block_belt_spring_stickslip(params):
    g = params["g"]; m = params["m"]; k = params["k"]
    mu_s = params["mu_s"]; mu_k = params["mu_k"]; v_belt = params["v_belt"]
    duration = params.get("duration", 12.0)

    omega = math.sqrt(k / m)
    T_n = 2 * math.pi / omega
    x_break_disp = mu_s * m * g / k
    x_new_disp = mu_k * m * g / k
    A = -x_break_disp + x_new_disp  # = -(mu_s - mu_k) m g / k (negative)
    B = -v_belt / omega
    half = math.atan2(-A, B)
    if half <= 0: half += math.pi
    t_slip = 2.0 * half / omega
    t_stick = x_break_disp / v_belt
    cycle = t_slip + t_stick

    return {
        "simulation": "block_belt_spring_stickslip",
        "physical_observation": (
            f"A cubic block (m={m:.3f} kg) on a conveyor belt moving at v_belt={v_belt:.3f} m/s "
            f"(in -x), tethered by a Hookean spring (k={k:.3f} N/m) to a fixed wall at +x. "
            f"Coulomb friction with mu_s={mu_s:.3f} > mu_k={mu_k:.3f} produces stick-slip oscillations."
        ),
        "physical_law": {
            "name": "Newton's 2nd law + Hooke's law + Coulomb static/kinetic friction",
            "statement": "STICK: block carried by belt, static friction balances spring up to mu_s m g. SLIP: m ddot{x} = -k(x - x_eq) - mu_k m g sign(v_rel).",
            "formula": f"omega = sqrt(k/m) = {omega:.4f} rad/s; cycle period ~ {cycle:.4f} s"
        },
        "ode_system": {
            "state_variables": ["x (block centre, m)", "v = dx/dt (m/s)"],
            "equations_python": [
                "STICK: x(t) = x_start - v_belt (t - t_start)",
                "SLIP: u'' + omega^2 u = 0, where u = x - x_new, x_new = x_eq - mu_k m g / k",
                "Re-stick when v = -v_belt and spring force within static-friction bound"
            ]
        },
        "derivation_steps": [
            "Stick phase: block moves with belt at v_block = -v_belt. Static friction provides whatever horizontal force is needed up to mu_s m g.",
            f"Stick ends at x_break = x_eq - mu_s m g / k = x_eq - {x_break_disp:.4f} m, when spring force exceeds mu_s m g.",
            f"Slip phase: SHM about x_new = x_eq - mu_k m g / k = x_eq - {x_new_disp:.4f} m with omega = sqrt(k/m) = {omega:.4f} rad/s.",
            f"u(0) = x_break - x_new = -{(x_break_disp - x_new_disp):.4f} m,  u'(0) = -v_belt = {-v_belt:.4f} m/s.",
            f"Re-stick when v_block = -v_belt; closed-form half-angle solution gives slip duration {t_slip:.4f} s."
        ],
        "physical_constants_derived": {
            "omega_rad_per_s": round(omega, 4),
            "natural_period_s": round(T_n, 4),
            "stick_duration_s": round(t_stick, 4),
            "slip_duration_s": round(t_slip, 4),
            "cycle_period_s": round(cycle, 4),
            "n_cycles_in_duration": round(duration / cycle, 2)
        },
        "numerical_method": {
            "solver": "Closed-form per phase; no ODE integration",
            "tolerance": "Exact within IEEE float",
            "justification": "Stick-slip dynamics have closed-form analytic solutions in each phase."
        },
        "code_validation": {
            "ode_source": "Newton + Hooke + Coulomb friction; standard textbook stick-slip oscillator.",
            "energy_check": "Energy is pumped in by belt-friction during stick and partially dissipated during slip.",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Block is carried left at v_belt={v_belt:.3f} m/s during stick (~{t_stick:.3f} s).",
            f"Spring releases block; SHM about shifted equilibrium during slip (~{t_slip:.3f} s).",
            f"Cycle repeats with period {cycle:.3f} s; ~{duration/cycle:.1f} cycles in {duration:.1f} s."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# block_chain_collision
# ────────────────────────────────────────────────────────────────────────────
def cot_block_chain_collision(params):
    N = params["N_blocks"]; m = params["m"]
    v_in = params["v_incoming"]; block = params["block_size"]; gap = params["gap"]
    e = params["e_rest"]; mu_k = params["mu_k"]; g = params["g"]
    duration = params.get("duration", 12.0)
    return {
        "simulation": "block_chain_collision",
        "physical_observation": (
            f"{N-1} stationary blocks (mass m={m:.3f} kg, side {block:.3f} m, gap {gap:.3f} m) "
            f"sit in a row on a frictional floor. A striker (block #{N}) enters from the right "
            f"with v={v_in:.3f} m/s. Pairwise 1D elastic collisions (e={e:.3f}) propagate momentum "
            f"Newton's-cradle-style; floor friction (mu_k={mu_k:.3f}) decelerates moving blocks."
        ),
        "physical_law": {
            "name": "Newton's 2nd law + 1D restitution collisions + Coulomb floor friction",
            "statement": "Between collisions: dv/dt = -mu_k g sign(v). At contact: 1D elastic-restitution velocity exchange between equal-mass blocks.",
            "formula": "v_i' = ((m_i - e m_j)v_i + (1+e)m_j v_j)/(m_i+m_j); equal mass: v_i' = (v_i(1-e) + v_j(1+e))/2"
        },
        "ode_system": {
            "state_variables": ["x_i for i=1..N", "v_i = dx_i/dt"],
            "equations_python": [
                "x_i' = v_i",
                "v_i' = -mu_k g sign(v_i) if |v_i|>eps else 0",
                "Event: x_{i+1} - x_i - block_size = 0 (gap closure) -> apply 1D restitution"
            ]
        },
        "derivation_steps": [
            "Newton's 2nd law per block: m a_i = -mu_k m g sign(v_i) (kinetic friction).",
            "Inter-block collisions are detected as gap-closure events.",
            "Apply 1D Newton-restitution between blocks i and i+1; tension transmitted instantly.",
            "Equal masses + e<1 means each collision reduces total KE by (1-e^2)/2 of the relative-velocity-squared term.",
            f"Striker initial KE = 0.5*m*v^2 = {0.5 * m * v_in * v_in:.4f} J."
        ],
        "physical_constants_derived": {
            "striker_initial_speed_m_s": abs(v_in),
            "striker_initial_KE_J": round(0.5 * m * v_in * v_in, 4),
            "deceleration_mug_m_s2": round(mu_k * g, 4)
        },
        "numerical_method": {
            "solver": "scipy.integrate.solve_ivp (RK45) with terminal events for each gap closure",
            "tolerance": "rtol=1e-9, atol=1e-11; max_step=0.01",
            "justification": "Hybrid integrator handles smooth segments + impulsive collisions correctly."
        },
        "code_validation": {
            "ode_source": "Newton's 2nd law + 1D Newton restitution; standard textbook chain-collision.",
            "energy_check": "KE strictly decreases (e<1, mu>0); momentum conserved per collision and decreases by friction impulse.",
            "physical_plausibility": True
        },
        "expected_behavior": [
            "Striker reaches the chain and triggers cascading 1D collisions.",
            "Like a Newton's cradle, the leftmost block ejects with most of the velocity.",
            f"Friction stops all blocks within ~{abs(v_in)/(mu_k*g):.1f} s after isolation."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# block_on_sphere_basin
# ────────────────────────────────────────────────────────────────────────────
def cot_block_on_sphere_basin(params):
    g = params["g"]; m_s = params["m_s"]; r_s = params["r_s"]
    M_b = params["M_b"]; s = params["s"]
    h_drop = params["h_drop"]
    e_bs = params["e_bs"]; mu_bs = params["mu_bs"]
    duration = params.get("duration", 12.0)
    t_drop = ((2 * (h_drop - r_s)) / g) ** 0.5

    return {
        "simulation": "block_on_sphere_basin",
        "physical_observation": (
            f"2D side view: a sphere (m_s={m_s:.3f} kg, r_s={r_s:.3f} m) sits in a U-basin. "
            f"A block (M_b={M_b:.3f} kg, side s={s:.3f} m) is released from height h_drop={h_drop:.3f} m. "
            f"On contact: block-sphere collision (e_bs={e_bs:.2f}, mu_bs={mu_bs:.2f}). "
            f"Sphere then rolls/slides on basin floor with kinetic friction; bounces off walls."
        ),
        "physical_law": {
            "name": "Newton-Euler rigid-body dynamics + impulsive contact resolution",
            "statement": "Free-flight: gravity + floor friction on sphere. Contacts: decoupled normal/Coulomb-tangent rigid-body impulses with restitution.",
            "formula": "J_n = -(1+e) v_rel.n / inv_m_n;  |J_t| <= mu |J_n|"
        },
        "ode_system": {
            "state_variables": [
                "Xb, Yb, theta_b, Vxb, Vyb, omb (block COM and rotation)",
                "Xs, Ys, theta_s, Vxs, Vys, oms (sphere)"
            ],
            "equations_python": [
                "block: ddot Xb = 0; ddot Yb = -g; ddot theta_b = 0  (free flight)",
                "sphere: dVxs/dt = -sgn(v_slip) mu_floor_sphere g; dom_s/dt depends on slip",
                "Events: block-sphere gap=0; block corners hit floor/walls; sphere reaches walls"
            ]
        },
        "derivation_steps": [
            f"Block free-fall: t_drop ~ sqrt(2(h_drop - r_s)/g) = {t_drop:.4f} s.",
            f"On block-sphere contact, apply 2D rigid-body impulse with normal restitution e_bs={e_bs:.2f} and Coulomb friction mu_bs={mu_bs:.2f}.",
            "Sphere is constrained to floor (Vys=0); can roll/slide; bounces off vertical basin walls.",
            "Block continues in flight until it lands on the floor; corner-by-corner impulse handles tilted impacts.",
            "Settling logic: chatter detection snaps block flat when KE < threshold."
        ],
        "physical_constants_derived": {
            "I_sphere_kg_m2": round((2.0/5.0) * m_s * r_s**2, 6),
            "free_fall_time_s": round(t_drop, 4),
            "impact_speed_m_s": round((2 * g * (h_drop - r_s)) ** 0.5, 4)
        },
        "numerical_method": {
            "solver": "Hybrid: scipy.integrate.solve_ivp (RK45) per smooth segment + analytic impulses at events",
            "tolerance": "rtol=1e-9, atol=1e-11; max_step=0.02; up to 200 segments",
            "justification": "Standard hybrid integrator for systems with terminal contact events."
        },
        "code_validation": {
            "ode_source": "Newton-Euler rigid bodies; Coulomb friction cone; Newton restitution.",
            "energy_check": "KE non-increasing (e<1, mu>0); momentum conserved at each contact (modulo external impulses).",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Block free-falls for ~{t_drop:.2f} s before striking sphere.",
            "Sphere kicked into motion, rolls and bounces off walls.",
            f"Block lands on floor and settles flat; system at rest within ~{duration:.1f} s."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# block_strikes_spring_pair
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_block_strikes_spring_pair(params):
    g = params["g"]; m1 = params["m1"]; m2 = params["m2"]; m3 = params["m3"]
    s = params["s"]; k = params["k"]; L0 = params["L0"]; v0 = params["v0"]
    e_rest = params["e_rest"]; mu_floor = params["mu_floor"]
    duration = params.get("duration", 12.0)
    omega = math.sqrt(k * (1/m2 + 1/m3))  # spring system between blocks 2-3
    T = 2 * math.pi / omega

    return {
        "simulation": "block_strikes_spring_pair",
        "physical_observation": (
            f"Three cubical blocks (m1={m1:.3f}, m2={m2:.3f}, m3={m3:.3f} kg) on a frictional floor. "
            f"Block 1 starts on the left moving right at v_0={v0:.3f} m/s; blocks 2 and 3 are at rest, "
            f"connected by a Hookean spring (k={k:.3f} N/m, L_0={L0:.3f} m). On contact, blocks 1 and 2 "
            f"undergo Newton restitution (e={e_rest:.2f}). Then 2 and 3 oscillate via the spring; "
            f"all decelerate by Coulomb floor friction (mu={mu_floor:.3f})."
        ),
        "physical_law": {
            "name": "Newton's 2nd law + Hooke's law + Coulomb friction + 1D Newton restitution",
            "statement": "Free-body Newton II per block; spring between 2-3; Coulomb friction; impulsive 1D collision at 1-2 contact.",
            "formula": "v1' = ((m1-e m2)/(m1+m2)) v1; v2' = ((1+e) m1/(m1+m2)) v1"
        },
        "ode_system": {
            "state_variables": ["x_i, v_i for i=1,2,3"],
            "equations_python": [
                "dx_i/dt = v_i",
                "dv_2/dt = (k(x_3 - x_2 - L_0) - mu m_2 g sign(v_2)) / m_2",
                "dv_3/dt = (-k(x_3 - x_2 - L_0) - mu m_3 g sign(v_3)) / m_3",
                "dv_1/dt = -mu g sign(v_1)",
                "Event: x_1 + s/2 = x_2 - s/2 -> apply 1D restitution"
            ]
        },
        "derivation_steps": [
            f"Phase 1 (block 1 free flight): m1 dv1/dt = -mu m1 g sign(v1).",
            f"Phase 2 (impulsive collision): Newton restitution e={e_rest:.2f} between blocks 1 and 2.",
            f"Phase 3 (coupled spring): m2 dv2/dt = k(x3-x2-L0) - friction; m3 dv3/dt = -k(x3-x2-L0) - friction.",
            "Static-friction shelf via tanh(v/V_EPS) regularization for Lipschitz RHS.",
            f"Spring natural omega = sqrt(k(1/m2+1/m3)) = {omega:.4f} rad/s; period T = {T:.4f} s."
        ],
        "physical_constants_derived": {
            "spring_omega_rad_per_s": round(omega, 4),
            "spring_period_s": round(T, 4),
            "deceleration_mug_m_s2": round(mu_floor * g, 4),
            "v0_initial_m_s": v0
        },
        "numerical_method": {
            "solver": "scipy.integrate.solve_ivp (RK45) with terminal contact event for 1-2 collision; tanh-regularized friction.",
            "tolerance": "rtol=1e-9, atol=1e-11; max_step=5e-3",
            "justification": "Hybrid: smooth ODE between collisions + impulsive restitution at contact."
        },
        "code_validation": {
            "ode_source": "Newton + Hooke + Coulomb + Newton restitution.",
            "energy_check": "KE+PE non-increasing; momentum conserved at impulsive collisions.",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Block 1 decelerates and strikes block 2 around t = {abs((params['x2_0']-params['x1_0'])/v0):.2f} s.",
            f"Spring oscillation between blocks 2 and 3 with period ~{T:.2f} s.",
            "Possible re-collision between blocks 1 and 2 if spring rebounds 2 backward."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# bouncing_rod
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_bouncing_rod(params):
    L = params["L"]
    m = params["m"]
    g = params["g"]
    e_rest = params["e_rest"]
    mu = params["mu"]
    xc0 = params["xc0"]
    yc0 = params["yc0"]
    theta0 = params["theta0"]
    vx0 = params["vx0"]
    vy0 = params["vy0"]
    omega0 = params["omega0"]

    I_cm = m * L * L / 12.0
    energy_loss_normal = 1 - e_rest * e_rest
    drop_h = max(yc0 - (L / 2) * abs(math.sin(theta0)), 0.0)
    t_first = math.sqrt(2.0 * drop_h / g) if drop_h > 0 else 0.0
    theta_deg = theta0 * 180.0 / math.pi

    return {
        "simulation": "bouncing_rod",
        "physical_observation": (
            f"A thin rigid rod of length L={L:.3f} m and mass m={m:.3f} kg is released at "
            f"angle theta0={theta_deg:.2f} deg above horizontal with COM height yc={yc0:.3f} m. "
            f"It is given a small horizontal drift vx={vx0:.3f} m/s, vertical velocity vy={vy0:.3f} m/s "
            f"and spin omega={omega0:.3f} rad/s. It falls under gravity g={g:.3f} m/s^2 and impacts a "
            f"flat ground with restitution e={e_rest:.3f} and Coulomb friction mu={mu:.3f}."
        ),
        "physical_law": {
            "name": "Newton II for a planar rigid body + impulse-momentum theorem with Newton's restitution and Coulomb friction",
            "statement": "Between contacts the COM is in projectile motion (m r_c'' = (0,-mg)) and orientation evolves at constant angular velocity (I theta'' = 0). At an instantaneous endpoint contact, an impulse J=(J_t,J_n) at the contact point updates linear and angular momenta; the normal component is set by Newton's restitution and the tangential component is bounded by the Coulomb cone.",
            "formula": "free flight: m r_c''=(0,-mg), I theta''=0; contact: J_n = -(1+e)*v_ey/(1/m + r_x^2/I), |J_t| <= mu*|J_n|; dv_c = J/m, domega = (r_x J_n - r_y J_t)/I",
        },
        "ode_system": {
            "state_variables": [
                "x_c (COM x, m)", "y_c (COM y, m)", "theta (orientation from horizontal, rad)",
                "v_x (m/s)", "v_y (m/s)", "omega (rad/s)",
            ],
            "equations_python": [
                "dxc/dt = vx",
                "dyc/dt = vy",
                "dtheta/dt = omega",
                "dvx/dt = 0.0",
                "dvy/dt = -g",
                "domega/dt = 0.0",
                "# impulsive at contact y_e=0 with v_ey<0:",
                f"Jn = -(1+{e_rest})*vp_y / (1/{m} + rx**2/{I_cm:.6f})",
                f"Jt = clip(-vp_x/(1/{m} + ry**2/{I_cm:.6f}), -{mu}*Jn, {mu}*Jn)",
                "vx += Jt/m;  vy += Jn/m;  omega += (rx*Jn - ry*Jt)/I_cm",
            ],
        },
        "derivation_steps": [
            f"Rod length L={L:.3f} m, mass m={m:.3f} kg.  Moment of inertia about COM: I = m L^2/12 = {I_cm:.5f} kg m^2.",
            "Endpoint positions: e_+- = (x_c +- (L/2) cos theta, y_c +- (L/2) sin theta).",
            "Endpoint velocities: v_e_x = v_x - r_y omega, v_e_y = v_y + r_x omega, with r=(r_x,r_y) the contact lever arm from COM.",
            f"Free flight: ddot x_c = 0, ddot y_c = -g = {-g:.3f}, ddot theta = 0.",
            f"Contact event: when y_e = 0 and v_ey < 0, apply impulse (J_t, J_n).  Newton restitution: J_n = -(1+e)*v_ey / (1/m + r_x^2/I) with e = {e_rest}.",
            f"Coulomb friction cone: |J_t| <= mu * |J_n| with mu = {mu}.  Stick candidate: J_t_stk = -v_ex / (1/m + r_y^2/I); clamp to the cone.",
            f"Each normal impulse loses fraction 1 - e^2 = {energy_loss_normal:.4f} of the normal kinetic energy at contact.",
            f"First-contact estimate (lower endpoint reaches ground): t1 ~ sqrt(2*(yc - (L/2)*|sin theta0|)/g) = {t_first:.3f} s.",
        ],
        "physical_constants_derived": {
            "I_cm_kg_m2": I_cm,
            "energy_loss_fraction_per_bounce_normal": energy_loss_normal,
            "first_endpoint_contact_time_s_estimate": t_first,
        },
        "numerical_method": {
            "solver": "Hybrid: scipy.integrate.solve_ivp (RK45) on the smooth free-flight ODE with two terminal events tracking endpoints reaching y=0 from above; analytic impulse update at every event, then RK45 resumes.",
            "tolerance": "rtol=1e-9, atol=1e-11; max_step=0.02 s",
            "justification": "Velocity is piecewise-continuous with impulsive jumps; treating those analytically is more robust than asking RK45 to resolve a near-discontinuous RHS.",
        },
        "code_validation": {
            "ode_source": "Newton II for rigid-body translation + Euler's rotation equation; impulse-momentum at contact (decoupled normal/tangent Coulomb collision matches standard rigid-body engines).",
            "energy_check": "Between impacts E = (1/2) m (v_x^2+v_y^2) + (1/2) I omega^2 + m g y_c is conserved; each impulse dissipates a non-negative amount.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Lower endpoint reaches ground in t ~ {t_first:.3f} s.",
            f"Each bounce loses ~{energy_loss_normal*100:.1f}% of normal KE; bouncing dies out within several impacts.",
            f"Coulomb friction (mu={mu:.2f}) damps horizontal drift and tangential motion at every contact.",
            "Final state: rod horizontal, y_c = 0, v_x = v_y = omega = 0.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# brachistochrone_race
# ────────────────────────────────────────────────────────────────────────────
import math
from scipy.optimize import brentq


def cot_brachistochrone_race(params):
    H = params["H"]
    D = params["D"]
    g = params["g"]
    ball_radius = params.get("ball_radius", 0.10)

    theta_e = brentq(lambda th: (th - math.sin(th)) / (1.0 - math.cos(th)) - D / H,
                     1e-6, 2.0 * math.pi - 1e-6, xtol=1e-12)
    R = H / (1.0 - math.cos(theta_e))
    T_brach = math.sqrt(R / g) * theta_e
    L_chord = math.sqrt(D * D + H * H)
    T_straight = math.sqrt(2.0 * L_chord * L_chord / (g * H))
    a_chord = g * H / L_chord
    delta_T = T_straight - T_brach

    return {
        "simulation": "brachistochrone_race",
        "physical_observation": (
            f"Two identical point-mass beads start at rest at A=(0,H) on a vertical wall (H={H:.3f} m) "
            f"and slide frictionlessly under gravity (g={g:.3f} m/s^2) to B=(D,0) on the floor (D={D:.3f} m). "
            f"One descends along the straight chord A->B; the other along the brachistochrone (cycloid arc). "
            f"The cycloid bead reaches B first; both then rest at B."
        ),
        "physical_law": {
            "name": "Brachistochrone problem (Bernoulli, 1696) and energy conservation on a frictionless ramp",
            "statement": "Among smooth curves connecting two points in a uniform gravitational field, the cycloid with cusp at A minimises the time of descent of a bead released from rest. v=sqrt(2 g h) on any frictionless wire.",
            "formula": "Cycloid: x=R(theta-sin theta), y=H-R(1-cos theta); endpoint: (theta_e-sin theta_e)/(1-cos theta_e)=D/H, R=H/(1-cos theta_e); theta(t)=sqrt(g/R) t; T_brach=sqrt(R/g) theta_e. Chord: L=sqrt(D^2+H^2), a=g H/L, T_straight=sqrt(2 L^2/(g H)).",
        },
        "ode_system": {
            "state_variables": [
                "theta(t): cycloid parameter (rad)",
                "s(t): arc length along the chord (m)",
            ],
            "equations_python": [
                f"theta(t) = sqrt(g/R)*t,  R={R:.6f},  clamp at theta_e={theta_e:.6f}",
                "x_cyc(t) = R*(theta - sin(theta));  y_cyc(t) = H - R*(1 - cos(theta))",
                f"s(t) = 0.5*(g*H/L)*t**2 = 0.5*{a_chord:.5f}*t**2,  clamp at L={L_chord:.6f}",
                "x_str(t) = (D/L)*s;  y_str(t) = H - (H/L)*s",
            ],
        },
        "derivation_steps": [
            f"A=(0,{H:.3f}), B=({D:.3f},0).  Gravity g={g:.3f}.",
            "Cycloid with cusp at A:  x=R(theta-sin theta), y=H-R(1-cos theta).  Endpoint constraints  R(theta_e-sin theta_e)=D, R(1-cos theta_e)=H  give  (theta_e-sin theta_e)/(1-cos theta_e)=D/H.",
            f"Numerical brentq solve: theta_e = {theta_e:.5f} rad ({math.degrees(theta_e):.2f} deg).  R = {R:.5f} m.",
            f"Energy conservation along the cycloid yields (d theta/dt)^2 = g/R, so theta(t) = sqrt(g/R) t and T_brach = sqrt(R/g) theta_e = {T_brach:.4f} s.",
            f"Chord A->B: L = sqrt(D^2+H^2) = {L_chord:.4f} m, sin alpha = H/L, a = g*H/L = {a_chord:.4f} m/s^2.",
            f"s(t) = (1/2) a t^2; T_straight = sqrt(2L^2/(gH)) = {T_straight:.4f} s.  Difference Delta T = {delta_T:.4f} s, so cycloid wins.",
        ],
        "physical_constants_derived": {
            "theta_e_rad": theta_e,
            "theta_e_deg": math.degrees(theta_e),
            "R_m": R,
            "T_brach_s": T_brach,
            "T_straight_s": T_straight,
            "delta_T_s": delta_T,
            "chord_length_L_m": L_chord,
            "chord_along_ramp_acceleration_m_s2": a_chord,
        },
        "numerical_method": {
            "solver": "scipy.optimize.brentq for the cycloid endpoint equation; closed-form kinematics for both beads.",
            "tolerance": "brentq xtol=1e-12 on theta_e in (1e-6, 2*pi - 1e-6).",
            "justification": "Both motions are integrable in closed form; sampling x(t),y(t) on the time grid avoids ODE-integrator drift.",
        },
        "code_validation": {
            "ode_source": "Cycloid endpoint equations and closed-form kinematics on chord and cycloid.",
            "energy_check": "(1/2)(ds/dt)^2 = g(H - y) holds identically on the cycloid given theta(t)=sqrt(g/R)t.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Both beads start at A; cycloid bead reaches B at t ~ {T_brach:.3f} s.",
            f"Chord bead reaches B at t ~ {T_straight:.3f} s, ~{delta_T:.3f} s later.",
            "After arrival, beads rest at B for the remainder of the window.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# cart_two_metronomes
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_cart_two_metronomes(params):
    g = params["g"]
    M = params["M"]
    m1 = params["m_1"]; m2 = params["m_2"]
    L1 = params["L_1"]; L2 = params["L_2"]
    b1 = params["b_1"]; b2 = params["b_2"]
    dx1 = params["dx_1"]; dx2 = params["dx_2"]
    h_pivot = params["h_pivot"]
    th1 = params["theta1_0"]; th2 = params["theta2_0"]
    M_tot = M + m1 + m2
    T1 = 2 * math.pi * math.sqrt(L1 / g)
    T2 = 2 * math.pi * math.sqrt(L2 / g)

    return {
        "simulation": "cart_two_metronomes",
        "physical_observation": (
            f"A cart (M={M:.3f} kg) on frictionless rails carries two pendulums of length "
            f"L1={L1:.3f} m, L2={L2:.3f} m and bob masses m1={m1:.3f} kg, m2={m2:.3f} kg, "
            f"with pivots at x-offsets dx1={dx1:.3f} m and dx2={dx2:.3f} m. The pendulums are "
            f"released at theta1={th1:.3f} rad and theta2={th2:.3f} rad. Cart motion couples them; "
            f"viscous angular damping b1={b1:.4f}, b2={b2:.4f} dissipates energy."
        ),
        "physical_law": {
            "name": "Lagrangian mechanics + horizontal-momentum conservation",
            "statement": "Generalised coordinates (X, theta1, theta2). The Euler-Lagrange equations yield a 3x3 mass matrix system; with frictionless rails horizontal momentum is conserved.",
            "formula": "M_tot Xdd + sum_i m_i L_i cos(theta_i) theta_i_dd = sum_i m_i L_i sin(theta_i) w_i^2;  m_i L_i^2 theta_i_dd + m_i L_i cos(theta_i) Xdd = -m_i g L_i sin(theta_i) - b_i w_i",
        },
        "ode_system": {
            "state_variables": ["X (m)", "theta1 (rad)", "theta2 (rad)",
                                "Xdot (m/s)", "w1 (rad/s)", "w2 (rad/s)"],
            "equations_python": [
                "A = [[M_tot, m1 L1 c1, m2 L2 c2], [m1 L1 c1, m1 L1^2, 0], [m2 L2 c2, 0, m2 L2^2]]",
                "b = [m1 L1 s1 w1^2 + m2 L2 s2 w2^2, -m1 g L1 s1 - b1 w1, -m2 g L2 s2 - b2 w2]",
                "[Xdd, t1dd, t2dd] = solve(A, b)",
            ],
        },
        "derivation_steps": [
            f"Total mass M_tot = M + m1 + m2 = {M_tot:.3f} kg.",
            "Bob i position: x_i = X + dx_i + L_i sin(theta_i),  y_i = h_pivot - L_i cos(theta_i).",
            "Form Lagrangian L = T - V with T = (1/2) M Xdot^2 + sum_i (1/2) m_i [vx_i^2 + vy_i^2], V = -sum_i m_i g L_i cos(theta_i).",
            "Euler-Lagrange equations give a 3x3 linear-in-accelerations system; solve at every RHS call.",
            f"Pendulum natural periods (small angle): T1 = 2 pi sqrt(L1/g) = {T1:.3f} s, T2 = 2 pi sqrt(L2/g) = {T2:.3f} s.",
            "Damping is Rayleigh dissipation per pendulum: -b_i theta_i_dot.",
            "Horizontal momentum P_x = M_tot Xdot + sum_i m_i L_i cos(theta_i) w_i is conserved.",
        ],
        "physical_constants_derived": {
            "M_tot_kg": M_tot,
            "T1_natural_s": T1,
            "T2_natural_s": T2,
        },
        "numerical_method": {
            "solver": "scipy.integrate.solve_ivp (RK45) on the 6-D state; numpy.linalg.solve for the 3x3 mass matrix at each RHS evaluation.",
            "tolerance": "rtol=1e-9, atol=1e-11.",
            "justification": "Smooth ODE; mass matrix is well-conditioned for moderate angles.",
        },
        "code_validation": {
            "ode_source": "Lagrangian for cart + two pendulums; standard derivation.",
            "energy_check": (
                "With damping, mechanical energy is dissipated. Horizontal momentum would be conserved "
                "only in the ideal undamped, force-free support direction; damping/support forces in the "
                "implemented model remove horizontal momentum from the cart-pendulum subsystem."
            ),
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Two oscillators with periods ~ {T1:.2f} s and {T2:.2f} s exchange energy via cart motion.",
            "Cart drifts/recoils to keep horizontal momentum constant.",
            "Damping eventually settles both pendulums to equilibrium.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# colliding_blocks
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_colliding_blocks(params):
    m1 = params["m1"]; s1 = params["s1"]
    m2 = params["m2"]; s2 = params["s2"]
    e_w = params["e_w"]; e_b = params["e_b"]
    x1_0 = params["x1_0"]; v1_0 = params["v1_0"]
    x2_0 = params["x2_0"]; v2_0 = params["v2_0"]

    ratio = m2 / m1
    if e_w == 1.0 and e_b == 1.0:
        try:
            N_predicted = int(math.floor(math.pi / math.atan(math.sqrt(m1 / m2))))
        except Exception:
            N_predicted = -1
    else:
        N_predicted = -1

    KE0 = 0.5 * m1 * v1_0 ** 2 + 0.5 * m2 * v2_0 ** 2
    p0 = m1 * v1_0 + m2 * v2_0

    return {
        "simulation": "colliding_blocks",
        "physical_observation": (
            f"A small block (m1={m1:.3f} kg, side s1={s1:.3f} m) at rest on a frictionless surface "
            f"sits at x1_0={x1_0:.3f} m to the right of a vertical wall at x=0. A larger block "
            f"(m2={m2:.3f} kg, side s2={s2:.3f} m) starts at x2_0={x2_0:.3f} m moving toward the wall "
            f"with v2_0={v2_0:.3f} m/s. Wall restitution e_w={e_w}; block-block restitution e_b={e_b}. "
            f"Mass ratio m2/m1 = {ratio:.3f}."
        ),
        "physical_law": {
            "name": "Conservation of momentum and energy at impulsive contacts (Newton restitution)",
            "statement": "Between contacts, free motion (no friction).  Block-wall and block-block collisions are instantaneous impulses governed by Newton restitution.",
            "formula": "wall: v1 -> -e_w v1.  block-block: v1' = ((m1 - e_b m2) v1 + (1+e_b) m2 v2)/(m1+m2), v2' = ((m2 - e_b m1) v2 + (1+e_b) m1 v1)/(m1+m2).",
        },
        "ode_system": {
            "state_variables": ["x1 (m)", "v1 (m/s)", "x2 (m)", "v2 (m/s)"],
            "equations_python": [
                "dx1/dt = v1; dv1/dt = 0",
                "dx2/dt = v2; dv2/dt = 0",
                "# wall event: x1 - s1/2 = 0 with v1<0",
                f"v1 <- -{e_w} * v1",
                "# block-block event: (x2 - s2/2) - (x1 + s1/2) = 0",
                f"v1, v2 <- ((m1 - {e_b}*m2)*v1 + (1+{e_b})*m2*v2)/(m1+m2),  ((m2 - {e_b}*m1)*v2 + (1+{e_b})*m1*v1)/(m1+m2)",
            ],
        },
        "derivation_steps": [
            f"Initial momentum: m1 v1_0 + m2 v2_0 = {p0:.4f} kg m/s.",
            f"Initial kinetic energy: KE0 = (1/2) m1 v1_0^2 + (1/2) m2 v2_0^2 = {KE0:.4f} J.",
            "Free motion between events: each block coasts at constant velocity.",
            f"Wall event (v1 -> -{e_w} v1) flips small-block velocity (with restitution).",
            "Block-block event applies the 1D Newton-restitution collision laws (above).",
            f"For elastic e=1, total KE and momentum (between contacts) are exactly conserved; total collision count is N = floor(pi / atan(sqrt(m1/m2))) = {N_predicted} (Galperin 2003).",
        ],
        "physical_constants_derived": {
            "mass_ratio_m2_over_m1": ratio,
            "initial_kinetic_energy_J": KE0,
            "initial_momentum_kg_m_s": p0,
            "predicted_total_collisions_if_elastic": N_predicted,
        },
        "numerical_method": {
            "solver": "Hybrid free-flight RK45 (scipy.solve_ivp) with two terminal events (wall, block-block); analytic impulse jumps applied at each contact.",
            "tolerance": "rtol=1e-9, atol=1e-11; max_step=0.05 s.",
            "justification": "Velocities have impulsive jumps; analytic event handling avoids near-discontinuous RHS issues.",
        },
        "code_validation": {
            "ode_source": "1D Newton-restitution collisions; standard textbook formulas.",
            "energy_check": "For e_w=e_b=1, sum (1/2 m_i v_i^2) is conserved exactly between contacts.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            "Large block approaches, hits small block, which bounces between large block and wall.",
            f"Predicted collisions (elastic): {N_predicted}.",
            "Eventually small block is moving rightward faster than large block and they separate; large block recoils toward +x.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# compound_atwood
# ────────────────────────────────────────────────────────────────────────────
def cot_compound_atwood(params):
    m1 = params["m1"]; m2 = params["m2"]; m3 = params["m3"]; g = params["g"]
    T_B = 4.0 * g / (1.0/m2 + 1.0/m3 + 4.0/m1)
    T_A = 2.0 * T_B
    a1 = g - T_A / m1
    a2 = g - T_B / m2
    a3 = g - T_B / m3
    aB = -a1

    return {
        "simulation": "compound_atwood",
        "physical_observation": (
            f"Compound (double) Atwood machine: a fixed pulley A on the ceiling carries a string with "
            f"mass m1={m1:.3f} kg on one side and the axle of a movable pulley B on the other. A rope "
            f"over B carries mass m2={m2:.3f} kg and m3={m3:.3f} kg. Gravity g={g:.3f} m/s^2 drives the "
            f"system; all motions start from rest."
        ),
        "physical_law": {
            "name": "Newton II + massless inextensible-cord constraints + massless pulleys",
            "statement": "Each mass obeys m_i ÿ_i = m_i g - T_i; the cord constraints couple accelerations; a massless movable pulley enforces T_A = 2 T_B.",
            "formula": "T_B = 4 g / (1/m2 + 1/m3 + 4/m1); T_A = 2 T_B; a_i = g - T_i/m_i; a_B = -a_1.",
        },
        "ode_system": {
            "state_variables": ["y1, y2, y3 (cube depths, m, +y down)", "yB (movable pulley depth)"],
            "equations_python": [
                "dy_i/dt = v_i; dv_i/dt = a_i (constants)",
                f"a1 = {a1:.6f}; a2 = {a2:.6f}; a3 = {a3:.6f}; aB = {aB:.6f}",
            ],
        },
        "derivation_steps": [
            f"Massless movable pulley B: tension balance gives T_A = 2 T_B (so T_A = {T_A:.4f} N, T_B = {T_B:.4f} N).",
            "Constraint on string A:  y1 + yB = const  =>  ÿ1 + ÿB = 0  =>  a_B = -a_1.",
            "Constraint on rope B:  (y2 - yB) + (y3 - yB) = const  =>  a_2 + a_3 - 2 a_B = 0.",
            "Newton II for each mass (down = +): m_i ÿ_i = m_i g - T_i (T_1 = T_A on m1; T_2 = T_3 = T_B on m2, m3).",
            "Solving the linear system yields T_B = 4 g / (1/m2 + 1/m3 + 4/m1).",
            f"Therefore a_1 = {a1:+.4f} m/s^2, a_2 = {a2:+.4f}, a_3 = {a3:+.4f}, a_B = {aB:+.4f}.",
        ],
        "physical_constants_derived": {
            "T_A_N": T_A,
            "T_B_N": T_B,
            "a_1_m_s2": a1,
            "a_2_m_s2": a2,
            "a_3_m_s2": a3,
            "a_B_m_s2": aB,
        },
        "numerical_method": {
            "solver": "Closed form (constant accelerations); positions are quadratic in t. No ODE integrator required.",
            "tolerance": "Machine precision.",
            "justification": "All four accelerations are time-independent, so y_i(t) = y_i_0 + v_i_0 t + 0.5 a_i t^2.",
        },
        "code_validation": {
            "ode_source": "Newton II for three point masses with two cord constraints and a tension ratio T_A=2 T_B.",
            "energy_check": "ΣKE - ΣPE evolves consistent with constant accelerations (no friction).",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Mass with the largest a_i descends fastest. a_1, a_2, a_3, a_B = {a1:+.3f}, {a2:+.3f}, {a3:+.3f}, {aB:+.3f} m/s^2.",
            "Motion stops in the render once the descender reaches the floor.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# conveyor_belt_drop
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_conveyor_belt_drop(params):
    g = params["g"]
    v_belt = params["v_belt"]
    mu_belt = params["mu_belt"]; mu_floor = params["mu_floor"]
    m = params["m_cube"]
    x_drop = params["x_drop"]
    y_drop_top = params["y_drop_top"]
    cube = params["cube_size"]
    y_belt_top = params["y_belt_top"]
    x_bl = params["x_belt_left"]; x_br = params["x_belt_right"]

    fall1 = (y_drop_top - cube) - y_belt_top
    t1 = math.sqrt(max(2.0 * fall1 / g, 0.0))
    a_f = mu_belt * g
    t2 = v_belt / a_f if a_f > 0 else 0.0
    dx2 = 0.5 * a_f * t2 ** 2
    x_p3 = x_drop + dx2
    t3 = max(0.0, (x_br - x_p3) / v_belt) if v_belt > 0 else 0.0
    fall4 = y_belt_top
    t4 = math.sqrt(2.0 * fall4 / g)
    dx4 = v_belt * t4
    a_fl = mu_floor * g
    t5 = v_belt / a_fl if a_fl > 0 else 0.0
    dx5 = v_belt ** 2 / (2.0 * a_fl) if a_fl > 0 else 0.0

    return {
        "simulation": "conveyor_belt_drop",
        "physical_observation": (
            f"A cube (m={m:.3f} kg, side={cube:.3f} m) is dropped from height y_drop_top={y_drop_top:.3f} m above "
            f"a conveyor belt whose top is at y={y_belt_top:.3f} m and runs at v_belt={v_belt:.3f} m/s rightward. "
            f"Coulomb friction mu_belt={mu_belt}, mu_floor={mu_floor} couples cube to belt and to the floor. "
            f"Cube exits the belt's right edge at x={x_br:.3f} m, falls to the floor, and slides to rest."
        ),
        "physical_law": {
            "name": "Newton II + Coulomb kinetic friction + perfectly inelastic vertical contact",
            "statement": "Vertical free fall under gravity; friction f = mu_k m g acts to oppose relative slip; cube does not bounce vertically off the belt or floor.",
            "formula": "Free fall: y'' = -g.  Slipping on belt: vx' = mu_belt g.  No-slip ride: vx = v_belt.  Off belt: vx const, y free fall.  Floor slide: vx' = -mu_floor g until vx=0.",
        },
        "ode_system": {
            "state_variables": ["x_cube (m)", "y_cube (m)"],
            "equations_python": [
                "Phase 1 (drop):       y(t) = y0 - 0.5 g t^2; x = x_drop",
                f"Phase 2 (slipping):   vx' = mu_belt*g = {a_f:.4f}; ends when vx = v_belt = {v_belt}",
                "Phase 3 (riding):     x' = v_belt; y on belt top",
                "Phase 4 (off belt):   x' = v_belt; y free fall",
                f"Phase 5 (floor):      vx' = -mu_floor*g = -{a_fl:.4f}; stops at v=0",
            ],
        },
        "derivation_steps": [
            f"Phase 1 free fall through {fall1:.3f} m: t1 = sqrt(2 (y_drop_top - cube_size - y_belt_top)/g) = {t1:.4f} s.",
            f"Phase 2 slipping: cube starts at vx=0, belt moves at v_belt. Friction f = mu_belt m g pulls cube forward. a = mu_belt g = {a_f:.4f} m/s^2; t2 = v_belt/a = {t2:.4f} s; dx2 = {dx2:.4f} m.",
            f"Phase 3 no-slip: cube co-moves with belt at v_belt; remaining distance to right edge = {x_br - x_p3:.4f} m -> t3 = {t3:.4f} s.",
            f"Phase 4 off-belt projectile: vy free fall from y_belt_top to floor (drop {fall4:.3f} m); t4 = {t4:.4f} s; horizontal travel dx4 = {dx4:.4f} m.",
            f"Phase 5 floor friction: deceleration a_fl = mu_floor g = {a_fl:.4f}; t5 = {t5:.4f} s; dx5 = v_belt^2/(2 a_fl) = {dx5:.4f} m.",
        ],
        "physical_constants_derived": {
            "t1_drop_s": t1,
            "t2_slip_s": t2,
            "t3_ride_s": t3,
            "t4_fall_s": t4,
            "t5_floor_slide_s": t5,
            "dx2_slip_m": dx2,
            "dx4_off_belt_m": dx4,
            "dx5_floor_m": dx5,
            "final_x_m": x_br + dx4 + dx5,
        },
        "numerical_method": {
            "solver": "Closed-form per phase; no ODE solver needed.",
            "tolerance": "Machine precision.",
            "justification": "Each phase has constant acceleration with analytic transition times.",
        },
        "code_validation": {
            "ode_source": "Newton II for each phase; standard friction-on-belt textbook problem.",
            "energy_check": "KE evolves consistent with the work-energy theorem; friction dissipates KE while belt does positive work in phase 2.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Drop, then slip on belt for ~{t2:.3f} s, ride to right edge, projectile to floor in ~{t4:.3f} s, and stop after ~{t5:.3f} s on the floor.",
            f"Final cube rest position x ~ {x_br + dx4 + dx5:.3f} m.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# cylinder_piston_ball
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_cylinder_piston_ball(params):
    g = params["g"]
    m_b = params["m_b"]; m_p = params["m_p"]
    r_b = params["r_b"]; D = params["D_cyl"]; t_p = params["t_p"]
    H = params["H_cyl"]
    y_b_0 = params["y_b_0"]; y_p_bot_0 = params["y_p_bot_0"]
    e_floor = params["e_floor"]; e_bp = params["e_bp"]

    drop_b = max(y_b_0 - r_b, 0.0)
    t1_floor = math.sqrt(2.0 * drop_b / g) if drop_b > 0 else 0.0
    drop_p_to_ball = max(y_p_bot_0 - (y_b_0 + r_b), 0.0)
    t1_bp = math.sqrt(2.0 * drop_p_to_ball / g) if drop_p_to_ball > 0 else 0.0

    return {
        "simulation": "cylinder_piston_ball",
        "physical_observation": (
            f"Inside a vertical cylinder (inner diameter D={D:.3f} m, height H={H:.3f} m, closed bottom) "
            f"a small ball (m_b={m_b:.3f} kg, r_b={r_b:.3f} m) starts at y={y_b_0:.3f} m and a piston "
            f"(m_p={m_p:.3f} kg, thickness t_p={t_p:.3f} m) starts with its bottom at y={y_p_bot_0:.3f} m. "
            f"Both released from rest under gravity g={g:.3f} m/s^2; ball-floor restitution e_floor={e_floor}, "
            f"ball-piston restitution e_bp={e_bp}."
        ),
        "physical_law": {
            "name": "Newton II in 1D + impulsive Newton restitution at contacts",
            "statement": "Between contacts, both bodies free-fall.  Floor and ball-piston collisions are instantaneous impulses governed by Newton's restitution law.",
            "formula": "Free fall: v_i' = -g.  Floor: v_b -> -e_floor v_b.  Ball-piston: v_b' = ((m_b-e_bp m_p)v_b + (1+e_bp)m_p v_p)/(m_b+m_p), v_p' = ((m_p-e_bp m_b)v_p + (1+e_bp)m_b v_b)/(m_b+m_p).",
        },
        "ode_system": {
            "state_variables": ["y_b (ball centre y)", "y_p_bot (piston bottom y)", "v_b", "v_p"],
            "equations_python": [
                "dy_b/dt = v_b; dy_p_bot/dt = v_p; dv_b/dt = -g; dv_p/dt = -g",
                "Floor event: y_b - r_b = 0 with v_b<0 -> v_b *= -e_floor",
                "Ball-piston event: y_p_bot - y_b - r_b = 0 with v_b>v_p -> apply Newton-restitution formulas above",
            ],
        },
        "derivation_steps": [
            f"Initial heights: ball at {y_b_0:.3f} m, piston bottom at {y_p_bot_0:.3f} m.",
            f"Free-fall time of ball to floor (no piston): t ~ sqrt(2 (y_b_0-r_b)/g) = {t1_floor:.3f} s.",
            f"Initial gap piston-ball: {drop_p_to_ball:.3f} m; piston catches up to ball after t ~ sqrt(2 gap/g) = {t1_bp:.3f} s (if ball were stationary).",
            "Each ball-floor impact reduces ball |v| by factor (1-e_floor) of the kinetic energy; each ball-piston impact transfers momentum/energy by the 1D Newton-restitution formulas.",
            "System eventually settles to ball at rest on floor and piston resting on ball.",
        ],
        "physical_constants_derived": {
            "free_fall_to_floor_s": t1_floor,
            "free_fall_to_piston_meet_s_if_ball_stationary": t1_bp,
            "expected_final_y_b": r_b,
            "expected_final_y_p_bot": 2.0 * r_b,
        },
        "numerical_method": {
            "solver": "Hybrid free-fall RK45 (scipy.solve_ivp) with three terminal events (ball-floor, ball-piston, piston-floor); analytic impulses at each event.",
            "tolerance": "rtol=1e-9, atol=1e-11; max_step=0.02 s.",
            "justification": "Velocities have impulsive jumps; analytic event handling avoids near-discontinuous RHS issues.",
        },
        "code_validation": {
            "ode_source": "Newton II + standard 1D restitution formulas (textbook).",
            "energy_check": "Each restitution event dissipates a non-negative amount of KE; total energy decreases monotonically.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            "Ball bounces on the floor several times while piston falls slower than ball-bounces.",
            "Eventually piston catches ball, dissipating energy through ball-piston impacts.",
            "System settles with ball resting on floor and piston resting on ball.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# discs_friction_coupling
# ────────────────────────────────────────────────────────────────────────────
def cot_discs_friction_coupling(params):
    m1 = params["m_1"]; m2 = params["m_2"]
    R1 = params["R_1"]; R2 = params["R_2"]
    om1 = params["omega_1_0"]; om2 = params["omega_2_0"]
    mu = params["mu_k"]; F_n = params["F_n"]
    gap = params["gap_0"]; v_approach = params["approach_speed"]
    I1 = 0.5 * m1 * R1 ** 2
    I2 = 0.5 * m2 * R2 ** 2
    s0 = -(om1 * R1 + om2 * R2)
    denom = mu * F_n * (R1 ** 2 / I1 + R2 ** 2 / I2)
    delta_t_slip = abs(s0) / denom if denom > 0 else 0.0
    t_app = gap / v_approach
    sign_s0 = 1.0 if s0 > 0 else (-1.0 if s0 < 0 else 0.0)
    a1 = R1 * mu * F_n * sign_s0 / I1
    a2 = R2 * mu * F_n * sign_s0 / I2
    om1_f = om1 + a1 * delta_t_slip
    om2_f = om2 + a2 * delta_t_slip

    return {
        "simulation": "discs_friction_coupling",
        "physical_observation": (
            f"Top-down view: two solid discs (m1={m1:.3f} kg, R1={R1:.3f} m; m2={m2:.3f} kg, R2={R2:.3f} m) "
            f"spin CCW at omega1_0={om1:.3f} rad/s and omega2_0={om2:.3f} rad/s on parallel axles. "
            f"Disc 2 axle is translated toward disc 1 at v_approach={v_approach:.3f} m/s across an initial "
            f"gap of {gap:.3f} m, then F_n={F_n:.3f} N presses the rims with friction mu_k={mu:.3f}, coupling "
            f"the spins until omega_1 R_1 + omega_2 R_2 = 0."
        ),
        "physical_law": {
            "name": "Newton II for rotation + Coulomb kinetic friction",
            "statement": "Each disc obeys I theta'' = R * mu_k * F_n * sign(slip), with the friction torque opposing rim slip. The no-slip condition is omega_1 R_1 + omega_2 R_2 = 0 (gear-like).",
            "formula": "I_i = (1/2) m_i R_i^2; s = -(omega_1 R_1 + omega_2 R_2); ds/dt = -mu_k F_n (R_1^2/I_1 + R_2^2/I_2) sign(s).",
        },
        "ode_system": {
            "state_variables": ["theta_1, theta_2 (rad)", "omega_1, omega_2 (rad/s)", "X_2 (axle x, m)"],
            "equations_python": [
                f"X_2(t) = X_2_initial - approach_speed * t,  for t < t_approach = {t_app:.4f}",
                f"omega_i(t) = omega_i_0 + alpha_i * (t - t_approach),  alpha_1 = {a1:.4f}, alpha_2 = {a2:.4f}",
                f"slip ends at t_no_slip = t_approach + |s_0|/[mu_k F_n (R1^2/I1 + R2^2/I2)] = {t_app + delta_t_slip:.4f}",
                f"after no-slip: omega_1 = {om1_f:.4f}, omega_2 = {om2_f:.4f}",
            ],
        },
        "derivation_steps": [
            f"I_1 = (1/2) m_1 R_1^2 = {I1:.5f} kg m^2;  I_2 = (1/2) m_2 R_2^2 = {I2:.5f} kg m^2.",
            f"At first contact, the slip velocity at the rim contact point is s_0 = -(omega_1 R_1 + omega_2 R_2) = {s0:.4f} m/s.",
            "Friction force at contact has magnitude mu_k F_n; its torque on disc i has magnitude R_i mu_k F_n with sign so as to oppose s.",
            f"Therefore alpha_i = R_i mu_k F_n sign(s) / I_i: alpha_1 = {a1:+.4f}, alpha_2 = {a2:+.4f} rad/s^2.",
            f"ds/dt = -(R_1^2/I_1 + R_2^2/I_2) mu_k F_n sign(s) is constant in magnitude; slip duration delta_t_slip = |s_0|/denom = {delta_t_slip:.4f} s.",
            f"Final angular velocities: omega_1 -> {om1_f:.4f}, omega_2 -> {om2_f:.4f} rad/s; check omega_1 R_1 + omega_2 R_2 = {(om1_f*R1 + om2_f*R2):.3e} ~ 0.",
        ],
        "physical_constants_derived": {
            "I_1_kg_m2": I1,
            "I_2_kg_m2": I2,
            "s_0_m_s": s0,
            "delta_t_slip_s": delta_t_slip,
            "t_no_slip_s": t_app + delta_t_slip,
            "omega_1_final_rad_s": om1_f,
            "omega_2_final_rad_s": om2_f,
        },
        "numerical_method": {
            "solver": "Closed-form per phase: phase 1 axle translation, phase 2 constant angular acceleration during slip, phase 3 constant angular velocity post-slip.",
            "tolerance": "Machine precision.",
            "justification": "Kinematics are constant-acceleration in each phase; closed-form is exact and avoids stiff ODE issues at the slip-stick transition.",
        },
        "code_validation": {
            "ode_source": "Newton II for rotation; Coulomb kinetic friction at the contact point.",
            "energy_check": "Total rotational KE strictly decreases during slip by mu_k F_n * |s| dt; constant after no-slip.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Approach phase lasts t_approach = {t_app:.3f} s.",
            f"Slip phase reduces |omega1 R1 + omega2 R2| to zero in delta_t_slip = {delta_t_slip:.3f} s.",
            f"After no-slip, both discs spin at constant {om1_f:.3f} and {om2_f:.3f} rad/s respectively.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# disk_spinoff
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_disk_spinoff(params):
    R = params["R_disk"]
    N = int(params["N_cubes"])
    om_max = params["omega_max"]
    t_ramp = params["t_ramp"]
    mu_s = params["mu_s_disk"]; mu_kd = params["mu_k_disk"]; mu_kf = params["mu_k_floor"]
    g = params["g"]
    cube_size = params["cube_size"]

    r_break = mu_s * g / (om_max ** 2) if om_max > 0 else float("inf")

    return {
        "simulation": "disk_spinoff",
        "physical_observation": (
            f"Top-down view: a disk of radius R={R:.3f} m spins from rest, ramping linearly to omega_max={om_max:.3f} "
            f"rad/s in t_ramp={t_ramp:.3f} s. {N} small cubes (side {cube_size:.3f} m) co-rotate with the disk; "
            f"once required centripetal force exceeds the static-friction limit (mu_s={mu_s}, g={g}), each cube slips "
            f"outward, crosses the rim, and decelerates on the floor under mu_k_floor={mu_kf} until it rests."
        ),
        "physical_law": {
            "name": "Newton II in 2D + Coulomb static/kinetic friction; static-friction limit at the cube-disk contact",
            "statement": "While stuck, friction supplies the centripetal+tangential force; once required acceleration exceeds mu_s g, kinetic friction f = mu_k m g acts opposite to relative slip velocity.",
            "formula": "Stuck-to-slip threshold: omega^2 r >= mu_s g (when alpha=0).  Slipping cube: a = -mu_k g v_rel/|v_rel|.  Floor cube: a = -mu_k_floor g v/|v|.",
        },
        "ode_system": {
            "state_variables": [
                "x_i, y_i (cube position, m)",
                "vx_i, vy_i (cube velocity, m/s)",
                "theta_i (cube orientation, rad)",
                "status_i in {STUCK, SLIPPING, FLOOR}",
            ],
            "equations_python": [
                "while STUCK and a_req <= mu_s*g: rotate position rigidly with disk; v = (-om y, om x).",
                "while SLIPPING: a = -mu_k_disk * g * v_rel/|v_rel|.",
                "after crossing R_disk: status=FLOOR; a = -mu_k_floor * g * v/|v|.",
            ],
        },
        "derivation_steps": [
            f"Disk angular velocity: omega(t) = omega_max * t/t_ramp for t<t_ramp, then omega_max.",
            f"At constant omega, a cube at radius r has centripetal acceleration omega^2 r. It detaches when omega^2 r > mu_s g, i.e., r > mu_s g / omega_max^2 = {r_break:.4f} m.",
            "During spin-up (t<t_ramp) the disk also has tangential acceleration alpha r; the required friction force is sqrt((omega^2 r)^2 + (alpha r)^2).",
            "Once slipping, kinetic friction f = mu_k_disk m g acts antiparallel to v_cube - v_disk_surface.",
            "Cube leaves the disk when x^2+y^2 >= R_disk^2; on the floor it decelerates by mu_k_floor g.",
        ],
        "physical_constants_derived": {
            "r_breakaway_at_max_omega_m": r_break,
        },
        "numerical_method": {
            "solver": "Fixed-step explicit Euler (dt=1e-3 s) on a 2D state per cube; analytic stuck/slip/floor branches.",
            "tolerance": "dt = 1 ms; eps = 1e-6 for velocity-zero snap.",
            "justification": "Simple to reason about and stable for the friction-limited dynamics over 12 s.",
        },
        "code_validation": {
            "ode_source": "Newton II in 2D; standard Coulomb friction (static cone for stick, kinetic vector for slip).",
            "energy_check": "Friction strictly reduces total KE during slip and on the floor.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Cubes initially co-rotate with the disk; as omega ramps up, those at r > {r_break:.3f} m slip first.",
            "Each slipping cube spirals outward, exits the disk, and slides on the floor until friction stops it.",
            "After several seconds all cubes that started outside r_breakaway have left the disk and come to rest.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# driven_string_fixed
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_driven_string_fixed(params):
    L = params["L"]; mu = params["mu"]; T = params["T"]
    A = params["A"]; f = params["f_drive"]; gamma_w = params["gamma_w"]
    c = math.sqrt(T / mu)
    omega = 2 * math.pi * f
    lam = c / f if f > 0 else float("inf")
    n_lambda = L / lam if lam > 0 else 0.0
    decay_length = c / gamma_w if gamma_w > 0 else float("inf")

    return {
        "simulation": "driven_string_fixed",
        "physical_observation": (
            f"A taut string of length L={L:.3f} m, density mu={mu:.4f} kg/m, tension T={T:.3f} N is fixed at "
            f"x=L and driven sinusoidally at x=0 with amplitude A={A:.3f} m and frequency f={f:.3f} Hz. "
            f"Phase speed c=sqrt(T/mu)={c:.3f} m/s; wavelength lambda=c/f={lam:.3f} m; ~{n_lambda:.2f} wavelengths fit in L. "
            f"Linear viscous damping gamma_w={gamma_w:.3f} 1/s gives decay length c/gamma_w={decay_length:.3f} m."
        ),
        "physical_law": {
            "name": "Damped wave equation on a string with Dirichlet BCs",
            "statement": "Small-amplitude transverse motion of a taut string obeys u_tt = c^2 u_xx - 2 gamma_w u_t with prescribed driver at the left end and zero displacement at the right end.",
            "formula": "u(0,t) = A sin(omega t);  u(L,t) = 0;  u_tt = c^2 u_xx - 2 gamma_w u_t,  c = sqrt(T/mu).",
        },
        "ode_system": {
            "state_variables": ["u(x_i, t) (transverse displacement at grid points)"],
            "equations_python": [
                "u^{n+1}_{j} = (1/(1+g dt))*(2 u^n_j - (1-g dt) u^{n-1}_j + (c dt/dx)^2 (u^n_{j+1} - 2 u^n_j + u^n_{j-1}))",
                "u^{n+1}_0 = A sin(omega t_{n+1});  u^{n+1}_N = 0",
            ],
        },
        "derivation_steps": [
            f"Phase speed c = sqrt(T/mu) = sqrt({T}/{mu}) = {c:.4f} m/s.",
            f"Driving angular frequency omega = 2 pi f = {omega:.4f} rad/s; wavelength lambda = c/f = {lam:.4f} m.",
            "Discretise u(x,t) on a uniform grid; use centred second differences in x and centred-time damping for stability.",
            "Apply Dirichlet BCs at every step: prescribed driver at j=0, zero at j=N.",
            f"CFL constraint: (c dt/dx)^2 < 1; using dt = 1/(fps * n_per_frame) so the simulation auto-tightens n_per_frame if needed.",
            f"Damping reduces wave amplitudes over a length scale c/gamma_w = {decay_length:.3f} m, ensuring the response remains bounded.",
        ],
        "physical_constants_derived": {
            "c_m_s": c,
            "omega_rad_s": omega,
            "lambda_m": lam,
            "n_wavelengths_in_L": n_lambda,
            "decay_length_m": decay_length,
        },
        "numerical_method": {
            "solver": "Explicit leapfrog FDM on a uniform grid with centred-time damping; CFL-stable when (c dt/dx)^2 < 1.",
            "tolerance": "Spatial second order; temporal second order; CFL margin enforced by adjusting n_per_frame.",
            "justification": "Hyperbolic PDE with smooth BCs; standard scheme provides good fidelity for the wavetrain and reflections.",
        },
        "code_validation": {
            "ode_source": "Damped wave equation in 1D with Dirichlet BCs.",
            "energy_check": "With damping, total energy decays smoothly; without damping the standing-wave envelope is steady.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Wavetrain emitted from x=0 propagates rightward at c={c:.3f} m/s; reflects from the fixed end with a 180-degree phase flip.",
            f"Outgoing + reflected waves superpose into an approximate standing wave with a node at x=L and antinodes spaced by lambda/2 = {lam/2:.3f} m.",
            f"After a few transit times (~L/c = {L/c:.3f} s), the response is nearly stationary in shape, modulated at omega.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# driven_string_ring
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_driven_string_ring(params):
    L = params["L"]; mu = params["mu"]; T = params["T"]; A = params["A"]
    f_drive = params["f_drive"]; gamma_w = params["gamma_w"]
    c = math.sqrt(T / mu)
    omega = 2 * math.pi * f_drive
    lam = c / f_drive
    n_lam = L / lam
    period = 1.0 / f_drive
    decay_len = c / gamma_w
    return {
        "simulation": "driven_string_ring",
        "physical_observation": (
            f"A taut string of length L={L:.3f} m, linear density mu={mu:.3f} kg/m, tension "
            f"T={T:.3f} N runs from a driven oscillator at x=0 to a frictionless ring on a "
            f"vertical rod at x=L. Driver: u(0,t) = A sin(omega t) with A={A:.3f} m, "
            f"f_drive={f_drive:.3f} Hz."
        ),
        "physical_law": {
            "name": "1-D Linear Wave Equation with Linear Viscous Damping; Driven Dirichlet (LEFT), Free-end Neumann (RIGHT)",
            "statement": "u_tt = c^2 u_xx - 2 gamma_w u_t with c = sqrt(T/mu); u(0,t) = A sin(omega t) (driver) and u_x(L,t) = 0 (free end via massless ring on frictionless rod).",
            "formula": "d^2u/dt^2 = c^2 d^2u/dx^2 - 2 gamma_w du/dt"
        },
        "ode_system": {
            "state_variables": ["u(x,t) -- transverse displacement, m"],
            "equations": [
                "u_tt = c^2 u_xx - 2 gamma_w u_t",
                "Driven BC: u(0,t) = A sin(2 pi f_drive t)",
                "Free BC: u_x(L,t) = 0 (Neumann via ghost-cell mirror)"
            ]
        },
        "derivation_steps": [
            "Newton II on a small string element: T u_xx dx = mu dx u_tt -> u_tt = c^2 u_xx with c=sqrt(T/mu).",
            "Linear viscous-damping term -2 gamma_w u_t bounds long-time amplitude under continuous driving.",
            "Massless ring on frictionless rod transmits no transverse force -> u_x(L,t) = 0 (free end).",
            "Discretise with explicit leapfrog FDM: (1+gamma_w dt) u_{i,n+1} = 2 u_{i,n} - (1-gamma_w dt) u_{i,n-1} + (c dt/dx)^2 lap.",
            "Free-end implementation: ghost cell u_{N+1} = u_{N-1}, so the laplacian at i=N becomes 2 (u_{N-1,n} - u_{N,n}).",
            "CFL: (c dt/dx)^2 < 1 must hold for stability; sub-step n_per_frame times per video frame."
        ],
        "physical_constants_derived": {
            "c_phase_speed_mps": round(c, 4),
            "lambda_wavelength_m": round(lam, 4),
            "n_wavelengths_in_L": round(n_lam, 4),
            "T_drive_period_s": round(period, 4),
            "decay_length_m": round(decay_len, 4)
        },
        "numerical_method": {
            "solver": "Explicit leapfrog FDM, second-order centred in time and space, with sub-stepping.",
            "tolerance": "Bit-exact within IEEE float; CFL must satisfy (c dt/dx)^2 < 1."
        },
        "code_validation": {
            "ode_source": "Standard 1-D wave equation with viscous damping; Dirichlet+Neumann BCs.",
            "energy_check": "Driver pumps energy in at x=0; gamma_w dissipation balances input in steady state so envelope saturates.",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Wavetrain forms and propagates rightward at c~{c:.3f} m/s.",
            f"Leading edge reaches the free end at t = L/c ~ {L/c:.3f} s and reflects WITHOUT phase inversion.",
            "After ~1-2 round trips a near-standing-wave pattern emerges; the ring is a displacement antinode."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# falling_spring
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_falling_spring(params):
    m1 = params["m1"]; m2 = params["m2"]; L0 = params["L0"]
    k = params["k"]; c = params["c"]
    theta0_deg = params["theta0_deg"]
    yCOM0 = params["yCOM0"]
    e_rest = params["e_rest"]; mu_fric = params["mu_fric"]
    cube_size = params["cube_size"]; g = params["g"]
    m_eff = m1 * m2 / (m1 + m2)
    omega_s = math.sqrt(k / m_eff)
    T_s = 2 * math.pi / omega_s
    theta0 = math.radians(theta0_deg)
    h_drop = max(yCOM0 - L0 / 2 * math.cos(theta0) - cube_size / 2, 0.001)
    t_fall = math.sqrt(2.0 * h_drop / g)
    return {
        "simulation": "falling_spring",
        "physical_observation": (
            f"Two cubes (m1={m1:.3f} kg, m2={m2:.3f} kg) connected by a Hookean spring "
            f"(rest length L0={L0:.3f} m, k={k:.2f} N/m, axial damping c={c:.3f} N*s/m) "
            f"start at COM height {yCOM0:.3f} m, tilted {theta0_deg:.2f} deg from vertical. "
            f"They fall under g={g:.2f}, bouncing off the floor with restitution e={e_rest:.3f} "
            f"and friction mu={mu_fric:.3f}."
        ),
        "physical_law": {
            "name": "Newton II per cube + Hooke's law for the spring + impulsive (penalty) floor contact with Coulomb friction",
            "statement": "Each cube obeys m a = F_spring + F_axial_damping + F_gravity + F_floor; floor contact is modelled as a stiff penalty spring-damper tuned to recover the requested coefficient of restitution.",
            "formula": "F_spring,1 = +k(L-L0) u_hat ; F_spring,2 = -F_spring,1 ; gravity (0, -m_i g)"
        },
        "ode_system": {
            "state_variables": ["x1,y1,x2,y2 (positions, m)", "vx1,vy1,vx2,vy2 (velocities, m/s)"],
            "equations": [
                "dx_i/dt = v_i; dv_i/dt = (F_spring + F_axial_damp + F_floor)/m_i + (0,-g)",
                "F_spring axial along bond direction; F_axial_damp opposes axial relative velocity",
                "F_floor: penalty spring-damper k_floor (pen) + c_floor (-vy) tuned via zeta -> e_rest, plus tangential mu_fric*Fn*tanh(vx/V_eps)"
            ]
        },
        "derivation_steps": [
            "Bond vector d = r2 - r1, length L=|d|, unit u_hat = d/L.",
            "Hooke axial force on cube 1: F_s,1 = +k(L-L0) u_hat; Newton III gives F_s,2 = -F_s,1.",
            "Axial damping along bond: F_d = -c (v_rel . u_hat) u_hat per cube (opposite signs).",
            f"Reduced mass for relative oscillation: m_eff = m1 m2/(m1+m2) = {m_eff:.4f}; omega_s = sqrt(k/m_eff) = {omega_s:.3f} rad/s; T_s = {T_s:.3f} s.",
            "Floor penalty contact via stiff spring-damper tuned so the 1-D damped collision recovers Newton restitution: zeta from -ln(e)=pi*zeta/sqrt(1-zeta^2).",
            "Tangential friction via tanh(vx/V_eps) regularises Coulomb friction near vx=0."
        ],
        "physical_constants_derived": {
            "m_eff_kg": round(m_eff, 6),
            "omega_spring_rad_s": round(omega_s, 4),
            "T_spring_seconds": round(T_s, 4),
            "free_fall_time_to_first_contact_s": round(t_fall, 4)
        },
        "numerical_method": {
            "solver": "LSODA (stiff/non-stiff auto-switch, suitable for stiff penalty contact)",
            "tolerance": "rtol=1e-7, atol=1e-9, max_step=1e-3"
        },
        "code_validation": {
            "ode_source": "Newton II per body + Hooke spring + viscous penalty contact with Coulomb tangential friction.",
            "energy_check": "Mechanical energy decreases monotonically due to axial damping c and floor losses.",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Free fall ~{t_fall:.3f} s before first contact.",
            "Spring oscillates (period ~T_s) throughout; cubes bounce and the spring axis rotates.",
            "Energy bleeds away over ~5-10 contacts; the assembly settles."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# gear_rack_spring_oscillator
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_gear_rack_spring_oscillator(params):
    m_g = params["m_g"]; R_g = params["R_g"]; m_r = params["m_r"]
    k_L = params["k_L"]; k_R = params["k_R"]; gamma = params["gamma"]
    v_0 = params["v_0"]; x_rack_0 = params["x_rack_0"]
    I_g = 0.5 * m_g * R_g * R_g
    m_eff = m_r + I_g / (R_g * R_g)
    k_eff = k_L + k_R
    omega_n = math.sqrt(k_eff / m_eff)
    zeta = gamma / (2.0 * math.sqrt(k_eff * m_eff))
    T_n = 2 * math.pi / omega_n
    return {
        "simulation": "gear_rack_spring_oscillator",
        "physical_observation": (
            f"A gear (m_g={m_g:.3f} kg, R_g={R_g:.3f} m) on a fixed axle meshes (no slip) "
            f"with a horizontal rack (m_r={m_r:.3f} kg) attached to walls by springs "
            f"(k_L={k_L:.2f} N/m, k_R={k_R:.2f} N/m). The rack is given an initial velocity "
            f"v_0={v_0:.3f} m/s. Light damping gamma={gamma:.3f} acts on the rack."
        ),
        "physical_law": {
            "name": "Newton II for translation + Newton II for rotation with no-slip constraint (reflected inertia)",
            "statement": "No-slip at the gear-rack interface gives v_rack = +omega_gear*R_g, allowing reduction to a single damped SHO in the rack coordinate with effective mass m_eff = m_r + I_g/R_g^2.",
            "formula": "m_eff x'' = -k_eff x - gamma x'  with k_eff = k_L + k_R"
        },
        "ode_system": {
            "state_variables": ["x_rack (m)", "v_rack (m/s)"],
            "equations": [
                "dx/dt = v",
                f"dv/dt = -(k_eff/m_eff) x - (gamma/m_eff) v   [m_eff={m_eff:.4f} kg, k_eff={k_eff:.4f} N/m]",
                "Closed-form damped SHM: x(t) = exp(-zeta*omega_n*t) (A cos omega_d t + B sin omega_d t)"
            ]
        },
        "derivation_steps": [
            "Gear inertia: I_g = (1/2) m_g R_g^2 (uniform disc).",
            f"No-slip constraint at the rack-gear contact: v_rack = +omega_gear R_g, so omega_gear = v_rack/R_g.",
            "Kinetic energy: T = (1/2) m_r v^2 + (1/2) I_g (v/R_g)^2 = (1/2) m_eff v^2 with m_eff = m_r + I_g/R_g^2.",
            "Both springs unstretched at x=0 -> potential energy V = (1/2)(k_L+k_R) x^2.",
            "Lagrangian/Newton II yields m_eff x'' + gamma x' + (k_L+k_R) x = 0.",
            f"Natural frequency omega_n = sqrt(k_eff/m_eff) = {omega_n:.4f} rad/s; T_n = {T_n:.4f} s.",
            f"Damping ratio zeta = gamma/(2 sqrt(k_eff m_eff)) = {zeta:.4f}."
        ],
        "physical_constants_derived": {
            "I_g_kg_m2": round(I_g, 6),
            "m_eff_kg": round(m_eff, 6),
            "k_eff_N_per_m": round(k_eff, 4),
            "omega_n_rad_s": round(omega_n, 4),
            "T_n_seconds": round(T_n, 4),
            "damping_ratio_zeta": round(zeta, 4)
        },
        "numerical_method": {
            "solver": "Closed-form damped SHM (no numerical integration required).",
            "tolerance": "exact"
        },
        "code_validation": {
            "ode_source": "Single damped SHO via reflected gear inertia (textbook).",
            "energy_check": "Energy E = (1/2) m_eff v^2 + (1/2) k_eff x^2 decreases monotonically when gamma>0.",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Underdamped sinusoidal oscillation with period T_n = {T_n:.3f} s, decaying with envelope exp(-zeta*omega_n*t).",
            "Gear angle proportional to rack displacement; visible no-slip rolling."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# half_cylinder_drop
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_half_cylinder_drop(params):
    g = params["g"]; M = params["M"]; R = params["R"]
    e_rest = params["e_rest"]; mu = params["mu"]; gamma_rock = params["gamma_rock"]
    h_com = 4.0 * R / (3.0 * math.pi)
    I_com = M * R * R * (0.5 - 16.0 / (9.0 * math.pi * math.pi))
    omega_rock_small = math.sqrt(M * g * h_com / (I_com + M * (R - h_com) ** 2))
    T_rock = 2 * math.pi / omega_rock_small
    return {
        "simulation": "half_cylinder_drop",
        "physical_observation": (
            f"A 2D half-disc (R={R:.3f} m, mass M={M:.3f} kg) is dropped from height "
            f"Y_com={params['Y_com_0']:.3f} m with initial tilt theta_0={params['theta_0']:.3f} rad. "
            f"It bounces (e={e_rest:.3f}, mu={mu:.3f}) and eventually rocks on its curved face."
        ),
        "physical_law": {
            "name": "Newton-Euler equations for a 2D rigid body with impulsive contact (Newton restitution + Coulomb friction)",
            "statement": "Free flight: F = M a, tau = I alpha (no external torque, gravity acts at COM). At contact, decoupled normal impulse Jn (Newton e) and tangential Jt clipped by Coulomb cone.",
            "formula": "Jn = -(1+e) v_cy /(1/M + rx^2/I_com); Jt = clip(Jt_stick, -mu Jn, +mu Jn)"
        },
        "ode_system": {
            "state_variables": ["X_com, Y_com, theta", "V_x, V_y, omega"],
            "equations": [
                "Free flight: X'' = 0, Y'' = -g, theta'' = 0",
                "Rocking single-DOF (no slip): M_eff(theta) theta'' + (1/2)dM_eff/dtheta theta'^2 + M g h_com sin(theta) + gamma_rock theta' = 0",
                "where M_eff(theta) = I_com + M[R^2 - 2 R h_com cos(theta) + h_com^2]"
            ]
        },
        "derivation_steps": [
            f"Half-disc COM offset below the diameter: h_com = 4R/(3 pi) = {h_com:.4f} m.",
            f"Moment of inertia about COM: I_com = M R^2 (1/2 - 16/(9 pi^2)) = {I_com:.6f} kg*m^2.",
            "Free flight: gravity at COM gives X''=0, Y''=-g, no torque -> theta''=0.",
            "At contact, contact-point velocity v_c = (V_x - r_y omega, V_y + r_x omega).",
            "Decoupled impulses: Jn from Newton e on the normal; tangential Jt clipped to Coulomb cone.",
            "Rocking: rolling without slipping on the curved face yields a single-DOF Lagrangian for theta.",
            f"Small-angle rocking frequency: omega_rock ~ sqrt(M g h_com / I_pivot_eff) ~ {omega_rock_small:.3f} rad/s; T ~ {T_rock:.3f} s."
        ],
        "physical_constants_derived": {
            "h_com_m": round(h_com, 6),
            "I_com_kg_m2": round(I_com, 6),
            "omega_rock_small_rad_s": round(omega_rock_small, 4),
            "T_rock_seconds": round(T_rock, 4)
        },
        "numerical_method": {
            "solver": "RK45 with terminal contact event for free flight; RK45 for rocking ODE.",
            "tolerance": "rtol=1e-9, atol=1e-11"
        },
        "code_validation": {
            "ode_source": "Standard Newton-Euler + impulsive contact + holonomic rolling Lagrangian.",
            "energy_check": "Energy strictly decreases at each impulse and via rocking damping gamma_rock.",
            "physical_plausibility": True
        },
        "expected_behavior": [
            "Free fall, one or more bounces with energy loss, transition to rocking on curved face.",
            "Rocking damps via gamma_rock and the body settles upright."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# hammer_projectile_bounce
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_hammer_projectile_bounce(params):
    m_rod = params["m_rod"]; m_head = params["m_head"]; L_rod = params["L_rod"]
    g = params["g"]; e_rest = params["e_rest"]; mu = params["mu"]
    Xc0 = params["Xc0"]; Yc0 = params["Yc0"]; theta0 = params["theta0"]
    Vx0 = params["Vx0"]; Vy0 = params["Vy0"]; omega0 = params["omega0"]
    M = m_rod + m_head
    x_com = (m_rod * L_rod / 2.0 + m_head * L_rod) / M
    I_com = (m_rod * L_rod**2 / 12.0
             + m_rod * (L_rod / 2.0 - x_com)**2
             + m_head * (L_rod - x_com)**2)
    T_rot = 2 * math.pi / abs(omega0) if omega0 != 0 else float("inf")
    return {
        "simulation": "hammer_projectile_bounce",
        "physical_observation": (
            f"A 'hammer' (rod m_rod={m_rod:.3f} kg, length L={L_rod:.3f} m, with a heavy head "
            f"m_head={m_head:.3f} kg at one end) is launched at v=({Vx0:.2f}, {Vy0:.2f}) m/s, "
            f"angular velocity omega0={omega0:.2f} rad/s, and bounces on the floor with "
            f"e={e_rest:.3f}, mu={mu:.3f}."
        ),
        "physical_law": {
            "name": "Newton-Euler equations + impulsive endpoint contacts (Newton restitution + Coulomb friction)",
            "statement": "Free flight: F=M a, no torque so omega is constant. At endpoint contact: decoupled normal and tangential impulses with cone clamp.",
            "formula": "Jn = -(1+e) v_p_y/(1/M + rx^2/I_com); Jt = clip(-v_p_x/(1/M + ry^2/I_com), -mu Jn, +mu Jn)"
        },
        "ode_system": {
            "state_variables": ["X_com, Y_com, theta", "V_x, V_y, omega"],
            "equations": [
                "Free flight: X''=0, Y''=-g, theta''=0.",
                "Endpoint contact events: tail at Y_com - x_com sin theta = 0; head at Y_com + (L_rod-x_com) sin theta = 0."
            ]
        },
        "derivation_steps": [
            f"Total mass M = m_rod + m_head = {M:.4f} kg.",
            f"COM offset from tail: x_com = (m_rod L/2 + m_head L)/M = {x_com:.4f} m.",
            f"Moment of inertia about COM (parallel axis on the rod + point head): I_com = {I_com:.6f} kg*m^2.",
            "Free flight has no torque about COM (gravity acts at COM): theta''=0; X''=0; Y''=-g.",
            "At an endpoint contact, contact-point velocity v_p = (Vx - ry omega, Vy + rx omega).",
            "Decoupled impulse: Jn = -(1+e) v_p_y/(1/M + rx^2/I_com); Jt = clip(stick value, -mu Jn, mu Jn).",
            "Apply Delta V_x = Jt/M, Delta V_y = Jn/M, Delta omega = (rx Jn - ry Jt)/I_com.",
            "Iterate over both endpoints (up to 8 passes) to handle simultaneous contacts."
        ],
        "physical_constants_derived": {
            "M_total_kg": round(M, 6),
            "x_com_m": round(x_com, 6),
            "I_com_kg_m2": round(I_com, 6),
            "T_rotation_initial_s": round(T_rot, 4) if T_rot != float("inf") else None
        },
        "numerical_method": {
            "solver": "RK45 with terminal endpoint events; iterative impulse solver at contact.",
            "tolerance": "rtol=1e-9, atol=1e-11"
        },
        "code_validation": {
            "ode_source": "Standard rigid-body Newton-Euler + impulsive contact mechanics.",
            "energy_check": "KE strictly decreases at each impulse for e<1; rest detection for chatter.",
            "physical_plausibility": True
        },
        "expected_behavior": [
            "Tumbling rod-with-head bounces on the floor; the head end carries most of the inertia.",
            "After several impacts, the body settles to rest flat on the floor."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# hemisphere_roll_off
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_hemisphere_roll_off(params):
    R = params["R"]; r = params["r"]; g = params["g"]
    theta_0 = params["theta_0"]; e_g = params["e_g"]
    mu_g = params["mu_g"]; mu_r = params["mu_r"]
    cos_thc = 10.0 / 17.0
    th_c_deg = math.degrees(math.acos(cos_thc))
    return {
        "simulation": "hemisphere_roll_off",
        "physical_observation": (
            f"A small uniform solid sphere (radius r={r:.3f} m) starts near the top of a fixed "
            f"hemisphere (radius R={R:.3f} m) at angle theta_0={theta_0:.3f} rad and rolls without "
            f"slipping until it loses contact at the textbook angle theta_c with cos theta_c = 10/17."
        ),
        "physical_law": {
            "name": "Lagrangian mechanics with rolling constraint + Newton II for radial detachment + impulsive ground contact + rolling resistance.",
            "statement": "Phase 1: rolling without slipping on the hemisphere. Phase 2: projectile flight after detachment. Phase 3: ground bounces with Newton+Coulomb. Phase 3b: rolling-resistance coast.",
            "formula": "Phase 1 EOM: theta'' = (5g)/(7(R+r)) sin(theta); detachment when N=0 -> cos(theta_c) = 10/17."
        },
        "ode_system": {
            "state_variables": ["theta (polar from vertical)", "theta'", "x, y, vx, vy"],
            "equations": [
                "Phase 1: dtheta/dt = omega; domega/dt = (5g/7(R+r)) sin(theta).",
                "Phase 2 (free flight): x''=0, y''=-g.",
                "Phase 3 (ground bounce): Jn=-(1+e_g)vy; Jt clipped to mu_g*Jn cone.",
                "Phase 3b (rolling on the floor): vx decays at -mu_r*g until vx=0."
            ]
        },
        "derivation_steps": [
            "Rolling without slipping on the hemisphere: KE = (1/2)mv^2 + (1/2)I omega^2 with v=(R+r)theta_dot and omega=(R+r)/r theta_dot for a solid sphere I=(2/5)m r^2.",
            "Total T = (7/10) m (R+r)^2 theta_dot^2; PE = m g (R+r) cos(theta).",
            "Lagrange yields theta'' = (5g)/(7(R+r)) sin(theta).",
            "Radial Newton's law: N = (m g/7)(17 cos theta - 10); zero at cos(theta_c) = 10/17 -> theta_c = " + f"{th_c_deg:.3f} deg.",
            "After detachment: projectile flight with initial position/velocity at the detachment angle.",
            "Ground impact: decoupled normal/tangent impulse with cone clamp using effective tangential mass 2/(7m) for a solid sphere.",
            "Once |vy_post| drops below threshold, switch to closed-form coast under -mu_r*g."
        ],
        "physical_constants_derived": {
            "cos_theta_c": round(cos_thc, 4),
            "theta_c_deg": round(th_c_deg, 3),
            "v_at_detach_mps_approx": round(math.sqrt((10.0/7.0) * g * (R + r) * (1 - cos_thc)), 4)
        },
        "numerical_method": {
            "solver": "RK45 with terminal events for detachment and ground contact.",
            "tolerance": "rtol=1e-9, atol=1e-11"
        },
        "code_validation": {
            "ode_source": "Lagrangian rolling + textbook detachment criterion + impulsive contact mechanics.",
            "energy_check": "Phase 1 conserves energy; subsequent bounces dissipate via e_g and mu_g; final coast drains to zero via mu_r.",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Sphere accelerates down the hemisphere; detaches at theta_c~{th_c_deg:.1f} deg.",
            "Lands and bounces a few times before coasting to rest under rolling resistance."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# pendulum_block_strike
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_pendulum_block_strike(params):
    g = params["g"]; m_b = params["m_b"]; M_B = params["M_B"]
    L = params["L"]; r_bob = params["r_bob"]; s = params["s"]
    e = params["e"]; mu_k = params["mu_k"]; b_p = params["b_p"]
    theta0 = params["theta0"]; omega0 = params["omega0"]
    omega_n = math.sqrt(g / L)
    T_small = 2 * math.pi / omega_n
    return {
        "simulation": "pendulum_block_strike",
        "physical_observation": (
            f"A pendulum bob (m_b={m_b:.3f} kg, rod length L={L:.3f} m) is released from "
            f"theta0={theta0:.3f} rad and strikes a cubical block (mass M_B={M_B:.3f} kg, "
            f"side s={s:.3f} m) sitting on a floor with kinetic friction mu_k={mu_k:.3f}. "
            f"Collision restitution e={e:.3f}; pendulum angular damping b_p={b_p:.3f} kg*m^2/s."
        ),
        "physical_law": {
            "name": "Newton II for rotation (pendulum) + impulsive collision with closed-form rule + Coulomb friction on the block.",
            "statement": "Pendulum: I_b theta'' = -m_b g L sin theta - b_p theta'. Collision: closed-form rule for oblique pendulum-block contact along horizontal normal.",
            "formula": "omega' = [omega(m_b - e M_B cos^2 theta) + (1+e) M_B v_b cos(theta)/L] / [m_b + M_B cos^2 theta]"
        },
        "ode_system": {
            "state_variables": ["theta, omega (pendulum)", "x_b, v_b (block)"],
            "equations": [
                "dtheta/dt = omega; domega/dt = -(g/L) sin(theta) - (b_p/(m_b L^2)) omega",
                "dx_b/dt = v_b; dv_b/dt = -mu_k g sign(v_b)  while v_b != 0",
                "Contact event: gap = (x_h + L sin theta - r_bob) - (x_b + s/2) -> 0"
            ]
        },
        "derivation_steps": [
            "Pendulum: pivot at (x_h, y_h) chosen so the bob just kisses the block at theta=0.",
            "Free swing EOM: m_b L^2 theta'' = -m_b g L sin theta - b_p theta'.",
            "At contact (horizontal normal): rod absorbs the radial component of the impulse, only tangential changes the bob's tangential velocity v_t = L omega cos(theta).",
            "Conservation: J = m_b L (omega' - omega)/cos(theta) (impulse on bob); equal-and-opposite impulse on the block changes v_b.",
            "Newton restitution along normal: L omega' cos(theta) - v_b' = -e (L omega cos(theta) - v_b).",
            "Solve simultaneously for omega' and v_b' (closed form).",
            "Block coasts under -mu_k g sign(v_b) until v_b = 0."
        ],
        "physical_constants_derived": {
            "omega_n_pendulum_rad_s": round(omega_n, 4),
            "T_small_seconds": round(T_small, 4)
        },
        "numerical_method": {
            "solver": "RK45 with terminal contact event and block-stop event.",
            "tolerance": "rtol=1e-9, atol=1e-11"
        },
        "code_validation": {
            "ode_source": "Standard pendulum + impulsive oblique collision rule + Coulomb friction.",
            "energy_check": "Pendulum loses energy via b_p damping and collision losses (e<1); block kinetic energy drains via mu_k.",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"First strike near t ~ T_small/4 ~ {T_small/4:.3f} s.",
            "Block accelerates after each strike, decelerating between strikes via friction; pendulum amplitude decays."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# pendulum_slack_revolution
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_pendulum_slack_revolution(params):
    g = params["g"]; L = params["L"]; m = params["m"]
    v_0 = params["v_0"]; damping_b = params["damping_b"]
    cos_th_slack = (2.0 * g * L - v_0 * v_0) / (3.0 * g * L)
    cos_th_slack = max(-1.0, min(1.0, cos_th_slack))
    th_slack_deg = math.degrees(math.acos(cos_th_slack))
    return {
        "simulation": "pendulum_slack_revolution",
        "physical_observation": (
            f"A point bob (m={m:.3f} kg) hangs from a hinge by an inextensible STRING of "
            f"length L={L:.3f} m. The bob is given an initial horizontal speed v_0={v_0:.3f} m/s "
            f"at the bottom; this is in the slack/projectile/re-taut regime "
            f"(2gL={2*g*L:.3f} < v_0^2={v_0*v_0:.3f} < 5gL={5*g*L:.3f})."
        ),
        "physical_law": {
            "name": "Newton's Second Law with a unilateral inextensible string constraint (T >= 0)",
            "statement": "While taut: theta_ddot = -(g/L) sin theta. Tension T = m L theta_dot^2 + m g cos theta. When T -> 0 the constraint releases and the bob is a projectile until |r| = L again.",
            "formula": "Phase 1 (taut): theta'' = -(g/L) sin theta. Phase 2 (slack): x'' = 0, y'' = -g."
        },
        "ode_system": {
            "state_variables": [
                "Phase 1: theta (rad), omega = theta' (rad/s)",
                "Phase 2: x, y (m), vx, vy (m/s)"
            ],
            "equations": [
                "Phase 1: dtheta/dt = omega; domega/dt = -(g/L) sin(theta) - (damping_b/(m L^2)) omega",
                "Phase 2: dx/dt = vx; dy/dt = vy; dvx/dt = 0; dvy/dt = -g",
                "Slack onset event: T = m L omega^2 + m g cos theta -> 0",
                "Re-taut event: x^2 + y^2 -> L^2; impulsive jerk removes outward radial velocity component"
            ]
        },
        "derivation_steps": [
            "Bob on a STRING (not a rod): the string can pull but not push. T = m L omega^2 + m g cos theta is the tension required for circular motion at angle theta with angular speed omega.",
            f"Slack threshold: T = 0 gives cos(theta_slack) = (2 g L - v_0^2)/(3 g L) = {cos_th_slack:.4f}, theta_slack = {th_slack_deg:.3f} deg.",
            "While slack the bob is a free projectile: ax=0, ay=-g.",
            "When the bob's distance from the hinge returns to L, an inelastic constraint jerk fires: kill the radial velocity component, keep the tangential component.",
            "Energy lost per re-taut event: dKE = -1/2 m v_radial^2."
        ],
        "physical_constants_derived": {
            "v0_squared": round(v_0 * v_0, 4),
            "two_gL": round(2 * g * L, 4),
            "five_gL": round(5 * g * L, 4),
            "cos_theta_slack": round(cos_th_slack, 4),
            "theta_slack_deg": round(th_slack_deg, 3)
        },
        "numerical_method": {
            "solver": "RK45 with terminal events for slack onset and re-taut crossings",
            "tolerance": "rtol=1e-9, atol=1e-11"
        },
        "code_validation": {
            "ode_source": "Newton II with unilateral string constraint (T>=0); textbook hybrid system.",
            "energy_check": "Mechanical energy is conserved within each phase and decreases only at re-taut jerks (radial velocity removed).",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"String goes slack at theta = {th_slack_deg:.1f} deg from vertical.",
            "After slack onset, the bob arcs as a projectile and re-taut event removes radial velocity.",
            "Repeated cycles continue with decreasing energy due to inelastic jerks until the bob settles to swinging."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# projectile_bounce
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_projectile_bounce(params):
    g = params["g"]; m = params["m"]; r = params["r_ball"]
    v0 = params["v0"]; theta0_deg = params["theta0_deg"]
    e = params["e"]; mu = params["mu"]
    x0 = params["x0"]; y0 = params["y0"]
    theta0 = math.radians(theta0_deg)
    vx0 = v0 * math.cos(theta0); vy0 = v0 * math.sin(theta0)
    range_no_bounce = (vx0 * vy0 + vx0 * math.sqrt(vy0 * vy0 + 2 * g * (y0 - r))) / g if y0 >= r else float("nan")
    return {
        "simulation": "projectile_bounce",
        "physical_observation": (
            f"A point-mass ball (m={m:.3f} kg, radius {r:.3f} m) is launched from "
            f"(x0={x0:.3f}, y0={y0:.3f}) with speed v0={v0:.3f} m/s at "
            f"angle {theta0_deg:.2f} deg above horizontal. Restitution e={e:.3f}, "
            f"friction mu={mu:.3f}."
        ),
        "physical_law": {
            "name": "Newton's Second Law (free-flight) + Newton restitution + Coulomb friction at contact",
            "statement": "Free flight: ax = 0, ay = -g. Floor collision applies normal impulse Jn = m(1+e)|vy| and tangential impulse Jt clipped to the friction cone |Jt| <= mu Jn.",
            "formula": "vy' = -e vy ; vx' = vx + Jt/m, with Jt = clip(-m vx, -mu Jn, +mu Jn)"
        },
        "ode_system": {
            "state_variables": ["x, y (m)", "vx, vy (m/s)"],
            "equations": [
                "dx/dt = vx; dy/dt = vy",
                "dvx/dt = 0; dvy/dt = -g  (free flight)",
                "Event: y - r_ball = 0 with vy<0 -> impulsive collision"
            ]
        },
        "derivation_steps": [
            "Free flight equations: ax=0 (no drag), ay=-g.",
            "At floor contact (y - r_ball = 0, vy<0) the contact impulse must produce post-impact normal vy' = -e vy (Newton restitution).",
            "Tangential impulse Jt is bounded by Coulomb cone: |Jt| <= mu Jn with Jn = m(1+e)|vy|.",
            "If the stick impulse Jt_stick = -m vx fits within the cone, vx' = 0 (sticks); otherwise vx' = vx - sign(vx) mu (1+e) |vy|.",
            "When |vy_post| drops below a threshold, switch to a closed-form coast-and-stop phase under -mu g friction along x."
        ],
        "physical_constants_derived": {
            "vx0_mps": round(vx0, 4),
            "vy0_mps": round(vy0, 4),
            "free_range_to_floor_m": round(range_no_bounce, 4) if range_no_bounce == range_no_bounce else None,
            "T_settle_threshold_vy_mps": 0.5
        },
        "numerical_method": {
            "solver": "RK45 with terminal contact event",
            "tolerance": "rtol=1e-9, atol=1e-11"
        },
        "code_validation": {
            "ode_source": "Standard 2D projectile kinematics + impulsive Newton/Coulomb collision.",
            "energy_check": "KE decreases at every bounce by factor depending on e and mu.",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Ball follows parabolic arc, bounces with e={e:.2f}, eventually settles via closed-form coast-and-stop.",
            "Number of bounces increases with e and decreases with mu."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# ring_pendulum
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_ring_pendulum(params):
    r = params["r"]; M = params["M"]; g = params["g"]; b = params["b"]
    theta0 = params["theta0"]; omega0 = params["omega0"]
    I_pivot = 2.0 * M * r * r
    omega_n = math.sqrt(g / (2.0 * r))
    T_small = 2.0 * math.pi / omega_n
    zeta = b / (2.0 * I_pivot * omega_n)
    return {
        "simulation": "ring_pendulum",
        "physical_observation": (
            f"A thin uniform circular ring (radius r={r:.3f} m, mass M={M:.3f} kg) is hinged "
            f"on a fixed point on its perimeter. The ring swings as a physical pendulum "
            f"in the vertical plane starting from theta0={theta0:.3f} rad, omega0={omega0:.3f} rad/s, "
            f"with linear angular damping b={b:.4f} kg*m^2/s."
        ),
        "physical_law": {
            "name": "Newton's Second Law for Rotation about a Fixed Axis (physical pendulum)",
            "statement": "For rigid-body rotation about a fixed axis, I*theta_ddot = sum of torques.",
            "formula": "I_pivot * theta'' = -M*g*r*sin(theta) - b*theta'  with I_pivot = 2*M*r^2"
        },
        "ode_system": {
            "state_variables": ["theta (angle from vertical, rad)", "omega = theta' (rad/s)"],
            "equations": [
                "dtheta/dt = omega",
                f"domega/dt = -(g/(2r)) sin(theta) - (b/I_pivot) omega   [I_pivot={I_pivot:.4f} kg*m^2]"
            ]
        },
        "derivation_steps": [
            "Thin uniform hoop about its centre: I_CM = M r^2.",
            "Hinge sits on the perimeter, distance d = r from CM.",
            f"Parallel-axis theorem: I_pivot = I_CM + M r^2 = 2 M r^2 = {I_pivot:.4f} kg*m^2.",
            "Gravity torque about hinge: tau_g = -M g r sin(theta).",
            "Linear viscous angular damping: tau_d = -b theta'.",
            f"Newton II: I_pivot theta'' = -M g r sin(theta) - b theta'.",
            f"Divide: theta'' = -(g/2r) sin(theta) - (b/I_pivot) theta'."
        ],
        "physical_constants_derived": {
            "I_pivot_kg_m2": round(I_pivot, 6),
            "omega_natural_rad_s": round(omega_n, 4),
            "T_small_seconds": round(T_small, 4),
            "damping_ratio_zeta": round(zeta, 6)
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince)",
            "tolerance": "rtol=1e-9, atol=1e-11"
        },
        "code_validation": {
            "ode_source": "Newton II for rotation about hinge; parallel-axis theorem.",
            "energy_check": "E = (1/2) I_pivot omega^2 + M g r (1 - cos theta) decreases monotonically when b>0.",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Small-angle period T_small = {T_small:.3f} s.",
            f"Damping ratio zeta = {zeta:.4f}; underdamped oscillation that decays in time."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# ring_sticky_collision
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_ring_sticky_collision(params):
    M = params["M"]
    R = params["R"]
    m = params["m"]
    Omega_0 = params["Omega_0"]
    v = params["v"]
    b = params["b"]
    x_start = params["x_start_point"]

    x_hit = -math.sqrt(R * R - b * b)
    y_hit = b
    t_c = (x_hit - x_start) / v
    M_tot = M + m
    V_com_x = m * v / M_tot
    R_com_x = m * x_hit / M_tot
    R_com_y = m * y_hit / M_tot
    I_ring = M * R * R
    I_total = M * R * R * (M + 2.0 * m) / M_tot
    L_before = M * R * R * Omega_0 - b * m * v
    Omega_after = ((M + m) * Omega_0 - m * b * v / (R * R)) / (M + 2.0 * m)
    KE_before = 0.5 * m * v * v + 0.5 * I_ring * Omega_0 ** 2
    KE_after = 0.5 * M_tot * V_com_x ** 2 + 0.5 * I_total * Omega_after ** 2

    return {
        "simulation": "ring_sticky_collision",
        "physical_observation": (
            f"A thin uniform ring (mass M={M:.3f} kg, radius R={R:.3f} m, "
            f"I_ring=M R^2={I_ring:.3f} kg m^2) spins in zero-gravity free space "
            f"at angular velocity Omega_0={Omega_0:.3f} rad/s with zero translational "
            f"velocity, centred at the origin. A point mass m={m:.3f} kg approaches "
            f"from the left along y={b:.3f} m at velocity ({v:.3f}, 0) m/s, strikes "
            f"the leftmost intersection of its trajectory with the ring at "
            f"r_hit=({x_hit:.4f}, {y_hit:.4f}) m, and STICKS perfectly inelastically. "
            f"Thereafter the composite translates uniformly and rotates uniformly about "
            f"its new COM in zero-g free space."
        ),
        "physical_law": {
            "name": "Conservation of linear and angular momentum at a perfectly inelastic impact + force/torque-free rigid-body motion",
            "statement": (
                "Across an instantaneous sticking impact in zero gravity, total linear "
                "momentum and total angular momentum about any fixed point are conserved. "
                "After impact the composite is a single rigid body whose COM velocity is "
                "fixed by linear momentum conservation, and whose angular velocity about "
                "the new COM is fixed by angular momentum conservation together with the "
                "parallel-axis theorem for the composite moment of inertia."
            ),
            "formula": (
                "V_com = m (v,0)/(M+m);  I_total = M R^2 (M+2m)/(M+m);  "
                "Omega_after = [(M+m) Omega_0 - m b v / R^2] / (M + 2m)"
            ),
        },
        "ode_system": {
            "state_variables": [
                "(x_p, y_p) — point-mass position before sticking (m)",
                "(X_c, Y_c) — ring centre position (m)",
                "phi_ring — ring orientation angle (rad)",
            ],
            "equations": [
                "Phase 1 (t < t_c):",
                "  dx_p/dt = v, dy_p/dt = 0",
                "  dX_c/dt = 0, dY_c/dt = 0",
                "  dphi_ring/dt = Omega_0",
                "Phase 2 (t >= t_c):",
                "  dX_com/dt = m v/(M+m), dY_com/dt = 0",
                "  dphi_body/dt = Omega_after",
            ],
        },
        "derivation_steps": [
            f"Pre-collision kinematics: r_p(t) = (x_start + v t, b) with x_start={x_start:.3f} m.",
            f"Geometry of impact: y=b cuts circle x^2+y^2=R^2 at x = +/- sqrt(R^2-b^2). "
            f"Leftmost intersection is r_hit = ({x_hit:.4f}, {y_hit:.4f}) m.",
            f"Collision time: t_c = (x_hit - x_start)/v = ({x_hit:.4f} - {x_start:.3f})/{v:.3f} = {t_c:.4f} s.",
            f"Ring moment of inertia: I_ring = M R^2 = {I_ring:.4f} kg m^2.",
            f"Linear momentum conservation: V_com = m v/(M+m) = {V_com_x:.4f} m/s in +x.",
            f"Composite COM (ring-centre frame) at t_c: R_com = m r_hit/(M+m) = ({R_com_x:.4f}, {R_com_y:.4f}) m.",
            f"Parallel-axis theorem: I_total = M R^2 + M |R_com|^2 + m |r_hit - R_com|^2 = M R^2 (M+2m)/(M+m) = {I_total:.4f} kg m^2.",
            f"L_before about origin = M R^2 Omega_0 + (r_hit x m v)_z = M R^2 Omega_0 - b m v = {L_before:.4f} kg m^2/s.",
            f"Solving L conservation: Omega_after = [(M+m) Omega_0 - m b v / R^2]/(M + 2m) = {Omega_after:.4f} rad/s.",
            "Phase 2: force/torque-free rigid body. COM moves uniformly; rigid spin about COM at Omega_after.",
        ],
        "physical_constants_derived": {
            "I_ring_kg_m2": I_ring,
            "I_total_kg_m2": I_total,
            "t_c_s": t_c,
            "x_hit_m": x_hit,
            "y_hit_m": y_hit,
            "V_com_x_m_s": V_com_x,
            "R_com_x_m": R_com_x,
            "R_com_y_m": R_com_y,
            "L_before_origin": L_before,
            "Omega_after_rad_s": Omega_after,
            "stuck_point_radius_about_com_m": M * R / M_tot,
            "ring_centre_radius_about_com_m": m * R / M_tot,
            "KE_before_J": KE_before,
            "KE_after_J": KE_after,
            "KE_dissipated_J": KE_before - KE_after,
        },
        "numerical_method": {
            "solver": "Closed-form analytic propagation (no ODE integrator).",
            "tolerance": "Exact (machine precision).",
            "justification": "Phase 1 and Phase 2 are both exactly solvable; closed-form sampling is faster and more accurate than numerical integration.",
        },
        "code_validation": {
            "ode_source": "Conservation of linear and angular momentum + parallel-axis theorem for the composite moment of inertia.",
            "energy_check": (
                f"Linear momentum and L_origin = M R^2 Omega_0 - b m v = {L_before:.4f} kg m^2/s "
                "are conserved across the impact. Kinetic energy DECREASES across the perfectly "
                f"inelastic impact by {(KE_before - KE_after):.4f} J (binding work)."
            ),
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Phase 1 (0 <= t < t_c ~ {t_c:.3f} s): ring spins at Omega_0={Omega_0:.3f} rad/s, point drifts rightward.",
            f"Collision at r_hit = ({x_hit:.4f}, {y_hit:.4f}) m.",
            f"Composite drifts at V_com = ({V_com_x:.4f}, 0) m/s and spins at Omega_after = {Omega_after:.4f} rad/s.",
            f"Stuck point traces a cycloid-like curve of orbital radius {M*R/M_tot:.4f} m about the moving COM.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# rod_ball_strike
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_rod_ball_strike(params):
    L = params["L"]
    M = params["M"]
    m_ball = params["m_ball"]
    r_ball = params["r_ball"]
    g = params["g"]
    e_rest = params["e_rest"]
    mu_k = params["mu_k"]
    xb0 = params["xb0"]; yb0 = params["yb0"]
    vbx0 = params["vbx0"]; vby0 = params["vby0"]
    xR0 = params["xR0"]; yR0 = params["yR0"]
    theta0 = params["theta0"]
    VRx0 = params["VRx0"]; VRy0 = params["VRy0"]
    omega0 = params["omega0"]

    I_rod = M * L * L / 12.0
    v0 = math.sqrt(vbx0 ** 2 + vby0 ** 2)

    return {
        "simulation": "rod_ball_strike",
        "physical_observation": (
            f"A uniform thin rigid rod (length L={L:.3f} m, mass M={M:.3f} kg, "
            f"I_cm = M L^2/12 = {I_rod:.4f} kg m^2) lies at rest on a horizontal "
            f"surface (top-down view). A ball (mass m={m_ball:.3f} kg, radius "
            f"r={r_ball:.3f} m) approaches at initial velocity ({vbx0:.3f}, {vby0:.3f}) m/s "
            f"(speed {v0:.3f} m/s) and collides with the rod with normal coefficient "
            f"of restitution e={e_rest:.3f}. Light kinetic friction (mu_k={mu_k:.4f}) "
            f"with the surface gradually decelerates both bodies."
        ),
        "physical_law": {
            "name": "Newton's laws + impulsive collision (impulse-momentum) + Coulomb friction",
            "statement": (
                "Between collisions each body slides under a friction force opposing its "
                "velocity (-mu_k m g v_hat) and the rod has angular damping. Across "
                "an impulsive contact, the normal impulse magnitude J is set by the "
                "coefficient-of-restitution condition: J = -(1+e) v_app / "
                "(1/m + 1/M + (r x n)^2 / I_rod), where v_app is the relative "
                "approach velocity along the contact normal n."
            ),
            "formula": (
                "Free: m dv/dt = -mu_k m g v_hat, M dV/dt = -mu_k M g V_hat, "
                "I_rod d omega/dt = -3 mu_k g / L sign(omega). "
                "Impact: Delta v_b = +J n / m, Delta V_R = -J n / M, "
                "Delta omega = -J (r x n) / I_rod."
            ),
        },
        "ode_system": {
            "state_variables": [
                "(x_b, y_b, v_bx, v_by) — ball pos & vel",
                "(x_R, y_R, theta) — rod COM & orientation",
                "(V_Rx, V_Ry, omega) — rod COM vel & angular vel",
            ],
            "equations": [
                "dx_b/dt = v_bx, dy_b/dt = v_by",
                "dv_b/dt = -mu_k g v_b/|v_b| (when |v_b| > eps else 0)",
                "dx_R/dt = V_Rx, dy_R/dt = V_Ry, dtheta/dt = omega",
                "dV_R/dt = -mu_k g V_R/|V_R|",
                "domega/dt = -3 mu_k g / L sign(omega)",
                "Plus impulsive jumps when ball-rod gap = 0 with approaching contact velocity.",
            ],
        },
        "derivation_steps": [
            f"Rod moment of inertia about its centre: I_rod = M L^2 / 12 = {I_rod:.4f} kg m^2.",
            "Free-motion friction: top-down sliding => friction force opposes velocity at magnitude mu_k m g.",
            "Closest distance from ball centre (x_b, y_b) to rod segment determines contact event.",
            "When closest_dist - r_ball = 0, an impulsive collision is applied.",
            "Contact normal n points from rod-segment closest point to ball centre.",
            "Contact-velocity at rod's contact point: V_R + omega x r_R.",
            "Approach velocity along normal: v_app = (v_ball - V_R_contact) . n.",
            "Impulse magnitude (frictionless tangent, normal restitution e): "
            "J = -(1+e) v_app / (1/m + 1/M + (r x n)^2 / I_rod).",
            "Apply: v_ball -> v_ball + J n/m; V_R -> V_R - J n/M; omega -> omega - J (r x n)/I_rod.",
            "Hybrid integration: solve_ivp with terminal events, restart after each impact.",
        ],
        "physical_constants_derived": {
            "I_rod_kg_m2": I_rod,
            "ball_initial_speed_m_s": v0,
            "rod_initial_speed_m_s": math.sqrt(VRx0 ** 2 + VRy0 ** 2),
            "max_friction_decel_m_s2": mu_k * g,
        },
        "numerical_method": {
            "solver": "RK45 (adaptive Runge-Kutta) with terminal events for collision detection; impulsive state update at each event.",
            "tolerance": "rtol=1e-9, atol=1e-11, max_step=0.05",
            "justification": "Hybrid continuous-impulsive system; smooth ODE between collisions, instantaneous impulse at each contact.",
        },
        "code_validation": {
            "ode_source": "Standard 2D rigid-body collision impulse formula and Coulomb sliding friction.",
            "energy_check": (
                f"Each impact dissipates energy by factor (1-e^2) = {1.0 - e_rest**2:.4f} "
                "of the normal-direction relative kinetic energy; friction monotonically "
                "decreases total kinetic energy between impacts."
            ),
            "physical_plausibility": True,
        },
        "expected_behavior": [
            "Ball approaches rod, collides, both bodies translate (and rod rotates).",
            "Friction decelerates each body; motion settles to rest within the simulation duration.",
            f"Rod and ball remain in frame for the {params.get('duration', 12.0)} s window because "
            "friction is small and initial speed is bounded.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# semicircular_track
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_semicircular_track(params):
    g = params["g"]
    m = params["m"]
    R = params["R"]
    r = params["r"]
    gamma = params["gamma"]
    theta0 = params["theta0"]
    omega0 = params["omega0"]

    k_coeff = 5.0 * g / (7.0 * (R - r))
    omega_n = math.sqrt(k_coeff)
    T_small = 2.0 * math.pi / omega_n
    zeta = gamma / (2.0 * omega_n)
    deg = math.degrees(theta0)

    return {
        "simulation": "semicircular_track",
        "physical_observation": (
            f"A solid uniform sphere (mass m={m:.3f} kg, radius r={r:.3f} m) "
            f"rolls without slipping inside the lower half of a circular bowl of "
            f"radius R={R:.3f} m. Released from theta0={theta0:.3f} rad "
            f"(~{deg:.1f} deg) with angular velocity omega0={omega0:.3f} rad/s, "
            f"the sphere oscillates back and forth at the bottom of the bowl, "
            f"its amplitude slowly decaying from viscous damping (gamma={gamma:.3f} 1/s)."
        ),
        "physical_law": {
            "name": "Lagrangian mechanics with the rolling-without-slipping constraint",
            "statement": (
                "For a sphere of mass m and radius r rolling on a circular track of "
                "radius R (centre constrained to a circle of radius (R-r)), the "
                "rolling constraint r*phi_dot = (R-r)*theta_dot couples the rotational "
                "and translational kinetic energies. The Euler-Lagrange equation for "
                "theta yields a nonlinear pendulum-like ODE with the 5/7 prefactor "
                "characteristic of a solid sphere (I = (2/5) m r^2)."
            ),
            "formula": "(7/5) m (R-r)^2 theta_ddot + m g (R-r) sin(theta) = 0",
        },
        "ode_system": {
            "state_variables": ["theta (polar angle from bowl bottom, rad)",
                                "omega = theta_dot (angular velocity, rad/s)"],
            "equations": [
                "dtheta/dt = omega",
                "domega/dt = -(5 g)/(7 (R-r)) sin(theta) - gamma omega",
            ],
        },
        "derivation_steps": [
            "Generalised coordinate: polar angle theta of the sphere's centre, "
            "measured from the bottom of the bowl (theta = 0 at the bottom).",
            f"Sphere centre constrained to a circle of radius (R-r) = {R-r:.4f} m about "
            "the bowl's centre of curvature.",
            "Centre position: x = (R-r) sin(theta), y = R - (R-r) cos(theta).",
            "Translational KE: (1/2) m (R-r)^2 theta_dot^2.",
            "Solid sphere moment of inertia: I = (2/5) m r^2.",
            "Rolling constraint: r phi_dot = (R-r) theta_dot.",
            "Rotational KE: (1/2) I phi_dot^2 = (1/5) m (R-r)^2 theta_dot^2.",
            "Total KE: T = (7/10) m (R-r)^2 theta_dot^2.",
            "Potential: V = m g (R - (R-r) cos(theta))  [zero at y=0].",
            "Euler-Lagrange: (7/5) m (R-r)^2 theta_ddot + m g (R-r) sin(theta) = 0.",
            "Add linear viscous damping -gamma theta_dot to model rolling/air resistance.",
            f"Final: theta_ddot = -(5g)/(7(R-r)) sin(theta) - gamma theta_dot "
            f"= -{k_coeff:.4f} sin(theta) - {gamma:.4f} theta_dot.",
        ],
        "physical_constants_derived": {
            "effective_radius_R_minus_r_m": R - r,
            "k_coefficient_per_s2": k_coeff,
            "small_amplitude_omega_rad_s": omega_n,
            "small_amplitude_period_s": T_small,
            "damping_ratio_zeta": zeta,
        },
        "numerical_method": {
            "solver": "RK45 (Dormand-Prince, 4th/5th order Runge-Kutta)",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": "Smooth ODE, no impacts; high-accuracy adaptive RK is appropriate.",
        },
        "code_validation": {
            "ode_source": "Euler-Lagrange equation for a solid sphere rolling without slipping in a circular bowl, with linear viscous damping.",
            "energy_check": "Without damping (gamma=0), total mechanical energy E = (7/10) m (R-r)^2 omega^2 + m g (R - (R-r) cos(theta)) is conserved.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Small-amplitude period T_small ~ {T_small:.3f} s "
            f"(~{(2*math.pi*math.sqrt(7*(R-r)/(5*g))):.3f} s).",
            (f"Damping ratio zeta = {zeta:.4f} < 1: underdamped oscillation, "
             "amplitude decays exponentially over many swings.") if zeta < 1 else
            (f"Damping ratio zeta = {zeta:.4f} >= 1: overdamped, no oscillation."),
            "The sphere's centre traces a circular arc of radius (R-r) about the bowl's centre.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# slab_springs_block_drop
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_slab_springs_block_drop(params):
    g = params["g"]; M_slab = params["M_slab"]
    L_slab = params["L_slab"]; m_b = params["m_b"]
    k = params["k"]; L_0 = params["L_0"]
    gamma_y = params["gamma_y"]; gamma_theta = params["gamma_theta"]
    H_drop = params["H_drop"]
    block_size = params["block_size"]
    slab_thickness = params["slab_thickness"]

    M_total = M_slab + m_b
    block_off = L_slab / 4.0
    d_block = M_slab * block_off / M_total
    d_slab = m_b * block_off / M_total
    I_slab = (1.0 / 12.0) * M_slab * L_slab ** 2
    I_total = I_slab + M_slab * d_slab ** 2 + m_b * d_block ** 2
    a_arm = -(L_slab / 2.0 + d_slab)
    b_arm = +(L_slab / 2.0 - d_slab)
    Y_s_eq = L_0 - M_slab * g / (2.0 * k)
    v_impact = math.sqrt(2.0 * g * H_drop)
    t_impact = v_impact / g
    v_com_y_after = m_b * (-v_impact) / M_total
    omega_after = (d_block * m_b * (-v_impact)) / I_total
    omega_trans = math.sqrt(2.0 * k / M_total)
    omega_rot = math.sqrt(k * (a_arm ** 2 + b_arm ** 2) / I_total)
    T_trans = 2.0 * math.pi / omega_trans
    T_rot = 2.0 * math.pi / omega_rot

    return {
        "simulation": "slab_springs_block_drop",
        "physical_observation": (
            f"A horizontal rigid slab (mass M_slab={M_slab:.3f} kg, length L={L_slab:.3f} m) "
            f"is suspended above the floor by two vertical Hookean springs "
            f"(each k={k:.3f} N/m, rest length L_0={L_0:.3f} m) attached to its left and "
            f"right ends. At t=0 the slab is in static equilibrium. A point block "
            f"(mass m_b={m_b:.3f} kg) is released from rest at height H_drop={H_drop:.3f} m "
            f"above the slab's body-frame x = +L/4 = {block_off:.3f} m, free-falls under "
            f"gravity, hits the slab at that point and STICKS perfectly inelastically. "
            f"The combined system then exhibits coupled translation+rotation about its new COM."
        ),
        "physical_law": {
            "name": "Newton-Euler equations for a 3-DOF rigid body + ideal Hookean springs + impulsive perfectly inelastic collision",
            "statement": (
                "Pre-impact: slab in static equilibrium, block free-falls (mg). "
                "Impact: linear and angular impulses applied at the contact point conserve "
                "linear and angular momentum across the perfectly inelastic collision. "
                "Post-impact: M_total a = sum F (springs + gravity + viscous damping); "
                "I_total alpha = sum tau."
            ),
            "formula": (
                "v_impact = sqrt(2 g H); "
                "v_com_y_after = m_b v_impact / M_total; "
                "omega_after = m_b v_impact d_block / I_total; "
                "M_total Y_com'' = F_L + F_R - M_total g - gamma_y vY; "
                "I_total theta'' = a_arm F_L + b_arm F_R - gamma_theta omega"
            ),
        },
        "ode_system": {
            "state_variables": [
                "X_com, Y_com — combined COM position (m)",
                "theta — slab orientation (rad)",
                "vX, vY, omega — derivatives",
            ],
            "equations": [
                "Pre-impact: y_block(t) = y_block_0 - 0.5 g t^2 (free-fall).",
                "Impact at t_impact: linear+angular momentum conserved.",
                "Post-impact: M_total a_com = F_L + F_R + (0, -M_total g) - gamma_y vY (y-only damping)",
                "I_total alpha = a_arm F_L_y + b_arm F_R_y - gamma_theta omega",
            ],
        },
        "derivation_steps": [
            f"Combined COM offset from slab geometric centre toward block: d_slab = m_b L/4 / M_total = {d_slab:.4f} m.",
            f"Block's body-frame x relative to combined COM: d_block = M_slab L/4 / M_total = {d_block:.4f} m.",
            f"Slab moment of inertia about its own centre: I_slab = (1/12) M_slab L^2 = {I_slab:.5f} kg m^2.",
            f"Combined moment of inertia (parallel-axis): I_total = I_slab + M_slab d_slab^2 + m_b d_block^2 = {I_total:.5f} kg m^2.",
            f"Slab static equilibrium height: Y_s_eq = L_0 - M_slab g / (2 k) = {Y_s_eq:.4f} m.",
            f"Block impact speed: v_impact = sqrt(2 g H) = {v_impact:.4f} m/s; t_impact = {t_impact:.4f} s.",
            f"Linear momentum conservation: v_com_y_after = m_b v_impact / M_total = {v_com_y_after:.4f} m/s.",
            f"Angular momentum conservation (about combined COM): "
            f"omega_after = d_block m_b v_impact / I_total = {omega_after:.4f} rad/s.",
            "Springs attached at slab body-frame ends: arms a = -(L/2 + d_slab), b = +(L/2 - d_slab).",
            f"Translation eigenmode: omega_trans = sqrt(2k/M_total) = {omega_trans:.3f} rad/s; period {T_trans:.3f} s.",
            f"Rotation eigenmode: omega_rot = sqrt(k(a^2 + b^2)/I_total) = {omega_rot:.3f} rad/s; period {T_rot:.3f} s.",
        ],
        "physical_constants_derived": {
            "M_total_kg": M_total,
            "d_block_m": d_block,
            "d_slab_m": d_slab,
            "I_total_kg_m2": I_total,
            "Y_s_eq_m": Y_s_eq,
            "v_impact_m_s": v_impact,
            "t_impact_s": t_impact,
            "v_com_y_after_m_s": v_com_y_after,
            "omega_after_rad_s": omega_after,
            "omega_trans_rad_s": omega_trans,
            "omega_rot_rad_s": omega_rot,
        },
        "numerical_method": {
            "solver": "Analytic free-fall pre-impact + RK45 for the post-impact 3-DOF rigid-body ODE.",
            "tolerance": "rtol=1e-9, atol=1e-11, max_step=0.005",
            "justification": "Smooth post-impact dynamics; tight tolerances and small max_step capture the rigid-body oscillations accurately.",
        },
        "code_validation": {
            "ode_source": "Newton-Euler equations of motion with two ideal Hookean springs at the slab ends and viscous damping; impulse-momentum at the perfectly inelastic impact.",
            "energy_check": "Energy decreases over time due to viscous damping (gamma_y, gamma_theta) and the impact dissipation.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Block free-falls for {t_impact:.3f} s, hits slab at v_impact={v_impact:.3f} m/s.",
            f"Combined system oscillates with translational period {T_trans:.3f} s and rotational period {T_rot:.3f} s.",
            "Damping causes the oscillations to decay over the simulation window.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# sliding_block_step_topple
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_sliding_block_step_topple(params):
    g = params["g"]; M = params["M"]; s = params["s"]
    v_0 = params["v_0"]; mu_floor = params["mu_floor"]
    h_step = params["h_step"]; x_step = params["x_step"]
    e_land = params["e_land"]; mu_upper = params["mu_upper"]
    X_b_0 = params["X_b_0"]

    I_cm = (1.0 / 6.0) * M * s ** 2
    half_s = s / 2.0
    d2 = half_s ** 2 + (half_s - h_step) ** 2
    d_pivot = math.sqrt(d2)
    I_pivot = I_cm + M * d2
    phi_0 = math.atan2(half_s - h_step, -half_s)
    theta_unstable = phi_0 - math.pi / 2.0
    delta_h_max = d_pivot - (half_s - h_step)
    slide_dist = (x_step - half_s) - X_b_0
    a_floor = mu_floor * g
    v_at_step_sq = v_0 * v_0 - 2.0 * a_floor * slide_dist
    v_at_step = math.sqrt(max(v_at_step_sq, 1e-9))
    omega_after = M * v_at_step * (half_s - h_step) / I_pivot
    KE_rot = 0.5 * I_pivot * omega_after ** 2
    KE_threshold = M * g * delta_h_max
    topple_possible = KE_rot > KE_threshold

    return {
        "simulation": "sliding_block_step_topple",
        "physical_observation": (
            f"A cubical block (mass M={M:.3f} kg, side s={s:.3f} m) slides at "
            f"v_0={v_0:.3f} m/s in +x on the lower of a two-level floor (lower at "
            f"y=0; upper at y={h_step:.3f} m for x>={x_step:.3f} m). The lower "
            f"floor has kinetic friction mu_floor={mu_floor:.3f}, the upper "
            f"mu_upper={mu_upper:.3f}. When the right face reaches the step, the "
            f"block's right face engages the step's top corner and pivots about "
            f"that corner; the topple-or-swing-back outcome depends on whether the "
            f"post-impact rotational KE exceeds the gravitational PE rise to the "
            f"unstable equilibrium."
        ),
        "physical_law": {
            "name": "Newton's laws + impulsive angular-momentum conservation about the pivot + Lagrangian for a rigid body pivoting about a fixed axis",
            "statement": (
                "Slide phase: m a = -mu_floor m g. "
                "Step impact: angular momentum of the block about the pivot is conserved "
                "(impulse at the contact passes through the pivot). "
                "Pivot phase: I_pivot theta_ddot = M g d cos(phi_0 - theta) "
                "(gravity torque about pivot)."
            ),
            "formula": (
                "v_at_step^2 = v_0^2 - 2 mu_floor g (x_step - X_b_0 - s/2); "
                "omega_after = M v_at_step (s/2 - h_step) / I_pivot; "
                "I_pivot theta_ddot = M g d cos(phi_0 - theta)"
            ),
        },
        "ode_system": {
            "state_variables": ["theta (CW pivot angle, rad)", "omega = theta_dot (rad/s)"],
            "equations": [
                "Slide: cm_x(t) = X_b_0 + v_0 t - 0.5 mu_floor g t^2 (until cm_x = x_step - s/2).",
                "Pivot: dtheta/dt = omega; domega/dt = M g d_pivot cos(phi_0 - theta) / I_pivot.",
                "Post-pivot: sliding kinematics (constant deceleration mu g) on whichever floor.",
            ],
        },
        "derivation_steps": [
            f"Cube moment of inertia: I_cm = M s^2 / 6 = {I_cm:.5f} kg m^2.",
            f"Pivot is the step's top corner at (x_step, h_step). Vector pivot->CM at impact "
            f"= (-s/2, s/2 - h_step), so d_pivot = sqrt((s/2)^2 + (s/2 - h)^2) = {d_pivot:.4f} m.",
            f"Parallel-axis: I_pivot = I_cm + M d^2 = {I_pivot:.5f} kg m^2.",
            f"Pre-impact slide: v_at_step = sqrt(v_0^2 - 2 mu_floor g (x_step - X_b_0 - s/2)) "
            f"= {v_at_step:.4f} m/s.",
            f"Angular-momentum conservation about pivot: omega_after = M v_at_step (s/2 - h_step)/I_pivot "
            f"= {omega_after:.4f} rad/s.",
            "Pivot dynamics: gravity torque about pivot tau = M g d cos(phi_0 - theta), where phi_0 "
            f"= atan2(s/2 - h_step, -s/2) = {phi_0:.4f} rad.",
            f"Topple criterion: post-impact rotational KE = (1/2) I_pivot omega_after^2 "
            f"= {KE_rot:.4f} J must exceed M g delta_h_max = {KE_threshold:.4f} J.",
            f"Topple possible: {topple_possible}.",
            "If toppled: rotational KE -> sliding KE on upper level with restitution e_land.",
            "Otherwise: block swings back to theta=0, separates with the same |omega| reversed, slides leftward.",
        ],
        "physical_constants_derived": {
            "I_cm_kg_m2": I_cm,
            "d_pivot_m": d_pivot,
            "I_pivot_kg_m2": I_pivot,
            "phi_0_rad": phi_0,
            "theta_unstable_rad": theta_unstable,
            "delta_h_max_m": delta_h_max,
            "v_at_step_m_s": v_at_step,
            "omega_after_rad_s": omega_after,
            "KE_rot_post_impact_J": KE_rot,
            "PE_threshold_J": KE_threshold,
            "topple_possible": topple_possible,
        },
        "numerical_method": {
            "solver": "RK45 with terminal events for the pivot phase; analytic kinematics elsewhere.",
            "tolerance": "rtol=1e-9, atol=1e-11, max_step=0.005",
            "justification": "Pivot ODE is smooth; impact and post-pivot phases use closed-form kinematic updates.",
        },
        "code_validation": {
            "ode_source": "Standard 2D rigid-body slide-impact-pivot sequence with Coulomb friction and angular-momentum conservation at the impulsive step impact.",
            "energy_check": (
                "Friction monotonically decreases KE during sliding; the step impact dissipates "
                f"KE by factor [I_pivot/(I_cm + M d^2)] (here ~unity since the pivot is the only contact). "
                "Topple-vs-swing-back outcome conserves energy along the gravity arc."
            ),
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Block slides {slide_dist:.3f} m on the lower level with friction "
            f"mu_floor={mu_floor:.3f} before reaching the step.",
            "Block pivots about the step's top corner; either topples to the upper level or swings back."
            if topple_possible else
            "Block lacks rotational KE to topple; swings back to lower floor and slides leftward.",
            "Final motion settles to rest within the simulation duration.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# spinning_ball_bounce
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_spinning_ball_bounce(params):
    R = params["R"]
    m = params["m"]
    g = params["g"]
    e_n = params["e_n"]
    mu = params["mu"]
    x0 = params["x0"]; y0 = params["y0"]
    vx0 = params["vx0"]; vy0 = params["vy0"]
    omega0 = params["omega0"]
    theta0 = params["theta0"]

    I_b = (2.0 / 5.0) * m * R * R
    vs0 = vx0 + omega0 * R
    Jn0 = -(1.0 + e_n) * m * vy0 if vy0 < 0 else 0.0  # only meaningful at impact
    return {
        "simulation": "spinning_ball_bounce",
        "physical_observation": (
            f"A solid ball of mass m={m:.3f} kg and radius R={R:.3f} m "
            f"(I = (2/5) m R^2 = {I_b:.5f} kg m^2) is launched from "
            f"({x0:.3f}, {y0:.3f}) m with initial velocity ({vx0:.3f}, {vy0:.3f}) m/s "
            f"and angular velocity omega_0={omega0:.3f} rad/s (CCW positive => "
            f"backspin when moving right). Free flight is purely ballistic; each "
            f"ground impact is resolved with normal restitution e_n={e_n:.3f} and "
            f"Coulomb friction mu={mu:.3f}."
        ),
        "physical_law": {
            "name": "Newton's laws for free flight + impulsive friction-cone (Routh) contact at the floor",
            "statement": (
                "Between bounces gravity acts on the ball's centre of mass; spin is "
                "conserved (no aerodynamic torque). At each contact the normal impulse "
                "J_n = -(1+e_n) m v_y (with v_y < 0 incoming) reverses the vertical "
                "velocity to -e_n v_y. The tangential impulse either drives the "
                "contact-point tangential velocity to zero (stick: J_t = -(2/7) m v_s) "
                "or saturates on the cone |J_t| = mu J_n (slip)."
            ),
            "formula": (
                "Free: vx' = 0, vy' = -g, omega' = 0. "
                "Bounce: J_n = -(1+e_n) m vy; J_t = clamp(-(2/7) m v_s, +/-mu J_n); "
                "vx <- vx + J_t/m; vy <- -e_n vy; omega <- omega + R J_t / I."
            ),
        },
        "ode_system": {
            "state_variables": ["x, y (m)", "vx, vy (m/s)", "omega (rad/s)", "theta (rad)"],
            "equations": [
                "dx/dt = vx, dy/dt = vy",
                "dvx/dt = 0, dvy/dt = -g",
                "domega/dt = 0, dtheta/dt = omega",
                "Plus impulsive jump at each (y - R = 0, vy < 0) event.",
            ],
        },
        "derivation_steps": [
            f"Solid sphere moment of inertia: I = (2/5) m R^2 = {I_b:.5f} kg m^2.",
            "Free flight ODE: only gravity acts, so trajectory is a parabola; spin and angular orientation evolve linearly.",
            "Bounce condition: y_c - R = 0 with vy < 0 (use solve_ivp event with direction = -1).",
            "Newton's restitution: vy' = -e_n vy.",
            "Tangential contact-point velocity: v_s = vx + omega R.",
            "Stick impulse (would zero v_s in one shot): J_t_stick = -(2/7) m v_s "
            "(reduced effective mass = m / (1 + m R^2 / I) = (2/7) m for solid sphere).",
            "If |J_t_stick| <= mu J_n, contact STICKS; else slips with J_t = -sign(v_s) mu J_n.",
            "Update post-bounce velocities and angular velocity accordingly.",
            "When the rebound speed is too small to clear gravity in one frame, switch to a settled rolling/sliding regime on the floor.",
        ],
        "physical_constants_derived": {
            "I_solid_sphere_kg_m2": I_b,
            "initial_contact_tangent_speed_vs0_m_s": vs0,
            "first_normal_impulse_J_n_estimate": Jn0,
            "free_fall_time_to_floor_s": (
                (vy0 + math.sqrt(max(vy0 * vy0 + 2 * g * (y0 - R), 0.0))) / g
                if y0 > R else 0.0
            ),
        },
        "numerical_method": {
            "solver": "RK45 with terminal events for ground contact; impulsive update at each event.",
            "tolerance": "rtol=1e-9, atol=1e-11, max_step=0.05",
            "justification": "Hybrid continuous-impulsive system; high-accuracy RK between bounces and exact impulse rules at each contact.",
        },
        "code_validation": {
            "ode_source": "Standard ballistic projectile + Routh friction-cone bounce model.",
            "energy_check": (
                f"Each bounce dissipates fraction (1 - e_n^2) = {1 - e_n*e_n:.4f} of the "
                "vertical kinetic energy plus any tangential dissipation when slipping; "
                "total mechanical energy strictly decreases."
            ),
            "physical_plausibility": True,
        },
        "expected_behavior": [
            "Ball undergoes a sequence of decreasing-amplitude bounces, eventually settling into rolling/sliding on the floor.",
            "Backspin (omega > 0) plus rightward motion (vx > 0) gives positive v_s; a stick impulse therefore reduces vx and omega in tandem.",
            "If friction is sufficient and backspin is heavy, the ball can reverse direction after the first bounce.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# spinning_disc_block_spring
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_spinning_disc_block_spring(params):
    g = params["g"]; m_b = params["m_b"]
    R_disc = params["R_disc"]; L_0 = params["L_0"]; k = params["k"]
    mu_s = params["mu_s"]; mu_k = params["mu_k"]
    omega_max = params["omega_max"]; t_ramp = params["t_ramp"]
    x_b_0 = params["x_b_0"]; y_b_0 = params["y_b_0"]

    omega_crit = math.sqrt(mu_s * g / L_0)
    t_slip = (omega_crit / omega_max) * t_ramp if omega_max > 0 else 0.0
    omega_n_spring = math.sqrt(k / m_b)
    T_spring = 2.0 * math.pi / omega_n_spring

    return {
        "simulation": "spinning_disc_block_spring",
        "physical_observation": (
            f"A circular disc of radius R={R_disc:.3f} m spins about its centre at the "
            f"origin with angular velocity omega(t) ramping linearly from 0 to "
            f"omega_max={omega_max:.3f} rad/s over t_ramp={t_ramp:.3f} s, then constant. "
            f"A small block of mass m_b={m_b:.3f} kg sits on the disc surface at initial "
            f"radius {math.hypot(x_b_0, y_b_0):.3f} m, tethered to the FIXED LAB origin "
            f"by a Hookean spring of stiffness k={k:.3f} N/m and rest length L_0={L_0:.3f} m. "
            f"Coulomb friction (mu_s={mu_s:.3f} static, mu_k={mu_k:.3f} kinetic) couples "
            f"the block to the disc surface."
        ),
        "physical_law": {
            "name": "Newton's laws + Coulomb friction (static/kinetic) + Hooke's spring law in non-inertial rotating contact",
            "statement": (
                "STICK: the block co-rotates with the disc, requiring static friction to "
                "supply m_b a_required - F_spring (centripetal + tangential). Slip onset "
                "when |F_required| > mu_s m_b g. SLIP: m_b dv/dt = -k (r - L_0) r_hat - "
                "mu_k m_b g v_slip / |v_slip|, where v_slip = v_block - omega x r."
            ),
            "formula": (
                "STICK: r=|r0|, position rotates rigidly with disc. "
                "SLIP ODE: m_b dv/dt = F_spring + F_friction. "
                "Slip-onset critical omega (at r=L_0): omega_crit = sqrt(mu_s g / L_0)."
            ),
        },
        "ode_system": {
            "state_variables": ["x, y (m)", "vx, vy (m/s)", "status in {0=stick, 1=slip}"],
            "equations": [
                "STICK: x(t) = r0 cos(phi0 + theta_disc(t)), y(t) = r0 sin(phi0 + theta_disc(t)).",
                "SLIP: m_b dvx/dt = -k (r - L_0) x/r + Ff_x, similarly y.",
                "Hybrid: switch when slip-onset criterion or v_slip drops below threshold.",
            ],
        },
        "derivation_steps": [
            "Set up disc-fixed and lab-fixed frames; spring anchored at lab origin.",
            "STICK regime: block point co-rotates with the disc surface point beneath it. "
            "Required centripetal+tangential acceleration in the lab frame must come from "
            "spring + static friction.",
            "Spring force at radius r: F_spring = -k (r - L_0) r_hat. At r = L_0 the spring is "
            "at rest length and exerts no force.",
            f"Slip onset criterion (at r=L_0): m_b L_0 omega^2 > mu_s m_b g, i.e. "
            f"omega_crit = sqrt(mu_s g / L_0) = {omega_crit:.4f} rad/s, "
            f"reached at t_slip ~ {t_slip:.4f} s.",
            "SLIP regime: integrate m_b dv/dt = F_spring + F_friction (kinetic). The friction "
            "force opposes the slip velocity v_slip = v_block - omega x r.",
            "Re-stick when |v_slip| drops below threshold AND required static friction at that "
            "moment is below the limit.",
        ],
        "physical_constants_derived": {
            "omega_critical_rad_s": omega_crit,
            "t_slip_onset_estimate_s": t_slip,
            "spring_omega_n_rad_s": omega_n_spring,
            "spring_period_s": T_spring,
            "initial_radius_m": math.hypot(x_b_0, y_b_0),
        },
        "numerical_method": {
            "solver": "Hybrid stick/slip integration: analytic kinematics during stick, RK45 with re-stick events during slip.",
            "tolerance": "rtol=1e-9, atol=1e-11, max_step=5e-3",
            "justification": "Capturing the transition between regimes precisely is critical; using analytic stick kinematics avoids numerical drift in radius.",
        },
        "code_validation": {
            "ode_source": "Newton's 2nd law in the lab frame with Coulomb friction; Hooke's law for the radial spring; smooth ramp in disc angular velocity.",
            "energy_check": "Friction monotonically removes energy from the relative slip; spring stores/releases energy elastically.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Block remains stuck while omega(t) < omega_crit ~ {omega_crit:.4f} rad/s (until t ~ {t_slip:.3f} s).",
            "Once slip begins, the block spirals outward, decelerated by the spring and kinetic friction.",
            "Possible re-sticking at larger radius if spring force balances out the centripetal requirement.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# spring_atwood
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_spring_atwood(params):
    g = params["g"]
    m_2 = params["m_2"]
    m_3 = params["m_3"]
    k = params["k"]
    L_0 = params["L_0"]
    y_floor = params["y_floor"]
    y_se_0 = params["y_se_0"]
    y_B_0 = params["y_B_0"]

    T_B_eq = 2.0 * m_2 * m_3 * g / (m_2 + m_3)
    T_A_eq = 2.0 * T_B_eq
    delta_eq = T_A_eq / k
    L_s_eq = L_0 + delta_eq
    y_se_eq = y_floor - L_s_eq
    omega_sq = (k / 4.0) * (1.0 / m_2 + 1.0 / m_3)
    omega = math.sqrt(omega_sq)
    period = 2.0 * math.pi / omega
    asym = abs(m_3 - m_2) / (m_2 + m_3)

    return {
        "simulation": "spring_atwood",
        "physical_observation": (
            f"Compound Atwood machine with a vertical Hookean spring (stiffness k={k:.3f} N/m, "
            f"natural length L_0={L_0:.3f} m) replacing the left hanging mass. The string over "
            f"fixed pulley A connects the spring's top to the axle of movable pulley B; the "
            f"rope over B carries m_2={m_2:.3f} kg and m_3={m_3:.3f} kg. Mass asymmetry "
            f"(m_3 - m_2)/(m_3 + m_2) = {asym:.4f} produces a slow gravity-driven drift "
            f"superimposed on a vertical bounce of the spring at angular frequency "
            f"omega = sqrt((k/4)(1/m_2 + 1/m_3)) = {omega:.4f} rad/s."
        ),
        "physical_law": {
            "name": "Newton's laws + ideal-string + ideal-spring constraints (massless inextensible cords, massless pulley B)",
            "statement": (
                "Massless inextensible cord on pulley A: y_se + y_B = const_A. "
                "Cord on movable pulley B: (y_2 - y_B) + (y_3 - y_B) = const_rope. "
                "Massless pulley B: T_A = 2 T_B. "
                "Spring: T_A = k (L_s - L_0) where L_s = y_floor - y_se."
            ),
            "formula": "m_i d^2 y_i/dt^2 = m_i g - T_B   for i in {2, 3}",
        },
        "ode_system": {
            "state_variables": ["y_2 (m, +y down)", "y_3 (m)", "v_2 (m/s)", "v_3 (m/s)"],
            "equations": [
                "dy_2/dt = v_2",
                "dy_3/dt = v_3",
                "y_B = (y_2 + y_3)/2 + C_pulley",
                "y_se = const_A - y_B",
                "L_s  = y_floor - y_se",
                "T_A  = k (L_s - L_0); T_B = T_A / 2",
                "dv_2/dt = g - T_B / m_2",
                "dv_3/dt = g - T_B / m_3",
            ],
        },
        "derivation_steps": [
            "Take +y as downward; ceiling at y=0; floor at y=y_floor.",
            "Pulley A is fixed; string over A is inextensible: y_se + y_B = const.",
            "Pulley B is movable, massless: tensions on the two sides of B sum to support T_A; T_A = 2 T_B.",
            "Rope over B is inextensible: (y_2 - y_B) + (y_3 - y_B) = const.",
            "From the two constraint equations, y_B is a linear function of (y_2 + y_3); y_se follows.",
            f"Spring: T_A = k (L_s - L_0); L_s = y_floor - y_se. T_B = T_A / 2.",
            "Newton's 2nd law on each mass: m_i a_i = m_i g - T_B.",
            f"Equilibrium tension: T_B_eq = 2 m_2 m_3 g / (m_2 + m_3) = {T_B_eq:.4f} N.",
            f"Equilibrium spring extension: Delta_eq = T_A_eq / k = {delta_eq:.4f} m.",
            f"Small-oscillation angular frequency: omega = sqrt((k/4)(1/m_2 + 1/m_3)) = {omega:.4f} rad/s, "
            f"period {period:.4f} s.",
        ],
        "physical_constants_derived": {
            "T_B_equilibrium_N": T_B_eq,
            "T_A_equilibrium_N": T_A_eq,
            "spring_extension_equilibrium_m": delta_eq,
            "L_s_equilibrium_m": L_s_eq,
            "y_se_equilibrium_m": y_se_eq,
            "oscillation_omega_rad_s": omega,
            "oscillation_period_s": period,
            "mass_asymmetry": asym,
        },
        "numerical_method": {
            "solver": "RK45",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": "Smooth ODE with no impacts (an event-based termination guards against m_2 reaching pulley B for unphysical parameter sets).",
        },
        "code_validation": {
            "ode_source": "Newton-Euler with massless inextensible string/rope and ideal Hookean spring; pulley B is massless so T_A = 2 T_B.",
            "energy_check": (
                "Total mechanical energy E = (1/2) m_2 v_2^2 + (1/2) m_3 v_3^2 - m_2 g y_2 - m_3 g y_3 "
                "+ (1/2) k (L_s - L_0)^2 should be conserved (no damping)."
            ),
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Spring oscillates at angular frequency {omega:.4f} rad/s "
            f"(period {period:.4f} s).",
            f"Mass asymmetry {asym:.4f} causes the heavier side to slowly accelerate downward "
            "while the lighter rises.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# spring_mass_string_fixed
# ────────────────────────────────────────────────────────────────────────────
import math


def cot_spring_mass_string_fixed(params):
    g = params["g"]
    m = params["m_mass"]
    k = params["k_spring"]
    L = params["L"]
    mu = params["mu"]
    T = params["T_str"]
    gamma_w = params["gamma_w"]
    tau_ramp = params["tau_ramp"]

    DeltaL_eq = m * g / k
    omega_s = math.sqrt(k / m)
    f_s = omega_s / (2 * math.pi)
    c = math.sqrt(T / mu)
    wavelength = c / f_s if f_s > 0 else float("inf")
    n_wavelengths = L / wavelength if wavelength > 0 else 0.0

    return {
        "simulation": "spring_mass_string_fixed",
        "physical_observation": (
            f"A vertical Hookean spring (k={k:.3f} N/m) hangs from a ceiling. A mass "
            f"m={m:.3f} kg released from the unstretched length performs SHM about its "
            f"equilibrium position with amplitude DeltaL_eq = m g / k = {DeltaL_eq:.4f} m "
            f"and angular frequency omega_s = sqrt(k/m) = {omega_s:.3f} rad/s. The mass's "
            f"vertical motion drives the LEFT end of a horizontal taut string of length "
            f"L={L:.3f} m, linear density mu={mu:.3f} kg/m, tension T={T:.3f} N, giving "
            f"wave speed c = sqrt(T/mu) = {c:.3f} m/s; the right end is fixed."
        ),
        "physical_law": {
            "name": "Driven 1D wave equation with viscous damping + spring-mass SHM (Hooke + Newton)",
            "statement": (
                "Mass: m d^2 y / dt^2 = -k (y - y_eq) (SHM with amplitude DeltaL_eq). "
                "String: u_tt = c^2 u_xx - 2 gamma_w u_t with Dirichlet BCs "
                "u(0, t) = ramp(t) y_mass(t) and u(L, t) = 0."
            ),
            "formula": "y(t) = DeltaL_eq cos(omega_s t); u_tt = c^2 u_xx - 2 gamma_w u_t",
        },
        "ode_system": {
            "state_variables": ["y(t) — mass vertical displacement", "u(x, t) — transverse string displacement"],
            "equations": [
                "y(t) = (m g / k) cos(sqrt(k/m) t)",
                "u_tt = (T/mu) u_xx - 2 gamma_w u_t,  0 < x < L",
                "u(0, t) = (1 - exp(-t/tau_ramp)) * y(t),  u(L, t) = 0",
            ],
        },
        "derivation_steps": [
            f"Spring equilibrium extension: DeltaL_eq = m g / k = {DeltaL_eq:.4f} m.",
            f"Spring-mass natural angular frequency: omega_s = sqrt(k/m) = {omega_s:.3f} rad/s "
            f"(= {f_s:.3f} Hz).",
            f"String wave speed: c = sqrt(T/mu) = {c:.3f} m/s.",
            f"Driven wavelength: lambda = c/f_s = {wavelength:.3f} m, "
            f"~{n_wavelengths:.3f} wavelengths fit on the string of length L.",
            "Wave equation derivation: small-amplitude transverse string under tension T and density mu yields "
            "u_tt = (T/mu) u_xx; viscous damping adds -2 gamma_w u_t.",
            f"Smooth ramp-in (1 - exp(-t/tau_ramp)) with tau_ramp={tau_ramp:.3f} s avoids the t=0 step discontinuity.",
            "Right end fixed: u(L, t) = 0 (Dirichlet BC).",
            "Numerical integration: explicit leapfrog FDM with centred-time damping, "
            "subject to CFL constraint (c dt / dx) ^2 < 1.",
        ],
        "physical_constants_derived": {
            "spring_extension_DeltaL_eq_m": DeltaL_eq,
            "omega_spring_rad_s": omega_s,
            "f_spring_Hz": f_s,
            "wave_speed_c_m_s": c,
            "wavelength_m": wavelength,
            "wavelengths_in_string": n_wavelengths,
        },
        "numerical_method": {
            "solver": "Explicit second-order leapfrog finite-difference for the wave equation; mass SHM treated analytically.",
            "tolerance": "CFL factor (c dt / dx)^2 < 1 enforced; spatial grid with N=200 cells, 16 sub-steps per video frame.",
            "justification": "Leapfrog is second-order, energy-stable, simple to implement; SHM is analytic so no integrator error from the source term.",
        },
        "code_validation": {
            "ode_source": "Wave equation u_tt = c^2 u_xx with linear viscous damping; spring-mass SHM via Hooke's law.",
            "energy_check": (
                "Wave energy E = ∫ ((mu/2) u_t^2 + (T/2) u_x^2) dx decays at rate 2 gamma_w E "
                "in the absence of forcing; with a sustained drive, E approaches a steady state."
            ),
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Mass oscillates sinusoidally at {omega_s:.3f} rad/s (period {2*math.pi/omega_s:.3f} s) "
            f"with amplitude {DeltaL_eq:.4f} m.",
            f"Driven string carries a travelling wave of wavelength {wavelength:.3f} m, "
            "reflecting at the fixed right end with phase reversal.",
            f"Damping coefficient gamma_w = {gamma_w:.3f} 1/s prevents long-time amplitude growth.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# spring_mass_string_ring
# ────────────────────────────────────────────────────────────────────────────
def cot_spring_mass_string_ring(params):
    import math
    g = params["g"]
    m_mass = params["m_mass"]
    k_spring = params["k_spring"]
    L = params["L"]
    mu = params["mu"]
    T_str = params["T_str"]
    gamma_w = params["gamma_w"]
    tau_ramp = params["tau_ramp"]

    DeltaL_eq = m_mass * g / k_spring
    omega_spring = math.sqrt(k_spring / m_mass)
    f_spring = omega_spring / (2 * math.pi)
    T_period = 2 * math.pi / omega_spring
    c = math.sqrt(T_str / mu)
    lam = 2 * math.pi * c / omega_spring
    n_wavelengths = L / lam
    return {
        "simulation": "spring_mass_string_ring",
        "physical_observation": (
            f"A vertical Hookean spring of stiffness k={k_spring:.3f} N/m hangs from a "
            f"ceiling; a cubical mass of m={m_mass:.3f} kg is attached at the bottom and "
            f"released from rest at the spring's unstretched length. Under gravity it "
            f"performs SHM with amplitude DeltaL_eq={DeltaL_eq:.4f} m and angular "
            f"frequency omega_spring={omega_spring:.3f} rad/s. The mass drives the left "
            f"end of a horizontal string (length L={L:.3f} m, tension T={T_str:.3f} N, "
            f"mu={mu:.3f} kg/m) connected to a free ring on a frictionless rod at x=L."
        ),
        "physical_law": {
            "name": "1-D Wave Equation with Linear Viscous Damping, Driven by SHM Mass-Spring; Free-End BC",
            "statement": "Decoupled spring-mass SHM provides a Dirichlet driver at the string's left end via a smooth ramp-in; the string is governed by the damped 1-D wave equation; the right end is a free, massless ring (Neumann BC).",
            "formula": (
                "y_mass(t) = DeltaL_eq cos(omega_spring t);  "
                "u_tt = c^2 u_xx - 2 gamma_w u_t;  "
                "u(0, t) = (1 - exp(-t/tau_ramp)) y_mass(t);  "
                "u_x(L, t) = 0"
            ),
        },
        "ode_system": {
            "state_variables": [
                "y_mass(t) (analytic SHM)",
                "u(x, t) (string transverse displacement)",
            ],
            "equations": [
                "y_mass(t) = DeltaL_eq * cos(omega_spring * t)",
                "u_tt = c^2 u_xx - 2 gamma_w u_t  (interior)",
                "u(0, t) = ramp(t) * y_mass(t)  (Dirichlet, left)",
                "u_x(L, t) = 0                    (Neumann/free, right)",
            ],
        },
        "derivation_steps": [
            f"Static equilibrium of mass: k DeltaL_eq = m g => DeltaL_eq = {DeltaL_eq:.4f} m.",
            f"Released from rest at unstretched length: SHM amplitude = DeltaL_eq, omega_spring = sqrt(k/m) = {omega_spring:.3f} rad/s.",
            f"Period: T = 2 pi/omega_spring = {T_period:.3f} s, frequency = {f_spring:.3f} Hz.",
            f"Wave phase speed: c = sqrt(T/mu) = sqrt({T_str:.3f}/{mu:.3f}) = {c:.3f} m/s.",
            f"Wavelength at driver frequency: lambda = 2 pi c / omega_spring = {lam:.3f} m, so {n_wavelengths:.3f} wavelengths fit in L.",
            "Wave equation derived from Newton II on a string element; viscous term -2 gamma_w u_t bounds long-time amplitude.",
            "Free-end ring (Neumann) gives reflection without phase inversion.",
        ],
        "physical_constants_derived": {
            "DeltaL_eq_m": DeltaL_eq,
            "omega_spring_rad_per_s": omega_spring,
            "f_spring_Hz": f_spring,
            "T_spring_period_s": T_period,
            "c_phase_speed_mps": c,
            "lambda_m": lam,
            "n_wavelengths_in_L": n_wavelengths,
            "tau_ramp_s": tau_ramp,
        },
        "numerical_method": {
            "solver": "Hybrid: closed-form SHM + leapfrog FDM with viscous damping",
            "tolerance": "CFL factor < 1; explicit second-order in space and time",
            "justification": "Mass dynamics decoupled (mu*L << m), so the SHM solution prescribes the left BC via a smooth ramp."
        },
        "code_validation": {
            "ode_source": "Hooke's law SHM + damped 1-D wave equation; Neumann free-end BC.",
            "energy_check": (
                "The prescribed spring-mass driver is an ideal SHM source in this reduced model. "
                "Wave-equation damping dissipates injected string energy until the driven envelope "
                "approaches a bounded steady state."
            ),
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Mass oscillates indefinitely at omega_spring={omega_spring:.3f} rad/s with amplitude {DeltaL_eq:.4f} m.",
            f"Wave train propagates rightward at c={c:.3f} m/s; leading edge reaches the ring at t = L/c = {L/c:.3f} s.",
            "Free-end reflection at the ring (no inversion) builds a near-standing wave with antinodes near the ring.",
            "Wave-equation damping limits the long-time string amplitude to a finite envelope.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# springs_two_slabs_compound
# ────────────────────────────────────────────────────────────────────────────
def cot_springs_two_slabs_compound(params):
    import math
    g = params["g"]
    m_1 = params["m_1"]
    m_2 = params["m_2"]
    K_top = params["K_top"]
    K_mid = params["K_mid"]
    L_top = params["L_top"]
    L_mid = params["L_mid"]
    gamma_1 = params["gamma_1"]
    gamma_2 = params["gamma_2"]
    y_ceil = params["y_ceil"]

    # Approximate uncoupled natural frequencies
    omega_1 = math.sqrt((K_top + K_mid) / m_1)
    omega_2 = math.sqrt(K_mid / m_2)
    T_1 = 2 * math.pi / omega_1
    T_2 = 2 * math.pi / omega_2
    return {
        "simulation": "springs_two_slabs_compound",
        "physical_observation": (
            f"From a rigid ceiling at y={y_ceil:.2f} m, parallel-springs of effective "
            f"stiffness K_top={K_top:.2f} N/m support an upper slab of mass m_1={m_1:.3f} kg. "
            f"From the upper slab, a second parallel-spring bank K_mid={K_mid:.2f} N/m hangs a "
            f"lower slab of mass m_2={m_2:.3f} kg. Linear viscous damping gamma_1={gamma_1:.3f} kg/s, "
            f"gamma_2={gamma_2:.3f} kg/s acts on each slab. The system oscillates and settles to "
            f"its damped two-mass equilibrium under gravity."
        ),
        "physical_law": {
            "name": "Newton's Second Law (Coupled Linear Spring-Mass System)",
            "statement": "Linear superposition of Hookean restoring forces, viscous damping, and gravity for two coupled DoF.",
            "formula": (
                "m_1 y1_dd = K_top (y_ceil - y_1 - L_top) - K_mid (y_1 - y_2 - L_mid) - gamma_1 v_1 - m_1 g; "
                "m_2 y2_dd = K_mid (y_1 - y_2 - L_mid) - gamma_2 v_2 - m_2 g"
            ),
        },
        "ode_system": {
            "state_variables": ["y_1", "y_2", "v_1", "v_2"],
            "equations": [
                "dy1/dt = v_1; dy2/dt = v_2",
                "dv1/dt = (K_top (y_ceil - y_1 - L_top) - K_mid (y_1 - y_2 - L_mid) - gamma_1 v_1 - m_1 g)/m_1",
                "dv2/dt = (K_mid (y_1 - y_2 - L_mid) - gamma_2 v_2 - m_2 g)/m_2",
            ],
        },
        "derivation_steps": [
            "Treat each spring bank as a single effective Hookean spring with K = sum of individual k.",
            "For the upper slab: top spring pulls up if stretched, middle spring pulls down on slab 1 if stretched.",
            "Hooke's law for each: F = K * stretch, where stretch = (separation distance) - rest length.",
            "Add gravity (-m g, downward) and viscous damping (-gamma v) to each equation.",
            f"Approx uncoupled natural frequencies: omega_1 = sqrt((K_top+K_mid)/m_1) = {omega_1:.3f} rad/s -> T_1 = {T_1:.3f} s; omega_2 = sqrt(K_mid/m_2) = {omega_2:.3f} rad/s -> T_2 = {T_2:.3f} s.",
        ],
        "physical_constants_derived": {
            "omega_1_uncoupled_rad_per_s": omega_1,
            "omega_2_uncoupled_rad_per_s": omega_2,
            "T_1_uncoupled_s": T_1,
            "T_2_uncoupled_s": T_2,
        },
        "numerical_method": {
            "solver": "scipy.solve_ivp RK45",
            "tolerance": "rtol=1e-9, atol=1e-11",
            "justification": "Smooth linear ODE; RK45 with tight tolerances captures both natural modes.",
        },
        "code_validation": {
            "ode_source": "Newton II for each slab with Hookean spring forces, gravity, and linear damping.",
            "energy_check": "Total mechanical energy decreases monotonically due to viscous damping; reaches static equilibrium asymptotically.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Upper slab oscillates near omega_1~{omega_1:.2f} rad/s, lower slab near omega_2~{omega_2:.2f} rad/s.",
            "Coupling between slabs gives two normal modes; damping makes the motion settle.",
            "Equilibrium positions shifted downward from rest lengths by gravity-induced stretches.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# stacked_balls_drop
# ────────────────────────────────────────────────────────────────────────────
def cot_stacked_balls_drop(params):
    import math
    g = params["g"]
    M = params["M"]
    R = params["R"]
    m = params["m"]
    r = params["r"]
    e_floor = params["e_floor"]
    e_b = params["e_b"]
    y_lower_0 = params["y_lower_0"]
    y_upper_0 = y_lower_0 + R + r
    v_drop_lower = math.sqrt(2 * g * (y_lower_0 - R))
    v_drop_upper = math.sqrt(2 * g * (y_upper_0 - (R + R + r)))  # same drop
    # After floor bounce: v_lower' = +e_floor*v_drop
    v_after_floor = e_floor * v_drop_lower
    # Approx upper ball gain (textbook 3x in idealized limit):
    vl = -v_drop_lower
    vu = -v_drop_lower
    new_vu = ((m - e_b * M) * vu + (1.0 + e_b) * M * v_after_floor) / (M + m)
    return {
        "simulation": "stacked_balls_drop",
        "physical_observation": (
            f"A heavy lower ball (M={M:.3f} kg, radius R={R:.3f} m) and a light upper "
            f"ball (m={m:.3f} kg, radius r={r:.3f} m) are stacked vertically and released "
            f"from rest with the lower-ball centre at {y_lower_0:.3f} m. They free-fall, "
            f"the lower ball strikes the floor with restitution e_floor={e_floor:.3f} and "
            f"is immediately struck from above by the still-falling upper ball "
            f"(restitution e_b={e_b:.3f}). The upper ball is launched upward at much "
            f"higher speed than its drop speed."
        ),
        "physical_law": {
            "name": "Newton's Laws of Motion + Newton's Law of Restitution for Hard-Body Collisions",
            "statement": "Both balls undergo free-fall under gravity (constant acceleration -g). Discrete impulsive collisions exchange velocities by Newton-restitution laws.",
            "formula": (
                "Free-fall: dv/dt = -g.  "
                "Floor: v_lower' = -e_floor v_lower.  "
                "Ball-ball: v_lower' = ((M - e_b m) v_lower + (1 + e_b) m v_upper)/(M + m); "
                "v_upper' = ((m - e_b M) v_upper + (1 + e_b) M v_lower)/(M + m)."
            ),
        },
        "ode_system": {
            "state_variables": ["y_lower (lower-ball centre)", "y_upper (upper-ball centre)", "v_lower", "v_upper"],
            "equations": [
                "dy_lower/dt = v_lower; dy_upper/dt = v_upper",
                "dv_lower/dt = -g; dv_upper/dt = -g  (free-flight)",
                "Floor event (y_lower=R, v_lower<0): v_lower <- -e_floor v_lower",
                "Ball-ball event (y_upper - y_lower = R + r): apply 1-D Newton restitution",
            ],
        },
        "derivation_steps": [
            f"Drop distance for lower-ball CoM to reach floor: y_lower_0 - R = {y_lower_0 - R:.3f} m.",
            f"Speed when lower ball hits floor: sqrt(2 g h) = {v_drop_lower:.3f} m/s.",
            f"After floor bounce: v_lower' = +e_floor * v_drop = {v_after_floor:.3f} m/s.",
            "Upper ball is still descending at the same speed (it dropped from the same height and has not yet been deflected).",
            "Apply 1-D Newton-restitution to the M-m collision; in the M >> m limit and e=1 this gives v_upper' approx 3 * v_drop.",
            f"Approximate upper-ball post-collision velocity (using v_after_floor for the lower): {new_vu:.3f} m/s.",
        ],
        "physical_constants_derived": {
            "v_drop_lower_mps": v_drop_lower,
            "v_after_floor_mps": v_after_floor,
            "approx_upper_post_collision_mps": new_vu,
            "mass_ratio_M_over_m": M / m,
        },
        "numerical_method": {
            "solver": "scipy.solve_ivp (RK45) with terminal events for floor and ball-ball contact",
            "tolerance": "rtol=1e-9, atol=1e-11; max_step=0.02 to bracket events accurately",
            "justification": "Hybrid integration: smooth free-flight ODE between impulsive collision events; standard for hard-body dynamics."
        },
        "code_validation": {
            "ode_source": "Newton II for free-fall and Newton's restitution law for hard-body collisions.",
            "energy_check": "Total energy decreases monotonically through both impacts; ratio is e_floor^2 and e_b^2 weighted by mass.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Lower ball reaches floor with speed ~{v_drop_lower:.2f} m/s and bounces.",
            "Upper ball is kicked upward at much higher speed than its drop speed (textbook stacked-ball amplification).",
            "Damped cascade of subsequent floor and ball-ball impacts until the system settles.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# string_block_wave
# ────────────────────────────────────────────────────────────────────────────
def cot_string_block_wave(params):
    import math
    L = params["L"]
    mu = params["mu"]
    M_block = params["M_block"]
    g = params["g"]
    A = params["A"]
    s_pulse = params["s_pulse"]
    sigma = params["sigma"]
    T = M_block * g
    c = math.sqrt(T / mu)
    transit = (L - s_pulse) / c
    round_trip = 2.0 * L / c
    return {
        "simulation": "string_block_wave",
        "physical_observation": (
            f"A heavy block of mass M_block={M_block:.3f} kg hangs from a rigid ceiling "
            f"on a vertical taut string of length L={L:.3f} m and linear mass density "
            f"mu={mu:.3f} kg/m. The block's weight provides string tension T={T:.3f} N. "
            f"At t=0 a Gaussian transverse pulse of amplitude A={A:.3f} m, width "
            f"sigma={sigma:.3f} m centred at s_pulse={s_pulse:.3f} m travels DOWN at "
            f"c={c:.3f} m/s. It reflects from the heavy block (near-Dirichlet, sign-"
            f"inverting) and from the rigid ceiling (Dirichlet)."
        ),
        "physical_law": {
            "name": "1-D Linear Wave Equation with Inertial (Block) Boundary",
            "statement": "Newton II for transverse string element; Newton II for the block under transverse tension component.",
            "formula": "u_tt = c^2 u_ss; u(0,t)=0; M_block u_tt(L,t) = -T u_s(L,t); c=sqrt(T/mu)",
        },
        "ode_system": {
            "state_variables": ["u(s, t)"],
            "equations": [
                "u_tt = c^2 u_ss (interior)",
                "u(0, t) = 0 (rigid ceiling)",
                "M_block u_tt(L, t) = -T u_s(L, t) (block)",
            ],
        },
        "derivation_steps": [
            f"Tension supplied by block weight: T = M_block g = {M_block:.3f} * {g:.3f} = {T:.3f} N.",
            f"Phase speed: c = sqrt(T/mu) = sqrt({T:.3f}/{mu:.3f}) = {c:.3f} m/s.",
            f"Transit time pulse->block: (L - s_pulse)/c = {transit:.3f} s.",
            f"Round-trip time ceiling->block->ceiling: 2L/c = {round_trip:.3f} s.",
            "Block much heavier than the string mass mu*L => near-Dirichlet bottom BC; reflection inverts pulse phase.",
            "Ceiling is rigid => exact Dirichlet, full inversion on reflection.",
        ],
        "physical_constants_derived": {
            "tension_N": T,
            "c_phase_speed_mps": c,
            "transit_time_s": transit,
            "round_trip_time_s": round_trip,
            "mass_ratio_block_over_string": M_block / (mu * L),
        },
        "numerical_method": {
            "solver": "Explicit leapfrog FDM",
            "tolerance": "CFL factor < 1, sub-stepping if needed",
            "justification": "Leapfrog is stable and second-order; lumped boundary mass m_eff = M_block + 0.5*mu*dx makes the block BC second-order.",
        },
        "code_validation": {
            "ode_source": "Standard 1-D linear wave equation with mass-loaded boundary.",
            "energy_check": "No damping; total energy conserved up to leapfrog drift (<0.1% in 12 s).",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Pulse propagates downward at c={c:.2f} m/s, reaching block at t~{transit:.2f} s.",
            "Block barely moves (heavy compared to string mass); reflection is near-fixed-end with phase inversion.",
            f"Round-trip time wall-block-wall is ~{round_trip:.2f} s; multiple reflections during 12 s window.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# string_ring_wave
# ────────────────────────────────────────────────────────────────────────────
def cot_string_ring_wave(params):
    L = params["L"]
    T = params["T"]
    mu = params["mu"]
    m_ring = params["m_ring"]
    A = params["A"]
    x_pulse = params["x_pulse"]
    sigma = params["sigma"]

    c = (T / mu) ** 0.5
    round_trip = 2.0 * L / c
    transit = (L - x_pulse) / c
    return {
        "simulation": "string_ring_wave",
        "physical_observation": (
            f"A taut string of length L={L:.3f} m, tension T={T:.3f} N, linear mass "
            f"density mu={mu:.3f} kg/m connects a rigid wall at x=0 to a ring of mass "
            f"m_ring={m_ring:.3f} kg at x=L. A right-travelling Gaussian pulse of "
            f"amplitude A={A:.3f} m, width sigma={sigma:.3f} m centred at "
            f"x_pulse={x_pulse:.3f} m propagates along the string at c={c:.3f} m/s, "
            f"hits the ring at t={transit:.3f} s, partially reflects, returns to the "
            f"wall, and inverts there."
        ),
        "physical_law": {
            "name": "1-D Linear Wave Equation with Inertial (Ring) Boundary",
            "statement": "Newton's 2nd law for transverse string element gives the wave equation; the ring obeys Newton's 2nd law under the transverse component of string tension.",
            "formula": "y_tt = c^2 y_xx;  y(0,t)=0;  m_ring y_tt(L,t) = -T y_x(L,t);  c=sqrt(T/mu)"
        },
        "ode_system": {
            "state_variables": ["y(x, t) (transverse displacement)"],
            "equations": [
                "y_tt = c^2 y_xx (interior)",
                "y(0, t) = 0 (wall)",
                "m_ring y_tt(L, t) = -T y_x(L, t) (ring)",
            ],
        },
        "derivation_steps": [
            "Apply Newton's 2nd law to a small string element: mu * y_tt dx = T (y_x|_(x+dx) - y_x|_x).",
            "Take the limit dx->0 to obtain y_tt = (T/mu) y_xx, defining c = sqrt(T/mu).",
            f"Pulse speed: c = sqrt(T/mu) = sqrt({T:.3f}/{mu:.3f}) = {c:.3f} m/s.",
            f"Pulse-to-ring travel time: (L - x_pulse)/c = ({L:.3f}-{x_pulse:.3f})/{c:.3f} = {transit:.3f} s.",
            f"Round-trip wall-ring-wall: 2L/c = {round_trip:.3f} s.",
            "Right boundary: vertical force on ring = -T * dy/dx|_L; inertia m_ring gives the ODE m_ring y_tt = -T y_x.",
            "m_ring->0 reduces to free-end (Neumann); m_ring->infinity reduces to fixed-end (Dirichlet).",
        ],
        "physical_constants_derived": {
            "c_phase_speed_mps": c,
            "round_trip_time_s": round_trip,
            "pulse_to_ring_time_s": transit,
            "ring_mass_kg": m_ring,
        },
        "numerical_method": {
            "solver": "Explicit leapfrog FDM in space and time (second-order)",
            "tolerance": "CFL factor < 1; sub-stepping to maintain stability",
            "justification": "Leapfrog conserves the discrete wave energy when undamped; effective boundary mass m_ring + 0.5*mu*dx makes the ring BC second-order accurate."
        },
        "code_validation": {
            "ode_source": "Newton II for string element + Newton II for ring; standard derivation.",
            "energy_check": "No damping; total kinetic + potential energy is conserved up to leapfrog drift (<0.1% over 12 s).",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Pulse travels right at c={c:.3f} m/s, reaching the ring at t~{transit:.3f} s.",
            "Ring momentarily lifts the string by inertial response.",
            "Reflection from ring depends on m_ring vs mu*L (light ring => near-free reflection, no inversion).",
            "Reflection from rigid wall fully inverts pulse phase.",
            f"Round-trip time wall-ring-wall is {round_trip:.3f} s.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# three_body_gravity
# ────────────────────────────────────────────────────────────────────────────
def cot_three_body_gravity(params):
    import math
    G = params["G"]
    m1 = params["m1"]
    m2 = params["m2"]
    m3 = params["m3"]
    eps = params["eps"]
    r1x_0 = params["r1x_0"]; r1y_0 = params["r1y_0"]
    r2x_0 = params["r2x_0"]; r2y_0 = params["r2y_0"]
    v1x_0 = params["v1x_0"]; v1y_0 = params["v1y_0"]
    v2x_0 = params["v2x_0"]; v2y_0 = params["v2y_0"]

    r3x_0 = -(m1 * r1x_0 + m2 * r2x_0) / m3
    r3y_0 = -(m1 * r1y_0 + m2 * r2y_0) / m3
    v3x_0 = -(m1 * v1x_0 + m2 * v2x_0) / m3
    v3y_0 = -(m1 * v1y_0 + m2 * v2y_0) / m3

    M_total = m1 + m2 + m3
    KE0 = 0.5 * (m1*(v1x_0**2 + v1y_0**2) + m2*(v2x_0**2 + v2y_0**2) + m3*(v3x_0**2 + v3y_0**2))
    return {
        "simulation": "three_body_gravity",
        "physical_observation": (
            f"Three point masses (m1={m1:.3f} kg, m2={m2:.3f} kg, m3={m3:.3f} kg) "
            f"interact only via mutual Newtonian gravitation (G={G:.3f} in code units) in "
            f"otherwise empty 2-D space. Body 3's initial conditions are fixed by total-"
            f"momentum=0 and centre-of-mass=origin: r3=({r3x_0:.3f},{r3y_0:.3f}), "
            f"v3=({v3x_0:.3f},{v3y_0:.3f}). The COM stays at the origin throughout."
        ),
        "physical_law": {
            "name": "Newton's Law of Universal Gravitation + Newton's Second Law",
            "statement": "Each body experiences pairwise inverse-square attraction; sum gives net acceleration.",
            "formula": "ddot{r_i} = G * sum_{j!=i} m_j (r_j - r_i) / (|r_j - r_i|^2 + eps^2)^(3/2)",
        },
        "ode_system": {
            "state_variables": ["r1, r2, r3 (positions, 2-D)", "v1, v2, v3 (velocities, 2-D)"],
            "equations": [
                "dr_i/dt = v_i",
                "dv_i/dt = G * sum_{j!=i} m_j (r_j - r_i) / (|r_j - r_i|^2 + eps^2)^(3/2)",
            ],
        },
        "derivation_steps": [
            "Apply Newton's law of universal gravitation pairwise; sum forces on each body.",
            "Divide by m_i (Newton II) to get acceleration; gives 12-D first-order ODE for the 6 DoF (3 bodies x 2-D).",
            "Use softening eps to prevent the 1/r^3 singularity at close passes; this keeps the integrator well-behaved.",
            "Set body-3 IC from total-momentum=0 and COM=0 so dynamics stays bounded with COM stationary.",
            f"Conserved quantities: total energy, total momentum (=0 by construction), COM position (=0), L_z.",
        ],
        "physical_constants_derived": {
            "M_total_kg": M_total,
            "r3_initial": [r3x_0, r3y_0],
            "v3_initial": [v3x_0, v3y_0],
            "kinetic_energy_initial": KE0,
        },
        "numerical_method": {
            "solver": "DOP853 (Dormand-Prince 8th order)",
            "tolerance": "rtol=1e-11, atol=1e-13",
            "justification": "High-order with tight tolerances needed because three-body problem is chaotic and conservation drift accumulates.",
        },
        "code_validation": {
            "ode_source": "Newton's law of universal gravitation, summed pairwise.",
            "energy_check": "Total energy E and momentum P should be conserved to better than 1e-9 with DOP853.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            "Generic chaotic motion: small differences in IC lead to exponentially diverging trajectories.",
            "Bodies experience close passes occasionally; eps softening prevents numerical blow-up.",
            "Centre-of-mass remains at origin throughout the rendered run.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# three_gear_chain
# ────────────────────────────────────────────────────────────────────────────
def cot_three_gear_chain(params):
    N_A = params["N_A"]
    N_B = params["N_B"]
    N_C = params["N_C"]
    R_A = params["R_A"]
    R_B = R_A * N_B / N_A
    R_C = R_A * N_C / N_A
    r_pulley = params["r_pulley"]
    v_max = params["v_max"]
    t_ramp = params["t_ramp"]

    omega_A_max = v_max / r_pulley
    omega_B_max = omega_A_max * (N_A / N_B)
    omega_C_max = omega_A_max * (N_A / N_C)
    return {
        "simulation": "three_gear_chain",
        "physical_observation": (
            f"Three external spur gears are arranged in a horizontal line: A "
            f"(N_A={N_A} teeth, R={R_A:.3f} m), B (N_B={N_B} teeth, R={R_B:.3f} m, "
            f"the idler), and C (N_C={N_C} teeth, R={R_C:.3f} m). Adjacent pairs A-B "
            f"and B-C mesh externally; A and C do not touch. A flat belt loops over "
            f"a pulley (r_pulley={r_pulley:.3f} m) on gear A's shaft, ramping linearly "
            f"to v_max={v_max:.3f} m/s over t_ramp={t_ramp:.3f} s, then runs at constant speed."
        ),
        "physical_law": {
            "name": "Mesh Kinematics for External Spur Gears",
            "statement": "At a meshing pair, the pitch-line speeds are equal in magnitude and the rotations are in opposite senses: omega_i N_i = -omega_j N_j.",
            "formula": "omega_A = +belt_v / r_pulley;  omega_B = -omega_A N_A/N_B;  omega_C = -omega_B N_B/N_C = +omega_A N_A/N_C",
        },
        "ode_system": {
            "state_variables": ["theta_A, theta_B, theta_C (gear angles)"],
            "equations": [
                "d theta_A / dt = belt_v(t) / r_pulley",
                "d theta_B / dt = -(N_A/N_B) d theta_A / dt",
                "d theta_C / dt = +(N_A/N_C) d theta_A / dt",
            ],
        },
        "derivation_steps": [
            "External meshing: pitch-line speeds match in magnitude, rotations are opposite in sign.",
            "A-B mesh: omega_A R_A = -omega_B R_B; combined with R_i=m N_i (common module), omega_A N_A = -omega_B N_B.",
            "B-C mesh similarly: omega_B N_B = -omega_C N_C.",
            "Multiplying through: omega_C = +(N_A/N_C) omega_A; B's tooth count cancels because B is the idler.",
            f"omega_A_max = v_max / r_pulley = {v_max:.3f}/{r_pulley:.3f} = {omega_A_max:.3f} rad/s.",
            f"omega_B_max = omega_A_max * (N_A/N_B) = {omega_B_max:.3f} rad/s (CW).",
            f"omega_C_max = omega_A_max * (N_A/N_C) = {omega_C_max:.3f} rad/s (CCW).",
        ],
        "physical_constants_derived": {
            "R_B_m": R_B,
            "R_C_m": R_C,
            "omega_A_max_rad_per_s": omega_A_max,
            "omega_B_max_rad_per_s": omega_B_max,
            "omega_C_max_rad_per_s": omega_C_max,
            "speed_ratio_A_to_C": N_A / N_C,
        },
        "numerical_method": {
            "solver": "Closed-form kinematics",
            "tolerance": "Exact",
            "justification": "Pure kinematic constraint; no ODE integration needed.",
        },
        "code_validation": {
            "ode_source": "Mesh kinematics for external spur gears (rigid teeth, no slip).",
            "energy_check": "Kinematic only; no energy bookkeeping required.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Gear A spins CCW reaching omega_A_max~{omega_A_max:.3f} rad/s.",
            "Gear B spins CW (idler).",
            f"Gear C spins CCW (same direction as A) at omega_C~{omega_C_max:.3f} rad/s.",
            "Tooth interleaving is preserved throughout; belt hash marks advance with belt velocity.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# three_gear_middle_drive
# ────────────────────────────────────────────────────────────────────────────
def cot_three_gear_middle_drive(params):
    N_A = params["N_A"]
    N_B = params["N_B"]
    N_C = params["N_C"]
    R_A = params["R_A"]
    R_B = R_A * N_B / N_A
    R_C = R_A * N_C / N_A
    r_pulley = params["r_pulley"]
    v_max = params["v_max"]
    t_ramp = params["t_ramp"]

    omega_B_max = v_max / r_pulley
    omega_A_max = omega_B_max * (N_B / N_A)
    omega_C_max = omega_B_max * (N_B / N_C)
    return {
        "simulation": "three_gear_middle_drive",
        "physical_observation": (
            f"Three external spur gears in a horizontal line: A (left, N_A={N_A}, "
            f"R={R_A:.3f} m), B (middle, N_B={N_B}, R={R_B:.3f} m, DRIVEN), and C "
            f"(right, N_C={N_C}, R={R_C:.3f} m). A flat belt loops over a pulley "
            f"(r_pulley={r_pulley:.3f} m) on gear B, ramping linearly to "
            f"v_max={v_max:.3f} m/s over t_ramp={t_ramp:.3f} s. Each mesh flips the "
            f"rotation direction, so A and C both rotate opposite to B (and same as each other)."
        ),
        "physical_law": {
            "name": "Mesh Kinematics for External Spur Gears",
            "statement": "At a meshing pair, pitch-line speeds match in magnitude and rotations are opposite: omega_i N_i = -omega_j N_j.",
            "formula": "omega_B = +belt_v/r_pulley;  omega_A = -omega_B N_B/N_A;  omega_C = -omega_B N_B/N_C",
        },
        "ode_system": {
            "state_variables": ["theta_A, theta_B, theta_C"],
            "equations": [
                "d theta_B / dt = belt_v(t) / r_pulley",
                "d theta_A / dt = -(N_B/N_A) d theta_B / dt",
                "d theta_C / dt = -(N_B/N_C) d theta_B / dt",
            ],
        },
        "derivation_steps": [
            "External meshing: pitch-line velocity match in magnitude, opposite signs.",
            "B drives both A and C through the meshes; ratios are N_B/N_A and N_B/N_C respectively.",
            f"omega_B_max = v_max / r_pulley = {v_max:.3f}/{r_pulley:.3f} = {omega_B_max:.3f} rad/s.",
            f"omega_A_max = omega_B_max * (N_B/N_A) = {omega_A_max:.3f} rad/s (CW since B is CCW).",
            f"omega_C_max = omega_B_max * (N_B/N_C) = {omega_C_max:.3f} rad/s (CW).",
            "Speed ratios |omega_A|/|omega_B| = N_B/N_A < 1 and |omega_C|/|omega_B| = N_B/N_C < 1; B is fastest.",
        ],
        "physical_constants_derived": {
            "R_B_m": R_B,
            "R_C_m": R_C,
            "omega_B_max_rad_per_s": omega_B_max,
            "omega_A_max_rad_per_s": omega_A_max,
            "omega_C_max_rad_per_s": omega_C_max,
            "speed_ratio_A_over_B": N_B / N_A,
            "speed_ratio_C_over_B": N_B / N_C,
        },
        "numerical_method": {
            "solver": "Closed-form kinematics",
            "tolerance": "Exact",
            "justification": "Pure kinematic constraint with rigid teeth and no slip.",
        },
        "code_validation": {
            "ode_source": "Gear mesh kinematics for external spur gears.",
            "energy_check": "Kinematic only; no energy bookkeeping.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"B accelerates over {t_ramp:.2f} s to omega_B_max~{omega_B_max:.3f} rad/s (CCW).",
            "A and C rotate CW (opposite to B); both same direction as each other.",
            "B is fastest; A and C are slower because they have more teeth.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# tilting_wedge_cylinder
# ────────────────────────────────────────────────────────────────────────────
def cot_tilting_wedge_cylinder(params):
    import math
    g = params["g"]
    R = params["R"]
    H = params["H"]
    M = params["M"]
    mu_s = params["mu_s"]
    mu_k = params["mu_k"]
    mu_floor = params["mu_floor"]
    e_rest = params["e"]
    alpha_0 = params["alpha_0"]
    alpha_dot = params["alpha_dot"]
    L_slope = params["L_slope"]

    alpha_topple = math.atan(2.0 * R / H)
    t_topple = (alpha_topple - alpha_0) / alpha_dot
    I_centre = 0.25 * M * R**2 + (1.0 / 12.0) * M * H**2
    d_pivot = math.sqrt(R**2 + (H / 2.0)**2)
    I_pivot = I_centre + M * d_pivot**2
    a_slope = g * (math.sin(alpha_topple) - mu_k * math.cos(alpha_topple))
    return {
        "simulation": "tilting_wedge_cylinder",
        "physical_observation": (
            f"A right-triangular wedge (slope length L_slope={L_slope:.3f} m) sits on a horizontal floor "
            f"with its lower-left vertex pinned to the origin. The wedge's slope angle alpha grows "
            f"linearly at alpha_dot={alpha_dot:.4f} rad/s from alpha_0={alpha_0:.3f} rad. A solid "
            f"cylinder (radius R={R:.3f} m, height H={H:.3f} m, mass M={M:.3f} kg) stands upright "
            f"on the centre of the slope. Static friction mu_s={mu_s:.3f} (exceeds 2R/H={2*R/H:.3f}) "
            f"holds the cylinder rigidly to the slope until the topple-critical angle "
            f"alpha_topple = arctan(2R/H) = {alpha_topple:.4f} rad ({math.degrees(alpha_topple):.2f} deg) "
            f"is reached at t_topple~{t_topple:.3f} s."
        ),
        "physical_law": {
            "name": "Newton-Euler Rigid-Body Mechanics with Phase-Transitions",
            "statement": "Quasi-static rotation of the cylinder about its down-slope edge once gravity torque overcomes the resisting torque; coefficient-of-restitution impulse on landing; sliding under kinetic friction.",
            "formula": (
                "Topple condition: tan(alpha) >= 2R/H.  "
                "Topple ODE: I_pivot phi_dd = M g [(H/2) sin(phi+alpha) - R cos(phi+alpha)].  "
                "Slope slide: a = g (sin alpha - mu_k cos alpha).  "
                "Floor slide deceleration: mu_floor g."
            ),
        },
        "ode_system": {
            "state_variables": ["alpha (wedge tilt)", "phi (cylinder tilt about pivot edge)", "x_CoM, v"],
            "equations": [
                "d alpha / dt = alpha_dot (until t_topple)",
                "I_pivot phi_dd = M g [(H/2) sin(phi+alpha_topple) - R cos(phi+alpha_topple)]",
                "After topple landing: v <- e * sqrt(2 KE_pre / M); slide on slope at a_slope = g (sin alpha - mu_k cos alpha)",
                "Floor: dv/dt = -mu_floor g (sign opposes motion)",
            ],
        },
        "derivation_steps": [
            f"Topple critical angle: tan(alpha_topple) = 2R/H => alpha_topple = arctan(2R/H) = {alpha_topple:.4f} rad.",
            f"Moment of inertia about the down-slope base edge (parallel-axis theorem): I_pivot = I_centre + M d^2 = (1/4)M R^2 + (1/12)M H^2 + M(R^2 + (H/2)^2) = {I_pivot:.5f} kg m^2.",
            "Topple ODE derived by writing the gravity torque about the pivot edge as M g times the lever arm of CoM displacement above the pivot.",
            f"Tangential slope acceleration after landing: a_slope = g (sin alpha_topple - mu_k cos alpha_topple) = {a_slope:.3f} m/s^2.",
            "Inelastic landing: KE_post = e^2 KE_pre; v_slide_0 = sqrt(2 KE_post / M).",
            "Floor slide: simple uniform deceleration at mu_floor g until rest.",
        ],
        "physical_constants_derived": {
            "alpha_topple_rad": alpha_topple,
            "alpha_topple_deg": math.degrees(alpha_topple),
            "t_topple_s": t_topple,
            "I_pivot_kg_m2": I_pivot,
            "a_slope_m_per_s2": a_slope,
        },
        "numerical_method": {
            "solver": "Hybrid: kinematic phases + scipy.solve_ivp RK45 for the topple ODE with terminal event at phi=pi/2",
            "tolerance": "rtol=1e-9, atol=1e-11; max_step=0.01 to bracket the landing event",
            "justification": "Each phase has a closed-form or low-DoF ODE; phase transitions are deterministic so a hybrid integrator is accurate and fast.",
        },
        "code_validation": {
            "ode_source": "Newton-Euler for rigid-body topple; standard kinematics with friction for sliding phases.",
            "energy_check": "Energy decreases at each restitution + friction phase; sliding consumes mu_k * N * distance.",
            "physical_plausibility": True,
        },
        "expected_behavior": [
            f"Wedge tilts up linearly until alpha={alpha_topple:.4f} rad (~{t_topple:.2f} s).",
            "Cylinder topples about its down-slope edge through 90 deg, lands on its side.",
            "Restitution converts a fraction e^2 of the rotational KE into translational sliding KE.",
            "Cylinder slides down the slope (now stationary), tips onto floor, slides to rest under floor friction.",
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# toppling_cylinder_wedge
# ────────────────────────────────────────────────────────────────────────────
def cot_toppling_cylinder_wedge(params):
    import math
    g = params["g"]; alpha_deg = params["alpha_deg"]
    alpha = math.radians(alpha_deg)
    H_wedge = params["H_wedge"]; R = params["R_cyl"]; H = params["H_cyl"]
    m = params["m_cyl"]; mu_s = params["mu_slope"]; mu_f = params["mu_floor"]
    e = params["e_impact"]; s_pivot = params["s_pivot"]; dt_tip = params["dt_tip"]
    L_base = H_wedge / math.tan(alpha)
    L_slope = H_wedge / math.sin(alpha)
    I_CoM = 0.25 * m * R * R + (1./12.) * m * H * H
    d2 = R*R + (H/2.)**2
    I_pivot = I_CoM + m * d2
    cond_2RH = 2 * R / H
    tan_a = math.tan(alpha)
    a_slope = max(g * (math.sin(alpha) - mu_s * math.cos(alpha)), 0.05)
    return {
        "simulation": "toppling_cylinder_wedge",
        "physical_observation": (
            f"A fixed right-triangular wedge (slope angle alpha={alpha_deg:.2f} deg, "
            f"height H_wedge={H_wedge:.3f} m) rests on a flat floor. A cylinder "
            f"(R={R:.3f} m, H={H:.3f} m, m={m:.3f} kg) stands upright on the slope "
            f"at slope-position s_pivot={s_pivot:.3f} m. Since 2R/H={cond_2RH:.3f} < tan(alpha)={tan_a:.3f}, "
            f"the cylinder is statically unstable and topples down-slope, then slides, tips "
            f"over the slope foot, and slides on the floor under friction (mu_slope={mu_s:.2f}, "
            f"mu_floor={mu_f:.2f}, restitution e={e:.2f})."
        ),
        "physical_law": {
            "name": "Rigid-body topple about a pivot edge + Coulomb sliding friction + inelastic impact",
            "statement": "I_pivot * theta_ddot = m g [(H/2) sin(theta+alpha) - R cos(theta+alpha)]; "
                         "a_slope = g(sin alpha - mu_slope cos alpha); KE_post = e^2 KE_pre.",
            "formula": "I_pivot theta_ddot = m g [(H/2) sin(theta+alpha) - R cos(theta+alpha)]"
        },
        "ode_system": {
            "state_variables": ["theta (topple angle)", "theta_dot (angular velocity)",
                                "Phase 2-4: closed-form kinematics (s_CoM, x_CoM)"],
            "equations": [
                "Phase 1: I_pivot theta_ddot = m g[(H/2) sin(theta+alpha) - R cos(theta+alpha)]",
                "Phase 2: s_CoM(t) = s0 + v_slide_0 t + 0.5 a_slope t^2",
                "Phase 3: theta_b(t) = alpha (1 - t/dt_tip), x_lead = L_base + v_lead_h t",
                "Phase 4: x_CoM(t) = x0 + v_floor_0 t - 0.5 mu_floor g t^2"
            ]
        },
        "derivation_steps": [
            f"Topple condition: 2R/H = {cond_2RH:.3f}, tan(alpha) = {tan_a:.3f}.",
            f"Moment of inertia: I_CoM = (1/4) m R^2 + (1/12) m H^2 = {I_CoM:.4f} kg m^2.",
            f"Parallel-axis: I_pivot = I_CoM + m d^2 = {I_pivot:.4f} kg m^2 with d^2 = R^2 + (H/2)^2 = {d2:.4f}.",
            f"Lagrangian: theta_ddot = m g[(H/2) sin(theta+alpha) - R cos(theta+alpha)] / I_pivot.",
            f"Initial: theta(0)=0, theta_dot(0)=0; integrate until theta=pi/2.",
            f"Impact at theta=pi/2: KE_post = e^2 KE_pre, gives v_slide_0 = sqrt(2 KE_post / m).",
            f"Phase 2 sliding: a_slope = g(sin a - mu_s cos a) = {a_slope:.3f} m/s^2.",
            "Phase 3: kinematic linear angle interpolation alpha -> 0 over dt_tip.",
            "Phase 4: floor kinetic-friction decel mu_floor g."
        ],
        "physical_constants_derived": {
            "L_base_m": round(L_base, 4),
            "L_slope_m": round(L_slope, 4),
            "I_CoM_kg_m2": round(I_CoM, 6),
            "I_pivot_kg_m2": round(I_pivot, 6),
            "topple_condition_2R_over_H": round(cond_2RH, 4),
            "tan_alpha": round(tan_a, 4),
            "topple_condition_satisfied": cond_2RH < tan_a,
            "a_slope_m_per_s2": round(a_slope, 4),
        },
        "numerical_method": {
            "solver": "scipy.integrate.solve_ivp (RK45) with terminal event at theta=pi/2 for phase 1; closed-form kinematics for phases 2-4",
            "tolerance": "rtol=1e-9, atol=1e-11"
        },
        "code_validation": {
            "ode_source": "Lagrangian for rigid-body rotation about a pivot edge under gravity",
            "energy_check": "Phase 1 conservative; impact dissipates (1-e^2) of KE; phases 2,4 dissipate via friction",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Cylinder topples over ~0.6 s (depends on alpha, R, H).",
            f"Post-impact slide velocity ~{math.sqrt(2*e*e*0.5*I_pivot*1.0/m):.2f} m/s scale.",
            f"a_slope = {a_slope:.3f} m/s^2; cylinder slides to slope foot.",
            "Tip transition smooths the floor contact; cylinder slides on floor and stops."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# two_body_gravity
# ────────────────────────────────────────────────────────────────────────────
def cot_two_body_gravity(params):
    import math
    G = params["G"]; m1 = params["m1"]; m2 = params["m2"]
    a = params["a_orbit"]; e = params["e"]
    M = m1 + m2
    T = 2 * math.pi * math.sqrt(a**3 / (G * M))
    r_p = a * (1 - e); r_a = a * (1 + e)
    v_p = math.sqrt(G * M * (1+e) / (a * (1-e)))
    return {
        "simulation": "two_body_gravity",
        "physical_observation": (
            f"Two point masses (m1={m1:.3f}, m2={m2:.3f}) interact via Newton's law "
            f"of gravity (G={G:.3f}). Initial conditions are set at periapsis of a closed "
            f"elliptical orbit with semi-major axis a={a:.3f} and eccentricity e={e:.3f}. "
            f"Total momentum is zero so the centre of mass is stationary at the origin; "
            f"both bodies trace closed ellipses."
        ),
        "physical_law": {
            "name": "Newton's law of universal gravitation + Newton's third law",
            "statement": "F_{1<-2} = +G m1 m2 (r2 - r1) / |r2-r1|^3, F_{2<-1} = -F_{1<-2}",
            "formula": "ddot{r}_i = G m_j (r_j - r_i) / |r_j - r_i|^3"
        },
        "ode_system": {
            "state_variables": ["x1, y1, x2, y2 (positions)", "vx1, vy1, vx2, vy2 (velocities)"],
            "equations": [
                "dx_i/dt = vx_i, dy_i/dt = vy_i",
                "dvx_1/dt = +G m2 (x2-x1)/r^3, dvy_1/dt = +G m2 (y2-y1)/r^3",
                "dvx_2/dt = -G m1 (x2-x1)/r^3, dvy_2/dt = -G m1 (y2-y1)/r^3"
            ]
        },
        "derivation_steps": [
            f"Reduced mass mu = m1 m2 / M = {m1*m2/M:.4f}.",
            f"Periapsis distance r_p = a(1-e) = {r_p:.4f}.",
            f"Apoapsis distance  r_a = a(1+e) = {r_a:.4f}.",
            f"Vis-viva at periapsis: v_p = sqrt(G M (1+e)/(a(1-e))) = {v_p:.4f}.",
            f"CM at origin: r1 = -(m2/M) r_p e_x, r2 = +(m1/M) r_p e_x.",
            f"Zero total momentum: v1 = +(m2/M) v_p e_y, v2 = -(m1/M) v_p e_y.",
            f"Kepler period: T = 2 pi sqrt(a^3 / (G M)) = {T:.4f}."
        ],
        "physical_constants_derived": {
            "M_total": M,
            "reduced_mass": m1*m2/M,
            "T_orbit": T,
            "r_periapsis": r_p,
            "r_apoapsis": r_a,
            "v_periapsis": v_p,
        },
        "numerical_method": {
            "solver": "scipy.integrate.solve_ivp method='DOP853' (8th-order Runge-Kutta)",
            "tolerance": "rtol=1e-12, atol=1e-14",
            "justification": "Kepler orbits demand tight tolerances to preserve the closed ellipse"
        },
        "code_validation": {
            "ode_source": "Newton's gravitation; Newton's 3rd law for action-reaction pair",
            "energy_check": "E = 0.5 m1 v1^2 + 0.5 m2 v2^2 - G m1 m2 / r conserved",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Closed elliptical orbits with period T = {T:.3f}.",
            f"Periapsis r_p = {r_p:.3f}, apoapsis r_a = {r_a:.3f}.",
            "CM stays at origin; bodies move on opposite sides scaled by mass ratio."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# two_carts_slack_string
# ────────────────────────────────────────────────────────────────────────────
def cot_two_carts_slack_string(params):
    import math
    g = params["g"]; m_L = params["m_L"]; m_R = params["m_R"]
    L_s = params["L_s"]; mu_f = params["mu_f"]
    x_L_0 = params["x_L_0"]; x_R_0 = params["x_R_0"]
    v_R_0 = params["v_R_0"]
    a_dec = mu_f * g
    sep_0 = x_R_0 - x_L_0
    disc = v_R_0**2 - 2.0 * a_dec * (L_s - sep_0)
    if disc > 0:
        t_star = (v_R_0 - math.sqrt(disc)) / a_dec
    else:
        t_star = float("nan")
    v_R_pre = v_R_0 - a_dec * (t_star if disc > 0 else 0.0)
    v_common = (m_R * v_R_pre) / (m_L + m_R)
    mu_red = m_L * m_R / (m_L + m_R)
    dKE = 0.5 * mu_red * v_R_pre**2
    return {
        "simulation": "two_carts_slack_string",
        "physical_observation": (
            f"Two carts on a horizontal rail (mass m_L={m_L:.3f}, m_R={m_R:.3f}) connected by an "
            f"inextensible string of rest-length L_s={L_s:.3f} m, initially slack. Cart R has "
            f"v_R_0={v_R_0:.3f} m/s rightward; cart L is at rest. Coulomb friction (mu_f={mu_f:.3f}) "
            f"acts on both carts."
        ),
        "physical_law": {
            "name": "Newton's 2nd law + Coulomb kinetic friction + inextensible-string constraint (jerk impulse)",
            "statement": "While slack, each cart decelerates independently at mu_f g. When the string goes taut, an "
                         "instantaneous inelastic constraint equalises along-string velocities; energy lost = (1/2) mu_red (v_R - v_L)^2.",
            "formula": "v' = (m_L v_L + m_R v_R)/(m_L+m_R); dKE = (1/2)(m_L m_R/(m_L+m_R))(v_R-v_L)^2"
        },
        "ode_system": {
            "state_variables": ["x_L, v_L (left cart)", "x_R, v_R (right cart)"],
            "equations": [
                "Phase 1 (slack): dv_L/dt = -mu_f g sgn(v_L), dv_R/dt = -mu_f g sgn(v_R)",
                "Phase 2 (jerk): impulsive: v_L, v_R -> v' = (m_L v_L + m_R v_R)/(m_L+m_R)",
                "Phase 3 (taut): both carts move at common v(t) decelerating at mu_f g"
            ]
        },
        "derivation_steps": [
            f"a_dec = mu_f g = {a_dec:.4f} m/s^2.",
            f"Initial separation = {sep_0:.3f} m, slack distance to taut = {L_s - sep_0:.3f} m.",
            f"Phase 1 motion: separation s(t) = sep_0 + v_R_0 t - 0.5 a_dec t^2.",
            f"Solve s(t) = L_s for t* (earliest positive root).",
            f"t* = {t_star:.4f} s; v_R at jerk = {v_R_pre:.4f} m/s.",
            f"Reduced mass mu_red = m_L m_R/(m_L+m_R) = {mu_red:.4f} kg.",
            f"Common velocity after jerk = {v_common:.4f} m/s.",
            f"Energy lost in jerk dKE = {dKE:.4f} J."
        ],
        "physical_constants_derived": {
            "a_dec": round(a_dec, 4),
            "t_star": round(t_star, 4) if disc > 0 else None,
            "v_R_pre_jerk": round(v_R_pre, 4),
            "v_common_after_jerk": round(v_common, 4),
            "energy_lost_J": round(dKE, 4),
        },
        "numerical_method": {
            "solver": "Closed-form analytical kinematics (no ODE integration needed)",
            "tolerance": "Exact within IEEE float"
        },
        "code_validation": {
            "ode_source": "Newton 2nd + Coulomb friction; inelastic string-jerk constraint",
            "energy_check": "Energy decreases by friction (continuous) and by dKE (instantaneous at jerk)",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Right cart slows from {v_R_0:.2f} m/s while left cart stays still (slack phase).",
            f"At t* = {t_star:.3f} s the string goes taut and a velocity-equalising jerk fires.",
            f"Both carts then move together at {v_common:.3f} m/s, decelerating to rest."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# two_conveyor_drop
# ────────────────────────────────────────────────────────────────────────────
def cot_two_conveyor_drop(params):
    g = params["g"]; v1 = params["v_belt1"]; v2 = params["v_belt2"]
    mu1 = params["mu_belt1"]; mu2 = params["mu_belt2"]; muf = params["mu_floor"]
    return {
        "simulation": "two_conveyor_drop",
        "physical_observation": (
            f"A cube falls onto an upper conveyor belt (v_belt1={v1:+.3f} m/s) and slips on it "
            f"under Coulomb friction (mu_belt1={mu1:.2f}) until it co-moves; rides off the right "
            f"edge, falls onto a lower belt running in the opposite direction (v_belt2={v2:+.3f} m/s, "
            f"mu_belt2={mu2:.2f}); slips again, rides leftward off the belt's left edge, falls to the "
            f"floor and slides under friction (mu_floor={muf:.2f}) to rest."
        ),
        "physical_law": {
            "name": "Newton's 2nd law + Coulomb kinetic friction; eight closed-form phases",
            "statement": "Free fall: y = y0 + vy0 t - (1/2) g t^2. Slip on belt: dvx/dt = -mu g sign(vx - v_belt). Co-move on belt: vx = v_belt.",
            "formula": "Phase-wise constant-acceleration kinematics + transitions"
        },
        "ode_system": {
            "state_variables": ["x, y (cube CoM)", "vx, vy"],
            "equations": [
                "Free fall: dx/dt = vx, dy/dt = vy, dvy/dt = -g, dvx/dt = 0",
                "Slip on belt: dvx/dt = -mu g sign(vx - v_belt), dvy/dt = 0",
                "Riding belt: vx = v_belt, dy/dt = 0"
            ]
        },
        "derivation_steps": [
            "Phase 1: free fall onto belt 1.",
            "Phase 2: slip on belt 1 -- friction accelerates cube to v_belt1.",
            "Phase 3: co-move with belt 1 to its right edge.",
            "Phase 4: free fall belt 1 -> belt 2.",
            "Phase 5: slip on belt 2 -- friction decelerates and reverses cube.",
            "Phase 6: co-move with belt 2 to its left edge.",
            "Phase 7: free fall belt 2 -> floor.",
            "Phase 8: floor friction decelerates cube to rest."
        ],
        "physical_constants_derived": {
            "a_belt1": mu1 * g,
            "a_belt2": -mu2 * g,
            "a_floor": muf * g,
        },
        "numerical_method": {
            "solver": "Closed-form constant-acceleration kinematics (8 phases)",
            "tolerance": "Exact within IEEE float"
        },
        "code_validation": {
            "ode_source": "Newton 2nd law + Coulomb friction; phase boundaries from kinematics",
            "energy_check": (
                "Friction dissipates mechanical energy, gravity exchanges potential and kinetic energy, "
                "and moving belts can do positive or negative work on the block depending on relative velocity."
            ),
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Cube lands on belt 1, accelerates to {v1:.2f} m/s.",
            f"Falls to belt 2 (going opposite direction at {v2:.2f} m/s) and reverses.",
            "Falls to floor and slides to rest."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# two_gear_belt
# ────────────────────────────────────────────────────────────────────────────
def cot_two_gear_belt(params):
    import math
    N_A = int(round(params["N_A"])); N_B = int(round(params["N_B"]))
    R_A = params["R_A"]; r_pulley = params["r_pulley"]
    v_max = params["v_max"]; t_ramp = params["t_ramp"]
    R_B = R_A * N_B / N_A
    omega_A_max = v_max / r_pulley
    omega_B_max = omega_A_max * (N_A / N_B)
    return {
        "simulation": "two_gear_belt",
        "physical_observation": (
            f"A flat belt with off-frame motor pulley wraps around a small pulley (r={r_pulley:.3f} m) "
            f"on gear A's central shaft. Gear A (N_A={N_A} teeth, R_A={R_A:.3f} m) meshes with a "
            f"smaller gear B (N_B={N_B} teeth, R_B={R_B:.3f} m). Belt accelerates from rest to "
            f"v_max={v_max:.3f} m/s over t_ramp={t_ramp:.2f} s, driving gear A CCW and gear B CW."
        ),
        "physical_law": {
            "name": "Belt-pulley kinematics + spur-gear mesh constraint (pitch-line equality)",
            "statement": "omega_A = v_belt / r_pulley; omega_B = -omega_A (N_A / N_B); R_B = R_A (N_B/N_A)",
            "formula": "omega_A(t) = v_belt(t)/r_pulley; omega_B(t) = -(N_A/N_B) omega_A(t)"
        },
        "ode_system": {
            "state_variables": ["theta_A (gear A angle)", "theta_B (gear B angle)"],
            "equations": [
                "dtheta_A/dt = v_belt(t)/r_pulley",
                "dtheta_B/dt = -(N_A/N_B) dtheta_A/dt"
            ]
        },
        "derivation_steps": [
            f"Belt cumulative arc-length: integrate v_belt(t) (ramp then constant).",
            f"Gear A angular speed: omega_A = v_belt/r_pulley = {omega_A_max:.4f} rad/s at v_max.",
            f"Mesh constraint at pitch line: R_A omega_A = -R_B omega_B.",
            f"Hence omega_B = -(R_A/R_B) omega_A = -(N_A/N_B) omega_A = {-omega_B_max:.4f} rad/s at v_max.",
            f"R_B fixed by shared diametral pitch: R_B = R_A N_B/N_A = {R_B:.4f} m."
        ],
        "physical_constants_derived": {
            "R_B": round(R_B, 4),
            "omega_A_max": round(omega_A_max, 4),
            "omega_B_max": round(-omega_B_max, 4),
            "speed_ratio_NA_over_NB": round(N_A / N_B, 4)
        },
        "numerical_method": {
            "solver": "Closed-form kinematic integration (no dynamics)",
            "tolerance": "Exact"
        },
        "code_validation": {
            "ode_source": "Belt-pulley kinematic constraint; spur-gear pitch-line equality",
            "energy_check": "Quasi-static; no dissipation modelled",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Gear A spins CCW at {omega_A_max:.2f} rad/s after ramp.",
            f"Gear B spins CW at {omega_B_max:.2f} rad/s (faster by N_A/N_B = {N_A/N_B:.2f})."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# wave_interference
# ────────────────────────────────────────────────────────────────────────────
def cot_wave_interference(params):
    import math
    T = params["T"]; mu = params["mu"]
    c = math.sqrt(T / mu)
    A_R = params["A_R"]; A_L = params["A_L"]
    sR = params["sigma_R"]; sL = params["sigma_L"]
    xR0 = params["x_R0"]; xL0 = params["x_L0"]
    return {
        "simulation": "wave_interference",
        "physical_observation": (
            f"Two Gaussian pulses on an infinite taut string travel toward each other at "
            f"common speed c=sqrt(T/mu)={c:.3f} m/s (T={T:.3f} N, mu={mu:.3f} kg/m). "
            f"Right-mover: A_R={A_R:+.3f}, sigma_R={sR:.3f} m, x_R0={xR0:+.3f}. "
            f"Left-mover: A_L={A_L:+.3f}, sigma_L={sL:.3f} m, x_L0={xL0:+.3f}. "
            f"They superpose linearly at the meeting and emerge unchanged."
        ),
        "physical_law": {
            "name": "1D wave equation (linear superposition)",
            "statement": "d^2 y/dt^2 = c^2 d^2 y/dx^2; superposition holds for any linear PDE.",
            "formula": "y(x,t) = f(x - c t) + g(x + c t) (d'Alembert)"
        },
        "ode_system": {
            "state_variables": ["y(x,t) string displacement"],
            "equations": ["d^2 y/dt^2 = c^2 d^2 y/dx^2"]
        },
        "derivation_steps": [
            f"Wave speed c = sqrt(T/mu) = {c:.4f} m/s.",
            "d'Alembert decomposition: y = f(x-ct) + g(x+ct).",
            f"Right-mover: f(x) = A_R exp(-(x-x_R0)^2 / (2 sigma_R^2)) with v_y0 = -c f'(x).",
            f"Left-mover: g(x) = A_L exp(-(x-x_L0)^2 / (2 sigma_L^2)) with v_y0 = +c g'(x).",
            "Initial state: y0 = f + g, dy/dt|0 = -c f' + c g'.",
            "Discretize with leapfrog FDM; CFL condition: c dt/dx < 1."
        ],
        "physical_constants_derived": {
            "wave_speed_c": round(c, 4),
            "meeting_time_estimate": round((xL0 - xR0) / (2 * c), 4)
        },
        "numerical_method": {
            "solver": "Explicit second-order leapfrog finite-difference scheme on a uniform grid",
            "tolerance": "CFL-stable: factor = (c dt/dx)^2 < 1; auto-clamped when needed"
        },
        "code_validation": {
            "ode_source": "Linear 1D wave equation",
            "energy_check": "Total integrated (1/2)(y_t^2 + c^2 y_x^2) approximately conserved",
            "physical_plausibility": True
        },
        "expected_behavior": [
            "Two Gaussian pulses converge, momentarily superpose, then separate intact.",
            "Linear superposition: shapes pass through each other without distortion."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# wedge_block
# ────────────────────────────────────────────────────────────────────────────
def cot_wedge_block(params):
    import math
    alpha_deg = params["alpha_deg"]; alpha = math.radians(alpha_deg)
    L_w = params["L_wedge"]; H_w = L_w * math.tan(alpha)
    M = params["M_wedge"]; m = params["m_block"]
    mu_bs = params["mu_block_slope"]; mu_w = params["mu_w"]; mu_f = params["mu_floor"]
    g = params["g"]
    return {
        "simulation": "wedge_block",
        "physical_observation": (
            f"A wedge (mass M={M:.3f}, base L={L_w:.3f} m, slope angle alpha={alpha_deg:.2f} deg, "
            f"H={H_w:.3f} m) sits on a friction floor. A block (m={m:.3f}, "
            f"W={params['W_block']:.3f} m, H={params['H_block']:.3f} m) is at rest at the top of the slope. "
            f"Released, the block slides down (slope friction mu_bs={mu_bs:.2f}) while reaction pushes "
            f"the wedge LEFT against floor friction (mu_w={mu_w:.3f})."
        ),
        "physical_law": {
            "name": "Lagrangian mechanics with constraint forces + Coulomb friction",
            "statement": "Generalised coords X (wedge), s (block down-slope arc-length). KE quadratic in (Xdot, sdot); friction enters as generalised force.",
            "formula": "Linear 2x2 system A [aX, as]^T = b for accelerations under constant friction signs"
        },
        "ode_system": {
            "state_variables": ["X (wedge x)", "s (block slope arc-length)", "Vx, Vs"],
            "equations": [
                "Phase 1: solve [(M+m), m cos alpha; m cos alpha, m] [aX; as] = ...",
                "Tip: theta_b = alpha (1 - t/dt_tip), B_x = const + v t",
                "Phase 2: aX = -sign(Vx) mu_w g, ax_block = -sign(vx) mu_floor g"
            ]
        },
        "derivation_steps": [
            f"alpha = {alpha:.4f} rad ({alpha_deg:.2f} deg).",
            "Coordinates: X_wedge, s_block. KE includes coupling cos(alpha) X_dot s_dot.",
            "Approximate normal forces: N_slope = m g cos alpha, N_floor = (M+m) g.",
            "Friction forces enter as generalised forces. Solve 2x2 linear system for (aX, as).",
            f"Tip transition: linear interpolation theta_b: alpha -> 0 over dt_tip = {params['dt_tip']:.3f}.",
            "Phase 2: independent decel under floor friction for both bodies."
        ],
        "physical_constants_derived": {
            "alpha_rad": round(alpha, 4),
            "H_wedge_m": round(H_w, 4),
            "L_slope_m": round(math.hypot(L_w, H_w), 4),
            "tan_alpha": round(math.tan(alpha), 4)
        },
        "numerical_method": {
            "solver": "Closed-form: 2x2 linear solve for phase-1 accelerations + closed-form kinematics",
            "tolerance": "Exact within IEEE float"
        },
        "code_validation": {
            "ode_source": "Euler-Lagrange equations for two-DoF wedge+block; Coulomb friction",
            "energy_check": "Energy decreases monotonically through three friction sinks",
            "physical_plausibility": True
        },
        "expected_behavior": [
            "Block slides down wedge while wedge slides left (momentum exchange).",
            "Tip transition smooths block's landing; both decelerate to rest on floor."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# wedge_sphere
# ────────────────────────────────────────────────────────────────────────────
def cot_wedge_sphere(params):
    import math
    alpha_deg = params["alpha_deg"]; alpha = math.radians(alpha_deg)
    L_w = params["L_wedge"]; H_w = L_w * math.tan(alpha)
    M = params["M_wedge"]; m = params["m_sphere"]; R = params["R_sphere"]
    mu_w = params["mu_w"]; mu_r = params["mu_r"]; g = params["g"]
    return {
        "simulation": "wedge_sphere",
        "physical_observation": (
            f"A wedge (M={M:.3f} kg, base L={L_w:.3f} m, slope alpha={alpha_deg:.2f} deg, "
            f"H={H_w:.3f} m) on a friction floor (mu_w={mu_w:.3f}). A solid sphere "
            f"(m={m:.3f} kg, R={R:.3f} m) rolls without slipping down the slope; reaction "
            f"pushes the wedge LEFT. Sphere transitions to floor and decelerates under "
            f"rolling resistance (mu_r={mu_r:.3f})."
        ),
        "physical_law": {
            "name": "Lagrangian mechanics + rolling-without-slip constraint + Coulomb friction",
            "statement": "T = (1/2)(M+m) Xdot^2 + m cos(alpha) Xdot sdot + (7/10) m sdot^2 (with rolling); V = m g (H - s sin alpha + R cos alpha).",
            "formula": "Linear 2x2 system A [aX, as]^T = b under constant friction signs"
        },
        "ode_system": {
            "state_variables": ["X (wedge x)", "s (sphere arc-length down slope)", "Vx, Vs"],
            "equations": [
                "Phase 1: solve [(M+m), m cos alpha; m cos alpha, (7/5) m] [aX; as] = [+mu_w (M+m) g; m g sin alpha]",
                "Phase 2: aX = -sign(Vx) mu_w g; ax_sphere = -sign(vx) mu_r g"
            ]
        },
        "derivation_steps": [
            f"alpha = {alpha:.4f} rad ({alpha_deg:.2f} deg).",
            "Rolling constraint: omega = -sdot/R. KE includes rotational (2/5) m R^2 omega^2 → effective (7/5) m sdot^2 / 2.",
            "Solve 2x2 linear system for (aX, as) under floor-friction sign convention.",
            f"Transition: sphere center reaches y=R when s = (H + R cos alpha - R)/sin alpha.",
            "Phase 2: independent decel for wedge (mu_w g) and sphere (rolling resistance mu_r g)."
        ],
        "physical_constants_derived": {
            "alpha_rad": round(alpha, 4),
            "H_wedge_m": round(H_w, 4),
            "L_slope_m": round(math.hypot(L_w, H_w), 4)
        },
        "numerical_method": {
            "solver": "Closed-form 2x2 linear solve (phase 1) + closed-form kinematics (phase 2)",
            "tolerance": "Exact within IEEE float"
        },
        "code_validation": {
            "ode_source": "Euler-Lagrange with rolling constraint; Coulomb floor friction; rolling resistance",
            "energy_check": "Total KE + PE decreases monotonically under floor friction & rolling resistance",
            "physical_plausibility": True
        },
        "expected_behavior": [
            "Sphere rolls down slope; wedge slides left.",
            "Sphere transitions to floor and decelerates under rolling resistance.",
            "Both stop within video duration."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# wheel_belt_drop
# ────────────────────────────────────────────────────────────────────────────
def cot_wheel_belt_drop(params):
    g = params["g"]; m = params["m"]; r_w = params["r_w"]
    v_belt = params["v_belt"]; mu_belt = params["mu_belt"]
    mu_g = params["mu_g"]; e_g = params["e_g"]
    I_w = 0.5 * m * r_w * r_w
    return {
        "simulation": "wheel_belt_drop",
        "physical_observation": (
            f"A solid disk wheel (m={m:.3f} kg, r={r_w:.3f} m) is dropped from rest above a "
            f"conveyor belt running at v_belt={v_belt:+.3f} m/s. Belt friction (mu_belt={mu_belt:.2f}) "
            f"spins up the wheel; it then rolls off the edge, falls to the floor, bounces "
            f"(e_g={e_g:.2f}) under Coulomb friction (mu_g={mu_g:.2f}) using a Routh decoupled-impulse "
            f"map, and finally rolls to rest."
        ),
        "physical_law": {
            "name": "Newton 2nd law + Coulomb friction (slipping) + Routh decoupled-impulse map (bounces)",
            "statement": "On belt: m dvx/dt = -mu_belt m g sign(s); I domega/dt = r_w F. Routh impulse: J_n = -(1+e) m vy; J_t = clip(stick, mu cone).",
            "formula": "v_x* = v_belt/3, omega* = 2 v_belt/(3 r_w) at end of slip on belt"
        },
        "ode_system": {
            "state_variables": ["x, y (centre)", "vx, vy", "theta, omega"],
            "equations": [
                "Free fall: dvy/dt = -g, others = 0",
                "Slip on belt: dvx/dt = -mu_belt g sign(s), domega/dt = -2 mu_belt g / r_w sign(s)",
                "Roll on belt: vx, omega constant; ride to right edge",
                "Bounces on floor: discrete Routh impulse + free flight between"
            ]
        },
        "derivation_steps": [
            f"Disk MOI: I = (1/2) m r_w^2 = {I_w:.6f} kg m^2.",
            "Phase 1: free fall to belt y = belt_y + r_w.",
            "Phase 2: belt impact perfectly inelastic (vy = 0).",
            f"Phase 3: slip s = vx + omega r_w - v_belt; ds/dt = -3 mu g sign(s); ends at v_x* = v_belt/3 = {v_belt/3:.3f} m/s.",
            "Phase 4: roll on belt at constant v_x*, omega*.",
            "Phase 5: free fall belt → floor.",
            "Phase 6+: chain of Routh-impulse bounces until vy < threshold.",
            "Phase 7: floor slip equilibration, then pure rolling under rolling resistance to rest."
        ],
        "physical_constants_derived": {
            "I_w": round(I_w, 6),
            "v_x_star": round(v_belt / 3.0, 4),
            "omega_star": round(2 * v_belt / (3 * r_w), 4)
        },
        "numerical_method": {
            "solver": "Closed-form per-phase kinematics + Routh decoupled-impulse map at each bounce",
            "tolerance": "Exact within IEEE float"
        },
        "code_validation": {
            "ode_source": "Newton 2nd + Coulomb friction; Routh impulse derivation",
            "energy_check": "Belt friction and bounces dissipate energy; total decreases monotonically",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Wheel falls onto belt, accelerates to v_x* = {v_belt/3:.2f} m/s.",
            "Rolls off, bounces a few times on the floor with decreasing height.",
            "Settles into rolling and decelerates to rest."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# wheel_down_stairs
# ────────────────────────────────────────────────────────────────────────────
def cot_wheel_down_stairs(params):
    g = params["g"]; m_w = params["m_w"]; R_w = params["R_w"]
    v_x_0 = params["v_x_0"]; e_g = params["e_g"]; mu_g = params["mu_g"]
    mu_r = params["mu_r"]
    N_steps = int(round(params["N_steps"]))
    w_step = params["w_step"]; h_step = params["h_step"]
    h_top = N_steps * h_step
    I_com = 0.5 * m_w * R_w * R_w
    I_edge = I_com + m_w * R_w * R_w
    return {
        "simulation": "wheel_down_stairs",
        "physical_observation": (
            f"A solid disk wheel (m={m_w:.3f} kg, R={R_w:.3f} m) rolls without slipping leftward "
            f"with v_x={v_x_0:+.3f} m/s, omega={-v_x_0/R_w:+.3f} rad/s, off the top of a "
            f"staircase (N={N_steps} steps, each w={w_step:.3f} m by h={h_step:.3f} m, total drop "
            f"{h_top:.3f} m). The wheel pivots over each top edge, falls/bounces between steps "
            f"under Routh decoupled-impulse contacts (e_g={e_g:.2f}, mu_g={mu_g:.2f}), and "
            f"finally rolls under rolling resistance (mu_r={mu_r:.3f}) on the lower floor."
        ),
        "physical_law": {
            "name": "Rigid-body pivot ODE + free-flight + Routh impulse map at every contact",
            "statement": "Pivot: I_edge phi_ddot = m g R sin phi. Detach when N=0 (phi_dot^2 = g cos phi / R). Free flight: ddot{r}=−g e_y. Contacts: Routh decoupled normal/tangent impulse with friction cone.",
            "formula": "I_edge phi_ddot = m g R sin(phi); detach @ phi_dot^2 R = g cos(phi)"
        },
        "ode_system": {
            "state_variables": ["x, y, theta (centre + body angle)", "vx, vy, omega"],
            "equations": [
                "Pure rolling on horizontal: x = X_0 + v_x_0 t, theta = omega_0 t",
                "Pivot: phi_ddot = (2g/(3 R)) sin phi (with I_edge = (3/2) m R^2)",
                "Free flight: dvy/dt = -g, others = 0",
                "Contact impulse: J_n = -(1+e_g) m_eff vc_n; J_t = clip(stick, mu_g cone)"
            ]
        },
        "derivation_steps": [
            f"Disk MOI: I_com = (1/2) m R^2 = {I_com:.6f} kg m^2.",
            f"Pivot MOI: I_edge = I_com + m R^2 = (3/2) m R^2 = {I_edge:.6f} kg m^2.",
            "Phase 1: pure rolling on upper floor until centre reaches the first edge.",
            "Pivot phase: phi_ddot = (2g/(3R)) sin(phi); detach when N→0 i.e. phi_dot^2 = g cos(phi)/R.",
            "Free-flight phases: parabolic arcs between contacts.",
            "Routh impulse map: n_hat is local surface normal (top: +y; corner: radial direction).",
            "Settled wheel: slip equilibration on lower floor, then rolling under resistance to rest."
        ],
        "physical_constants_derived": {
            "I_com": round(I_com, 6),
            "I_edge": round(I_edge, 6),
            "h_top": round(h_top, 4),
            "omega_0": round(-v_x_0 / R_w, 4)
        },
        "numerical_method": {
            "solver": "scipy.integrate.solve_ivp (RK45) for pivot ODE and free-flight; closed-form impulses",
            "tolerance": "rtol=1e-9, atol=1e-11, max_step=0.005"
        },
        "code_validation": {
            "ode_source": "Standard Lagrangian for rolling and pivoting; Routh decoupled friction-cone impulse model",
            "energy_check": "Pivot phases conserve energy; impulses dissipate KE; rolling resistance terminates motion",
            "physical_plausibility": True
        },
        "expected_behavior": [
            "Wheel rolls to the first edge, pivots over it.",
            "Detaches when normal force vanishes; free-flies and contacts the next surface.",
            "After several bounces, settles on the lower floor and rolls to rest."
        ],
        "parameters": params,
    }


# ────────────────────────────────────────────────────────────────────────────
# wheel_wall_bounce
# ────────────────────────────────────────────────────────────────────────────
def cot_wheel_wall_bounce(params):
    g = params["g"]; m = params["m"]; r_w = params["r_w"]
    v_x_0 = params["v_x_0"]; e_w = params["e_w"]; mu_w = params["mu_w"]
    mu_g = params["mu_g"]; mu_r = params["mu_r"]
    omega_0 = -v_x_0 / r_w
    I_w = 0.5 * m * r_w * r_w
    return {
        "simulation": "wheel_wall_bounce",
        "physical_observation": (
            f"A solid disk wheel (m={m:.3f} kg, r={r_w:.3f} m) rolls without slipping leftward "
            f"with v_x={v_x_0:+.3f} m/s, omega_0={omega_0:+.3f} rad/s, toward a vertical wall. "
            f"Wall impulse uses Newton restitution e_w={e_w:.2f} and Coulomb friction mu_w={mu_w:.2f}; "
            f"the wheel rebounds, slip-equilibrates on the floor (mu_g={mu_g:.2f}), then "
            f"rolls under rolling resistance (mu_r={mu_r:.3f}) until rest."
        ),
        "physical_law": {
            "name": "Routh decoupled-impulse map (wall) + Coulomb friction (floor)",
            "statement": "Wall impulse: J_n = -(1+e_w) m vx; J_t = clip(stick, mu_w cone). Floor slip: ds/dt = -3 mu_g g sign(s).",
            "formula": "v_x_new = -e_w v_x; omega_new = omega/3 (stick branch)"
        },
        "ode_system": {
            "state_variables": ["x, vx (centre)", "theta, omega"],
            "equations": [
                "Phase 1 rolling: dx/dt = vx (constant), dtheta/dt = omega (constant)",
                "Phase 2 wall impulse (instantaneous)",
                "Phase 3 slip on floor: dvx/dt = -mu_g g sign(s), domega/dt = -2 mu_g g/r_w sign(s)",
                "Phase 4 rolling decel: dvx/dt = -mu_r g; omega = -vx/r_w"
            ]
        },
        "derivation_steps": [
            f"Disk MOI: I_w = (1/2) m r_w^2 = {I_w:.6f} kg m^2.",
            "Phase 1: x(t) = X_0 + v_x_0 t; impact at x = x_wall + r_w.",
            f"Wall impulse normal: J_n = -(1+e_w) m vx = {-(1+e_w)*m*v_x_0:.4f} N·s.",
            "Tangent impulse: stick value J_t_stk = r_w omega m / 3, clipped to mu_w |J_n| cone.",
            "If stick: v_x' = -e_w v_x; v_y' = J_t/m; omega' = omega - r_w J_t / I_w.",
            "Phase 3: post-bounce slip s_0 = vx_post + omega_post r_w; t_slip = |s_0|/(3 mu_g g).",
            "Phase 4: rolling under rolling resistance until rest."
        ],
        "physical_constants_derived": {
            "I_w": round(I_w, 6),
            "omega_0": round(omega_0, 4),
            "stick_threshold_mu": round(1.0 / (3.0 * (1.0 + e_w)), 4)
        },
        "numerical_method": {
            "solver": "Closed-form per-phase kinematics + decoupled-impulse map at the wall",
            "tolerance": "Exact within IEEE float"
        },
        "code_validation": {
            "ode_source": "Newton 2nd + Routh decoupled impulse for inelastic frictional contact",
            "energy_check": "Energy decreases at wall impulse and via friction afterwards",
            "physical_plausibility": True
        },
        "expected_behavior": [
            f"Wheel rolls toward wall, hits it.",
            "Rebounds rightward with reduced speed; slip resolves on floor.",
            "Rolls under rolling resistance until rest."
        ],
        "parameters": params,
    }


COT_GENERATORS = {
    "simple_pendulum":          cot_simple_pendulum,
    "double_pendulum":          cot_double_pendulum,
    "single_spring":            cot_single_spring,
    "double_spring":            cot_double_spring,
    "cart_pendulum":            cot_cart_pendulum,
    "moveable_pendulum":        cot_moveable_pendulum,
    "rigid_double_pendulum":    cot_rigid_double_pendulum,
    "moveable_double_pendulum": cot_moveable_double_pendulum,
    "spring_2d":                cot_spring_2d,
    "double_2d_spring":         cot_double_2d_spring,
    "dangle_stick":             cot_dangle_stick,
    "chain_of_springs":         cot_chain_of_springs,
    "molecule_2":               cot_molecule_2,
    "roller_single":            cot_roller_single,
    "brachistochrone":          cot_brachistochrone,
    "lagrange_roller":          cot_lagrange_roller,
    "magnet_wheel":             cot_magnet_wheel,
    "robot_speed":              cot_robot_speed,
    "complex_collision_plane":  cot_complex_collision_plane,
    "ballistic_pendulum":       cot_ballistic_pendulum,
    "sand_onto_moving_cart":    cot_sand_onto_moving_cart,
    "accelerating_cart_sliding_mass": cot_accelerating_cart_sliding_mass,
    "watt_straight_line_linkage": cot_watt_straight_line_linkage,
    "u_tube_fluid_oscillation": cot_u_tube_fluid_oscillation,
    "spool_pull_direction_2d":  cot_spool_pull_direction_2d,
    "differential_pulley_chain_fall": cot_differential_pulley_chain_fall,
    "rolling_race_hoop_vs_disk_vs_sphere": cot_rolling_race_hoop_vs_disk_vs_sphere,
    "spinning_ball_on_moving_belt": cot_spinning_ball_on_moving_belt,    "accelerating_beaker_water": cot_accelerating_beaker_water,
    "atwood_on_table": cot_atwood_on_table,
    "ball_wrapping_pole": cot_ball_wrapping_pole,
    "balls_in_basin": cot_balls_in_basin,
    "belt_gear_rack_train": cot_belt_gear_rack_train,
    "billiards_break": cot_billiards_break,
    "block_belt_spring_stickslip": cot_block_belt_spring_stickslip,
    "block_chain_collision": cot_block_chain_collision,
    "block_on_sphere_basin": cot_block_on_sphere_basin,
    "block_strikes_spring_pair": cot_block_strikes_spring_pair,
    "bouncing_rod": cot_bouncing_rod,
    "brachistochrone_race": cot_brachistochrone_race,
    "cart_two_metronomes": cot_cart_two_metronomes,
    "colliding_blocks": cot_colliding_blocks,
    "compound_atwood": cot_compound_atwood,
    "conveyor_belt_drop": cot_conveyor_belt_drop,
    "cylinder_piston_ball": cot_cylinder_piston_ball,
    "discs_friction_coupling": cot_discs_friction_coupling,
    "disk_spinoff": cot_disk_spinoff,
    "driven_string_fixed": cot_driven_string_fixed,
    "driven_string_ring": cot_driven_string_ring,
    "falling_spring": cot_falling_spring,
    "gear_rack_spring_oscillator": cot_gear_rack_spring_oscillator,
    "half_cylinder_drop": cot_half_cylinder_drop,
    "hammer_projectile_bounce": cot_hammer_projectile_bounce,
    "hemisphere_roll_off": cot_hemisphere_roll_off,
    "pendulum_block_strike": cot_pendulum_block_strike,
    "pendulum_slack_revolution": cot_pendulum_slack_revolution,
    "projectile_bounce": cot_projectile_bounce,
    "ring_pendulum": cot_ring_pendulum,
    "ring_sticky_collision": cot_ring_sticky_collision,
    "rod_ball_strike": cot_rod_ball_strike,
    "semicircular_track": cot_semicircular_track,
    "slab_springs_block_drop": cot_slab_springs_block_drop,
    "sliding_block_step_topple": cot_sliding_block_step_topple,
    "spinning_ball_bounce": cot_spinning_ball_bounce,
    "spinning_disc_block_spring": cot_spinning_disc_block_spring,
    "spring_atwood": cot_spring_atwood,
    "spring_mass_string_fixed": cot_spring_mass_string_fixed,
    "spring_mass_string_ring": cot_spring_mass_string_ring,
    "springs_two_slabs_compound": cot_springs_two_slabs_compound,
    "stacked_balls_drop": cot_stacked_balls_drop,
    "string_block_wave": cot_string_block_wave,
    "string_ring_wave": cot_string_ring_wave,
    "three_body_gravity": cot_three_body_gravity,
    "three_gear_chain": cot_three_gear_chain,
    "three_gear_middle_drive": cot_three_gear_middle_drive,
    "tilting_wedge_cylinder": cot_tilting_wedge_cylinder,
    "toppling_cylinder_wedge": cot_toppling_cylinder_wedge,
    "two_body_gravity": cot_two_body_gravity,
    "two_carts_slack_string": cot_two_carts_slack_string,
    "two_conveyor_drop": cot_two_conveyor_drop,
    "two_gear_belt": cot_two_gear_belt,
    "wave_interference": cot_wave_interference,
    "wedge_block": cot_wedge_block,
    "wedge_sphere": cot_wedge_sphere,
    "wheel_belt_drop": cot_wheel_belt_drop,
    "wheel_down_stairs": cot_wheel_down_stairs,
    "wheel_wall_bounce": cot_wheel_wall_bounce,

}


# ─────────────────────────────────────────────────────────────────────────────
# Unicode → LaTeX / Python conversion
# ─────────────────────────────────────────────────────────────────────────────
# LLMs tokenize LaTeX far better than Unicode (LaTeX is standard in ArXiv /
# Wikipedia / textbooks; combining diacritics and sub/superscript codepoints
# are off-distribution and fragment into many BPE tokens). We emit equations
# in both LaTeX (for physics reasoning) and Python (for code-generation grounding).
# ─────────────────────────────────────────────────────────────────────────────

_GREEK_LOWER = {
    "α": "alpha", "β": "beta",  "γ": "gamma", "δ": "delta", "ε": "epsilon",
    "ζ": "zeta",  "η": "eta",   "θ": "theta", "ι": "iota",  "κ": "kappa",
    "λ": "lambda","μ": "mu",    "ν": "nu",    "ξ": "xi",    "π": "pi",
    "ρ": "rho",   "σ": "sigma", "τ": "tau",   "υ": "upsilon","φ": "phi",
    "χ": "chi",   "ψ": "psi",   "ω": "omega",
}
_GREEK_UPPER = {
    "Γ": "Gamma", "Δ": "Delta", "Θ": "Theta", "Λ": "Lambda", "Π": "Pi",
    "Σ": "Sigma", "Φ": "Phi",   "Ψ": "Psi",   "Ω": "Omega",
}
_SUBSCRIPT_DIGIT   = {"₀":"0","₁":"1","₂":"2","₃":"3","₄":"4",
                      "₅":"5","₆":"6","₇":"7","₈":"8","₉":"9"}
_SUPERSCRIPT_DIGIT = {"⁰":"0","¹":"1","²":"2","³":"3","⁴":"4",
                      "⁵":"5","⁶":"6","⁷":"7","⁸":"8","⁹":"9"}
# Latin letter subscripts (scattered across U+2090-209C and U+1D62-1D66).
# Used for indexed quantities like τᵢ, mⱼ, ωₙ. These emit `_i`, `_j`, `_n`
# (with leading underscore) in BOTH LaTeX and Python, matching the
# Python convention `tau_i`, `m_j`.
_SUBSCRIPT_LETTER = {
    "ₐ":"a","ₑ":"e","ₕ":"h","ᵢ":"i","ⱼ":"j","ₖ":"k","ₗ":"l","ₘ":"m",
    "ₙ":"n","ₒ":"o","ₚ":"p","ᵣ":"r","ₛ":"s","ₜ":"t","ᵤ":"u","ᵥ":"v","ₓ":"x",
}
_COMB_DOT  = "\u0307"   # combining dot above    → derivative
_COMB_DDOT = "\u0308"   # combining diaeresis    → 2nd derivative

_LATEX_SYM = {
    "−": "-", "·": " \\cdot ", "×": " \\times ", "÷": " \\div ",
    "±": " \\pm ",  "∓": " \\mp ",
    "≈": " \\approx ", "≤": " \\leq ", "≥": " \\geq ", "≠": " \\neq ",
    "≡": " \\equiv ", "≅": " \\cong ", "∼": " \\sim ", "≪": " \\ll ", "≫": " \\gg ",
    "→": " \\rightarrow ", "⇐": " \\Leftarrow ", "⇒": " \\Rightarrow ",
    "↔": " \\leftrightarrow ", "⇔": " \\Leftrightarrow ",
    "∞": " \\infty ", "∂": " \\partial ",  "∫": " \\int ",
    "∑": " \\sum ",  "∏": " \\prod ", "∇": " \\nabla ",
    "∈": " \\in ", "∉": " \\notin ", "⊂": " \\subset ", "⊆": " \\subseteq ",
    "⊃": " \\supset ", "⊇": " \\supseteq ", "∪": " \\cup ", "∩": " \\cap ",
    "∅": " \\emptyset ", "∀": " \\forall ", "∃": " \\exists ",
    "¬": " \\neg ", "∧": " \\wedge ", "∨": " \\vee ",
    "∝": " \\propto ", "⊕": " \\oplus ", "⊗": " \\otimes ",
    "⟨": " \\langle ", "⟩": " \\rangle ",
    "½": " \\tfrac{1}{2} ", "¼": " \\tfrac{1}{4} ", "¾": " \\tfrac{3}{4} ",
    "√": " \\sqrt ", "°": "^{\\circ}",
    # Punctuation / typographic chars (not math but still non-ASCII)
    "—": "---", "–": "--", "…": "...", "“": '"', "”": '"', "‘": "'", "’": "'",
}
_PY_SYM = {
    "−": "-", "·": " * ", "×": " * ", "÷": " / ",
    "±": " ",  "∓": " ",
    "≈": " ~= ", "≤": " <= ", "≥": " >= ", "≠": " != ",
    "≡": " == ", "∼": " ~= ", "≪": " << ", "≫": " >> ",
    "→": " -> ", "⇐": " <= ", "⇒": " => ", "↔": " <-> ", "⇔": " <=> ",
    "∞": "float('inf')", "∂": "d", "∫": "integral",
    "∑": "sum", "∏": "prod", "∇": "grad",
    "∈": " in ", "∉": " not in ", "∝": " ~ ",
    "∪": " | ", "∩": " & ", "∧": " and ", "∨": " or ", "¬": " not ",
    "⊕": " ^ ", "⊗": " * ",
    "½": "0.5", "¼": "0.25", "¾": "0.75",
    "√": "np.sqrt", "°": "*np.pi/180",
    "⟨": "(", "⟩": ")",
    # Typographic chars
    "—": "---", "–": "--", "…": "...", "“": '"', "”": '"', "‘": "'", "’": "'",
}
_MATH_FUNCS = ("sin", "cos", "tan", "sinh", "cosh", "tanh",
               "arctan", "arcsin", "arccos", "atan", "asin", "acos",
               "sqrt", "exp", "log", "ln")


def _unicode_to_latex(s: Any) -> Any:
    """Char-by-char Unicode → LaTeX conversion. Looks ahead one char for
    combining diacritics (̇ ̈) and wraps base char in \\dot{} / \\ddot{}.
    Also wraps bare math functions like sin → \\sin."""
    if not isinstance(s, str) or not s:
        return s
    s = unicodedata.normalize("NFD", s)   # decompose ẍ → x+̈, θ̇ stays θ+̇
    out: list[str] = []
    i, n = 0, len(s)
    while i < n:
        ch = s[i]
        nxt = s[i+1] if i+1 < n else ""
        if ch in _GREEK_LOWER:
            tok = "\\" + _GREEK_LOWER[ch]
        elif ch in _GREEK_UPPER:
            tok = "\\" + _GREEK_UPPER[ch]
        elif ch in _SUBSCRIPT_DIGIT:
            tok = "_" + _SUBSCRIPT_DIGIT[ch]
        elif ch in _SUBSCRIPT_LETTER:
            tok = "_" + _SUBSCRIPT_LETTER[ch]
        elif ch in _SUPERSCRIPT_DIGIT:
            tok = "^" + _SUPERSCRIPT_DIGIT[ch]
        elif ch in _LATEX_SYM:
            tok = _LATEX_SYM[ch]
        else:
            tok = ch
        if nxt == _COMB_DOT:
            out.append("\\dot{" + tok + "}")
            i += 2
        elif nxt == _COMB_DDOT:
            out.append("\\ddot{" + tok + "}")
            i += 2
        else:
            out.append(tok)
            i += 1
    r = "".join(out)
    # Wrap math functions. Use a custom boundary that treats digits and
    # underscores as NON-word for this purpose (so 'L_2sin' → 'L_2\sin').
    for fn in _MATH_FUNCS:
        r = re.sub(rf"(?<![\\a-zA-Z]){fn}(?![a-zA-Z])", rf"\\{fn}", r)
    return r


def _unicode_to_python(s: Any) -> Any:
    """Char-by-char Unicode → Python conversion. Greek → ASCII names,
    subscripts → digits (no underscore, matching param naming),
    superscripts → **N, combining dot/ddot → _dot/_ddot suffix,
    math funcs → np.X. Inserts * between ')' and identifier/'('."""
    if not isinstance(s, str) or not s:
        return s
    s = unicodedata.normalize("NFD", s)   # decompose ẍ → x+̈, θ̇ stays θ+̇
    out: list[str] = []
    i, n = 0, len(s)
    while i < n:
        ch = s[i]
        nxt = s[i+1] if i+1 < n else ""
        if ch in _GREEK_LOWER:
            tok = _GREEK_LOWER[ch]
        elif ch in _GREEK_UPPER:
            tok = _GREEK_UPPER[ch]
        elif ch in _SUBSCRIPT_DIGIT:
            tok = _SUBSCRIPT_DIGIT[ch]
        elif ch in _SUBSCRIPT_LETTER:
            tok = "_" + _SUBSCRIPT_LETTER[ch]
        elif ch in _SUPERSCRIPT_DIGIT:
            tok = "**" + _SUPERSCRIPT_DIGIT[ch]
        elif ch in _PY_SYM:
            tok = _PY_SYM[ch]
        else:
            tok = ch
        if nxt == _COMB_DOT:
            out.append(tok + "_dot")
            i += 2
        elif nxt == _COMB_DDOT:
            out.append(tok + "_ddot")
            i += 2
        else:
            out.append(tok)
            i += 1
    r = "".join(out)
    # Insert explicit '*' between adjacent tokens FIRST, so that tokens like
    # 'm2cos(...)' become 'm2 * cos(...)' and the function-wrapping below
    # can then match the now-standalone 'cos'.
    r = re.sub(r"(\))(\s*)([A-Za-z_(])", r"\1\2 * \3", r)
    r = re.sub(r"(\d)(\s*)([A-Za-z_(])", r"\1\2 * \3", r)
    for fn in _MATH_FUNCS:
        if fn == "ln":
            r = re.sub(r"(?<!\.)\bln\b", "np.log", r)
        else:
            r = re.sub(rf"(?<!np\.)(?<!\.)\b{fn}\b", rf"np.{fn}", r)
    return r


def _walk_latex(val: Any) -> Any:
    """Recursively apply _unicode_to_latex to every string in a nested
    structure (dict values, list items, dict keys)."""
    if isinstance(val, str):
        return _unicode_to_latex(val)
    if isinstance(val, dict):
        return {_unicode_to_latex(k) if isinstance(k, str) else k: _walk_latex(v)
                for k, v in val.items()}
    if isinstance(val, list):
        return [_walk_latex(v) for v in val]
    return val


def _transform_cot_equations(cot: dict) -> dict:
    """Post-process a CoT dict:
      1. Split `ode_system.equations` (Unicode) into `equations_latex`
         + `equations_python` lists.
      2. Recursively convert every other string in the CoT to LaTeX so
         no raw Unicode math/punctuation remains anywhere."""
    # Step 1: split ode equations (must happen BEFORE the recursive walk
    # so that equations_python doesn't get re-walked as LaTeX).
    if "ode_system" in cot and isinstance(cot["ode_system"], dict):
        ode = cot["ode_system"]
        if "equations" in ode:
            equations = ode.pop("equations")
            ode["equations_latex"]  = [_unicode_to_latex(e)  for e in equations]
            ode["equations_python"] = [_unicode_to_python(e) for e in equations]

    # Step 2: stash the Python equations, LaTeX-walk the rest, restore.
    py_eqs = None
    if "ode_system" in cot and "equations_python" in cot["ode_system"]:
        py_eqs = cot["ode_system"].pop("equations_python")

    cot = _walk_latex(cot)

    if py_eqs is not None:
        cot["ode_system"]["equations_python"] = py_eqs
    return cot


# ─────────────────────────────────────────────────────────────────────────────
# ASCII normalization for variable keys (Greek letters + Unicode subscripts).
# We standardize on ASCII so 'parameters' and 'variables' use the same names.
# ─────────────────────────────────────────────────────────────────────────────
_UNICODE_GREEK = {
    "α": "alpha", "β": "beta",  "γ": "gamma", "δ": "delta",
    "ε": "epsilon", "ζ": "zeta", "η": "eta", "θ": "theta",
    "ι": "iota", "κ": "kappa", "λ": "lambda", "μ": "mu",
    "ν": "nu", "ξ": "xi", "π": "pi", "ρ": "rho",
    "σ": "sigma", "τ": "tau", "υ": "upsilon", "φ": "phi",
    "χ": "chi", "ψ": "psi", "ω": "omega",
    "Α": "Alpha", "Β": "Beta", "Γ": "Gamma", "Δ": "Delta",
    "Θ": "Theta", "Λ": "Lambda", "Π": "Pi", "Σ": "Sigma",
    "Φ": "Phi", "Ω": "Omega",
}
_UNICODE_SUB = {"₀": "0", "₁": "1", "₂": "2", "₃": "3", "₄": "4",
                "₅": "5", "₆": "6", "₇": "7", "₈": "8", "₉": "9"}
_UNICODE_DOT  = {"̇": "_dot", "̈": "_ddot"}  # combining diacritic above

def _to_ascii_key(s: str) -> str:
    out = []
    for ch in s:
        if ch in _UNICODE_GREEK:
            out.append(_UNICODE_GREEK[ch])
        elif ch in _UNICODE_SUB:
            out.append(_UNICODE_SUB[ch])
        elif ch in _UNICODE_DOT:
            out.append(_UNICODE_DOT[ch])
        else:
            out.append(ch)
    return "".join(out)


def _merge_params_and_variables(params_raw: dict[str, Any],
                                variables: dict[str, Any]) -> dict[str, Any]:
    """Build a single dict keyed by ASCII param names, with rich entries:
       {value, unit, description}. Pulls unit/description from `variables`
       by ASCII-normalizing variable keys and matching against param keys
       (with fallback for '_0' / trailing '0' initial-condition suffixes)."""
    var_lookup: dict[str, dict] = {}
    for vk, vv in variables.items():
        ascii_vk = _to_ascii_key(vk)
        if isinstance(vv, dict):
            var_lookup[ascii_vk] = vv
        else:
            var_lookup[ascii_vk] = {"value": vv}

    merged: dict[str, dict] = {}
    for pkey, pval in params_raw.items():
        candidates = [pkey]
        if pkey.endswith("_0"):
            candidates.append(pkey[:-2])
        elif pkey.endswith("0") and len(pkey) > 1 and not pkey[-2].isdigit():
            candidates.append(pkey[:-1])
        entry = next((var_lookup[c] for c in candidates if c in var_lookup), None)

        unit = entry.get("unit", "") if entry else ""
        desc = entry.get("description", "") if entry else ""
        merged[pkey] = {"value": pval, "unit": unit, "description": desc}
    return merged


def generate_cot(simulation_name: str, params: dict[str, Any]) -> dict:
    """Generate a structured CoT dict for a given simulation and parameter set.

    Post-processing applied uniformly to all generators:
      1. Merge `variables` into `parameters` so there is a single source of
         truth, keyed by ASCII param names with {value, unit, description}.
      2. Place the merged `parameters` key at the END so the model first
         derives the equations, then reads off the numerical values.
    """
    if simulation_name not in COT_GENERATORS:
        raise ValueError(f"Unknown simulation: {simulation_name!r}. "
                         f"Available: {list(COT_GENERATORS.keys())}")
    cot = COT_GENERATORS[simulation_name](params)
    cot = _transform_cot_equations(cot)
    params_raw = cot.pop("parameters", params)
    variables  = cot.pop("variables", {})
    cot["parameters"] = _merge_params_and_variables(params_raw, variables)
    return cot
