"""Kubric/PyBullet COT helpers.

Kubric experiment modules build COTs through simulations.kubric_3d._base.
This module is the engine-specific import surface for that functionality.
"""

from simulations.kubric_3d._base import build_cot, param_entry

__all__ = ["build_cot", "param_entry"]
