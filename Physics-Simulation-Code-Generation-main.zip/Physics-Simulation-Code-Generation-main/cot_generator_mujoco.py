"""MuJoCo/Sim2Reason COT helpers."""

from simulations.mujoco.sim2reason_cot import build_cot_for_scene, COT_REGISTRY

__all__ = ["build_cot_for_scene", "COT_REGISTRY"]
